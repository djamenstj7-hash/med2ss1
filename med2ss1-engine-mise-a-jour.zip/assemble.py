#!/usr/bin/env python3
"""Assemble a verified, additive MED_ENGINE release over a MED2 S1 checkout."""
from __future__ import annotations

import argparse
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import zipfile

APP = 'med2ss1-engine'
PART_NAME = re.compile(r'med2ss1-engine-contenus-[1-9][0-9]*\.zip\Z')
DIGEST = re.compile(r'[0-9a-f]{64}\Z')
HOST_FILES = {'index.html', 'service-worker.js', 'engine-host.js'}
EXCLUDED = {'.git', '.github', 'node_modules', '__pycache__', 'engine', 'engine-module',
            'engine-src', 'engine-tests', 'scripts', 'qa', 'docs', '.DS_Store'}
MAX_FILES = 20_000
MAX_BYTES = 300 * 1024 * 1024


def sha(path: Path) -> str:
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def relative(value: str) -> PurePosixPath:
    if not isinstance(value, str) or not value or '\\' in value or ':' in value or value.startswith('/'):
        raise ValueError('Chemin de livraison interdit.')
    parts = value.rstrip('/').split('/')
    if any(part in {'', '.', '..'} for part in parts):
        raise ValueError('Chemin de livraison interdit.')
    return PurePosixPath(*parts)


def payload_path(value: str) -> bool:
    path = relative(value)
    return str(path) in HOST_FILES or (len(path.parts) >= 2 and path.parts[0] == 'engine-module'
                                     and path.suffix in {'.js', '.css', '.json', '.map', '.woff2'})


def read_manifest(delivery_root: Path) -> dict:
    manifest_path = delivery_root / 'delivery.json'
    if manifest_path.is_symlink() or not manifest_path.is_file():
        raise ValueError('Le manifeste de la mise à jour manque.')
    data = json.loads(manifest_path.read_text(encoding='utf-8'))
    if not isinstance(data, dict) or data.get('application') != APP or data.get('schemaVersion') != 1:
        raise ValueError('Ce paquet ne cible pas MED2 S1.')
    for key in ('parts', 'payload', 'guards'):
        if not isinstance(data.get(key), list):
            raise ValueError(f'Liste de livraison invalide : {key}.')
    if not 1 <= len(data['parts']) <= 20 or not 3 <= len(data['payload']) <= 200:
        raise ValueError('Nombre de fichiers de livraison invalide.')
    return data


def verify_delivery(delivery_root: Path, repository_root: Path) -> tuple[dict, list[Path]]:
    """Validate every input before touching the publication directory."""
    data = read_manifest(delivery_root)
    payload_names = set()
    for item in data['payload']:
        if not isinstance(item, dict) or not payload_path(item.get('path')):
            raise ValueError('La mise à jour tente de remplacer un fichier non autorisé.')
        name, digest = item['path'], item.get('sha256')
        if name in payload_names or not isinstance(digest, str) or not DIGEST.fullmatch(digest):
            raise ValueError('Entrée du correctif invalide ou dupliquée.')
        path = delivery_root / 'patch' / name
        if path.is_symlink() or not path.is_file() or sha(path) != digest:
            raise ValueError(f'Correctif absent ou endommagé : {name}.')
        payload_names.add(name)
    if not HOST_FILES.issubset(payload_names):
        raise ValueError('La mise à jour est incomplète : les fichiers de l’interface manquent.')
    patch_root = delivery_root / 'patch'
    actual = set()
    for path in patch_root.rglob('*'):
        if path.is_symlink():
            raise ValueError('Les liens symboliques ne sont pas acceptés.')
        if path.is_file():
            actual.add(path.relative_to(patch_root).as_posix())
    if actual != payload_names:
        raise ValueError('Le correctif contient des fichiers non déclarés.')

    guards = set()
    for item in data['guards']:
        if not isinstance(item, dict) or item.get('path') not in HOST_FILES:
            raise ValueError('Garde de compatibilité invalide.')
        name = item['path']
        allowed = item.get('acceptedSha256')
        if name in guards or not isinstance(allowed, list) or not allowed or any(
                digest is not None and (not isinstance(digest, str) or not DIGEST.fullmatch(digest))
                for digest in allowed):
            raise ValueError('Empreinte de compatibilité invalide.')
        path = repository_root / name
        if path.is_symlink():
            raise ValueError(f'Fichier hôte non autorisé : {name}.')
        actual_digest = sha(path) if path.is_file() else None
        if actual_digest not in allowed:
            raise ValueError(f'La version de {name} a changé depuis la préparation du paquet. '
                             'La publication est arrêtée pour préserver cette nouvelle version. '
                             'Demande un paquet adapté ; les fichiers data et Assets ne sont pas en cause.')
        guards.add(name)
    if guards != HOST_FILES:
        raise ValueError('Les trois fichiers hôtes doivent être protégés par une empreinte.')

    archives = []
    names = set()
    for item in data['parts']:
        if not isinstance(item, dict):
            raise ValueError('Partie de contenu invalide.')
        name, digest = item.get('file'), item.get('sha256')
        if not isinstance(name, str) or not PART_NAME.fullmatch(name) or name in names:
            raise ValueError('Nom de partie de contenu invalide.')
        if not isinstance(digest, str) or not DIGEST.fullmatch(digest):
            raise ValueError('Empreinte de partie invalide.')
        path = repository_root / name
        if path.is_symlink() or not path.is_file():
            raise ValueError(f'Partie manquante : {name}. Envoie les trois ZIP à la racine du dépôt.')
        if sha(path) != digest:
            raise ValueError(f'Le fichier {name} ne correspond pas à cette livraison. Remplace ce ZIP.')
        names.add(name)
        archives.append(path)

    entries, total, found, directories = 0, 0, set(), set()
    for archive in archives:
        with zipfile.ZipFile(archive) as bundle:
            for entry in bundle.infolist():
                entries += 1
                total += entry.file_size
                if entries > MAX_FILES or total > MAX_BYTES:
                    raise ValueError('La taille du contenu dépasse la limite autorisée.')
                path = relative(entry.filename)
                mode = entry.external_attr >> 16
                if path.parts[0] != 'engine' or len(path.parts) < 2 or stat.S_ISLNK(mode):
                    raise ValueError('Une partie contient un chemin interdit.')
                name = str(path)
                if entry.is_dir():
                    if name in found:
                        raise ValueError('Collision de dossier dans les contenus.')
                    directories.add(name)
                    continue
                if name in found or name in directories or any(str(parent) in found for parent in path.parents):
                    raise ValueError('Fichier de contenu dupliqué ou en collision.')
                found.add(name)
                directories.update(str(parent) for parent in path.parents)
            if bundle.testzip() is not None:
                raise ValueError(f'Le ZIP {archive.name} est endommagé.')
    expected = data.get('engineFiles')
    if not isinstance(expected, int) or expected != len(found) or 'engine/manifest.json' not in found:
        raise ValueError('La liste des contenus MED_ENGINE est incomplète.')
    return data, archives


def public_file(path: Path, repository_root: Path) -> bool:
    rel = path.relative_to(repository_root)
    # These already-public content trees are preserved byte for byte, including
    # the historical Assets/.svg and data/.gitkeep entries in this repository.
    public_content = rel.parts[0] in {'data', 'Assets'}
    return not any(part in EXCLUDED or (part.startswith('.') and not public_content) for part in rel.parts) and not (
        path.suffix.lower() in {'.zip', '.py', '.ts', '.tsx', '.cjs'} or
        rel.name in {'package.json', 'package-lock.json', 'engine-integration.json'} or
        rel.name.startswith(('tsconfig.', 'vite.', 'vitest.')))


class Scripts(HTMLParser):
    def __init__(self):
        super().__init__()
        self.active = False
        self.scripts = []
        self.current = []

    def handle_starttag(self, tag, attrs):
        values = dict(attrs)
        if tag.lower() == 'script' and 'src' not in values and values.get('type', '') in {'', 'text/javascript', 'module'}:
            self.active = True
            self.current = []

    def handle_data(self, data):
        if self.active:
            self.current.append(data)

    def handle_endtag(self, tag):
        if tag.lower() == 'script' and self.active:
            self.active = False
            self.scripts.append(''.join(self.current))


def check_javascript(output: Path) -> None:
    parser = Scripts()
    parser.feed((output / 'index.html').read_text(encoding='utf-8'))
    with tempfile.TemporaryDirectory(prefix='med2-engine-js-') as folder:
        for index, content in enumerate(parser.scripts):
            path = Path(folder) / f'inline-{index}.mjs'
            path.write_text(content, encoding='utf-8')
            subprocess.run(['node', '--check', str(path)], check=True, capture_output=True, text=True)
    for path in [output / 'engine-host.js', output / 'service-worker.js', *sorted((output / 'engine-module').glob('*.js'))]:
        subprocess.run(['node', '--check', str(path)], check=True, capture_output=True, text=True)


def assemble(repository_root: Path, delivery_root: Path, output: Path, check_js: bool = True) -> dict:
    repository_root, delivery_root, output = repository_root.resolve(), delivery_root.resolve(), output.resolve()
    if (output == repository_root or output.is_relative_to(repository_root) or
            repository_root.is_relative_to(output) or output == delivery_root or output.is_relative_to(delivery_root)):
        raise ValueError('Le dossier de publication doit être distinct des sources et de la livraison.')
    if output.exists() and any(output.iterdir()):
        raise ValueError('Le dossier de publication doit être vide.')
    data, archives = verify_delivery(delivery_root, repository_root)
    source_files = []
    for path in repository_root.rglob('*'):
        if not public_file(path, repository_root):
            continue
        if path.is_symlink():
            raise ValueError('Un fichier public est un lien symbolique non accepté.')
        if path.is_file():
            source_files.append(path)
    output.mkdir(parents=True, exist_ok=True)
    for path in source_files:
        destination = output / path.relative_to(repository_root)
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, destination)
    for item in data['payload']:
        destination = output / item['path']
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(delivery_root / 'patch' / item['path'], destination)
    for archive in archives:
        with zipfile.ZipFile(archive) as bundle:
            for entry in bundle.infolist():
                target = output / str(relative(entry.filename))
                if entry.is_dir():
                    target.mkdir(parents=True, exist_ok=True)
                else:
                    target.parent.mkdir(parents=True, exist_ok=True)
                    with bundle.open(entry) as source, target.open('xb') as destination:
                        shutil.copyfileobj(source, destination)
    (output / '.nojekyll').write_text('', encoding='utf-8')
    report = {'application': APP, 'version': data.get('version'), 'sourceCommit': data.get('baseCommit'),
              'engineFiles': data['engineFiles'], 'preservedFiles': len(source_files)}
    (output / 'engine-integration.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    if check_js:
        check_javascript(output)
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repository-root', type=Path, required=True)
    parser.add_argument('--delivery-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    try:
        report = assemble(args.repository_root, args.delivery_root, args.output)
    except (ValueError, OSError, zipfile.BadZipFile, RuntimeError, subprocess.CalledProcessError) as error:
        print(f'Installation MED_ENGINE interrompue : {error}', file=sys.stderr)
        return 1
    print(json.dumps(report, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
