import { defineConfig } from 'vite';
import { readFileSync } from 'node:fs';

const thirdPartyNotices = ['react/LICENSE', 'react-dom/LICENSE', 'scheduler/LICENSE', 'lucide-react/LICENSE', 'idb-keyval/LICENCE', 'ts-fsrs/LICENSE']
  .map(path => `${path}\n${readFileSync(new URL(`./node_modules/${path}`, import.meta.url), 'utf8')}`)
  .join('\n\n');

export default defineConfig({
  base: './',
  publicDir: false,
  define: { 'process.env.NODE_ENV': '"production"' },
  build: {
    outDir: 'engine-module',
    emptyOutDir: true,
    target: 'es2022',
    lib: {
      entry: 'engine-src/main.tsx',
      name: 'Med2Engine',
      formats: ['iife'],
      fileName: () => 'engine.js',
      cssFileName: 'engine',
    },
    cssCodeSplit: false,
    sourcemap: false,
    rollupOptions: { output: { banner: `/*! Third-party licenses\n${thirdPartyNotices.replaceAll('*/', '* /')}\n*/` } },
  },
  esbuild: { jsx: 'automatic' },
});
