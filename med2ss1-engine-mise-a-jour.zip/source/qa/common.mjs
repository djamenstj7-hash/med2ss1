import { createRequire } from 'node:module';
import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';

const require = createRequire(process.env.MED2_QA_DEPS || '/tmp/medora-qa/package.json');
const { chromium } = require('playwright');
const AxeBuilder = require('@axe-core/playwright').default;
export const repository = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const baseURL = process.env.MED2_QA_BASE || 'http://127.0.0.1:4180/med2ss1/';
export const engineManifest = JSON.parse(await fs.readFile(path.join(repository, 'engine/manifest.json'), 'utf8'));
export const curriculum = JSON.parse(await fs.readFile(path.join(repository, 'data/pedagogie.json'), 'utf8'));
export const catalogue = JSON.parse(await fs.readFile(path.join(repository, 'data/catalogue.json'), 'utf8'));
export const oldCourse = catalogue.resources.find(item => item.kind === 'cm' && curriculum.lessons[item.id]);

export async function setup(suite) {
  const outputDirectory = path.join(repository, 'qa/results');
  await fs.mkdir(outputDirectory, { recursive: true });
  const result = { suite, baseURL, startedAt: new Date().toISOString(), passed: [], failed: [], accessibility: [], pageErrors: [], consoleErrors: [], badResponses: [], privateRequests: [], offlineFailures: [], screenshots: [], facts: {} };
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium', headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const context = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 1, isMobile: true, hasTouch: true, locale: 'fr-FR', reducedMotion: 'reduce', acceptDownloads: true });
  const page = await context.newPage();
  page.setDefaultTimeout(14000);
  let offline = false;
  page.on('pageerror', error => result.pageErrors.push(error.message));
  page.on('console', message => { if (message.type() === 'error') result.consoleErrors.push({ offline, text: message.text() }); });
  page.on('response', response => { if (response.status() >= 400) result.badResponses.push({ offline, status: response.status(), url: response.url() }); });
  page.on('request', request => { if (/\/(?:rest|auth|functions)\/v1\//.test(request.url())) result.privateRequests.push(request.url()); });
  page.on('requestfailed', request => { if (offline) result.offlineFailures.push({ url: request.url(), error: request.failure()?.errorText }); });
  page.on('dialog', dialog => dialog.accept());
  const screenshot = async name => {
    const destination = path.join(outputDirectory, suite + '-' + name + '.png');
    await page.screenshot({ path: destination, fullPage: false });
    result.screenshots.push(path.relative(repository, destination));
  };
  const run = async (name, task) => {
    try { await task(); result.passed.push(name); console.log('PASS ' + name); }
    catch (error) { result.failed.push({ name, error: error.stack || String(error) }); console.log('FAIL ' + name + ': ' + error.message); await screenshot('failure-' + result.failed.length).catch(() => {}); }
  };
  const axe = async name => {
    const report = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa', 'wcag21aa']).analyze();
    const violations = report.violations.map(item => ({ id: item.id, impact: item.impact, description: item.description, nodes: item.nodes.map(node => ({ target: node.target, failureSummary: node.failureSummary })).slice(0, 12) }));
    result.accessibility.push({ name, violations });
    assert.deepEqual(violations, [], 'Accessibility violations on ' + name);
  };
  const setOffline = async value => { offline = value; await context.setOffline(value); };
  const close = async () => {
    result.finishedAt = new Date().toISOString();
    await setOffline(false).catch(() => {});
    await fs.writeFile(path.join(outputDirectory, suite + '.json'), JSON.stringify(result, null, 2));
    await browser.close();
    if (result.failed.length) process.exitCode = 1;
    console.log(JSON.stringify({ suite, passed: result.passed.length, failed: result.failed.length, accessibility: result.accessibility.map(item => ({ name: item.name, violations: item.violations.length })) }));
  };
  return { browser, context, page, result, run, axe, screenshot, setOffline, close };
}

export async function noOverflow(page, label) {
  const size = await page.evaluate(() => ({ width: innerWidth, root: document.documentElement.scrollWidth, body: document.body.scrollWidth }));
  assert(size.root <= size.width + 1 && size.body <= size.width + 1, label + ': ' + JSON.stringify(size));
}

export async function hostNav(page, id) {
  const close = page.getByRole('button', { name: 'Fermer le cours', exact: true });
  if (await close.isVisible().catch(() => false)) await close.click();
  const genericClose = page.locator('[role="dialog"] [data-action="close-modal"]').first();
  if (await genericClose.isVisible().catch(() => false)) await genericClose.click();
  await page.locator('.nav button[data-action="nav"][data-id="' + id + '"]:visible').first().click();
}

export async function engineHome(page) {
  await hostNav(page, 'library');
  await page.locator('[data-action="engine-open"]').first().click();
  await page.locator('#med2-engine-mount .med2-engine-root').waitFor();
  const navigation = page.getByRole('navigation', { name: 'Navigation MED_ENGINE', exact: true });
  await navigation.getByRole('button', { name: 'Bibliothèque', exact: true }).click();
  await page.getByRole('textbox', { name: 'Rechercher dans MED_ENGINE', exact: true }).waitFor();
}

export async function openPack(page, id) {
  await engineHome(page);
  await page.locator('.engine-pack-card[data-pack-id="' + id + '"]').click();
  await page.locator('.engine-start').waitFor();
}

export async function workCard(page, id, type) {
  await openPack(page, id);
  await page.getByLabel('Format des cartes', { exact: true }).selectOption(type);
  await page.locator('.engine-card-list > button').first().click();
  await page.getByRole('button', { name: 'Travailler cette carte', exact: true }).click();
  await page.locator('.engine-session-heading').waitFor();
  await page.locator('.engine-question').waitFor();
}

export async function answerQuestion(page) {
  const question = page.locator('.engine-question').first();
  const choices = question.locator('.eq-options input');
  if (await choices.count()) {
    await choices.first().check();
    await question.getByRole('button', { name: 'Valider ma réponse', exact: true }).click();
  } else {
    const free = question.locator('textarea');
    if (await free.count()) await free.fill('Réponse de vérification à comparer aux mécanismes et aux nuances du cours.');
    const compare = question.getByRole('button', { name: /^Comparer au corrigé/ }).first();
    if (await compare.count()) await compare.click();
    const self = question.getByRole('button', { name: 'Éléments retrouvés', exact: true });
    if (await self.count()) await self.click();
  }
  return question;
}

export async function finishPractice(page) {
  await page.getByRole('button', { name: 'Terminer maintenant', exact: true }).click();
  await page.getByRole('button', { name: 'Terminer et enregistrer', exact: true }).click();
  await page.getByRole('heading', { name: 'Séance terminée.', exact: true }).waitFor();
}

export async function engineState(page) {
  return page.evaluate(() => new Promise((resolve, reject) => {
    const opening = indexedDB.open('med2ss1-engine-v1');
    opening.onerror = () => reject(opening.error);
    opening.onsuccess = () => {
      const db = opening.result;
      if (!db.objectStoreNames.contains('state')) { db.close(); resolve(null); return; }
      const request = db.transaction('state', 'readonly').objectStore('state').get('engine-state-v1');
      request.onerror = () => { db.close(); reject(request.error); };
      request.onsuccess = () => { db.close(); resolve(request.result || null); };
    };
  }));
}

export async function engineSection(page, label) {
  await page.getByRole('navigation', { name: 'Navigation MED_ENGINE', exact: true }).getByRole('button', { name: label, exact: true }).click();
}

export async function openOldCourse(page) {
  await hostNav(page, 'library');
  await page.getByRole('searchbox', { name: 'Rechercher un cours, un chapitre ou une notion', exact: true }).fill(curriculum.lessons[oldCourse.id].title);
  await page.locator('[data-action="open-lesson"][data-id="' + oldCourse.id + '"]').first().click();
  await page.locator('.reader').waitFor();
}
