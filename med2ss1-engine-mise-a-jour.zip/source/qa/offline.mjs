import assert from 'node:assert/strict';
import { setup, baseURL, engineManifest, engineHome, engineSection, openPack, workCard, finishPractice, noOverflow, hostNav, openOldCourse } from './common.mjs';

const qa = await setup('offline');
const { page, result, run, screenshot } = qa;
const encodedPath = path => path.split('/').map(encodeURIComponent).join('/');
const files = [...new Set(['manifest.json', ...engineManifest.files])];
const expected = files.map(path => new URL('engine/' + encodedPath(path), baseURL).href);
const cacheName = 'med2ss1-engine-v1';

try {
  await page.addInitScript(() => {
    if (window.top !== window) return;
    if (!localStorage.getItem('qa.offline.seeded')) {
      localStorage.setItem('med2.semestre1.etat.v1', JSON.stringify({ view: 'home', history: [], memory: {}, cycleDone: [], qaSentinel: 'ancien-site-preserve-hors-ligne' }));
      localStorage.setItem('medora:qa-preservation', 'medora-hors-ligne-independant');
      localStorage.setItem('qa.offline.seeded', '1');
    }
    void caches.open('medora-qa-preserve').then(cache => cache.put(new URL('/medora/qa-owned.json', location.origin), new Response('{"protected":true}', { headers: { 'Content-Type': 'application/json' } })));
  });
  await page.goto(baseURL, { waitUntil: 'networkidle' });
  await run('Published MED2 PWA retains iOS metadata, icons and its own /med2ss1/ installation scope', async () => {
    const data = await page.evaluate(async () => {
      const link = document.querySelector('link[rel="manifest"]');
      const response = await fetch(link.href);
      return { manifestURL: link.href, status: response.status, manifest: await response.json(), appleCapable: document.querySelector('meta[name="apple-mobile-web-app-capable"]')?.content, viewport: document.querySelector('meta[name="viewport"]')?.content };
    });
    result.facts.manifest = data;
    assert.equal(data.status, 200);
    assert.equal(data.appleCapable, 'yes');
    assert(data.viewport.includes('viewport-fit=cover'));
    assert.equal(new URL(data.manifest.scope, data.manifestURL).pathname, '/med2ss1/');
    assert.equal(new URL(data.manifest.start_url, data.manifestURL).pathname, '/med2ss1/index.html');
    for (const icon of data.manifest.icons) assert((await page.request.get(new URL(icon.src, data.manifestURL).href)).ok());
  });
  await run('Service worker controls MED2 and preserves unrelated Medora caches', async () => {
    await page.evaluate(() => Promise.race([navigator.serviceWorker.ready.then(() => true), new Promise((_, reject) => setTimeout(() => reject(new Error('Service worker readiness timeout')), 25000))]));
    if (!await page.evaluate(() => Boolean(navigator.serviceWorker.controller))) await page.reload({ waitUntil: 'networkidle' });
    await page.waitForFunction(() => Boolean(navigator.serviceWorker.controller));
    const data = await page.evaluate(async () => {
      const registration = await navigator.serviceWorker.ready;
      const protectedResponse = await (await caches.open('medora-qa-preserve')).match(new URL('/medora/qa-owned.json', location.origin));
      return { scope: registration.scope, script: registration.active.scriptURL, cacheNames: await caches.keys(), medora: protectedResponse ? await protectedResponse.json() : null };
    });
    result.facts.worker = data;
    assert.equal(new URL(data.scope).pathname, '/med2ss1/');
    assert.equal(new URL(data.script).pathname, '/med2ss1/service-worker.js');
    assert.deepEqual(data.medora, { protected: true });
  });
  await run('Download button prepares every one of the 755 MED_ENGINE files before opening a chapter', async () => {
    await engineHome(page);
    await engineSection(page, 'Sauvegarde et hors ligne');
    await page.getByRole('button', { name: 'Télécharger MED_ENGINE', exact: true }).click();
    await page.getByText('755 / 755 fichiers disponibles', { exact: true }).waitFor({ timeout: 150000 });
    await page.getByText('Les contenus MED_ENGINE fournis sont disponibles hors connexion sur cet appareil.', { exact: true }).waitFor();
    const data = await page.evaluate(async ({ cacheName, expected }) => {
      const cache = await caches.open(cacheName);
      const urls = (await cache.keys()).map(item => item.url);
      const missing = [];
      for (const url of expected) if (!await cache.match(url)) missing.push(url);
      return { expected: expected.length, cached: urls.length, missing, privateOrForeign: urls.filter(url => new URL(url).origin !== location.origin || /\/(?:rest|auth|functions)\/v1\//.test(url) || !new URL(url).pathname.startsWith('/med2ss1/engine/')) };
    }, { cacheName, expected });
    result.facts.engineCache = data;
    assert.equal(data.expected, 755);
    assert.equal(data.missing.length, 0);
    assert.equal(data.privateOrForeign.length, 0);
    await screenshot('iphone-download-complete');
  });
  await run('Original MED2 course data, PDF renderer and engine shell are cached', async () => {
    await page.locator('[data-action="engine-close"]').click();
    await page.locator('[data-action="settings"]:visible').first().click();
    const retry = page.locator('[data-action="check-files"]');
    await retry.waitFor();
    await retry.waitFor({ state: 'visible' });
    await page.waitForFunction(() => !document.querySelector('[data-action="check-files"]')?.disabled, null, { timeout: 120000 });
    await retry.click();
    await page.waitForFunction(() => !document.querySelector('[data-action="check-files"]')?.disabled, null, { timeout: 120000 });
    const data = await page.evaluate(async () => {
      const wanted = ['index.html', 'engine-host.js', 'engine-module/engine.js', 'engine-module/engine.css', 'pdf-library.js', 'Assets/pdfjs-4.10.38.min.mjs', 'Assets/pdfjs-4.10.38.worker.min.mjs', 'data/pedagogie.json', 'data/catalogue.json', 'data/cours-semio.json'];
      const cachesToInspect = (await caches.keys()).filter(name => name.startsWith('med2-s1-'));
      const missing = [];
      for (const relative of wanted) {
        const url = new URL(relative, location.href).href;
        let found = false;
        for (const name of cachesToInspect) if (await (await caches.open(name)).match(url)) found = true;
        if (!found) missing.push(relative);
      }
      return { caches: cachesToInspect, missing };
    });
    result.facts.originalCache = data;
    assert.deepEqual(data.missing, []);
  });
  await qa.setOffline(true);
  await run('Offline reload preserves the original MED2 catalogue and navigation', async () => {
    await page.reload({ waitUntil: 'domcontentloaded', timeout: 25000 });
    await hostNav(page, 'library');
    await page.getByText('85 cours rédigés', { exact: false }).waitFor();
    await noOverflow(page, 'offline-host390');
    await screenshot('iphone-host-offline');
  });
  await run('Never-opened MED_ENGINE chapter, supplied figure zoom and zone correction work offline', async () => {
    await workCard(page, 'anat_fc2', 'zone');
    const q = page.locator('.engine-question');
    await q.locator('.eq-zone-canvas').waitFor();
    await q.getByRole('button', { name: 'Agrandir le schéma', exact: true }).click();
    await page.locator('.eq-zoom img').evaluate(image => image.decode());
    assert(await page.locator('.eq-zoom img').evaluate(image => image.naturalWidth > 0));
    await page.getByRole('button', { name: 'Fermer l’illustration', exact: true }).click();
    await q.getByText('Répondre avec les repères numérotés', { exact: true }).click();
    await q.getByRole('button', { name: 'Repère 1', exact: true }).click();
    await q.getByRole('button', { name: 'Valider ma réponse', exact: true }).click();
    await q.locator('.eq-feedback').waitFor();
    await noOverflow(page, 'offline-zone390');
    await screenshot('iphone-engine-offline');
    await finishPractice(page);
  });
  await run('Interactive diagram and its Markdown explanation run offline inside their sandbox', async () => {
    await engineHome(page);
    await page.getByRole('navigation', { name: 'Espaces MED_ENGINE', exact: true }).getByRole('button', { name: 'Comprendre', exact: true }).click();
    await page.getByLabel('Choisir un schéma', { exact: true }).selectOption('bmct:activite-intrinseque');
    const frame = page.locator('.eq-diagram-frame');
    await frame.waitFor();
    assert.equal(await frame.getAttribute('sandbox'), 'allow-scripts');
    assert((await frame.getAttribute('srcdoc')).includes("connect-src 'none'"));
    assert((await frame.contentFrame().locator('body').innerText()).length > 100);
    await page.locator('.eq-diagram-text').waitFor();
    await screenshot('iphone-diagram-offline');
  });
  await run('Original detailed MED2 course still opens offline after visiting MED_ENGINE', async () => {
    await openOldCourse(page);
    await page.locator('.reader [data-action="lesson-tab"][data-id="story"]').click();
    await page.locator('.reader [data-action="cd-hlmode"]').waitFor();
    assert.equal(await page.locator('.reader .cd-error').count(), 0);
    await page.locator('.reader [data-action="lesson-tab"][data-id="qcm"]').click();
    await page.locator('.reader .qitem').first().waitFor();
    await page.getByRole('button', { name: 'Fermer le cours', exact: true }).click();
  });
  await run('Offline mobile widths and landscape retain MED2 and MED_ENGINE without horizontal overflow', async () => {
    for (const viewport of [{ width: 320, height: 740 }, { width: 390, height: 844 }, { width: 430, height: 932 }, { width: 844, height: 390 }]) {
      await page.setViewportSize(viewport);
      await hostNav(page, 'library');
      await noOverflow(page, 'offline-host-' + viewport.width);
      await engineHome(page);
      await noOverflow(page, 'offline-engine-' + viewport.width);
      await openPack(page, 'semio_abord');
      await noOverflow(page, 'offline-chapter-' + viewport.width);
    }
  });
  await run('Offline work preserves unrelated MED2 and Medora data and caches', async () => {
    const evidence = await page.evaluate(async () => {
      const protectedResponse = await (await caches.open('medora-qa-preserve')).match(new URL('/medora/qa-owned.json', location.origin));
      return { legacy: JSON.parse(localStorage.getItem('med2.semestre1.etat.v1')), medora: localStorage.getItem('medora:qa-preservation'), protectedCache: protectedResponse ? await protectedResponse.json() : null };
    });
    assert.equal(evidence.legacy.qaSentinel, 'ancien-site-preserve-hors-ligne');
    assert.equal(evidence.medora, 'medora-hors-ligne-independant');
    assert.deepEqual(evidence.protectedCache, { protected: true });
    assert.deepEqual(result.pageErrors, []);
    assert.deepEqual(result.consoleErrors, []);
    assert.deepEqual(result.badResponses, []);
    assert.deepEqual(result.privateRequests, []);
  });
} finally { await qa.close(); }
