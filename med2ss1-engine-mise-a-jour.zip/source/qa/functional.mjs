import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import { setup, baseURL, repository, engineManifest, curriculum, engineHome, engineSection, openPack, workCard, answerQuestion, finishPractice, engineState, noOverflow, hostNav, openOldCourse, oldCourse } from './common.mjs';

const qa = await setup('functional');
const { page, context, result, run, axe, screenshot } = qa;
const fixturePDF = (() => {
  const drawing = '0 0 0 RG 20 20 200 200 re S\n';
  const objects = ['<< /Type /Catalog /Pages 2 0 R >>', '<< /Type /Pages /Kids [3 0 R] /Count 1 >>', '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 300 300] /Resources << >> /Contents 4 0 R >>', '<< /Length ' + Buffer.byteLength(drawing) + ' >>\nstream\n' + drawing + 'endstream'];
  let pdf = '%PDF-1.4\n';
  const offsets = [0];
  for (let index = 0; index < objects.length; index++) { offsets.push(Buffer.byteLength(pdf)); pdf += `${index + 1} 0 obj\n${objects[index]}\nendobj\n`; }
  const xref = Buffer.byteLength(pdf);
  pdf += 'xref\n0 5\n0000000000 65535 f \n' + offsets.slice(1).map(offset => String(offset).padStart(10, '0') + ' 00000 n \n').join('');
  pdf += 'trailer\n<< /Root 1 0 R /Size 5 >>\nstartxref\n' + xref + '\n%%EOF\n';
  return Buffer.from(pdf);
})();

try {
  await page.addInitScript(() => {
    if (window.top !== window) return;
    if (!localStorage.getItem('qa.med2.seeded')) {
      localStorage.setItem('med2.semestre1.etat.v1', JSON.stringify({ view: 'home', history: [], memory: {}, cycleDone: [], qaSentinel: 'preserver-les-85-cours' }));
      localStorage.setItem('medora:qa-preservation', 'medora-progression-independante');
      localStorage.setItem('qa.med2.seeded', '1');
    }
  });
  await page.goto(baseURL, { waitUntil: 'networkidle' });
  await run('MED2 S1 retains 85 courses, 594 chapters and its five original navigation entries', async () => {
    const lessons = Object.values(curriculum.lessons);
    assert.equal(lessons.length, 85);
    assert.equal(lessons.reduce((sum, item) => sum + item.sections.length, 0), 594);
    for (const id of ['home', 'library', 'missions', 'exams', 'progress']) { await hostNav(page, id); await noOverflow(page, 'host-' + id); }
    await hostNav(page, 'library');
    await page.getByText('85 cours rédigés', { exact: false }).waitFor();
    await screenshot('iphone-host-library');
    await axe('host-library390');
  });
  await run('Original detailed course, highlighting and QCM remain functional', async () => {
    await openOldCourse(page);
    await page.locator('.reader [data-action="lesson-tab"][data-id="story"]').click();
    await page.locator('.reader [data-action="cd-hlmode"]').click();
    const paragraph = page.locator('.reader [data-action="cd-hl"]').first();
    await paragraph.click();
    const highlights = await page.evaluate(() => localStorage.getItem('med2.semestre1.surlignages.v1'));
    assert(highlights && highlights.length > 2, 'Detailed reader did not save highlight');
    result.facts.legacyHighlights = highlights;
    await page.locator('.reader [data-action="lesson-tab"][data-id="qcm"]').click();
    const option = page.locator('.reader [data-action="qrm-toggle"], .reader [data-action="quiz-answer"]').first();
    await option.click();
    const validate = page.locator('.reader [data-action="qrm-check"]').first();
    if (await validate.count()) await validate.click();
    await page.locator('.reader .qfeedback').first().waitFor();
    await page.getByRole('button', { name: 'Fermer le cours', exact: true }).click();
    const evidence = await page.evaluate(() => JSON.parse(localStorage.getItem('med2.semestre1.etat.v1')));
    assert.equal(evidence.qaSentinel, 'preserver-les-85-cours');
    result.facts.legacyProgressBeforeEngine = evidence;
  });
  await run('Original PDF import, rendering and fullscreen close remain usable', async () => {
    await openOldCourse(page);
    await page.locator('.reader [role="tab"][data-action="lesson-tab"][data-id="fiches"]').click();
    await page.getByLabel('Choisir la fiche PDF de ce cours', { exact: true }).setInputFiles({ name: 'verification-med2-preservee.pdf', mimeType: 'application/pdf', buffer: fixturePDF });
    await page.locator('.reader canvas').first().waitFor({ timeout: 30000 });
    await page.getByRole('button', { name: 'Lire la fiche en plein écran', exact: true }).click();
    await page.getByRole('button', { name: 'Fermer le PDF', exact: true }).click();
    await noOverflow(page, 'original-pdf390');
    await page.getByRole('button', { name: 'Fermer le cours', exact: true }).click();
  });
  await run('MED_ENGINE loads its 141 chapter catalogue with search and provenance filters', async () => {
    await engineHome(page);
    assert.equal(await page.locator('.engine-pack-card').count(), 141);
    await page.getByRole('textbox', { name: 'Rechercher dans MED_ENGINE', exact: true }).fill('semiologie');
    assert(await page.locator('.engine-pack-card').count() > 0);
    await page.getByRole('textbox', { name: 'Rechercher dans MED_ENGINE', exact: true }).fill('');
    await page.getByLabel('Niveau ou provenance', { exact: true }).selectOption('annales');
    assert(await page.locator('.engine-pack-card').count() > 0);
    await noOverflow(page, 'engine-catalogue390');
    await screenshot('iphone-engine-catalogue');
    await axe('engine-catalogue390');
    result.facts.content = { chapters: engineManifest.packs.length, notes: engineManifest.audit.noteCount, sourceCards: engineManifest.audit.sourceCardCount, variants: engineManifest.audit.cardCount };
  });
  await run('MED_ENGINE notes, favourites, guide and byte-identical source export persist locally', async () => {
    await openPack(page, 'semio_abord');
    await page.getByRole('button', { name: 'Ajouter le chapitre aux favoris', exact: true }).click();
    await page.getByLabel('Ma note pour ce chapitre', { exact: true }).fill('QA MED2 S1 : relier anamnèse, examen et raisonnement clinique.');
    await page.getByRole('button', { name: 'Enregistrer ma note', exact: true }).click();
    await page.getByText('Note enregistrée.', { exact: true }).waitFor();
    const href = await page.getByRole('link', { name: 'Télécharger le paquet source', exact: true }).getAttribute('href');
    const actual = await (await page.request.get(new URL(href, baseURL).href)).body();
    const expected = await fs.readFile(path.join(repository, 'engine/packs/semio_abord.json'));
    assert.deepEqual(actual, expected);
    await page.getByRole('tab', { name: 'Lire', exact: true }).click();
    await page.locator('.er-markdown').waitFor();
    await openPack(page, 'semio_abord');
    assert((await page.getByLabel('Ma note pour ce chapitre', { exact: true }).inputValue()).includes('QA MED2 S1'));
    await page.getByRole('button', { name: 'Retirer le chapitre des favoris', exact: true }).waitFor();
    await screenshot('iphone-engine-chapter');
  });
  await run('A note edited while its previous version is saving remains autosaved on leaving', async () => {
    await openPack(page, 'semio_abord');
    const originalText = 'QA note A : version dont l’enregistrement est encore en attente.';
    const editedText = 'QA note B : ajout saisi pendant l’enregistrement, à conserver après la sortie.';
    await page.evaluate(() => {
      const descriptor = Object.getOwnPropertyDescriptor(IDBTransaction.prototype, 'oncomplete');
      if (!descriptor?.set || !descriptor.get) throw new Error('Transaction completion cannot be instrumented in this browser');
      const gate = { descriptor, claimed: false, completed: false, delivered: false, forceRelease: false, release: undefined };
      window.__med2NoteGate = gate;
      Object.defineProperty(IDBTransaction.prototype, 'oncomplete', {
        configurable: descriptor.configurable,
        enumerable: descriptor.enumerable,
        get() { return descriptor.get.call(this); },
        set(callback) {
          if (typeof callback === 'function' && this.db.name === 'med2ss1-engine-v1' && this.mode === 'readwrite' && !gate.claimed) {
            gate.claimed = true;
            const transaction = this;
            descriptor.set.call(this, event => {
              gate.completed = true;
              gate.release = () => {
                if (gate.delivered) return;
                gate.delivered = true;
                callback.call(transaction, event);
              };
              if (gate.forceRelease) gate.release();
            });
          } else descriptor.set.call(this, callback);
        },
      });
    });
    try {
      const note = page.getByLabel('Ma note pour ce chapitre', { exact: true });
      await note.fill(originalText);
      await page.getByRole('button', { name: 'Enregistrer ma note', exact: true }).click();
      await page.waitForFunction(() => window.__med2NoteGate?.completed === true);
      assert(await page.getByRole('button', { name: 'Enregistrer ma note', exact: true }).isDisabled(), 'Expected the first save to remain in flight');
      await note.fill(editedText);
      await page.evaluate(() => window.__med2NoteGate.release());
      await page.getByText('Note enregistrée.', { exact: true }).waitFor();
      assert.equal(await note.inputValue(), editedText);
      await hostNav(page, 'library');
      await openPack(page, 'semio_abord');
      assert.equal(await page.getByLabel('Ma note pour ce chapitre', { exact: true }).inputValue(), editedText);
      const state = await engineState(page);
      assert.equal(state.study.notes['engine:pack:semio_abord'], editedText);
    } finally {
      await page.evaluate(() => {
        const gate = window.__med2NoteGate;
        if (!gate) return;
        gate.forceRelease = true;
        gate.release?.();
        Object.defineProperty(IDBTransaction.prototype, 'oncomplete', gate.descriptor);
        delete window.__med2NoteGate;
      });
    }
  });
  await run('QRM practice gives detailed delayed corrections without scheduling FSRS', async () => {
    const before = await engineState(page);
    await workCard(page, 'semio_abord', 'qrm');
    const q = page.locator('.engine-question');
    assert.equal(await q.locator('.eq-feedback').count(), 0);
    await q.getByLabel('Hésitant', { exact: true }).check();
    await q.locator('.eq-options input').first().check();
    await q.getByRole('button', { name: 'Valider ma réponse', exact: true }).click();
    await q.locator('.eq-feedback').waitFor();
    await q.getByRole('heading', { name: 'Pourquoi, proposition par proposition', exact: true }).waitFor();
    await screenshot('iphone-engine-qrm');
    await axe('engine-qrm390');
    await finishPractice(page);
    const after = await engineState(page);
    assert.deepEqual(after.fsrs, before.fsrs, 'Practice mutated spaced repetition');
    assert(after.study.attempts.length > before.study.attempts.length);
  });
  await run('Cloze and QROC require explicit self-assessment before recording success', async () => {
    await workCard(page, 'semio_abord', 'cloze');
    let q = page.locator('.engine-question');
    assert(await q.locator('.eq-blank').count() > 0);
    await q.getByRole('button', { name: 'Comparer au corrigé', exact: true }).click();
    assert.equal(await q.locator('.eq-blank').count(), 0);
    await q.getByRole('button', { name: 'Éléments retrouvés', exact: true }).click();
    await finishPractice(page);
    await workCard(page, 'semio_abord', 'qroc');
    q = page.locator('.engine-question');
    await q.locator('textarea').fill('Réponse clinique à comparer au corrigé et aux notions du cours.');
    await q.getByRole('button', { name: 'Comparer au corrigé', exact: true }).click();
    await q.getByRole('button', { name: 'À retravailler', exact: true }).click();
    await finishPractice(page);
  });
  await run('QRU, recall cards and medical lexicon keep their own response formats', async () => {
    await workCard(page, 'semio_abord', 'qru');
    let question = page.locator('.engine-question');
    assert(await question.locator('.eq-options input[type="radio"]').count() > 1);
    await answerQuestion(page);
    await question.locator('.eq-feedback').waitFor();
    await finishPractice(page);
    for (const type of ['basic', 'lexique']) {
      await workCard(page, 'semio_abord', type);
      question = page.locator('.engine-question');
      assert.equal(await question.locator('.eq-options input').count(), 0);
      await question.getByRole('button', { name: 'Comparer au corrigé', exact: true }).click();
      await question.getByRole('button', { name: 'Éléments retrouvés', exact: true }).click();
      await question.locator('.eq-feedback').waitFor();
      await finishPractice(page);
    }
  });
  await run('Supplied zone and legend diagrams zoom and accept accessible responses', async () => {
    await workCard(page, 'anat_fc2', 'zone');
    let q = page.locator('.engine-question');
    await q.locator('.eq-zone-canvas').waitFor();
    await q.getByRole('button', { name: 'Agrandir le schéma', exact: true }).click();
    await page.locator('.eq-zoom img').evaluate(image => image.decode());
    await page.getByRole('button', { name: 'Fermer l’illustration', exact: true }).click();
    await q.getByText('Répondre avec les repères numérotés', { exact: true }).click();
    await q.getByRole('button', { name: 'Repère 1', exact: true }).click();
    await q.getByRole('button', { name: 'Valider ma réponse', exact: true }).click();
    await q.locator('.eq-feedback').waitFor();
    await noOverflow(page, 'zone390');
    await finishPractice(page);
    await workCard(page, 'anat_sch1', 'legend');
    q = page.locator('.engine-question');
    await q.locator('.eq-figure img').first().evaluate(image => image.decode());
    await answerQuestion(page);
    await q.locator('.eq-feedback').waitFor();
    await finishPractice(page);
  });
  await run('Missing required figures are preserved as ungraded exercises', async () => {
    const before = await engineState(page);
    await workCard(page, 'semio_abord', 'zone');
    const q = page.locator('.engine-question');
    await q.getByText(/L’image de repérage n’est pas fournie/).waitFor();
    assert.equal(await q.locator('.eq-zone-canvas').count(), 0);
    await q.getByRole('button', { name: 'Consulter le corrigé sans notation', exact: true }).click();
    await q.locator('.eq-feedback').waitFor();
    await finishPractice(page);
    const after = await engineState(page);
    assert.equal(after.study.attempts.length, before.study.attempts.length, 'Unavailable figure was counted as a graded attempt');
    assert(Object.keys(after.study.writingDrafts).length > Object.keys(before.study.writingDrafts).length);
  });
  await run('Annales, timed simulation, pause and resume keep exam corrections deferred', async () => {
    await openPack(page, 'semio_abord');
    await page.getByLabel('Format des cartes', { exact: true }).selectOption('qrm');
    await page.getByRole('button', { name: 'Annales', exact: true }).click();
    await page.locator('.eq-annale').waitFor();
    await answerQuestion(page);
    await finishPractice(page);
    await openPack(page, 'semio_abord');
    await page.getByLabel('Format des cartes', { exact: true }).selectOption('qrm');
    await page.getByRole('button', { name: 'Simulation', exact: true }).click();
    await answerQuestion(page);
    await page.locator('.eq-saved').waitFor();
    assert.equal(await page.locator('.eq-feedback').count(), 0);
    await page.getByRole('button', { name: 'Pause', exact: true }).click();
    await hostNav(page, 'library');
    await engineHome(page);
    await page.getByRole('button', { name: 'Reprendre', exact: true }).click();
    await page.getByRole('button', { name: 'Reprendre le chronomètre', exact: true }).click();
    await finishPractice(page);
    await page.getByRole('button', { name: 'Voir les corrections', exact: true }).click();
    await page.locator('.eq-feedback').first().waitFor();
  });
  await run('Interactive diagrams keep their opaque sandbox and local explanation', async () => {
    await engineHome(page);
    await page.getByRole('navigation', { name: 'Espaces MED_ENGINE', exact: true }).getByRole('button', { name: 'Comprendre', exact: true }).click();
    await page.getByLabel('Choisir un schéma', { exact: true }).selectOption('bmct:activite-intrinseque');
    const frame = page.locator('.eq-diagram-frame');
    await frame.waitFor();
    assert.equal(await frame.getAttribute('sandbox'), 'allow-scripts');
    assert((await frame.getAttribute('srcdoc')).includes("connect-src 'none'"));
    await frame.contentFrame().locator('body').waitFor();
    assert((await frame.contentFrame().locator('body').innerText()).length > 100);
    await page.locator('.eq-diagram-text').waitFor();
    await noOverflow(page, 'interactive-diagram390');
  });
  await run('Confidence, activity and personal examination dates persist in MED_ENGINE only', async () => {
    await engineHome(page);
    await page.getByRole('navigation', { name: 'Espaces MED_ENGINE', exact: true }).getByRole('button', { name: 'Mon suivi', exact: true }).click();
    await page.getByLabel('Date personnelle MED_ENGINE', { exact: true }).fill('2027-12-12');
    await page.getByRole('button', { name: 'Enregistrer la date', exact: true }).click();
    await page.getByText('Date personnelle enregistrée.', { exact: true }).waitFor();
    const state = await engineState(page);
    assert(Object.values(state.study.exams).includes('2027-12-12'));
    assert(state.study.attempts.some(item => item.confidence === 'hesitant'));
    await noOverflow(page, 'engine-progress390');
    await screenshot('iphone-engine-progress');
    await axe('engine-progress390');
  });
  await run('Local FSRS decks require activation and preserve source-rich question review', async () => {
    await openPack(page, 'semio_abord');
    await page.getByRole('button', { name: 'Ajouter à mes decks FSRS', exact: true }).click();
    await page.getByRole('button', { name: 'Activer ces cartes', exact: true }).waitFor();
    let state = await engineState(page);
    assert.equal(state.fsrs.decks.length, 1);
    assert.equal(state.fsrs.decks[0].active, false);
    const cardCount = state.fsrs.cards.length;
    assert(cardCount > 0);
    assert(state.fsrs.cards.every(item => !item.active));
    await page.getByRole('button', { name: 'Activer ces cartes', exact: true }).click();
    await page.locator('.me-deck-preview').waitFor({ state: 'hidden' });
    await page.locator('.engine-question').waitFor();
    assert.equal(await page.getByRole('button', { name: /^Bien/ }).count(), 0, 'FSRS rating visible before recall');
    await answerQuestion(page);
    await page.getByRole('button', { name: /^Bien/ }).click();
    await page.getByText('Révision enregistrée sur cet appareil.', { exact: true }).waitFor();
    state = await engineState(page);
    assert.equal(state.fsrs.logs.length, 1);
    assert(state.fsrs.logs[0].cardId);
    await screenshot('iphone-engine-fsrs');
    await openPack(page, 'semio_abord');
    await page.getByRole('button', { name: 'Ajouter à mes decks FSRS', exact: true }).click();
    state = await engineState(page);
    assert.equal(state.fsrs.decks.length, 1);
    assert.equal(state.fsrs.cards.length, cardCount);
    assert.equal(state.fsrs.logs.length, 1);
  });
  await run('Study backup roundtrip preserves local review logs and unrelated MED2 and Medora state', async () => {
    await engineSection(page, 'Sauvegarde et hors ligne');
    const before = await engineState(page);
    const downloading = page.waitForEvent('download');
    await page.getByRole('button', { name: 'Exporter ma sauvegarde MED_ENGINE', exact: true }).click();
    const download = await downloading;
    const downloaded = await fs.readFile(await download.path());
    const value = JSON.parse(downloaded);
    assert.equal(value.application, 'med2ss1-engine');
    await page.getByLabel('Importer une sauvegarde MED_ENGINE', { exact: true }).setInputFiles({ name: 'sauvegarde-med-engine.json', mimeType: 'application/json', buffer: downloaded });
    await page.getByText('Sauvegarde MED_ENGINE importée et fusionnée.', { exact: true }).waitFor();
    const after = await engineState(page);
    assert.equal(after.fsrs.logs.length, before.fsrs.logs.length);
    assert.equal(after.study.attempts.length, before.study.attempts.length);
    assert.deepEqual(after.study.bookmarks, before.study.bookmarks);
    const legacy = await page.evaluate(() => ({ state: JSON.parse(localStorage.getItem('med2.semestre1.etat.v1')), highlights: localStorage.getItem('med2.semestre1.surlignages.v1'), medora: localStorage.getItem('medora:qa-preservation') }));
    assert.equal(legacy.state.qaSentinel, 'preserver-les-85-cours');
    assert.equal(legacy.medora, 'medora-progression-independante');
    assert.equal(legacy.highlights, result.facts.legacyHighlights);
    for (const key of ['quizAnswers', 'quizAttemptHistory', 'qroc', 'history', 'memory', 'cycleDone']) assert.deepEqual(legacy.state[key], result.facts.legacyProgressBeforeEngine[key], 'Legacy field changed: ' + key);
    await axe('engine-data390');
  });
  await run('iPhone 320, 390, 430, landscape and dark layouts preserve both applications', async () => {
    for (const viewport of [{ width: 320, height: 740 }, { width: 390, height: 844 }, { width: 430, height: 932 }, { width: 844, height: 390 }]) {
      await page.setViewportSize(viewport);
      await hostNav(page, 'library');
      await noOverflow(page, 'host-' + viewport.width);
      await engineHome(page);
      await noOverflow(page, 'engine-' + viewport.width);
      await openPack(page, 'semio_abord');
      await noOverflow(page, 'chapter-' + viewport.width);
    }
    await page.evaluate(() => { localStorage.setItem('med2.semestre1.apparence.v1', 'dark'); document.documentElement.dataset.theme = 'dark'; });
    await page.setViewportSize({ width: 390, height: 844 });
    await engineHome(page);
    await axe('engine-dark390');
    await screenshot('iphone-engine-dark');
  });
  await run('No observed JavaScript exception, HTTP asset failure or external private request', async () => {
    assert.deepEqual(result.pageErrors, []);
    assert.deepEqual(result.badResponses, []);
    assert.deepEqual(result.consoleErrors, []);
    assert.deepEqual(result.privateRequests, []);
  });
} finally { await qa.close(); }
