import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import { setup, baseURL, repository, engineManifest, engineHome, openPack, engineState, noOverflow, openOldCourse, fixturePDF, answerQuestion, finishPractice } from './common.mjs';

const qa = await setup('access');
const { page, context, result, run, axe, screenshot } = qa;
const pdf = fixturePDF();
const packRequests = [];
page.on('request', request => { const match = request.url().match(/\/engine\/packs\/([^/?]+)\.json(?:\?|$)/); if (match) packRequests.push(match[1]); });
const spaces = () => page.getByRole('navigation', { name: 'Espaces MED_ENGINE', exact: true });
const readingNav = () => page.getByRole('navigation', { name: 'Lecture du chapitre MED_ENGINE', exact: true });
const goUnderstand = async () => { await engineHome(page); await spaces().getByRole('button', { name: 'Comprendre', exact: true }).click(); await page.locator('.engine-gallery').waitFor(); };

try {
  await page.goto(baseURL, { waitUntil: 'networkidle' });
  await run('Opening a chapter defaults to readable structured guide, with distinct training and diagrams', async () => {
    await engineHome(page);
    await page.locator('.engine-pack-card[data-pack-id="semio_abord"]').click();
    assert.equal(await page.getByRole('tab', { name: 'Lire', exact: true }).getAttribute('aria-selected'), 'true');
    const guide = page.locator('.er-markdown');
    await guide.waitFor();
    assert((await guide.innerText()).length > 100);
    assert(await guide.locator('h3,h4,p,li,table').count() > 2);
    assert.equal(await page.locator('.engine-start:visible').count(), 0);
    for (const tab of ['Lire', 'S’entraîner', 'Schémas']) assert.equal(await page.getByRole('tab', { name: tab, exact: true }).count(), 1);
    await noOverflow(page, 'guide390');
    await axe('reading390');
    await screenshot('iphone-reading-guide');
  });
  await run('Reading cards and corrections does not record an attempt or schedule a spaced review', async () => {
    const before = await engineState(page);
    await readingNav().getByRole('button', { name: 'Fiches et corrections', exact: true }).click();
    const cards = page.locator('.er-card');
    assert.equal(await cards.count(), 12);
    assert(await cards.first().locator('.eq-feedback').count() > 0);
    await page.getByLabel('Format des fiches de lecture', { exact: true }).selectOption('lexique');
    assert(await cards.count() > 0);
    await page.getByLabel('Rechercher dans les fiches de lecture', { exact: true }).fill('zzzz-introuvable-qa');
    assert.equal(await cards.count(), 0);
    await page.getByText('Aucune fiche ne correspond à cette recherche.', { exact: true }).waitFor();
    const after = await engineState(page);
    assert.deepEqual(after?.study.attempts, before?.study.attempts);
    assert.deepEqual(after?.fsrs, before?.fsrs);
  });
  await run('Windows document paths remain labelled references rather than broken download links', async () => {
    await readingNav().getByRole('button', { name: 'Documents cités', exact: true }).click();
    const references = page.locator('.er-references');
    assert(await references.locator('article').count() > 0);
    assert.equal(await references.locator('article a').count(), 2);
    await references.getByText('fichier non retrouvé dans ce Drive', { exact: false }).first().waitFor();
    for (const href of await references.locator('article a').evaluateAll(links => links.map(link => link.href))) assert.match(href, /^https:\/\/drive\.google\.com\/file\/d\/[\w-]+\/view/);
    assert((await references.innerText()).includes('Les chemins d’origine restent des références bibliographiques'));
  });
  await run('Existing MED2 S1 reader link opens the exact matching course and the generic link retains all 85 courses', async () => {
    await page.getByRole('button', { name: /^Lire le cours MED2 S1 : Abord/ }).click();
    await page.locator('.reader').waitFor();
    assert((await page.locator('.reader').innerText()).includes('Abord et examen clinique du malade'));
    await page.getByRole('button', { name: 'Fermer le cours', exact: true }).click();
    await openPack(page, 'semio_abord', 'Lire');
    await page.getByRole('button', { name: 'Ouvrir la bibliothèque des 85 cours MED2 S1', exact: true }).click();
    await page.getByText('85 cours rédigés', { exact: false }).waitFor();
  });
  await run('The new course catalogue exposes all 123 files, safe original Drive links and the three BMCT pharmacodynamics parts', async () => {
    await engineHome(page);
    await spaces().getByRole('button', { name: 'Cours du Drive', exact: true }).click();
    const documents = page.getByRole('region', { name: 'Tous les cours du Drive', exact: true });
    await documents.getByText('116 PDF et 7 documents complémentaires, classés par UE.', { exact: true }).waitFor();
    await documents.getByText('123 document(s)', { exact: true }).waitFor();
    while (await documents.getByRole('button', { name: /^Afficher les documents suivants/ }).count()) await documents.getByRole('button', { name: /^Afficher les documents suivants/ }).click();
    assert.equal(await documents.locator('[data-source-document]').count(), 123);
    const links = await documents.locator('a.engine-document-link').evaluateAll(items => items.map(link => ({ href: link.href, target: link.target, rel: link.rel })));
    assert.equal(links.length, 123);
    for (const link of links) {
      const url = new URL(link.href);
      assert.equal(url.protocol, 'https:');
      assert(['drive.google.com', 'docs.google.com'].includes(url.hostname));
      assert.equal(link.target, '_blank');
      assert(link.rel.includes('noopener') && link.rel.includes('noreferrer'));
    }
    await documents.getByLabel('Rechercher dans les cours du Drive', { exact: true }).fill('pharmacodynamie générale');
    await documents.getByText('3 document(s)', { exact: true }).waitFor();
    assert.equal(await documents.locator('[data-source-document]').count(), 3);
    for (const width of [320, 390]) { await page.setViewportSize({ width, height: 844 }); await noOverflow(page, 'drive-catalogue' + width); }
    await axe('drive-catalogue390');
    await openPack(page, 'bmct_pharmacodynamie', 'Lire');
    assert.equal(await page.locator('.er-direct-course-actions a.engine-document-link').count(), 3);
    await readingNav().getByRole('button', { name: 'Cours du Drive', exact: true }).click();
    const direct = page.locator('.engine-direct-documents');
    assert.equal(await direct.locator('[data-source-document]').count(), 3);
    result.facts.sourceDocuments = { documents: 123, pdf: 116, pharmacodynamicsParts: 3, access: 'Drive en ligne, import personnel pour le hors connexion' };
  });
  await run('A chapter imports its own PDF, keeps it after reload and leaves an original-course PDF separate', async () => {
    await openOldCourse(page);
    await page.locator('.reader [role="tab"][data-action="lesson-tab"][data-id="fiches"]').click();
    await page.getByLabel('Choisir la fiche PDF de ce cours', { exact: true }).setInputFiles({ name: 'qa-ancien-cours-conserve.pdf', mimeType: 'application/pdf', buffer: pdf });
    await page.locator('.reader canvas').first().waitFor({ timeout: 30000 });
    await page.getByRole('button', { name: 'Fermer le cours', exact: true }).click();
    await openPack(page, 'semio_abord', 'Lire');
    await readingNav().getByRole('button', { name: 'Mes PDF', exact: true }).click();
    await page.getByLabel('Choisir la fiche PDF de ce cours', { exact: true }).setInputFiles({ name: 'qa-engine-chapitre-prive.pdf', mimeType: 'application/pdf', buffer: pdf });
    await page.locator('.er-personal-pdf canvas').first().waitFor({ timeout: 30000 });
    assert.equal(await page.locator('.er-personal-pdf .m2f-name').innerText(), 'qa-engine-chapitre-prive.pdf');
    await page.getByRole('button', { name: 'Lire la fiche en plein écran', exact: true }).click();
    await page.getByRole('button', { name: 'Fermer le PDF', exact: true }).click();
    await page.reload({ waitUntil: 'networkidle' });
    await openPack(page, 'semio_abord', 'Lire');
    await readingNav().getByRole('button', { name: 'Mes PDF', exact: true }).click();
    await page.locator('.er-personal-pdf canvas').first().waitFor({ timeout: 30000 });
    assert.equal(await page.locator('.er-personal-pdf .m2f-name').innerText(), 'qa-engine-chapitre-prive.pdf');
    await openOldCourse(page);
    await page.locator('.reader [role="tab"][data-action="lesson-tab"][data-id="fiches"]').click();
    await page.locator('.reader canvas').first().waitFor();
    assert.equal(await page.locator('.reader .m2f-name').innerText(), 'qa-ancien-cours-conserve.pdf');
    await page.getByRole('button', { name: 'Fermer le cours', exact: true }).click();
  });
  await run('The global gallery exposes 438 images in 13 chapters without loading all question banks', async () => {
    const before = packRequests.length;
    await goUnderstand();
    const gallery = page.locator('.engine-gallery');
    assert((await gallery.innerText()).includes('438 images fournies, dans 13 chapitres'));
    assert.equal(await gallery.locator('[data-gallery-pack]').count(), 13);
    assert.deepEqual(packRequests.slice(before), [], 'Opening the global gallery eagerly loaded a question bank');
    await gallery.getByLabel('Chapitre illustré', { exact: true }).selectOption('anat_sch1');
    await gallery.getByText('70 images disponibles', { exact: true }).waitFor();
    assert.deepEqual(packRequests.slice(before), ['anat_sch1'], 'The gallery loaded question banks other than the selected chapter');
    assert.equal(await gallery.locator('[data-gallery-figure]').count(), 32);
    await gallery.getByRole('button', { name: /^Afficher les images suivantes/ }).click();
    assert.equal(await gallery.locator('[data-gallery-figure]').count(), 64);
    await gallery.getByRole('button', { name: /^Afficher les images suivantes/ }).click();
    assert.equal(await gallery.locator('[data-gallery-figure]').count(), 70);
    await gallery.locator('[data-gallery-figure]').first().click();
    await gallery.locator('.engine-gallery-main-image img').evaluate(image => image.decode());
    await gallery.locator('.engine-gallery-main-image').click();
    const dialog = page.getByRole('dialog', { name: /^Figure agrandie/ });
    await dialog.locator('img').evaluate(image => image.decode());
    await dialog.getByRole('button', { name: 'Agrandir la figure', exact: true }).click();
    assert.equal(await dialog.locator('output').innerText(), '150 %');
    await dialog.getByRole('button', { name: 'Ajuster', exact: true }).click();
    assert.equal(await dialog.locator('output').innerText(), '100 %');
    await page.getByRole('button', { name: 'Fermer la figure agrandie', exact: true }).click();
    await noOverflow(page, 'gallery390');
    await screenshot('iphone-gallery');
    await axe('gallery390');
    result.facts.gallery = { images: 438, illustratedChapters: 13, selectedChapterImages: 70, pageSize: 32 };
  });
  await run('A figure launches an available zone exercise directly in its own chapter', async () => {
    const gallery = page.locator('.engine-gallery');
    await gallery.getByLabel('Chapitre illustré', { exact: true }).selectOption('anat_fc2');
    await gallery.locator('[data-gallery-figure="retro-malleolaire.svg"]').click();
    await gallery.getByRole('button', { name: 'Travailler ce repérage', exact: true }).first().click();
    await page.locator('.engine-session-heading').waitFor();
    await page.locator('.engine-question .eq-zone-canvas').waitFor();
    assert((await page.locator('.engine-session-heading').innerText()).includes(engineManifest.packs.find(item => item.id === 'anat_fc2').title));
    await page.locator('.engine-question').getByText('Répondre avec les repères numérotés', { exact: true }).click();
    await page.locator('.engine-question').getByRole('button', { name: 'Repère 1', exact: true }).click();
    await page.locator('.engine-question').getByRole('button', { name: 'Valider ma réponse', exact: true }).click();
    await page.locator('.engine-question .eq-feedback').waitFor();
    await finishPractice(page);
    const state = await engineState(page);
    assert.equal(state.study.attempts.at(-1).lessonId, 'engine:pack:anat_fc2');
  });
  await run('All 15 explanatory supports load with honest labels and the five interactive supports respond', async () => {
    await goUnderstand();
    let interactiveCount = 0;
    for (const diagram of engineManifest.diagrams) {
      await page.getByLabel('Choisir un schéma', { exact: true }).selectOption(diagram.id);
      const frame = page.locator('.eq-diagram-frame');
      await frame.waitFor();
      assert.equal(await frame.getAttribute('sandbox'), 'allow-scripts');
      assert((await frame.getAttribute('srcdoc')).includes("connect-src 'none'"));
      const body = frame.contentFrame().locator('body');
      assert((await body.innerText()).length > 100);
      const source = await fs.readFile(path.join(repository, 'engine', diagram.htmlPath), 'utf8');
      const interactive = /<script\b/i.test(source);
      assert.equal(await page.locator('.eq-diagram-kind').innerText(), interactive ? 'Schéma interactif' : 'Schéma explicatif');
      if (interactive) {
        interactiveCount++;
        const before = await body.innerHTML();
        const buttons = frame.contentFrame().locator('button');
        if (await buttons.count()) await buttons.last().click();
        else await frame.contentFrame().locator('input[type="range"]').first().evaluate(input => { input.value = input.min; input.dispatchEvent(new Event('input', { bubbles: true })); input.dispatchEvent(new Event('change', { bubbles: true })); });
        assert.notEqual(await body.innerHTML(), before, 'Interactive controls did not change ' + diagram.id);
      }
    }
    assert.equal(interactiveCount, 5);
    result.facts.supports = { total: engineManifest.diagrams.length, interactive: interactiveCount, explanatory: engineManifest.diagrams.length - interactiveCount };
  });
  await run('Fullscreen diagrams zoom, retain their sandbox and keep a visible close control on narrow iPhone layouts', async () => {
    for (const viewport of [{ width: 320, height: 740 }, { width: 390, height: 844 }, { width: 430, height: 932 }, { width: 844, height: 390 }]) {
      await page.setViewportSize(viewport);
      await page.getByLabel('Choisir un schéma', { exact: true }).selectOption('bmct:activite-intrinseque');
      await page.locator('.eq-diagram-frame').waitFor();
      await page.getByRole('button', { name: 'Agrandir le schéma', exact: true }).click();
      const dialog = page.locator('dialog.eq-diagram-zoom');
      await dialog.waitFor();
      assert.equal(await dialog.locator('iframe').getAttribute('sandbox'), 'allow-scripts');
      await dialog.getByRole('button', { name: 'Zoomer le schéma', exact: true }).click();
      assert.equal(await dialog.locator('output').innerText(), '125 %');
      await dialog.getByRole('button', { name: 'Taille initiale', exact: true }).click();
      const close = dialog.getByRole('button', { name: 'Fermer le schéma agrandi', exact: true });
      const bounds = await close.boundingBox();
      assert(bounds && bounds.x >= 0 && bounds.y >= 0 && bounds.x + bounds.width <= viewport.width + 1 && bounds.y + bounds.height <= viewport.height + 1, 'Close control is outside viewport ' + JSON.stringify(viewport));
      await close.click();
      await dialog.waitFor({ state: 'hidden' });
      await noOverflow(page, 'diagram-' + viewport.width);
    }
    await page.setViewportSize({ width: 390, height: 844 });
    await screenshot('iphone-diagram-access');
  });
  await run('Reading, references and the chapter gallery preserve narrow iPhone layouts', async () => {
    for (const viewport of [{ width: 320, height: 740 }, { width: 390, height: 844 }, { width: 430, height: 932 }]) {
      await page.setViewportSize(viewport);
      await openPack(page, 'anat_sch1', 'Lire');
      await page.locator('.er-markdown').waitFor();
      await noOverflow(page, 'reading-' + viewport.width);
      await readingNav().getByRole('button', { name: 'Documents cités', exact: true }).click();
      await noOverflow(page, 'sources-' + viewport.width);
      await page.getByRole('tab', { name: 'Schémas', exact: true }).click();
      await page.locator('.engine-gallery').getByText('70 images disponibles', { exact: true }).waitFor();
      await noOverflow(page, 'chapter-gallery-' + viewport.width);
    }
  });
  await run('Access improvements cause no observed JavaScript exception, HTTP asset failure or private network request', async () => {
    assert.deepEqual(result.pageErrors, []);
    assert.deepEqual(result.badResponses, []);
    assert.deepEqual(result.consoleErrors, []);
    assert.deepEqual(result.privateRequests, []);
  });
} finally { await qa.close(); }
