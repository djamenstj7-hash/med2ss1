import 'fake-indexeddb/auto';
import { beforeEach, describe, expect, it } from 'vitest';
import type { EngineCard, EnginePack } from '../engine-src/lib/engine-types';
import { localFsrs } from '../engine-src/lib/local-fsrs';
import { clearEngineProgress, exportEngineBackup, importEngineBackup } from '../engine-src/lib/local-backup';

function pack(id = 'pack', subject = 'ue'): EnginePack { return { id, title: `Chapter ${id}`, subjects: [{ id: subject, nom: subject, couleur: '#7755aa' }] } as unknown as EnginePack; }
function card(packId = 'pack', note = 'n1', type = 'basic'): EngineCard { return { id: `engine:${packId}:${note}:main`, packId, noteId: note, prompt: 'Explain the mechanism', answer: 'A source-based answer', explanation: 'Source explanation', type } as EngineCard; }
beforeEach(async () => { await clearEngineProgress(); });
describe('client FSRS over source MED_ENGINE cards', () => {
  it('installs an idempotent draft and requires explicit activation', async () => {
    expect(await localFsrs.installPack(pack(), [card()])).toEqual({ deckId: 'engine-deck:pack', count: 1 });
    expect(await localFsrs.installPack(pack(), [card()])).toEqual({ deckId: 'engine-deck:pack', count: 0 });
    expect(await localFsrs.getReviewQueue()).toEqual([]);
    await expect(localFsrs.reviewCard(card().id, 3, new Date(Date.now() + 1_000))).rejects.toThrow(/Active/);
    await localFsrs.activateDeck('engine-deck:pack'); expect(await localFsrs.getReviewQueue()).toHaveLength(1);
  });
  it('excludes visual tasks whose required source illustration is absent', async () => {
    const available = { ...card('pack', 'n3', 'zone'), questionIllustration: { path: 'a.png', available: true } };
    expect(await localFsrs.installPack(pack(), [card(), card('pack', 'n2', 'zone'), available, { ...card('pack', 'n4', 'legend'), questionIllustration: { path: 'missing.png', available: false } }])).toMatchObject({ count: 2 });
    expect((await localFsrs.exportState()).state.cards.map(value => value.noteId)).toEqual(['n1', 'n3']);
  });
  it('uses actual ts-fsrs scheduling and stores a detailed idempotent review log', async () => {
    await localFsrs.installPack(pack(), [card()]); await localFsrs.activateDeck('engine-deck:pack'); const instant = new Date(Date.now() + 1_000);
    const next = await localFsrs.reviewCard(card().id, 3, instant, 'review-1');
    expect(next.schedule.reps).toBe(1); expect(next.schedule.stability).toBeGreaterThan(0); expect(next.schedule.due.getTime()).toBeGreaterThan(instant.getTime());
    await localFsrs.reviewCard(card().id, 3, instant, 'review-1');
    const backup = await localFsrs.exportState(); expect(backup.state.logs).toHaveLength(1); expect(backup.state.logs[0]).toMatchObject({ scheduler: 'ts-fsrs@5.2.3', rating: 3, before: { reps: 0 }, after: { reps: 1 } });
    await expect(localFsrs.reviewCard(card().id, 4, instant, 'review-1')).rejects.toThrow(/identifiant/);
    await expect(localFsrs.reviewCard(card().id, 3, instant, 'review-2')).rejects.toThrow(/pas encore/);
  });
  it('interleaves due subjects and never returns inactive or future cards', async () => {
    await localFsrs.installPack(pack('a', 'ue-a'), [card('a', 'n1'), card('a', 'n2')]); await localFsrs.installPack(pack('b', 'ue-b'), [card('b', 'n1'), card('b', 'n2')]);
    await localFsrs.activateDeck('engine-deck:a'); await localFsrs.activateDeck('engine-deck:b');
    const queue = await localFsrs.getReviewQueue(); expect(queue.map(value => value.packId)).toEqual(['a', 'b', 'a', 'b']);
    await localFsrs.reviewCard(queue[0].id, 3, new Date(Date.now() + 1_000)); expect(await localFsrs.getReviewQueue()).toHaveLength(3);
    expect(await localFsrs.getReviewQueue('engine-deck:b')).toHaveLength(2);
  });
  it('exports/imports Date schedules and merges without rolling back a newer local review', async () => {
    await localFsrs.installPack(pack(), [card()]); await localFsrs.activateDeck('engine-deck:pack'); const instant = new Date(Date.now() + 1_000); await localFsrs.reviewCard(card().id, 3, instant, 'r1');
    const backup = JSON.stringify(await exportEngineBackup()); const first = (await localFsrs.exportState()).state.cards[0];
    await localFsrs.reviewCard(card().id, 3, first.schedule.due, 'r2'); await importEngineBackup(backup);
    let state = await localFsrs.exportState(); expect(state.state.cards[0].schedule.reps).toBe(2); expect(state.state.logs).toHaveLength(2);
    await clearEngineProgress(); await importEngineBackup(backup); state = await localFsrs.exportState(); expect(state.state.cards[0].schedule.due).toBeInstanceOf(Date); expect(state.state.cards[0].schedule.reps).toBe(1);
  });
  it('keeps newly added source cards in draft while preserving prior review histories', async () => {
    await localFsrs.installPack(pack(), [card()]); await localFsrs.activateDeck('engine-deck:pack'); await localFsrs.reviewCard(card().id, 3, new Date(Date.now() + 1_000), 'r1');
    expect(await localFsrs.installPack(pack(), [card(), card('pack', 'n2')])).toMatchObject({ count: 1 });
    expect((await localFsrs.exportState()).state.cards.find(value => value.noteId === 'n2')?.active).toBe(false);
    await localFsrs.activateDeck('engine-deck:pack'); const value = await localFsrs.exportState(); expect(value.state.logs).toHaveLength(1); expect(value.state.cards.find(item => item.noteId === 'n1')?.schedule.reps).toBe(1);
  });
});
