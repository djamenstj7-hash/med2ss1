import { readFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { describe, expect, it } from 'vitest';
import { engineCards, toEnginePack } from '../engine-src/lib/engine';
import { engineFigureCards, engineFigurePracticeAvailable, engineGalleryFigures, enginePackFigures } from '../engine-src/lib/engine-media';
import type { EngineCard, EngineManifest, EnginePack } from '../engine-src/lib/engine-types';

const directory = resolve(import.meta.dirname, '../engine');
const manifest = JSON.parse(readFileSync(resolve(directory, 'manifest.json'), 'utf8')) as EngineManifest;
const load = (id: string): EnginePack => { const summary = manifest.packs.find(pack => pack.id === id)!; return toEnginePack(id, JSON.parse(readFileSync(resolve(directory, summary.sourcePath), 'utf8')), summary); };

describe('MED_ENGINE supplied illustrations gallery', () => {
  it('exposes all 438 supplied images from 13 chapters, including the 70 anatomy plates', () => {
    const figures = engineGalleryFigures(manifest);
    expect(figures).toHaveLength(438);
    expect(new Set(figures.map(figure => figure.id)).size).toBe(438);
    expect(new Set(figures.map(figure => figure.packId)).size).toBe(13);
    expect(figures.filter(figure => figure.packId === 'anat_sch1')).toHaveLength(70);
    for (const figure of figures) expect(existsSync(resolve(directory, figure.path)), figure.path).toBe(true);
  });

  it('does not turn absent source illustrations into gallery entries or image requests', () => {
    const pack = load('semio_abord');
    expect(engineCards(pack).some(card => card.questionIllustration?.available === false)).toBe(true);
    expect(enginePackFigures(pack)).toEqual([]);
    expect(engineGalleryFigures(manifest).filter(figure => figure.packId === pack.id)).toEqual([]);
  });

  it('joins every supplied image to its exact source cards and preserves captions', () => {
    const figures = engineGalleryFigures(manifest);
    let covered = 0;
    for (const packId of new Set(figures.map(figure => figure.packId))) {
      const pack = load(packId);
      for (const figure of enginePackFigures(pack)) {
        const cards = engineFigureCards(pack, figure.path);
        expect(cards.length, figure.path).toBeGreaterThan(0);
        for (const card of cards) expect([card.questionIllustration, card.illustration, card.schemaIllustration].some(image => image?.path === figure.path && image.available !== false)).toBe(true);
        covered++;
      }
    }
    expect(covered).toBe(438);
    expect(enginePackFigures(load('anat_sch1')).some(figure => figure.caption?.includes('Sujet 2022/2023'))).toBe(true);
  });

  it('keeps chapter identity when filenames repeat and rejects unsafe or unpublished media', () => {
    const a = { ...manifest.packs[0], id: 'a', title: 'A', availableMedia: ['same.png', '../private.png', 'nested/hidden.svg', 'not-published.svg'] };
    const b = { ...a, id: 'b', title: 'B', availableMedia: ['same.png'] };
    const sample = { ...manifest, packs: [a, b], files: ['assets/packs/a/media/same.png', 'assets/packs/b/media/same.png'] };
    const result = engineGalleryFigures(sample);
    expect(result.map(figure => figure.path)).toEqual(['assets/packs/a/media/same.png', 'assets/packs/b/media/same.png']);
    expect(engineFigureCards(load('anat_fc2'), 'assets/packs/anat_sch1/media/same.png')).toEqual([]);
  });

  it('prioritizes direct repérage and legend work while keeping missing question visuals ungraded', () => {
    const pack = load('anat_fc2');
    const figure = enginePackFigures(pack).find(item => engineFigureCards(pack, item.path).some(card => card.type === 'zone'))!;
    expect(engineFigureCards(pack, figure.path)[0].type).toBe('zone');
    const source = engineCards(pack).find(card => card.type === 'zone')!;
    expect(engineFigurePracticeAvailable(source)).toBe(true);
    expect(engineFigurePracticeAvailable({ ...source, questionIllustration: { path: 'absent.svg', available: false } })).toBe(false);
    expect(engineFigurePracticeAvailable({ ...source, questionIllustration: undefined })).toBe(false);
    expect(engineFigurePracticeAvailable({ ...source, type: 'qrm', questionIllustration: undefined } as EngineCard)).toBe(true);
  });
});
