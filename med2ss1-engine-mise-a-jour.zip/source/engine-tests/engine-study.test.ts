import { describe, expect, it } from 'vitest';
import type { EngineCard, EnginePackSummary } from '../engine-src/lib/engine-types';
import { createEngineSession, engineLessonKey, engineSubjectKey, filterEngineCards, filterEnginePacks, isEngineSession, latestEngineAttempts, nextEngineExam, pauseEngineSession, readEngineDraftAnswer, restoreEngineCards } from '../engine-src/lib/engine-study';
import type { StudyAttempt } from '../engine-src/lib/study-types';

const card = (id: string, patch: Partial<EngineCard> = {}): EngineCard => ({ id: `engine:p:${id}:one`, noteId: id, packId: 'p', chapterId: 'chapter-p', subjectId: 'ue-a', type: 'qrm', prompt: 'Quelle est la définition de l’érythème ?', answer: 'Réponse', explanation: 'Explication', options: ['A', 'B'], correct: [0], required: [], forbidden: [], justifications: ['Vrai', 'Faux'], tags: ['niveau-simple'], annale: false, official: false, source: {}, fields: {}, note: { id, type: 'qrm', chapter_id: 'chapter-p', tags: [], champs: {} }, ...patch });
const summary = (patch: Partial<EnginePackSummary> = {}): EnginePackSummary => ({ id: 'p', title: 'Sémiologie : examen du malade', subjectId: 'ue-a', subjectIds: ['ue-a'], chapterIds: ['chapter-p'], noteCount: 2, cardCount: 3, sourceCardCount: 2, annaleCount: 1, unverifiedCount: 0, types: { qrm: 2, cloze: 1 }, tags: ['niveau-simple', 'definitions'], searchText: 'Érythème, anamnèse', sourcePath: 'packs/p.json', availableMedia: [], ...patch });

describe('MED_ENGINE practice preserves source identity and records evidence', () => {
  it('searches accents and combines UE, format and source-level filters without inventing matches', () => {
    const packs = [summary(), summary({ id: 'b', title: 'Pharmacologie', subjectId: 'ue-b', subjectIds: ['ue-b'], annaleCount: 0, unverifiedCount: 1, types: { basic: 1 }, tags: ['a-relire'] })];
    expect(filterEnginePacks(packs, { query: 'erytheme', subjectId: 'ue-a', type: 'cloze', level: 'annales' }).map(item => item.id)).toEqual(['p']);
    expect(filterEnginePacks(packs, { type: 'basic', level: 'annales' })).toHaveLength(0);
    expect(filterEnginePacks(packs, { level: 'a-relire' }).map(item => item.id)).toEqual(['b']);
  });
  it('annales and mistakes are exact sets and keep separate cloze/image variants', () => {
    const cards = [card('cloze-1', { type: 'cloze', annale: true }), card('cloze-2', { type: 'cloze', annale: true }), card('new', { annale: false })];
    const weak = new Set([cards[1].id]);
    expect(filterEngineCards(cards, { weakIds: weak }, 'annales').map(item => item.id)).toEqual([cards[1].id]);
    expect(filterEngineCards(cards, {}, 'annales')).toHaveLength(2);
    expect(cards).toHaveLength(3);
  });
  it('saves only card/attempt IDs, pauses active time and restores the original sequence', () => {
    const cards = [card('a'), card('b'), card('c')];
    const now = Date.parse('2026-10-27T16:00:00Z');
    const session = createEngineSession('p', cards, 'bachotage', 0, 20, now);
    session.answers[session.cardIds[0]] = 'attempt-a';
    const paused = pauseEngineSession(session, now + 15000);
    expect(paused.elapsedMs).toBe(15000); expect(paused.runningSince).toBeNull();
    expect(pauseEngineSession(paused, now + 600000).elapsedMs).toBe(15000);
    expect(restoreEngineCards([...cards].reverse(), paused).map(item => item.id)).toEqual(session.cardIds);
    expect(isEngineSession(JSON.parse(JSON.stringify(paused)))).toBe(true);
    expect(paused).not.toHaveProperty('schedule');
    expect(paused.limitSeconds).toBeNull();
  });
  it('rejects replaced content and invalid saved sessions rather than silently skipping cards', () => {
    const cards = [card('a'), card('b')]; const session = createEngineSession('p', cards, 'exam', 20, 12);
    expect(() => restoreEngineCards(cards.slice(0, 1), session)).toThrow(/changé/);
    expect(isEngineSession({ ...session, application: 'med2' })).toBe(false);
    expect(isEngineSession({ ...session, answers: { 'unrelated-card': 'attempt' } })).toBe(false);
    expect(isEngineSession({ ...session, index: 8 })).toBe(false);
    expect(isEngineSession({ ...session, cardIds: [session.cardIds[0], session.cardIds[0]] })).toBe(false);
    expect(session.limitSeconds).toBe(720);
  });
  it('resumes ungraded mental and typed exam answers without turning them into failures', () => {
    const mental = readEngineDraftAnswer(JSON.stringify({ application: 'engine', answer: { graded: false, correct: false, confidence: 'sure' } }));
    expect(mental).toEqual({ graded: false, correct: false, confidence: 'sure' });
    const typed = readEngineDraftAnswer(JSON.stringify({ application: 'engine', answer: { graded: false, correct: false, responseText: 'Ma réponse', selected: [], point: { x: 12, y: 30 }, confidence: 'hesitant', unknown: 'dropped' } }));
    expect(typed).toMatchObject({ graded: false, responseText: 'Ma réponse', point: { x: 12, y: 30 } });
    expect(typed).not.toHaveProperty('unknown');
    expect(readEngineDraftAnswer(JSON.stringify({ application: 'engine', answer: { graded: false, selected: [-1] } }))).toBeUndefined();
    expect(readEngineDraftAnswer(JSON.stringify({ application: 'engine', answer: { graded: false, point: { x: '12', y: 30 } } }))).toBeUndefined();
    expect(readEngineDraftAnswer(JSON.stringify({ application: 'engine', answer: { graded: false, confidence: 'invented' } }))).toBeUndefined();
    expect(readEngineDraftAnswer(JSON.stringify({ application: 'med2', answer: { graded: false } }))).toBeUndefined();
  });
  it('uses the most recent recorded answer and does not borrow MED2 failures', () => {
    const attempt = (id: string, questionId: string, correct: boolean, createdAt: string): StudyAttempt => ({ id, questionId, subjectId: engineSubjectKey('ue-a'), lessonId: engineLessonKey('p'), mode: 'practice', correct, createdAt });
    const records = [attempt('1', 'engine:p:q:one', false, '2026-10-26T10:00:00Z'), attempt('2', 'engine:p:q:one', true, '2026-10-27T10:00:00Z'), attempt('3', 'med2-other', false, '2026-10-27T11:00:00Z')];
    const latest = latestEngineAttempts([...records].reverse());
    expect(latest.size).toBe(1); expect(latest.get('engine:p:q:one')?.correct).toBe(true);
    expect(nextEngineExam('2026-10-26', '2026-10-27')).toBeNull();
    expect(nextEngineExam('2026-10-27', '2026-10-27')).toBe('2026-10-27');
    expect(nextEngineExam('2026-13-03', '2026-10-27')).toBeNull();
  });
});
