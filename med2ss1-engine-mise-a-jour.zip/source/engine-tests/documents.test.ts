import { describe, expect, it } from 'vitest';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { readFileSync } from 'node:fs';
import EngineDocuments from '../engine-src/components/EngineDocuments';
import { documentMatchesQuery, documentSearch, engineDocumentCounts, engineDocumentsForPack, engineDocumentsForSource, engineOtherSubjectDocuments, engineSourceDocuments, safeDocumentUrl } from '../engine-src/lib/engine-documents';
import { toEnginePack, type EngineManifest } from '../engine-src/lib/engine';

const root = new URL('../', import.meta.url);
const read = (path: string) => JSON.parse(readFileSync(new URL(path, root), 'utf8'));
const manifest = read('engine/manifest.json') as EngineManifest;
const load = (id: string) => { const summary = manifest.packs.find(pack => pack.id === id)!; return toEnginePack(id, read('engine/' + summary.sourcePath), summary); };

describe('MED_ENGINE actual Drive course documents', () => {
  it('exposes every verified file without changing the observed URLs or embedding PDF bytes', () => {
    const inventory = read('docs/source-pdf-inventory.json');
    expect(engineDocumentCounts).toEqual({ documents: 123, pdf: 116, matchedPacks: 61 });
    expect(engineSourceDocuments).toHaveLength(inventory.files.length);
    const byId = new Map(inventory.files.map((file: { id: string; url: string }) => [file.id, file]));
    for (const file of engineSourceDocuments) {
      expect(file.url).toBe((byId.get(file.id) as { url: string }).url);
      expect(file.url).toMatch(/^https:\/\/(drive|docs)\.google\.com\//);
    }
  });

  it('retrieves the three actual BMCT parts without replacing old editions or annales', () => {
    const pack = load('bmct_pharmacodynamie');
    expect(engineDocumentsForPack(pack).map(file => file.title)).toEqual(['PHARMACODYNAMIE GÉNÉRALE 1', 'PHARMACODYNAMIE GENREALE 2', 'PHARAMCODYNAMIE GÉNÉRALE 3']);
    expect(engineDocumentsForSource(pack.id, 'src-cours-bmct-pd-2425')).toEqual([]);
    expect(engineDocumentsForSource(pack.id, 'src-annales-bmct-pd')).toEqual([]);
    expect(engineDocumentsForPack('unknown')).toEqual([]);
  });

  it('keeps same-UE browsing separate from exact source matches', () => {
    const pack = load('bmct_pharmacodynamie');
    const exact = engineDocumentsForPack(pack), other = engineOtherSubjectDocuments(pack);
    expect(other.length).toBeGreaterThan(0);
    expect(other.every(file => file.ue === 'BMCT')).toBe(true);
    expect(other.some(file => exact.some(source => source.id === file.id))).toBe(false);
    expect(documentSearch('SÉMIOLOGIE')).toBe('semiologie');
  });

  it('finds all three pharmacodynamie parts using the validated chapter title despite original filename typos', () => {
    const exact = engineDocumentsForPack(load('bmct_pharmacodynamie'));
    const broad = engineSourceDocuments.filter(file => documentMatchesQuery(file, 'pharmacodynamie'));
    expect(broad.map(file => file.id)).toEqual(expect.arrayContaining(exact.map(file => file.id)));
    for (const query of ['pharmacodynamie générale', 'PHARMACODYNAMIE GENERALE']) {
      const found = engineSourceDocuments.filter(file => documentMatchesQuery(file, query));
      expect(found.map(file => file.id).sort()).toEqual(exact.map(file => file.id).sort());
    }
    expect(exact[1].title).toBe('PHARMACODYNAMIE GENREALE 2');
    expect(exact[2].title).toBe('PHARAMCODYNAMIE GÉNÉRALE 3');
    expect(engineDocumentsForSource('bmct_pharmacodynamie', 'src-cours-bmct-pd-2425')).toEqual([]);
  });

  it('opens reliable provider viewers in a separate tab, without unsafe URLs or automatic cross-origin downloads', () => {
    const html = renderToStaticMarkup(createElement(EngineDocuments, { pack: load('bmct_pharmacodynamie') }));
    expect(html).toContain('target="_blank" rel="noopener noreferrer"');
    expect(html).toContain('Une connexion est nécessaire');
    expect(html).not.toContain('<iframe');
    expect(html).not.toContain('download=');
    for (const value of ['javascript:alert(1)', 'https://drive.google.com.evil.test/file/d/x/view', 'https://user:secret@drive.google.com/file/d/x/view', 'https://drive.google.com/uc?export=download&id=x', 'http://drive.google.com/file/d/x/view']) expect(safeDocumentUrl(value)).toBeUndefined();
  });
});
