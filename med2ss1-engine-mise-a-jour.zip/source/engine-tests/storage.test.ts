import 'fake-indexeddb/auto';
import { beforeEach, describe, expect, it } from 'vitest';
import { createStore, get, set } from 'idb-keyval';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { createEmptyCard } from 'ts-fsrs';
import { study } from '../engine-src/lib/study';
import { clearEngineProgress, exportEngineBackup, importEngineBackup, MAX_ENGINE_BACKUP_BYTES } from '../engine-src/lib/local-backup';
import { backupFitsByteLimit } from '../engine-src/lib/engine-local-validation';
import { engineCards, toEnginePack, type EngineManifest } from '../engine-src/lib/engine';
import { localFsrs, type LocalEngineCard, type LocalEngineDeck } from '../engine-src/lib/local-fsrs';

const attempt = { id: 'answer-1', questionId: 'engine:pack:n1:main', lessonId: 'engine:pack:pack', subjectId: 'engine:subject:ue', mode: 'practice' as const, correct: true, selected: [0, 2], confidence: 'sure' as const, application: 'engine' as const, engineMode: 'bachotage' as const };
beforeEach(async () => { await clearEngineProgress(); });
describe('local MED_ENGINE progress', () => {
  it('keeps every original MED2 and Medora database untouched, including on reset', async () => {
    const original = createStore('med2.semestre1.pdf.v1', 'pdfs'), medora = createStore('medora-curriculum-v2', 'study');
    await set('pdf-1', { bytes: [1, 2, 3] }, original); await set('study:owner', { note: 'existing' }, medora);
    await study.setNote('engine:pack:pack', 'New MED_ENGINE note'); await clearEngineProgress();
    expect(await get('pdf-1', original)).toEqual({ bytes: [1, 2, 3] }); expect(await get('study:owner', medora)).toEqual({ note: 'existing' });
    expect((await study.load()).notes).toEqual({});
  });
  it('serializes concurrent edits without losing notes, bookmarks or attempts', async () => {
    await Promise.all([study.setNote('engine:pack:pack', 'A note'), study.setBookmark('engine:pack:pack', true), study.recordAttempt(attempt)]);
    const value = await study.load(); expect(value.notes['engine:pack:pack']).toBe('A note'); expect(value.bookmarks).toEqual(['engine:pack:pack']); expect(value.attempts).toHaveLength(1);
    expect(value.attempts[0]).toMatchObject({ confidence: 'sure', selected: [0, 2], application: 'engine', engineMode: 'bachotage' });
  });
  it('makes repeated answer and session identifiers idempotent', async () => {
    await study.recordAttempt(attempt); await study.recordAttempt(attempt);
    const session = { id: 'session-1', mode: 'practice' as const, lessonId: 'engine:pack:pack', startedAt: '2026-10-28T10:00:00Z', finishedAt: '2026-10-28T10:01:00Z', questionCount: 1, correctCount: 1, durationSeconds: 60 };
    await study.recordSession(session); await study.recordSession(session);
    const state = await study.load(); expect(state.attempts).toHaveLength(1); expect(state.sessions).toHaveLength(1);
  });
  it('persists a paused exam with ungraded mental answers without inventing a failure', async () => {
    const id = 'engine:exam-answer:mental-1'; await study.saveWritingDraft(id, JSON.stringify({ application: 'engine', answer: { correct: false, graded: false } }));
    await study.saveActiveSession({ application: 'engine', schemaVersion: 1, id: 'exam-1', packId: 'pack', mode: 'exam', cardIds: [attempt.questionId], answers: { [attempt.questionId]: id }, index: 0, startedAt: '2026-10-28T10:00:00Z', elapsedMs: 1_000, runningSince: 3_000, questionStartedMs: 0, limitSeconds: 60 });
    const state = await study.load(); expect(state.attempts).toHaveLength(0); expect(state.activeSession?.runningSince).toBeNull(); expect(state.activeSession?.elapsedMs).toBe(1_000); expect(JSON.parse(state.writingDrafts[id]).answer.graded).toBe(false);
  });
  it('round-trips and merges a module backup while keeping newer local notes', async () => {
    await study.setNote('engine:pack:pack', 'Old note'); await study.recordAttempt(attempt); const backup = JSON.stringify(await exportEngineBackup());
    await study.setNote('engine:pack:pack', 'Current note'); await study.recordAttempt({ ...attempt, id: 'answer-2', questionId: 'engine:pack:n2:main' });
    await importEngineBackup(backup); await importEngineBackup(backup);
    const state = await study.load(); expect(state.notes['engine:pack:pack']).toBe('Current note'); expect(state.attempts).toHaveLength(2);
  });
  it('rejects another app, oversized text, impossible dates and foreign owner scopes', async () => {
    await expect(importEngineBackup({ application: 'medora', schemaVersion: 1 })).rejects.toThrow();
    expect(() => study.setNote('engine:pack:pack', 'x'.repeat(40_001))).toThrow();
    expect(() => study.setExamDate('engine:subject:ue', '2026-02-30')).toThrow();
    expect(() => study.setBookmark('engine:pack:pack', true, 'medora-owner')).toThrow();
    expect(() => study.setNote('__proto__', 'Bad')).toThrow();
    expect((await study.load()).notes).toEqual({});
  });
  it('preflights both backup sections so invalid FSRS data cannot partly import notes', async () => {
    await study.setNote('engine:pack:pack', 'Imported'); const backup = await exportEngineBackup(); await clearEngineProgress();
    (backup.fsrs.state as unknown as { cards: unknown[] }).cards = [{ id: 'broken' }];
    await expect(importEngineBackup(backup)).rejects.toThrow(); expect((await study.load()).notes).toEqual({});
  });
  it('uses the same 100 MiB byte bound for UTF-8 JSON rather than counting characters', () => {
    expect(MAX_ENGINE_BACKUP_BYTES).toBe(100 * 1024 * 1024);
    for (const text of ['abc', 'élève', '🧠医学', '\ud800']) {
      const bytes = new TextEncoder().encode(text).byteLength;
      expect(backupFitsByteLimit(text, bytes)).toBe(true);
      expect(backupFitsByteLimit(text, bytes - 1)).toBe(false);
    }
  });
  it('round-trips the complete 141-pack bank above the former 25 MiB limit without dropping cards or history', async () => {
    const manifest = JSON.parse(readFileSync(resolve('engine/manifest.json'), 'utf8')) as EngineManifest;
    const backup = await exportEngineBackup(), now = new Date('2026-10-28T12:00:00.000Z');
    for (const summary of manifest.packs) {
      const raw = JSON.parse(readFileSync(resolve('engine', summary.sourcePath), 'utf8'));
      const pack = toEnginePack(summary.id, raw, summary);
      const eligible = engineCards(pack).filter(card => !['zone', 'legend'].includes(card.type) || card.questionIllustration && card.questionIllustration.available !== false);
      if (!eligible.length) continue;
      const deck: LocalEngineDeck = { id: `engine-deck:${pack.id}`, packId: pack.id, title: pack.title, subjectId: pack.subjects[0]?.id || 'engine:subject:other', createdAt: now.toISOString(), cardIds: eligible.map(card => card.id), active: false };
      backup.fsrs.state.decks.push(deck);
      for (const card of eligible) backup.fsrs.state.cards.push({ id: card.id, sourceId: card.id, packId: pack.id, deckId: deck.id, noteId: card.noteId, prompt: card.prompt, answer: card.answer, explanation: card.explanation, schedule: createEmptyCard(now), active: false } satisfies LocalEngineCard);
    }
    expect(backup.fsrs.state.decks).toHaveLength(141);
    expect(backup.fsrs.state.cards).toHaveLength(23_280);
    await importEngineBackup(backup);
    const first = backup.fsrs.state.cards[0], last = backup.fsrs.state.cards.at(-1)!;
    await localFsrs.activateDeck(first.deckId);
    await localFsrs.reviewCard(first.id, 3, new Date(now.getTime() + 1_000), 'complete-bank-review');
    await study.recordAttempt(attempt);
    await study.setNote('engine:pack:pack', 'Personal note retained with the complete bank.');
    // Older formatted exports remain importable too; compact output is now used by the UI.
    const exported = JSON.stringify(await exportEngineBackup(), null, 2);
    const byteLength = new TextEncoder().encode(exported).byteLength;
    expect(byteLength).toBeGreaterThan(25 * 1024 * 1024);
    expect(byteLength).toBeLessThan(MAX_ENGINE_BACKUP_BYTES);
    await clearEngineProgress();
    await importEngineBackup(exported);
    const restored = await exportEngineBackup();
    expect(restored.fsrs.state.cards).toHaveLength(23_280);
    expect(restored.fsrs.state.decks).toHaveLength(141);
    expect(restored.fsrs.state.logs.map(log => log.id)).toEqual(['complete-bank-review']);
    expect(restored.fsrs.state.cards.find(card => card.id === first.id)?.schedule.reps).toBe(1);
    expect(restored.fsrs.state.cards.at(-1)).toMatchObject({ id: last.id, prompt: last.prompt, answer: last.answer });
    expect(restored.study.state.attempts).toHaveLength(1);
    expect(restored.study.state.notes['engine:pack:pack']).toBe('Personal note retained with the complete bank.');
  }, 60_000);
});
