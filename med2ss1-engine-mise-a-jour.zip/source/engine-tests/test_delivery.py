"""The phone installer must preserve the old site and reject incomplete releases."""
import hashlib
import importlib.util
import json
from pathlib import Path
import stat
import tempfile
import unittest
import warnings
import zipfile

SCRIPT = Path(__file__).resolve().parents[1] / 'docs/engine-iphone/assemble.py'
SPEC = importlib.util.spec_from_file_location('engine_assemble', SCRIPT)
assembly = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(assembly)


def digest(data):
    return hashlib.sha256(data).hexdigest()


class DeliveryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.repo = self.root / 'repository'
        self.delivery = self.root / 'delivery'
        self.output = self.root / 'site'
        self.repo.mkdir()
        self.delivery.mkdir()
        for name, value in [('index.html', b'<main>85 cours existants</main>'),
                            ('service-worker.js', b'const VERSION="old";'),
                            ('data/pedagogie.json', b'cours personnels conserves'),
                            ('data/.gitkeep', b''),
                            ('Assets/figure.svg', b'<svg/>'),
                            ('Assets/.svg', b'historical public file'),
                            ('pdf-library.js', b'const pdf = true;'),
                            ('.env', b'not public'),
                            ('.github/workflows/old.yml', b'not public')]:
            path = self.repo / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(value)
        payload = []
        for name, value in [('index.html', b'<main>85 cours + MED_ENGINE</main>'),
                            ('service-worker.js', b'const VERSION="new";'),
                            ('engine-host.js', b'const engine = true;'),
                            ('engine-module/engine.js', b'const moduleReady = true;'),
                            ('engine-module/engine.css', b'.engine{color:purple}')]:
            path = self.delivery / 'patch' / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(value)
            payload.append({'path': name, 'sha256': digest(value)})
        self.manifest = {'application': 'med2ss1-engine', 'schemaVersion': 1, 'version': 'test',
                         'baseCommit': 'snapshot', 'engineFiles': 2, 'parts': [], 'payload': payload,
                         'guards': [{'path': name, 'acceptedSha256': [assembly.sha(self.repo / name) if (self.repo / name).is_file() else None,
                                                                        assembly.sha(self.delivery / 'patch' / name)]}
                                    for name in ['index.html', 'service-worker.js', 'engine-host.js']]}
        self.part('med2ss1-engine-contenus-1.zip', [('engine/manifest.json', b'{"packs":[]}')])
        self.part('med2ss1-engine-contenus-2.zip', [('engine/packs/test.json', b'{"notes":[]}')])
        self.save()

    def part(self, name, entries):
        path = self.repo / name
        with warnings.catch_warnings():
            warnings.simplefilter('ignore', UserWarning)
            with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as bundle:
                for name_or_info, value in entries:
                    bundle.writestr(name_or_info, value)
        entry = {'file': name, 'sha256': assembly.sha(path)}
        self.manifest['parts'] = [item for item in self.manifest['parts'] if item['file'] != name] + [entry]

    def save(self):
        (self.delivery / 'delivery.json').write_text(json.dumps(self.manifest))

    def run_assembly(self):
        return assembly.assemble(self.repo, self.delivery, self.output, check_js=False)

    def test_preserves_existing_courses_assets_pdfs_and_excludes_private_source_files(self):
        report = self.run_assembly()
        self.assertEqual(report['engineFiles'], 2)
        for name in ['data/pedagogie.json', 'data/.gitkeep', 'Assets/figure.svg', 'Assets/.svg', 'pdf-library.js']:
            self.assertEqual((self.repo / name).read_bytes(), (self.output / name).read_bytes())
        self.assertIn('MED_ENGINE', (self.output / 'index.html').read_text())
        self.assertEqual((self.repo / 'index.html').read_text(), '<main>85 cours existants</main>')
        self.assertFalse((self.output / '.env').exists())
        self.assertFalse((self.output / '.github').exists())
        self.assertEqual(list(self.output.glob('*.zip')), [])

    def test_missing_part_stops_before_publication_directory_exists(self):
        (self.repo / 'med2ss1-engine-contenus-2.zip').unlink()
        with self.assertRaisesRegex(ValueError, 'Partie manquante'):
            self.run_assembly()
        self.assertFalse(self.output.exists())

    def test_wrong_digest_stops_before_any_copy(self):
        with (self.repo / 'med2ss1-engine-contenus-1.zip').open('ab') as stream:
            stream.write(b'corruption')
        with self.assertRaisesRegex(ValueError, 'correspond pas'):
            self.run_assembly()
        self.assertFalse(self.output.exists())

    def test_new_host_version_is_preserved_by_refusing_old_patch(self):
        (self.repo / 'index.html').write_text('<main>newer interface</main>')
        with self.assertRaisesRegex(ValueError, 'a changé'):
            self.run_assembly()
        self.assertFalse(self.output.exists())
        self.assertEqual((self.repo / 'index.html').read_text(), '<main>newer interface</main>')

    def test_compatible_already_patched_host_is_accepted_for_rerun(self):
        for name in assembly.HOST_FILES:
            (self.repo / name).write_bytes((self.delivery / 'patch' / name).read_bytes())
        self.assertEqual(self.run_assembly()['engineFiles'], 2)

    def test_path_traversal_absolute_and_unknown_prefix_rejected(self):
        for path in ['../outside.json', '/engine/outside.json', 'engine/../outside.json',
                     'engine\\outside.json', 'data/pedagogie.json', 'engine//outside.json']:
            with self.subTest(path=path):
                self.part('med2ss1-engine-contenus-2.zip', [(path, b'bad')])
                self.save()
                with self.assertRaises(ValueError):
                    self.run_assembly()
                self.assertFalse(self.output.exists())

    def test_symlink_and_duplicate_entry_rejected(self):
        link = zipfile.ZipInfo('engine/packs/link.json')
        link.create_system = 3
        link.external_attr = (stat.S_IFLNK | 0o777) << 16
        for entries in [[(link, b'../../outside')], [('engine/manifest.json', b'duplicate')],
                        [('engine/packs/a.json', b'a'), ('engine/packs/a.json', b'b')],
                        [('engine/packs', b'file'), ('engine/packs/b.json', b'collision')]]:
            with self.subTest(entries=str(entries)):
                self.part('med2ss1-engine-contenus-2.zip', entries)
                self.save()
                with self.assertRaises(ValueError):
                    self.run_assembly()
                self.assertFalse(self.output.exists())

    def test_payload_cannot_overwrite_course_data(self):
        self.manifest['payload'].append({'path': 'data/pedagogie.json', 'sha256': '0' * 64})
        self.save()
        with self.assertRaisesRegex(ValueError, 'non autorisé'):
            self.run_assembly()

    def test_payload_corruption_rejected(self):
        (self.delivery / 'patch/engine-host.js').write_text('modified')
        with self.assertRaisesRegex(ValueError, 'endommagé'):
            self.run_assembly()
        self.assertFalse(self.output.exists())

    def test_engine_file_count_and_output_source_overlap_rejected(self):
        self.manifest['engineFiles'] = 3
        self.save()
        with self.assertRaisesRegex(ValueError, 'incomplète'):
            self.run_assembly()
        self.assertFalse(self.output.exists())
        with self.assertRaisesRegex(ValueError, 'distinct'):
            assembly.assemble(self.repo, self.delivery, self.repo / 'site', check_js=False)


if __name__ == '__main__':
    unittest.main()
