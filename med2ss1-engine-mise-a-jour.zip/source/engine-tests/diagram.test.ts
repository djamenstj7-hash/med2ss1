import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import { engineDiagramIsInteractive } from '../engine-src/components/EngineQuestion';
import type { EngineManifest } from '../engine-src/lib/engine-types';

describe('Labels for the supplied MED_ENGINE diagram supports', () => {
  it('distinguishes the five supplied interactive supports from the ten explanatory supports', () => {
    const manifest = JSON.parse(readFileSync(new URL('../engine/manifest.json', import.meta.url), 'utf8')) as EngineManifest;
    const supports = manifest.diagrams.map(diagram => ({
      id: diagram.id,
      interactive: engineDiagramIsInteractive(readFileSync(new URL('../engine/' + diagram.htmlPath, import.meta.url), 'utf8')),
    }));
    expect(supports).toHaveLength(15);
    expect(supports.filter(diagram => diagram.interactive).map(diagram => diagram.id).sort()).toEqual([
      'bmct:activite-intrinseque',
      'bmct:affinite-activite',
      'bmct:essai-parallele-croise',
      'bmct:ki-affinite',
      'bmct:potentiel-action',
    ]);
    expect(supports.filter(diagram => !diagram.interactive)).toHaveLength(10);
  });

  it('recognises authored SVG controls without claiming that a static diagram is an exercise', () => {
    expect(engineDiagramIsInteractive('<svg><path d="M0 0L10 10" /></svg>')).toBe(false);
    expect(engineDiagramIsInteractive('<svg><g onclick="showLabel(1)"><circle r="10" /></g></svg>')).toBe(true);
    expect(engineDiagramIsInteractive('<button onpointerdown="selectRegion(1)">Repère</button>')).toBe(true);
  });
});
