import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';

const root = new URL('../', import.meta.url);
const original = JSON.parse(readFileSync(new URL('qa/base-content-hashes.json', root), 'utf8')) as { sourceCommit: string; sha256: Record<string, string> };

describe('Original MED2 S1 content and user tools remain intact', () => {
  it('preserves every original course, illustration, PDF tool and installation identity byte for byte', () => {
    expect(Object.keys(original.sha256).length).toBeGreaterThan(240);
    for (const [file, digest] of Object.entries(original.sha256)) {
      expect(createHash('sha256').update(readFileSync(new URL(file, root))).digest('hex'), file).toBe(digest);
    }
  });
  it('keeps the existing 85 courses and all 594 detailed chapters available', () => {
    const value = JSON.parse(readFileSync(new URL('data/pedagogie.json', root), 'utf8')) as { lessons: Record<string, { sections: unknown[] }> };
    const lessons = Object.values(value.lessons);
    expect(lessons).toHaveLength(85);
    expect(lessons.reduce((sum, lesson) => sum + lesson.sections.length, 0)).toBe(594);
  });
});
