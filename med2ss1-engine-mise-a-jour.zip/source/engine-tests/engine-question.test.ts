import { describe, expect, it } from 'vitest';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import EngineQuestion from '../engine-src/components/EngineQuestion';
import type { EngineCard, EnginePack } from '../engine-src/lib/engine-types';
import { buildEngineDiagramDocument, engineExactChoices, engineZoneCenter, parseEngineCloze, pointInEngineZone } from '../engine-src/lib/engine-question';

describe('MED_ENGINE question interpretation', () => {
  const pack: EnginePack = { id: 'test', title: 'Test', sourcePath: 'packs/test.json', format: 'hippocampe.paquet', format_version: 1, subjects: [], chapters: [], source_documents: [], media: [], notes: [], cards: [], variants: [] };
  const card: EngineCard = { id: 'test-card', noteId: 'test-note', packId: 'test', chapterId: 'test', subjectId: 'test', type: 'zone', prompt: 'Où se situe le repère ?', answer: 'Le repère source.', explanation: 'Explication.', options: [], correct: [], required: [], forbidden: [], justifications: [], tags: [], annale: false, official: false, source: {}, fields: {}, note: { id: 'test-note', type: 'zone', chapter_id: 'test', tags: [], champs: {} }, questionIllustration: { path: 'assets/packs/test/media/missing.svg', available: false } };

  it('does not emit an image request for a known-missing required visual', () => {
    const html = renderToStaticMarkup(createElement(EngineQuestion, { pack, card }));
    expect(html).not.toContain('<img');
    expect(html).not.toContain('<image');
    expect(html).toContain('L’image de repérage n’est pas fournie');
    expect(html).toContain('Consulter le corrigé sans notation');
  });

  it('keeps absent correction media as a reference without inventing an incorrect preview', () => {
    const html = renderToStaticMarkup(createElement(EngineQuestion, { pack, card: { ...card, type: 'qrm', options: ['A', 'B'], correct: [1], questionIllustration: undefined, illustration: { path: 'assets/packs/test/media/missing.png', available: false } }, disabled: true, reveal: true }));
    expect(html).not.toContain('<img');
    expect(html).toContain('Illustration absente des fichiers fournis');
    expect(html).toContain('Corrigé de référence');
    expect(html).not.toContain('À revoir');
  });

  it('hides every occurrence of only the selected cloze group, including hints', () => {
    const source = 'Les signes {{c1::fonctionnels::type}} sont {{c2::subjectifs}}. {{c1::Fonctionnel}} signifie recueilli à l’interrogatoire.';
    const question = parseEngineCloze(source, 1);
    expect(question.filter(part => part.hidden)).toHaveLength(2);
    expect(question.map(part => part.text).join('')).not.toContain('fonctionnels');
    expect(question.map(part => part.text).join('')).toContain('subjectifs');
    expect(question[1].hint).toBe('type');
    expect(parseEngineCloze(source, 1, true).every(part => !part.hidden)).toBe(true);
  });

  it('grades an exact set, supports all-false items and ignores duplicate selections', () => {
    expect(engineExactChoices([3, 1], [1, 3])).toBe(true);
    expect(engineExactChoices([1, 3, 4], [1, 3])).toBe(false);
    expect(engineExactChoices([], [])).toBe(true);
    expect(engineExactChoices([1, 1], [1])).toBe(true);
  });

  it('uses image units with inclusive rectangular and circular boundaries', () => {
    expect(pointInEngineZone({ x: 250, y: 295 }, { cle: 'a', forme: 'rect', coords: [30, 40, 250, 295] })).toBe(true);
    expect(pointInEngineZone({ x: 251, y: 295 }, { cle: 'a', forme: 'rect', coords: [30, 40, 250, 295] })).toBe(false);
    expect(pointInEngineZone({ x: 13, y: 14 }, { cle: 'a', forme: 'circle', coords: [10, 10, 5] })).toBe(true);
    expect(pointInEngineZone({ x: 13, y: 15 }, { cle: 'a', forme: 'circle', coords: [10, 10, 5] })).toBe(false);
  });

  it('supports concave polygons without accepting their empty bounding box corners', () => {
    const zone = { cle: 'a', forme: 'poly', coords: [0, 0, 100, 0, 100, 20, 20, 20, 20, 100, 0, 100] };
    expect(pointInEngineZone({ x: 10, y: 80 }, zone)).toBe(true);
    expect(pointInEngineZone({ x: 80, y: 80 }, zone)).toBe(false);
    const accessibleCenter = engineZoneCenter(zone)!;
    expect(pointInEngineZone(accessibleCenter, zone)).toBe(true);
  });

  it('keeps malformed geometry ungraded instead of inventing an incorrect answer', () => {
    expect(pointInEngineZone({ x: 10, y: 10 }, { cle: 'a', forme: 'poly', coords: [0, 0, 2] })).toBeNull();
    expect(pointInEngineZone({ x: Number.NaN, y: 10 }, { cle: 'a', forme: 'rect', coords: [0, 0, 20, 20] })).toBeNull();
    expect(pointInEngineZone({ x: 10, y: 10 }, { cle: 'a', forme: 'unsupported', coords: [0, 0] })).toBeNull();
  });

  it('places a restrictive CSP before source scripts while preserving local interactivity', () => {
    const html = '<!doctype html><html><head><meta http-equiv="refresh" content="0;url=https://example.invalid"><base href="https://example.invalid"></head><body><button onclick="this.textContent=42">Test</button><script>const answer = 42;</script></body></html>';
    const document = buildEngineDiagramDocument(html);
    expect(document).toContain("connect-src 'none'");
    expect(document).toContain("default-src 'none'");
    expect(document).toContain("script-src 'unsafe-inline'");
    expect(document.indexOf('Content-Security-Policy')).toBeLessThan(document.indexOf('<script>'));
    expect(document).not.toContain('http-equiv="refresh"');
    expect(document).not.toContain('<base ');
    expect(document).toContain('onclick="this.textContent=42"');
  });
});
