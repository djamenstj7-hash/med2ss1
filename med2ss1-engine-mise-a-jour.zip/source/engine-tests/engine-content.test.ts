import { readFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';
import { describe, expect, it } from 'vitest';
import { clozeIndices, engineAnnale, engineAssetUrl, engineCards, engineVariants, toEnginePack } from '../engine-src/lib/engine';
import type { EngineManifest, EngineNote } from '../engine-src/lib/engine';

const root = resolve(import.meta.dirname, '../engine');
const read = (path: string) => JSON.parse(readFileSync(resolve(root, path), 'utf8'));
const note = (id: string, type: EngineNote['type'], champs: Record<string, unknown>): EngineNote => ({ id, type, chapter_id: 'chapter', tags: [], champs });
const raw = (notes: EngineNote[], cards = notes.map(item => ({ id: item.id, note_id: item.id, kind: item.type }))) => ({ format: 'hippocampe.paquet', format_version: 1, subjects: [{ id: 'subject', nom: 'Sujet', couleur: '#007AFF' }], chapters: [{ id: 'chapter', nom: 'Chapitre', subject_id: 'subject' }], source_documents: [], media: [], notes, cards });

describe('MED_ENGINE independent recall cards', () => {
  it('separates cloze groups, keeps repeated groups together and preserves authored hints', () => {
    const n = note('cloze', 'cloze', { texte: 'Le {{c1::sodium::ion}} et le {{c2::potassium}} ; encore {{c1::Na+}}.' });
    const pack = toEnginePack('sample', raw([n]));
    const cards = engineCards(pack);
    expect(clozeIndices(String(n.champs.texte))).toEqual([1, 2]);
    expect(cards.map(item => item.id)).toEqual(['engine:sample:cloze:c1', 'engine:sample:cloze:c2']);
    expect(cards[0].prompt).toBe('Le [ion] et le potassium ; encore […].');
    expect(cards[1].prompt).toBe('Le sodium et le […] ; encore Na+.');
    expect(cards[0].answer).toBe('Le sodium et le potassium ; encore Na+.');
    expect(n.champs.texte).toContain('{{c1::sodium::ion}}');
  });

  it('retains the exact IDs of already expanded source cloze cards', () => {
    const n = note('cloze', 'cloze', { texte: '{{c1::A}} {{c2::B}}' });
    const cards = [{ id: 'cloze#c1', note_id: 'cloze', kind: 'cloze' }, { id: 'cloze#c2', note_id: 'cloze', kind: 'cloze' }];
    expect(engineVariants('sample', [n], cards).map(item => item.sourceCardId)).toEqual(['cloze#c1', 'cloze#c2']);
  });

  it('expands only requested image regions and keeps coordinates and source notes', () => {
    const n = note('zone', 'zone', { image: 'image.svg', question: 'Retrouve {label}.', zones: [{ cle: 'a', libelle: 'le foie', forme: 'poly', coords: [1, 2, 3, 4], note: 'Repère fourni.' }, { cle: 'b', libelle: 'le rein', forme: 'circle', coords: [20, 30, 10] }], demandees: ['b'] });
    const cards = engineCards(toEnginePack('sample', raw([n])));
    expect(cards).toHaveLength(1);
    expect(cards[0].prompt).toBe('Retrouve le rein.');
    expect(cards[0].zone).toMatchObject({ cle: 'b', forme: 'circle', coords: [20, 30, 10] });
    expect(cards[0].questionIllustration?.path).toBe('assets/packs/sample/media/image.svg');
  });

  it('makes one numbered label per card, preserving distractors and correction text', () => {
    const n = note('legend', 'legend', { titre: 'Planche', planche: 'labels.png', numeros: [{ numero: 2, legende: 'Foie', note: 'Correction du 2.' }, { numero: 7, legende: 'Rein' }], intrus: ['Rate'], explication: 'Texte commun.' });
    const cards = engineCards(toEnginePack('sample', raw([n])));
    expect(cards.map(item => item.legendNumber)).toEqual([2, 7]);
    expect([...cards[0].options].sort()).toEqual(['Foie', 'Rate', 'Rein']);
    expect(cards[0].options[cards[0].correct[0]]).toBe('Foie');
    expect(cards[1].options[cards[1].correct[0]]).toBe('Rein');
    expect(cards[0].explanation).toBe('Correction du 2.\n\nTexte commun.');
  });

  it('deduplicates repeated diagram labels so identical wording cannot be graded differently', () => {
    const n = note('repeated', 'legend', { planche: 'image.png', numeros: [{ numero: 1, legende: 'Muscle' }, { numero: 2, legende: 'Muscle' }], intrus: ['Nerf', 'Muscle'] });
    const cards = engineCards(toEnginePack('sample', raw([n])));
    for (const card of cards) { expect(card.options).toHaveLength(2); expect(card.options[card.correct[0]]).toBe('Muscle'); }
    expect(cards.map(card => card.options)).toEqual(engineCards(toEnginePack('sample', raw([n]))).map(card => card.options));
  });

  it('keeps QRM answer sets, indispensable and unacceptable choices, and official-key provenance distinct', () => {
    const n = { ...note('qrm', 'qrm', { enonce: 'Question', propositions: ['A', 'B', 'C'], vraies: ['A', 'C'], indispensables: ['C'], inacceptables: ['B'], justifications: ['J1', 'J2', 'J3'] }), cle_officielle: false, tags: ['annales', 'a-relire'], source: { source_id: 'source', session_examen: '2024 S1' }, source_secondaire: { source_id: 'cours' } };
    const card = engineCards(toEnginePack('sample', raw([n])))[0];
    expect(card).toMatchObject({ correct: [0, 2], required: [2], forbidden: [1], justifications: ['J1', 'J2', 'J3'], official: false, annale: true, secondarySource: { source_id: 'cours' } });
    expect(card.note).toEqual(n);
  });

  it('accepts the alternative QRU question/options/correct authoring convention', () => {
    const card = engineCards(toEnginePack('sample', raw([note('qru', 'qru', { question: 'Choisis', options: ['A', 'B', 'C'], correct: 'C' })])))[0];
    expect(card.prompt).toBe('Choisis'); expect(card.correct).toEqual([2]); expect(card.answer).toBe('C. C');
  });

  it('preserves lexicon roots and references without inventing quiz choices', () => {
    const n = note('lex', 'lexique', { terme: 'Érythème', definition: 'Définition donnée.', racines: [{ forme: 'éryth(r)-', sens: 'rouge' }], pages: [{ source_id: 'cours', page: 3 }] });
    const card = engineCards(toEnginePack('sample', raw([n])))[0];
    expect(card.prompt).toBe('Érythème'); expect(card.answer).toBe('Définition donnée.'); expect(card.fields).toEqual(n.champs); expect(card.options).toEqual([]);
    expect(engineAnnale({ ...n, cle_officielle: true })).toBe(false);
  });

  it('separates identical source note IDs in different packages and blocks path traversal', () => {
    const n = note('shared', 'basic', { recto: 'Q', verso: 'A' });
    expect(engineCards(toEnginePack('one', raw([n])))[0].id).not.toBe(engineCards(toEnginePack('two', raw([n])))[0].id);
    expect(engineAssetUrl('../private.json')).toBe(''); expect(engineAssetUrl('packs/a.json?secret=x')).toBe(''); expect(engineAssetUrl('https://example.org/a.json')).toBe('');
    expect(engineAssetUrl('assets/packs/one/media/schéma.svg')).toMatch(/engine\/assets\/packs\/one\/media\/sch%C3%A9ma\.svg$/);
  });
});

describe('complete imported MED_ENGINE programme', () => {
  it('includes every source pack and all eight note formats with independently counted variants', () => {
    const manifest = read('manifest.json') as EngineManifest;
    expect(manifest.packs).toHaveLength(141);
    const sourceNotes = new Set<string>();
    let notes = 0, stored = 0, variants = 0, annales = 0;
    for (const summary of manifest.packs) {
      const pack = toEnginePack(summary.id, read(summary.sourcePath), summary);
      const cards = engineCards(pack);
      expect(cards).toHaveLength(summary.cardCount);
      expect(new Set(cards.map(card => card.id)).size).toBe(cards.length);
      for (const n of pack.notes) sourceNotes.add(n.type);
      notes += pack.notes.length; stored += pack.cards.length; variants += cards.length; annales += cards.filter(card => card.annale).length;
    }
    expect([...sourceNotes].sort()).toEqual(['basic', 'cloze', 'legend', 'lexique', 'qrm', 'qroc', 'qru', 'zone']);
    expect({ notes, stored, variants, annales }).toEqual({ notes: manifest.audit.noteCount, stored: manifest.audit.sourceCardCount, variants: manifest.audit.cardCount, annales: manifest.audit.annaleCount });
    expect(manifest.audit.unknownTypes).toEqual([]);
  });

  it('marks source references with no supplied image as unavailable instead of requesting invented paths', () => {
    const manifest = read('manifest.json') as EngineManifest;
    expect(manifest.audit.missingAssets.length).toBeGreaterThan(0);
    expect(manifest.packs.reduce((count, pack) => count + pack.availableMedia.length, 0)).toBe(438);
    const summary = manifest.packs.find(pack => pack.id === manifest.audit.missingAssets[0].pack)!;
    const pack = toEnginePack(summary.id, read(summary.sourcePath), summary);
    const figures = engineCards(pack).flatMap(card => [card.illustration, card.questionIllustration, card.schemaIllustration]).filter(Boolean);
    expect(figures.some(figure => figure!.available === false)).toBe(true);
    for (const figure of figures) expect(figure!.available).toBe(existsSync(resolve(root, figure!.path)));
  });

  it('preserves all 752 supplied files byte for byte, including images, author notes and diagram pairs', () => {
    const provenance = read('provenance.json') as { inputSha256: Record<string, string> };
    expect(Object.keys(provenance.inputSha256)).toHaveLength(752);
    for (const [input, hash] of Object.entries(provenance.inputSha256)) {
      let output = '';
      if (input.startsWith('contenu/chapitres/')) {
        const [, , id, ...rest] = input.split('/');
        output = rest.join('/') === 'paquet.json' ? `packs/${id}.json` : `assets/packs/${id}/${rest.join('/')}`;
      } else if (input.startsWith('contenu/schemas_claude/')) output = input.replace('contenu/schemas_claude/', 'assets/diagrams/');
      else if (input.startsWith('contenu/squelettes/')) {
        const [, , id, filename] = input.split('/');
        output = `scaffolds/${id}.${filename === 'paquet.json' ? 'json' : 'md'}`;
      } else if (input.startsWith('med_engine/resources/')) output = input.replace('med_engine/', '');
      expect(output).not.toBe('');
      expect(createHash('sha256').update(readFileSync(resolve(root, output))).digest('hex')).toBe(hash);
    }
  });

  it('ships every declared file and retains byte-identical exportable source packages', () => {
    const manifest = read('manifest.json') as EngineManifest;
    const provenance = read('provenance.json') as { inputSha256: Record<string, string> };
    expect(new Set(manifest.files).size).toBe(manifest.files.length);
    for (const file of manifest.files) { expect(file).not.toContain('..'); expect(existsSync(resolve(root, file))).toBe(true); }
    for (const pack of manifest.packs) {
      const bytes = readFileSync(resolve(root, pack.sourcePath));
      expect(createHash('sha256').update(bytes).digest('hex')).toBe(provenance.inputSha256[`contenu/chapitres/${pack.id}/paquet.json`]);
    }
    expect(manifest.diagrams).toHaveLength(15);
    expect(manifest.scaffolds).toHaveLength(1);
  });
});
