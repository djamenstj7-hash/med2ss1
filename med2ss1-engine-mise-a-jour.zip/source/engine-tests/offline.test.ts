import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { engineOfflineUrls } from '../engine-src/lib/engine-offline';

describe('MED_ENGINE public offline boundaries', () => {
  const base = 'https://djamenstj7-hash.github.io/med2ss1/';

  it('resolves the complete supplied programme under this app, without touching Medora', () => {
    const manifest = JSON.parse(readFileSync(new URL('../engine/manifest.json', import.meta.url), 'utf8'));
    const urls = engineOfflineUrls(manifest.files, base);
    expect(urls).toHaveLength(755);
    expect(new Set(urls).size).toBe(755);
    expect(urls.every(url => url.startsWith(base + 'engine/'))).toBe(true);
    expect(urls.some(url => /\/medora\/|supabase|token|auth\//i.test(url))).toBe(false);
  });

  it('deduplicates the manifest and safely encodes accented public file names', () => {
    expect(engineOfflineUrls(['manifest.json', 'assets/schéma.svg', 'assets/schéma.svg'], base)).toEqual([
      base + 'engine/manifest.json', base + 'engine/assets/sch%C3%A9ma.svg',
    ]);
  });

  it.each(['../index.html', '/medora/index.html', 'https://example.org/a.json', 'packs/a.json?token=secret', 'a\\b.svg', 'packs/./a.json'])(
    'refuses a path outside the fixed public catalogue: %s', path => {
      expect(() => engineOfflineUrls([path], base)).toThrow();
    },
  );

  it('rejects an unbounded file list before starting a download', () => {
    expect(() => engineOfflineUrls(Array(10001).fill('packs/test.json'), base)).toThrow();
  });
});
