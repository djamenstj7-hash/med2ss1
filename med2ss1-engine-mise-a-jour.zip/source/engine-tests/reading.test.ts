import { describe, expect, it } from 'vitest';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { readFileSync, existsSync } from 'node:fs';
import { EngineReadingMarkdown } from '../engine-src/components/EngineReading';
import { engineExistingCourses, enginePdfCourseId, parseReadingMarkdown, readingInline, readingLink, readingReferences } from '../engine-src/lib/engine-reading';
import { toEnginePack, type EngineManifest } from '../engine-src/lib/engine';

const root = new URL('../', import.meta.url);
const read = (path: string) => JSON.parse(readFileSync(new URL(path, root), 'utf8'));

describe('MED_ENGINE reading uses the material actually supplied', () => {
  it('renders real guide structure, including tables and emphasis, without executing authored HTML', () => {
    const text = '# Mon guide\n\nUn **point important** et `un terme`.\n\n| Notion | Définition |\n|---|---|\n| A | Première |\n\n- Un point\n- Un autre\n\n<script>alert(1)</script>\n\n[externe](https://example.org/reference) [unsafe](javascript:alert(1))';
    const blocks = parseReadingMarkdown(text);
    expect(blocks.map(block => block.kind)).toEqual(['heading', 'paragraph', 'table', 'list', 'paragraph', 'paragraph']);
    const html = renderToStaticMarkup(createElement(EngineReadingMarkdown, { text }));
    expect(html).toContain('<table>'); expect(html).toContain('<strong>point important</strong>');
    expect(html).toContain('&lt;script&gt;'); expect(html).not.toContain('<script>');
    expect(html).not.toContain('href="javascript:'); expect(html).toContain('rel="noopener noreferrer"');
  });

  it('keeps Windows and missing PDF references as plain bibliographic text', () => {
    const manifest = read('engine/manifest.json') as EngineManifest;
    const summary = manifest.packs.find(pack => pack.id === 'semio_abord')!;
    const pack = toEnginePack(summary.id, read('engine/' + summary.sourcePath), summary);
    const references = readingReferences(pack);
    expect(references.length).toBeGreaterThan(0);
    expect(references.every(source => source.status === 'reference-only')).toBe(true);
    expect(references.some(source => source.path?.endsWith('.pdf'))).toBe(true);
    expect(readingLink(references.find(source => source.path)?.path || '')).toBeUndefined();
    expect(readingLink('file:///C:/cours.pdf')).toBeUndefined();
    expect(readingLink('https://user:password@example.org/secret')).toBeUndefined();
    expect(readingInline('[source](../../private.pdf)')[0]).toMatchObject({ kind: 'link', href: undefined });
  });

  it('exposes every one of the 139 supplied chapter guides without inventing extra course files', () => {
    const manifest = read('engine/manifest.json') as EngineManifest;
    const supplied = manifest.packs.filter(pack => pack.readmePath);
    expect(supplied).toHaveLength(139);
    for (const pack of supplied) {
      const path = new URL('engine/' + pack.readmePath, root);
      expect(existsSync(path)).toBe(true);
      expect(parseReadingMarkdown(readFileSync(path, 'utf8')).length).toBeGreaterThan(0);
    }
  });

  it('links only explicitly checked existing MED2 courses', () => {
    const catalogue = read('data/pedagogie.json');
    for (const value of Object.values(engineExistingCourses)) expect(catalogue.lessons[value.id].title).toBe(value.title);
    expect(engineExistingCourses.anat_fc2).toBeUndefined();
  });

  it('isolates chapter PDF attachments from historical course identifiers', () => {
    expect(enginePdfCourseId('semio_abord')).toBe('engine:semio_abord');
    expect(enginePdfCourseId('semio_abord')).not.toBe(engineExistingCourses.semio_abord.id);
    expect(() => enginePdfCourseId('../private')).toThrow();
  });
});
