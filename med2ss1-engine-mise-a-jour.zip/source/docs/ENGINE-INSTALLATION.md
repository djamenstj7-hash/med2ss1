# MED_ENGINE V0.50.1 dans MED2 S1 depuis ton iPhone

Cette livraison complète **le site MED2 S1 existant**, à l’adresse **https://djamenstj7-hash.github.io/med2ss1/**. Elle conserve son interface et ses 85 cours, ses exercices, ses fiches PDF, son calendrier et sa progression. Medora reste une autre application, à son adresse habituelle `/medora/`.

La rubrique MED_ENGINE apporte les 141 banques d’exercices dans 13 UE déjà importées dans Medora : 15 592 notes et 25 753 variantes de travail, les QRM, QRU, QROC, rappels actifs, textes à trous, lexique, repérages et planches à légender.

Le correctif V0.50.1 ouvre chaque banque sur **Lire**, avec les cours Drive retrouvés, son guide, ses fiches et corrections et l’import d’un PDF personnel. **S’entraîner** conserve les exercices ; **Schémas** donne un accès direct aux illustrations disponibles et à leurs exercices. La galerie comprend les 438 images fournies dans 13 banques, dont 70 planches dans `anat_sch1`. Les 15 schémas HTML comprennent cinq documents avec commandes interactives et dix documents statiques ; leur affichage peut être agrandi.

La rubrique **Cours du Drive**, disponible dans la bibliothèque MED_ENGINE et dans **Lire**, donne accès à **123 documents : 116 PDF et sept documents d’errata**. Les noms de fichiers ont permis de retrouver 97 références sources dans 61 banques, correspondant à 81 PDF distincts. Ces correspondances reposent sur les noms d’origine normalisés, sans association approximative. Tous les autres documents restent consultables dans le catalogue par UE ; leur présence dans la même UE ne prouve pas qu’ils sont la source d’un chapitre précis.

Les boutons **Lire sur Drive** ouvrent le document en ligne dans un nouvel onglet. Une connexion est nécessaire ; Drive peut demander le compte Google autorisé à consulter le dossier. Les documents sont ceux du dossier fourni : **https://drive.google.com/drive/folders/118IjkuUetWqWG9GupWsJmBi30FSanMBR**. Ils ne sont pas copiés dans les ZIP ni téléchargés automatiquement pour le hors connexion. Pour conserver un PDF sur l’iPhone, enregistre-le dans Fichiers, puis importe-le dans **Mes PDF** du chapitre.

Ce module ne reproduit pas encore toutes les fonctions Windows. Les guides et corrections ne sont pas les ronéos PDF complets. Windows lit ses PDF depuis un dossier personnel séparé, choisi dans ses réglages ; les distributions du programme seules ne contenaient pas ces documents. Le dossier de cours partagé ensuite permet maintenant d’en ouvrir 116 en ligne. Les références sans correspondance restent signalées et les autres éditions ou annales ne sont pas assimilées à ces fichiers. La comparaison des fonctions est fournie dans `COMPARAISON-WINDOWS-MOBILE.md`.

**Aucun projet Supabase, jeton, clé API ni crédit IA n’est nécessaire pour cette installation.** Les contenus préécrits et les révisions espacées de ce module sont exécutés sur l’appareil. Cette livraison n’ajoute pas les fonctions IA de Medora à MED2 S1.

## 1. Sauvegarder les deux progressions

Dans MED2 S1, ouvre **Réglages → Mes données → Exporter** et conserve la sauvegarde JSON dans Fichiers. Conserve également les PDF originaux : les PDF importés sont enregistrés sur l’appareil et ne sont pas inclus dans cette sauvegarde JSON.

Le module MED_ENGINE dispose de sa propre sauvegarde. Après son installation, son écran de sauvegarde permet d’exporter son suivi et ses révisions espacées. Il ne remplace ni n’importe automatiquement les résultats de Medora ou de l’ancienne application Windows.

## 2. Télécharger les fichiers de cette livraison

### Si MED_ENGINE V0.50 fonctionne déjà sur ton site

Enregistre uniquement le nouveau **`med2ss1-engine-mise-a-jour.zip`** et **`installation-med-engine-iphone.txt`**. Remplace ces deux éléments dans GitHub selon les étapes 3 et 4, puis relance le workflow. **Garde les deux ZIP de contenus déjà présents dans ton dépôt : ils sont identiques et n’ont pas besoin d’être renvoyés.** Le workflow vérifie leurs empreintes avant la publication.

### Pour une première installation

Enregistre dans Fichiers les **trois ZIP**, sans les décompresser :

- `med2ss1-engine-mise-a-jour.zip` ;
- `med2ss1-engine-contenus-1.zip` ;
- `med2ss1-engine-contenus-2.zip`.

Télécharge aussi **`installation-med-engine-iphone.txt`**, le texte du workflow à copier. Utilise le ZIP principal et le workflow de cette livraison V0.50.1. Les deux ZIP de contenus V0.50 sont réutilisés sans modification. Chaque ZIP fait moins de 24 Mo pour faciliter l’envoi depuis Safari.

Garde leurs noms exacts. Si l’iPhone ajoute « (1) », « 2 » ou un autre suffixe, renomme le fichier dans Fichiers.

## 3. Créer le workflow dans le bon dépôt

1. Ouvre **https://github.com/djamenstj7-hash/med2ss1** dans Safari, branche **main**.
2. Dans **Code**, choisis **Add file → Create new file**.
3. Dans le nom du fichier, saisis exactement **`.github/workflows/installation-med-engine.yml`**. Les barres obliques créent les dossiers.
4. Ouvre `installation-med-engine-iphone.txt`, copie tout son texte puis colle-le dans l’éditeur GitHub. Il s’agit du texte complet, sans balises Markdown.
5. Touche **Commit changes**, directement sur **main**.

Si ce fichier existe déjà, ouvre-le et utilise le crayon pour remplacer tout son contenu. Cette livraison ne modifie pas le workflow de Medora.

Si Safari masque une commande, ouvre son menu de page et choisis **Version pour ordinateur**, puis dézoome avec deux doigts.

## 4. Envoyer les ZIP, un par un

1. Reviens à la racine du dépôt **med2ss1**, dans **Code → main**.
2. Choisis **Add file → Upload files** et sélectionne **uniquement** `med2ss1-engine-mise-a-jour.zip`.
3. Attends la fin du chargement puis touche **Commit changes**, sur **main**.
4. **Pour la mise à jour V0.50 → V0.50.1, arrête-toi ici : conserve les deux ZIP de contenus actuels.** Passe à la rubrique 5 ci-dessous.
5. Pour une première installation, recommence avec **uniquement** `med2ss1-engine-contenus-1.zip`, puis valide son commit.
6. Recommence avec **uniquement** `med2ss1-engine-contenus-2.zip`, puis valide son commit.

Les trois ZIP doivent apparaître à la racine, dont les deux ZIP de contenus conservés si tu fais la mise à jour. Ils ne remplacent pas les dossiers `data` et `Assets` ni tes fichiers PDF locaux. Une mise à jour du module peut réutiliser ces deux parties si le guide de livraison le précise.

## 5. Choisir GitHub Actions pour publier ce site

Dans **le dépôt med2ss1**, ouvre **Settings → Pages → Build and deployment → Source**, puis sélectionne **GitHub Actions**.

Cette sélection concerne seulement le mode de publication de MED2 S1. Le contenu du dépôt reste présent. Le nouveau workflow assemble les cours actuels du dépôt avec le module, puis publie cet ensemble.

## 6. Lancer l’installation

1. Ouvre **Actions**, éventuellement dans **More**.
2. Sélectionne **Installer MED_ENGINE dans MED2 S1**. Si tu es sur « All workflows », sélectionne ce nom avec le menu **Workflow** ou ouvre la page du workflow.
3. Touche **Run workflow**, choisis **main**, puis confirme avec le second **Run workflow**.
4. Attends la coche verte finale avant de vérifier le site.

Il n’y a **aucune case Supabase** pour cette installation. Le script vérifie les empreintes et les ZIP avant de publier. Si un fichier manque ou appartient à une autre livraison, le message nomme le fichier à remplacer. Si l’interface du dépôt a été modifiée depuis la préparation de ce paquet, l’installation s’arrête pour préserver cette nouvelle interface ; il faut alors un paquet réadapté.

## 7. Ouvrir la nouvelle rubrique sur iPhone

Ouvre **https://djamenstj7-hash.github.io/med2ss1/** dans Safari, connecté à Internet. Actualise la page ou ferme puis rouvre l’application si tu vois encore l’ancienne version.

Dans la bibliothèque, ouvre la nouvelle entrée **MED_ENGINE**. Vérifie également un cours MED2 existant, tes résultats et une fiche PDF importée. L’interface habituelle reste disponible en quittant la rubrique MED_ENGINE.

Ouvre **Cours du Drive** pour rechercher parmi les 123 documents, filtrer par UE ou par type d’enseignement, puis toucher **Lire sur Drive**. Dans une banque, **Lire** affiche les liens de documents retrouvés et les onglets **Cours du Drive**, **Guide du chapitre**, **Fiches et corrections**, **Mes PDF** et **Documents cités**. **S’entraîner** ouvre les questions ; **Schémas** affiche ses images disponibles.

Dans **Mes PDF**, tu peux importer un PDF que tu possèdes pour le lire sur cet appareil, y compris un cours préalablement enregistré depuis Drive dans Fichiers. Ce PDF personnel reste dans le stockage du site et n’est pas envoyé dans le dépôt public GitHub. Le lien vers la bibliothèque MED2 S1 permet de retrouver les 85 cours existants ; seuls les chapitres dont la correspondance a été vérifiée proposent un raccourci direct vers leur cours.

Pour l’installation sur l’écran d’accueil : dans Safari, touche **Partager → Sur l’écran d’accueil**. Les icônes MED2 S1 et Medora peuvent coexister.

## 8. Préparer le hors connexion

Dans le module MED_ENGINE, utilise le bouton de téléchargement hors connexion et garde l’application ouverte jusqu’à la fin. Le téléchargement des contenus MED2 S1 habituels reste disponible séparément dans **Réglages → Installation et hors ligne**.

Les 752 fichiers de contenu fournis sont conservés et vérifiés, dont 438 images PNG/SVG. Les données sources citent aussi **8 699 références de figures absentes** du dossier reçu. Elles sont signalées comme absentes ; les exercices qui exigent ces images ne produisent pas de fausse notation. Les 82 variantes signalées comme non vérifiées gardent leur mention. **Les 123 documents du catalogue Drive ne font pas partie de ce téléchargement hors connexion.** Les PDF que tu importes toi-même dans **Mes PDF** sont conservés séparément sur cet appareil.

Les résultats restent sur cet appareil. Une navigation privée, un effacement des données du site ou une éviction du stockage peut faire perdre des données locales ; conserve les sauvegardes JSON et les PDF originaux. Les révisions FSRS de MED_ENGINE sont distinctes des rappels déjà présents dans MED2 S1.

## 9. Mettre ensuite les cours du site à jour

Les cours et les images continuent de provenir des dossiers **`data` et `Assets` du dépôt**. Tu peux y ajouter ou remplacer du contenu comme avant. Avec **Pages → GitHub Actions**, relance ensuite **Installer MED_ENGINE dans MED2 S1** pour publier ces modifications avec le module conservé.

La livraison inclut les sources du module pour relecture et adaptation. Elle ne pousse aucun fichier décompressé dans ton dépôt : le workflow assemble une copie temporaire pour la publication. Les mises à jour de l’interface `index.html` ou de `service-worker.js` demandent une nouvelle préparation du paquet afin de conserver leurs changements.
