# Ajouter MED_ENGINE à MED2 S1 depuis ton iPhone

Cette livraison complète **le site MED2 S1 existant**, à l’adresse **https://djamenstj7-hash.github.io/med2ss1/**. Elle conserve son interface et ses 85 cours, ses exercices, ses fiches PDF, son calendrier et sa progression. Medora reste une autre application, à son adresse habituelle `/medora/`.

La rubrique MED_ENGINE apporte les 141 chapitres dans 13 UE déjà importés dans Medora : 15 592 notes et 25 753 variantes de travail, les QRM, QRU, QROC, rappels actifs, textes à trous, lexique, repérages et planches à légender. Les 15 schémas HTML fournis et leurs explications sont présents.

**Aucun projet Supabase, jeton, clé API ni crédit IA n’est nécessaire pour cette installation.** Les contenus préécrits et les révisions espacées de ce module sont exécutés sur l’appareil. Cette livraison n’ajoute pas les fonctions IA de Medora à MED2 S1.

## 1. Sauvegarder les deux progressions

Dans MED2 S1, ouvre **Réglages → Mes données → Exporter** et conserve la sauvegarde JSON dans Fichiers. Conserve également les PDF originaux : les PDF importés sont enregistrés sur l’appareil et ne sont pas inclus dans cette sauvegarde JSON.

Le module MED_ENGINE dispose de sa propre sauvegarde. Après son installation, son écran de sauvegarde permet d’exporter son suivi et ses révisions espacées. Il ne remplace ni n’importe automatiquement les résultats de Medora ou de l’ancienne application Windows.

## 2. Télécharger les fichiers de cette livraison

Enregistre dans Fichiers les **trois ZIP**, sans les décompresser :

- `med2ss1-engine-mise-a-jour.zip` ;
- `med2ss1-engine-contenus-1.zip` ;
- `med2ss1-engine-contenus-2.zip`.

Télécharge aussi **`installation-med-engine-iphone.txt`**, le texte du workflow à copier. Tous ces fichiers doivent provenir de la même livraison. Chaque ZIP fait moins de 24 Mo pour faciliter l’envoi depuis Safari.

Garde leurs noms exacts. Si l’iPhone ajoute « (1) », « 2 » ou un autre suffixe, renomme le fichier dans Fichiers.

## 3. Créer le workflow dans le bon dépôt

1. Ouvre **https://github.com/djamenstj7-hash/med2ss1** dans Safari, branche **main**.
2. Dans **Code**, choisis **Add file → Create new file**.
3. Dans le nom du fichier, saisis exactement **`.github/workflows/installation-med-engine.yml`**. Les barres obliques créent les dossiers.
4. Ouvre `installation-med-engine-iphone.txt`, copie tout son texte puis colle-le dans l’éditeur GitHub. Il s’agit du texte complet, sans balises Markdown.
5. Touche **Commit changes**, directement sur **main**.

Si ce fichier existe déjà, ouvre-le et utilise le crayon pour remplacer tout son contenu. Cette livraison ne modifie pas le workflow de Medora.

Si Safari masque une commande, ouvre son menu de page et choisis **Version pour ordinateur**, puis dézoome avec deux doigts.

## 4. Envoyer les ZIP, un par un

1. Reviens à la racine du dépôt **med2ss1**, dans **Code → main**.
2. Choisis **Add file → Upload files** et sélectionne **uniquement** `med2ss1-engine-mise-a-jour.zip`.
3. Attends la fin du chargement puis touche **Commit changes**, sur **main**.
4. Recommence avec **uniquement** `med2ss1-engine-contenus-1.zip`, puis valide son commit.
5. Recommence avec **uniquement** `med2ss1-engine-contenus-2.zip`, puis valide son commit.

Les trois ZIP doivent apparaître à la racine. Ils ne remplacent pas les dossiers `data` et `Assets` ni tes fichiers PDF locaux. Lors d’une future mise à jour du module, remplace les trois ZIP et le texte du workflow par ceux de la nouvelle livraison.

## 5. Choisir GitHub Actions pour publier ce site

Dans **le dépôt med2ss1**, ouvre **Settings → Pages → Build and deployment → Source**, puis sélectionne **GitHub Actions**.

Cette sélection concerne seulement le mode de publication de MED2 S1. Le contenu du dépôt reste présent. Le nouveau workflow assemble les cours actuels du dépôt avec le module, puis publie cet ensemble.

## 6. Lancer l’installation

1. Ouvre **Actions**, éventuellement dans **More**.
2. Sélectionne **Installer MED_ENGINE dans MED2 S1**. Si tu es sur « All workflows », sélectionne ce nom avec le menu **Workflow** ou ouvre la page du workflow.
3. Touche **Run workflow**, choisis **main**, puis confirme avec le second **Run workflow**.
4. Attends la coche verte finale avant de vérifier le site.

Il n’y a **aucune case Supabase** pour cette installation. Le script vérifie les empreintes et les ZIP avant de publier. Si un fichier manque ou appartient à une autre livraison, le message nomme le fichier à remplacer. Si l’interface du dépôt a été modifiée depuis la préparation de ce paquet, l’installation s’arrête pour préserver cette nouvelle interface ; il faut alors un paquet réadapté.

## 7. Ouvrir la nouvelle rubrique sur iPhone

Ouvre **https://djamenstj7-hash.github.io/med2ss1/** dans Safari, connecté à Internet. Actualise la page ou ferme puis rouvre l’application si tu vois encore l’ancienne version.

Dans la bibliothèque, ouvre la nouvelle entrée **MED_ENGINE**. Vérifie également un cours MED2 existant, tes résultats et une fiche PDF importée. L’interface habituelle reste disponible en quittant la rubrique MED_ENGINE.

Pour l’installation sur l’écran d’accueil : dans Safari, touche **Partager → Sur l’écran d’accueil**. Les icônes MED2 S1 et Medora peuvent coexister.

## 8. Préparer le hors connexion

Dans le module MED_ENGINE, utilise le bouton de téléchargement hors connexion et garde l’application ouverte jusqu’à la fin. Le téléchargement des contenus MED2 S1 habituels reste disponible séparément dans **Réglages → Installation et hors ligne**.

Les 752 fichiers de contenu fournis sont conservés et vérifiés, dont 438 images PNG/SVG. Les données sources citent aussi **8 699 références de figures absentes** du dossier reçu. Elles sont signalées comme absentes ; les exercices qui exigent ces images ne produisent pas de fausse notation. Les 82 variantes signalées comme non vérifiées gardent leur mention. Les documents externes cités ne sont pas téléchargés automatiquement.

Les résultats restent sur cet appareil. Une navigation privée, un effacement des données du site ou une éviction du stockage peut faire perdre des données locales ; conserve les sauvegardes JSON et les PDF originaux. Les révisions FSRS de MED_ENGINE sont distinctes des rappels déjà présents dans MED2 S1.

## 9. Mettre ensuite les cours du site à jour

Les cours et les images continuent de provenir des dossiers **`data` et `Assets` du dépôt**. Tu peux y ajouter ou remplacer du contenu comme avant. Avec **Pages → GitHub Actions**, relance ensuite **Installer MED_ENGINE dans MED2 S1** pour publier ces modifications avec le module conservé.

La livraison inclut les sources du module pour relecture et adaptation. Elle ne pousse aucun fichier décompressé dans ton dépôt : le workflow assemble une copie temporaire pour la publication. Les mises à jour de l’interface `index.html` ou de `service-worker.js` demandent une nouvelle préparation du paquet afin de conserver leurs changements.
