# Vérification de MED_ENGINE dans MED2 S1 — V0.50

Cette livraison ajoute une rubrique au site existant. Elle n'installe pas une seconde copie de Medora et ne publie aucune modification sur GitHub ou Supabase pendant sa préparation.

## Résultats exécutés

- TypeScript et construction du module précompilé : réussis.
- 53 tests JavaScript : réussis. Ils couvrent les paquets, les huit formats, l'isolation du stockage, les imports atomiques, FSRS, l'idempotence et la préservation du site d'origine. La sauvegarde de la banque complète (141 paquets et 23 280 cartes éligibles, plus un historique) a été exportée puis réimportée sans perte au-delà de l'ancienne limite de 25 Mio.
- 10 tests Python de livraison : réussis. Ils vérifient les empreintes, les ZIP incomplets/corrompus, les chemins, les collisions et les gardes de compatibilité de l'interface.
- 18 parcours navigateur fonctionnels : réussis. Ils incluent les cours et QCM existants, le lecteur PDF et sa fermeture plein écran, les huit formats MED_ENGINE, les sources, les notes, les favoris, les annales, les simulations, FSRS et les sauvegardes. Une écriture IndexedDB volontairement retardée vérifie que la note modifiée pendant l'enregistrement reste sauvegardée à la sortie.
- Six vues contrôlées avec axe : aucune violation détectée.
- 10 parcours navigateur hors connexion : réussis. Les 755 fichiers MED_ENGINE sont présents dans leur cache, avec zéro fichier manquant et zéro ressource privée ou étrangère.
- Les 246 fichiers historiques protégés sont identiques octet pour octet. Les 85 cours et leurs 594 chapitres restent présents. Le lecteur PDF, les illustrations et les clés de progression historiques sont conservés.
- Les formats 320, 390 et 430 pixels, le paysage et le thème sombre ont été contrôlés. Aucun débordement horizontal, exception JavaScript, échec HTTP ou appel API privé observé pendant les parcours finaux.

Les rapports détaillés sont fournis dans `ENGINE-VERIFICATION-NAVIGATEUR.json` et `ENGINE-VERIFICATION-HORS-LIGNE.json`. Les scripts et les empreintes historiques sont inclus dans les sources de la livraison.

## Limites des vérifications et du contenu

Les parcours ont été exécutés sur Chromium avec simulation mobile, pas sur un iPhone physique ni sur Safari iOS réel. La disponibilité du stockage hors connexion dépend également de l'espace et des règles de conservation de Safari sur l'appareil.

Les 752 fichiers de la source MED_ENGINE ont été conservés avec leurs empreintes, dont 438 images PNG/SVG. Les références de figures absentes restent signalées ; elles ne sont pas remplacées par des images inventées. Les exercices de repérage impossibles ne produisent aucun résultat de réussite ou d'échec et sont exclus des nouveaux decks FSRS. Les corrections officielles, déduites et non vérifiées restent distinguées. L'adaptation technique ne constitue pas une nouvelle validation médicale des cours.

La progression MED_ENGINE est propre à ce site et à cet appareil. Elle ne synchronise pas automatiquement les données de Medora, de l'ancien programme Windows ou des autres appareils. La sauvegarde MED_ENGINE contient son suivi et ses révisions ; les sauvegardes JSON ne contiennent pas les PDF personnels de MED2 S1.

## Publication

La préparation a été réalisée depuis le snapshot public `e1ed06444503ae453b67a261cfb058a68d93987e`. L'assembleur refuse de remplacer une interface historique devenue incompatible, tout en conservant les cours et ressources du dépôt au moment du déploiement.

Les ZIP sont vérifiés puis assemblés avec le même script que celui du workflow. Le guide explique la publication manuelle dans le dépôt `djamenstj7-hash/med2ss1` ; aucun secret Supabase ni crédit IA n'est nécessaire pour ces contenus préécrits.
