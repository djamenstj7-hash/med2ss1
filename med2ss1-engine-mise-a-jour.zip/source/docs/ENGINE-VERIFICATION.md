# Vérification MED2 S1 — correctif MED_ENGINE V0.50.1

Vérification du 28 octobre 2026. Le correctif conserve l’application MED2 S1 existante et ajoute des accès aux contenus MED_ENGINE. Aucun déploiement GitHub ni modification Supabase n’a été effectué pendant sa préparation.

## Résultats exécutés

- TypeScript et compilation de production : réussis.
- 70 tests JavaScript et 10 tests Python de livraison : réussis. Ils couvrent notamment les huit formats, le contenu original, le stockage isolé, FSRS, les sauvegardes atomiques, les guides, la galerie et les correspondances documentaires.
- 18 parcours fonctionnels : réussis, dont les cours/QCM/PDF existants, les huit formats d’exercices, les notes et favoris, les annales/simulations, FSRS et les sauvegardes.
- 12 parcours d’accès aux contenus : réussis. Lecture structurée, lecture libre sans notation, sources correctement signalées, ouverture des cours existants, import PDF par chapitre et conservation après rechargement, catalogue Drive de 123 documents, trois parties de pharmacodynamie, galerie de 438 images, 70 planches d’anatomie, exercices lancés dans la bonne banque, 15 supports dont cinq réellement interactifs, agrandissement et fermeture.
- 12 parcours hors connexion : réussis. Les 755 fichiers MED_ENGINE sont en cache, avec zéro fichier manquant et zéro ressource privée/étrangère. Guides, galerie et PDF importé restent lisibles après rechargement hors connexion. Le catalogue Drive conserve ses métadonnées et signale que les documents distants nécessitent Internet.
- Neuf vues contrôlées avec axe : aucune violation détectée.
- Les 246 fichiers historiques protégés restent identiques octet pour octet : 85 cours, 594 chapitres, ressources et lecteur PDF existants conservés.
- Largeurs 320/390/430 pixels, paysage et thème sombre contrôlés ; pas de débordement horizontal ni exception JavaScript observés dans les parcours finaux.

Les rapports détaillés et scripts sont inclus dans les sources du ZIP. Les deux ZIP de contenus sont inchangés ; seul le ZIP principal et son workflow doivent être remplacés pour une installation V0.50 existante.

## Sources documentaires et limites

Le dossier Drive S1 a été inventorié : 123 documents dont 116 PDF (230049005 octets). Parmi les références de sources des banques, 97 correspondent exactement par leur nom à 81 PDF distincts dans 61 banques ; aucun rapprochement approximatif n’est présenté comme une source exacte. Les noms et liens observés sont conservés. Un PDF de pharmacodynamie générale partie 1 a été téléchargé et lu : PDF valide de six pages, ronéo 2026-2027, professeur Bordet. Les 115 autres PDF n’ont pas fait l’objet d’une comparaison binaire de leur contenu.

Les liens Drive ouvrent un nouvel onglet et utilisent les droits d’accès existants. Les tests vérifient le catalogue, les liens et leur association ; ils ne prouvent pas que tous les fichiers s’ouvrent dans Safari connecté au compte de l’utilisateur. Les 230 Mo de PDF ne sont pas embarqués dans les ZIP et ne sont pas téléchargés automatiquement. Pour les lire intégralement hors connexion, l’utilisateur doit les enregistrer dans Fichiers puis les importer dans Mes PDF.

Les parcours ont été exécutés sur Chromium avec simulation mobile, pas sur un iPhone physique ni Safari iOS réel. La conservation locale dépend de l’espace et des règles de Safari. Les sauvegardes JSON n’incluent pas les PDF personnels.

La comparaison détaillée avec Windows figure dans COMPARAISON-WINDOWS-MOBILE.md. Le correctif ne porte pas encore toutes les fonctions Windows : historique de lecture, lexique d’UE et pages, planches complètes, échelle, barème, journal/annulation, XP et exports ZIP/APKG. Les figures absentes ne sont pas inventées et les exercices impossibles restent non notés. L’adaptation technique ne constitue pas une validation médicale nouvelle des cours.
