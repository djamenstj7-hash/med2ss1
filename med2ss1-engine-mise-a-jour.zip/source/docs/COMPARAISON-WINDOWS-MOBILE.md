# MED_ENGINE Windows V2.34 et MED2 S1 mobile V0.50

Comparaison du 28 octobre 2026. Elle porte sur **la livraison V0.50 réellement fournie**, et non sur les correctifs encore en préparation dans le dossier de travail.

La version mobile fournie est une adaptation partielle des contenus et des exercices MED_ENGINE. Elle ne reproduit pas toutes les fonctions de l'application Windows. L'absence de lecture des ronéos n'est donc pas due à une erreur de manipulation sur l'iPhone.

## Périmètre vérifié

- Windows : distribution « MED_ENGINE_full_v2.34 27 10 2026 » dans le [dossier fourni](https://drive.google.com/drive/folders/19gMoAC7eJPwxv3xedxjjcgm0b8RNI12y), les deux notices, les ressources livrées et les modules embarqués dans l'exécutable. L'exécutable et le fichier BAT n'ont **jamais été exécutés** : les archives et les objets de code Python ont été lus statiquement.
- Mobile : sources de l'archive livrée `med2ss1-engine-mise-a-jour.zip`, SHA-256 `ce154553e175ffe53fb718e19e7197dd0ddaa7c3db186401ec3f7c8b7218668e`, ainsi que le manifeste des contenus. La version publique a été contrôlée séparément : les fichiers principaux sont bien ceux de cette livraison.
- Capture de l'utilisateur : tableau BMCT V2.34 avec Lecture P1/P2/P3, Simple/Moyen/Annales, Épreuve, Entretien, Lexique et Schémas, export ZIP/APKG, journal et XP.
- [Dossier des cours S1 fourni](https://drive.google.com/drive/folders/118IjkuUetWqWG9GupWsJmBi30FSanMBR) : inventaire vérifié de 123 fichiers, dont **116 PDF totalisant 230 049 005 octets**, dans les branches CM/ED. Les trois parties de pharmacodynamie générale figurent notamment dans BMCT. Ces PDF existent donc désormais parmi les sources disponibles pour la correction mobile. L'inventaire détaillé est conservé dans `docs/source-pdf-inventory.json`.

## Pourquoi le bouton Lire fonctionne sous Windows

Le code Windows distingue deux emplacements externes à la distribution :

1. `course_root` : la racine d'archive des cours/Ronéosaure, parcourue en lecture seule ;
2. `documents_root` : le **Dossier des PDF de cours** réglé sur le PC, dont les fichiers sont ouverts par les chapitres. S'il est vide, l'emplacement par défaut est `cours` à côté de la base personnelle.

Les paquets de questions portent le nom et le chemin du document dans `source_documents`. Windows cherche ce chemin dans le dossier réglé sur le PC et ouvre le PDF seulement s'il existe. Les noms Unicode décomposés et la casse sont pris en compte. Le lecteur utilise une route locale `/cours/…`, avec une page précise lorsque le lexique renvoie au cours.

**Ces chemins ne transportent pas les fichiers PDF.** GitHub Pages et Safari ne peuvent pas lire un dossier `C:\…`, `D:\…` ou `%LOCALAPPDATA%` du PC. Les 116 PDF maintenant repérés dans le dossier S1 permettent de préparer leur association aux chapitres. Le correctif V0.50.1 en préparation prévoit un accès en ligne aux PDF sources sur Drive et un import privé sur le téléphone ; cette préparation n'est pas une fonction déjà présente dans la V0.50 publiée.

Preuves : modules Windows `med_engine.config` (`documents_dir`, `resolve_document`, `servable_document`) ; `med_engine.ui.pages.content` (`Lecteur`, `_boutons_cours`, `_ligne`) ; `med_engine.ui.pages.misc.render_settings` (« Dossier des PDF de cours »). La notice Windows confirme que la base et les médias personnels vivent hors du dossier de l'application.

## Fonctions présentes, partielles et absentes

| Fonction Windows | Livraison mobile V0.50 | Écart constaté |
|---|---|---|
| Bibliothèque de chapitres par UE | **Présente pour les contenus importés** | 141 banques, 13 UE ; l'ensemble de la bibliothèque personnelle Windows n'est pas transféré. Les 85 cours MED2 S1 d'origine restent distincts et conservés. |
| Lecture des ronéos, parties P1/P2/P3 | **Absente dans MED_ENGINE** | Les sources sont affichées comme références textuelles ; aucun lecteur des documents `source_documents` n'est connecté à ces chapitres. Le lecteur PDF de l'ancien MED2 S1 existe encore, séparément. |
| Historique « J'ai lu », dates et nombre de lectures | **Absent pour les chapitres MED_ENGINE** | Le suivi des exercices n'enregistre pas une lecture de ronéo. Les marqueurs de lecture des 85 cours d'origine ne couvrent pas les 141 banques. |
| Guides du chapitre | **Partiels** | Les guides fournis sont accessibles, mais sous forme de Markdown brut dans un bloc de texte. Ils sont des notices pédagogiques, pas les ronéos complets. |
| Lexique d'UE, racines et renvois aux pages | **Partiel** | Le type de carte « lexique » est disponible par filtre ; la vue regroupée d'UE, le tri des termes et les liens vers une page de cours ne sont pas portés. |
| Schémas majeurs d'UE | **Partiel** | Les 15 documents HTML « Comprendre » existent. Leur regroupement par UE et leur accès ne reprennent pas le tableau Windows. Cinq de ces HTML contiennent des scripts ; dix sont statiques. |
| Images et planches, consultation directe | **Partiel / difficile à trouver** | 438 SVG/PNG livrés sont accessibles surtout via les cartes ; aucune galerie générale n'est prévue dans la livraison V0.50. |
| Repérages de zones | **Présents si le média existe** | Interaction disponible ; les cartes nécessitant une image absente sont signalées et exclues de la notation. |
| Planche complète à légender | **Partielle** | Le mobile dérive des questions par numéro/légende ; il ne reproduit pas la réponse à toute la planche et sa moyenne par numéro dans une seule carte Windows. |
| Échelle Simple → Moyen → Annales | **Partielle** | Des filtres de niveau et d'annales existent. Le parcours par thème, les marches acquises/à reprendre et les jauges du tableau Windows ne sont pas reproduits. |
| Bachotage et annales | **Présents** | Séances de pratique avec correction et sauvegarde ; elles ne déplacent pas les échéances FSRS. Le mobile ne reproduit pas tout le périmètre multi-chapitres/UE Windows. |
| Sujets d'annales par année/session, ordre du fascicule | **Partiels** | Provenance des questions conservée, filtre annales disponible. L'écran Windows qui recompose un sujet entier par année/session n'est pas porté. |
| Épreuve blanche | **Présente, simplifiée** | Chronomètre, pause/reprise, réponses enregistrées et correction finale ; organisation des sujets et barème Windows non identiques. |
| Barème médical QRM et note de maîtrise | **Différent** | Windows attribue 1 / 0,5 / 0,2 / 0 selon les discordances et applique les drapeaux indispensables/inacceptables. V0.50 enregistre une réussite booléenne sur l'ensemble exact des réponses, puis affiche un nombre de réponses réussies. Ce résultat n'est pas la note Windows sur vingt. |
| Révisions espacées FSRS | **Présentes, différentes** | FSRS local sur iPhone après installation/activation du deck. Ce n'est pas le même moteur/configurateur que Windows ; les dates personnelles et l'historique Windows ne sont pas importés. |
| Dates d'examen et planification | **Partielles** | Une date personnelle par matière peut être enregistrée. Le planificateur local V0.50 ne l'applique pas à ses intervalles comme le fait Windows. |
| Notes personnelles / commentaires | **Présents en partie** | Note libre par banque et favoris ; la colonne Windows avec date du commentaire et tous les récapitulatifs de travail n'est pas reproduite. |
| Consulter / recherche dans toutes les notes | **Partiel** | Recherche de banques, filtres, liste des questions d'une banque ; pas de recherche plein texte globale dans toutes les cartes comparable à Windows. |
| Journal détaillé, annuler une réponse et rejouer FSRS | **Partiel** | Suivi des tentatives/séances et logs FSRS sauvegardés. Pas de journal Windows complet avec annulation/rejeu d'une révision ou d'une séance. |
| XP, rangs, séries | **Absents pour MED_ENGINE** | La progression propre à Windows n'est ni migrée ni recalculée dans le module mobile livré. |
| Créer/modifier des cartes | **Absent** | Consultation et pratique des banques livrées ; pas d'éditeur de contenu MED_ENGINE Windows. |
| Importer/mettre à jour un paquet de chapitre ZIP/JSON | **Absent dans l'interface du module** | L'import d'une sauvegarde de progression mobile existe, mais ne remplace pas l'import de contenus Windows. |
| Exporter un chapitre/une UE en ZIP et Anki APKG | **Absent** | La sauvegarde JSON mobile ne contient pas ces paquets de contenus. Windows signale lui-même que repérages et planches ne se transposent pas dans Anki. |
| Fusionner les bibliothèques Windows | **Absent** | La sauvegarde JSON mobile et ses fusions ne lisent pas la base SQLite Windows, ses lectures ou son XP. |
| Réglages avancés | **Partiels** | Les réglages Windows de quota de nouvelles/dues, frontière de journée, rétention, rappel de pause et dossiers ne sont pas tous exposés dans le module mobile. |
| Manuel Windows | **Absent** | Les notices des banques sont conservées ; le manuel applicatif de Windows n'est pas repris. |
| Mode hors connexion | **Présent après téléchargement** | Téléchargement explicite des fichiers publics du module. Les PDF personnels du PC ne peuvent pas y apparaître sans import. |

Les mots « absent » ci-dessus désignent une fonction du **module MED_ENGINE V0.50 livré**. Ils ne signifient pas qu'une fonction comparable a été supprimée des 85 cours d'origine ou de Medora.

## Contenus réellement livrés

Le miroir importé contient 752 fichiers source : 142 JSON, 155 Markdown, 308 SVG, 130 PNG, 15 HTML et deux TOML. Les fichiers techniques générés pour le site portent le total à 755.

- 141 paquets ; 15 592 notes source ; 15 605 cartes source ; 25 753 variantes de rappel générées pour l'adaptation mobile. Ces trois nombres ne désignent pas la même unité.
- 438 SVG/PNG présents dans 13 paquets. Les images présentes ont été vérifiées ; elles ne sont pas toutes faciles à découvrir dans la navigation V0.50.
- Aucun PDF/DOCX dans **le miroir de contenus embarqué dans la livraison V0.50**. De nombreux documents y sont cités dans les métadonnées : citation et fichier lisible sont différents. Le dossier S1 distinct, désormais inventorié, fournit bien 116 PDF qui pourront être ouverts séparément et associés aux banques ; il ne faut donc pas annoncer que les PDF sources sont introuvables.
- 8 699 références distinctes `(paquet, nom de figure)` n'ont pas de fichier correspondant dans le miroir fourni. Cela n'est pas une panne de chargement de 8 699 images publiées : les fichiers n'y sont pas. On ne sait pas lesquels existent dans le dossier personnel du PC sans le recevoir.
- La capture Windows montre des UE supplémentaires, notamment neuroanatomie, appareil locomoteur et bactériologie. Leur présence dans la bibliothèque Windows personnelle est constatée sur la capture, mais leur contenu complet n'est pas établi dans les 141 banques fournies. Il ne faut ni annoncer qu'il a été transféré, ni inventer ces cours à partir des seuls intitulés.

## Corrections prioritaires

1. Séparer clairement **Lire / S'entraîner / Schémas**, avec un accès direct aux illustrations et à leurs exercices, en conservant les fonctions déjà présentes.
2. Fournir un lecteur agréable des guides et fiches disponibles, en les distinguant des ronéos ; associer les 116 PDF du dossier S1 aux banques correspondantes sans inventer d'équivalence pour les intitulés ambigus. L'accès Drive requiert une connexion et les droits de lecture ; seule une copie importée localement permet de lire ce PDF hors connexion.
3. Rétablir le parcours de lecture et ses dates, le lexique d'UE et les renvois aux pages, puis le travail sur les planches complètes.
4. Traiter séparément la parité pédagogique : barème, échelle, sujets d'annales, politique d'examen et journal. Une amélioration de navigation ne suffit pas à annoncer leur équivalence.
5. Ajouter les échanges de contenus ZIP/APKG et l'import de la bibliothèque personnelle Windows avec un format documenté, sans écraser les données mobiles.

## Correctif V0.50.1 préparé après cette comparaison

Le correctif ajoute l’accès direct **Lire / S’entraîner / Schémas**, les guides structurés, les fiches et corrections en lecture libre, la galerie des 438 images et les exercices associés. Les 15 supports HTML peuvent être agrandis ; cinq sont interactifs et dix explicatifs. Le catalogue **Cours du Drive** donne accès aux 116 PDF et sept documents complémentaires ; 97 références de 61 banques correspondent par leur nom à 81 PDF distincts, dont les trois parties de pharmacodynamie. Les PDF s’ouvrent en ligne dans Drive, dans un nouvel onglet. L’import privé permet leur lecture intégrée hors connexion sur l’appareil.

Les tests du correctif sont consignés dans `ENGINE-VERIFICATION.md`. Il est livré pour installation manuelle ; il n’est pas encore publié sur le site par cette préparation. L’historique de lecture Windows, le lexique d’UE avec renvois de pages, les planches complètes, l’échelle et le barème Windows, le journal avec annulation, les XP et les exports ZIP/APKG restent des écarts. Ce correctif ne doit pas être présenté comme une reproduction complète de Windows.

## Sources techniques de la comparaison

- Notices : [LISEZ_MOI](https://drive.google.com/file/d/19G792bpJZKrw_SfIf95xbMmIMgQwx52l/view) ; [GUIDE — bachoter une UE](https://drive.google.com/file/d/16iiLDJ-ZlZc6z8H5nCN4g4aIG7w0nuuS/view).
- Modules Windows lus statiquement : `config`, `ui.pages.content`, `ui.pages.lexique`, `application.lexicon`, `ui.echelle`, `application.papers`, `ui.pages.mock_exam`, `ui.pages.misc`, `ui.pages.search`, `ui.manual_text`, `infrastructure.anki_export`, `infrastructure.merge`, `seed`.
- Sources mobiles extraites du ZIP V0.50 : `EngineLibrary.tsx`, `EngineQuestion.tsx`, `EngineReview.tsx`, `EngineDataPanel.tsx`, `engine-study.ts`, `engine-question.ts`, `local-fsrs.ts`, `study.ts`, et `engine/manifest.json`.
- Inventaire du dossier PDF S1 : `docs/source-pdf-inventory.json`, observé le 28 octobre 2026, 123 fichiers/116 PDF/16 dossiers parcourus. Les sept autres fichiers sont des tableaux d'erreurs au format Google Docs ou DOCX.
- Les traces de lecture statique sont conservées dans `/workspace/med-engine-windows-audit/` : liste des entrées d'archive, modules décompressés, constantes textuelles et désassemblages. Aucun import du programme Windows, aucune exécution de son code.
