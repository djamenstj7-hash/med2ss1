#!/usr/bin/env python3
"""Build the three iPhone-uploadable MED2 S1 MED_ENGINE archives after QA."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import tempfile
import zipfile
import zlib

MAX_ZIP = 24_000_000
STAMP = (2026, 10, 28, 0, 0, 0)
MAIN_NAME = 'med2ss1-engine-mise-a-jour.zip'


def digest(path: Path) -> str:
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def add_bytes(bundle: zipfile.ZipFile, name: str, value: bytes) -> None:
    entry = zipfile.ZipInfo(name, STAMP)
    entry.compress_type = zipfile.ZIP_DEFLATED
    entry.external_attr = 0o100644 << 16
    bundle.writestr(entry, value, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)


def write_zip(path: Path, values: list[tuple[str, Path | bytes]]) -> None:
    with zipfile.ZipFile(path, 'w') as bundle:
        for name, value in sorted(values):
            add_bytes(bundle, name, value if isinstance(value, bytes) else value.read_bytes())
    with zipfile.ZipFile(path) as bundle:
        if bundle.testzip() is not None:
            raise ValueError(f'Archive endommagée : {path.name}')
    if path.stat().st_size >= MAX_ZIP:
        raise ValueError(f'{path.name} dépasse la taille prévue pour l’envoi sur iPhone.')


def package(root: Path, output: Path) -> dict:
    root, output = root.resolve(), output.resolve()
    if output == root or output.is_relative_to(root):
        raise ValueError('Choisis un dossier de livraison en dehors du projet.')
    required = ['index.html', 'service-worker.js', 'engine-host.js', 'engine-module/engine.js',
                'engine-module/engine.css', 'engine/manifest.json', 'docs/engine-iphone/assemble.py',
                'docs/engine-iphone/installation-med-engine.template.yml', 'docs/engine-iphone/base-guards.json',
                'docs/ENGINE-INSTALLATION.md']
    for name in required:
        path = root / name
        if path.is_symlink() or not path.is_file():
            raise ValueError(f'Fichier manquant : {name}. Construis et vérifie le module avant de préparer les ZIP.')
    output.mkdir(parents=True, exist_ok=True)

    # Balance actual compressed sizes, rather than raw image sizes, into two uploads.
    contents = sorted(path for path in (root / 'engine').rglob('*') if path.is_file())
    if len(contents) != 755 or any(path.is_symlink() for path in contents):
        raise ValueError('Cette livraison attend les 755 fichiers MED_ENGINE fournis et vérifiés.')
    weighted = [(len(zlib.compress(path.read_bytes(), 9)), path) for path in contents]
    bins: list[list[Path]] = [[], []]
    weights = [0, 0]
    for weight, path in sorted(weighted, key=lambda row: (-row[0], row[1].as_posix())):
        index = min(range(2), key=lambda item: weights[item])
        bins[index].append(path)
        weights[index] += weight + len(path.relative_to(root).as_posix().encode()) * 2 + 120
    parts = []
    for index, paths in enumerate(bins, start=1):
        name = f'med2ss1-engine-contenus-{index}.zip'
        target = output / name
        write_zip(target, [(path.relative_to(root).as_posix(), path) for path in paths])
        parts.append({'file': name, 'sha256': digest(target), 'bytes': target.stat().st_size, 'files': len(paths)})

    payload = [root / name for name in ['index.html', 'service-worker.js', 'engine-host.js']]
    payload += sorted(path for path in (root / 'engine-module').rglob('*') if path.is_file())
    if any(path.is_symlink() for path in payload):
        raise ValueError('Les fichiers du module doivent être des fichiers ordinaires.')
    base = json.loads((root / 'docs/engine-iphone/base-guards.json').read_text())
    old = {item['path']: item['sha256'] for item in base['files']}
    guards = [{'path': name, 'acceptedSha256': list(dict.fromkeys([old[name], digest(root / name)]))}
              for name in ['index.html', 'service-worker.js', 'engine-host.js']]
    manifest = {'application': 'med2ss1-engine', 'schemaVersion': 1, 'version': '0.50.0-engine.1',
                'baseCommit': base['sourceCommit'], 'engineFiles': len(contents), 'parts': parts,
                'guards': guards, 'payload': [{'path': path.relative_to(root).as_posix(), 'sha256': digest(path),
                                              'bytes': path.stat().st_size} for path in payload]}
    files = [('delivery.json', (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode()),
             ('assemble.py', root / 'docs/engine-iphone/assemble.py')]
    files += [('patch/' + path.relative_to(root).as_posix(), path) for path in payload]
    # The reviewable sources are included, but never deployed over the public checkout.
    source_paths = set()
    for directory in ['engine-src', 'engine-tests', 'docs/engine-iphone']:
        for path in (root / directory).rglob('*'):
            if path.is_file() and not path.is_symlink() and '__pycache__' not in path.parts:
                source_paths.add(path)
    for name in ['package.json', 'package-lock.json', 'tsconfig.engine.json', 'vite.engine.config.ts',
                 'vitest.engine.config.ts', 'scripts/package-engine.py', 'docs/ENGINE-INSTALLATION.md']:
        path = root / name
        if path.is_file():
            source_paths.add(path)
    # Reproducible browser scripts and their baseline fixture belong to the
    # reviewable delivery; transient screenshots and failed-run output do not.
    for path in (root / 'qa').glob('*.mjs'):
        if path.is_file() and not path.is_symlink():
            source_paths.add(path)
    for pattern in ['ENGINE-VERIFICATION.md', 'ENGINE-VERIFICATION-*.json']:
        for path in (root / 'docs').glob(pattern):
            if path.is_file() and not path.is_symlink():
                source_paths.add(path)
    baseline_fixture = root / 'qa/base-content-hashes.json'
    if baseline_fixture.is_file() and not baseline_fixture.is_symlink():
        source_paths.add(baseline_fixture)
    files += [('source/' + path.relative_to(root).as_posix(), path) for path in source_paths]
    main_zip = output / MAIN_NAME
    write_zip(main_zip, files)
    main_hash = digest(main_zip)
    workflow = (root / 'docs/engine-iphone/installation-med-engine.template.yml').read_text(encoding='utf-8')
    if workflow.count('__MAIN_SHA256__') != 1:
        raise ValueError('Le modèle du workflow ne contient pas le bon repère d’empreinte.')
    workflow = workflow.replace('__MAIN_SHA256__', main_hash)
    for name in ['installation-med-engine.yml', 'installation-med-engine-iphone.txt']:
        (output / name).write_text(workflow, encoding='utf-8')
    shutil.copyfile(root / 'docs/ENGINE-INSTALLATION.md', output / 'LISEZ-MOI-IPHONE.txt')
    report = {'application': manifest['application'], 'version': manifest['version'],
              'baseCommit': manifest['baseCommit'], 'engineFiles': len(contents),
              'archives': [{'file': MAIN_NAME, 'sha256': main_hash, 'bytes': main_zip.stat().st_size}, *parts]}
    (output / 'CONTENU-LIVRAISON.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

    # Exercise exactly the assembler shipped to GitHub, over the original public snapshot.
    spec = importlib.util.spec_from_file_location('med2_engine_assembly', root / 'docs/engine-iphone/assemble.py')
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    with tempfile.TemporaryDirectory(prefix='med2-engine-package-') as tmp:
        temp = Path(tmp)
        delivery = temp / 'delivery'
        with zipfile.ZipFile(main_zip) as bundle:
            bundle.extractall(delivery)
        # The checkout remains the authoritative source of public course data and images.
        checkout = temp / 'checkout'
        checkout.mkdir()
        for path in root.rglob('*'):
            if path.is_file() and module.public_file(path, root):
                destination = checkout / path.relative_to(root)
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(path, destination)
        for part in parts:
            shutil.copyfile(output / part['file'], checkout / part['file'])
        assembled = temp / 'site'
        module.assemble(checkout, delivery, assembled)
        for path in contents:
            target = assembled / path.relative_to(root)
            if digest(path) != digest(target):
                raise ValueError(f'Contenu différent après assemblage : {path.name}.')
        for directory in ['data', 'Assets']:
            for path in (root / directory).rglob('*'):
                if path.is_file() and digest(path) != digest(assembled / path.relative_to(root)):
                    raise ValueError(f'Un fichier existant a été modifié : {path.name}.')
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    try:
        result = package(args.root, args.output)
    except (ValueError, OSError, zipfile.BadZipFile, RuntimeError) as error:
        print(f'Livraison interrompue : {error}', file=sys.stderr)
        return 1
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
