import { engineAssetUrl, engineCards } from './engine';
import type { EngineCard, EngineManifest, EnginePack, EnginePackSummary } from './engine-types';

export interface EngineGalleryFigure {
  id: string;
  path: string;
  filename: string;
  packId: string;
  packTitle: string;
  caption?: string;
  sourceId?: string;
}

function suppliedFigure(pack: Pick<EnginePackSummary, 'id' | 'title'>, filename: string): EngineGalleryFigure | undefined {
  if (typeof filename !== 'string' || !filename || /[\\/:?#\u0000-\u001f]/.test(filename) || !/\.(?:png|svg|webp|jpe?g)$/i.test(filename)) return undefined;
  const path = `assets/packs/${pack.id}/media/${filename}`;
  if (!engineAssetUrl(path)) return undefined;
  return { id: path, path, filename, packId: pack.id, packTitle: pack.title };
}

/** The gallery lists supplied files, never the much larger list of missing source references. */
export function engineGalleryFigures(manifest: EngineManifest): EngineGalleryFigure[] {
  const published = new Set(manifest.files);
  const seen = new Set<string>();
  return manifest.packs.flatMap(pack => pack.availableMedia.flatMap(filename => {
    const figure = suppliedFigure(pack, filename);
    if (!figure || !published.has(figure.path) || seen.has(figure.id)) return [];
    seen.add(figure.id);
    return [figure];
  }));
}

export function enginePackFigures(pack: EnginePack): EngineGalleryFigure[] {
  const seen = new Set<string>();
  const cards = engineCards(pack);
  return (pack.availableMedia || []).flatMap(filename => {
    const figure = suppliedFigure(pack, filename);
    if (!figure || seen.has(figure.id)) return [];
    seen.add(figure.id);
    const media = pack.media.find(item => item.fichier.replace(/^media\//, '') === filename);
    const illustrated = cards.flatMap(card => [card.questionIllustration, card.illustration, card.schemaIllustration]).find(item => item?.path === figure.path && item.available !== false);
    return [{ ...figure, caption: media?.legende || illustrated?.caption || undefined, sourceId: media?.source_id }];
  });
}

/** Full paths retain the source chapter identity when two chapters use the same filename. */
export function engineFigureCards(pack: EnginePack, path: string): EngineCard[] {
  if (!enginePackFigures(pack).some(figure => figure.path === path)) return [];
  const priority = (card: EngineCard) => card.type === 'zone' ? 0 : card.type === 'legend' ? 1 : 2;
  return engineCards(pack).filter(card => [card.questionIllustration, card.illustration, card.schemaIllustration]
    .some(figure => figure?.available !== false && figure?.path === path))
    .sort((left, right) => priority(left) - priority(right));
}

export function engineFigurePracticeAvailable(card: EngineCard): boolean {
  return !['zone', 'legend'].includes(card.type) || Boolean(card.questionIllustration && card.questionIllustration.available !== false);
}
