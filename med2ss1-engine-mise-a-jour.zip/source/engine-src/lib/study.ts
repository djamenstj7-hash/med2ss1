import type { StudyAttempt, StudyMode, StudySession, StudyState } from './study-types';
import { isEngineSession, type EngineAttempt } from './engine-study';
import { mutateEngineDatabase, readEngineDatabase, subscribeEngineDatabase } from './engine-local-db';
import { array, boolean, calendar, fail, identifier, integer, jsonCopy, number, object, parseBackup, record, string, timestamp, unique } from './engine-local-validation';
export type * from './study-types';

const SCOPE = 'med2ss1-local';
const modes: StudyMode[] = ['practice', 'exam', 'qroc', 'writing', 'flashcard'];
export interface StudyBackup { application: 'med2ss1-engine-study'; schemaVersion: 1; exportedAt: string; state: StudyState }
export function emptyStudyState(): StudyState {
  return { schemaVersion: 2, read: {}, bookmarks: [], notes: {}, attempts: [], sessions: [], missions: [], exams: {}, settings: { dailyMinutes: 90, backgroundMinutes: 15, fontSize: 18, lineHeight: 1.75, readerTheme: 'light', readerFont: 'system' }, lessonReviews: {}, writingDrafts: {}, version: 0, syncStatus: 'local' };
}
function scope(expected?: string) { if (expected !== undefined && expected !== SCOPE) throw new Error('Cette action appartient à une autre bibliothèque.'); }
function engineId(value: unknown): string { return identifier(value, 'engine:'); }
function mode(value: unknown): StudyMode { if (!modes.includes(value as StudyMode)) fail('Mode d’entraînement invalide.'); return value as StudyMode; }
function point(value: unknown): { x: number; y: number } { if (!object(value)) fail(); return { x: number(value.x, 0, 1_000_000), y: number(value.y, 0, 1_000_000) }; }
export function decodeAttempt(value: unknown): EngineAttempt {
  if (!object(value)) fail('Réponse MED_ENGINE invalide.');
  const result: EngineAttempt = { id: identifier(value.id), questionId: engineId(value.questionId), subjectId: engineId(value.subjectId), mode: mode(value.mode), correct: boolean(value.correct), createdAt: timestamp(value.createdAt), application: 'engine' };
  if (value.application !== undefined && value.application !== 'engine') fail();
  if (value.lessonId !== undefined) result.lessonId = engineId(value.lessonId);
  if (value.chapterIndex !== undefined) result.chapterIndex = integer(value.chapterIndex, 0, 10_000);
  if (value.selected !== undefined) result.selected = unique(array(value.selected, 100).map(index => integer(index, 0, 999)));
  if (value.responseText !== undefined) result.responseText = string(value.responseText);
  if (value.score !== undefined) result.score = number(value.score, 0, 1);
  if (value.durationSeconds !== undefined) result.durationSeconds = number(value.durationSeconds, 0, 86_400);
  if (value.confidence !== undefined) { if (!['sure', 'hesitant', 'guess'].includes(String(value.confidence))) fail(); result.confidence = value.confidence as EngineAttempt['confidence']; }
  if (value.engineMode !== undefined) { if (!['bachotage', 'annales', 'exam'].includes(String(value.engineMode))) fail(); result.engineMode = value.engineMode as EngineAttempt['engineMode']; }
  if (value.point !== undefined) result.point = point(value.point);
  if (value.selfAssessed !== undefined) result.selfAssessed = boolean(value.selfAssessed);
  if (value.imported !== undefined) result.imported = boolean(value.imported);
  return result;
}
function decodeSession(value: unknown): StudySession {
  if (!object(value)) fail('Bilan MED_ENGINE invalide.');
  const result: StudySession = { id: identifier(value.id), mode: mode(value.mode), startedAt: timestamp(value.startedAt), finishedAt: timestamp(value.finishedAt), questionCount: integer(value.questionCount, 0, 10_000), correctCount: integer(value.correctCount, 0, 10_000), durationSeconds: number(value.durationSeconds, 0, 86_400 * 7) };
  if (result.correctCount > result.questionCount || result.finishedAt < result.startedAt) fail('Le bilan comporte des valeurs incohérentes.');
  if (value.lessonId !== undefined) result.lessonId = engineId(value.lessonId);
  if (value.subjectId !== undefined) result.subjectId = engineId(value.subjectId);
  if (value.imported !== undefined) result.imported = boolean(value.imported);
  return result;
}
function activeSession(value: unknown): Record<string, unknown> {
  if (!isEngineSession(value) || JSON.stringify(value).length > 256_000) fail('La séance sauvegardée est invalide ou trop volumineuse.');
  return { application: 'engine', schemaVersion: 1, id: identifier(value.id), packId: identifier(value.packId), mode: value.mode, cardIds: value.cardIds.map(engineId), answers: Object.fromEntries(Object.entries(value.answers).map(([key, answer]) => [engineId(key), identifier(answer)])), index: value.index, startedAt: timestamp(value.startedAt), elapsedMs: number(value.elapsedMs, 0, 86_400_000 * 30), runningSince: null, questionStartedMs: number(value.questionStartedMs, 0, 86_400_000 * 30), limitSeconds: value.limitSeconds === null ? null : number(value.limitSeconds, 1, 10_800), ...(value.finishedAt === undefined ? {} : { finishedAt: timestamp(value.finishedAt) }) };
}
function textMap(value: unknown): Record<string, string> { return Object.fromEntries(Object.entries(record(value)).map(([key, text]) => [engineId(key), string(text)])); }
export function decodeStudyState(value: unknown): StudyState {
  if (value === undefined) return emptyStudyState();
  if (!object(value) || value.schemaVersion !== 2) fail('Version des données MED_ENGINE non prise en charge.');
  const state = emptyStudyState();
  state.bookmarks = unique(array(value.bookmarks).map(engineId));
  state.notes = textMap(value.notes);
  state.writingDrafts = textMap(value.writingDrafts);
  state.exams = Object.fromEntries(Object.entries(record(value.exams)).map(([key, date]) => [engineId(key), calendar(date)]));
  state.read = Object.fromEntries(Object.entries(record(value.read)).map(([key, values]) => [engineId(key), unique(array(values, 10_000).map(index => integer(index, 0, 10_000)))]));
  state.attempts = array(value.attempts).map(decodeAttempt);
  state.sessions = array(value.sessions).map(decodeSession);
  if (new Set(state.attempts.map(item => item.id)).size !== state.attempts.length || new Set(state.sessions.map(item => item.id)).size !== state.sessions.length) fail('La sauvegarde contient des événements en double.');
  state.version = integer(value.version, 0, Number.MAX_SAFE_INTEGER);
  if (value.activeSession !== undefined) state.activeSession = activeSession(value.activeSession);
  return state;
}
export function decodeStudyBackup(raw: unknown): StudyState {
  const value = parseBackup(raw);
  if (!object(value) || value.application !== 'med2ss1-engine-study' || value.schemaVersion !== 1) fail('Ce fichier n’est pas une sauvegarde MED_ENGINE de MED2 S1.');
  timestamp(value.exportedAt); return decodeStudyState(value.state);
}
export function mergeStudyStates(current: StudyState, incoming: StudyState): StudyState {
  const attempts = new Map(current.attempts.map(value => [value.id, value])); for (const value of incoming.attempts) if (!attempts.has(value.id)) attempts.set(value.id, value);
  const sessions = new Map(current.sessions.map(value => [value.id, value])); for (const value of incoming.sessions) if (!sessions.has(value.id)) sessions.set(value.id, value);
  const read: Record<string, number[]> = { ...current.read }; for (const [key, values] of Object.entries(incoming.read)) read[key] = unique([...(read[key] || []), ...values]);
  const merged = { ...current, bookmarks: unique([...current.bookmarks, ...incoming.bookmarks]), notes: { ...incoming.notes, ...current.notes }, exams: { ...incoming.exams, ...current.exams }, writingDrafts: { ...incoming.writingDrafts, ...current.writingDrafts }, attempts: [...attempts.values()], sessions: [...sessions.values()], read, activeSession: current.activeSession || incoming.activeSession, version: Math.max(current.version, incoming.version) + 1 };
  return decodeStudyState(merged);
}
function mutate(change: (state: StudyState) => void, expected?: string): Promise<StudyState> {
  scope(expected);
  return mutateEngineDatabase(data => { const state = decodeStudyState(data.study); change(state); state.version += 1; data.study = decodeStudyState(state); return jsonCopy(data.study) as StudyState; });
}
export const study = {
  async ownerScope() { return SCOPE; },
  async load(): Promise<StudyState> { return decodeStudyState((await readEngineDatabase()).study); },
  subscribe: subscribeEngineDatabase,
  setBookmark(lessonId: string, enabled: boolean, expected?: string) { engineId(lessonId); boolean(enabled); return mutate(state => { state.bookmarks = enabled ? unique([...state.bookmarks, lessonId]) : state.bookmarks.filter(id => id !== lessonId); }, expected); },
  setNote(lessonId: string, value: string, expected?: string) { engineId(lessonId); string(value); return mutate(state => { if (value) state.notes[lessonId] = value; else delete state.notes[lessonId]; }, expected); },
  recordAttempt(input: Omit<StudyAttempt, 'id' | 'createdAt'> & { id?: string }, expected?: string) {
    const attempt = decodeAttempt({ ...input, id: input.id || crypto.randomUUID(), createdAt: new Date().toISOString() });
    return mutate(state => { if (!state.attempts.some(value => value.id === attempt.id)) state.attempts.push(attempt); }, expected);
  },
  recordSession(input: Omit<StudySession, 'id'> & { id?: string }, expected?: string) { const session = decodeSession({ ...input, id: input.id || crypto.randomUUID() }); return mutate(state => { if (!state.sessions.some(value => value.id === session.id)) state.sessions.push(session); }, expected); },
  setExamDate(subjectId: string, value: string | null, expected?: string) { engineId(subjectId); if (value !== null) calendar(value); return mutate(state => { if (value === null) delete state.exams[subjectId]; else state.exams[subjectId] = value; }, expected); },
  saveWritingDraft(id: string, value: string, expected?: string) { engineId(id); string(value); return mutate(state => { if (value) state.writingDrafts[id] = value; else delete state.writingDrafts[id]; }, expected); },
  saveActiveSession(session: Record<string, unknown> | null, expected?: string) { const validated = session === null ? undefined : activeSession(session); return mutate(state => { if (validated) state.activeSession = validated; else delete state.activeSession; }, expected); },
  async exportState(): Promise<StudyBackup> { return { application: 'med2ss1-engine-study', schemaVersion: 1, exportedAt: new Date().toISOString(), state: await study.load() }; },
  validateImportState(raw: unknown): void { decodeStudyBackup(raw); },
  importState(raw: unknown): Promise<StudyState> { const incoming = decodeStudyBackup(raw); return mutateEngineDatabase(data => { const merged = mergeStudyStates(decodeStudyState(data.study), incoming); data.study = merged; return jsonCopy(merged); }); },
  clearProgress(): Promise<StudyState> { return mutateEngineDatabase(data => { data.study = emptyStudyState(); return jsonCopy(data.study) as StudyState; }); },
};
