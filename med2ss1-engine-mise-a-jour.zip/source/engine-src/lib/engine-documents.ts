import catalogue from '../data/source-documents.json';
import type { EnginePack } from './engine-types';

export interface EngineSourceDocument { id: string; title: string; path: string; mime: string; size: number; url: string; ue: string; kind: string }

/** URLs are observed Drive metadata, not reconstructed download URLs or bearer links. */
export function safeDocumentUrl(value: string): string | undefined {
  try {
    const url = new URL(value);
    const driveFile = url.hostname === 'drive.google.com' && /^\/file\/d\/[\w-]+\/view$/.test(url.pathname);
    const googleDocument = url.hostname === 'docs.google.com' && /^\/document\/d\/[\w-]+\/edit$/.test(url.pathname);
    if (url.protocol !== 'https:' || url.username || url.password || (!driveFile && !googleDocument)) return undefined;
    return url.href;
  } catch { return undefined; }
}

export const engineSourceDocuments: EngineSourceDocument[] = catalogue.files.flatMap(file => {
  const url = safeDocumentUrl(file.url);
  if (!url) return [];
  const parts = file.path.split('/').map(part => part.trim());
  return [{ ...file, url, ue: parts[2] || 'Autres documents', kind: parts[1] || 'Autre' }];
});
const byId = new Map(engineSourceDocuments.map(file => [file.id, file]));
const links: Readonly<Record<string, Record<string, string[]>>> = catalogue.links;
const linkedTitles = new Map<string, Set<string>>();
const packTitles: Readonly<Record<string, string>> = catalogue.packTitles;
for (const [packId, sources] of Object.entries(links)) {
  const title = packTitles[packId];
  if (!title) continue;
  for (const id of Object.values(sources).flat()) {
    const titles = linkedTitles.get(id) || new Set<string>();
    titles.add(title); linkedTitles.set(id, titles);
  }
}
export const engineDocumentCounts = {
  documents: engineSourceDocuments.length,
  pdf: engineSourceDocuments.filter(file => file.mime === 'application/pdf').length,
  matchedPacks: Object.keys(links).length,
};

export function engineDocumentsForSource(packId: string, sourceId: string): EngineSourceDocument[] {
  return (links[packId]?.[sourceId] || []).flatMap(id => { const file = byId.get(id); return file ? [file] : []; });
}
export function engineDocumentsForPack(pack: EnginePack | string): EngineSourceDocument[] {
  const id = typeof pack === 'string' ? pack : pack.id;
  const ids = typeof pack === 'string' ? Object.keys(links[id] || {}) : pack.source_documents.map(source => source.id);
  const seen = new Set<string>();
  return ids.flatMap(sourceId => engineDocumentsForSource(id, sourceId).filter(file => { if (seen.has(file.id)) return false; seen.add(file.id); return true; }));
}

const subjectFolders: Readonly<Record<string, string[]>> = {
  'ue-anatomie': ['ANATOMIE'], 'ue-biomed-quanti': ['BIOMEDECINE QUANTITATIVE'],
  'ue-bmcp': ['BMCP'], 'ue-bmct': ['BMCT'], 'ue-immunologie': ['IMMUNOLOGIE'],
  'ue-info-medicale': ['INFORMATIQUE MÉDICALE'], 'ue-parasito': ['PARASITOLOGIE - MYCOLOGIE'],
  'ue-semio': ['SEMIOLOGIE'], 'ue-ssh': ['SSH', 'SSH - ETHIQUE ET DROIT'],
  'ue-tissu-sanguin': ['TISSU SANGUIN'], 'ue-virologie': ['VIROLOGIE'],
};
/** A common UE groups documents for browsing; it never establishes a source match. */
export function engineOtherSubjectDocuments(pack: EnginePack): EngineSourceDocument[] {
  const direct = new Set(engineDocumentsForPack(pack).map(file => file.id));
  const folders = new Set(pack.subjects.flatMap(subject => subjectFolders[subject.id] || []));
  return engineSourceDocuments.filter(file => folders.has(file.ue) && !direct.has(file.id));
}
export function documentSearch(value: string): string { return value.normalize('NFD').replace(/\p{M}/gu, '').toLocaleLowerCase('fr'); }
/** Search aliases come only from already validated source links; filenames stay unchanged. */
export function documentMatchesQuery(file: EngineSourceDocument, query: string): boolean {
  const needle = documentSearch(query.trim());
  if (!needle) return true;
  return documentSearch(`${file.title} ${file.ue} ${file.path} ${[...(linkedTitles.get(file.id) || [])].join(' ')}`).includes(needle);
}
export function documentSize(bytes: number): string { return bytes >= 1_000_000 ? `${(bytes / 1_000_000).toLocaleString('fr-FR', { maximumFractionDigits: 1 })} Mo` : `${Math.max(1, Math.round(bytes / 1000))} ko`; }
export const engineDocumentsSourceRoot = catalogue.sourceRoot;
