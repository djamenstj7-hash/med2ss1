import { engineAssetUrl, loadEngineManifest } from './engine';

export const ENGINE_CACHE = 'med2ss1-engine-v1';
export interface EngineOfflineStatus { total: number; cached: number; missing: number; bytes?: number }
export interface EngineOfflineProgress { total: number; done: number; current: string; failed: string[] }
let downloading = false;

/** Only the public files explicitly listed by the shipped manifest are eligible. */
export function engineOfflineUrls(files: string[], base = document.baseURI): string[] {
  if (!Array.isArray(files) || files.length > 10000) throw new Error('Le catalogue hors connexion est invalide.');
  const root = new URL('./engine/', base);
  const paths = [...new Set(['manifest.json', ...files])];
  return paths.map(path => {
    if (typeof path !== 'string' || path.length > 1200) throw new Error('Un chemin du catalogue est invalide.');
    if (!engineAssetUrl(path)) throw new Error('Un chemin du catalogue est invalide.');
    const cleaned = path.replace(/^\.\//, '').replace(/^engine\//, '');
    const url = new URL(cleaned.split('/').map(encodeURIComponent).join('/'), root);
    if (url.origin !== root.origin || !url.pathname.startsWith(root.pathname) || url.search || url.hash) {
      throw new Error('Un fichier du catalogue sort de l’application.');
    }
    return url.href;
  });
}

function requireCache() {
  if (!('caches' in globalThis)) throw new Error('Le stockage hors connexion n’est pas disponible dans ce navigateur. Ouvre le site dans Safari avec une connexion HTTPS.');
}

async function expectedUrls() {
  const manifest = await loadEngineManifest();
  return engineOfflineUrls(manifest.files);
}

export async function getEngineOfflineStatus(): Promise<EngineOfflineStatus> {
  requireCache();
  const urls = await expectedUrls();
  const cache = await caches.open(ENGINE_CACHE);
  const keys = new Set((await cache.keys()).map(request => request.url));
  const cached = urls.reduce((sum, url) => sum + Number(keys.has(url)), 0);
  return { total: urls.length, cached, missing: urls.length - cached };
}

export async function downloadEngine(onProgress?: (progress: EngineOfflineProgress) => void, signal?: AbortSignal): Promise<EngineOfflineStatus> {
  requireCache();
  if (downloading) throw new Error('Un téléchargement MED_ENGINE est déjà en cours.');
  downloading = true;
  try {
    const urls = await expectedUrls();
    const cache = await caches.open(ENGINE_CACHE);
    const failed: string[] = [];
    let done = 0;
    for (const url of urls) {
      signal?.throwIfAborted();
      const path = decodeURIComponent(new URL(url).pathname.split('/engine/')[1] || '');
      try {
        const existing = await cache.match(url);
        if (!existing?.ok) {
          const response = await fetch(url, { signal, cache: 'no-cache', credentials: 'omit', redirect: 'error' });
          if (!response.ok || response.type === 'opaque') throw new Error('Fichier indisponible.');
          const length = Number(response.headers.get('content-length'));
          if (length > 30 * 1024 * 1024) throw new Error('Fichier trop volumineux.');
          await cache.put(url, response);
        }
      } catch (error) {
        if (signal?.aborted || error instanceof DOMException && error.name === 'AbortError') throw error;
        failed.push(path);
      }
      done += 1;
      onProgress?.({ total: urls.length, done, current: path, failed: [...failed] });
    }
    const status = await getEngineOfflineStatus();
    if (status.missing) throw new Error(`${status.missing} fichier${status.missing > 1 ? 's restent' : ' reste'} à télécharger. Les fichiers déjà reçus sont conservés ; réessaie avec une connexion stable.`);
    return status;
  } finally {
    downloading = false;
  }
}

export async function clearEngineOffline(): Promise<void> {
  requireCache();
  if (downloading) throw new Error('Arrête le téléchargement avant de supprimer les fichiers.');
  await caches.delete(ENGINE_CACHE);
}
