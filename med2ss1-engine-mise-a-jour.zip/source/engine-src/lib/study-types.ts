export type StudyMode = 'practice' | 'exam' | 'qroc' | 'writing' | 'flashcard';
export type LessonLevel = 'mastered' | 'partial' | 'again';
export interface StudySettings {
  dailyMinutes: number;
  backgroundMinutes: number;
  fontSize: number;
  lineHeight: number;
  readerTheme: 'light' | 'sepia' | 'dark';
  readerFont: 'serif' | 'sans' | 'system' | 'atkinson';
}
export interface StudyAttempt {
  id: string;
  questionId: string;
  lessonId?: string;
  subjectId: string;
  chapterIndex?: number;
  mode: StudyMode;
  correct: boolean;
  selected?: number[];
  responseText?: string;
  score?: number;
  durationSeconds?: number;
  createdAt: string;
  imported?: boolean;
}
export interface StudySession {
  id: string;
  subjectId?: string;
  lessonId?: string;
  mode: StudyMode;
  startedAt: string;
  finishedAt: string;
  questionCount: number;
  correctCount: number;
  durationSeconds: number;
  imported?: boolean;
}
export interface LessonReview { id: string; level: LessonLevel; createdAt: string }
export interface ExtraMission { id: string; lessonId: string; type: 'read' | 'practice' | 'recall'; createdAt: string }
export interface ImportedCatalogue {
  schemaVersion: 1;
  subjects: { id: string; name: string; color?: string }[];
  resources: { id: string; subject: string; title: string; kind: string; status?: string; url?: string }[];
}
export interface StudyState {
  schemaVersion: 2;
  read: Record<string, number[]>;
  bookmarks: string[];
  notes: Record<string, string>;
  lastRead?: { lessonId: string; chapterIndex: number };
  attempts: StudyAttempt[];
  sessions: StudySession[];
  missions: ExtraMission[];
  exams: Record<string, string>;
  settings: StudySettings;
  lessonReviews: Record<string, LessonReview[]>;
  writingDrafts: Record<string, string>;
  activeSession?: Record<string, unknown>;
  /** The original MED2 evidence remains exportable; legacy intervals are never substituted for FSRS. */
  importedLegacy?: Record<string, unknown>;
  customCatalogue?: ImportedCatalogue;
  version: number;
  syncStatus?: 'local' | 'synced' | 'pending' | 'unavailable';
}
export type StudyEventKind = 'read' | 'bookmark' | 'note' | 'last-read' | 'attempt' | 'session' | 'exam' | 'settings' | 'lesson-review' | 'writing' | 'active-session' | 'legacy' | 'catalogue' | 'reset-progress' | 'mission-add' | 'mission-remove';
export interface StudyEvent {
  id: string;
  kind: StudyEventKind;
  clock: number;
  createdAt: string;
  data: Record<string, unknown>;
}
export interface StudyEnvelope {
  schemaVersion: 2;
  events: StudyEvent[];
  pending: string[];
  syncStatus: NonNullable<StudyState['syncStatus']>;
  /** Exported server/private FSRS snapshot retained as evidence, never blindly replayed onto a different account. */
  archivedLibrary?: unknown;
}
