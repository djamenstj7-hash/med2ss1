import { createEmptyCard, fsrs, type Card, type Grade, type ReviewLog } from 'ts-fsrs';
import type { EngineCard, EnginePack } from './engine-types';
import { mutateEngineDatabase, readEngineDatabase, subscribeEngineDatabase } from './engine-local-db';
import { array, boolean, date, fail, identifier, integer, number, object, parseBackup, string, timestamp, unique } from './engine-local-validation';

export interface LocalEngineDeck { id: string; packId: string; title: string; subjectId: string; createdAt: string; cardIds: string[]; active: boolean }
export interface LocalEngineCard { id: string; deckId: string; packId: string; sourceId: string; noteId: string; prompt: string; answer: string; explanation: string; schedule: Card; active: boolean }
export interface LocalReviewLog { id: string; cardId: string; deckId: string; rating: 1 | 2 | 3 | 4; createdAt: string; before: Card; after: Card; fsrsLog: ReviewLog; scheduler: 'ts-fsrs@5.2.3' }
export interface LocalFsrsState { schemaVersion: 1; decks: LocalEngineDeck[]; cards: LocalEngineCard[]; logs: LocalReviewLog[] }
export interface LocalFsrsBackup { application: 'med2ss1-engine-fsrs'; schemaVersion: 1; exportedAt: string; state: LocalFsrsState }
const scheduler = fsrs({ request_retention: 0.9, enable_fuzz: false, enable_short_term: true });
export function emptyFsrsState(): LocalFsrsState { return { schemaVersion: 1, decks: [], cards: [], logs: [] }; }
const safePack = (value: unknown): string => { const text = identifier(value); if (!/^[a-z0-9][a-z0-9_-]{0,119}$/i.test(text)) fail('Chapitre MED_ENGINE invalide.'); return text; };
export function decodeSchedule(raw: unknown): Card {
  if (!object(raw)) fail('Échéance FSRS invalide.');
  const schedule: Card = { due: date(raw.due), stability: number(raw.stability, 0, 1_000_000), difficulty: number(raw.difficulty, 0, 10), elapsed_days: number(raw.elapsed_days, 0, 1_000_000), scheduled_days: number(raw.scheduled_days, 0, 1_000_000), learning_steps: integer(raw.learning_steps, 0, 10_000), reps: integer(raw.reps, 0, 100_000_000), lapses: integer(raw.lapses, 0, 100_000_000), state: integer(raw.state, 0, 3) };
  if (schedule.lapses > schedule.reps) fail('Historique FSRS incohérent.');
  if (raw.last_review !== undefined && raw.last_review !== null) schedule.last_review = date(raw.last_review);
  return schedule;
}
function decodeDeck(raw: unknown): LocalEngineDeck {
  if (!object(raw)) fail('Deck FSRS invalide.');
  const packId = safePack(raw.packId), id = identifier(raw.id, 'engine-deck:');
  if (id !== `engine-deck:${packId}`) fail('Ce deck ne correspond pas au chapitre indiqué.');
  const cardIds = array(raw.cardIds, 5_000).map(value => identifier(value, 'engine:'));
  if (new Set(cardIds).size !== cardIds.length) fail('Le deck contient des cartes en double.');
  return { id, packId, title: string(raw.title, 3_000), subjectId: identifier(raw.subjectId), createdAt: timestamp(raw.createdAt), cardIds, active: boolean(raw.active) };
}
function decodeCard(raw: unknown): LocalEngineCard {
  if (!object(raw)) fail('Carte FSRS invalide.');
  const id = identifier(raw.id, 'engine:'), sourceId = identifier(raw.sourceId, 'engine:'), packId = safePack(raw.packId), deckId = identifier(raw.deckId, 'engine-deck:');
  if (id !== sourceId || !id.startsWith(`engine:${packId}:`) || deckId !== `engine-deck:${packId}`) fail('La carte ne correspond pas à son chapitre.');
  return { id, sourceId, packId, deckId, noteId: identifier(raw.noteId), prompt: string(raw.prompt, 20_000), answer: string(raw.answer, 40_000), explanation: string(raw.explanation, 40_000), active: boolean(raw.active), schedule: decodeSchedule(raw.schedule) };
}
function decodeLog(raw: unknown): LocalReviewLog {
  if (!object(raw) || raw.scheduler !== 'ts-fsrs@5.2.3' || !object(raw.fsrsLog)) fail('Journal FSRS invalide.');
  const l = raw.fsrsLog;
  return { id: identifier(raw.id), cardId: identifier(raw.cardId, 'engine:'), deckId: identifier(raw.deckId, 'engine-deck:'), rating: integer(raw.rating, 1, 4) as LocalReviewLog['rating'], createdAt: timestamp(raw.createdAt), before: decodeSchedule(raw.before), after: decodeSchedule(raw.after), scheduler: 'ts-fsrs@5.2.3', fsrsLog: { rating: integer(l.rating, 1, 4), state: integer(l.state, 0, 3), due: date(l.due), stability: number(l.stability, 0, 1_000_000), difficulty: number(l.difficulty, 0, 10), elapsed_days: number(l.elapsed_days, 0, 1_000_000), last_elapsed_days: number(l.last_elapsed_days, 0, 1_000_000), scheduled_days: number(l.scheduled_days, 0, 1_000_000), learning_steps: integer(l.learning_steps, 0, 10_000), review: date(l.review) } };
}
export function decodeFsrsState(raw: unknown): LocalFsrsState {
  if (raw === undefined) return emptyFsrsState();
  if (!object(raw) || raw.schemaVersion !== 1) fail('Version des révisions FSRS non prise en charge.');
  const result: LocalFsrsState = { schemaVersion: 1, decks: array(raw.decks, 1_000).map(decodeDeck), cards: array(raw.cards).map(decodeCard), logs: array(raw.logs).map(decodeLog) };
  const decks = new Map(result.decks.map(value => [value.id, value])), cards = new Map(result.cards.map(value => [value.id, value]));
  if (decks.size !== result.decks.length || cards.size !== result.cards.length || new Set(result.logs.map(value => value.id)).size !== result.logs.length) fail('Les révisions contiennent des identifiants en double.');
  for (const card of result.cards) if (!decks.get(card.deckId)?.cardIds.includes(card.id)) fail('Une carte ne figure pas dans son deck.');
  for (const deck of result.decks) for (const id of deck.cardIds) if (cards.get(id)?.deckId !== deck.id) fail('Le deck référence une carte manquante.');
  for (const log of result.logs) if (cards.get(log.cardId)?.deckId !== log.deckId || log.fsrsLog.rating !== log.rating) fail('Un journal référence une carte invalide.');
  return result;
}
export function decodeFsrsBackup(raw: unknown): LocalFsrsState {
  const value = parseBackup(raw);
  if (!object(value) || value.application !== 'med2ss1-engine-fsrs' || value.schemaVersion !== 1) fail('Ce fichier n’est pas une sauvegarde FSRS de MED2 S1.');
  timestamp(value.exportedAt); return decodeFsrsState(value.state);
}
export function mergeFsrsStates(current: LocalFsrsState, incoming: LocalFsrsState): LocalFsrsState {
  const decks = new Map(current.decks.map(value => [value.id, value])), cards = new Map(current.cards.map(value => [value.id, value])), logs = new Map(current.logs.map(value => [value.id, value]));
  for (const value of incoming.decks) { const old = decks.get(value.id); decks.set(value.id, old ? { ...old, cardIds: unique([...old.cardIds, ...value.cardIds]), active: old.active || value.active } : value); }
  for (const value of incoming.cards) {
    const old = cards.get(value.id);
    if (!old) cards.set(value.id, value);
    else {
      const oldTime = old.schedule.last_review?.getTime() || 0, nextTime = value.schedule.last_review?.getTime() || 0;
      cards.set(value.id, { ...(nextTime > oldTime || nextTime === oldTime && value.schedule.reps > old.schedule.reps ? value : old), active: old.active || value.active });
    }
  }
  for (const value of incoming.logs) { const old = logs.get(value.id); if (old && (old.cardId !== value.cardId || old.rating !== value.rating)) fail('Deux journaux différents utilisent le même identifiant.'); if (!old) logs.set(value.id, value); }
  return decodeFsrsState({ schemaVersion: 1, decks: [...decks.values()], cards: [...cards.values()], logs: [...logs.values()] });
}
function interleave(cards: LocalEngineCard[], decks: LocalEngineDeck[]): LocalEngineCard[] {
  const subjects = new Map(decks.map(deck => [deck.id, deck.subjectId])), buckets = new Map<string, LocalEngineCard[]>();
  for (const card of cards.sort((a, b) => a.schedule.due.getTime() - b.schedule.due.getTime() || a.id.localeCompare(b.id))) { const subject = subjects.get(card.deckId) || card.packId; buckets.set(subject, [...(buckets.get(subject) || []), card]); }
  const result: LocalEngineCard[] = []; let left = cards.length;
  while (left) for (const bucket of buckets.values()) { const card = bucket.shift(); if (card) { result.push(card); left--; } }
  return result;
}
export const localFsrs = {
  async loadDecks(): Promise<LocalEngineDeck[]> { return decodeFsrsState((await readEngineDatabase()).fsrs).decks; },
  installPack(pack: EnginePack, sourceCards: EngineCard[]): Promise<{ deckId: string; count: number }> {
    const packId = safePack(pack.id); if (!Array.isArray(sourceCards) || sourceCards.length > 5_000 || sourceCards.some(card => card.packId !== packId)) fail('Les cartes ne correspondent pas au chapitre choisi.');
    const eligible = sourceCards.filter(card => !['zone', 'legend'].includes(card.type) || Boolean(card.questionIllustration && card.questionIllustration.available !== false));
    if (!eligible.length) throw new Error('Ce chapitre ne contient aucune carte révisable avec les illustrations fournies.');
    return mutateEngineDatabase(data => {
      const state = decodeFsrsState(data.fsrs), deckId = `engine-deck:${packId}`, oldDeck = state.decks.find(value => value.id === deckId), known = new Set(state.cards.map(value => value.id)); let count = 0;
      const deck: LocalEngineDeck = oldDeck || { id: deckId, packId, title: pack.title, subjectId: pack.subjects[0]?.id || 'engine:subject:other', createdAt: new Date().toISOString(), cardIds: [], active: false };
      for (const source of eligible) if (!known.has(source.id)) {
        const card = decodeCard({ id: source.id, sourceId: source.id, packId, deckId, noteId: source.noteId, prompt: source.prompt, answer: source.answer, explanation: source.explanation, schedule: createEmptyCard(), active: false });
        state.cards.push(card); deck.cardIds.push(card.id); known.add(card.id); count++;
      }
      if (!oldDeck) state.decks.push(deck);
      data.fsrs = decodeFsrsState(state); return { deckId, count };
    });
  },
  activateDeck(id: string): Promise<LocalEngineDeck> {
    identifier(id, 'engine-deck:'); return mutateEngineDatabase(data => { const state = decodeFsrsState(data.fsrs), deck = state.decks.find(value => value.id === id); if (!deck) throw new Error('Ce deck MED_ENGINE est introuvable.'); deck.active = true; for (const card of state.cards) if (card.deckId === id) card.active = true; data.fsrs = state; return { ...deck, cardIds: [...deck.cardIds] }; });
  },
  async getReviewQueue(deckId?: string, now = new Date()): Promise<LocalEngineCard[]> {
    const time = date(now).getTime(); if (deckId !== undefined) identifier(deckId, 'engine-deck:');
    const state = decodeFsrsState((await readEngineDatabase()).fsrs), active = new Set(state.decks.filter(deck => deck.active && (!deckId || deck.id === deckId)).map(deck => deck.id));
    return interleave(state.cards.filter(card => card.active && active.has(card.deckId) && card.schedule.due.getTime() <= time), state.decks);
  },
  reviewCard(cardId: string, rating: 1 | 2 | 3 | 4, now = new Date(), eventId = crypto.randomUUID()): Promise<LocalEngineCard> {
    identifier(cardId, 'engine:'); integer(rating, 1, 4); identifier(eventId); const instant = date(now);
    return mutateEngineDatabase(data => {
      const state = decodeFsrsState(data.fsrs), card = state.cards.find(value => value.id === cardId); if (!card) throw new Error('Cette carte MED_ENGINE est introuvable.');
      const existing = state.logs.find(log => log.id === eventId);
      if (existing) { if (existing.cardId !== cardId || existing.rating !== rating) throw new Error('Cet identifiant de révision a déjà été utilisé.'); return card; }
      if (!card.active || !state.decks.some(deck => deck.id === card.deckId && deck.active)) throw new Error('Active ce deck avant de commencer ses révisions.');
      if (card.schedule.due.getTime() > instant.getTime()) throw new Error('Cette carte n’est pas encore à réviser. Recharge la file de révision.');
      if (card.schedule.last_review && instant < card.schedule.last_review) throw new Error('L’horloge de cet appareil précède la dernière révision.');
      const before = decodeSchedule(card.schedule), next = scheduler.next(before, instant, rating as Grade); card.schedule = next.card;
      state.logs.push({ id: eventId, cardId, deckId: card.deckId, rating, createdAt: instant.toISOString(), before, after: decodeSchedule(next.card), fsrsLog: next.log, scheduler: 'ts-fsrs@5.2.3' });
      data.fsrs = decodeFsrsState(state); return decodeCard(card);
    });
  },
  subscribe: subscribeEngineDatabase,
  async exportState(): Promise<LocalFsrsBackup> { return { application: 'med2ss1-engine-fsrs', schemaVersion: 1, exportedAt: new Date().toISOString(), state: decodeFsrsState((await readEngineDatabase()).fsrs) }; },
  validateImportState(raw: unknown): void { decodeFsrsBackup(raw); },
  importState(raw: unknown): Promise<void> { const incoming = decodeFsrsBackup(raw); return mutateEngineDatabase(data => { data.fsrs = mergeFsrsStates(decodeFsrsState(data.fsrs), incoming); }); },
  clearProgress(): Promise<void> { return mutateEngineDatabase(data => { data.fsrs = emptyFsrsState(); }); },
};

export const loadDecks = localFsrs.loadDecks;
export const installPack = localFsrs.installPack;
export const getReviewQueue = localFsrs.getReviewQueue;
export const reviewCard = localFsrs.reviewCard;
