import { createStore, get, update } from 'idb-keyval';
import { object } from './engine-local-validation';

/** No key in the original MED2 app or in Medora is ever read or written here. */
export const ENGINE_DB_NAME = 'med2ss1-engine-v1';
export const ENGINE_DB_KEY = 'engine-state-v1';
export interface EngineLocalDatabase { schemaVersion: 1; study?: unknown; fsrs?: unknown }
const database = createStore(ENGINE_DB_NAME, 'state');
const listeners = new Set<() => void>();
let operations: Promise<unknown> = Promise.resolve();
const channel = typeof window !== 'undefined' && typeof BroadcastChannel !== 'undefined' ? new BroadcastChannel('med2ss1-engine-v1') : undefined;
function emit() { for (const listener of listeners) { try { listener(); } catch { /* A view cannot undo a committed write. */ } } }
if (channel) channel.onmessage = () => emit();
function decoded(raw: unknown): EngineLocalDatabase {
  if (raw === undefined) return { schemaVersion: 1 };
  if (!object(raw) || raw.schemaVersion !== 1) throw new Error('Les données locales MED_ENGINE sont illisibles. Conserve une sauvegarde avant de réessayer.');
  return { schemaVersion: 1, study: raw.study, fsrs: raw.fsrs };
}
function storageError(reason: unknown): Error {
  if (reason instanceof Error && reason.name === 'QuotaExceededError') return new Error('L’espace de stockage de cet iPhone est insuffisant. Exporte tes données et libère de la place avant de réessayer.');
  if (reason instanceof Error) return reason;
  return new Error('Impossible d’enregistrer MED_ENGINE sur cet appareil. Vérifie que le stockage du navigateur est autorisé.');
}
export async function readEngineDatabase(): Promise<EngineLocalDatabase> {
  await operations;
  try { return decoded(await get(ENGINE_DB_KEY, database)); } catch (reason) { throw storageError(reason); }
}
/** idb-keyval update keeps the read/modify/write inside one IDB transaction, including across tabs. */
export function mutateEngineDatabase<T>(change: (data: EngineLocalDatabase) => T): Promise<T> {
  const operation = operations.then(async () => {
    let output: T;
    try {
      await update(ENGINE_DB_KEY, (raw: unknown) => { const data = decoded(raw); output = change(data); return data; }, database);
    } catch (reason) { throw storageError(reason); }
    emit(); channel?.postMessage({ changed: true }); return output!;
  });
  operations = operation.catch(() => undefined);
  return operation;
}
export function subscribeEngineDatabase(listener: () => void): () => void { listeners.add(listener); return () => { listeners.delete(listener); }; }
