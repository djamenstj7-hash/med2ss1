import type { EnginePack } from './engine-types';

export type ReadingInline = { kind: 'text' | 'strong' | 'em' | 'code'; text: string } | { kind: 'link'; text: string; href?: string };
export type ReadingBlock =
  | { kind: 'heading'; level: number; text: string }
  | { kind: 'paragraph' | 'quote' | 'code'; text: string }
  | { kind: 'list'; ordered: boolean; items: string[] }
  | { kind: 'table'; header: string[]; rows: string[][] }
  | { kind: 'rule' };

/** The original guide is text, never executable HTML. Only explicit web links become links. */
export function readingLink(value: string): string | undefined {
  if (!/^https?:\/\//i.test(value)) return undefined;
  try {
    const url = new URL(value);
    if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) return undefined;
    return url.href;
  } catch { return undefined; }
}

export function readingInline(value: string): ReadingInline[] {
  const result: ReadingInline[] = [];
  const expression = /\[([^\]\n]+)\]\(([^)\n]+)\)|\*\*([^*\n]+)\*\*|`([^`\n]+)`|\*([^*\n]+)\*/g;
  let cursor = 0;
  for (const match of value.matchAll(expression)) {
    const at = match.index!;
    if (at > cursor) result.push({ kind: 'text', text: value.slice(cursor, at) });
    if (match[1] !== undefined) result.push({ kind: 'link', text: match[1], href: readingLink(match[2]) });
    else if (match[3] !== undefined) result.push({ kind: 'strong', text: match[3] });
    else if (match[4] !== undefined) result.push({ kind: 'code', text: match[4] });
    else result.push({ kind: 'em', text: match[5] });
    cursor = at + match[0].length;
  }
  if (cursor < value.length) result.push({ kind: 'text', text: value.slice(cursor) });
  return result;
}

function cells(line: string): string[] {
  const trimmed = line.trim().replace(/^\|/, '').replace(/\|$/, '');
  const result: string[] = []; let cell = '', escaped = false;
  for (const character of trimmed) {
    if (escaped) { cell += character; escaped = false; }
    else if (character === '\\') escaped = true;
    else if (character === '|') { result.push(cell.trim()); cell = ''; }
    else cell += character;
  }
  if (escaped) cell += '\\';
  result.push(cell.trim());
  return result;
}
const separator = (line: string) => cells(line).every(cell => /^:?-{3,}:?$/.test(cell));
const listLine = (line: string) => /^\s*(?:[-+*]|\d+[.)])\s+/.test(line);

export function parseReadingMarkdown(value: string): ReadingBlock[] {
  const lines = value.replace(/\r\n?/g, '\n').split('\n');
  const result: ReadingBlock[] = [];
  for (let index = 0; index < lines.length;) {
    const line = lines[index];
    if (!line.trim()) { index++; continue; }
    const heading = /^(#{1,6})\s+(.+?)\s*#*\s*$/.exec(line);
    if (heading) { result.push({ kind: 'heading', level: heading[1].length, text: heading[2] }); index++; continue; }
    if (/^\s*(```|~~~)/.test(line)) {
      const marker = line.trim().slice(0, 3); const contents: string[] = []; index++;
      while (index < lines.length && !lines[index].trim().startsWith(marker)) contents.push(lines[index++]);
      if (index < lines.length) index++;
      result.push({ kind: 'code', text: contents.join('\n') }); continue;
    }
    if (/^\s*(?:-{3,}|\*{3,}|_{3,})\s*$/.test(line)) { result.push({ kind: 'rule' }); index++; continue; }
    if (line.includes('|') && index + 1 < lines.length && separator(lines[index + 1])) {
      const header = cells(line), rows: string[][] = []; index += 2;
      while (index < lines.length && lines[index].trim() && lines[index].includes('|')) rows.push(cells(lines[index++]));
      result.push({ kind: 'table', header, rows }); continue;
    }
    if (listLine(line)) {
      const ordered = /^\s*\d+[.)]\s+/.test(line), items: string[] = [];
      while (index < lines.length && listLine(lines[index]) && /^\s*\d+[.)]\s+/.test(lines[index]) === ordered) {
        items.push(lines[index++].replace(/^\s*(?:[-+*]|\d+[.)])\s+/, ''));
      }
      result.push({ kind: 'list', ordered, items }); continue;
    }
    if (/^\s*>/.test(line)) {
      const contents: string[] = [];
      while (index < lines.length && /^\s*>/.test(lines[index])) contents.push(lines[index++].replace(/^\s*>\s?/, ''));
      result.push({ kind: 'quote', text: contents.join('\n') }); continue;
    }
    const contents = [line]; index++;
    while (index < lines.length && lines[index].trim() && !/^(#{1,6})\s|^\s*(```|~~~)|^\s*>/.test(lines[index]) && !listLine(lines[index]) && !/^\s*(?:-{3,}|\*{3,}|_{3,})\s*$/.test(lines[index]) && !(lines[index].includes('|') && index + 1 < lines.length && separator(lines[index + 1]))) contents.push(lines[index++]);
    result.push({ kind: 'paragraph', text: contents.join('\n') });
  }
  return result;
}

/** Explicitly reviewed links; similar titles are not treated as equivalent sources. */
export const engineExistingCourses: Readonly<Record<string, { id: string; title: string }>> = {
  semio_abord: { id: 'cm-de715b67886d4881', title: 'Abord et examen clinique du malade' },
  sang_hemogramme: { id: 'cm-b60fb75949097685', title: 'Myélogramme et hémogramme — lire les indices du sang' },
};

export function enginePdfCourseId(packId: string): string {
  if (!/^[a-z0-9][a-z0-9_-]{0,119}$/i.test(packId)) throw new Error('Identifiant de chapitre invalide.');
  return `engine:${packId}`;
}

export function readingReferences(pack: EnginePack) {
  return pack.source_documents.map(source => ({
    id: source.id,
    title: source.titre || source.id,
    kind: typeof source.kind === 'string' ? source.kind.toUpperCase() : 'DOCUMENT',
    path: source.chemin_relatif,
    author: source.auteur,
    note: source.note,
    status: 'reference-only' as const,
  }));
}
