import { mutateEngineDatabase, readEngineDatabase } from './engine-local-db';
import { fail, object, parseBackup, timestamp } from './engine-local-validation';
import { decodeStudyBackup, decodeStudyState, emptyStudyState, mergeStudyStates, type StudyBackup } from './study';
import { decodeFsrsBackup, decodeFsrsState, emptyFsrsState, mergeFsrsStates, type LocalFsrsBackup } from './local-fsrs';
export { MAX_ENGINE_BACKUP_BYTES } from './engine-local-validation';

export interface EngineBackup { application: 'med2ss1-engine'; schemaVersion: 1; exportedAt: string; study: StudyBackup; fsrs: LocalFsrsBackup }
/** Both sections come from one database read, rather than two different moments. */
export async function exportEngineBackup(): Promise<EngineBackup> {
  const data = await readEngineDatabase(), exportedAt = new Date().toISOString();
  return { application: 'med2ss1-engine', schemaVersion: 1, exportedAt, study: { application: 'med2ss1-engine-study', schemaVersion: 1, exportedAt, state: decodeStudyState(data.study) }, fsrs: { application: 'med2ss1-engine-fsrs', schemaVersion: 1, exportedAt, state: decodeFsrsState(data.fsrs) } };
}
/** Full validation precedes one atomic write. An invalid FSRS section cannot partly import study data. */
export async function importEngineBackup(raw: unknown): Promise<void> {
  const value = parseBackup(raw);
  if (!object(value) || value.application !== 'med2ss1-engine' || value.schemaVersion !== 1) fail('Ce fichier n’est pas une sauvegarde MED_ENGINE de MED2 S1.');
  timestamp(value.exportedAt); const study = decodeStudyBackup(value.study), fsrs = decodeFsrsBackup(value.fsrs);
  await mutateEngineDatabase(data => {
    const nextStudy = mergeStudyStates(decodeStudyState(data.study), study), nextFsrs = mergeFsrsStates(decodeFsrsState(data.fsrs), fsrs);
    data.study = nextStudy; data.fsrs = nextFsrs;
  });
}
/** Only this module’s sections are reset. Existing MED2 results/PDF and Medora databases remain untouched. */
export async function clearEngineProgress(): Promise<void> { await mutateEngineDatabase(data => { data.study = emptyStudyState(); data.fsrs = emptyFsrsState(); }); }
