import type { EngineZone } from './engine-types';

export interface ClozePart { text: string; hidden: boolean; answer?: string; hint?: string }

/** One deletion index can occur several times; all of its occurrences stay hidden. */
export function parseEngineCloze(text: string, target: number, reveal = false): ClozePart[] {
  const expression = /{{c(\d+)::([\s\S]*?)}}/g;
  const parts: ClozePart[] = [];
  let end = 0;
  for (const match of text.matchAll(expression)) {
    if (match.index! > end) parts.push({ text: text.slice(end, match.index), hidden: false });
    const [answer, ...hints] = match[2].split('::');
    const hidden = !reveal && Number(match[1]) === target;
    parts.push({ text: hidden ? hints.join('::') || '…' : answer, hidden, answer, hint: hints.join('::') || undefined });
    end = match.index! + match[0].length;
  }
  if (end < text.length) parts.push({ text: text.slice(end), hidden: false });
  return parts.length ? parts : [{ text, hidden: false }];
}

export function engineExactChoices(selected: number[], expected: number[]): boolean {
  const actual = new Set(selected);
  const correct = new Set(expected);
  return actual.size === correct.size && [...actual].every((index) => correct.has(index));
}

function distanceToLine(x: number, y: number, x1: number, y1: number, x2: number, y2: number) {
  const dx = x2 - x1, dy = y2 - y1;
  const t = Math.max(0, Math.min(1, ((x - x1) * dx + (y - y1) * dy) / (dx * dx + dy * dy || 1)));
  return Math.hypot(x - x1 - t * dx, y - y1 - t * dy);
}

/** Coordinates are source-image units. null means unsupported/malformed, never incorrect. */
export function pointInEngineZone(point: { x: number; y: number }, zone: EngineZone, tolerance = 0): boolean | null {
  const a = zone.coords || [];
  const { x, y } = point;
  if (![x, y, ...a].every(Number.isFinite) || !a.length) return null;
  const t = Number.isFinite(tolerance) ? Math.max(0, tolerance) : 0;
  if (zone.forme === 'rect' && a.length === 4) {
    return x >= Math.min(a[0], a[2]) - t && x <= Math.max(a[0], a[2]) + t && y >= Math.min(a[1], a[3]) - t && y <= Math.max(a[1], a[3]) + t;
  }
  if (zone.forme === 'circle' && a.length === 3 && a[2] > 0) return Math.hypot(x - a[0], y - a[1]) <= a[2] + t;
  if (zone.forme === 'poly' && a.length >= 6 && a.length % 2 === 0) {
    let inside = false;
    for (let i = 0, j = a.length - 2; i < a.length; j = i, i += 2) {
      if (distanceToLine(x, y, a[j], a[j + 1], a[i], a[i + 1]) <= Math.max(t, 0.000001)) return true;
      if ((a[i + 1] > y) !== (a[j + 1] > y) && x < (a[j] - a[i]) * (y - a[i + 1]) / (a[j + 1] - a[i + 1]) + a[i]) inside = !inside;
    }
    return inside;
  }
  return null;
}

export function engineZoneCenter(zone: EngineZone): { x: number; y: number } | undefined {
  const a = zone.coords || [];
  if (!a.length || !a.every(Number.isFinite)) return undefined;
  if (zone.forme === 'circle' && a.length === 3) return { x: a[0], y: a[1] };
  const xs = a.filter((_, i) => i % 2 === 0), ys = a.filter((_, i) => i % 2 !== 0);
  if (!ys.length) return undefined;
  const bounds = [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)];
  const center = { x: (bounds[0] + bounds[2]) / 2, y: (bounds[1] + bounds[3]) / 2 };
  if (pointInEngineZone(center, zone)) return center;
  for (let row = 1; row < 16; row++) for (let column = 1; column < 16; column++) {
    const p = { x: bounds[0] + (bounds[2] - bounds[0]) * column / 16, y: bounds[1] + (bounds[3] - bounds[1]) * row / 16 };
    if (pointInEngineZone(p, zone)) return p;
  }
  return undefined;
}

/** Opaque sandbox plus a document CSP: the illustration never gets Medora's origin. */
export function buildEngineDiagramDocument(html: string): string {
  const policy = "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data: blob:; font-src 'none'; connect-src 'none'; media-src 'none'; object-src 'none'; frame-src 'none'; base-uri 'none'; form-action 'none'";
  const header = '<meta http-equiv="Content-Security-Policy" content="' + policy + '"><meta name="viewport" content="width=device-width, initial-scale=1"><style>html,body{box-sizing:border-box;max-width:100%;overflow-wrap:anywhere}*,*:before,*:after{box-sizing:border-box}body{margin:0!important;padding:12px!important;font-size:16px}svg,img,canvas{max-width:100%;height:auto}button,input,select{min-height:44px}button{touch-action:manipulation}</style>';
  const cleaned = html.replace(/<meta\b[^>]*http-equiv\s*=\s*["']?refresh\b[^>]*>/gi, '').replace(/<base\b[^>]*>/gi, '');
  return /<head\b[^>]*>/i.test(cleaned) ? cleaned.replace(/<head\b[^>]*>/i, '$&' + header) : '<!doctype html><html lang="fr"><head>' + header + '</head><body>' + cleaned + '</body></html>';
}
