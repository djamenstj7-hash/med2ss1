/** Bounded, explicit decoding shared by the local MED_ENGINE stores. */
export const MAX_RECORDS = 100_000;
/** One shared byte limit for downloaded backups and imported files (100 MiB). */
export const MAX_ENGINE_BACKUP_BYTES = 100 * 1024 * 1024;
export function object(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}
export function fail(message = 'La sauvegarde MED_ENGINE est invalide.'): never { throw new Error(message); }
export function identifier(value: unknown, prefix?: string): string {
  if (typeof value !== 'string' || !value || value.length > 550 || /[\u0000-\u001f]/.test(value) || ['__proto__', 'prototype', 'constructor'].includes(value) || prefix && !value.startsWith(prefix)) fail('Identifiant MED_ENGINE invalide.');
  return value;
}
export function string(value: unknown, max = 40_000): string {
  if (typeof value !== 'string' || value.length > max) fail('Texte MED_ENGINE invalide ou trop long.');
  return value;
}
export function number(value: unknown, min = 0, max = 1_000_000_000): number {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < min || value > max) fail('Valeur numérique MED_ENGINE invalide.');
  return value;
}
export function integer(value: unknown, min = 0, max = 1_000_000_000): number {
  const result = number(value, min, max); if (!Number.isInteger(result)) fail(); return result;
}
export function boolean(value: unknown): boolean { if (typeof value !== 'boolean') fail(); return value; }
export function date(value: unknown): Date {
  if (!(value instanceof Date) && typeof value !== 'string') fail('Date MED_ENGINE invalide.');
  const parsed = new Date(value); if (!Number.isFinite(parsed.getTime()) || parsed.getUTCFullYear() < 1970 || parsed.getUTCFullYear() > 9999) fail('Date MED_ENGINE invalide.'); return parsed;
}
export function timestamp(value: unknown): string { return date(value).toISOString(); }
export function calendar(value: unknown): string {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value) || timestamp(`${value}T12:00:00.000Z`).slice(0, 10) !== value) fail('Date d’examen invalide.'); return value;
}
export function array(value: unknown, max = MAX_RECORDS): unknown[] { if (!Array.isArray(value) || value.length > max) fail('La sauvegarde contient trop d’éléments ou un tableau invalide.'); return value; }
export function record(value: unknown, max = MAX_RECORDS): Record<string, unknown> {
  if (!object(value) || Object.keys(value).length > max) fail();
  for (const key of Object.keys(value)) identifier(key);
  return value;
}
export function unique<T>(values: T[]): T[] { return [...new Set(values)]; }
/** Count UTF-8 bytes without allocating a second byte array for a large JSON file. */
export function backupFitsByteLimit(value: string, limit = MAX_ENGINE_BACKUP_BYTES): boolean {
  if (value.length > limit) return false;
  // A UTF-16 code unit needs at most three UTF-8 bytes (a surrogate pair needs four).
  if (value.length <= Math.floor(limit / 3)) return true;
  let bytes = 0;
  for (let index = 0; index < value.length; index++) {
    const code = value.charCodeAt(index);
    if (code <= 0x7f) bytes++;
    else if (code <= 0x7ff) bytes += 2;
    else if (code >= 0xd800 && code <= 0xdbff && index + 1 < value.length && value.charCodeAt(index + 1) >= 0xdc00 && value.charCodeAt(index + 1) <= 0xdfff) { bytes += 4; index++; }
    else bytes += 3;
    if (bytes > limit) return false;
  }
  return true;
}
export function parseBackup(value: unknown): unknown {
  if (typeof value !== 'string') return value;
  if (!backupFitsByteLimit(value)) fail('La sauvegarde dépasse la limite de 100 Mio.');
  try { return JSON.parse(value); } catch { return fail('Le fichier ne contient pas une sauvegarde JSON valide.'); }
}
export function jsonCopy<T>(value: T): T { return JSON.parse(JSON.stringify(value)) as T; }
