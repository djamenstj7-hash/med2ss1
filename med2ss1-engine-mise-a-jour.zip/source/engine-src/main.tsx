import { Component, useEffect, useState, type ErrorInfo, type ReactNode } from 'react';
import { createRoot, type Root } from 'react-dom/client';
import { BookOpen, CalendarClock, Database, Check } from 'lucide-react';
import EngineLibrary from './components/EngineLibrary';
import EngineReview from './components/EngineReview';
import EngineDataPanel from './components/EngineDataPanel';
import { engineCards, type EnginePack } from './lib/engine';
import { localFsrs } from './lib/local-fsrs';
import './theme.css';

class EngineBoundary extends Component<{ children: ReactNode }, { error: string }> {
  state = { error: '' };
  static getDerivedStateFromError(error: Error) { return { error: error.message || 'Le module n’a pas pu s’afficher.' }; }
  componentDidCatch(_error: Error, _info: ErrorInfo) { /* The message stays on this device; no telemetry. */ }
  render() {
    return this.state.error ? <div className="med2-engine-root"><div className="error-banner" role="alert"><h2>MED_ENGINE n’a pas pu s’ouvrir</h2><p>{this.state.error}</p><p>Reviens dans Cours, puis réessaie avec une connexion. Les données MED2 S1 et tes PDF restent dans leur espace habituel.</p></div></div> : this.props.children;
  }
}

type View = 'library' | 'review' | 'data';
function EngineApp() {
  const [view, setView] = useState<View>('library');
  const [deckId, setDeckId] = useState<string>();
  const [message, setMessage] = useState('');
  const [due, setDue] = useState<number>();
  useEffect(() => {
    let live = true;
    const refresh = () => { void localFsrs.getReviewQueue().then(cards => { if (live) setDue(cards.length); }).catch(() => { if (live) setDue(undefined); }); };
    refresh(); const unsubscribe = localFsrs.subscribe(refresh);
    return () => { live = false; unsubscribe(); };
  }, []);
  async function install(pack: EnginePack) {
    const result = await localFsrs.installPack(pack, engineCards(pack));
    setDeckId(result.deckId);
    setMessage(`${result.count} cartes disponibles dans le deck « ${pack.title} ». Relis les réponses, puis active ce deck pour commencer ses révisions espacées.`);
    setView('review');
    window.scrollTo({ top: 0, behavior: 'auto' });
  }
  function navigate(next: View) { setView(next); setMessage(''); window.scrollTo({ top: 0, behavior: 'auto' }); }
  return <div className="med2-engine-root" onKeyDown={event => event.stopPropagation()}>
    <nav className="me-module-nav" aria-label="Navigation MED_ENGINE">
      <button type="button" aria-current={view === 'library' ? 'page' : undefined} onClick={() => navigate('library')}><BookOpen size={18} /><span>Bibliothèque</span></button>
      <button type="button" aria-current={view === 'review' ? 'page' : undefined} onClick={() => navigate('review')}><CalendarClock size={18} /><span>Révisions{due ? <span className="me-count">{due}</span> : ''}</span></button>
      <button type="button" aria-current={view === 'data' ? 'page' : undefined} onClick={() => navigate('data')}><Database size={18} /><span>Sauvegarde et hors ligne</span></button>
    </nav>
    {message && <div className="info-banner" role="status"><Check size={18} /><span>{message}</span><button type="button" className="text-button" onClick={() => setMessage('')}>Fermer</button></div>}
    {view === 'library' && <EngineLibrary onInstallDeck={install} />}
    {view === 'review' && <EngineReview initialDeckId={deckId} onBrowse={() => navigate('library')} />}
    {view === 'data' && <EngineDataPanel />}
  </div>;
}

let activeRoot: Root | undefined;
let activeElement: HTMLElement | undefined;
/** Called by the existing MED2 S1 view; no second application or service worker is installed. */
export function mount(element: HTMLElement): () => void {
  unmount();
  activeElement = element;
  activeRoot = createRoot(element);
  activeRoot.render(<EngineBoundary><EngineApp /></EngineBoundary>);
  return () => { if (activeElement === element) unmount(); };
}
export function unmount() { activeRoot?.unmount(); activeRoot = undefined; activeElement = undefined; }
