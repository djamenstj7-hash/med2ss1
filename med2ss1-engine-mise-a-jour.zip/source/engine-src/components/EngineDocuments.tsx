import { useMemo, useState } from 'react';
import { BookOpen, ExternalLink, FileText } from 'lucide-react';
import type { EnginePack } from '../lib/engine-types';
import { documentMatchesQuery, documentSize, engineDocumentCounts, engineDocumentsForPack, engineOtherSubjectDocuments, engineSourceDocuments, type EngineSourceDocument } from '../lib/engine-documents';
import '../engine-documents.css';

interface Props { pack?: EnginePack; onAddPersonalPdf?: () => void }

export function EngineDocumentLink({ document }: { document: EngineSourceDocument }) {
  return <a className="secondary engine-document-link" href={document.url} target="_blank" rel="noopener noreferrer"><BookOpen size={17} aria-hidden="true" /><span>Lire sur Drive<span className="sr-only"> : {document.title} (nouvel onglet)</span></span><ExternalLink size={16} aria-hidden="true" /></a>;
}

function DocumentList({ documents }: { documents: EngineSourceDocument[] }) {
  const [limit, setLimit] = useState(24);
  return <><div className="engine-document-list">{documents.slice(0, limit).map(document => <article className="panel engine-document" key={document.id} data-source-document={document.id}><div className="engine-document-tags"><span className="soft-badge">{document.ue}</span><span>{document.kind} · {document.mime === 'application/pdf' ? 'PDF' : 'Document'} · {documentSize(document.size)}</span></div><h4>{document.title}</h4><EngineDocumentLink document={document} /></article>)}</div>{documents.length > limit && <button type="button" className="secondary engine-document-more" onClick={() => setLimit(value => value + 24)}>Afficher les documents suivants ({documents.length - limit} restants)</button>}</>;
}

export default function EngineDocuments({ pack, onAddPersonalPdf }: Props) {
  const [query, setQuery] = useState(''); const [ue, setUe] = useState('all'); const [kind, setKind] = useState('all');
  const direct = useMemo(() => pack ? engineDocumentsForPack(pack) : [], [pack]);
  const other = useMemo(() => pack ? engineOtherSubjectDocuments(pack) : engineSourceDocuments, [pack]);
  const filtered = useMemo(() => other.filter(file => (ue === 'all' || file.ue === ue) && (kind === 'all' || file.kind === kind) && documentMatchesQuery(file, query)), [other, query, ue, kind]);
  return <section className="engine-documents" aria-label={pack ? 'Cours du Drive pour ce chapitre' : 'Tous les cours du Drive'}>
    <header className="engine-document-heading"><FileText size={24} aria-hidden="true" /><div><h2>Cours du Drive</h2><p>{engineDocumentCounts.pdf} PDF et {engineDocumentCounts.documents - engineDocumentCounts.pdf} documents complémentaires, classés par UE.</p></div></header>
    <p className="engine-document-online">Les cours s’ouvrent dans le lecteur Google Drive, dans un nouvel onglet. Une connexion est nécessaire ; Drive peut demander de te connecter au compte qui y a accès. Pour les lire hors connexion dans MED2 S1, enregistre le PDF dans Fichiers puis importe-le dans « Mes PDF ».</p>
    {onAddPersonalPdf && <button type="button" className="text-button" onClick={onAddPersonalPdf}>Importer un PDF de ce chapitre sur mon iPhone</button>}
    {pack && <section className="engine-direct-documents"><h3>Documents retrouvés dans les références de ce chapitre</h3>{direct.length ? <><p className="small-muted">{direct.length} document(s) retrouvé(s) par leur nom de fichier d’origine. Les autres éditions et annales citées restent distinctes.</p><DocumentList documents={direct} /></> : <p>Aucun fichier du Drive ne correspond exactement aux noms de documents cités pour ce chapitre. Les documents de la même UE ci-dessous restent accessibles pour consultation.</p>}</section>}
    <section className="engine-all-documents"><h3>{pack ? 'Autres documents de cette UE' : 'Tous les documents'}</h3>{pack && <p className="small-muted">Ces documents sont regroupés par matière. Ce regroupement ne signifie pas qu’ils correspondent aux sources de ce chapitre.</p>}<div className="engine-document-filters"><label className="field"><span>Rechercher un cours</span><input type="search" aria-label="Rechercher dans les cours du Drive" value={query} onChange={event => setQuery(event.target.value)} placeholder="Titre du cours, matière…" /></label>{!pack && <label className="field"><span>UE</span><select aria-label="UE des cours du Drive" value={ue} onChange={event => setUe(event.target.value)}><option value="all">Toutes les UE</option>{[...new Set(other.map(file => file.ue))].sort((a, b) => a.localeCompare(b, 'fr')).map(value => <option value={value} key={value}>{value}</option>)}</select></label>}<label className="field"><span>Enseignement</span><select aria-label="Type des cours du Drive" value={kind} onChange={event => setKind(event.target.value)}><option value="all">CM et ED</option>{[...new Set(other.map(file => file.kind))].sort().map(value => <option value={value} key={value}>{value}</option>)}</select></label></div><p className="small-muted" aria-live="polite">{filtered.length} document(s)</p>{filtered.length ? <DocumentList key={`${pack?.id || 'all'}:${query}:${ue}:${kind}`} documents={filtered} /> : <p>Aucun document ne correspond à ces filtres.</p>}</section>
  </section>;
}
