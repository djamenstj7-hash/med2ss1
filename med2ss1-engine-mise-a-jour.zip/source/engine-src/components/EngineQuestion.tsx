import { useEffect, useId, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { AlertCircle, Check, CheckCheck, ChevronDown, Expand, LoaderCircle, RotateCcw, X } from 'lucide-react';
import type { EngineCard, EngineDiagram, EngineIllustration, EnginePack, EngineZone } from '../lib/engine-types';
import { engineAssetUrl } from '../lib/engine';
import { buildEngineDiagramDocument, engineExactChoices, engineZoneCenter, parseEngineCloze, pointInEngineZone } from '../lib/engine-question';
import '../engine-question.css';

export interface EngineAnswer {
  correct: boolean;
  selected?: number[];
  responseText?: string;
  confidence?: 'sure' | 'hesitant' | 'guess';
  point?: { x: number; y: number };
  selfAssessed?: boolean;
  /** False for a response saved before its explicit self-assessment. */
  graded?: boolean;
}
export interface EngineQuestionProps {
  pack: EnginePack;
  card: EngineCard;
  onAnswered?: (result: EngineAnswer) => void;
  initialAnswer?: EngineAnswer;
  disabled?: boolean;
  reveal?: boolean;
  mode?: 'practice' | 'exam';
}
const typeLabels: Record<string, string> = { qrm: 'QRM', qru: 'QRU', basic: 'Rappel actif', cloze: 'Texte à trous', qroc: 'QROC', lexique: 'Lexique', zone: 'Repérage', legend: 'Planche à légender' };
const asText = (value: unknown): string => typeof value === 'string' ? value : typeof value === 'number' ? String(value) : value == null ? '' : JSON.stringify(value);
const asObjects = (value: unknown): Record<string, unknown>[] => Array.isArray(value) ? value.filter(item => item && typeof item === 'object') : [];

/** The supported emphasis convention never interprets source content as HTML. */
export function EngineText({ text }: { text: string }) {
  return <>{String(text).split(/(\*\*[\s\S]+?\*\*)/g).map((part, index) => part.startsWith('**') && part.endsWith('**') ? <strong key={index}>{part.slice(2, -2)}</strong> : part)}</>;
}

function ZoomFigure({ figure, onClose }: { figure: EngineIllustration; onClose: () => void }) {
  const dialog = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const prior = document.activeElement as HTMLElement | null;
    const element = dialog.current;
    if (element && !element.open) element.showModal();
    return () => { if (element?.open) element.close(); prior?.focus?.(); };
  }, []);
  return createPortal(<dialog ref={dialog} className="eq-zoom" aria-label={figure.caption || 'Illustration agrandie'} onCancel={event => { event.preventDefault(); onClose(); }} onKeyDown={event => { if (event.key === 'Escape') { event.stopPropagation(); event.preventDefault(); onClose(); } }}>
    <header><strong>Illustration du cours</strong><button type="button" autoFocus onClick={onClose} aria-label="Fermer l’illustration"><X size={22} /></button></header>
    <div className="eq-zoom-image"><img src={engineAssetUrl(figure.path)} alt={figure.caption || 'Illustration médicale source'} /></div>
    {figure.caption && <p>{figure.caption}</p>}<small>Écartez deux doigts pour agrandir dans Safari.</small>
  </dialog>, document.body);
}

function EngineFigure({ figure, label = 'Illustration', onUnavailable }: { figure?: EngineIllustration; label?: string; onUnavailable?: () => void }) {
  const [zoom, setZoom] = useState(false);
  const [failed, setFailed] = useState(false);
  useEffect(() => { setFailed(false); setZoom(false); }, [figure?.path]);
  if (!figure) return null;
  if (figure.available === false) return <p className="eq-notice"><AlertCircle size={17} />Illustration absente des fichiers fournis. Sa référence est conservée : {figure.caption || figure.path}.</p>;
  if (failed) return <p className="eq-notice"><AlertCircle size={17} />Illustration indisponible sur cet appareil. Sa référence est conservée : {figure.caption || figure.path}.</p>;
  return <figure className="eq-figure"><button type="button" className="eq-figure-button" onClick={() => setZoom(true)} aria-label={'Agrandir : ' + (figure.caption || label)}><img loading="lazy" src={engineAssetUrl(figure.path)} alt={figure.caption || label} onError={() => { setFailed(true); onUnavailable?.(); }} /><span><Expand size={15} />Agrandir</span></button>{figure.caption && <figcaption>{figure.caption}</figcaption>}{zoom && <ZoomFigure figure={figure} onClose={() => setZoom(false)} />}</figure>;
}

function Shape({ zone }: { zone: EngineZone }) {
  const p = zone.coords || [];
  if (zone.forme === 'rect' && p.length === 4) return <rect x={Math.min(p[0], p[2])} y={Math.min(p[1], p[3])} width={Math.abs(p[2] - p[0])} height={Math.abs(p[3] - p[1])} />;
  if (zone.forme === 'circle' && p.length === 3) return <circle cx={p[0]} cy={p[1]} r={p[2]} />;
  if (zone.forme === 'poly' && p.length >= 6 && p.length % 2 === 0) return <polygon points={p.map((n, i) => String(n) + (i % 2 === 0 ? ',' : ' ')).join('')} />;
  return null;
}

function ZoneQuestion({ card, point, setPoint, shown, locked, onUnavailable }: { card: EngineCard; point?: { x: number; y: number }; setPoint: (point: { x: number; y: number }) => void; shown: boolean; locked: boolean; onUnavailable: () => void }) {
  const width = Number(card.fields.largeur) || 900, height = Number(card.fields.hauteur) || 600;
  const zones = asObjects(card.fields.zones) as unknown as EngineZone[];
  const [failed, setFailed] = useState(false);
  const [zoom, setZoom] = useState(false);
  const figure = card.questionIllustration;
  useEffect(() => setFailed(false), [card.id]);
  if (!figure || figure.available === false) return <p className="eq-notice">L’image de repérage n’est pas fournie. Le corrigé reste consultable, sans notation du repérage.</p>;
  return <div className="eq-zone">
    <p className="eq-help">Touchez l’emplacement sur l’image, puis validez. Les repères numérotés permettent aussi de répondre au clavier.</p>
    {!failed && <svg className={'eq-zone-canvas ' + (locked ? 'is-locked' : '')} viewBox={'0 0 ' + width + ' ' + height} role="img" aria-label={figure.caption || 'Schéma de repérage'} onPointerDown={event => {
      if (locked) return;
      const bounds = event.currentTarget.getBoundingClientRect();
      if (!bounds.width || !bounds.height) return;
      setPoint({ x: Math.max(0, Math.min(width, (event.clientX - bounds.left) * width / bounds.width)), y: Math.max(0, Math.min(height, (event.clientY - bounds.top) * height / bounds.height)) });
    }}>
      <image href={engineAssetUrl(figure.path)} x={0} y={0} width={width} height={height} onError={() => { setFailed(true); onUnavailable(); }} />
      {shown && card.zone && <g className="eq-zone-correct"><Shape zone={card.zone} /></g>}
      {zones.map((zone, index) => { const center = engineZoneCenter(zone); return center ? <g key={zone.cle || index} className="eq-zone-number" transform={'translate(' + center.x + ',' + center.y + ')'}><circle r={Math.max(width / 52, 12)} /><text textAnchor="middle" dominantBaseline="central" fontSize={Math.max(width / 48, 12)}>{index + 1}</text></g> : null; })}
      {point && <g className="eq-zone-point" transform={'translate(' + point.x + ',' + point.y + ')'}><circle r={Math.max(width / 48, 13)} /><path d="M-8 0H8M0-8V8" /></g>}
    </svg>}
    {!failed && <button type="button" className="eq-secondary eq-zone-zoom" onClick={() => setZoom(true)}><Expand size={16} />Agrandir le schéma</button>}
    {zoom && <ZoomFigure figure={figure} onClose={() => setZoom(false)} />}
    {failed && <p className="eq-notice"><AlertCircle size={17} />L’image ne s’est pas chargée. Réessayez en ligne ou utilisez la comparaison au corrigé.</p>}
    <details className="eq-zone-access"><summary>Répondre avec les repères numérotés</summary><div>{zones.map((zone, index) => { const center = engineZoneCenter(zone); return center && <button key={zone.cle || index} type="button" disabled={locked} className={point && Math.hypot(point.x - center.x, point.y - center.y) < 1 ? 'is-selected' : ''} onClick={() => setPoint(center)}>Repère {index + 1}</button>; })}</div></details>
    {figure.caption && <p className="eq-help">{figure.caption}</p>}
  </div>;
}

function SourceReference({ value, pack, label = 'Source' }: { value: unknown; pack: EnginePack; label?: string }) {
  if (!value) return null;
  if (Array.isArray(value)) return <>{value.map((item, index) => <SourceReference key={index} value={item} pack={pack} label={label} />)}</>;
  if (typeof value !== 'object') return <p>{label} : {asText(value)}</p>;
  const source = value as Record<string, unknown>;
  const document = pack.source_documents.find(item => item.id === source.source_id);
  const details = [source.page != null && 'p. ' + asText(source.page), source.pages != null && 'p. ' + asText(source.pages), asText(source.session_examen), asText(source.numero), asText(source.extrait)].filter(Boolean);
  return <div className="eq-source-ref"><strong>{label} : {document?.titre || asText(source.source_id) || 'référence du paquet'}</strong>{details.length > 0 && <span>{details.join(' · ')}</span>}{document?.auteur && <span>{document.auteur}</span>}{document?.chemin_relatif && <span>Référence d’origine : {document.chemin_relatif}</span>}{document?.note && <span>{document.note}</span>}</div>;
}

export default function EngineQuestion({ pack, card, onAnswered, initialAnswer, disabled = false, reveal = false, mode = 'practice' }: EngineQuestionProps) {
  const uid = useId();
  const [selected, setSelected] = useState(initialAnswer?.selected || []);
  const [response, setResponse] = useState(initialAnswer?.responseText || '');
  const [confidence, setConfidence] = useState<EngineAnswer['confidence']>(initialAnswer?.confidence);
  const [point, setPoint] = useState(initialAnswer?.point);
  const [submitted, setSubmitted] = useState(Boolean(initialAnswer));
  const [showModel, setShowModel] = useState(false);
  const [outcome, setOutcome] = useState<boolean | undefined>(initialAnswer?.graded === false ? undefined : initialAnswer?.correct);
  const [none, setNone] = useState(false);
  const [questionImageFailed, setQuestionImageFailed] = useState(false);
  useEffect(() => { setSelected(initialAnswer?.selected || []); setResponse(initialAnswer?.responseText || ''); setConfidence(initialAnswer?.confidence); setPoint(initialAnswer?.point); setSubmitted(Boolean(initialAnswer)); setShowModel(false); setOutcome(initialAnswer?.graded === false ? undefined : initialAnswer?.correct); setNone(false); setQuestionImageFailed(false); }, [card.id]); // Parent keys persisted answers by card ID.
  const missingRequiredVisual = ['zone', 'legend'].includes(card.type) && (!card.questionIllustration || card.questionIllustration.available === false || questionImageFailed);
  const choice = ['qrm', 'qru', 'legend'].includes(card.type) && card.options.length > 0 && !missingRequiredVisual;
  const multiple = card.type === 'qrm';
  const shown = reveal || showModel || (submitted && mode === 'practice');
  const locked = disabled || submitted || reveal || showModel;
  const zoneGrade = card.type === 'zone' && point && card.zone ? pointInEngineZone(point, card.zone, Number(card.fields.tolerance) || 0) : null;
  const zoneReady = card.type === 'zone' && !missingRequiredVisual && point && zoneGrade !== null;
  const free = !choice && !zoneReady;
  const result = choice ? engineExactChoices(selected, card.correct) : zoneReady ? zoneGrade : outcome;
  const warning = card.tags.includes('a-relire') || card.tags.some(tag => /non[- ]v[ée]rifi/i.test(tag));
  const confidenceLocked = disabled || submitted || reveal || showModel;
  function commit(correct: boolean, selfAssessed = false, graded = true) {
    if (submitted && (initialAnswer?.graded !== false || outcome !== undefined)) return;
    setSubmitted(true); setOutcome(graded ? correct : undefined);
    onAnswered?.({ correct, selected: [...selected], responseText: graded ? response.trim() || undefined : response.trim(), confidence, point, selfAssessed, graded });
  }
  function validate() {
    if (disabled || submitted || reveal) return;
    if (missingRequiredVisual) { setShowModel(mode !== 'exam'); commit(false, false, false); return; }
    if (choice) commit(engineExactChoices(selected, card.correct));
    else if (zoneReady) commit(Boolean(zoneGrade));
    else if (mode === 'exam') commit(false, false, false);
    else setShowModel(true);
  }
  const canValidate = missingRequiredVisual || (choice ? selected.length > 0 || none : card.type === 'zone' ? Boolean(point) : card.type === 'qroc' ? response.trim().length > 0 : true);
  const missedRequired = card.required.filter(index => !selected.includes(index));
  const pickedForbidden = card.forbidden.filter(index => selected.includes(index));
  return <article className="engine-question" aria-labelledby={uid + '-prompt'}>
    <div className="eq-meta"><span className="eq-format">{typeLabels[card.type] || card.type}</span>{card.annale && <span className="eq-annale">Annales{asText(card.source.session_examen) && ' · ' + asText(card.source.session_examen)}</span>}{card.annale && <span className={'eq-key ' + (!card.official ? 'is-caution' : '')}>{card.official ? 'Corrigé officiel' : 'Clé déduite · à vérifier'}</span>}</div>
    {warning && <div className="eq-warning"><AlertCircle size={18} /><span>À relire — contenu signalé comme non vérifié dans le paquet d’origine.</span></div>}
    <h3 id={uid + '-prompt'}><EngineText text={card.type === 'cloze' ? 'Complétez le passage de mémoire.' : card.prompt} /></h3>
    {card.type === 'cloze' && typeof card.fields.texte === 'string' && <div className="eq-cloze">{parseEngineCloze(card.fields.texte, card.clozeIndex || 1, shown).map((part, index) => part.hidden ? <span className="eq-blank" key={index} aria-label={'Texte à retrouver' + (part.hint ? ' : ' + part.hint : '')}>[{part.text}]</span> : <EngineText key={index} text={part.text} />)}</div>}
    {card.type !== 'zone' && <EngineFigure figure={card.questionIllustration} label="Illustration de la question" onUnavailable={() => setQuestionImageFailed(true)} />}
    {card.type === 'zone' && <ZoneQuestion card={card} point={point} setPoint={setPoint} shown={shown} locked={locked} onUnavailable={() => setQuestionImageFailed(true)} />}
    {choice ? <fieldset className="eq-options" disabled={locked}><legend>{multiple ? 'Sélectionnez toutes les propositions exactes.' : card.type === 'legend' ? 'Choisissez la légende du numéro demandé.' : 'Sélectionnez une réponse.'}</legend>{card.options.map((option, index) => <label key={index} className={'eq-option ' + (selected.includes(index) ? 'is-selected ' : '') + (shown && card.correct.includes(index) ? 'is-correct ' : shown && selected.includes(index) ? 'is-incorrect ' : '')}><input type={multiple ? 'checkbox' : 'radio'} name={uid + '-choice'} checked={selected.includes(index)} onChange={() => { setNone(false); setSelected(current => multiple ? current.includes(index) ? current.filter(value => value !== index) : [...current, index] : [index]); }} /><span className="eq-letter">{String.fromCharCode(65 + index)}</span><span><EngineText text={option} /></span>{shown && card.correct.includes(index) && <Check size={17} aria-label="Proposition exacte" />}</label>)}{multiple && <label className="eq-none"><input type="checkbox" checked={none} onChange={event => { setNone(event.target.checked); if (event.target.checked) setSelected([]); }} />Je ne retiens aucune proposition</label>}</fieldset> : card.type !== 'zone' && <label className="eq-response"><span>{card.type === 'qroc' ? 'Votre réponse, avec vos mots' : 'Votre réponse de mémoire (facultatif)'}</span><textarea rows={card.type === 'qroc' ? 5 : 3} maxLength={20000} value={response} disabled={locked} onChange={event => setResponse(event.target.value)} placeholder="Retrouvez l’information avant de consulter la correction…" /></label>}
    <fieldset className="eq-confidence" disabled={confidenceLocked}><legend>Votre confiance avant correction <small>(facultatif)</small></legend><div>{([['sure', 'Sûr'], ['hesitant', 'Hésitant'], ['guess', 'Au hasard']] as const).map(([value, label]) => <label key={value} className={confidence === value ? 'is-selected' : ''}><input type="radio" name={uid + '-confidence'} value={value} checked={confidence === value} onChange={() => setConfidence(value)} /><span>{label}</span></label>)}</div></fieldset>
    {!submitted && !reveal && !showModel && <button type="button" className="eq-primary" disabled={disabled || !canValidate} onClick={validate}>{missingRequiredVisual ? mode === 'exam' ? 'Enregistrer sans notation' : 'Consulter le corrigé sans notation' : choice || zoneReady ? 'Valider ma réponse' : mode === 'exam' ? 'Enregistrer ma réponse' : 'Comparer au corrigé'}<Check size={17} /></button>}
    {card.type === 'zone' && !missingRequiredVisual && !submitted && !reveal && !showModel && <button type="button" className="eq-secondary eq-zone-fallback" disabled={disabled} onClick={() => mode === 'exam' ? commit(false, false, false) : setShowModel(true)}>{mode === 'exam' ? 'Enregistrer sans pointage' : 'Comparer au corrigé sans pointage'}</button>}
    {submitted && !shown && <p className="eq-saved" role="status"><CheckCheck size={17} />Réponse enregistrée. Correction à la fin de l’épreuve.{initialAnswer?.graded === false && ' Une autoévaluation reste nécessaire.'}</p>}
    {shown && <section className={'eq-feedback ' + (submitted && result === true ? 'is-good' : submitted && result === false ? 'is-again' : '')} aria-label="Correction">
      <strong className="eq-feedback-title">{submitted && (choice || zoneReady) ? result ? 'Réponse exacte' : 'À revoir' : 'Corrigé de référence'}</strong>
      {choice && <p>Réponse{card.correct.length > 1 ? 's' : ''} attendue{card.correct.length > 1 ? 's' : ''} : <b>{card.correct.length ? card.correct.map(index => String.fromCharCode(65 + index)).join(', ') : 'aucune proposition'}</b>. {multiple && 'La comparaison porte sur l’ensemble exact des réponses.'}</p>}
      {!choice && card.answer && <p className="eq-model"><EngineText text={card.answer} /></p>}
      {choice && card.justifications.length > 0 && <div className="eq-justifications"><h4>Pourquoi, proposition par proposition</h4>{card.options.map((option, index) => <div key={index}><strong>{String.fromCharCode(65 + index)} · {card.correct.includes(index) ? 'Vrai' : 'Faux'}{card.required.includes(index) && ' · Indispensable'}{card.forbidden.includes(index) && ' · Inacceptable'}</strong><p><EngineText text={card.justifications[index] || 'Aucune justification spécifique fournie dans le paquet.'} /></p></div>)}</div>}
      {choice && submitted && (missedRequired.length > 0 || pickedForbidden.length > 0) && <p className="eq-warning"><AlertCircle size={17} /><span>{missedRequired.length > 0 && 'Proposition(s) indispensable(s) non retenue(s) : ' + missedRequired.map(index => String.fromCharCode(65 + index)).join(', ') + '. '}{pickedForbidden.length > 0 && 'Proposition(s) inacceptable(s) retenue(s) : ' + pickedForbidden.map(index => String.fromCharCode(65 + index)).join(', ') + '.'} Ces mentions proviennent du paquet ; aucun barème partiel n’est inventé.</span></p>}
      {card.explanation && <p><EngineText text={card.explanation} /></p>}
      {card.type === 'lexique' && asObjects(card.fields.racines).length > 0 && <div className="eq-roots"><h4>Racines et étymologie</h4>{asObjects(card.fields.racines).map((root, index) => <p key={index}><b>{asText(root.forme)}</b> — {asText(root.sens)}</p>)}</div>}
      <EngineFigure figure={card.illustration} label="Illustration de la correction" /><EngineFigure figure={card.schemaIllustration} label="Schéma de la correction" />
      <div className="eq-sources"><SourceReference value={card.source} pack={pack} /><SourceReference value={card.secondarySource} pack={pack} label="Source complémentaire" />{asObjects(card.fields.pages).map((source, index) => <SourceReference key={index} value={source} pack={pack} label="Autre page du cours" />)}</div>
      {missingRequiredVisual && <p className="eq-help">Consultation du corrigé uniquement : l’image nécessaire n’est pas disponible. Aucun résultat de repérage n’est compté.</p>}
      {free && !missingRequiredVisual && !disabled && (!reveal || mode === 'exam') && (!submitted || initialAnswer?.graded === false && outcome === undefined) && <div className="eq-self"><p>Comparez le sens, les unités et les nuances à votre réponse. Cette comparaison locale ne fournit pas une notation médicale automatique.</p><div><button type="button" className="eq-secondary" onClick={() => commit(false, true)}><RotateCcw size={17} />À retravailler</button><button type="button" className="eq-primary" onClick={() => commit(true, true)}><Check size={17} />Éléments retrouvés</button></div></div>}
      {submitted && outcome !== undefined && free && <p className="eq-help" role="status">Autoévaluation enregistrée : {outcome ? 'éléments retrouvés' : 'à retravailler'}.</p>}
    </section>}
  </article>;
}

export function EngineDiagramView({ diagram }: { diagram: EngineDiagram }) {
  const [document, setDocument] = useState('');
  const [description, setDescription] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [retry, setRetry] = useState(0);
  useEffect(() => {
    let active = true; const controller = new AbortController();
    setLoading(true); setError(''); setDocument(''); setDescription('');
    const read = async (path: string) => { const url = engineAssetUrl(path); if (!url) throw new Error('La référence du schéma est invalide.'); const response = await fetch(url, { signal: controller.signal }); if (!response.ok) throw new Error('Le schéma n’est pas disponible sur cet appareil. Téléchargez le programme ou réessayez avec Internet.'); return response.text(); };
    void Promise.allSettled([read(diagram.htmlPath), diagram.markdownPath ? read(diagram.markdownPath) : Promise.resolve('')]).then(([html, markdown]) => {
      if (!active) return;
      if (html.status === 'fulfilled') setDocument(buildEngineDiagramDocument(html.value));
      else setError(html.reason instanceof Error ? html.reason.message : 'Le schéma ne peut pas être chargé.');
      if (markdown.status === 'fulfilled') setDescription(markdown.value);
      else if (html.status === 'fulfilled') setError('Le schéma est chargé, mais son explication textuelle n’est pas encore disponible sur cet appareil. Réessayez avec Internet.');
      setLoading(false);
    });
    return () => { active = false; controller.abort(); };
  }, [diagram.id, diagram.htmlPath, diagram.markdownPath, retry]);
  return <section className="engine-diagram"><h3>{diagram.title}</h3><p className="eq-help">Schéma pédagogique repris de MED_ENGINE. Le cours et la ronéo de l’année restent les références.</p>{loading && <p className="eq-loading" role="status"><LoaderCircle size={18} className="spin" />Ouverture du schéma…</p>}{error && <div className="eq-notice" role="alert"><span>{error}</span><button type="button" className="eq-secondary" onClick={() => setRetry(value => value + 1)}>Réessayer</button></div>}{document && <iframe title={diagram.title + ' — schéma interactif'} srcDoc={document} sandbox="allow-scripts" referrerPolicy="no-referrer" className="eq-diagram-frame" />}{description && <details className="eq-diagram-text" open><summary>Explication et références <ChevronDown size={17} /></summary><div><EngineText text={description} /></div></details>}</section>;
}
