import { useCallback, useEffect, useState } from 'react';
import { BookOpen, CalendarClock, CheckCircle2, LoaderCircle, Layers3 } from 'lucide-react';
import { engineCards, loadEnginePack, type EngineCard, type EnginePack } from '../lib/engine';
import { localFsrs, type LocalEngineCard, type LocalEngineDeck } from '../lib/local-fsrs';
import EngineQuestion from './EngineQuestion';

const reasonText = (reason: unknown) => reason instanceof Error ? reason.message : 'Impossible de charger les révisions.';
const ratings = [{ value: 1, label: 'À revoir', detail: 'Je ne retrouvais pas' }, { value: 2, label: 'Difficile', detail: 'Avec beaucoup d’effort' }, { value: 3, label: 'Bien', detail: 'Avec un effort normal' }, { value: 4, label: 'Facile', detail: 'Immédiatement' }] as const;

export default function EngineReview({ initialDeckId, onBrowse }: { initialDeckId?: string; onBrowse: () => void }) {
  const [decks, setDecks] = useState<LocalEngineDeck[]>([]);
  const [deckId, setDeckId] = useState(initialDeckId || 'all');
  const [queue, setQueue] = useState<LocalEngineCard[]>([]);
  const [pack, setPack] = useState<EnginePack>();
  const [sourceCard, setSourceCard] = useState<EngineCard>();
  const [previewId, setPreviewId] = useState('');
  const [inspectDeck, setInspectDeck] = useState(false);
  const [revealed, setRevealed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [reviewed, setReviewed] = useState(0);
  const [generation, setGeneration] = useState(0);
  const current = queue[0];
  const deck = decks.find(item => item.id === deckId);
  const showingPreview = Boolean(deck && (!deck.active || inspectDeck));
  const refresh = useCallback(async () => {
    const [nextDecks, nextQueue] = await Promise.all([localFsrs.loadDecks(), localFsrs.getReviewQueue(deckId === 'all' ? undefined : deckId)]);
    setDecks(nextDecks); setQueue(nextQueue);
  }, [deckId]);
  useEffect(() => {
    let live = true; setLoading(true); setError('');
    void Promise.all([localFsrs.loadDecks(), localFsrs.getReviewQueue(deckId === 'all' ? undefined : deckId)]).then(([nextDecks, nextQueue]) => { if (live) { setDecks(nextDecks); setQueue(nextQueue); } }).catch(reason => { if (live) setError(reasonText(reason)); }).finally(() => { if (live) setLoading(false); });
    return () => { live = false; };
  }, [deckId, generation]);
  useEffect(() => localFsrs.subscribe(() => setGeneration(value => value + 1)), []);
  useEffect(() => {
    let live = true; setPack(undefined); setSourceCard(undefined); setRevealed(false);
    const packId = showingPreview && deck ? deck.packId : current?.packId;
    if (!packId) return;
    void loadEnginePack(packId).then(value => {
      if (!live) return; setPack(value);
      if (current && !showingPreview) {
        const card = engineCards(value).find(item => item.id === current.sourceId);
        if (!card) throw new Error('La carte source n’est plus disponible. Son échéance reste conservée.');
        setSourceCard(card);
      }
    }).catch(reason => { if (live) setError(reasonText(reason)); });
    return () => { live = false; };
  }, [current?.id, deck?.id, deck?.active, showingPreview]);
  const previewCards = pack && deck && showingPreview ? engineCards(pack).filter(card => deck.cardIds.includes(card.id)).filter(card => !(['zone', 'legend'].includes(card.type) && (!card.questionIllustration || card.questionIllustration.available === false))) : [];
  const preview = previewCards.find(card => card.id === previewId) || previewCards[0];
  async function activate() {
    if (!deck || busy) return; setBusy(true); setError('');
    try { await localFsrs.activateDeck(deck.id); setInspectDeck(false); setMessage('Deck activé : les cartes entrent maintenant dans tes révisions espacées.'); await refresh(); }
    catch (reason) { setError(reasonText(reason)); } finally { setBusy(false); }
  }
  async function rate(value: 1 | 2 | 3 | 4) {
    if (!current || !revealed || busy) return; setBusy(true); setError('');
    try { await localFsrs.reviewCard(current.id, value, new Date(), crypto.randomUUID()); setReviewed(n => n + 1); setRevealed(false); await refresh(); setMessage('Révision enregistrée sur cet appareil.'); }
    catch (reason) { setError(reasonText(reason)); } finally { setBusy(false); }
  }
  return <section className="me-review" aria-labelledby="me-review-title">
    <header className="page-heading"><div><span className="eyebrow">RÉPÉTITION ESPACÉE · FSRS</span><h1 id="me-review-title">Au bon moment.</h1><p>Retrouve la réponse avant de consulter la correction, puis évalue l’effort nécessaire.</p></div><CalendarClock size={32} /></header>
    <p className="small-muted">Les échéances et l’historique MED_ENGINE sont conservés sur cet iPhone. Les exercices libres, annales et simulations gardent leur suivi distinct.</p>
    {error && <div className="error-banner" role="alert">{error}<button type="button" className="text-button" onClick={() => setError('')}>Fermer</button></div>}
    {message && <div className="info-banner" role="status"><CheckCircle2 size={18} />{message}</div>}
    <label className="field"><span>Deck de révision</span><select aria-label="Deck de révision" value={deckId} onChange={event => { setDeckId(event.target.value); setPreviewId(''); setInspectDeck(false); setMessage(''); }}><option value="all">Tous mes decks actifs · matières mélangées</option>{decks.map(item => <option key={item.id} value={item.id}>{item.title}{item.active ? '' : ' · brouillon'}</option>)}</select></label>
    <div className="me-review-summary"><span className="soft-badge">{queue.length} carte(s) à revoir maintenant</span><span className="small-muted">{reviewed} révision(s) pendant cette ouverture</span></div>
    {deck?.active && !showingPreview && <button type="button" className="text-button" onClick={() => { setPreviewId(''); setInspectDeck(true); }}>Relire ce deck et ses cartes ajoutées</button>}
    {loading ? <div className="panel" role="status"><LoaderCircle className="spin" size={20} />Chargement des révisions…</div> : !decks.length ? <div className="empty-state panel"><Layers3 size={32} /><h2>Choisis d’abord un chapitre.</h2><p>Depuis la bibliothèque, ajoute ses cartes à un deck FSRS, relis-les et active ce deck.</p><button type="button" className="primary" onClick={onBrowse}>Parcourir les chapitres</button></div> : showingPreview && deck ? <>
      <div className="panel me-activation"><h2>{deck.active ? 'Relire les réponses du deck.' : 'Relis ce nouveau deck.'}</h2><p>{deck.active ? 'Tu peux vérifier les réponses et activer les nouvelles cartes ajoutées à ce chapitre, en conservant les échéances déjà établies.' : `Ces ${deck.cardIds.length} cartes restent en brouillon jusqu’à ton activation.`} Les corrections officielles, déduites ou à vérifier gardent leurs mentions.</p><p>Les repérages et légendes dont l’image manque sont exclus du deck.</p><div className="engine-actions"><button type="button" className="primary" onClick={() => void activate()} disabled={busy}>{busy ? 'Activation…' : deck.active ? 'Activer les cartes ajoutées' : 'Activer ces cartes'}</button>{deck.active && <button type="button" className="secondary" onClick={() => setInspectDeck(false)}>Retour aux révisions</button>}</div></div>
      {pack && preview ? <section className="panel me-deck-preview"><h2>Aperçu des réponses</h2><label className="field"><span>Carte à relire</span><select aria-label="Carte à relire" value={preview.id} onChange={event => setPreviewId(event.target.value)}>{previewCards.map((card, index) => <option key={card.id} value={card.id}>{index + 1}. {card.prompt.slice(0, 115)}</option>)}</select></label><EngineQuestion key={preview.id} pack={pack} card={preview} reveal disabled /></section> : <p role="status">Ouverture des réponses source…</p>}
    </> : current ? <>
      <p className="me-review-chapter"><BookOpen size={17} />{decks.find(item => item.id === current.deckId)?.title || current.packId}</p>
      {pack && sourceCard ? <EngineQuestion key={current.id} pack={pack} card={sourceCard} disabled={busy} onAnswered={answer => setRevealed(answer.graded !== false)} /> : !error && <div className="panel" role="status">Ouverture de la carte…</div>}
      {revealed && <div className="me-rating-area"><h2>Quel effort pour retrouver la réponse ?</h2><p className="small-muted">Cette appréciation règle la prochaine révision. Elle reste distincte de la correction de l’exercice.</p><div className="me-ratings">{ratings.map(rating => <button type="button" className={`me-rating me-rating-${rating.value}`} key={rating.value} disabled={busy} onClick={() => void rate(rating.value)}><strong>{rating.label}</strong><span>{rating.detail}</span></button>)}</div></div>}
    </> : <div className="empty-state panel"><CheckCircle2 size={34} /><h2>Aucune carte à revoir maintenant.</h2><p>Les cartes actives reviendront à leur échéance. Tu peux continuer un entraînement libre dans la bibliothèque ou activer un autre brouillon.</p><button type="button" className="secondary" onClick={onBrowse}>Ouvrir la bibliothèque</button></div>}
  </section>;
}
