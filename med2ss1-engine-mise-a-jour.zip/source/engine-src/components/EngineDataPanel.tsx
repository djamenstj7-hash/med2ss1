import { useEffect, useRef, useState } from 'react';
import { Check, Download, FileUp, HardDriveDownload, LoaderCircle, RefreshCw, Trash2 } from 'lucide-react';
import { clearEngineProgress, exportEngineBackup, importEngineBackup, MAX_ENGINE_BACKUP_BYTES } from '../lib/local-backup';
import { clearEngineOffline, downloadEngine, getEngineOfflineStatus, type EngineOfflineProgress, type EngineOfflineStatus } from '../lib/engine-offline';

const messageOf = (reason: unknown) => reason instanceof Error ? reason.message : 'Cette action n’a pas pu être terminée.';
const backupLimitLabel = `${Math.floor(MAX_ENGINE_BACKUP_BYTES / (1024 * 1024))} Mio`;
export default function EngineDataPanel() {
  const [status, setStatus] = useState<EngineOfflineStatus>();
  const [progress, setProgress] = useState<EngineOfflineProgress>();
  const [busy, setBusy] = useState('');
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const importInput = useRef<HTMLInputElement>(null);
  const downloadController = useRef<AbortController | undefined>(undefined);
  const live = useRef(true);
  useEffect(() => { live.current = true; void getEngineOfflineStatus().then(value => { if (live.current) setStatus(value); }).catch(reason => { if (live.current) setError(messageOf(reason)); }); return () => { live.current = false; downloadController.current?.abort(); }; }, []);
  async function action(name: string, operation: () => Promise<void>) {
    if (busy) return; setBusy(name); setError(''); setMessage('');
    try { await operation(); } catch (reason) { if (live.current) setError(messageOf(reason)); }
    finally { if (live.current) setBusy(''); }
  }
  function downloadBlob(data: unknown, filename: string) {
    const blob = new Blob([JSON.stringify(data)], { type: 'application/json' });
    if (blob.size > MAX_ENGINE_BACKUP_BYTES) throw new Error(`La sauvegarde dépasse la limite de ${backupLimitLabel} et ne peut pas être exportée dans ce format. Ton suivi reste conservé sur cet appareil.`);
    const url = URL.createObjectURL(blob), anchor = document.createElement('a');
    anchor.href = url; anchor.download = filename; anchor.hidden = true; document.body.appendChild(anchor); anchor.click(); anchor.remove(); window.setTimeout(() => URL.revokeObjectURL(url), 30000);
  }
  async function exportBackup() {
    await action('export', async () => { const backup = await exportEngineBackup(); downloadBlob(backup, `med2ss1-med-engine-${new Date().toISOString().slice(0, 10)}.json`); if (live.current) setMessage('Sauvegarde MED_ENGINE préparée. Enregistre le fichier JSON dans Fichiers.'); });
  }
  async function importBackup(file?: File) {
    if (!file) return;
    await action('import', async () => {
      if (file.size > MAX_ENGINE_BACKUP_BYTES) throw new Error(`Cette sauvegarde dépasse la limite de ${backupLimitLabel}.`);
      let parsed: unknown;
      try { parsed = JSON.parse(await file.text()); } catch { throw new Error('Ce fichier n’est pas une sauvegarde JSON lisible.'); }
      if (!window.confirm('Fusionner cette sauvegarde MED_ENGINE avec les données présentes sur cet appareil ? Les cours MED2 S1 et les PDF personnels restent dans leur espace habituel.')) return;
      await importEngineBackup(parsed);
      if (live.current) setMessage('Sauvegarde MED_ENGINE importée et fusionnée.');
    });
    if (importInput.current) importInput.current.value = '';
  }
  async function downloadOffline() {
    await action('download', async () => {
      const controller = new AbortController(); downloadController.current = controller;
      try {
        const result = await downloadEngine(value => { if (live.current) setProgress(value); }, controller.signal);
        if (live.current) { setStatus(result); setMessage(result.missing ? 'Téléchargement partiel : relance-le avec une connexion pour préparer les fichiers restants.' : 'Les contenus MED_ENGINE fournis sont disponibles hors connexion sur cet appareil.'); }
      } catch (reason) {
        if (!controller.signal.aborted) throw reason;
        const result = await getEngineOfflineStatus();
        if (live.current) { setStatus(result); setMessage('Téléchargement arrêté. Les fichiers déjà préparés sont conservés ; tu peux reprendre le téléchargement plus tard.'); }
      } finally { downloadController.current = undefined; }
    });
  }
  async function checkOffline() { await action('check', async () => { const result = await getEngineOfflineStatus(); if (live.current) { setStatus(result); setMessage(result.missing ? `${result.missing} fichier(s) restent à préparer pour le hors connexion.` : 'Tous les fichiers MED_ENGINE fournis sont présents.'); } }); }
  async function clearOffline() {
    if (!window.confirm('Retirer les contenus MED_ENGINE téléchargés sur cet appareil ? Ton suivi, tes decks et tes notes seront conservés. Il faudra une connexion pour rouvrir les contenus retirés.')) return;
    await action('clear-cache', async () => { await clearEngineOffline(); const value = await getEngineOfflineStatus(); if (live.current) { setStatus(value); setMessage('Les fichiers MED_ENGINE téléchargés ont été retirés. Le suivi est conservé.'); } });
  }
  async function clearProgress() {
    if (!window.confirm('Effacer le suivi MED_ENGINE de cet appareil, ses decks FSRS et ses notes ? Exporte d’abord une sauvegarde si tu souhaites les garder. Les 85 cours MED2 S1 et leurs données restent dans leur espace habituel.')) return;
    await action('clear-progress', async () => { await clearEngineProgress(); if (live.current) setMessage('Le suivi MED_ENGINE a été réinitialisé sur cet appareil.'); });
  }
  return <section className="me-data" aria-labelledby="me-data-title">
    <header className="page-heading"><div><span className="eyebrow">TON IPHONE, TON ESPACE DE TRAVAIL</span><h1 id="me-data-title">Sauvegarde et hors ligne.</h1><p>Prépare les contenus, puis conserve une copie de ta progression.</p></div></header>
    {error && <div className="error-banner" role="alert">{error}<button type="button" className="text-button" onClick={() => setError('')}>Fermer</button></div>}
    {message && <div className="info-banner" role="status"><Check size={18} />{message}</div>}
    <section className="panel me-offline"><HardDriveDownload size={27} /><h2>MED_ENGINE sans réseau</h2><p>Le téléchargement prépare les chapitres, les images fournies et les schémas. Garde l’application ouverte et connectée jusqu’à la fin.</p>
      <p className="me-offline-count" aria-live="polite">{status ? `${status.cached} / ${status.total} fichiers disponibles` : 'Vérification des fichiers…'}</p>
      {busy === 'download' && progress && <div className="me-download-progress" role="status"><progress max={Math.max(1, progress.total)} value={progress.done} aria-label="Téléchargement MED_ENGINE" /><span>{progress.done} / {progress.total} fichiers préparés{progress.failed.length ? ` · ${progress.failed.length} à réessayer` : ''}</span></div>}
      <div className="engine-actions"><button type="button" className="primary" disabled={Boolean(busy)} onClick={() => void downloadOffline()}>{busy === 'download' ? <LoaderCircle className="spin" size={18} /> : <Download size={18} />}Télécharger MED_ENGINE</button><button type="button" className="secondary" disabled={Boolean(busy)} onClick={() => void checkOffline()}><RefreshCw size={17} />Vérifier les fichiers hors connexion</button>{busy === 'download' && <button type="button" className="secondary" onClick={() => downloadController.current?.abort()}>Arrêter le téléchargement</button>}</div>
      <p className="small-muted">Le dossier reçu ne contient pas toutes les figures citées : celles qui manquent sont signalées dans les exercices. Le téléchargement ne les recrée pas. Les PDF et liens externes cités restent distincts.</p>
      <button type="button" className="text-button" disabled={Boolean(busy)} onClick={() => void clearOffline()}><Trash2 size={16} />Supprimer les fichiers MED_ENGINE téléchargés</button>
    </section>
    <section className="panel me-backup"><h2>Une copie de ton travail</h2><p>La sauvegarde MED_ENGINE contient tes entraînements, séances à reprendre, favoris, notes, dates personnelles, decks FSRS et leur historique. Elle est indépendante de la sauvegarde habituelle MED2 S1.</p><div className="engine-actions"><button type="button" className="primary" disabled={Boolean(busy)} onClick={() => void exportBackup()}><Download size={18} />Exporter ma sauvegarde MED_ENGINE</button><label className="secondary me-file-button"><FileUp size={18} />Importer une sauvegarde MED_ENGINE<input ref={importInput} type="file" accept="application/json,.json" aria-label="Importer une sauvegarde MED_ENGINE" disabled={Boolean(busy)} onChange={event => void importBackup(event.target.files?.[0])} /></label></div><p className="small-muted">Tes données restent dans le navigateur de cet appareil. Medora et MED2 S1 n’échangent pas automatiquement leur progression. Les PDF personnels du site MED2 S1 ne sont pas inclus dans ce fichier MED_ENGINE.</p></section>
    <details className="panel me-reset"><summary>Réinitialiser le suivi MED_ENGINE</summary><p>Cette action retire uniquement les données de travail de ce module sur cet appareil. Une sauvegarde exportée peut ensuite être réimportée.</p><button type="button" className="secondary" disabled={Boolean(busy)} onClick={() => void clearProgress()}><Trash2 size={17} />Effacer mon suivi MED_ENGINE</button></details>
  </section>;
}
