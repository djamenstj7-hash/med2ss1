import { useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { ArrowLeft, ArrowRight, Expand, Image, LoaderCircle, Minus, Plus, X } from 'lucide-react';
import { engineAssetUrl, loadEnginePack } from '../lib/engine';
import type { EngineCard, EngineManifest, EnginePack } from '../lib/engine-types';
import { engineFigureCards, engineFigurePracticeAvailable, engineGalleryFigures, enginePackFigures, type EngineGalleryFigure } from '../lib/engine-media';
import '../engine-gallery.css';

interface Props {
  manifest: EngineManifest;
  pack?: EnginePack;
  onPractice: (pack: EnginePack, card: EngineCard) => void;
}

function FigureZoom({ figure, onClose }: { figure: EngineGalleryFigure; onClose: () => void }) {
  const dialog = useRef<HTMLDialogElement>(null);
  const [scale, setScale] = useState(1);
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    const focus = document.activeElement as HTMLElement | null;
    const oldOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const element = dialog.current;
    if (element && !element.open) element.showModal();
    return () => { if (element?.open) element.close(); document.body.style.overflow = oldOverflow; focus?.focus?.(); };
  }, []);
  return createPortal(<dialog ref={dialog} className="eq-zoom engine-media-zoom" aria-label={'Figure agrandie : ' + (figure.caption || figure.filename)} onCancel={event => { event.preventDefault(); onClose(); }} onKeyDown={event => { if (event.key === 'Escape') { event.stopPropagation(); event.preventDefault(); onClose(); } }}>
    <header><strong>{figure.packTitle}</strong><button type="button" autoFocus onClick={onClose} aria-label="Fermer la figure agrandie"><X size={22} /></button></header>
    <div className="engine-media-zoom-controls" role="group" aria-label="Zoom de la figure">
      <button type="button" disabled={scale <= 1} onClick={() => setScale(value => Math.max(1, value - .5))} aria-label="Réduire la figure"><Minus size={20} /></button>
      <output aria-live="polite">{Math.round(scale * 100)} %</output>
      <button type="button" disabled={scale >= 4} onClick={() => setScale(value => Math.min(4, value + .5))} aria-label="Agrandir la figure"><Plus size={20} /></button>
      <button type="button" onClick={() => setScale(1)}>Ajuster</button>
    </div>
    {failed ? <p role="alert">Cette figure ne s’est pas chargée. Réessaie en ligne ou prépare les fichiers hors connexion.</p> : <div className="engine-media-zoom-viewport"><img style={{ width: `${scale * 100}%` }} src={engineAssetUrl(figure.path)} alt={figure.caption || figure.filename} onError={() => setFailed(true)} /></div>}
    <p>{figure.caption || figure.filename}</p><small>Fais glisser l’image pour explorer la figure agrandie. Dans Safari, tu peux aussi écarter deux doigts.</small>
  </dialog>, document.body);
}

export default function EngineGallery({ manifest, pack, onPractice }: Props) {
  const [packId, setPackId] = useState(pack?.id || '');
  const [loadedPack, setLoadedPack] = useState<EnginePack | undefined>(pack);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [retry, setRetry] = useState(0);
  const [limit, setLimit] = useState(32);
  const [selected, setSelected] = useState('');
  const [relatedLimit, setRelatedLimit] = useState(12);
  const [zoom, setZoom] = useState(false);
  const [imageFailed, setImageFailed] = useState(false);
  const detail = useRef<HTMLElement>(null);
  const allFigures = useMemo(() => engineGalleryFigures(manifest), [manifest]);
  const illustratedPacks = useMemo(() => manifest.packs.filter(item => allFigures.some(figure => figure.packId === item.id)), [manifest, allFigures]);

  useEffect(() => { setPackId(pack?.id || ''); setLoadedPack(pack); setSelected(''); setLimit(32); setError(''); setZoom(false); }, [pack?.id]);
  useEffect(() => {
    if (!packId) { setLoadedPack(undefined); setLoading(false); return; }
    if (pack?.id === packId) { setLoadedPack(pack); setLoading(false); return; }
    let live = true;
    setLoading(true); setError(''); setLoadedPack(undefined);
    void loadEnginePack(packId).then(value => { if (live) setLoadedPack(value); }).catch(reason => { if (live) setError(reason instanceof Error ? reason.message : 'Les figures de ce chapitre n’ont pas pu être chargées.'); }).finally(() => { if (live) setLoading(false); });
    return () => { live = false; };
  }, [packId, pack, retry]);
  const figures = useMemo(() => loadedPack ? enginePackFigures(loadedPack) : [], [loadedPack]);
  const figure = figures.find(item => item.id === selected);
  const related = useMemo(() => loadedPack && figure ? engineFigureCards(loadedPack, figure.path) : [], [loadedPack, figure]);
  useEffect(() => { setImageFailed(false); setRelatedLimit(12); if (selected) detail.current?.scrollIntoView({ block: 'start', behavior: 'auto' }); }, [selected]);
  function choosePack(id: string) { setPackId(id); setSelected(''); setLimit(32); setZoom(false); }
  function chooseFigure(item: EngineGalleryFigure) { setSelected(item.id); setImageFailed(false); }

  return <section className="engine-gallery" aria-label="Galerie des illustrations MED_ENGINE">
    <div className="section-heading"><div><h2>Planches et illustrations</h2><p className="small-muted">{allFigures.length} images fournies, dans {illustratedPacks.length} chapitres. Ouvre une figure pour l’agrandir ou travailler les questions qui l’utilisent.</p></div><Image size={25} aria-hidden="true" /></div>
    {!pack && <label className="field"><span>Chapitre illustré</span><select aria-label="Chapitre illustré" value={packId} onChange={event => choosePack(event.target.value)}><option value="">Choisir un chapitre illustré…</option>{illustratedPacks.map(item => <option key={item.id} value={item.id}>{item.title} · {allFigures.filter(figure => figure.packId === item.id).length} images</option>)}</select></label>}
    {error && <div className="error-banner" role="alert"><span>{error}</span><button type="button" className="text-button" onClick={() => setRetry(value => value + 1)}>Réessayer</button></div>}
    {loading && <p className="engine-gallery-loading" role="status"><LoaderCircle size={18} className="spin" />Ouverture des illustrations…</p>}
    {!packId && <div className="engine-gallery-packs">{illustratedPacks.map(item => <button key={item.id} type="button" className="panel" data-gallery-pack={item.id} onClick={() => choosePack(item.id)}><Image size={22} aria-hidden="true" /><strong>{item.title}</strong><span>{allFigures.filter(figure => figure.packId === item.id).length} images disponibles <ArrowRight size={16} aria-hidden="true" /></span></button>)}</div>}
    {loadedPack && !figures.length && <div className="panel"><h3>Aucune image de ce chapitre n’était fournie.</h3><p>Ses références et ses corrections restent consultables. Les figures manquantes ne peuvent pas être recréées à partir de leur seul nom de fichier.</p><p className="small-muted">Les autres chapitres illustrés sont accessibles dans Comprendre → Planches et illustrations.</p></div>}
    {loadedPack && figures.length > 0 && <>
      <div className="engine-gallery-chapter-heading"><h3>{loadedPack.title}</h3><span className="soft-badge">{figures.length} images disponibles</span></div>
      {!pack && <button type="button" className="text-button" onClick={() => choosePack('')}><ArrowLeft size={17} />Tous les chapitres illustrés</button>}
      {figure && <section className="panel engine-gallery-detail" ref={detail} aria-label="Illustration sélectionnée">
        <div className="section-heading"><h3>{figure.caption || figure.filename}</h3><button type="button" className="text-button" onClick={() => setSelected('')} aria-label="Fermer le détail de la figure"><X size={20} /></button></div>
        <p className="engine-gallery-filename">Fichier fourni : {figure.filename}</p>
        {imageFailed ? <p className="eq-notice" role="alert">Cette image ne s’est pas chargée. Réessaie avec une connexion ou prépare les fichiers hors connexion.</p> : <button type="button" className="engine-gallery-main-image" aria-label={'Agrandir : ' + (figure.caption || figure.filename)} onClick={() => setZoom(true)}><img src={engineAssetUrl(figure.path)} alt={figure.caption || figure.filename} onError={() => setImageFailed(true)} /><span><Expand size={17} />Agrandir et zoomer</span></button>}
        {figure.sourceId && <p className="small-muted">Source : {loadedPack.source_documents.find(source => source.id === figure.sourceId)?.titre || figure.sourceId}</p>}
        <h4>Travailler avec cette figure</h4>
        <p className="small-muted">{related.length ? `${related.length} exercice(s) utilise(nt) cette illustration. Choisir un exercice lance directement le rappel actif ; regarder la figure n’ajoute aucun résultat à ton suivi.` : 'Aucun exercice ne référence directement cette image. Tu peux l’étudier et l’agrandir librement.'}</p>
        <div className="engine-gallery-related">{related.slice(0, relatedLimit).map(card => <div key={card.id}><p>{card.prompt}</p>{engineFigurePracticeAvailable(card) ? <button type="button" className="secondary" onClick={() => onPractice(loadedPack, card)}>{card.type === 'zone' ? 'Travailler ce repérage' : card.type === 'legend' ? 'Travailler cette légende' : 'Travailler cette carte'}<ArrowRight size={16} aria-hidden="true" /></button> : <p className="small-muted">L’image de la question n’était pas fournie ; cette illustration de correction reste consultable, sans notation du repérage.</p>}</div>)}</div>
        {related.length > relatedLimit && <button type="button" className="text-button" onClick={() => setRelatedLimit(value => value + 12)}>Afficher les exercices suivants ({related.length - relatedLimit} restants)</button>}
      </section>}
      <div className="engine-gallery-images">{figures.slice(0, limit).map((item, index) => <button type="button" key={item.id} className={'engine-gallery-thumbnail' + (selected === item.id ? ' is-selected' : '')} data-gallery-figure={item.filename} aria-label={`Ouvrir la figure ${index + 1} : ${item.caption || item.filename}`} onClick={() => chooseFigure(item)}><span className="engine-gallery-image-box"><img loading="lazy" src={engineAssetUrl(item.path)} alt="" /></span><span><strong>Figure {index + 1}</strong><small>{item.caption || item.filename}</small></span></button>)}</div>
      {figures.length > limit && <button type="button" className="secondary engine-gallery-more" onClick={() => setLimit(value => value + 32)}>Afficher les images suivantes ({figures.length - limit} restantes)</button>}
    </>}
    {zoom && figure && <FigureZoom figure={figure} onClose={() => setZoom(false)} />}
  </section>;
}
