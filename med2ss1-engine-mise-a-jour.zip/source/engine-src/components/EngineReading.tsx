import { useEffect, useMemo, useRef, useState } from 'react';
import { BookOpen, ChevronLeft, ChevronRight, FileText, LoaderCircle } from 'lucide-react';
import { engineAssetUrl, engineCards, type EnginePack } from '../lib/engine';
import { engineExistingCourses, enginePdfCourseId, parseReadingMarkdown, readingInline, readingReferences } from '../lib/engine-reading';
import EngineQuestion from './EngineQuestion';
import EngineDocuments, { EngineDocumentLink } from './EngineDocuments';
import { engineDocumentsForPack, engineDocumentsForSource } from '../lib/engine-documents';
import '../engine-reading.css';

interface Props { pack: EnginePack; onOpenCourse?: (lessonId?: string) => void }
interface PdfLibrary {
  mountFiches: (container: HTMLElement, options: { courseId: string; courseTitle: string }) => { ready?: Promise<unknown> } | undefined;
  unmount: (container: HTMLElement) => void;
}
declare global { interface Window { Med2Pdf?: PdfLibrary } }

function Inline({ text }: { text: string }) {
  return <>{readingInline(text).map((part, index) => part.kind === 'strong' ? <strong key={index}>{part.text}</strong> : part.kind === 'em' ? <em key={index}>{part.text}</em> : part.kind === 'code' ? <code key={index}>{part.text}</code> : part.kind === 'link' && part.href ? <a key={index} href={part.href} target="_blank" rel="noopener noreferrer">{part.text}</a> : <span key={index}>{part.text}</span>)}</>;
}

export function EngineReadingMarkdown({ text }: { text: string }) {
  const blocks = useMemo(() => parseReadingMarkdown(text), [text]);
  return <div className="er-markdown">{blocks.map((block, index) => {
    if (block.kind === 'heading') return block.level <= 2 ? <h3 key={index}><Inline text={block.text} /></h3> : <h4 key={index}><Inline text={block.text} /></h4>;
    if (block.kind === 'rule') return <hr key={index} />;
    if (block.kind === 'code') return <pre key={index}><code>{block.text}</code></pre>;
    if (block.kind === 'quote') return <blockquote key={index}><Inline text={block.text} /></blockquote>;
    if (block.kind === 'list') { const items = block.items.map((item, itemIndex) => <li key={itemIndex}><Inline text={item} /></li>); return block.ordered ? <ol key={index}>{items}</ol> : <ul key={index}>{items}</ul>; }
    if (block.kind === 'table') return <div className="er-table-scroll" key={index} tabIndex={0} role="region" aria-label="Tableau du guide"><table><thead><tr>{block.header.map((cell, cellIndex) => <th scope="col" key={cellIndex}><Inline text={cell} /></th>)}</tr></thead><tbody>{block.rows.map((row, rowIndex) => <tr key={rowIndex}>{block.header.map((_cell, cellIndex) => <td key={cellIndex}><Inline text={row[cellIndex] || ''} /></td>)}</tr>)}</tbody></table></div>;
    return <p key={index}><Inline text={block.text} /></p>;
  })}</div>;
}

function ChapterPdf({ pack }: { pack: EnginePack }) {
  const container = useRef<HTMLDivElement>(null);
  const [error, setError] = useState('');
  const [retry, setRetry] = useState(0);
  useEffect(() => {
    const element = container.current, library = window.Med2Pdf;
    if (!element) return;
    setError(''); let live = true;
    if (!library) { setError('Le lecteur PDF de MED2 S1 n’est pas encore disponible. Rouvre le site avec une connexion, puis réessaie.'); return; }
    try {
      const view = library.mountFiches(element, { courseId: enginePdfCourseId(pack.id), courseTitle: `MED_ENGINE — ${pack.title}` });
      void view?.ready?.catch(reason => { if (live) setError(reason instanceof Error ? reason.message : 'Les PDF de ce chapitre n’ont pas pu être chargés.'); });
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Le lecteur PDF n’a pas pu être ouvert.'); }
    return () => { live = false; library.unmount(element); };
  }, [pack.id, pack.title, retry]);
  return <section className="er-personal-pdf" aria-labelledby="er-personal-pdf-title"><h3 id="er-personal-pdf-title">Mes PDF de ce chapitre</h3><p>Ajoute depuis Fichiers le cours complet que tu possèdes pour le lire ici. Le PDF est conservé sur cet appareil, pour ce chapitre, avec le lecteur habituel de MED2 S1.</p><p className="small-muted">Les PDF personnels ne sont pas inclus dans les sauvegardes JSON MED_ENGINE. Conserve les fichiers originaux.</p>{error && <div className="error-banner" role="alert"><span>{error}</span><button type="button" className="text-button" onClick={() => setRetry(value => value + 1)}>Réessayer le lecteur PDF</button></div>}<div ref={container} /></section>;
}

export default function EngineReading({ pack, onOpenCourse }: Props) {
  const [tab, setTab] = useState<'guide' | 'drive' | 'cards' | 'pdf' | 'sources'>('guide');
  const [guide, setGuide] = useState(''); const [loading, setLoading] = useState(false); const [error, setError] = useState(''); const [retry, setRetry] = useState(0);
  const [query, setQuery] = useState(''); const [format, setFormat] = useState('all'); const [page, setPage] = useState(0);
  const cards = useMemo(() => engineCards(pack), [pack]);
  const references = useMemo(() => readingReferences(pack), [pack]);
  const driveDocuments = useMemo(() => engineDocumentsForPack(pack), [pack]);
  const filtered = useMemo(() => { const needle = query.normalize('NFD').replace(/\p{M}/gu, '').toLocaleLowerCase('fr'); return cards.filter(card => (format === 'all' || card.type === format) && (!needle || `${card.prompt} ${card.answer} ${card.explanation}`.normalize('NFD').replace(/\p{M}/gu, '').toLocaleLowerCase('fr').includes(needle))); }, [cards, format, query]);
  const pageSize = 12, pages = Math.max(1, Math.ceil(filtered.length / pageSize)), safePage = Math.min(page, pages - 1);
  const existing = engineExistingCourses[pack.id];
  useEffect(() => { setTab('guide'); setQuery(''); setFormat('all'); setPage(0); }, [pack.id]);
  useEffect(() => {
    let live = true; const controller = new AbortController(); setGuide(''); setError('');
    if (!pack.readmePath) { setLoading(false); return () => controller.abort(); }
    setLoading(true);
    const url = engineAssetUrl(pack.readmePath);
    if (!url) { setLoading(false); setError('La référence du guide est invalide. Les fiches et les corrections restent consultables dans leur onglet.'); return () => controller.abort(); }
    void fetch(url, { signal: controller.signal }).then(async response => { if (!response.ok) throw new Error('Le guide n’est pas disponible sur cet appareil. Télécharge MED_ENGINE pour le lire hors connexion.'); return response.text(); }).then(value => { if (live) setGuide(value); }).catch(reason => { if (live && !controller.signal.aborted) setError(reason instanceof Error ? reason.message : 'Le guide n’a pas pu être ouvert.'); }).finally(() => { if (live) setLoading(false); });
    return () => { live = false; controller.abort(); };
  }, [pack.id, pack.readmePath, retry]);
  function openCourse(lessonId?: string) { if (onOpenCourse) onOpenCourse(lessonId); else window.dispatchEvent(new CustomEvent('med2-engine-open-course', { detail: { lessonId } })); }
  return <section className="engine-reading" aria-labelledby="er-title">
    <header className="er-heading"><BookOpen size={24} /><div><h2 id="er-title">Lire le chapitre</h2><p>Cours, guide et fiches pour « {pack.title} ».</p></div></header>
    <p className="er-source-notice">Les guides et les fiches font partie de MED_ENGINE. Les cours complets du Drive s’ouvrent en ligne ; ils ne sont pas inclus dans le téléchargement hors connexion. Les références d’anciennes éditions et d’annales restent distinctes.</p>
    {driveDocuments.length > 0 && <div className="er-direct-course-actions"><h3>Cours retrouvés sur Drive</h3>{driveDocuments.map(document => <div key={document.id}><strong>{document.title}</strong><EngineDocumentLink document={document} /></div>)}<button type="button" className="text-button" onClick={() => setTab('drive')}>Voir les documents et les autres cours de cette UE</button></div>}
    <div className="er-course-links">{existing && <button type="button" className="secondary" onClick={() => openCourse(existing.id)}><BookOpen size={18} /><span>Lire le cours MED2 S1 : {existing.title}</span></button>}<button type="button" className="text-button" onClick={() => openCourse()}>Ouvrir la bibliothèque des 85 cours MED2 S1</button></div>
    <nav className="er-tabs engine-reading-tabs" aria-label="Lecture du chapitre MED_ENGINE">{([{ id: 'drive', label: 'Cours du Drive' }, { id: 'guide', label: 'Guide du chapitre' }, { id: 'cards', label: 'Fiches et corrections' }, { id: 'pdf', label: 'Mes PDF' }, { id: 'sources', label: 'Documents cités' }] as const).map(item => <button key={item.id} type="button" aria-current={tab === item.id ? 'page' : undefined} onClick={() => setTab(item.id)}>{item.label}</button>)}</nav>
    {tab === 'drive' && <EngineDocuments pack={pack} onAddPersonalPdf={() => setTab('pdf')} />}
    {tab === 'guide' && <section className="panel er-guide"><h3>Guide du chapitre</h3>{loading && <p role="status"><LoaderCircle size={18} className="spin" />Ouverture du guide…</p>}{error && <div className="error-banner" role="alert"><span>{error}</span><button type="button" className="text-button" onClick={() => setRetry(value => value + 1)}>Réessayer le guide</button></div>}{guide ? <EngineReadingMarkdown text={guide} /> : !loading && !error && <p>Aucun guide séparé n’était fourni pour ce chapitre. Ses fiches et corrections restent consultables dans l’onglet suivant.</p>}</section>}
    {tab === 'cards' && <section className="er-cards"><h3>Fiches et corrections fournies</h3><p className="small-muted">Lecture libre : elle n’enregistre aucune réponse évaluée et ne modifie pas tes révisions FSRS. Les étiquettes de correction officielle, déduite ou à vérifier restent visibles.</p><div className="engine-filter-grid"><label className="field"><span>Rechercher dans les fiches</span><input type="search" aria-label="Rechercher dans les fiches de lecture" value={query} onChange={event => { setQuery(event.target.value); setPage(0); }} /></label><label className="field"><span>Format des fiches de lecture</span><select aria-label="Format des fiches de lecture" value={format} onChange={event => { setFormat(event.target.value); setPage(0); }}><option value="all">Tous les formats</option>{[...new Set(cards.map(card => card.type))].map(type => <option key={type} value={type}>{({ qrm: 'QRM', qru: 'QRU', cloze: 'Textes à trous', qroc: 'QROC', basic: 'Rappels actifs', lexique: 'Lexique', zone: 'Repérages', legend: 'Planches à légender' })[type]}</option>)}</select></label></div><p className="small-muted" aria-live="polite">{filtered.length} fiche(s) · page {safePage + 1} sur {pages}</p>{filtered.slice(safePage * pageSize, (safePage + 1) * pageSize).map(card => <article className="er-card" key={card.id}><EngineQuestion pack={pack} card={card} disabled reveal /></article>)}{!filtered.length && <p>Aucune fiche ne correspond à cette recherche.</p>}<nav className="er-pagination" aria-label="Pages des fiches de lecture"><button type="button" className="secondary" disabled={safePage === 0} onClick={() => setPage(safePage - 1)}><ChevronLeft size={17} />Page précédente</button><button type="button" className="secondary" disabled={safePage >= pages - 1} onClick={() => setPage(safePage + 1)}>Page suivante<ChevronRight size={17} /></button></nav></section>}
    {tab === 'pdf' && <section className="panel"><ChapterPdf pack={pack} /></section>}
    {tab === 'sources' && <section className="panel er-references"><h3><FileText size={20} />Documents cités par ce paquet</h3><p>Les chemins d’origine restent des références bibliographiques. Lorsqu’un nom de fichier a été retrouvé dans le Drive fourni, un bouton de lecture est proposé.</p>{references.length ? references.map(reference => { const documents = engineDocumentsForSource(pack.id, reference.id); return <article key={reference.id}><span className="soft-badge">{reference.kind} · {documents.length ? 'nom de fichier retrouvé sur Drive' : 'fichier non retrouvé dans ce Drive'}</span><h4>{reference.title}</h4>{reference.author && <p>{reference.author}</p>}{reference.path && <p className="er-reference-path">Référence d’origine : {reference.path}</p>}{reference.note && <p>{reference.note}</p>}{documents.map(document => <EngineDocumentLink document={document} key={document.id} />)}</article>; }) : <p>Aucune référence documentaire séparée n’est déclarée dans ce paquet.</p>}<button type="button" className="secondary" onClick={() => setTab('pdf')}>Ajouter mon PDF de cours</button></section>}
  </section>;
}
