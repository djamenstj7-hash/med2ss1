import { defineConfig } from 'vitest/config';

export default defineConfig({
  base: './',
  test: {
    include: ['engine-tests/**/*.test.ts', 'engine-tests/**/*.test.tsx'],
    environment: 'node',
    pool: 'forks',
    maxWorkers: 2,
  },
  esbuild: { jsx: 'automatic' },
});
