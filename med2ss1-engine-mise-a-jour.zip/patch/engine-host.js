/* MED_ENGINE dans MED2 S1 : seul ce petit chargeur appartient au shell initial. */
(() => {
  'use strict';
  const RELEASE = '20261028-v050-engine1';
  let loading = null;
  let generation = 0;
  let cleanup = null;

  function resource(path) {
    const url = new URL(path, document.baseURI);
    url.searchParams.set('v', RELEASE);
    return url.href;
  }

  function stylesheet() {
    const existing = document.querySelector('link[data-med2-engine-css]');
    if (existing?.sheet) return Promise.resolve();
    return new Promise((resolve, reject) => {
      const link = existing || document.createElement('link');
      link.rel = 'stylesheet';
      link.href = resource('./engine-module/engine.css');
      link.dataset.med2EngineCss = '';
      const timer = setTimeout(() => fail(), 30000);
      const fail = () => { clearTimeout(timer); link.remove(); reject(new Error('La présentation de MED_ENGINE n’a pas pu être chargée.')); };
      link.onload = () => { clearTimeout(timer); resolve(); };
      link.onerror = fail;
      if (!existing) document.head.append(link);
    });
  }

  function javascript() {
    if (window.Med2Engine?.mount) return Promise.resolve();
    return new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = resource('./engine-module/engine.js');
      script.async = true;
      const timer = setTimeout(() => fail(), 30000);
      const fail = () => { clearTimeout(timer); script.remove(); reject(new Error('Le module MED_ENGINE n’a pas pu être chargé.')); };
      script.onload = () => {
        clearTimeout(timer);
        if (window.Med2Engine?.mount) resolve();
        else fail();
      };
      script.onerror = fail;
      document.head.append(script);
    });
  }

  function load() {
    if (!loading) loading = Promise.all([stylesheet(), javascript()]).catch(error => { loading = null; throw error; });
    return loading;
  }

  function leave() {
    generation++;
    const dispose = cleanup;
    cleanup = null;
    if (dispose) dispose();
  }

  function enter(target) {
    leave();
    if (!target?.isConnected) return;
    const current = generation;
    target.innerHTML = '<section class="card engine-load" role="status"><h1>MED_ENGINE</h1><p>Chargement des chapitres et de ton suivi…</p></section>';
    load().then(() => {
      if (current !== generation || !target.isConnected) return;
      const dispose = window.Med2Engine.mount(target);
      cleanup = typeof dispose === 'function' ? dispose : () => window.Med2Engine?.unmount?.();
    }).catch(() => {
      if (current !== generation || !target.isConnected) return;
      target.innerHTML = '<section class="card engine-load" role="alert"><h1>MED_ENGINE</h1><p>Le module n’a pas pu être ouvert. Vérifie la connexion et réessaie. Pour l’utiliser sans réseau, prépare son téléchargement dans ses réglages.</p><button type="button" class="btn" data-engine-retry>Réessayer</button></section>';
      target.querySelector('[data-engine-retry]').addEventListener('click', () => enter(target));
    });
  }

  window.Med2EngineHost = Object.freeze({ enter, leave, load });
  addEventListener('pagehide', leave);
  addEventListener('pageshow', event => {
    const target = document.getElementById('med2-engine-mount');
    if (event.persisted && target) enter(target);
  });
})();
