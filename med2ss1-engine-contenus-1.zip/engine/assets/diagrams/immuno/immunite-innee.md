---
id: immuno/immunite-innee
titre: L'immunité innée, étape par étape — brèche, détection, alarme, quatre acteurs, relais adaptatif
ue: Immunologie
chapitre: Immunité innée et réponse inflammatoire ; organisation temporelle de la réponse immunitaire
themes_app: []
cartes_en_plus: [imm-fa-missions-innee, imm-qc-innee, imm-fa-capteurs, imm-qc-capteurs, imm-qc-forces-innee, imm-fa-frise, imm-qc-frise, imm-qc-cellule-dendritique, inn-qc-mediateurs, inn-qc-macrophages, inn-qc-pnn, inn-qc-nk-cytokines, inn-fa-mediateurs-tardifs, inn-ech-nk-m3, inn-fa-phase-cellulaire, inn-fa-phagocytes, inn-ech-nk-s12, inn-rv-pnn-macrophage, inn-ech-pha-m3, inn-fa-inflammation, inf-qc-tlr, inf-qr-tlr4, inf-fa-tlr, inf-qc-interferons, inf-fa-ifn, inf-rv-ifn-types, inf-qr-ifn-viraux, inf-qc-cooperation-macrophage, lex-chimiokine, inn-an-2021s2-q9, inf-an-2425s1-q10]
cartes_exclues: []
mots_cles: [immunité innée, barrière, PRR, PAMP, DAMP, TLR, sentinelles, macrophages, cellules dendritiques, mastocytes, cytokines, IL-1, TNF-α, IL-6, chimiokines, IL-8, CCL2, interférons de type I, inflammasome, inflammation, neutrophiles, monocytes, cellules NK, IFN-γ]
schema: immunite-innee.html
majeur: true
date: 2026-10-24
---

## Explication

> Schéma fourni par Vincent (fiche « Immunologie, partie 1 », section 7 : https://claude.ai/artifact/84U99NbJwDZSXbtZHNRdca), mis au format MED_ENGINE. Cours : Immuno_partie1_161025 (16/10/2025) et chapitres `immuno_*` de l'application.

### Le schéma

1. **Brèche** : un microbe franchit la barrière (peau, muqueuses), ou un tissu est lésé.
2. **Détection** : les sentinelles déjà en place (macrophages, cellules dendritiques, mastocytes, épithéliums) reconnaissent par leurs PRR (TLR…) les PAMP du microbe et les DAMP des cellules lésées. Le complément, lui, s'active directement, sans PRR.
3. **Alarme** : cytokines (IL-1, TNF-α, IL-6), chimiokines (IL-8, CCL2), interférons de type I, inflammasome.
4. **Quatre acteurs** : le complément (opsonisation, recrutement, lyse) ; l'inflammation, qui recrute les neutrophiles (en quelques heures) puis les monocytes, qui deviennent des macrophages (en 1 à 2 jours) ; les cellules NK, qui tuent les cellules infectées ou tumorales et sécrètent l'IFN-γ ; les cellules dendritiques, qui capturent l'antigène, migrent au ganglion et activent les LT naïfs.
5. **Issue** : élimination du pathogène (phagocytose, lyse, cytotoxicité) puis résolution ; relais vers la réponse adaptative (J4 à J7).

### Neutrophile ou macrophage ?

Le neutrophile est le premier recruté en masse, rapide et à vie courte. Le macrophage est à la fois sentinelle (présent dans le tissu avant l'infection) et nettoyeur (issu ensuite des monocytes recrutés) ; il donne l'alerte par les cytokines.

## Cartes

### Q: Que reconnaissent les PRR des cellules sentinelles ?
R: Les PAMP, motifs moléculaires communs aux microbes, et les DAMP, signaux de danger libérés par les cellules lésées.

### Q: Dans quel ordre arrivent neutrophiles et monocytes au site inflammatoire ?
R: Les neutrophiles d'abord, en quelques heures ; les monocytes ensuite, en 1 à 2 jours, qui deviennent des macrophages dans le tissu.

### Q: Quelle cellule fait le lien entre immunité innée et adaptative ?
R: La cellule dendritique : elle capture l'antigène dans le tissu, migre au ganglion et active les LT naïfs.
