---
id: immuno/immunite-adaptative
titre: La réponse adaptative — présentation au ganglion, trois lymphocytes, contraction et mémoire
ue: Immunologie
chapitre: Organisation temporelle ; réponse immunitaire T ; activation des LB ; contraction clonale et mémoire
themes_app: []
cartes_en_plus: [imm-fa-missions-adaptative, imm-qc-adaptative, imm-fa-effecteurs, imm-qc-effecteurs, imm-fa-humorale-cellulaire, imm-qc-humorale-cellulaire, imm-fa-etapes, imm-qc-etapes, imm-qc-reintroduction, imm-qr-anamnestique, imm-qc-forces-adaptative, rpt-qc-cd4-cd8, rpt-qc-signal-1, rpt-qc-signal-2, rpt-rv-trois-signaux, rpt-fa-trois-signaux, rpt-qr-cd28, rpt-qr-aide-cd8, rpt-qc-cytokines-th, rpt-qc-cytotoxicite, rpt-qc-trois-reponses, rpt-qc-cd40, rpt-rv-cd40, rpt-ech-m7, rpt-ech-m9, rpt-ech-s4, rpt-ech-s17, rpt-an-2324s1-q2, rpt-an-2021s1-q4, rpt-an-2122s2-q4, alb-ech-m4, alb-an-2021-qroc5, mem-fa-types, mem-qc-types, mem-qc-origine, mem-qc-duree-vie, mem-ech-m1]
cartes_exclues: []
mots_cles: [immunité adaptative, cellule dendritique, ganglion, LT naïf, CMH, signal 1, signal 2, CD80, CD86, CD28, signal 3, expansion clonale, IL-2, LT CD8, perforine, granzymes, LT CD4, Th1, Th2, Th17, Tfh, Treg, lymphocyte B, centre germinatif, commutation de classe, maturation d'affinité, plasmocyte, anticorps, contraction, mémoire, réponse secondaire]
schema: immunite-adaptative.html
majeur: true
date: 2026-10-24
---

## Explication

> Schéma fourni par Vincent (fiche « Immunologie, partie 1 », section 7 : https://claude.ai/artifact/84U99NbJwDZSXbtZHNRdca), mis au format MED_ENGINE. Cours : Immuno_partie1_161025 (16/10/2025) et chapitres `immuno_*` de l'application.

### Le schéma

1. **Capture** : une cellule dendritique capture l'antigène dans le tissu et migre au ganglion.
2. **Présentation aux LT naïfs** : signal 1 (peptide-CMH), signal 2 (CD80/86–CD28), signal 3 (cytokines), puis expansion clonale (IL-2).
3. **Trois lymphocytes** :
   - LT CD8 cytotoxique : reconnaît le CMH I ; perforine, granzymes ; tue la cellule infectée (apoptose sans inflammation).
   - LT CD4 auxiliaire : reconnaît le CMH II ; Th1, Th2, Th17, Tfh, Treg ; oriente toute la réponse, aide les LT CD8 et les LB, renforce l'inné (macrophages et neutrophiles activés).
   - Lymphocyte B : reconnaît l'antigène natif ; centre germinatif avec les Tfh ; commutation de classe, maturation d'affinité ; plasmocytes qui sécrètent les anticorps (IgM, puis IgG, IgA ou IgE).
4. **Contraction et mémoire** : 90 % des effecteurs meurent ; restent des LT et LB mémoire et des plasmocytes à longue vie. La réponse secondaire est plus rapide, plus forte, avec des IgG de haute affinité.

### Le piège classique

Le LT reconnaît un peptide présenté par le CMH ; le LB reconnaît l'antigène natif, entier.

## Cartes

### Q: Quels sont les trois signaux d'activation d'un LT naïf ?
R: Signal 1 : peptide présenté par le CMH reconnu par le TCR ; signal 2 : costimulation CD80/86–CD28 ; signal 3 : cytokines. Puis expansion clonale sous IL-2.

### Q: Quelle classe de CMH reconnaissent les LT CD8 et les LT CD4 ?
R: CD8 : CMH I ; CD4 : CMH II.

### Q: Pourquoi la réponse secondaire est-elle plus rapide et plus forte ?
R: Après la contraction (90 % des effecteurs meurent), restent des LT et LB mémoire et des plasmocytes à longue vie ; les LB mémoire ont déjà commuté et maturé leur affinité (IgG de haute affinité).
