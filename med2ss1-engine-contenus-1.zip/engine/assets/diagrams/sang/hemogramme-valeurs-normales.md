---
id: sang/hemogramme-valeurs-normales
titre: Hémogramme — valeurs normales et noms des anomalies
ue: Tissu sanguin
chapitre: Myélogramme et hémogramme normaux (ronéo 2026-27, p. 3-13)
themes_app: [sang_hemogramme/hemogramme]
cartes_en_plus: [hem-qr-seuils-plaquettes, hem-fa-plaquettes, hem-qc-thrombopenie, hem-fa-anemie, hem-qc-anemie-def, hem-fa-polyglobulie, hem-qc-polyglobulie, hem-fa-neutropenie, hem-qc-neutropenie, hem-fa-agranulocytose, hem-qc-agranulocytose, hem-rv-thrombocytose, hem-rv-lymphopenie, hem-qc-lymphocytose, hem-qc-neutrophilie, hem-ech-s1, hem-ech-s12, hem-ech-m4, hem-an-2324-q10, hem-an-2425-q6, hem-an-2021s2-q4]
cartes_exclues: [hem-qc-examens, hem-qr-frottis]
mots_cles: [hémogramme, NFS, valeurs normales, hémoglobine, VGM, CCMH, réticulocytes, plaquettes, leucocytes, neutrophiles, éosinophiles, basophiles, lymphocytes, monocytes, anémie, polyglobulie, thrombopénie, thrombocytose, leucopénie, neutropénie, agranulocytose, pancytopénie]
schema: hemogramme-valeurs-normales.html
majeur: true
date: 2026-10-21
---

## Explication

> Valeurs du ronéo 2026-27 « Myélogramme et hémogramme normaux », telles que les cartes de `sang_hemogramme` les retiennent (décompte normal p. 3, bornes des leucocytes p. 5, anémie p. 9, polyglobulie, plaquettes p. 13). Le seuil de 120 G/L de réticulocytes vient du ronéo 2024-25 et de l'arbre décisionnel (`sang_anemies`). L'ancien cours donnait d'autres normes pour certains leucocytes (monocytes 0,2-1, neutrophiles 2-7,5) : retenir celles-ci.

### Le tableau

| Paramètre | Normale | En dessous | Au-dessus |
|---|---|---|---|
| Hémoglobine | ≥ 12 g/dL (F), ≥ 13 (H) | Anémie : < 12 (F), < 13 (H), < 11 (femme enceinte) | Polyglobulie : > 17,5 (F), > 18,5 (H) |
| VGM | 80-100 fL | Microcytose < 80 | Macrocytose > 100 |
| CCMH | 32-36 g/dL | Hypochromie < 32 | > 36 : pas de sens clinique |
| Réticulocytes | 25-100 G/L | Anémie arégénérative | > 120 : régénérative |
| Plaquettes | 150-450 G/L | Thrombopénie < 150 (saignements provoqués < 50, spontanés < 20) | Thrombocytose > 450 |
| Leucocytes | 4-10 G/L | Leucopénie < 4 | Hyperleucocytose > 10 |
| Neutrophiles | 1,5-7 G/L | Neutropénie < 1,5 ; agranulocytose < 0,5 (risque majeur) | Neutrophilie > 7 |
| Éosinophiles | 0-0,4 G/L | — | Éosinophilie > 0,4 |
| Basophiles | 0-0,1 G/L | — | Basophilie > 0,1 |
| Lymphocytes | 1,5-4 G/L | Lymphopénie < 1,5 | Lymphocytose > 4 |
| Monocytes | 0,2-0,8 G/L | — | Monocytose > 0,8 |

Les trois lignées basses : pancytopénie.

### Conversion

1 G/L = 1 000 /mm³ : un compte en /mm³ se divise par 1 000 (551 000 plaquettes/mm³ = 551 G/L ; 1 900 lymphocytes/mm³ = 1,9 G/L, normal).

### Lire un hémogramme

1. Hémoglobine : anémie ou polyglobulie (l'anémie se définit sur l'hémoglobine, pas sur l'hématocrite).
2. VGM : micro-, normo- ou macrocytaire, qui oriente vers la cause.
3. Réticulocytes : la moelle compense-t-elle ?
4. Plaquettes puis globules blancs, en valeur absolue (G/L), jamais en pourcentage.

Exemple (Mme A, 25 ans) : Hb 8,4, VGM 76, plaquettes 551 G/L, globules blancs normaux → anémie microcytaire avec thrombocytose, le profil de la carence en fer.

## Cartes

### Q: Quelles sont les valeurs normales des leucocytes et de leur formule ?
R: Leucocytes 4-10 G/L ; neutrophiles 1,5-7 ; éosinophiles 0-0,4 ; basophiles 0-0,1 ; lymphocytes 1,5-4 ; monocytes 0,2-0,8 G/L.

### Q: Comment convertir un compte cellulaire en /mm³ en G/L ?
R: Diviser par 1 000 : 1 G/L = 1 000 /mm³ (ex. 551 000 plaquettes/mm³ = 551 G/L).

### Q: Quelles anomalies présente un hémogramme avec Hb 8,4 g/dL, VGM 76 fL, plaquettes 551 G/L et une formule leucocytaire normale chez une femme de 25 ans ?
R: Une anémie (< 12 g/dL) microcytaire (VGM < 80 fL) avec thrombocytose (> 450 G/L) ; leucocytes normaux. Profil de la carence en fer.
