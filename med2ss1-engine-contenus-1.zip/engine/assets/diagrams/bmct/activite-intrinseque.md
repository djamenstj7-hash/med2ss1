---
id: bmct/activite-intrinseque
titre: Activité intrinsèque, agonistes, antagonistes et agonistes inverses
ue: BMCT
chapitre: FC n°1 - Pharmacodynamie générale, I.E Agoniste / Antagoniste (p. 4-5)
themes_app: [bmct_pharmacodynamie/agonistes]
cartes_en_plus: []
cartes_exclues: []
mots_cles: [activité intrinsèque, affinité, agoniste entier, agoniste partiel, antagoniste, agoniste inverse, activité constitutive, AMP cyclique]
schema: activite-intrinseque.html
majeur: true
date: 2026-10-18
---

## Explication

> Le cours (p. 4-5) donne la classification par l'activité intrinsèque, l'AMPc comme lecture de l'effet, la baisse de 5 à 10 % de l'agoniste inverse et la buprénorphine comme agoniste partiel. La notion d'activité constitutive et l'exemple du bêtabloquant sont du complément de compréhension. Les valeurs du schéma sont illustratives.

### Le point de départ : le récepteur n'est jamais complètement éteint

Même sans aucun ligand, un récepteur bascule spontanément de temps en temps dans sa forme active et produit un peu d'AMPc : c'est son activité constitutive, la « production endogène, indépendamment de toute stimulation par un ligand » du cours. Elle fixe un niveau basal d'AMPc, et chaque type de ligand se définit par ce qu'il fait par rapport à ce niveau.

### L'activité intrinsèque (α)

C'est l'effet produit quand le ligand occupe tous les récepteurs, rapporté à l'effet maximal possible (« l'augmentation de l'AMP cyclique maximale jamais observée »). Elle ne dit rien de la force de fixation (c'est l'affinité), mais de ce que le ligand fait au récepteur une fois fixé.

- **α = 1, agoniste entier** : il fait basculer le récepteur en forme active, l'AMPc monte au maximum.
- **0 < α < 1, agoniste partiel** : même à saturation, il n'atteint qu'une partie du maximum.
- **α = 0, antagoniste** : il se fixe sans changer la forme du récepteur, l'AMPc reste au niveau basal.
- **α < 0, agoniste inverse** : il bloque le récepteur en forme inactive et supprime même l'activité spontanée ; l'AMPc passe sous le niveau basal.

### « Pas d'effet sur l'AMPc, mais un effet pharmacologique »

L'antagoniste agit en occupant la place : tant qu'il est fixé, l'agoniste ne peut plus se fixer. Son effet est invisible au repos et n'apparaît qu'en présence d'un agoniste. Exemple (hors cours) : un bêtabloquant change peu la fréquence cardiaque au repos, mais à l'effort il empêche l'adrénaline de stimuler les récepteurs β1 ; l'AMPc ne monte pas et le cœur accélère beaucoup moins. Son effet, c'est d'empêcher la montée, pas de faire baisser.

### Pourquoi l'agoniste inverse fait si peu (5 à 10 %)

Il ne peut retirer que la part d'AMPc due à l'activité spontanée du récepteur, et cette part est petite (une partie de l'AMPc de la cellule vient d'autres voies). Il ne fait donc baisser l'AMPc que d'un cran sous le niveau basal : en pratique, il se distingue peu d'un antagoniste. La différence ne devient importante que si l'activité spontanée est forte (récepteur muté ou surexprimé).

### L'agoniste partiel, agoniste ou antagoniste selon le contexte

Seul, l'agoniste partiel stimule : l'effet monte au-dessus du niveau basal. En présence d'un agoniste entier, il lui prend des récepteurs et fait baisser l'effet total : il se comporte en antagoniste fonctionnel. C'est l'exemple du cours avec la buprénorphine (Subutex), agoniste partiel des récepteurs opioïdes μ : chez un patient sous buprénorphine, une injection d'héroïne produit un effet moindre.

## Cartes

### Q: Qu'est-ce que l'activité constitutive d'un récepteur, et quel type de ligand la supprime ?
R: L'activité spontanée du récepteur en l'absence de tout ligand (il bascule parfois seul en forme active et produit un peu d'AMPc). L'agoniste inverse la supprime, d'où une baisse de l'AMPc sous le niveau basal.

### Q: Pourquoi l'effet d'un antagoniste n'apparaît-il qu'en présence d'un agoniste ?
R: Son activité intrinsèque est nulle : seul, il ne change pas l'AMPc. Son effet est d'occuper le récepteur et d'empêcher l'agoniste d'agir, ce qui ne se voit que si un agoniste est présent.

### Q: Pourquoi, en pratique, un agoniste inverse se distingue-t-il peu d'un antagoniste ?
R: Il ne retire que la part d'AMPc due à l'activité spontanée du récepteur, qui est faible : la baisse n'est que de 5 à 10 %.

### Q: Quelle différence entre affinité et activité intrinsèque ?
R: L'affinité mesure la capacité du ligand à se fixer sur le récepteur ; l'activité intrinsèque mesure l'effet qu'il produit une fois fixé (de 1 pour un agoniste entier à moins de 0 pour un agoniste inverse).
