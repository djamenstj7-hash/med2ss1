---
id: bmct/essai-parallele-croise
titre: Essai parallèle ou essai croisé — et pourquoi le parallèle pour une maladie évolutive
ue: BMCT
chapitre: FC n°1 - Pharmacodynamie générale, partie 3, I. Comparaison (p. 2)
themes_app: []
cartes_en_plus: [pdg-an-1617s1-q2b, pdg-qc-comparaison, pdg-qc-comparabilite, pdg-qr-randomisation, pdg-ech-s25, pdg-fa-trois-principes]
cartes_exclues: []
mots_cles: [essai parallèle, essai croisé, wash-out, effet rémanent, carry-over, comparabilité, maladie évolutive, propre témoin]
schema: essai-parallele-croise.html
majeur: true
date: 2026-10-18
---

## Explication

> Le cours (partie 3, p. 2) donne : l'essai croisé demande moins de sujets, il suppose que le sujet soit identique au début de la seconde période, et il ne convient pas au système nerveux central (plasticité cérébrale). L'effet rémanent (carry-over) et la liste des indications du croisé sont du complément. L'application a déjà un schéma de ce cours (`essai-parallele-croise.svg`) ; celui-ci est l'explication pas à pas.

### Les deux plans

- **Essai parallèle** : deux groupes de patients différents, l'un sous molécule, l'autre sous placebo (ou traitement de référence), pendant toute la durée de l'essai. La randomisation rend les deux groupes comparables.
- **Essai croisé** : chaque patient reçoit les deux traitements l'un après l'autre, dans un ordre tiré au sort, séparés par une période sans traitement (wash-out) qui élimine le premier produit. On compare le patient à lui-même.

L'atout du croisé : chaque sujet est son propre témoin, la variabilité entre individus disparaît, il faut beaucoup moins de patients.

### La condition du croisé

Il ne marche que si le patient est le même au début de la période 2 qu'au début de la période 1 : seul le traitement doit changer entre les deux.

### Pourquoi le parallèle dans l'annale 2016/2017 (Q2 b)

- **La maladie est évolutive** : entre les deux périodes, le patient s'est aggravé. Une différence en période 2 peut venir de la progression de la maladie autant que du traitement : l'effet du temps se confond avec celui du médicament.
- **Les lésions sont visibles en IRM**, a priori irréversibles : un bénéfice obtenu en période 1 persiste en période 2. Le wash-out élimine le médicament, pas son effet (effet rémanent ou carry-over).
- **C'est une atteinte du système nerveux central** : le cours précise que le médicament agit sur la plasticité cérébrale, si bien qu'on ne peut pas être sûr que le sujet soit le même à la seconde période.

En parallèle, les deux groupes évoluent pendant le même temps : le temps touche les deux bras de la même façon, la seule différence reste le traitement. C'est le principe de comparabilité que demande la question.

### Le réflexe d'examen

Croisé : maladie chronique stable, traitement à effet rapide et réversible (hypertension, asthme stable, douleur chronique). Dès que l'énoncé parle de maladie évolutive, de lésions, de guérison possible, d'effet durable ou de système nerveux central : essai parallèle.

## Cartes

### Q: Quelle condition un essai croisé suppose-t-il ?
R: Que le sujet soit identique au début de la seconde période : seul le traitement change d'une période à l'autre (maladie stable, effet du traitement réversible, wash-out suffisant).

### Q: Pourquoi choisir un essai parallèle plutôt que croisé pour une maladie évolutive ?
R: Le patient s'aggrave entre les deux périodes : l'effet du temps se confondrait avec celui du traitement. En parallèle, les deux groupes évoluent pendant le même temps et seule la molécule les distingue.

### Q: Qu'est-ce que l'effet rémanent (carry-over) dans un essai croisé ?
R: Un effet du premier traitement qui persiste pendant la seconde période malgré le wash-out (le médicament est éliminé, pas son effet, par exemple sur des lésions) : il fausse la comparaison.

### Q: Quel est l'avantage de l'essai croisé sur l'essai parallèle ?
R: Chaque sujet est son propre témoin : la variabilité entre individus disparaît, et il faut moins de sujets.
