---
id: bmct/ki-affinite
titre: Le Ki — une concentration qui mesure l'affinité (et pourquoi Ki bas = affinité forte)
ue: BMCT
chapitre: FC n°1 - Pharmacodynamie générale, I.D Sélection des produits (p. 3-4)
themes_app: [bmct_pharmacodynamie/affinite]
cartes_en_plus: []
cartes_exclues: [pdg-ech-s9]
mots_cles: [Ki, Kd, CI50, constante de dissociation, constante d'association, affinité, sélectivité, occupation des récepteurs, criblage]
schema: ki-affinite.html
majeur: true
date: 2026-10-19
---

## Explication

> Le cours (p. 3-4) mesure l'affinité par le Ki, « la méthode la plus simple et compréhensible », et retient au criblage la molécule de Ki le plus faible. La forme de l'équilibre, le lien avec ΔG° et le passage CI50 → Ki sont du complément. Voir aussi [[bmct/affinite-activite]].

### L'équilibre de liaison

Le ligand L se fixe de façon réversible sur le récepteur R : L + R ⇌ LR. La constante s'écrit dans le sens de la **dissociation** (LR → L + R) :

Ki = [L]·[R] / [LR]

Aucune activité ni aucun effet n'entre dans le calcul, seulement des concentrations à l'équilibre : le Ki mesure la liaison (l'affinité), rien de l'activité intrinsèque. Deux concentrations au numérateur, une au dénominateur : il a l'unité d'une concentration (nM, µM).

### Ce qu'il veut dire

Quand la moitié des récepteurs est occupée, [R] libre = [LR] : les deux termes s'annulent et il reste Ki = [L]. **Le Ki est la concentration de ligand qui occupe la moitié des récepteurs.**

- Ki bas (1 nM) : il en faut très peu pour occuper la moitié des récepteurs, le ligand s'accroche fort : affinité forte.
- Ki élevé (100 nM) : il en faut beaucoup pour la même occupation : affinité faible.

Le schéma montre les deux courbes d'occupation ; le curseur de concentration donne, à chaque concentration, la part des récepteurs occupés par chaque molécule.

### Le lien avec la thermodynamique

Écrite dans l'autre sens, la constante d'association vaut Ka = 1/Ki et grandit avec l'affinité, comme l'intuition le voudrait ; la pharmacologie utilise la constante de dissociation parce qu'elle se lit directement comme une concentration. Côté énergie : ΔG°(liaison) = RT·ln Ki (Ki en mol/L) ; plus le Ki est petit, plus la liaison est favorable ; un facteur 10 sur le Ki vaut environ 5,7 kJ/mol à 37 °C.

### Ki, Kd, CI50

Le Kd est la constante de dissociation mesurée directement, avec un ligand marqué. Le Ki est la même grandeur pour une molécule non marquée (souvent un inhibiteur ou un antagoniste), obtenue par compétition : on mesure la concentration qui déplace la moitié d'un ligand marqué de référence (la CI50), puis on corrige pour la concurrence de ce ligand. Même lecture : bas = forte affinité.

### Le piège : affinité n'est pas sélectivité

Le ronéo écrit « plus le Ki est faible, meilleure est la sélectivité » (p. 4) : c'est faux tel quel (déjà signalé `ATTENTION` dans `pdg-qc-affinite`). Un Ki faible signe une forte affinité. La sélectivité se juge en comparant les Ki d'une même molécule sur plusieurs sous-types de récepteurs : une molécule peut avoir un Ki très bas sur tous et n'être sélective de rien.

## Cartes

### Q: Pourquoi le Ki a-t-il l'unité d'une concentration ?
R: C'est une constante de dissociation, Ki = [L]·[R]/[LR] : deux concentrations au numérateur, une au dénominateur. Elle ne fait intervenir aucune activité, seulement des concentrations à l'équilibre.

### Q: Que représente concrètement le Ki ?
R: La concentration de ligand qui occupe la moitié des récepteurs (à 50 % d'occupation, [R] libre = [LR], donc Ki = [L]).

### Q: Pourquoi un Ki bas signe-t-il une forte affinité ?
R: Parce qu'il faut alors très peu de ligand pour occuper la moitié des récepteurs : le ligand s'accroche fort. Le Ki est une constante de dissociation ; la constante d'association, Ka = 1/Ki, varie dans le même sens que l'affinité.

### Q: Une molécule de Ki très bas est-elle forcément sélective ?
R: Non. Un Ki bas signe une forte affinité ; la sélectivité se juge en comparant les Ki de la molécule sur plusieurs sous-types de récepteurs. Une molécule peut avoir un Ki très bas sur tous.
