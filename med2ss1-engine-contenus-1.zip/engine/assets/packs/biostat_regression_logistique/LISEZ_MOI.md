# Régression logistique — paquet Biomédecine quantitative

81 notes, 118 cartes. Chapitre `chap-ue-biomed-quanti-fc13` de l'UE
Biomédecine quantitative, onzième de l'UE. Cours du **Pr G. Ficheur, le
03/12/2025, de 8 h à 9 h 15**, dans le **Ronéosaure 2025-26** (FC n°11, 11
pages) ; les annales de trois polycopiés du Ronéosaure 2024-25 (13 sessions
citées). Examen : partiel du mercredi 16 décembre 2026.

**Fiche provisoire** (C15, décision de Vincent du 02/10) : le cours de l'année
2026-27 n'est pas encore paru. Chaque carte de cours cite la FC 2025-26 à sa
page, et l'application montre « Cours 2025-26 » ; le ronéo 2026-27 la corrigera
quand il sortira. Aucune carte n'est « Absent du cours 2026-27 ».

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 54 | 54 |
| QRU | 1 | 1 |
| Texte à trous | 8 | 42 |
| QROC | 7 | 7 |
| Recto-verso | 2 | 2 |
| Lexique | 8 | 8 |
| Schéma cliquable | 1 | 4 |

Dont **36 annales** sur 13 sessions (25 du polycopié « 13 - Régression
logistique », 5 du « 2. Régression linéaire », 6 du « 14 - Analyses de
survie »), et 19 QCM de cours.

Huit thèmes, plus `hors-fiche`. `coefficients` (régression linéaire multiple)
et `hors-fiche` (sémiologie) existent, et leur libellé dit vrai ici ; les sept
autres clés sont nouvelles et leurs libellés restent à ajouter à
`THEME_LABELS` (`app/src/med_engine/application/scopes.py`) :

| Clé | Libellé | Notes |
|---|---|---|
| `multivarie` | Analyses multivariées | 12 |
| `usages-modele` | Expliquer ou prédire : choisir les variables | 4 |
| `confidentialite-donnees` | Confidentialité des données de recherche | 2 |
| `logit` | Modéliser une variable binaire | 15 |
| `coefficients` *(existante)* | Lire les coefficients d'un modèle | 28 |
| `rr-or` | Risque relatif, odds ratio, hazard ratio | 4 |
| `facteurs-confusion` | Facteurs de confusion et ajustement | 4 |
| `hypotheses-rlog` | Logit-linéarité et événements par variable | 4 |
| `hors-fiche` *(existante, tag en plus du thème)* | Tombé en annales, absent de la fiche | 7 |

Le plan C15 proposait `confidentialite` : le mot seul est celui qu'une autre UE
voudrait (le secret médical, en SSH) ; la clé devient `confidentialite-donnees`,
au même libellé. `multivarie`, `rr-or` et `facteurs-confusion` sont partagées
avec d'autres chapitres de l'UE (scores, pharmacovigilance, survie, phase III),
aux libellés du plan.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-biomed-rlg-2526` — Ronéosaure, « FC n°11 - Régression logistique » (11 p.) | 2025-26 | le cours ; `SRC["fiche"]` et 12 de ses figures. Le chapitre des phases I et II la cite déjà sous cet identifiant (lexique, « Hypothético-déductif », p. 3) |
| `src-annales-13-regression-logistique` — « 13 - Régression logistique » (13 p.) | 2024-25 | 13 sessions de 2017/2018 S1 à 2023/2024 S2 ; table p. 13 ; `SRC["annales"]` |
| `src-annales-2-regression-lineaire` — « 2. Régression linéaire » (32 p.) | 2024-25 | cinq questions ; la session 2023/2024 S1 le cite (`SRC["sessions"]`) ; déclaration recopiée de `biostat_regression_lineaire` |
| `src-annales-14-analyses-de-survie` — « 14 - Analyses de survie » (13 p.) | 2024-25 | six questions sur les modèles multivariés ; table p. 13 |

Les trois sources d'annales sont déclarées selon la règle commune de C15 (id
tiré du nom du fichier, cinq champs, rien d'autre), à l'identique dans
`biostat_scores`, `biostat_regression_lineaire`, `biostat_phase_4_eim` et
`biostat_survie` (vérifié à la relecture). Le modèle de générateur ne connaît qu'une
source d'annales par session, et les trois polycopiés partagent leurs sessions :
2023/2024 S1 cite le n°2 (trois de ses quatre questions), toutes les autres le
n°13 ; chaque carte imprimée dans un autre polycopié que celui qu'elle cite le
dit dans son explication.

Lus en appoint sans être déclarés : le cours n°13 2024-25 (« Régression
logistique ») et le Charonéo 2023-24 (n°12), qui ne traitent ni le pouvoir
discriminant ni le test de Hosmer-Lemeshow ; l'errata des cours 2025-26 (aucune
entrée pour la FC n°11) et celui des annales 2024-25 (aucune entrée pour ces
trois polycopiés).

Les en-têtes des ronéos, des erratas et des polycopiés portent des noms
d'étudiants : aucun n'est repris. Les polycopiés n°13 et n°14 attribuent le
cours au « Pr Décaudin » : c'est le Pr Ficheur, on ne reprend pas
l'attribution.

## Ce que le cours a dicté

- **Le rouge** : les titres ; « OR = exp(β) » et « dans le modèle de régression
  logistique, on prend l'exponentiel du coefficient » (p. 7) ; la lecture d'un
  OR quantitatif « pour un gain d'1 point » (p. 7) ; « OR > 1, facteur de
  risque » (p. 8) ; la condition OR ≈ RR, maladie rare sous 10 % (p. 6). Chacun
  a sa carte (`rlg-qc-exp-beta`, `rlg-qc-age`, `rlg-fa-or`,
  `rlg-fa-significativite`, `rlg-qc-rr-or`, `rlg-fa-rr-or`).
- **Le gris** est la voix des rédacteurs (décision du 25/09) : « vu dans la
  suite du cours » (p. 2) ; la question d'un étudiant sur la taille de l'IC et
  le nombre de sujets (p. 8), qui relève du chapitre des phases I et II (nombre
  de sujets nécessaires) et n'a pas de carte ici ; les points influents (p. 11,
  « le prof est vite passé »), cités dans les annales de régression linéaire.
- **Les frontières (plan C15)** : les « méthodes d'analyse multivariée »
  (tester séparément ou simultanément, plusieurs Y, Student) sont au chapitre
  des scores cliniques ; le modèle de Cox et le hazard ratio à celui des
  analyses de survie ; le RR et l'OR des études de pharmacovigilance à la FC
  n°9 — la définition du RR, la cohorte qui donne RR et OR, l'étude
  cas-témoins qui ne donne que l'OR, même quand la FC n°11 les rappelle (p. 6).
  Ici, les « modèles multivariés » des annales (ajustement, p > 0,05, âge
  quantitatif ou qualitatif, IC) et le reste de la FC n°11 : l'OR du modèle
  (exp β), qui n'approche le RR que si la maladie est rare (p. 6, 11), et la
  confidentialité des données (p. 4).
- **Précisions sans ATTENTION**, dites dans les cartes : le rouge « une seule
  condition pour laquelle OR = RR » est une approximation, que la phrase
  annonce (`rlg-qc-rr-or`) ; la diapositive de la p. 7 écrit « 1 » dans la
  colonne « estimation » de la référence, c'est son OR (`rlg-qc-tabac`) ; et
  « 1,12¹⁰ = 3,00 » est calculé sur l'OR non arrondi, e^1,1 ≈ 3,0 (avec 1,12,
  on trouve 3,1) (`rlg-qc-age`, `rlg-fa-or`). Au sens strict, l'OR multiplie
  la cote de l'événement ; le professeur le lit comme un risque « multiplié »,
  entre guillemets sur ses diapositives, et les cartes répondent comme lui.
- **Une QRU d'exercice** (`rlg-qc-protecteur`) met des chiffres sur l'exemple du
  HDL-cholestérol (OR 0,6 [0,4 ; 0,8]) : la carte dit que le cours ne donne que
  le sens des deux OR.

## Les erreurs du ronéo 2025-26

Le Ronéosaure n'est pas le ronéo de l'année : chaque erreur est portée par un
**ATTENTION nu** dans la carte qui tient la notion, la sorte dite dans le texte,
et rien n'entre dans `contenu/ERRATA_RONEOS_2026-27.md`.

| Page | Le ronéo dit | Retenu | Sorte | Carte |
|---|---|---|---|---|
| 2 | « un coefficient de "rural" par rapport à "urbain" et un coefficient de "semi-rural" par rapport à "rural" » | « rural » est la référence (même page) : « urbain » contre « rural », « semi-rural » contre « rural » | prise de notes | `rlg-qc-qualitative` (explication) |
| 7 | « comme cet exemple concerne un nombre de patients raisonnable : OR est une bonne estimation de RR » | c'est la rareté de la maladie (< 10 %) qui compte, pas l'effectif (p. 6, en rouge ; p. 11) | prise de notes | `rlg-qc-tabac` (explication), `rlg-qc-rr-or` (B) |
| 8 | « OR = 2 et p-v > 0,05 → on ne peut rien conclure → il n'y a pas de différence » | on ne peut pas conclure ; ce n'est pas la preuve d'une absence de différence (même page) | prise de notes | `rlg-qc-significativite` (explication) |
| 8 | « si 1 dans l'IC de OR : non significatif → comme si p-valeur = 0,05 » | p ≥ 0,05 (p = 0,05 tout juste quand 1 est sur une borne) | prise de notes | `rlg-qc-significativite` (explication) |
| 8 | « les modèles multivariés permettent de cacher les facteurs cachés » | de les **contrôler** (la phrase suivante, et les annales) | prise de notes | `rlg-qc-randomisation` (explication) |
| 10 | les modalités « sans procédures additionnelles », « sans biopsie » et « avec polypectomie » | « With biopsy » dans le tableau de la même page : **avec** biopsie, OR 2,97 [1,91 ; 4,50] (relevé à la relecture, absent du plan C15) | prise de notes | `rlg-qc-article-coloscopie` (explication) |
| 10 | « le professeur a également parlé des SNIP, critères parfois utilisés en approche machine learning » | sans doute les SNP (prononcés « snips »), polymorphismes d'un nucléotide : le même professeur, la veille, donne en exemple 600 000 SNP pour 2 500 cas (FC n°8 d'informatique 2025-26, plan C16, qui relève aussi « SNIP ») | point douteux | aucune |

## Ce que les annales ont dicté

| Savoir | Questions | Clé |
|---|---|---|
| « La régression logistique permet de modéliser la relation entre… » | 2018/2019 S1 Q21, 2019/2020 S2 Q39, 2020/2021 S1 Q29 et S2 Q29, 2021/2022 S1 Q36, 2022/2023 S1 Q19, 2023/2024 S1 Q30 | BCE |
| Propriétés : coefficient ≠ OR, OR < 1 protecteur | 2021/2022 S2 Q24, 2022/2023 S2 Q20 | ABE |
| Propriétés : coefficient ≠ RR, OR > 1 facteur de risque | 2019/2020 S2 Q29, 2021/2022 S1 Q35 | ABDE |
| Propriétés : OR ajustés, aire sous la courbe ROC de 80 % | 2020/2021 S1 Q28 et S2 Q28 | ABDE |
| Propriétés : pas de RR, OR < 1 protecteur, « 0 » dans l'IC | 2023/2024 S1 Q25 et S2 Q25 | ACE |
| Propriétés : survie, Y quantitative, test global, e^β | 2017/2018 S1 Q38 et S2 Q27, 2018/2019 S1 Q18 | CDE |
| Propriétés : résidus normaux, coefficient = OR | 2018/2019 S1 Q19 ; S2 Q29 | AC ; ACE |
| Modèles de régression multivariée (ajustement, parcimonie) | 2020/2021 S1 Q31 et S2 Q31 | BD |
| Modèles multivariés, « on peut conclure que la variable est indépendante » | 2019/2020 S2 Q27, 2020/2021 S1 Q33 et S2 Q33, 2021/2022 S1 Q5 | ADE |
| Modèles multivariés, « on ne peut pas conclure » | 2021/2022 S2 Q21, 2022/2023 S2 Q17, 2023/2024 S2 Q27 | ABDE |
| Modèles multivariés, hypothèses à vérifier | 2023/2024 S1 Q23 | ACDE |
| Choix du modèle : reflux gastro-œsophagien du nouveau-né | 2021/2022 S2 Q33, 2022/2023 S2 Q26, 2023/2024 S1 Q27 ; 2021/2022 S1 Q33 | D ; **C déduite** |
| Pouvoir discriminant | 2021/2022 S1 Q34 et S2 Q34 | CD |

**Non cartées ici** (plan C15) : du polycopié n°13, la 2019/2020 S1 Q18 (pas
d'énoncé, la table donne « BCD »), la 2019/2020 S1 Q19 et Q21 (imputabilité,
règles de décision : chapitre de la FC n°10), la 2020/2021 S2 Q32 (méthodes
d'analyse multivariée : `biostat_scores`), la 2019/2020 S2 Q33 (régression
linéaire multiple : `biostat_regression_lineaire`). Les recopies ne sont pas
recartées : la 2021/2022 S2 Q33 du n°13 et du n°14 (cartée sous le n°2), les
2023/2024 S1 Q23, 2020/2021 S2 Q31 et Q33 du n°14 (cartées sous le n°2 et le
n°13) ; les colonnes « 2018/2019 » du n°14 recopient les clés de 2020/2021,
sans énoncé.

**Les notions hors fiche** (tag `hors-fiche`, 7 annales), justifiées sur des
sources citées dans chaque carte : le pouvoir discriminant — aire sous la
courbe ROC, pourcentage de bien classés — et le test de Hosmer-Lemeshow, qui
évalue la calibration (FC n°1 2025-26, p. 13 ; Steyerberg et al., Epidemiology
2010 ; Hosmer et Lemeshow, Applied Logistic Regression, pour « 0,8 à 0,9 :
excellente discrimination ») ; le test global du modèle (Penn State STAT 504,
leçon 6). Le test de Student cas particulier de la régression linéaire (FC n°8
2025-26, p. 4) et la parcimonie (FC n°1 2025-26, p. 12 ; FC n°11, p. 11) sont
dans des fiches 2025-26 de l'UE : ils ne font pas porter le tag.

## Les annales, une par une

Clé imprimée, clé retenue (en gras quand elle diffère), thème, identifiant.

| Polycopié | Session | N° | Imprimée | Retenue | Thème | Carte | Remarque |
|---|---|---|---|---|---|---|---|
| n°13 | 2017/2018 S1 | Q38 | CDE | CDE | `coefficients` | `rlg-an-1718s1-q38` | hors fiche (test global) |
| n°13 | 2017/2018 S2 | Q27 | CDE | CDE | `coefficients` | `rlg-an-1718s2-q27` | hors fiche (test global) |
| n°13 | 2018/2019 S1 | Q18 | CDE | CDE | `coefficients` | `rlg-an-1819s1-q18` | hors fiche (test global) |
| n°13 | 2018/2019 S1 | Q19 | AC | AC | `coefficients` | `rlg-an-1819s1-q19` |  |
| n°13 | 2018/2019 S1 | Q21 | BCE | BCE | `logit` | `rlg-an-1819s1-q21` |  |
| n°13 | 2018/2019 S2 | Q29 | ACE | ACE | `coefficients` | `rlg-an-1819s2-q29` |  |
| n°13 | 2019/2020 S2 | Q29 | ABDE | ABDE | `coefficients` | `rlg-an-1920s2-q29` |  |
| n°13 | 2019/2020 S2 | Q39 | BCE | BCE | `logit` | `rlg-an-1920s2-q39` |  |
| n°14 | 2019/2020 S2 | Q27 | ADE | ADE | `multivarie` | `rlg-an-1920s2-q27` | cite le n°13 |
| n°13 | 2020/2021 S1 | Q28 | ABDE | ABDE | `coefficients` | `rlg-an-2021s1-q28` | hors fiche (aire sous la courbe ROC) |
| n°13 | 2020/2021 S1 | Q29 | BCE | BCE | `logit` | `rlg-an-2021s1-q29` |  |
| n°13 | 2020/2021 S1 | Q31 | BD | BD | `multivarie` | `rlg-an-2021s1-q31` |  |
| n°14 | 2020/2021 S1 | Q33 | ADE | ADE | `multivarie` | `rlg-an-2021s1-q33` | cite le n°13 |
| n°13 | 2020/2021 S2 | Q28 | ABDE | ABDE | `coefficients` | `rlg-an-2021s2-q28` | hors fiche (aire sous la courbe ROC) |
| n°13 | 2020/2021 S2 | Q29 | BCE | BCE | `logit` | `rlg-an-2021s2-q29` |  |
| n°13 | 2020/2021 S2 | Q31 | BD | BD | `multivarie` | `rlg-an-2021s2-q31` | aussi au n°14 |
| n°13 | 2020/2021 S2 | Q33 | ADE | ADE | `multivarie` | `rlg-an-2021s2-q33` | aussi au n°14 |
| n°14 | 2021/2022 S1 | Q5 | ADE | ADE | `multivarie` | `rlg-an-2122s1-q5` | cite le n°13 |
| n°13 | 2021/2022 S1 | Q33 | — | **C** | `logit` | `rlg-an-2122s1-q33` | clé absente de la table, déduite ; `a-relire` |
| n°13 | 2021/2022 S1 | Q34 | CD | CD | `usages-modele` | `rlg-an-2122s1-q34` | hors fiche (discrimination) |
| n°13 | 2021/2022 S1 | Q35 | ABDE | ABDE | `coefficients` | `rlg-an-2122s1-q35` |  |
| n°13 | 2021/2022 S1 | Q36 | BCE | BCE | `logit` | `rlg-an-2122s1-q36` |  |
| n°14 | 2021/2022 S2 | Q21 | ABDE | ABDE | `multivarie` | `rlg-an-2122s2-q21` | cite le n°13 |
| n°13 | 2021/2022 S2 | Q24 | ABE | ABE | `coefficients` | `rlg-an-2122s2-q24` |  |
| n°2 | 2021/2022 S2 | Q33 | D | D | `logit` | `rlg-an-2122s2-q33` | aussi aux n°13 et 14 (même clé) |
| n°13 | 2021/2022 S2 | Q34 | CD | CD | `usages-modele` | `rlg-an-2122s2-q34` | hors fiche (discrimination) |
| n°13 | 2022/2023 S1 | Q19 | BCE | BCE | `logit` | `rlg-an-2223s1-q19` |  |
| n°14 | 2022/2023 S2 | Q17 | ABDE | ABDE | `multivarie` | `rlg-an-2223s2-q17` | cite le n°13 |
| n°13 | 2022/2023 S2 | Q20 | ABE | ABE | `coefficients` | `rlg-an-2223s2-q20` |  |
| n°2 | 2022/2023 S2 | Q26 | D | D | `logit` | `rlg-an-2223s2-q26` | cite le n°13 |
| n°2 | 2023/2024 S1 | Q23 | ACDE | ACDE | `multivarie` | `rlg-an-2324s1-q23` | aussi au n°14 |
| n°2 | 2023/2024 S1 | Q25 | ACE | ACE | `rr-or` | `rlg-an-2324s1-q25` | même énoncé que la 2023/2024 S2 Q25 |
| n°2 | 2023/2024 S1 | Q27 | D | D | `logit` | `rlg-an-2324s1-q27` |  |
| n°13 | 2023/2024 S1 | Q30 | BCE | BCE | `logit` | `rlg-an-2324s1-q30` | cite le n°2 |
| n°13 | 2023/2024 S2 | Q25 | ACE | ACE | `rr-or` | `rlg-an-2324s2-q25` | même énoncé que la 2023/2024 S1 Q25 |
| n°14 | 2023/2024 S2 | Q27 | ABDE | ABDE | `multivarie` | `rlg-an-2324s2-q27` | énoncé imprimé sous « 2022/2023 (Session 1) », table : 2023/2024 S2 ; cite le n°13 |

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2021/2022 S1 Q33 (choix du modèle, univarié ou multivarié) | — (la colonne de la table commence à la Q34) | **C**, `officielle=False`, `a-relire` | clé déduite du cours : Y binaire, quatre facteurs mesurés ensemble et liés entre eux (poids, prématurité) : une régression logistique multivariée, qui rend des OR ajustés (p. 2, 5-6). La même question à la session 2 (Q33, « Régression logistique ») est cotée D. La proposition D, « régression logistique univariée », est donnée fausse — un facteur à la fois, sans ajustement, c'est l'analyse bivariée qui précède le modèle (p. 3) — et la justification dit que ce point reste à relire |

Toutes les autres clés sont reprises telles quelles ; `CONFLITS` est vide.
Deux points sont discutés dans les cartes sans changer la clé : **« une aire
sous la courbe ROC égale à 80 % a un bon pouvoir discriminant »** (2020/2021
Q28 E, vraie) — la FC n°1 dit « performant si AUC > 0,8 », et Hosmer et
Lemeshow appellent « excellente » une aire de 0,8 à 0,9 ; **« les résidus (Y
prédit – Y observé) »** (2018/2019 Q19 B et Q29 B, fausse) — la justification
note aussi que le résidu s'écrit Y observé − Y prédit.

## Les schémas et les figures

**Douze figures de la FC 2025-26**, en PNG : l'équation manuscrite (p. 2), le
tableau de données (p. 4), la
droite qui dépasse 1, l'écriture du modèle logistique et la courbe logistique
estimée (p. 5), la démonstration de e^β = OR (p. 6), les tableaux du tabac et
de l'âge (p. 7), le tableau OR > 1 / OR < 1 (p. 8, rendu depuis le texte du
PDF), la « Table 3 » de l'article (p. 9), les antécédents de coloscopie et le
logit par décennie d'âge (p. 10). Captures de diapositives à leur taille
d'origine, les bandes noires des p. 6-7 retirées. Le logo de la page de garde et le
graphique brut de Y en fonction de l'âge (p. 4, que la droite de la p. 5 reprend)
ne sont pas repris. Aucune photographie de patient.

**Un schéma cliquable** (`schemas.py`), avec sa version légendée en correction :

| Fichier | Ce qu'on clique | Pourquoi ce dessin |
|---|---|---|
| `forest-plot.svg` | la ligne du facteur de risque, du facteur protecteur, de l'OR > 1 non significatif, de l'OR < 1 non significatif (4 zones) | douze annales demandent ce qu'on conclut d'un OR « strictement supérieur (inférieur) à 1 » avec p = 0,001, deux d'entre elles si « 0 » dans l'IC rend significatif ; le cours (p. 8-10) lit l'IC par rapport à 1. Échelle logarithmique de base 2, ligne OR = 1 en tirets, valeurs du cours (OR 7 [3 ; 10], p. 8 ; OR 1,20 [0,97 ; 1,49], p. 9) ; chaque ligne est une zone de la marge gauche à la marge droite, et les lignes sont mélangées pour que l'ordre ne donne pas la réponse |

**49 QCM sur 55 illustrés (89 %)**, 63 notes sur 81. Sans figure : deux QCM de
cours sur le choix des variables et l'ajustement, deux sur la randomisation et
les événements par variable, et les deux annales du pouvoir discriminant,
notion hors fiche qu'aucune figure de la FC n°11 ne montre.

## Le lexique

Huit termes, ceux du plan C15 ; aucun n'existait (vérifié contre les `lex-*` de
tous les paquets et contre les autres propositions d'étymologies). Pages
mesurées dans le texte de la FC 2025-26 (motif de `chercher_pages.py`), page de
garde exclue :

| Terme | Origine | Pages |
|---|---|---|
| Logit | grec logistikós ; le mot vient de Berkson (1944), « logistic unit » | 5, 6, 10 |
| Ajustement | latin ad + justus | 5, 6, 8, 9 |
| Confondant | latin confundere | 5 |
| Stratification | latin stratum + facere | 9 |
| Coloscopie | grec kólon + skopeîn | 9, 10 |
| Polypectomie | grec polúpous + ektomḗ | 10 |
| Adénome | grec adḗn + -ōma | 9 |
| Dysplasie | grec dus- + plásis | 9 |

Quatre racines sont enseignées par la FC de sémantique et la citent : `dys-`
(2/2, p. 6), `-ectomie` (2/2, p. 2), `-plasie` (1/2, p. 8), `ad- (latin)`
(2/2, p. 4, « ad- / af- : mouvement de rapprochement, vers » ; citation ajoutée
au regroupement du 03/10, comme dans `biostat_phase_4_eim`). Huit racines
reprennent les clés existantes de `etymologies.json` (`logizesthai (grec)`,
`ad- (latin)`, `cum (latin)`, `-fier, de facere (latin)`, `-scopie`,
`-ectomie`, `-ome`, `dys-`) ; sept sont nouvelles (`justus (latin)`,
`fundere (latin)`, `stratum (latin)`, `col(o)-`, `polyp(o)-`, `adén(o)-`,
`-plasie`), proposées avec les huit termes à la table commune, vérifiées sur le
Wiktionnaire, le Gaffiot et le Bailly (fichier de proposition dans le brouillon
de C15, `etym/biostat_regression_logistique.json`) ; les textes du lexique sont
déjà écrits dans la forme que `appliquer_etymologies.py` produirait. `col(o)-`
suit le grec κόλον, « gros intestin » (LSJ, Wiktionary), et non κῶλον,
« membre », auquel le Wiktionnaire français rattache côlon.

## Décisions prises en route

- **`EXAMENS` n'est pas déclaré** (décision de BMCT FC1) : le partiel du 16/12
  se règle dans l'application.
- **Une carte par session** : les questions répétées d'une session à l'autre ont
  chacune leur carte, et l'explication renvoie aux autres ; seules les recopies
  d'un polycopié à l'autre ne sont pas recartées.
- **Les énoncés imprimés** sont repris tels quels, ponctuation et casse
  comprises (« laquelle (lesquelles) est (sont) exacte(s)? », « au moyen: ») ;
  seuls les blancs perdus à l'extraction du texte sont rétablis (« Quel(s)
  modèle(s) »).
- **À la relecture** (vérification adversariale, 02/10) : le recto-verso
  « cohorte ou cas-témoins : où calcule-t-on un RR ? » est retiré, doublon de
  `pvg-rv-cohorte-cas-temoins` (la frontière du plan C15 donne la définition du
  RR et les types d'études à la FC n°9) ; `rlg-qc-rr-or` et `rlg-fa-rr-or` ne
  portent plus que l'OR du modèle et sa condition de rareté ; la 2023/2024 S2
  Q25 reprend le thème `rr-or` du plan, comme sa jumelle de session 1 ; l'erreur
  « sans biopsie » de la p. 10 est ajoutée au tableau.
- **La session « 2023-2024 » du polycopié n°2** est la session 1, comme l'a
  décidé `biostat_regression_lineaire` (le n°12 la range en session 1) ; le
  n°13 imprime le même énoncé de Q25 en session 2, d'où deux cartes.

## Questions pour Vincent

1. **2021/2022 S1 Q33** (reflux du nouveau-né, variante univariée/multivariée) :
   la table n'a pas de clé. La carte retient C, la régression logistique
   multivariée, et compte fausse D, « régression logistique univariée ». Faut-il
   cocher D aussi, chaque modèle univarié répondant en partie à la question ?
   (carte `a-relire`)
2. **La clé de thème `confidentialite-donnees`** remplace `confidentialite` du
   plan, pour laisser le mot seul à une autre UE : à confirmer avec le libellé
   « Confidentialité des données de recherche ».

## À relire

**Une carte `a-relire`** : `rlg-an-2122s1-q33`, dont la clé est déduite (voir
ci-dessus) ; le tag se retire quand Vincent aura tranché. Reste aussi :

- quand le ronéo 2026-27 paraîtra, relire chaque carte sur lui et retirer le
  badge « Cours 2025-26 » ;
- `copier_les_cours.py` avec le dossier `…/S1 25-26/examen décembre` du
  Ronéosaure 2025-26, hors du bac à sable, pour que la fiche s'ouvre dans
  l'application ;
- ajouter les sept libellés de thème à `THEME_LABELS` (le test
  `test_tout_theme_du_paquet_a_son_libelle` les attend) ;
- fusionner la proposition d'étymologies dans `etymologies.json`.

## L'échelle : Simple → Moyen → Annale (C20, 18/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 16 décembre. Sous les annales, 15 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 7 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `multivarie` | 6 | 2 | 10 |
| `usages-modele` | 2 | 1 | 2 |
| `logit` | 2 | 1 | 11 |
| `coefficients` | 3 | 2 | 11 |
| `rr-or` | 2 | 1 | 2 |

**Le schéma** `ech-regression-logistique`, « La régression logistique · choisir, lire, juger », donne 59 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_REGRESSION_LOGISTIQUE`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sources déclarées en plus** : `src-fc-biomed-rlm-2526` (pour `rlg-ech-s3`) et `src-fc-biomed-scr-2526` (pour `rlg-ech-s14`, `rlg-ech-s15`, `rlg-ech-m7`), à l'identique de leurs chapitres.

**Le seuil de l'aire sous la courbe ROC** (C29, 18/10) : la FC n°1 dit « AUC > 0,8 » (p. 13), la FC n°3 « à partir de 0,8 » (p. 6) ; la clé de 2020/2021 Q28 E (S1 et S2) compte vraie une aire égale à 80 %, comme la FC n°3. La justification `N_AUC_80` le dit désormais par un ATTENTION.

**Sans marche** :
- rlg-an-1718s1-q38 C, rlg-an-1718s2-q27 C, rlg-an-1819s1-q18 C : le test global du modèle (H0 : tous les coefficients nuls) n'est dans aucune fiche de l'UE ; sa justification cite Penn State STAT 504. La lettre est posée sur « Tester un coefficient », la case la plus proche.
- rlg-an-2324s1-q27 E, rlg-an-2223s2-q26 E, rlg-an-2122s2-q33 E : le test de nullité du coefficient de corrélation (deux variables quantitatives) relève de la FC n°1 2025-26 (p. 8) et n'entre pas dans le mécanisme du schéma ; il se révise avec biostat_scores. La lettre est posée sur la régression linéaire multiple.
- rlg-an-2122s1-q34 A et C, rlg-an-2122s2-q34 A et C : le nombre et le pourcentage d'observations bien classées ne sont dans aucune fiche de l'UE (justification fondée sur Steyerberg et al., Epidemiology 2010). Les lettres sont posées sur « Juger le modèle ».

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```
