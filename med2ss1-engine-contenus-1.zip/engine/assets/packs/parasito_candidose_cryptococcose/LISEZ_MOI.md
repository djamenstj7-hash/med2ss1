# Mycoses de l'immunodéprimé : candidose, cryptococcose — paquet Parasitologie et mycologie

92 notes, 158 cartes. Chapitre `chap-ue-parasito-fc9` (l'identifiant du
squelette, qui suit la numérotation 2024-25) de l'UE Parasitologie et
mycologie, ordre 8. Cours du **Pr Sendid, le 25/11/2025**, « Mycose de
l'immunodéprimé : candidose, cryptococcose » (FC n°8 du Ronéosaure 2025-26,
12 pages dont la dernière blanche) ; annales du polycopié « 9 & 10 » du
Ronéosaure 2024-25 (25 questions, 12 sessions) et du sujet 2024/2025 de l'UE
(2 questions, sans corrigé). Examen du 5 janvier 2027.

**Une fiche provisoire.** Aucun ronéo 2026-27 de parasitologie n'est paru : le
chapitre est carté sur le Ronéosaure 2025-26 (demande de Vincent du 02/10), et
le ronéo de l'année corrigera les cartes à sa parution. La fiche porte son
année dans son auteur (« Ronéosaure 2025-26 ») : chaque carte de cours prend le
tag `cours-2025-26` et montre « Cours 2025-26 ». Aucune carte ne dit « Absent du
cours 2026-27 », et les erreurs du Ronéosaure sont dites par un ATTENTION sans
genre ; `contenu/ERRATA_RONEOS_2026-27.md` ne concerne que les ronéos 2026-27.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 47 | 47 |
| Texte à trous | 15 | 75 |
| QROC | 8 | 8 |
| Recto-verso | 10 | 10 |
| Schéma cliquable | 1 | 7 |
| Planche à légender | 1 | 1 |
| Lexique | 10 | 10 |

Dont **27 annales** : 22 QCM (QRM) et 5 QROC (recto-verso, rédactionnels),
sur 13 sessions, de 2015/2016 S1 à 2024/2025 S1 (Q8 et Q9 du sujet 2024/2025,
clés déduites). Les 25 QCM du cours ont, comme les annales, une justification
par proposition. **40 QCM sur 47 sont illustrés (85 %)**, 60 notes sur 92 en
tout.

Sept thèmes :

| Clé | Libellé |
|---|---|
| `candida-portage` | Candida : espèces et portage |
| `candidoses-cutaneo-muqueuses` | Candidoses cutanéo-muqueuses |
| `candidoses-invasives` | Candidoses invasives |
| `cryptococcus` | Cryptococcus : agent, terrain, physiopathologie |
| `cryptococcose-clinique` | Cryptococcose : clinique, bilan et traitement |
| `diagnostic-biologique` | Diagnostic biologique (thème partagé de l'UE) |
| `immunodeprime` | Infections opportunistes de l'immunodéprimé (thème partagé de l'UE) |

Les sept libellés sont à ajouter à `THEME_LABELS` (`application/scopes.py`) ;
d'ici là, `test_tout_theme_du_paquet_a_son_libelle` échoue pour ce chapitre.

## Les sources et leurs années

| Source | Rôle | Cité |
|---|---|---|
| FC n°8 du **Ronéosaure 2025-26**, `PARASITO-MYCOLOGIE/FC n°8 Candidose, cryptococcose.pdf` | la fiche du chapitre (`chapitre=`), que le lecteur ouvre | à la page, sur chaque carte de cours |
| Polycopié « 9 & 10 - mycoses de l'immunodéprimé & mycoses superficielles » du **Ronéosaure 2024-25** | les annales ; déclaration commune avec `parasito_mycoses_superficielles`, identique au caractère près | provenance des annales |
| FC n°9 du **Ronéosaure 2024-25**, même cours, même professeur | appoint : neutropénie facteur de risque (p. 6), PCR « sans kit satisfaisant » (p. 9), cryptococcose « opportuniste la plus fréquente » (p. 9), LCS trouble réservé à la méningite bactérienne (p. 13), culture du cryptocoque (p. 14) | dans le texte des cartes |
| Cours **2023-24** (Charonéo), même professeur | seulement pour trancher une annale : histologie de certitude (p. 12), PCR à « intérêt limité » (p. 13), titre d'antigène > 1/512 (p. 17) | dans le texte des cartes |
| `src-sujets-parasito-2425` — sujets de parasitologie-mycologie 2024/2025, session 1 (examen du 10/01/2025, 14 p.), sans chemin | 2024/2025 S1 Q8 et Q9, par `SRC["sessions"]` ; **aucun corrigé**, clés déduites du cours ; déclaration commune aux dix chapitres de l'UE, champ pour champ | provenance des deux annales 2024/2025 |

Sources extérieures, citées là où elles tranchent : ANOFEL (campus de
parasitologie UNF3S 2014, « Cryptococcose » : LCS « généralement clair »,
anticorps non contributifs, titre d'antigène > 1/512 de mauvais pronostic,
signes focaux par atteinte des nerfs crâniens, 5-FC à 100-150 mg/kg/j) ; Lockhart et al., *Clin Infect Dis* 2017
(résistances de C. auris) ; Dromer et al., *PLoS Med* 2007, étude CryptoA/D
(sérotypes en France) ; Park et al., *AIDS* 2009, et Denning, *Lancet Infect
Dis* 2024 (fréquence de la cryptococcose).

## Ce que le cours a dicté

- **Le rouge** : une seule ligne, « 4 % des souches [de C. auris] sont
  résistantes à tous les antifongiques » (p. 6) — `cdc-fa-auris`, `cdc-qc-auris`.
- **Les consignes** : l'atteinte neuroméningée « à connaître +++ » (p. 9) et
  le bilan d'extension « important ++ » (p. 11) portent une proposition
  `indispensable` (`cdc-qc-neuromeningee` A, `cdc-qc-conclusion` E), et chacune
  son texte à trous.
- **Le gris** n'est que celui des titres de parties, la voix des rédacteurs :
  il se carte.
- **Les figures** : les dix-neuf images de la fiche (p. 2 à 11), extraites à la
  résolution de l'image du PDF, illustrent les corrections. Deux images de la
  p. 4 ne sont pas reprises : la candidose génito-fessière du nourrisson et la
  balanite, des photographies que le texte suffit à décrire.

## Les erreurs du Ronéosaure 2025-26

Chacune est dite dans la carte qui porte la notion, par un ATTENTION.

| Page | Le ronéo écrit | Ce qui est juste, et sa source | Carte |
|---|---|---|---|
| 10 | « Le LCS présente alors un aspect trouble » | **clair** dans la grande majorité des cas : errata 2025-26 de la promo (d'après le professeur), ANOFEL (« généralement clair »), clés de quatre annales ; le cours 2024-25 réservait le LCS trouble à la méningite bactérienne (p. 13) | `cdc-qc-lcs` A, `cdc-fa-lcs`, et les justifications des annales du LCS |
| 3 | « Xérotomie » | xérostomie (errata 2025-26 de la promo) | `cdc-fa-facteurs`, `lex-xerostomie` |
| 6 | « 54 % des souches sont résistantes au Bromuconazole » | le **voriconazole** : 54 % de CMI élevées (Lockhart 2017, d'où viennent les autres chiffres) ; le bromuconazole est un fongicide agricole | `cdc-fa-auris` |
| 11 | antigène cryptococcique « supérieur à 500/mm3 » | un titre, pas un compte par mm³ : « > 1/512 en agglutination latex » (ANOFEL ; cours 2023-24, p. 17) ; la carte retient « un titre très élevé est de mauvais pronostic », sans chiffre | `cdc-qc-diag-crypto` D |
| 11 | « 5-fluorocytosine à 100 mg » | 100 mg/kg/j (diapositive de la même page ; ANOFEL : 100 à 150 mg/kg/j) | `cdc-qc-traitement-crypto` A |
| 9 | « En Europe, on a essentiellement la variété Neoformans » | la diapositive situe la var. neoformans en Europe, la var. grubii partout ; le sérotype A (grubii) fait 72,5 % des cas français (CryptoA/D). Pas de proposition sur ce point | `cdc-qc-crypto-agent` C |

**La PCR** : « elle ne fonctionne pas pour les candidoses » (p. 8), alors que
trois corrigés d'annales la citent. Ce n'est pas une erreur de prise de notes —
les cours 2024-25 (« pas de kit satisfaisant ») et 2023-24 (« intérêt
diagnostique limité », kits en évaluation, utile sur les tissus) disent la même
réserve. Les corrigés sont repris, avec un ATTENTION qui nuance.

**Point douteux, non carté** : « au-delà de 12 h après une hémoculture
positive, la mortalité augmente de 80 % » (p. 7) ; les cours 2024-25 et
2023-24 donnent environ 10 % de mortalité pour un diagnostic dans les 12 h,
puis 35 à 40 % à 48 h (2024-25, p. 8) ou 30 à 35 % au-delà de 24 à 48 h
(2023-24, p. 12) (`cdc-qc-diag-invasive` B cite le cours 2024-25).

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| Le LCS de la cryptococcose : clair, protéines hautes, glucose bas, levure capsulée | 2024/2025 S1 8), 2023/2024 S1 Q5, 2022/2023 S2 Q4, 2021/2022 S2 Q1, 2020/2021 S1 Q15 |
| Le diagnostic de la cryptococcose : levure, antigène, pas d'anticorps | 2020/2021 S1 Q15, 2020/2021 S2 Q5, 2023/2024 S2 QROC 4 |
| La cryptococcose : agent, porte d'entrée, terrain, forme neuroméningée | 2023/2024 S2 Q9, 2022/2023 S1 Q8, 2021/2022 S1 Q4, 2019/2020 S2 Q2, 2015/2016 S1 Q12, 2019/2020 S1 QROC 5 |
| Facteurs de risque et épidémiologie des candidoses invasives | 2023/2024 S1 Q7, 2022/2023 S1 Q10, 2023/2024 S2 Q10, 2022/2023 S2 Q6, 2021/2022 S1 Q8, 2015/2016 S1 Q11 |
| Où détecter Candida : site stérile ou site colonisé | 2024/2025 S1 9), 2022/2023 S2 Q5, 2021/2022 S2 Q2 |
| Les moyens du diagnostic d'une candidose invasive | 2018/2019 S1 Q13, 2023/2024 S1 QROC 2, 2020/2021 S2 QROC 5, 2019/2020 S1 QROC 3 |
| Les infections opportunistes | 2021/2022 S1 Q2 |

| Session | Q | Sujet | Clé imprimée | Clé retenue |
|---|---|---|---|---|
| 2024/2025 S1 | 8) | cryptococcose (reprise de 2021/2022 S2 Q.1, A et D récrites) | aucune (sujet sans corrigé) | ACE (clé déduite) |
| 2024/2025 S1 | 9) | prélèvements d'une candidose invasive | aucune (sujet sans corrigé) | AE (clé déduite) |
| 2023/2024 S1 | Q.5 | cryptococcose méningée | ACE | ACE |
| 2023/2024 S1 | Q.7 | facteurs de risque, candidose invasive | ABCE | ABCE |
| 2023/2024 S1 | QROC.2 | diagnostic d'une candidose invasive | corrigé | corrigé + ATTENTION (PCR) |
| 2023/2024 S2 | Q.9 | épidémiologie de la cryptococcose | ADE | ADE |
| 2023/2024 S2 | Q.10 | candidoses invasives | ABDE | ABDE |
| 2023/2024 S2 | QROC.4 | diagnostic de la cryptococcose neuroméningée | corrigé | corrigé |
| 2022/2023 S1 | Q.8 | cryptococcose | BC, non officielle | BC (clé déduite) |
| 2022/2023 S1 | Q.10 | facteurs de risque, candidose invasive | ABCDE, non officielle | ABCDE (clé déduite) |
| 2022/2023 S2 | Q.4 | cryptococcose méningée | AC | AC |
| 2022/2023 S2 | Q.5 | détection de Candida | AD | AD |
| 2022/2023 S2 | Q.6 | épidémiologie des candidoses invasives | ABCE | ABCE |
| 2021/2022 S1 | Q.2 | infections opportunistes | CD | CD |
| 2021/2022 S1 | Q.4 | cryptococcose | BCE | BCE |
| 2021/2022 S1 | Q.8 | candidémie | ABCD | ABCD |
| 2021/2022 S2 | Q.1 | cryptococcose méningée | ACE | ACE |
| 2021/2022 S2 | Q.2 | détection de Candida | AB | **ABD** |
| 2020/2021 S1 | Q.15 | cryptococcose neuroméningée | AB | **ABE** |
| 2020/2021 S2 | Q.5 | cryptococcose neuroméningée | ABCD | ABCD |
| 2020/2021 S2 | QROC.5 | diagnostic d'une candidose invasive | corrigé | corrigé + ATTENTION (PCR) |
| 2019/2020 S1 | QROC.3 | diagnostic d'une candidose invasive | non officiel | repris + ATTENTION (PCR) |
| 2019/2020 S1 | QROC.5 | cryptococcose neuroméningée | non officiel | repris |
| 2019/2020 S2 | Q.2 | cryptococcose | ACD, gris foncé | ACD (non marquée officielle) |
| 2018/2019 S1 | Q.13 | candidose invasive | ABC (sous « Q.11 ») | ABC |
| 2015/2016 S1 | Q.11 | candidoses | BCDE | BCDE |
| 2015/2016 S1 | Q.12 | Cryptococcus neoformans | DE | DE |

Une même question posée à plusieurs sessions donne une carte par session, et
l'explication renvoie aux autres. Les questions de mycoses superficielles du
même polycopié sont dans `parasito_mycoses_superficielles`. La question
2019/2020 S1 Q3 du polycopié n°7, qui mêle le mannane de Candida et le
galactomannane d'Aspergillus, est dans `parasito_aspergillose_pneumocystose`
(plan C16 : une source par session et par chapitre).

## Le schéma cliquable et la planche

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `portes-entree-nu.svg` | sur un corps vu de face (le contour d'`immuno_organes`) : le poumon, porte d'entrée de Cryptococcus ; le cerveau, son tropisme ; l'intestin, principale porte d'entrée des candidoses invasives ; le cathéter central, porte cutanée ; le foie, l'œil, le rein, localisations de la candidose invasive | 7 |

Les organes pairs (poumon, œil, rein) ne sont pleins que du côté qui porte la
zone. Le cerveau et le rein, deux ellipses, sont tracés par le polygone même de
leur zone : un clic sur leur bord tombe dans la zone. Les libellés demandés ne
nomment pas l'organe : « l'organe où les levures disséminées forment des
nodules ou des abcès » (le foie), « la localisation dite « anciennement :
preuve de l'infection » » (l'œil, diapositive p. 7), « l'organe atteint quand
une candidurie est de « contamination haute » » (le rein). La version
légendée, `portes-entree.svg`, tirée des mêmes constantes, illustre sa
correction, un texte à trous et trois QCM.

**La planche** `cdc-pl-capsule` : la diapositive « La capsule : principal
facteur de virulence » (p. 9), une image (`planche_depuis_image.py`), six
numéros — membrane, paroi (mélanine, chitine), capsule, anti-phagocytose,
résistance au complément et aux anticorps, effet immunomodulateur. Le titre de
la diapositive, qui nommait la capsule, est effacé avec la légende n°3. Intrus,
tous du même champ : pseudofilament, adhésines, transition levure-hyphe,
sécrétion de protéinases (les armes de Candida), polarisation Th1 (l'inverse de
l'effet de la capsule).

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2021/2022 S2 Q.2, D « dans le liquide cérébrospinal » | AB | **ABD**, `officielle=False`, conflit déclaré | le LCS est un site normalement stérile, cité par le cours parmi les prélèvements (FC 2025-26 p. 7, cours 2024-25 p. 8) ; le corrigé de 2023/2024 S1 QROC 2 y dose le mannane |
| 2020/2021 S1 Q.15, E « la recherche d'anticorps spécifiques n'est pas contributive » | AB | **ABE**, `officielle=False`, conflit déclaré | ANOFEL : « La recherche des anticorps n'est pas contributive pour le diagnostic » ; 2020/2021 S2 Q5 E, cotée fausse, dit l'inverse ; oubli probable de E |
| 2019/2020 S2 Q.2 | ACD, imprimée en gris foncé | ACD, `officielle=False` | statut incertain (gris sans la mention « pas de correction officielle ») ; A, formule des cours 2023-24 et 2024-25, porte un ATTENTION : chiffres de 2009, démentis par Denning 2024 — à l'examen, on répond comme le professeur |
| 2022/2023 S1 Q.8 et Q.10 ; 2019/2020 S1 QROC 3 et QROC 5 | « pas de correction officielle » | corrigés repris, `officielle=False` | clés déduites du cours, qui confirment le polycopié |
| 2018/2019 S1 Q.13 | ABC, imprimée sous « Q.11 » | ABC, officielle | seule question de la session dans le polycopié ; ATTENTION dans l'explication |
| 2024/2025 S1 8) (diagnostic de cryptococcose) | aucune (sujet sans corrigé) | **ACE**, `officielle=False` | clé déduite du cours (FC 2025-26 p. 9-11 ; LCS clair d'après l'errata de la promo et ANOFEL), celle de 2021/2022 S2 Q.1, dont la question est la **reprise** : énoncé sans « méningée », A (« la forme neuro-méningée est grave ») et D (« une hyperglycorachie est souvent retrouvée ») récrites, B, C, E mot pour mot |
| 2024/2025 S1 9) (prélèvements d'une candidose invasive) | aucune (sujet sans corrigé) | **AE**, `officielle=False` | clé déduite : hémoculture et histologie d'une biopsie (FC 2025-26 p. 7 ; cours 2023-24 p. 12) ; écouvillon rectal et aspiration bronchique ne montrent que la colonisation (portage digestif et oropharyngé, p. 2), le cuir chevelu est le prélèvement d'une teigne |

## Questions pour Vincent

1. **Deux clés retenues contre la table** (question 2 du plan C16) :
   Candida dans le LCS (2021/2022 S2 Q2, AB → ABD) et anticorps non
   contributifs dans la cryptococcose (2020/2021 S1 Q15, AB → ABE). La
   proposition du plan est appliquée et signalée sur chaque carte ; préfères-tu
   que la carte réponde comme la table imprimée ?
2. **« L'infection fongique invasive la plus fréquente dans le monde »**
   (2019/2020 S2 Q2 A) : la carte la donne vraie, comme le professeur l'a
   enseigné en 2023-24 et 2024-25, avec un ATTENTION sur les chiffres actuels
   (194 000 méningites cryptococciques par an contre plus de 2 millions
   d'aspergilloses invasives, Denning 2024). D'accord ?
3. **L'examen du 5 janvier 2027** (question 5 du plan) : `EXAMENS` n'est pas
   déclaré, comme dans les autres chapitres ; le déclarer dans les chapitres
   des quatre UE de janvier ?

## Le lexique

Dix termes, tous de la FC n°8, pages mesurées dans son texte
(`chercher_pages.py` sur le texte de pymupdf) : Candidémie (p. 2, 6, 7),
Fongémie (2, 9), Muguet (4), Perlèche (4), Balanite (4), Xérostomie (3, imprimée
« Xérotomie »), Périonyxis (3), Protéinorachie (10, via « hyperprotéinorachie »),
Glycorachie (10, via « hypoglycorachie »), Cryptococcome (10). Aucun n'est
accueilli ailleurs.

Chaque terme dit son origine. Dix racines et dix termes nouveaux sont proposés
pour `etymologies.json` dans le brouillon
`scratchpad/etym/parasito_candidose_cryptococcose.json` (vérifiés sur le TLFi
par l'API cnrtl.fr, le Wiktionnaire, le Bailly et le Gaffiot) ; la racine
`onych(o)-` reprend au caractère près la proposition de
`parasito_mycoses_superficielles`. Le texte de `LEXIQUE` est déjà celui
qu'écrirait `appliquer_etymologies.py` avec ces entrées (vérifié : aucun écart,
aucune réécriture).

## À relire

Aucune carte ne porte le tag `a-relire` : chaque carte de cours cite sa page de
la FC n°8, relue contre le PDF ; chaque annale est recopiée mot pour mot et
contrôlée sur l'image du polycopié, tables de corrections comprises — ou, pour
les deux de 2024/2025, sur le PDF du sujet, clé déduite à la page.

**Relecture critique du 05/10.** Toutes les cartes ont été relues contre leur
page, les clés contre la table imprimée, les citations des cours 2024-25 et
2023-24 et d'ANOFEL contre leur texte. Corrigé à cette occasion :
- l'énoncé de 2015/2016 S1 Q.12, qui portait « est (sont) » au lieu de
  l'imprimé « est (ou sont) » ;
- le schéma : le cerveau et le rein étaient dessinés en ellipse mais corrigés
  en cercle (un clic sur leur bord comptait faux) ; trois libellés de zone qui
  nommaient l'organe (« fond d'œil », « hépatosplénique », « pyélonéphrite ») ;
- le cours 2024-25 n'écrit pas « LCS clair » pour la cryptococcose, il réserve
  le LCS trouble à la méningite bactérienne : les cartes le citent ainsi, et
  ANOFEL (« généralement clair ») porte la correction avec l'errata ;
- la mortalité selon le délai du diagnostic (« à 48 h », non « au-delà »), la
  dose de 5-FC d'ANOFEL (100 à 150 mg/kg/j), le seuil d'antigène d'ANOFEL
  (> 1/512), sa formule exacte sur les nerfs crâniens ;
- l'encre de Chine et l'examen direct comparé sont illustrés par la
  photographie de la p. 8, qui montre le halo de la capsule, et non par
  l'anatomopathologie de la p. 11, qui ne le montre pas.


## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier. Sous les annales, 43 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 8 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `candida-portage` | 1 | 1 | 1 |
| `candidoses-invasives` | 10 | 1 | 6 |
| `cryptococcus` | 7 | 1 | 3 |
| `cryptococcose-clinique` | 8 | 1 | 3 |
| `diagnostic-biologique` | 16 | 3 | 13 |
| `immunodeprime` | 1 | 1 | 1 |

**Le schéma** `ech-candida-cryptococcus`, « Candida, Cryptococcus · de l'entrée au diagnostic », donne 74 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_CANDIDA_CRYPTOCOCCUS`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- cdc-an-2425s1-q9 D (prélèvement du cuir chevelu) : c'est le prélèvement d'une teigne, du cours des mycoses superficielles ; la FC n°8 n'en dit rien, aucune case ne la porte.
- cdc-an-2122s1-q2 A, B, C, E (amœbose, giardiose, pneumocystose, taeniasis) : d'autres cours de l'UE (FC n°3, n°5, n°9) ; la FC n°8 n'en dit rien. Seule D, la candidose invasive opportuniste, a ses marches (cdc-ech-s8, cdc-ech-m8).
- cdc-an-1920s2-q2 A (« l'infection fongique invasive la plus fréquente dans le monde ») : formule des cours 2023-24 et 2024-25, absente de la FC 2025-26 qui fait foi, et démentie par les estimations récentes (ATTENTION de l'annale) ; une marche l'enseignerait comme vraie ou la contredirait, elle n'en a pas.
- cdc-an-2324s2-q9 C (C. gattii « exclusivement présent en Europe ») : la répartition de C. gattii diverge entre la diapositive 2025-26 (régions tropicales et subtropicales, p. 8) et le cours 2024-25 (« cosmopolite », p. 10) ; le schéma la tient hors de ses cases, sa lettre reste posée sur la case du champignon, et cdc-ech-m6 ne parle que du réservoir et du terrain.

## Régénérer

```powershell
cd contenu\chapitres\parasito_candidose_cryptococcose
..\..\..\app\.venv\Scripts\python.exe generer.py
```

La planche numérotée se refait depuis ses rectangles (`PLANCHES`, `efface`) :

```powershell
python ..\..\..\.claude\skills\nouveau-chapitre\scripts\planche_depuis_image.py . cdc-pl-capsule --taille 24
```
