# Globules rouges — paquet Tissu sanguin

59 notes, 97 cartes. Quatrième chapitre de l'UE **Tissu sanguin**
(`chap-ue-tissu-sanguin-fc4`). **Cours du 07/10/2026, 8 h-9 h, Pr B. Podvin, en
une ronéo Ronéo & Juliette 2026-27** : « Aspects structuraux et fonctionnels,
métabolisme de l'hème » (12 p., dépôt du 19/10/2026). Réaligné sur elle le
19/10/2026 ; il était carté sur le cours du Pr Maboudou de 2024-25 (Ronéosaure
2024-25, FC n°4 « Globules rouges »), un autre professeur, qui n'est plus qu'un
appoint. **Pas de polycopié d'annales** pour ce cours : une annale, le QCM 5 du
sujet 2024/2025. Examen : partiel de novembre (mercredi 4/11/2026).

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 23 | 23 |
| QRU (marches Simple de l'échelle) | 9 | 9 |
| Texte à trous | 8 | 39 |
| QROC | 5 | 5 |
| Recto-verso | 9 | 9 |
| Lexique | 4 | 4 |
| Schéma cliquable | 1 | 8 |

Dont **1 annale** (sujet 2024/2025, QCM 5, clé déduite du cours), 11 marches
d'échelle (9 Simple, 2 Moyen) et 20 QCM de cours. **31 QCM sur 32 illustrés
(97 %)**, 47 notes sur 59 ; le seul QCM sans figure est `gr-qc-membrane`, absent
du cours 2026-27. **6 cartes absentes du cours 2026-27** (tag `absent-2026`),
**18 cartes portent un piège de la ronéo** (thème « Pièges des ronéos »).

Six thèmes, déjà dans `THEME_LABELS` (`app/src/med_engine/application/scopes.py`) ;
le réalignement n'en ajoute aucun :

| Clé | Libellé |
|---|---|
| `structure` | Structure du globule rouge |
| `metabolisme` | Les deux voies métaboliques |
| `anomalies` | Anomalies constitutionnelles |
| `heme` | L'hème et ses rôles |
| `biosynthese` | Biosynthèse et porphyries |
| `catabolisme` | Catabolisme et bilirubine |

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-sang-gr` — « Aspects structuraux et fonctionnels, métabolisme de l'hème » (12 p.), `Tissu sanguin/MÉTABOLISME DE L’HEME.pdf` | **2026-27** | la ronéo du 07/10/2026, Pr B. Podvin ; `SRC["fiche"]`, ce que le lecteur ouvre, et `SRC["medias"]` ; 52 notes la citent à leur page (48 de cours, 4 termes de lexique), et l'annale en source secondaire |
| `src-cours-sang-gr` — « Globules rouges » (11 p.), Pr Maboudou | 2024-25 | **appoint** (`SRC["cours"]`, sans `chapitre=`) : ce que la ronéo 2026-27 ne reprend pas, une figure (`gr-glycolyse.png`), et la source des **6 cartes absentes** |
| `src-fc-sang-gr-2526` — FC n°4 2025-26 (11 p.), Pr B. Podvin | 2025-26 | **contre-épreuve** : le même cours l'an dernier ; aucune carte ne le cite comme source, les textes le citent « FC 2025-26, p. 6 » |
| `src-sujets-sang-2425` — Sujets de tissu sanguin 2024/2025, session 1 | 2024-25 | le QCM 5 ; `SRC["sessions"]["2024/2025 S1"]` |
| tableau d'erreurs Tissu sanguin de la promo (19/10/2026) | 2026-27 | deux entrées pour ce cours, p. 6 et p. 8 |

Les textes citent « p. 5 » (ronéo 2026-27), « cours 2024-25, p. 4 » ou « FC
2025-26, p. 6 ». La fiche de l'année se copie dans le dossier des PDF de
l'application par `outils/copier_les_cours.py`, lancé avec le dossier des ronéos
du 19/10/2026 (`Ajouts/[NUMERIQUE] Ronéo & Juliette 26-27 19 10 2026/S1/CM`), hors
du bac à sable. Les en-têtes des ronéos et les erratas du Ronéosaure nomment des
étudiants : aucun nom n'est repris.

## Ce qui correspond à quoi

| Cours 2024-25 (Pr Maboudou) | Ronéo 2026-27 (Pr Podvin) |
|---|---|
| I-a, b Généralités, rôle (p. 2-3) | I.A Généralités, tableau des valeurs (p. 2) |
| I-c Membrane et cytosquelette (p. 3) | I.B Composition, I.C.1 Cytosquelette (p. 2-3) — bande 3, spectrine, ankyrine |
| — | I.C.2 Hémoglobine, globines α, β, γ, δ (p. 3-4) — **nouveau** |
| I-d Métabolisme : glycolyse, pentoses, méthémoglobine, glutathion (p. 3-6) | II.A Métabolisme énergétique (p. 4-6), II.B oxydo-réducteur : glutathion, cytochrome b5 (p. 6-7) |
| I-e Anomalies constitutionnelles (p. 6) | IV Hémolyse (p. 10-11) |
| II-a Généralités sur l'hème (p. 6-8) | III.A (p. 7) — affinité, effet Bohr, 270 millions d'hémoglobines |
| II-b Biosynthèse, régulation, porphyries (p. 8-10) | III.B (p. 8) — régulation par ALAS-2 et le fer, saturnisme |
| II-c Catabolisme (p. 10-11) | III.C (p. 9-10) |
| II-d Pathologies du catabolisme (p. 11) | p. 10 (ictère, en gris) et IV |
| — | V Conclusion, schéma bilan au tableau, chlorophylle (p. 11-12) — **nouveau** |

## Le réalignement du 19/10/2026

Les 43 notes de la version 2024-25 ont été relues une à une contre la ronéo
2026-27. Chaque proposition ou trou que seul le cours 2024-25 porte le dit dans sa
justification (« cours 2024-25, p. 5 ; la ronéo 2026-27 ne donne pas de
chiffre ») : une carte n'est confirmée que si sa notion centrale est dans le
cours de l'année.

**Relues et confirmées (21), qui citent leur page de l'année** : `gr-qc-structure`
(p. 2), `gr-qc-pentoses`, `gr-qc-methemoglobine`, `gr-qr-enzymes` (p. 6),
`gr-qc-heme-role`, `gr-qc-hemoglobine` (p. 7), `gr-qc-biosynthese` (p. 8),
`gr-qc-catabolisme`, `gr-fa-catabolisme` (p. 9), `gr-qc-anomalies`,
`gr-qc-ictere` (p. 10), les marches `gr-ech-s1` (p. 2), `-s4`, `-s5` (p. 5),
`-s3`, `-s6`, `-m1` (p. 6), `-s7` (p. 7), `-s8`, `-s9` (p. 4), et l'annale
`gr-an-2425-q5`, qui cite la ronéo p. 5 en source secondaire.

**Réécrites (16), parce que le cours 2026-27 dit autrement** :

- **Le partage 90 % / 10 % porte sur le glucose entrant** (p. 5-6), non plus sur
  l'énergie (cours 2024-25, p. 4) : `gr-fa-voies`, `gr-qc-metabolisme` B,
  `gr-ech-s2` (son énoncé), `gr-ech-m2` B, les zones de `gr-zo-voies` (p. 5) et
  le schéma de l'échelle.
- **2 ATP et 2 lactates par glucose** (p. 5), non plus 1 ATP : `gr-qc-metabolisme`
  E le dit par un ATTENTION nu.
- **Le 2,3-BPG vient du shunt de Rapoport-Luebering** (p. 6) : `gr-qc-anaerobie`
  B, `gr-qr-2-3-bpg`.
- **La méthémoglobine se répare par la voie du cytochrome b5** (p. 6) :
  `gr-qc-anaerobie` D ; `gr-rv-bebes-bleus` devient les méthémoglobinémies
  héréditaires du cours (Blue Fugates, hémoglobine M).
- **Porphyries héréditaires, saturnisme acquis** (p. 8) : `gr-qc-porphyries`
  (énoncé et propositions A, B, E) ; l'« ALA déshydrogénase » du cours 2024-25
  devient l'ALA déshydratase (ATTENTION nu, D).
- **ALAS-1 ubiquitaire, ALAS-2 érythropoïétique activée par le fer** (p. 8) :
  `gr-fa-ala` (trous 3 et 4 ; le « transcriptionnel / traductionnel » du cours
  2024-25 passe dans l'explication) ; `gr-fa-biosynthese` (« de manière
  ubiquitaire »).
- **La pompe garde l'équilibre hydrique et osmotique** (3 Na+ / 2 K+, p. 4-5) :
  `gr-rv-pompe`.
- `gr-rv-glutathion`, `gr-rv-bilirubine`, `gr-rv-selles`, `gr-qr-ligands` : verso
  ou réponse dit sur les mots de l'année (thiols, deux glucuronates, urobiline
  des urines, imidazole de l'histidine F8).

**Notes nouvelles (16)** — 14 au réalignement, 2 à la relecture :

| Note | Ce qu'elle carte |
|---|---|
| `gr-fa-valeurs` | le tableau des valeurs « à connaître » : GR, Hb, VGM, TCMH, CCMH (p. 2) |
| `gr-qc-cytosquelette` | bande 3, ankyrine, spectrine, protéines accessoires, Minkowski-Chauffard (p. 3, 10) |
| `gr-qc-globines` | α2β2 de l'adulte, α2γ2 du nouveau-né, résidu δ (p. 4) |
| `gr-qc-voies-glucose` | Embden-Meyerhof, shunt des hexoses monophosphates, Rapoport-Luebering (p. 5-6) |
| `gr-qc-cytb5` | la voie du cytochrome b5, la méthémoglobine réductase (p. 6-7) |
| `gr-qc-affinite` | 2,3-BPG, hyperthermie, acidose ; 270 millions d'hémoglobines (p. 7) |
| `gr-qc-regulation-fer` | ALAS-1 et ALAS-2, le fer et le récepteur de la transferrine (p. 8) |
| `gr-qc-hemolyse` | causes génétiques et acquises d'hémolyse (p. 10-11) |
| `gr-rv-ecchymose` | la coloration des ecchymoses, l'ictère (p. 9-10) |
| `gr-rv-chlorophylle` | hème et chlorophylle, Fe2+ et Mg2+ (p. 12) |
| `gr-fa-sre` | le SRE : noyau porphyrique ouvert, biliverdine, bilirubine libre, 85 % de l'hémoglobine, globine recyclée en acides aminés (p. 9) — relecture |
| `gr-qr-nac` | la N-acétylcystéine, l'autre moyen de reconstituer le glutathion (p. 6) — relecture |
| `lex-methemoglobine`, `lex-porphyrie`, `lex-saturnisme`, `lex-bilirubine` | les premiers termes du lexique de l'UE |

**Les figures de l'année** (16, `gr-2627-*.png`, extraites des images de la
ronéo, quantifiées à 256 ou 64 couleurs) vont toutes du côté de la correction :
tableau des valeurs (p. 2), cytosquelette et hème (p. 3), hémoglobine et
globines (p. 4), schéma du métabolisme énergétique (p. 5), glutathion et
cytochrome b5 (p. 6), voie et régulation de la biosynthèse (p. 8), catabolisme,
SRE et conjugaison (p. 9), intestin (p. 10), **le schéma bilan du professeur au
tableau** (p. 11), chlorophylle (p. 12). La figure du cours 2024-25
(`gr-glycolyse.png`) reste sur `gr-qr-enzymes`.

## La relecture du 19/10/2026 (second lecteur, sceptique)

Chaque carte nouvelle ou changée relue contre sa page et son image, les
références vérifiées (PubMed, CNRTL, PMC). Ce qui a changé :

- **ALAS « avec 2 sous-unités »** (p. 11) passe de « prise de notes » à
  **douteux** : la p. 8 dit deux formes, mais chaque ALAS est réellement un
  homodimère (Bailey et al., Nat Commun 2020) ; la phrase n'est pas fausse à la
  lettre (`gr-qc-regulation-fer` B). Sa proposition D dit aussi la régulation
  traductionnelle d'ALAS-2 par les IRP.
- **Erreur nouvelle, le cours lui-même** : le schéma de la glycolyse (p. 5),
  recopié de la diapositive du professeur (FC 2025-26, p. 4), fait produire du
  NADH à la lactate déshydrogénase (`gr-qc-anaerobie` D).
- **Deux points douteux nouveaux** : l'hème « autant le recycler » (p. 9,
  `gr-qc-heme-role` D, dont la justification relayait la formule) ; la
  sphérocytose qui toucherait les trois protéines « à la fois » (p. 10) — la
  proposition D de `gr-qc-cytosquelette`, note nouvelle, dit désormais
  « l'ankyrine, la spectrine ou la protéine de bande 3 ».
- **Sources corrigées** : la gammaglobuline n'a pas d'article TLFi (Académie
  française, 9e éd.) ; la FC 2025-26 ne partage avec la ronéo que le « gamma »,
  pas les « 2 ALA » de l'ALA synthase (`gr-qc-biosynthese` B) ; la diapositive de
  la chlorophylle légende « Human Blood Hemoglobin » le dessin d'un hème
  (`gr-rv-chlorophylle`).
- **Deux notes ajoutées** pour des pages sans carte : `gr-fa-sre` (p. 9) et
  `gr-qr-nac` (p. 6).

## Absent du cours 2026-27

Six cartes (`ABSENTS_2026`), qui citent le cours 2024-25 (`SRC["cours"]`) et
portent « Absent du cours 2026-27 » en tête de leur explication :

| Carte | Ce que seul le cours 2024-25 porte |
|---|---|
| `gr-qc-membrane` | la membrane à 50 % de protéines et 40 % de lipides, des protéines « musculaires » (actine, myosine, tropomyosine, tropomoduline) |
| `gr-fa-membrane` | la même composition, en trous |
| `gr-fa-chiffres` | 130 µm² par hématie, 3 800 m² en tout, la demi-vie de 28 jours |
| `gr-qr-methylene` | le traitement par le bleu de méthylène |
| `gr-rv-qualitatif` | drépanocytose qualitative, thalassémies quantitatives |
| `gr-rv-dracula` | les signes cutanés et neurologiques des porphyries, le mythe de Dracula |

## Les erreurs de la ronéo 2026-27

Portées là où la notion se joue, avec leur genre ; la liste de la promo
(`contenu/ERRATA_RONEOS_2026-27.md`) les reprendra. Les deux entrées du tableau
d'erreurs de la promo sont marquées ★.

**Prise de notes** (le professeur dit juste ailleurs : diapositive, même ronéo,
FC 2025-26) :

| Page | La ronéo dit | Juste | Carte |
|---|---|---|---|
| ★ 6 | la forme oxydée « GSHG » | GSSG (diapositive p. 6) | `gr-qc-pentoses` B, `gr-rv-glutathion` |
| ★ 8 | « un capteur IC » du fer circulant | un capteur extracellulaire : le fer de la transferrine se fixe au récepteur de la transferrine, à la surface de l'érythroblaste (diapositive p. 8) | `gr-qc-regulation-fer` D |
| 2 | protéines de membrane : « sphérocytose ; erythrocytose » | elliptocytose (p. 10 ; FC 2025-26, p. 10) | `gr-qc-cytosquelette` E |
| 3 | protoporphyrine « dû au 4 noyaux tétracyclique » | quatre noyaux pyrrole, un cycle tétrapyrrolique (figure p. 3) | `gr-qc-heme-role` A |
| 4 | « gamma-globuline » | chaîne de globine γ ; une gammaglobuline est une protéine du plasma à fonction d'anticorps (Académie française, 9e éd.) | `gr-qc-globines` E |
| 6 | « le NADH est notamment régénéré par le cyt B5 » | le NADH réduit le cytochrome b5 (diapositive p. 6 ; FC 2025-26, p. 5) | `gr-qc-cytb5` B |
| 7 | le GR « doit impérativement revenir à l'état ferrique » | à l'état ferreux, Fe2+ (p. 6, diapositive) | `gr-qc-cytb5` E |
| 7 | le fer fait « 2 [liaisons] avec l'hémoglobine », le reste avec l'O2 | 4 à l'hème, 1 à l'histidine F8, 1 à l'O2 (même page) | `gr-qc-hemoglobine` D, `gr-qr-ligands` |
| 7 | « 270 millions d'hémoglobines soit 270 millions d'hème » | ≈ 1,1 milliard d'hèmes (4 par hémoglobine) | `gr-qc-affinite` D |
| 7 | « un GB c'est 1,1 milliards d'O2 » (et GB pour GR p. 11, 12) | un globule rouge (FC 2025-26, p. 6) | `gr-qc-affinite` E |
| 7 | le P450 transfère des électrons « au sein de la chaîne respiratoire mitochondriale » | deux exemples distincts (FC 2025-26, p. 7 ; diapositive p. 8) | `gr-qc-heme-role` C |
| 8 | « 2 acides gamma-aminolévuliniques à partir d'une glycine et d'un succinyl-CoA » | un acide δ-aminolévulinique par glycine et succinyl-CoA (diapositive p. 8) | `gr-qc-biosynthese` B |

**Le cours lui-même** (la diapositive ou la FC 2025-26 du même professeur disent
pareil ; la carte répond comme le professeur, puis donne la référence) :

| Page | Le cours dit | La référence | Carte |
|---|---|---|---|
| 2 | le GR mesure « entre 8 et 12 µm » | 7,5 à 8,7 µm (Diez-Silva, MRS Bull 2010) | `gr-qc-structure` A |
| 5 | le schéma de la glycolyse, recopié de la diapositive (FC 2025-26, p. 4), écrit à la lactate déshydrogénase « 2 NAD → 2 NADH » | pyruvate → lactate OXYDE le NADH en NAD+ ; le NADH vient de la glycéraldéhyde-3-phosphate déshydrogénase | `gr-qc-anaerobie` D |
| 6 | la LDH « recycle le lactate en pyruvate » et la voie « nécessite du NADH » (flèches de la diapositive) | la LDH change le pyruvate en lactate en oxydant le NADH ; le NADH du cytochrome b5 vient de la glycolyse | `gr-qc-cytb5` A |
| 7 | les Blue Fugates avaient une « mutation germinale du cyt B5 » | un déficit en NADH-cytochrome b5 réductase (Cawein, Arch Intern Med 1964) | `gr-rv-bebes-bleus` |
| 7 | 2,3-BPG, hyperthermie et acidose rangés sous « l'effet Bohr » | l'effet Bohr est celui du pH et du CO2 | `gr-qc-affinite` C |
| 10 | la bilirubine hydrophobe est « verte/jaune » | jaune ; le vert d'une ecchymose est la biliverdine | `gr-rv-ecchymose` |
| 12 | la chlorophylle, « très proche de l'hémoglobine » (la diapositive légende « Human Blood Hemoglobin » le dessin d'un hème), a « exactement la même fonction » | proche de l'hème ; pigment de la photosynthèse (TLFi) | `gr-rv-chlorophylle` |

**Points douteux** :

| Page | La ronéo dit | Le doute | Carte |
|---|---|---|---|
| 2 | les mitochondries, en périphérie du noyau, s'externalisent avec lui | éliminées dans le réticulocyte par mitophagie (Sandoval, Nature 2008) | `gr-qc-structure` B |
| 5 | les lactates vont au foie « pour produire sa propre énergie » | le foie en refait du glucose (cycle de Cori) | `gr-qc-voies-glucose` B |
| 9 | « l'hème n'est pas simple à produire donc autant le recycler » | l'hème est dégradé (biliverdine, bilirubine) ; l'hème oxygénase n'en libère que le fer (diapositive p. 8) | `gr-qc-heme-role` D |
| 10 | la sphérocytose « peut toucher ces 3 protéines à la fois » | plusieurs gènes possibles, d'ordinaire un seul par famille (An et Mohandas, Br J Haematol 2008) ; la proposition dit « l'ankyrine, la spectrine ou la bande 3 » | `gr-qc-cytosquelette` D |
| 10 | le déficit en ATP rattaché aux enzymes, « voie du G6PD et PK » (la ronéo n'est pas sûre) ; la FC 2025-26 écrit « déficit en G6PD arrête la production d'ATP » | le déficit en G6PD hémolyse par stress oxydatif (NADPH, glutathion ; Manuel MSD) ; l'ATP, c'est la PK | `gr-qc-hemolyse` B |
| 11 | l'ALAS « avec 2 sous-unités » | la p. 8 dit deux formes, ALAS-1 et ALAS-2 ; mais chaque ALAS est bien un homodimère, deux sous-unités (Bailey, Nat Commun 2020) : phrase ambiguë, « deux formes » à l'examen | `gr-qc-regulation-fer` B |

**Les erreurs du cours 2024-25** restent dites par un ATTENTION nu, sans genre :
« 1 ATP » par glucose (`gr-qc-metabolisme` E), « ALA déshydrogénase »
(`gr-qc-porphyries` D), le 90 % « de l'énergie » (`gr-ech-s2` B, `gr-ech-m2` B).

## Le schéma cliquable : les deux voies

Huit boîtes, un seul substrat, un carrefour (`voies-globule-rouge.svg`,
`gr-zo-voies`, p. 5). Les zones disent maintenant « la voie qui reçoit 90 % du
glucose entrant » et « les 10 % restants » :

| | Glycolyse anaérobie | Pentoses phosphates |
|---|---|---|
| Part du glucose entrant | **90 %** | **10 %** |
| Produits | ATP (pompes Na+/K+), NADH (cytochrome b5), 2,3-BPG par le shunt | NADPH → glutathion |
| Enzyme | **pyruvate kinase** | **G6PD** |

## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026)

Sous l'annale, 9 cartes Simple (`niveau-simple`) et 2 Moyen (`niveau-moyen`),
thème `metabolisme`. **Relues sur la ronéo 2026-27 le 19/10/2026** : toutes citent
sa page (`SRC["fiche"]`) ; leurs justifications citent la ronéo, et « cours
2024-25 » là où seul l'ancien cours parle.

**Le schéma** `ech-globule-rouge` (13 fichiers, `schemas.py`, dessiné par
`echelle.py`, copie exacte du modèle) est redessiné d'après la ronéo 2026-27
(p. 2-8, 11-12). Trois cases changent : « 90 % du glucose entrant » et « 2 ATP et
2 lactates » (glycolyse, p. 5), « l'équilibre hydrique et osmotique » (ce que
garde la pompe, p. 5), « le minimum vital, un métabolisme optimisé » (la cellule,
p. 2, 4). Les trous restent ceux du 16/10, et aucune case nouvelle ne trahit un
trou : la case de l'eau dit l'équilibre, pas son sens.

Les formes sont tenues : clés Simple réparties (A : s1, s4, s6 ; B : s2, s7, s8 ;
C : s3, s5, s9), Moyen à une ou deux vraies (m1 BD, m2 C), « ↗ Prépare la
proposition X » en fin d'explication.

**ATTENTION posés** : la correction surlignée du sujet 2024/2025 laisse de côté
l'item E de son QCM 5 (s6, s7, m1, comme `CONFLITS`) ; 90 % de l'énergie (cours
2024-25) contre 90 % du glucose entrant (cours 2026-27) (s2, m2).

## L'annale : le sujet 2024/2025

Le QCM 5 du sujet 2024/2025 (`gr-an-2425-q5`), verbatim. Sa session cite le sujet
(`src-sujets-sang-2425`) ; il cite aussi la ronéo 2026-27 p. 5 en source
secondaire. Sa figure est désormais le schéma bilan du professeur (p. 11) ; le
schéma de l'échelle, à lettres, l'accompagne. Chaque item a été relu sur la ronéo
2026-27, qui le confirme.

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2024/2025, QCM 5 (`gr-an-2425-q5`) | aucune (sujet sans corrigé) ; surlignée : BCD | **BCDE** | E : le NADH de la glycolyse sert la voie du cytochrome b5, qui ramène le fer à l'état Fe2+ (p. 6-7, 11-12) ; le cours 2024-25 le disait mot pour mot (p. 4). `ATTENTION —` et entrée `CONFLITS` |

**La correction surlignée (officieuse).** Les sujets du dépôt du 15/10 portent
des réponses surlignées, posées après coup et d'origine inconnue : ni grille ni
corrigé de la faculté. Quand elle diffère et que le cours tranche, la carte suit
le cours.

## Le lexique

Les quatre premiers termes de l'UE Tissu sanguin, pages mesurées
(`chercher_pages.py`) dans la ronéo 2026-27 et le cours 2024-25 :
`lex-methemoglobine` (p. 2, 6), `lex-porphyrie` (p. 3, 8), `lex-saturnisme`
(p. 8, 11), `lex-bilirubine` (p. 9-11). `lex-hemolyse` (BMCP) et `lex-ictere`
(virologie) sont accueillis ailleurs. Leurs étymologies (TLFi par l'API du
CNRTL, Bailly, Gaffiot) sont proposées dans le brouillon `etym/sang_gr.json`,
avec quatre racines nouvelles (`porphyr-`, `saturn- (latin)`, `bili- (latin)`,
`rub- (latin)`) ; les définitions les écrivent déjà sous la forme
qu'`appliquer_etymologies.py` produirait. Le TLFi range « méthémoglobine » sous
mét(a)- (μετά), le Wiktionnaire sous « métal » : la table suit le TLFi.

## À relire

Aucune carte `a-relire` : chaque carte cite sa page, dans la ronéo 2026-27 ou,
pour les six cartes absentes, dans le cours 2024-25.

## Questions pour Vincent

- **Le « capteur EC »** (p. 8) : la ronéo dit elle-même mal entendre
  l'enregistrement ; la carte suit le tableau de la promo et la diapositive (le
  récepteur de la transferrine, à la surface). Si tu as noté autre chose en
  cours, `gr-qc-regulation-fer` D est à reprendre.
- **« 8 à 12 µm »** : la carte garde la fourchette du professeur pour l'examen,
  et donne 7,5 à 8,7 µm en référence. D'accord ?
- **La lactate déshydrogénase** : les deux diapositives du professeur la dessinent
  chacune autrement (glycolyse : NAD → NADH ; cytochrome b5 : lactate →
  pyruvate avec NADH → NAD), et aucune n'est juste. Les cartes répondent « la
  glycolyse fait le NADH, dont une partie sert la cytochrome b5 réductase ».
  S'il a dit autre chose à l'oral, `gr-qc-anaerobie` D et `gr-qc-cytb5` A sont à
  reprendre.
- **Le lexique de l'UE** commence ici (4 termes) : les étymologies sont à verser
  dans `etymologies.json` depuis le brouillon.
- **La fiche** `Tissu sanguin/MÉTABOLISME DE L’HEME.pdf` n'est pas encore dans le
  dossier des PDF de l'application : `outils/copier_les_cours.py`, hors du bac à
  sable.

## Régénérer

```
python generer.py
```
