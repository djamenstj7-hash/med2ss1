# Dépistage biochimique des maladies métaboliques — paquet BMCP

79 notes, 145 cartes. Chapitre `chap-ue-bmcp-fc4` de l'UE BMCP (identifiant du
squelette). Cours du **Pr Dessein, le 23/09/2026** (semaine 3), en un ronéo de
16 pages. **Aucune annale** : voir plus bas.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 31 | 31 |
| QRU | 1 | 1 |
| Texte à trous | 12 | 73 |
| QROC | 13 | 13 |
| Recto-verso | 8 | 8 |
| Schéma cliquable | 2 | 7 |
| Lexique | 12 | 12 |

Huit thèmes, dans l'ordre du cours : maladies héréditaires du métabolisme
(`mhm`), voie métabolique et point de blocage (`voie-metabolique`), substrats
énergétiques et réserves (`substrats`), compartimentation spatiale et
temporelle (`compartimentation`), stratégie diagnostique et exploration
biochimique (`strategie-diagnostique`), intoxication : ammoniac et cycle de
l'urée (`intoxication`), carence énergétique : bêta-oxydation et PDH
(`carence-energetique`), dépistage néonatal (`depistage-neonatal`). Les huit
clés sont nouvelles : leurs libellés sont à ajouter à `THEME_LABELS`.

## Les sources et leurs années

- **Le ronéo 2026-27** (Ronéo & Juliette, `src-fc-bmcp-depistage`,
  `BMCP/DEPISTAGE BIOCHIMIQUE MALADIE MÉTABOLIQUE.pdf`) fait foi. Toute carte
  qui en vient porte sa page et le cite.
- **La FC n°4 du Ronéosaure 2024-25** (`src-cours-dep-2425`, même professeur)
  sert d'appoint : pour trancher une erreur du ronéo, et comme source des cinq
  cartes que le cours de l'année ne porte plus. L'errata du Ronéosaure ne relève
  pour ce cours qu'une coquille typographique (p. 5, espaces manquants).
- Aucune version plus ancienne du cours dans le Ronéosaure (ni « COURS 2023-24 »,
  ni Charonéo).

Ce que 2026-27 ajoute : la partie VIII sur le dépistage néonatal (dépistage
contre diagnostic, les six critères de la HAS, les 16 maladies dépistées en
France, deux figures p. 15-16), la synthèse des cas (VII), le tableau du bilan
rédox de Baptiste (p. 13), la liste complète du bilan de base (bilan hépatique,
CPK, NFS). Ce qu'il retire : le cinquième cas clinique (Eli), la conduite à
tenir immédiate chez Maya, le malonyl-CoA, l'opposition des rapports L/P élevé
et normal.

## Ce que le cours a dicté

- **Le rouge du ronéo** : « AU PLUS PRÈS DE LA CRISE !!!! » (p. 9) — carte
  `dep-qc-exploration`, où c'est une proposition `indispensable`, un QROC
  (`dep-qr-quand`) et un texte à trous ; « troubles digestifs et troubles
  neurologiques » chez Noa (p. 10) — `dep-qc-noa`, `indispensable` aussi.
- **Le gris du ronéo** n'est pas défini comme hors programme dans son
  introduction : il se carte (décision du 25/09). Deux passages : la fin des
  deux phrases du diagnostic de certitude (p. 8, voix des rédacteurs), et la
  liste des examens spécialisés d'orientation (p. 10), suivie de « (N'a pas été
  dit) » — projetée, pas commentée, ce que la FC 2024-25 disait déjà (« sur
  diapo mais pas énoncé »). Elle a une carte, `dep-qc-specialises`, qui le dit.
- **Le raisonnement A → E** (p. 3-4) porte tout le cours : il a un texte à
  trous, trois QCM dont une QRU « quelle enzyme ? », un recto-verso et le premier
  schéma cliquable.
- **Les quatre cas cliniques** (Noa, Sylvie, Maya, Baptiste) sont en QCM à
  vignette, chacun avec son QROC de réflexe (ammoniac, glucose, bêta-oxydation,
  PDH). La synthèse (p. 14) a son QCM et son texte à trous.

## Ce que les annales ont dicté

Rien : le polycopié « BMCP 4 » n'existe pas (le dossier des annales saute de
BMCP 2 à BMCP 5). La seule question d'annales qui touche ce cours, **2023/2024
S1 Q. 14** (métabolisme intermédiaire et MHM, compartimentation spatiale,
hypoglycémie sans corps cétoniques, ammoniac et cycle de l'urée), est rangée
dans le polycopié BMCP 5 et **déjà cartée** dans `bmcp_metabolisme`
(`met-an-2324-q14`). Elle n'est pas recopiée ici : deux notes pour une même
annale feraient doublon dans le planificateur. Ses cinq propositions sont
couvertes par `dep-qc-temporelle`, `dep-qc-spatiale`, `dep-qc-maya` et
`dep-qc-ammoniac`.

## Les schémas cliquables

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `voie-bloquee.svg` (`dep-zo-voie-bloquee`) | la voie A → E bloquée sur E2, avec B' : le composé qui s'accumule modérément (A), massivement (B), le métabolite alternatif (B'), la partie où plus rien n'est produit (C-D-E) | 4 |
| `jeune-frise.svg` (`dep-zo-jeune`) | l'axe du temps après un repas, trois bandes sans nom : période post-prandiale, jeûne court, jeûne long, désignées par ce qui s'y passe | 3 |

Le premier reproduit la figure du ronéo p. 4, blocage compris, sans aucune
légende de rôle ; la figure du ronéo est en correction. Le second n'a pas de
figure dans le ronéo : la frise légendée de `schemas.py` sert de correction.

## Les figures du ronéo

Six figures du ronéo 2026-27, extraites en PNG (réduites à 256 couleurs) et
déclarées dans `IMAGES` avec leur page : la voie A → E (p. 3), le blocage sur
E2 (p. 4), la stratégie diagnostique (p. 8), le bilan rédox de Baptiste (p. 13),
dépistage contre diagnostic (p. 15), les pathologies dépistées en France
(p. 16). Trois schémas légendés, redessinés dans `schemas.py`, complètent :
substrats et carrefour de l'acétyl-CoA (p. 5-6), les voies du jeûne (p. 6-7 et
12), intervalle libre ou atteinte d'emblée (p. 10-14). **26 QCM sur 32** sont
illustrés en correction ; les six autres (compartimentation spatiale, bilan de
base, examens spécialisés, OTC, Sylvie, Eli) n'ont pas de figure qui dise
quelque chose de plus que le texte.

## Les erreurs du ronéo 2026-27

Le ronéo de l'année ne sera pas corrigé, et le tableau des erreurs de la BMCP
n'existe pas encore. Chaque erreur est portée sur la carte où elle se joue,
dans la justification, avec la bonne lecture et sa source : `ATTENTION (prise
de notes)` quand le ronéo a mal noté le cours, `ATTENTION (douteux)` quand rien
ne tranche (Krebs et la cétogenèse, Sylvie « censée ne plus être porteuse »).
L'écran de correction en fait un encadré, et la carte entre dans le thème
« Pièges des ronéos ».

| Page | Le ronéo dit | Ce qui est juste | Source | Carte |
|---|---|---|---|---|
| 3 | « la digestion et l'assignation des nutriments » | l'**assimilation** des nutriments | TLFi (assimilation) ; FC 2024-25 p. 4 | `dep-qc-fonctions` B |
| 6 | le cycle de Krebs, point de départ de la « cétogénèse » et de la néoglucogenèse | la néoglucogenèse part de l'oxaloacétate ; la cétogenèse part de l'acétyl-CoA de la bêta-oxydation, quand l'oxaloacétate part vers la néoglucogenèse — pas d'un intermédiaire du cycle | FC 2024-25 p. 6 (néoglucogenèse seule) ; le même ronéo p. 7 et 13 ; StatPearls, *Biochemistry, Ketogenesis* — **douteuse** (formulation de diapositive possible) | `dep-qc-krebs` B |
| 10 | « on mesure l'activité enzymatique : c'est la biologie moléculaire à la recherche des mutations » | la mesure d'activité est l'étude fonctionnelle ; la biologie moléculaire est le génotypage | le même ronéo p. 8-9 ; FC 2024-25 p. 11 | `dep-qc-certitude` C |
| 11 | les filles, « porteuses saines et transmettrices » du déficit en OTC | les femmes hétérozygotes ne sont pas forcément saines : selon l'inactivation de l'X, elles peuvent avoir une forme symptomatique et décompenser (Sylvie) | le même ronéo p. 12 et 14 ; FC 2024-25 p. 13 ; MedlinePlus Genetics | `dep-qc-otc` C |
| 12 | Sylvie « censée ne plus être porteuse » | elle est hétérozygote, donc porteuse : « censée n'être que porteuse » (sans symptôme) ou « censée ne pas être porteuse » (aucun antécédent familial) — **douteuse**, on ne peut pas trancher | le même ronéo, même phrase ; déjà dans la FC 2024-25 p. 14 | `dep-qc-otc` D |
| 14 | les garçons « représentent 76 à 85 % des cas de déficit en PDH » | 76 à 85 % est la part des déficits en PDH dus au gène PDHA1 ; le déficit lié à PDHA1 touche presque autant les filles | FC 2024-25 p. 17 ; MedlinePlus Genetics (≈ 80 %) ; revue de 891 patients dans *Brain*, 2025 (53 % de filles) | `dep-qc-pdh` E, `dep-qr-pdha1` |

Trois différences entre années, qui ne sont pas des erreurs : Maya décompense
à **H15** de vie en 2026-27, à **H21** en 2024-25 (aucune carte ne demande
l'heure) ; une voie compte « 3, 5 voire 20 réactions » en 2026-27, « 3, 10,
50 » en 2024-25 (la carte suit 2026-27) ; la lipolyse et la bêta-oxydation
sont un paragraphe sans titre entre le jeûne court et le jeûne long en 2026-27
(p. 7), le début du jeûne long en 2024-25 (p. 8) — les deux disent qu'elles
prennent le relais du glycogène épuisé, et `dep-qc-jeune` B le dit sans
`ATTENTION`.

## Les clés qui ne sont pas reprises telles quelles

Aucune : le chapitre n'a pas d'annale. Les propositions que le ronéo
2026-27 affirme à tort sont marquées `ATTENTION` et cotées selon la bonne
lecture (tableau ci-dessus).

## Absent du cours 2026-27

Cinq cartes entières, tirées de la FC 2024-25, portent le tag `absent-2026` et
le disent en tête de leur explication :

| Carte | Notion | FC 2024-25 |
|---|---|---|
| `dep-qc-eli` | le cas clinique 5 : profil de déficit en PDH, PDHA1 normal, variants d'ECHS1 (crotonase) | p. 16-18 |
| `dep-qr-glucose-maya` | le geste qui réveille Maya : perfusion de glucose concentré | p. 15 |
| `dep-qr-malonyl` | le malonyl-CoA, qui bloque l'entrée des acides gras dans la mitochondrie | p. 7 |
| `dep-rv-dilution` | pourquoi 3 fois la normale chez l'adulte vaut 15 fois chez le nouveau-né | p. 13 |
| `dep-rv-lactate-pyruvate` | rapport L/P élevé (chaîne respiratoire) contre normal (PDH) | p. 16 |

Des propositions isolées de 2024-25 le disent dans leur propre justification :
les premières urines du matin (`dep-fa-exploration`), la dilution
(`dep-qc-sylvie` C), le rapport L/P élevé (`dep-qc-baptiste` E).

## Le lexique

Douze termes, que ce chapitre accueille parce que son ronéo les emploie le plus
dans la BMCP 2026-27 (mesuré sur le texte des neuf ronéos parus) : homéostasie,
métabolite, ammoniémie, hyperlactacidémie, hyperpyruvicémie, glucoformateur,
cétogène, anamnèse, eutrophe, génotypage, néonatal, décompensation. Pages
mesurées dans le PDF 2026-27 avec les règles de `chercher_pages.py` (mot entier,
pluriel permis) ; pour « néonatal », les pages comptent aussi « néonatale » et
« néonataux » (p. 10, 12, 15), que la règle ne voit pas.

Les racines que les tableaux des FC de sémantique 2026-27 enseignent les
citent : homéo- (FC 2, p. 5), -stase (FC 1, p. 2), -gène et géno- (FC 1, p. 6,
comme dans `bmcp_lipides`), eu- (FC 2, p. 6), ana- (FC 2, p. 10), hyper- (FC 2,
p. 9). Les autres restent grises, « hors FC ». Les racines hyper-, -émie,
-stase et -trophie existent déjà dans la table ; les autres, et les douze
termes, sont proposés à `etymologies.json` (vérifiés sur le TLFi, le Bailly, le
Gaffiot et le Wiktionnaire) et seront écrits par `appliquer_etymologies.py` ;
-gène est proposée à l'identique par `bmcp_lipides` : une seule entrée.

## À relire

Aucune carte `a-relire` : chacune a été confrontée à sa page du ronéo 2026-27,
ou de la FC 2024-25 pour les cinq cartes absentes.

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```
