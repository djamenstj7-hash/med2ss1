# Métabolisme glucidique — paquet BMCP

68 notes, 136 cartes. Chapitre `chap-ue-bmcp-fc6` de l'UE BMCP, septième de l'UE
(`ordre=7`). **Cours du Pr V. Huin, le 30/09/2026, de 9 h à 10 h, dans le ronéo
Ronéo & Juliette 2026-27** « Métabolisme glucidique » (12 pages) : réaligné sur lui le
11/10/2026. Le chapitre était carté depuis le 05/10 (plan C16) sur la FC n°7 du
Ronéosaure 2025-26 (Dr Huin, 03/10/2025), qui n'est plus qu'un appoint. Une annale du
Ronéosaure 2024-25 (BMCP 6, le QROC 3 de 2023/2024 S1), et la Q. 19 du sujet de
2024/2025, sans corrigé. Examen : mardi 5 janvier
2027.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 23 | 23 |
| QRU | 1 | 1 |
| Texte à trous | 12 | 77 |
| QROC | 9 | 9 |
| Recto-verso | 9 | 9 |
| Lexique | 11 | 11 |
| Schéma cliquable | 1 | 4 |
| Planche à légender | 2 | 2 |

Dont **4 notes d'annales** : les trois sous-questions du QROC 3 de 2023/2024 S1
(BMCP 6), en recto-verso, sans corrigé officiel, et la Q. 19 du sujet de 2024/2025
(examen du 09/01/2025, sans corrigé, déposé le 15/10/2026). **21 QCM sur 24 sont
illustrés** (88 %), 47 notes sur 68. **15 cartes portent un piège du ronéo 2026-27** (thème
« Pièges des ronéos »). Aucune carte absente du cours 2026-27, aucune carte
`a-relire`.

Huit thèmes, dans l'ordre du cours, tous déjà dans `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) ; le réalignement n'en ajoute aucun :

| Clé | Libellé | Notes |
|---|---|---|
| `glucides` | Glucides | 8 |
| `glucose` | Métabolisme du glucose | 5 |
| `apports-glucidiques` | Apports alimentaires en glucides | 9 |
| `saccharose` | Saccharose et sucres cachés | 5 |
| `lactose` | Lactose et lactase | 7 |
| `fodmaps` | Troubles fonctionnels intestinaux et FODMAPs | 4 |
| `fibres-alimentaires` | Fibres alimentaires | 5 |
| `index-glycemique` | Index glycémique et pouvoir hyperglycémiant | 14 |

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-bmcp-glu-2627` — « Métabolisme glucidique » (12 p.), `BMCP/MÉTABOLISME GLUCIDIQUE.pdf` | **2026-27** | **la base** : `SRC["fiche"]`, ce que le lecteur ouvre (`chapitre=`) ; cours du 30/09/2026, 9 h-10 h, Pr V. Huin ; sa seule figure, les actions de l'insuline (p. 11) ; 53 notes de cours et les 11 termes du lexique la citent |
| `src-fc-bmcp-glu-2526` — Ronéosaure, « FC n°7-métabolisme glucidique » (19 p.) | 2025-26 | **appoint** (`SRC["cours"]`, `SRC["medias"]`, sans `chapitre=`) : ses diapositives (p. 5 ×2, 13, 16, 17), que le ronéo 2026-27 n'a pas, et ce qu'elle seule disait, cité « FC 2025-26, p. 16 » dans les cartes |
| `src-annales-bmcp-6-metabolisme-glucidique` — « BMCP 6 - Métabolisme glucidique » | 2024-25 | le QROC 3 de 2023/2024 S1 ; table p. 3 |
| `src-sujets-bmcp-2425` — « Sujets de BMCP 2024/2025, session 1 » (30 p.) | 2024-25 | le sujet de l'examen du 09/01/2025, **sans corrigé** (dépôt `Annales_15102026/`, 15/10/2026) : la Q. 19 ; `SRC["sessions"]["2024/2025 S1"]` ; déclaré à l'identique dans tous les chapitres de BMCP qui en cartent une question |

Les textes citent « p. 7 » pour le ronéo 2026-27, « FC 2025-26, p. 10 » pour l'appoint.
Les pages sont celles du PDF ; les p. 1-2 portent la page de garde et le plan.

Lus en appoint, sans être déclarés : les cours 2024-25 (FC n°6 du Ronéosaure 2024-25)
et 2023-24 (« 6. BMCP - Métabolisme glucidique ») du même enseignant, pour trier une
erreur du ronéo entre prise de notes et cours lui-même ; l'errata des cours 2025-26
(aucune entrée sur cette FC) et celui des annales 2024-25 (rien sur BMCP 6). La promo
2026-27 n'a pas de tableau d'erreurs BMCP au 11/10/2026.

La fiche de l'année se copie dans le dossier des PDF de l'application par
`outils/copier_les_cours.py`, lancé avec le dossier des ronéos 2026-27
(`Ajouts/[NUMERIQUE] Ronéo & Juliette 26-27 11 10 2026/S1/CM`), hors du bac à sable.

Les en-têtes des ronéos et du polycopié portent des noms d'étudiants : aucun n'est
repris.

## Ce qui correspond à quoi

Le ronéo 2026-27 suit tout le plan de la FC 2025-26, dans le même ordre, et presque
mot pour mot : c'est le même cours, avec moins de figures.

| FC 2025-26 | Ronéo 2026-27 |
|---|---|
| I. Définition, classification, glucose, disaccharides, polysaccharides (p. 3-4) | p. 2-3 |
| Rappel sur le glycogène, II. Résumé du métabolisme énergétique (p. 5-6) | p. 3-4 |
| III.A-C Ration, régimes occidentaux, proportion de sucre (p. 6-7) | p. 4-5 |
| III.D-F Digestion, sucres de l'alimentation, glycogène (p. 7-8) | p. 5-6 |
| III.G Saccharose, pouvoir sucrant, excès (p. 9) | p. 6 |
| III.H Lactose, lactase, intolérance (p. 9-11) | p. 6-7 |
| III.I-K Troubles fonctionnels, FODMAPs, glucides non digérés (p. 11-13) | p. 7-8 |
| III.L Fibres (p. 13-15) | p. 8-9 |
| III.M Sucres cachés (p. 15-16) | p. 9-10 |
| IV.A-B Vitesse d'absorption, pouvoir hyperglycémiant, IG (p. 16-18) | p. 10-11 |
| IV.C Conséquences de l'hyperglycémie, cuisson, ordre des aliments (p. 18-19) | p. 11-12 |
| Diapositives : après un repas, opposition (p. 5), glucides non digérés (p. 13), pouvoir hyperglycémiant (p. 16), IG (p. 17) | **aucune** |
| Diapositive des actions de l'insuline (p. 18) | **p. 11**, plus nette |

## Le réalignement du 11/10/2026

**Les 63 notes de la version 2025-26 ont été relues une à une** contre le ronéo
2026-27. Toutes y retrouvent leur notion centrale : **toutes citent désormais leur page
de l'année** (et perdent le badge « Cours 2025-26 ») :

| Ronéo 2026-27 | Notes |
|---|---|
| p. 2 | `glu-fa-definition`, `glu-qc-classification`, `glu-qc-glucose`, `glu-qr-dextrose` |
| p. 3 | `glu-fa-utilisations`, `glu-qc-utilisations`, `glu-rv-lactose-saccharose`, `glu-rv-amidon-glycogene`, `glu-rv-foie-muscle`, `glu-rv-insuline-glucagon`, `glu-pl-opposition` |
| p. 4 | `glu-fa-ration`, `glu-qc-ration`, `glu-qc-occident` |
| p. 5 | `glu-fa-sources`, `glu-qc-proportions`, `glu-qc-digestion`, `glu-qr-monosaccharides`, `glu-qr-lactase` |
| p. 6 | `glu-fa-pouvoir-sucrant`, `glu-qc-exces-saccharose`, `glu-qr-glycogene`, `glu-qr-lactose-sucrant` |
| p. 7 | `glu-fa-lactose`, `glu-fa-intolerance`, `glu-qc-lactase`, `glu-qc-intolerance`, `glu-qc-tfi`, `glu-rv-micronesie`, `glu-qr-hydrogene` |
| p. 8 | `glu-fa-fodmaps`, `glu-fa-fibres`, `glu-qc-non-digeres`, `glu-qc-fibres-roles`, `glu-qr-cellulose`, `glu-rv-fibres-types` |
| p. 9 | `glu-qc-fibres-sources`, `glu-qc-sucres-caches` |
| p. 10 | `glu-fa-vitesse`, `glu-qc-vitesse`, `glu-qc-pouvoir-hyperglycemiant`, `glu-qr-etiquette`, `glu-qr-hypoglycemie`, `glu-zo-courbes` |
| p. 11 | `glu-fa-ig`, `glu-qc-ig-aliments`, `glu-qc-ig-moyen`, `glu-qc-hyperglycemie` |
| p. 12 | `glu-fa-repas`, `glu-qc-cuisson-ordre` |
| lexique | les 10 termes, pages remesurées dans le ronéo 2026-27 |
| annales | les 3 versos du QROC 3, qui citent désormais les pages de l'année |

Chaque proposition, chaque trou ou chaque phrase que seule la FC 2025-26 porte le dit
dans sa carte (« FC 2025-26, p. 16 ; le ronéo 2026-27 n'a pas la figure »).

**Ce que le ronéo 2026-27 dit autrement, et ce qui a été réécrit** :

- **« Sucres rapides, sucres lents » : « n'importe quoi ! »** — la formule du
  professeur n'est plus dans le ronéo, qui garde l'idée (tous les sucres sont digérés
  très vite, p. 10). Le texte à trous `glu-fa-vitesse` commence désormais par l'idée,
  ses six trous restent ; la formule est citée dans l'explication, et dans
  `glu-qc-vitesse` C, avec sa page de 2025-26. « Quasiment aussi rapide que le glucose
  pur » est aussi propre à 2025-26 (`glu-qc-vitesse` A).
- **La glycogénogenèse** : le ronéo 2026-27 nomme ainsi la deuxième étape (p. 3), comme
  la diapositive ; le trou c3 de `glu-fa-utilisations` attend « glycogénogenèse » (et
  non plus « glycogenèse »), le verso de `glu-rv-insuline-glucagon` met le mot de l'année
  en premier.
- **La Micronésie** : le radeau et la pêche pauvre ne sont plus dans le ronéo, qui garde
  la sélection de ceux qui « pouvaient stocker les aliments » et leur désadaptation
  (p. 7) ; le verso de `glu-rv-micronesie` est réécrit sur lui, l'histoire du radeau
  passe dans l'explication (FC 2025-26, p. 10).
- **La cuisson des pommes de terre** : le ronéo garde « le pire : cuisson à haute
  température en rajoutant du gras (frites) » et « le mieux : à la vapeur ou à l'eau »
  (p. 12), sans l'exemple du four et de la noisette de beurre ; la proposition A de
  `glu-qc-cuisson-ordre` dit « plutôt qu'à haute température » au lieu de « plutôt qu'au
  four ».
- **La prise de masse grasse** (conséquence de l'hyperglycémie) et **l'étiquette que peu
  de gens regardent** ne sont plus dans le ronéo : dites avec leur page de 2025-26
  (`glu-qc-hyperglycemie` D, `glu-qr-etiquette`).
- **Les figures** : le ronéo 2026-27 n'a que celle des actions de l'insuline (p. 11).
  Elle **remplace** la même diapositive de la FC 2025-26 (p. 18) dans
  `glu-insuline-actions.png` (786 × 494 au lieu de 594 × 372) et fait une planche
  nouvelle. Les autres diapositives restent celles de la FC 2025-26, citées comme
  telles. Les schémas redessinés d'après le texte citent les pages du ronéo 2026-27,
  sauf les courbes de glycémie, dessinées d'après la diapositive de 2025-26.
- **Les erreurs du ronéo 2025-26** que le ronéo 2026-27 redit ont pris leur genre
  (voir plus bas) ; celle qu'il ne redit pas — le glucose rangé parmi les
  polysaccharides — est dite sans ATTENTION dans `glu-qc-classification` B.

**Notes nouvelles (4)**, sur ce que le cours 2026-27 porte et qu'aucune carte ne
tenait :

| Note | Ce qu'elle carte |
|---|---|
| `glu-qc-polysaccharides` | amidon et glycogène, réserves des végétaux et des animaux ; les autres polymères d'oses, végétaux, sont des fibres ; ce qui différencie les fibres ; pas d'énergie (p. 3-4). Porte le point douteux de la lignine |
| `glu-qc-fodmaps` | l'acronyme, le fructose monosaccharide, les polyols de synthèse, la durée du régime, la réintroduction (p. 8). Porte l'erreur du fructose « disaccharide » |
| `glu-pl-insuline` | la figure du ronéo 2026-27 (p. 11), ses six cases d'actions vidées : placer chaque action de l'insuline sur le muscle, le foie ou le tissu adipeux ; 4 intrus (actions du jeûne) |
| `lex-microbiote` | un terme du lexique (voir plus bas) |

## Ce que le cours a dicté

- **Ni rouge ni gris** dans ce ronéo : tout se carte. Le plan du cours fait les thèmes.
- **Ce qui n'est pas carté ici**, parce qu'un autre chapitre le tient (plan C16,
  § 0.7) : le cycle de Krebs, la néoglucogenèse et les corps cétoniques en détail
  (`bmcp_metabolisme`) ; la dépense énergétique, les réserves, les rendements
  (`bmcp_energetique`) ; l'insulinorésistance, le récepteur de l'insuline, le diabète
  (`bmcp_insuline`). Les cartes les citent. Le chapitre carte en revanche les six
  étapes d'utilisation du glucose et leur opposition, et les conséquences de
  l'hyperglycémie vues par ce cours (p. 11).
- **Le nitrite du jambon** (p. 10) n'a pas de carte à lui : ce n'est pas du métabolisme
  glucidique. Ses deux erreurs sont portées par `glu-qc-sucres-caches`, la carte qui
  donne l'exemple du jambon (voir plus bas).

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| Commenter une alimentation : ration, saccharose, IG, fibres, sucres cachés | 2023/2024 S1 QROC 3, 1) |
| Repérer les glucides à IG élevé d'un repas | 2023/2024 S1 QROC 3, 2) |
| Conseiller sans changer la quantité de glucides : IG bas, cuisson, ordre des aliments, fibres | 2023/2024 S1 QROC 3, 3) |
| Ration, amidon, glycogène alimentaire *(carte d'annale au chapitre « Métabolisme cellulaire »)* | 2022/2023 S1 Q.17 |
| Les mêmes, retournés : 50 % de la ration, le glucose et non le fructose, les polysaccharides, l'amidon des plantes, l'amidon qui n'est pas négligeable | 2024/2025 S1 Q. 19 (`glu-an-2425s1-q19`), cartée ici |

Les cinq QCM de BMCP 6 sont déjà dans `bmcp_metabolisme` et ne se recartent pas :
2022/2023 Q.17 (`met-an-2223-q17`), 2020/2021 Q.8 (`met-an-2021s1-q8`, la même
question que BMCP 5 Q.1), 2019/2020 Q.29, 2018/2019 Q.1 et Q.2 (copies de BMCP 1). Les
cartes de cours `glu-qc-ration`, `glu-qc-glucose`, `glu-rv-amidon-glycogene` en
reprennent les notions et nomment l'annale.

Les trois versos du QROC 3 ont été relus sur le ronéo 2026-27 : ils tiennent, et
citent ses pages ; la cuisson des pommes de terre y reste la réponse du professeur
(voir `glu-qc-cuisson-ordre`).

## Le schéma cliquable et les planches

| Fichier | Ce qu'on fait | Cartes |
|---|---|---|
| `courbes-glycemie.svg` | cliquer la glycémie de départ, le pic du glucose, le pic de l'aliment à IG bas, l'hypoglycémie réactive (ronéo p. 10-11 ; dessin d'après la diapositive de la FC 2025-26, p. 16) | 4 |
| `glu-opposition-numerotee.png` | légender la diapositive « Opposition glycolyse et néoglucogenèse » (FC 2025-26, p. 5 ; le ronéo 2026-27 la raconte p. 3-4) : cinq voies, deux hormones ; 4 intrus | 1 |
| `glu-insuline-numerotee.png` (**nouvelle**) | placer les six actions de l'insuline sur la figure du ronéo 2026-27 (p. 11) : le foie bloque glycogénolyse et néoglucogenèse, stocke le glycogène, convertit le glucose en acides gras puis triglycérides ; le muscle capte, stocke le glycogène, bloque la protéolyse ; le tissu adipeux fait la lipogenèse et stocke les triglycérides. Deux numéros (muscle, foie) partagent la même légende. 4 intrus : active la glycogénolyse, la lipolyse, la protéolyse, la néoglucogenèse | 1 |

La planche de l'insuline efface l'intérieur des six cases, dont le cadre reste (la case
du tissu adipeux, dont le texte mordait sur le cadre, perd ses bords haut et bas) ; les
noms des organes et le mot « Insuline » restent : on apprend les actions organe contre
organe. Pour la refaire, depuis `app/` :
`uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/bmcp_glucides glu-pl-insuline --apercus <brouillon> --taille 30`.

## Les erreurs du ronéo 2026-27

Aucun tableau d'erreurs BMCP de la promo au 11/10/2026 : tout ce qui suit a été trouvé
en relisant, trié avec la FC 2025-26 et les cours 2024-25 et 2023-24, et va dans
`contenu/ERRATA_RONEOS_2026-27.md`. Le ronéo de l'année reprend presque mot pour mot
celui de 2025-26 ; une formule qu'il partage avec lui seul ne prouve donc pas qu'elle
vient du professeur. À l'examen, on répond d'abord comme le professeur.

**Prises de notes fausses** (`ATTENTION (prise de notes)`) :

| Page | Le ronéo dit | Ce qui est juste | Carte |
|---|---|---|---|
| 7 | « Cette limitation peut concerner de nombreux adultes, notamment dans les régions européennes » | en Europe, c'est la persistance de la lactase qui est fréquente : le même ronéo quelques lignes plus bas, le cours 2024-25 (p. 7 : « contrairement aux régions européennes (90 % de la population caucasienne possèdent de la lactase) »), le cours 2023-24 ; Itan et al., BMC Evol Biol 2010 | `glu-qc-lactase` (explication, et E) |
| 7 | la persistance de la lactase par « augmentation du nombre de gênes » | des « mutations du promoteur » (même phrase) : le variant −13910 C>T, amplificateur dans MCM6 (Enattah et al., Nat Genet 2002) ; « une mutation » (cours 2024-25, p. 7) | `glu-qc-lactase` (B) |
| 8 | les intolérances « dûes aux disaccharides avec le lactose et le fructose » (déjà dans la FC 2025-26, p. 12) | le fructose est un monosaccharide, le M de l'acronyme (la ligne du dessus ; cours 2024-25, p. 8 ; Gibson et Shepherd, J Gastroenterol Hepatol 2010) | `glu-qc-fodmaps` (B), `glu-fa-fodmaps` |
| 9 | les fibres diminuent « l'hypocholestérolémie » (déjà dans la FC 2025-26, p. 14) | l'hypercholestérolémie : elles diminuent le cholestérol (même page) ; « hypocholestérolémiant » (cours 2024-25, p. 9), « l'hypercholestérolémie » (cours 2023-24, p. 10) | `glu-qc-fibres-roles` (D) |

**C'est le cours lui-même** (`ATTENTION (cours)` : « À l'examen : … », puis « La
référence : … ») :

| Page | Le cours dit | La référence | À l'examen | Carte |
|---|---|---|---|---|
| 3 | le foie, « seul organe capable de distribuer du glucose dans le sang » (FC 2025-26 p. 5, cours 2024-25 p. 2-3, 2023-24 p. 14, clé de 2017/2018 S1 Q.8) | le principal, pas le seul : rein et intestin ont la glucose-6-phosphatase (Vily-Petit, Gautier-Stein et Mithieux, médecine/sciences 2025 ; Gerich, Diabetes Care 2001) | « le foie, seul » | `glu-rv-foie-muscle` |
| 6 | aspartame : pouvoir sucrant 350 (FC 2025-26 p. 9, cours 2024-25 p. 6) | environ 200 (EFSA) | 350 | `glu-fa-pouvoir-sucrant` |
| 9 | « T65 = très raffiné », « très blanche » ; « T45 = peu raffinée, de couleur plutôt brune » (FC 2025-26 p. 15, cours 2024-25 p. 9, 2023-24 p. 11) | l'inverse : le type est le taux de cendres ; la T45 (< 0,50 %) est la plus blanche, la T150 (> 1,40 %) la complète (cahier des charges Label Rouge « Farine de meule », INAO) | plus le type est élevé, plus la farine est raffinée | `glu-qc-fibres-sources` (explication) |
| 12 | « le pire : cuisson à haute température en rajoutant du gras (frites) » ; « le mieux : à la vapeur ou à l'eau » (FC 2025-26 p. 19, cours 2024-25 p. 11, 2023-24 p. 13) | le gras abaisse la réponse glycémique (du cheddar fait passer l'IG d'une pomme de terre au four de 93 à 39, − 58 % : Henry et al., Eur J Clin Nutr 2006) ; les frites ont le plus souvent un IG plus bas que la pomme de terre au four ; l'eau n'est pas toujours mieux que le four (Nayak, Berrios et Tang, Food Res Int 2014) | vrai, comme le professeur | `glu-qc-cuisson-ordre` (A, B, et l'explication) |
| 10 | le nitrate/nitrite de sodium, « cancérigène reconnu par l'OMS » (FC 2025-26 p. 16, cours 2023-24 p. 11 ; « cancérigène », cours 2024-25 p. 10) | le CIRC classe le nitrate ou le nitrite ingérés dans des conditions de nitrosation endogène « probablement cancérogènes » (groupe 2A, monographie 94) ; c'est la viande transformée qui est cancérogène avérée (groupe 1, monographie 114) | comme le professeur | `glu-qc-sucres-caches` (explication) |

**Points douteux** (`ATTENTION (douteux)`), dits dans la carte sans changer sa clé :

| Page | Le point | Carte |
|---|---|---|
| 3 | la lignine parmi les « autres polymères d'oses » (comme la FC 2025-26 ; les cours 2024-25 et 2023-24 ne la nomment pas) : c'est une fibre, mais un polymère phénolique, pas un glucide (EFSA 2010 : « non-digestible carbohydrates plus lignin ») ; l'erreur est sûre, sa source (diapositive ou prise de notes) ne l'est pas | `glu-qc-polysaccharides` (explication) |
| 7 | le lait de femme « près de 2 fois plus concentré » en lactose : les chiffres du cours (55-60 contre 45 g/L, trois années) donnent 1,3 ; les mesures, environ 74 contre 47 g/L, 1,6 (Porter, Proc Nutr Soc 1978) | `glu-fa-lactose` |
| 7 | l'obésité de la Micronésie, « conséquence très dangereuse » enchaînée sur la persistance de la lactase : c'est un autre exemple de sélection par la famine, le « génotype d'épargne » (Neel, Am J Hum Genet 1962) | `glu-rv-micronesie` |
| 7, 8 | les gaz de la « fermentation lactique » : la fermentation colique donne du lactate parmi d'autres produits, et des gaz (H₂, CO₂, CH₄) qui ne viennent pas de la fermentation lactique proprement dite (Windey et al., Nutrients 2015) ; « fermentation du lactose » en 2024-25 et 2023-24 | `glu-fa-intolerance`, `glu-qc-non-digeres` |
| 10 | le dextrose, « sucre modifié dérivé du saccharose » (FC 2025-26 p. 16 ; « équivalent de saccharose modifié » en 2024-25 ; « sucre modifié » en 2023-24) : c'est le D-glucose (p. 2 du même ronéo), tiré de l'amidon de maïs ; l'erreur est sûre, sa source ne l'est pas, et aucune proposition à clé ne la teste | `glu-qr-dextrose` |
| 10 | la ratatouille, 2,3 carrés de sucre par pot : « le sucre ne fait pas partie de la recette, c'est en fait l'amidon de maïs présent qui est un type de sucre » (comme la FC 2025-26, p. 15) : les « sucres » d'une étiquette ne comptent que les mono- et disaccharides (règlement (UE) n° 1169/2011, annexe I), l'amidon n'y entre pas, et ceux d'une ratatouille viennent surtout des légumes ; le cours 2024-25 disait ce sucre ajouté « pour donner du goût » (p. 10). Le professeur appelle « sucre » tout glucide : la source de la formule n'est pas sûre | `glu-qc-sucres-caches` (explication) |
| 10 | le rose du jambon, « pas naturel => colorant » (FC 2025-26, p. 16 : « c'est un colorant ») : le nitrite est un conservateur (E 250, règlement (CE) n° 1333/2008), et le rose vient de la nitrosomyoglobine qu'il forme avec la myoglobine ; les cours 2024-25 (p. 10) et 2023-24 (p. 11) disaient seulement qu'il donne la couleur rose | `glu-qc-sucres-caches` (explication) |

Dit sans ATTENTION, parce que deux années se contredisent sans erreur sûre : le
dextrose du jambon sert aussi « à le conserver » pour le ronéo 2026-27 (p. 10) et la FC
2025-26, alors que les cours 2024-25 (p. 10) et 2023-24 (p. 11) disaient que ce n'est
pas son rôle, le nitrite conservant déjà (`glu-qc-sucres-caches` E).

Non repris, comme toutes les coquilles sans conséquence : le titre « Résumé du
métabolisme génétique » (p. 3) pour « énergétique », comme le dit le plan (p. 1).

Dits sans ATTENTION, parce que ce ne sont pas des erreurs : les seuils d'IG du cours
(≤ 50, 50-70, ≥ 70 %) quand les tables internationales placent le bas à 55
(`glu-fa-ig`) ; les « souris » de l'expérience du sucre et de la cocaïne, des rats dans
l'étude classique (`glu-qc-sucres-caches` B).

## Les erreurs du Ronéosaure 2025-26

Le Ronéosaure n'est pas le ronéo de l'année : ses erreurs sont dites sans genre et
n'entrent pas dans la liste de la promo. Toutes celles que la version du 05/10 relevait
sont redites par le ronéo 2026-27 et ont pris son genre, sauf une :

| Page | Le Ronéosaure dit | Sorte | Carte |
|---|---|---|---|
| 3 | polysaccharides « (ex : glucose, amidon, glycogène) » | prise de notes ; le ronéo 2026-27 ne le dit plus (« ex/ polymère de glucose », p. 3) | `glu-qc-classification` (B), sans ATTENTION |

Changements de genre au passage : le foie « seul », l'aspartame, les farines et la
cuisson restent « le cours lui-même » ; l'« augmentation du nombre de gènes » et
« l'hypocholestérolémie » restent des prises de notes ; le lait « 2 fois », la
Micronésie et le dextrose restent douteux. La « fermentation lactique » (dite sans
ATTENTION en 2025-26), la lactase « notamment dans les régions européennes » (ambiguë
en 2025-26, fausse en 2026-27), le fructose « disaccharide » et la lignine sont relevés
pour la première fois, comme, à la relecture du 11/10, le nitrite « cancérigène reconnu
par l'OMS », le rose « colorant » et le sucre de la ratatouille attribué à l'amidon de
maïs.

## La relecture du 11/10/2026

Un second passage a relu chaque carte nouvelle ou changée contre sa page du ronéo
2026-27, et chaque erreur contre les cours 2025-26, 2024-25 et 2023-24. Il a :

- porté sur `glu-qc-sucres-caches`, la carte de l'exemple du jambon, les deux erreurs
  du jambon qui n'avaient pas de carte (le nitrite, le rose « colorant »), et une
  troisième, le sucre de la ratatouille attribué à l'amidon de maïs (point douteux) ;
  la justification E ne donne plus pour sûr que le dextrose « conserve » le jambon ;
- corrigé la référence de la pomme de terre au cheddar (Henry et al., Eur J Clin Nutr
  2006, que la revue de Nayak date de 2005) ;
- précisé les années qui disent la même chose (la FC 2025-26 pour le fructose
  « disaccharide » et « l'hypocholestérolémie », le cours 2023-24 qui disait juste
  « l'hypercholestérolémie », les chiffres du lait que le cours 2024-25 ne donne pas) ;
- ajouté à `glu-qc-fodmaps` C que le sorbitol est aussi naturel (pomme, poire, fruits
  à noyau) ;
- porté l'`ATTENTION (cours)` de la cuisson aussi sur `glu-qc-cuisson-ordre` A (« le
  mieux : à la vapeur ou à l'eau »), la proposition en cause avec B : à l'examen vrai,
  et la référence (Nayak, Berrios et Tang, 2014) ;
- dit dans `glu-fa-ration` que 400 g de glucides et 1 225 à 1 500 kcal ne se recoupent
  pas tout à fait (400 g × 4 kcal/g ≈ 1 600 kcal) : deux ordres de grandeur du cours, à
  retenir tels quels — ce n'est pas une erreur de la ronéo, les années précédentes
  disaient les mêmes chiffres.

Revérifiés sans changement : les pages citées de la FC 2025-26 et des cours 2024-25 et
2023-24 pour chaque erreur ; la clé imprimée de 2017/2018 S1 Q.8 (BMCP 1) ; les
références (Porter 1978 : 74 contre 47 g/L ; cahier des charges INAO LA 05/14 pour les
types de farine ; Vily-Petit et al., médecine/sciences 2025 ; Gerich 2001 ; Henry et al.
2006, repris par Nayak et al. 2014) ; la planche de l'insuline contre sa figure ;
l'étymologie de « microbiote » (Wiktionnaire, « biote » : du grec βίοτος).

## Absent du cours 2026-27

**Aucune carte.** Le ronéo du 30/09/2026 reprend tout le plan de la FC n°7 2025-26, et
chaque carte y retrouve sa notion centrale ; ce que seule la FC 2025-26 disait est dit
dans la carte, avec sa page. `ABSENTS_2026` est vide.

## En attente des ronéos suivantes

**Rien.** Le ronéo « Métabolisme glucidique » n'est pas numéroté et couvre tout le
cours d'une heure du 30/09/2026, jusqu'à sa conclusion (l'organisation du repas, p. 12) ;
aucune carte du chapitre ne vise une partie du cours qui resterait à paraître.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2023/2024 S1 QROC 3, 1), 2) et 3) | aucune (« Pas de corrections officielles ») | versos déduits du ronéo 2026-27 (p. 4-12), `officielle=False` | la table ne donne rien ; chaque explication le dit |
| 2024/2025 S1 Q. 19 | aucune (sujet sans corrigé) | **AC**, déduite, `officielle=False` | A, 50 à 60 % de la ration (p. 4) ; B fausse, le glucose est le représentant majeur (p. 2) ; C, l'amidon, polysaccharide, domine (p. 4, 6) ; D fausse, l'amidon est la réserve des végétaux, le glycogène celle des animaux (p. 3) ; E fausse, c'est le glycogène alimentaire qui est négligeable (p. 6). La 2022/2023 Q.17, propositions retournées |

Aucun conflit déclaré (`CONFLITS = []`) : il n'y a pas de clé imprimée à contredire.

## Questions pour Vincent

- (11/10) Le foie, « seul » organe qui libère du glucose (ronéo p. 3). La carte `glu-rv-foie-muscle` répond comme le professeur (« À l'examen : le foie, seul ») et donne la référence. Mais le chapitre « Métabolisme cellulaire » retient FAUX sur les deux annales qui posent « le seul » (2017/2018 S1 Q.8, clé imprimée vrai ; 2020/2021 S1 Q.8, sans clé). Faut-il harmoniser, et dans quel sens ?
- (11/10) La cuisson des pommes de terre (p. 12, propositions A et B), les farines T45/T65 (p. 9) et l'aspartame à 350 (p. 6) : quatre années de ronéos disent la même chose. Les cartes répondent comme le professeur et donnent la référence. D'accord ?
- (11/10) La lactase « notamment dans les régions européennes » (p. 7) est traitée comme une prise de notes, parce que les cours 2024-25 et 2023-24 disaient l'inverse. Si le Pr Huin l'a vraiment dit cette année, ce serait « le cours lui-même » : à confirmer avec quelqu'un qui était au cours.

1. **Le foie, « seul » organe qui libère du glucose** (p. 3) : la carte répond comme
   le professeur (« À l'examen : le foie, seul »), avec la référence ; mais le chapitre
   « Métabolisme cellulaire » retient **faux** sur les deux annales qui posent « le
   seul » (2017/2018 S1 Q.8, clé imprimée vrai ; 2020/2021 S1 Q.8, sans clé). Faut-il
   harmoniser — et dans quel sens ?
2. **La cuisson des pommes de terre** (p. 12), **les farines** (p. 9), **l'aspartame**
   (p. 6) : quatre années de ronéos disent la même chose ; les cartes répondent comme
   le professeur et donnent la référence. D'accord ?
3. **La lactase « notamment dans les régions européennes »** (p. 7) est traitée comme
   une prise de notes, parce que les trois années précédentes disent l'inverse. Si le
   professeur l'a vraiment dit cette année, ce serait « le cours lui-même ».

## Le lexique

Onze termes accueillis ici ; pages mesurées dans le texte du ronéo 2026-27
(`chercher_pages.py`), page de garde et plan exclus :

| Terme | Pages 2026-27 |
|---|---|
| Ose | 2, 3 |
| Disaccharide | 2, 3, 5, 8 (p. 3 et 5 : « disaccarides ») |
| Polysaccharide | 2, 3, 5, 6 |
| Amidon | 3, 4, 5, 6, 10, 11 |
| Glycoconjugué | 2 |
| Saccharose | 3, 4, 5, 6, 10 |
| Lactase | 5, 7 |
| Fermentation | 7, 8 |
| Glycogénolyse | 4 |
| Index glycémique | 9, 10, 11, 12 (« indice glycémique » p. 11-12) |
| **Microbiote** (nouveau) | 8, 9 |

**Microbiote** n'est accueilli par aucun autre chapitre (le ronéo de métabolisme
glucidique est le seul ronéo BMCP qui l'emploie, et aucune annale ne le nomme) : grec
μικρός + βίοτος, par biote, « petit + vie ». Sa racine `micr(o)-` est déjà dans la
table et cite la FC de sémantique 2/2, p. 6 ; la racine `-biote` (βίοτος, distincte de
`bi(o)-`, βίος) et le terme sont proposés, avec leurs sources (Wiktionnaire, Bailly),
dans le brouillon `etym/bmcp_glucides.json`. Le texte du lexique est déjà écrit dans la
forme que produirait `appliquer_etymologies.py`.

## À relire

Aucune carte `a-relire` : chaque carte de cours cite sa page du ronéo 2026-27, les
trois versos d'annales sont déduits de pages citées et le disent, comme la clé de la Q. 19
de 2024/2025.

## Intégration

- Aucun thème nouveau : rien à ajouter à `THEME_LABELS`.
- Les étymologies proposées (`-biote`, `lex-microbiote`) sont à verser dans
  `.claude/skills/nouveau-chapitre/scripts/etymologies.json`.
- Les erreurs ci-dessus sont à verser dans `contenu/ERRATA_RONEOS_2026-27.md`
  (section BMCP, « Métabolisme glucidique — Pr Huin, 30/09 »).

## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier (BMCP) ou du 6 janvier (SSH, papier). Sous les annales, 12 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 2 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `apports-glucidiques` | 7 | 1 | 2 |
| `index-glycemique` | 5 | 1 | 2 |

**Le schéma** `ech-glucides`, « Les glucides de l'assiette · ration et index glycémique », donne 16 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_GLUCIDES`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

## Régénérer

```
..\..\..\app\.venv\Scripts\python.exe generer.py
```

`generer.py` est la copie exacte du modèle du skill. Pour refaire une planche après
avoir touché ses rectangles (`efface` dans `PLANCHES`), depuis `app/` :
`uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/bmcp_glucides <glu-pl-opposition | glu-pl-insuline> --apercus <brouillon>`.
