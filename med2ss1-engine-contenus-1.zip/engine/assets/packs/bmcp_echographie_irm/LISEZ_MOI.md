# Échographie et IRM — paquet BMCP

80 notes, 168 cartes. Chapitre `chap-ue-bmcp-fc18` de l'UE BMCP, ordre 19.
Cours du **Pr Huglo, le 08/12/2025, de 9 h à 10 h**, dans le **Ronéosaure
2025-26** (FC n°19, 16 pages) ; les annales de trois polycopiés du Ronéosaure
2024-25 (BMCP 18, BMCP 21, BMCP 16) et les trois QCM de 2024/2025 que le ronéo
recopie p. 15, avec la correction des rédacteurs — dix sessions. Ces trois
questions citent depuis le 15/10/2026 le **sujet de 2024/2025 S1** (examen du
09/01/2025, sans corrigé), d'où elles viennent. Examen : mardi 5 janvier 2027.

**Fiche provisoire** (C16, décision de Vincent du 02/10) : le cours 2026-27
n'est pas encore paru. Chaque carte de cours cite la FC 2025-26 à sa page et
porte le badge « Cours 2025-26 » ; le ronéo 2026-27 la corrigera quand il
sortira. Aucune carte n'est « Absent du cours 2026-27 ».

Le dossier avait été commencé par une passe interrompue le 03/10 : `schemas.py`
et les 33 PNG de `media/` étaient là, sans `donnees.py` ni `annales.py`. Tout a
été relu comme un travail neuf — chaque figure sur sa page, le schéma rendu et
ses huit zones vérifiées — et gardé ; le reste est écrit ici.

Relu ensuite carte par carte contre les pages du PDF et ses diapositives, les
clés contre les tables de BMCP 16, 18 et 21 (05/10). Ce que la relecture a
changé :
- la planche, recomposée en cinq numéros au lieu de sept, et le reste de
  l'astérisque du « T2* » effacé ;
- un point douteux de plus, la pente du flux en échographie de contraste ;
- trois formulations resserrées sur la diapositive : la sélection de coupe,
  les agents superparamagnétiques et la cadence de l'échographie.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 36 | 36 |
| Texte à trous | 15 | 96 |
| QROC | 11 | 11 |
| Recto-verso | 7 | 7 |
| Lexique | 9 | 9 |
| Schéma cliquable | 1 | 8 |
| Planche à légender | 1 | 1 |

Dont **16 annales** (QCM) sur 10 sessions, de 2015/2016 S2 à 2024/2025 S1.

Sept thèmes, dans l'ordre du cours, tous nouveaux ; leurs libellés sont dans `THEME_LABELS` (`app/src/med_engine/application/scopes.py`) depuis l'intégration du 05/10 :

| Clé | Libellé | Notes |
|---|---|---|
| `echographie-modes` | Échographie : modes et sondes | 10 |
| `echogenicite` | Échogénicité et artefacts | 12 |
| `contraste-echo` | Doppler et contraste échographique | 5 |
| `rmn` | Phénomène de RMN : précession, résonance, relaxation | 15 |
| `temps-relaxation` | Temps de relaxation longitudinal et transversal | 13 |
| `sequences-irm` | Localisation spatiale et séquences | 10 |
| `examen-irm` | L'examen IRM et ses contre-indications | 6 |

Le plan C16 proposait `t1-t2` (« T1, T2 et T2* ») : une clé chiffrée n'est pas
un thème (`scopes.is_theme`), et un libellé ne porte pas de chiffre. Elle
devient `temps-relaxation`. `bmcp_contrastes_irm`, écrit en parallèle, n'a pas
pris de thème pour T1 et T2 : il range sa relaxation sous `rmn`. `rmn` et
`examen-irm` y portent exactement les mêmes libellés qu'ici ; `temps-relaxation`
n'est employé que dans ce chapitre.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-bmcp-eci-2526` — Ronéosaure, « FC n°19 - Echographie et IRM » (16 p.) | 2025-26 | le cours ; `SRC["fiche"]` et ses 32 figures ; la correction des rédacteurs des trois QCM de 2024/2025 (p. 15), citée dans leurs explications |
| `src-sujets-bmcp-2425` — « Sujets de BMCP 2024/2025, session 1 » (examen du 09/01/2025, 30 p.) | 2024-25 | la session 2024/2025 S1 (Q.25 à 27) ; sujet sans corrigé ; déclarée à l'identique dans tous les chapitres de BMCP qui en tirent une question |
| `src-annales-bmcp-18-echographie-et-irm` — « BMCP 18 - Échographie et IRM » | 2024-25 | table p. 4 ; source par défaut : 7 cartes (2023/2024 S1, 2022/2023 S1, 2019/2020 S1, 2018/2019 S1) ; 2 autres de nos questions y sont aussi, citées à BMCP 21 |
| `src-annales-bmcp-21-contrastes-en-irm` — « BMCP 21 - Contrastes en IRM » | 2024-25 | 5 cartes : sessions 2021/2022 S1, 2018/2019 S2, 2017/2018 S1, 2015/2016 S2 ; table p. 10-11 |
| `src-annales-bmcp-16-medecine-nucleaire` — « BMCP 16 - Médecine nucléaire » | 2024-25 | 2023/2024 S2 Q.13 et l'image du cas ; table p. 7 |

Les trois polycopiés sont déclarés avec les seuls champs que fixe la consigne
de C16 (`id`, `kind`, `titre`, `chemin_relatif`, `auteur`), pour que les
chapitres d'imagerie écrits en parallèle les déclarent à l'identique. Les pages
citées sont celles du PDF : le ronéo imprime « n/13 » avec une page de décalage
(p. 15 du PDF = « 14/13 »).

Lus en appoint, sans être déclarés : les cours 2024-25 (FC n°18) et 2023-24
(n°18) du même professeur, pour vérifier qu'une formule du ronéo 2025-26 vient
du cours (« 4 images/sec », « en l'augmentant », les antennes et B0) ; la FC 20
(p. 9, 11), citée dans quelques justifications ; l'errata
des cours 2025-26 et celui des annales, qui ne disent rien de ce cours ni de
ces trois polycopiés. Sources sûres nommées dans les cartes : les
recommandations EFSUMB sur les produits de contraste échographiques
(intravasculaires, non néphrotoxiques).

Les en-têtes des ronéos, des polycopiés et des erratas portent des noms
d'étudiants : aucun n'est repris.

## Ce que le cours a dicté

- **Le rouge** (mots clés : sondes, renforcement postérieur, volume sanguin,
  ω0 = γB0, Mz, voxel, TE = 2τ, aimants…) a ses cartes ; **le gris** se carte
  comme le reste (décision du 25/09), sauf ce que le professeur a dit de
  laisser. Il est passé vite sur l'effet miroir (une QROC, une zone, une
  proposition) ; « pas à retenir, juste pour illustrer » (p. 4) introduit les
  trois artéfacts de distance, cartés quand même, car les annales de 2024/2025
  les interrogent (Q.25 E) ; « si vous ne comprenez pas c'est normal » (p. 11) :
  la localisation spatiale tient en un QCM, un texte à trous, une QROC et un
  recto-verso ;
  les « autres séquences » de la fin, passées très vite (p. 12-13 : TSE, STIR,
  FLAIR, ARM, BOLD), sont à `bmcp_contrastes_irm` (FC 22) et ne sont pas
  cartées ici.
- **Les courbes J(ν) et le temps de corrélation** (p. 9), jamais interrogés :
  une seule carte, `eci-rv-eau-macromolecules`.
- **Ce qui n'est pas carté ici** (plan C16, § 0.7) : la place de chaque
  technique, la sémiologie et le gadolinium en clinique (`bmcp_bases_imagerie`,
  FC 20) ; reconnaître T1, T2, FLAIR, TOF, diffusion, perfusion (FC 22). Les
  cartes les citent.

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| Les trois étapes et leur ordre : précession (B0), résonance (B1), relaxation | 2023/2024 S1 Q.25, 2019/2020 S1 Q.25, 2018/2019 S1 Q.25, 2024/2025 Q.26 |
| T1, T2, T2* : leurs noms, leur ordre de grandeur | 2022/2023 S1 Q.26, 2019/2020 S1 Q.26, 2017/2018 S1 Q.25, 2015/2016 S2 Q.27, 2024/2025 Q.27 |
| Échographie : fréquence et profondeur, cône d'ombre, Doppler, microbulles | 2018/2019 S1 Q.24, 2022/2023 S1 Q.25, 2024/2025 Q.25, 2023/2024 S2 Q.13 |
| L'examen : non irradiant, coupes, contre-indications, bruit, durée | 2021/2022 S1 Q.22 et Q.25, 2018/2019 S2 Q.26 |

**Les copies, une seule carte chacune** : BMCP 21 recopie de BMCP 18 les
2023/2024 S1 Q.25, 2022/2023 S1 Q.26, 2021/2022 S1 Q.22, 2019/2020 S1 Q.26,
2018/2019 S1 Q.25 et 2017/2018 S1 Q.25 ; l'explication de chaque carte nomme
l'autre polycopié. Les sessions 2021/2022 S1 et 2017/2018 S1 sont cartées sur
le texte de BMCP 21 (une source par session : il est seul à porter la Q.25 de
2021/2022, et seul à imprimer entière la proposition E de 2017/2018).

**Ce que ce chapitre laisse aux autres** : BMCP 18 2023/2024 S1 Q.30
(`bmcp_bases_imagerie`) et 2022/2023 S2 Q.28 (`bmcp_contrastes_irm`) ; les QROC
1 à 4 de 2023/2024 S2 de BMCP 21 (`bmcp_contrastes_irm`, même si la QROC 3 —
les trois étapes — et la QROC 4 — les contre-indications — parlent de ce
cours) ; BMCP 16 2023/2024 S2 Q.12 (`bmcp_bases_physiques`). Les Q.14 et Q.15
de 2023/2024 S2, annoncées par « Questions 12 à 15 : données communes », ne
sont imprimées nulle part : rien à carter.

L'image du cas de l'enfant de 8 ans (BMCP 16, p. 3) se montre **avant** la
question 2023/2024 S2 Q.13 (`illustration_question`) : la lire est la question.
C'est une imagerie médicale, non une photographie de patient.

## Les erreurs du ronéo 2025-26

Le Ronéosaure n'est pas le ronéo de l'année : chaque erreur est portée par un
**ATTENTION nu** dans la carte qui tient la notion, la sorte dite dans le texte,
et rien n'entre dans `contenu/ERRATA_RONEOS_2026-27.md`. Aucune n'est dans
l'errata de la promo 2025-26.

| Page | Le ronéo dit | Retenu | Sorte | Carte |
|---|---|---|---|---|
| 10 | « le gadolinium joue un rôle sur le temps de relaxation T1 en l'augmentant » (en rouge ; même phrase en 2024-25) | il **raccourcit** le T1 : la diapositive de la même page dit « accroissement de la vitesse de relaxation », T1 de 500 à 333 ms dans son exemple ; d'où l'hypersignal T1 (FC 20, p. 11) ; le cours 2023-24 disait « interviennent plus sur le T1 » | prise de notes | `eci-qc-gadolinium` C |
| 9 | « T2 … c'est le passage de l'état antiparallèle des protons à l'état parallèle » | c'est le T1 ; le T2 est le déphasage des spins entre eux (p. 8) | prise de notes | `eci-qc-t1-t2-tissus` |
| 9 | « T1 est inversement proportionnel à la fréquence de Larmor », « T2 … à la fréquence proche de l'origine » | à J(ν0) et à J(0), la densité spectrale des chocs à ces fréquences (diapositive) | prise de notes | `eci-qc-t1-t2-tissus` |
| 13 | « les antennes RF permettent de créer le champ B0 » (même phrase en 2024-25) | B1 ; B0 vient de l'aimant | prise de notes | `eci-qc-appareil` B, `eci-fa-appareil` |
| 5 | « très bonne résolution temporelle (4 images/sec) » (déjà dans les ronéos 2023-24 et 2024-25) | un examen en temps réel suppose plusieurs dizaines d'images par seconde ; le chiffre n'est pas carté | point douteux | `eci-qc-interets-echo` A |
| 5 | importance du flux : « pente à partir du pic » (« par la pente du pic » en 2023-24) | la diapositive DCE-US de la même page : flux = « pente max de rehaussement », la montée de la courbe ; le temps moyen de transit = « largeur à mi-hauteur » | point douteux | `eci-qc-contraste` D |

Dit autrement dans la carte, sans ATTENTION : B0 qui « devient homogène qu'au
milieu » sous le gradient (p. 11) — le gradient fait varier le champ partout,
et seule la coupe où il vaut encore B0 résonne à la fréquence ν0 de l'onde B1,
ce que montre la diapositive (`eci-qc-localisation` C).

Sans carte, parce qu'aucune n'en dépend : B0 « 10 000x le champ magnétique
terrestre » (p. 6 ; à 1,5 T, c'est plutôt 30 000 fois les 50 µT terrestres) ;
le balayage du mode B jadis « avec plusieurs émetteurs », aujourd'hui « avec un
seul détecteur » (p. 2, formulation qui semble inversée : la sonde électronique
est une barrette de nombreux éléments ; seul « électronique, donc plus rapide »
est carté).

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2024/2025 Q.25 | A, B (« VRAI? »), E vraies — correction des rédacteurs | ABE, `officielle=False` | aucune table officielle : « clé déduite du cours » ; le cours confirme B |
| 2024/2025 Q.26 | AC (D cotée FAUX) | **ACD**, `officielle=False`, CONFLITS | la diapositive de la p. 7 : « le moment magnétique résultant reste de module identique et s'inscrit donc sur la surface d'une sphère » ; le ronéo : M « garde la même distance » |
| 2024/2025 Q.27 | ABE (E cotée VRAI) | **AB**, `officielle=False`, CONFLITS | le cours ne connaît que le T2* (p. 8), dû aux hétérogénéités, qui ne touchent pas la relaxation longitudinale ; point douteux (voir les questions) |

Toutes les autres clés sont celles des tables, reprises telles quelles. Deux
anomalies d'impression, sans conflit : le premier bloc de BMCP 18 est étiqueté
« 2022/2023, session 1 » alors que sa table le range en 2023/2024 S1 (comme
BMCP 21) ; la table de BMCP 21 laisse vide la ligne de 2022/2023 S1 Q.26, dont
BMCP 18 donne la clé BD. Coquilles gardées telles qu'imprimées : « temps de
relation spin-réseau » (2024/2025 Q.27 D), « spinéch » (2015/2016 S2 Q.27 E),
« de type « sectorielle » sans guillemet fermant (2023/2024 S2 Q.13 E), la
proposition E de 2024/2025 Q.25 coupée après « à l'origine » — dans le sujet
lui-même, relu le 15/10/2026 (cahier de QCM, p. 10), et non par le ronéo qui
le recopie.

**Les trois QCM de 2024/2025 relus sur le sujet** (annales du 15/10/2026) :
énoncés et propositions identiques à ceux des cartes, mot pour mot (le sujet
écrit B₀, B₁ en indices) ; ids et clés inchangés. La session cite désormais le
sujet (`SRC["sessions"]["2024/2025 S1"]`), et non plus la FC, qui n'en était
que la copie ; les explications disent toujours d'où viennent les clés.

## Questions pour Vincent

1. **2024/2025 Q.27 E, « il existe un T1* »** — la carte suit la proposition du
   plan : FAUX, car le cours ne connaît que le T2*. Mais un T1* existe en IRM
   avancée : le T1 apparent, plus court, des séquences de Look-Locker (MOLLI,
   cartographie T1 du myocarde), hors du programme. Si la correction des
   rédacteurs venait du professeur, la clé serait ABE. Garder AB ?
2. **2024/2025 Q.26 D** — la carte suit la diapositive (VRAI : le module de M
   reste constant pendant B1) contre la correction des rédacteurs (FAUX). À
   confirmer si un corrigé officiel de 2024/2025 circule (le sujet déposé le
   15/10/2026 n'en a pas).

## Les schémas et les figures

**32 figures de la FC 2025-26**, extraites en PNG (captures de diapositives,
réduites à 1000 px de large au plus, en 256 couleurs ou en niveaux de gris ;
la courbe de relaxation à sa taille native) : les trois modes (p. 2), les
sondes, les échos de répétition, la différence de célérités (p. 3),
l'amplification, le cône d'ombre et le renforcement, l'image en miroir (p. 4),
l'échographie de contraste, la courbe DCE-US, les intérêts et limites, les
protons au hasard (p. 5), les deux niveaux, la fréquence de Larmor, Boltzmann
(p. 6), la résonance, la bascule, la FID (p. 7), les courbes de relaxation
(p. 8), la densité spectrale et le tableau des tissus (p. 9), les produits de
contraste et le contraste entre deux tissus (p. 10), voxel, gradient de coupe,
paramètres de coupe, codage (p. 11), chronogramme et séquences (p. 12),
pondération et cage de Faraday (p. 13). Et l'image du cas de 2023/2024 S2
(BMCP 16, p. 3). Aucune photographie de patient.

**Un schéma cliquable** (`schemas.py`, avec sa version légendée en
correction) :

| Fichier | Ce qu'on clique | Pourquoi ce dessin |
|---|---|---|
| `echo-artefacts.svg` | dans quatre échographies redessinées, la sonde en haut : la calcification et son cône d'ombre, le kyste et son renforcement postérieur, les interfaces réelles et les échos de répétition, l'angiome et son image en miroir (8 zones) | les images des p. 3-4 ; on clique l'artéfact ou la structure qui le crée, et le piège de 2018/2019 S1 Q.24 B (un cône d'ombre derrière une structure anéchogène) se joue entre les vignettes A et B ; aucune légende sur le schéma nu |

**Une planche à légender** (`eci-pl-relaxation`, `scripts/planche_depuis_image.py`,
numéros de 32 px) : la diapositive de la p. 8, ses légendes, ses formules, ses
puces et la phrase du bas effacées, cinq numéros — « Après une impulsion π/2 »,
la repousse de Mz (T1, longitudinal, spin-réseau), la décroissance de Mxy (T2,
transversal, spin-spin), la courbe du T2 vrai, celle du T2* — et six intrus
qui inversent longitudinal et transversal, Mz et Mxy, ou inventent un T1*. Le
texte de chaque courbe (titre, équation, définition) porte un seul numéro :
deux numéros pour la même courbe se seraient échangés sans faute de
compréhension, et l'inversion vaut zéro. Les pastilles des numéros 4 et 5
coupent un court segment des deux courbes : la forme reste lisible.

**36 QCM sur 36 illustrés (100 %)**, 70 notes sur 80.

## Le lexique

Neuf termes, ceux du plan C16 ; aucun n'existait dans l'UE ni ailleurs
(vérifié contre les `lex-*` de tous les paquets). Pages mesurées dans le PDF de
la FC 2025-26 (`chercher_pages.py`), sommaire de la p. 1 exclu :

| Terme | Origine | Pages |
|---|---|---|
| Échogénicité | grec ēkhṓ + -genḗs | 3 |
| Anéchogène | grec an- + ēkhṓ + -genḗs | 3, 4 |
| Endocavitaire | grec éndon + latin cavitas | 3 |
| Précession | latin praecessio | 6, 7, 15 |
| Gyromagnétique | grec gûros + magnễtis líthos | 6 |
| Résonance | latin resonantia | 6, 7, 15 |
| Relaxation | latin relaxatio | 7, 8, 9, 10, 13, 15 |
| Paramagnétique | grec pará + magnễtis líthos | 10 |
| Claustrophobie | latin claustrum + grec phóbos (la FC dit « claustrophobes ») | 14 |

Racines enseignées par les FC de sémantique, qui les citent : `a-/an-` (1/2,
p. 3), `endo-` (1/2, p. 2), `-gène` (1/2, p. 6), `pré- (latin)` (2/2, p. 10),
`gyr(o)-` (2/2, p. 5), `para- (grec)`, `claustr-` et `-phobie` (2/2, p. 8).
Racines nouvelles proposées à la table commune (`etymologies.json`, par le
brouillon `etym/bmcp_echographie_irm.json`) : `cavitas (latin)`,
`cedere (latin)`, `gyr(o)-`, `magnét(o)-`, `sonare (latin)`, `laxare (latin)`,
`claustr-`, `-phobie`, et les neuf termes ; `écho- (grec)`, `-gène`, `a-/an-`,
`endo-`, `pré- (latin)`, `re- (latin)` et `para- (grec)` reprennent les clés
existantes. Les textes du lexique sont déjà écrits dans la forme que
`appliquer_etymologies.py` produirait.

## À relire

**Aucune carte `a-relire`** : chaque note cite une page de la FC 2025-26, la
diapositive qu'elle reproduit, ou une source sûre nommée. Reste à Vincent :

- les deux questions ci-dessus ;
- quand le ronéo 2026-27 paraîtra, relire chaque carte sur lui et retirer le
  badge « Cours 2025-26 » ;
- `copier_les_cours.py` avec le dossier `…/examen janvier` du Ronéosaure
  2025-26, hors du bac à sable, pour que la fiche s'ouvre dans l'application.

## Intégration (05/10)

- Les libellés de thèmes sont dans `THEME_LABELS`
  (`app/src/med_engine/application/scopes.py`), bloc « BMCP FC n°6 à 22 ».
- Les étymologies proposées (racines et termes) sont versées dans
  `.claude/skills/nouveau-chapitre/scripts/etymologies.json` ;
  `appliquer_etymologies.py` n'a rien réécrit, les textes du lexique étant
  déjà à sa forme.

## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier (BMCP) ou du 6 janvier (SSH, papier). Sous les annales, 39 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 8 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `echographie-modes` | 6 | 1 | 2 |
| `echogenicite` | 3 | 1 | 1 |
| `contraste-echo` | 4 | 1 | 1 |
| `rmn` | 9 | 1 | 4 |
| `temps-relaxation` | 9 | 2 | 5 |
| `sequences-irm` | 2 | 1 | 1 |
| `examen-irm` | 6 | 1 | 2 |

**Le schéma** `ech-echographie-irm`, « Échographie et IRM · ultrasons, signal RMN, relaxation, examen », donne 64 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_ECHOGRAPHIE_IRM`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Tag `edn`** (passage « pas à retenir ») : `eci-ech-s8`.

**Sans marche** :
- eci-an-2324s2-q13 A — reconnaître une échographie sur l'image de l'examen B, c'est lire l'image (la question est l'image) ; eci-ech-s4 (sonde sectorielle, image conique) et eci-ech-s5 (Doppler en couleurs) en donnent les indices. Lettre posée sur la case des sondes.
- eci-an-2223s1-q25 B — l'emploi des microbulles chez l'insuffisant rénal n'est pas dans le cours ; la carte de l'annale le justifie par les recommandations EFSUMB. Lettre posée sur la case des microbulles, sans marche.

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```
