# Récepteurs et signalisation cellulaire — paquet BMCP

87 notes, 149 cartes. Chapitre `chap-ue-bmcp-fc13` de l'UE BMCP, ordre 14. Cours
du **Pr S. Lancel, le 14/11/2025, de 10 h à 12 h**, dans le **Ronéosaure
2025-26** (FC n°14, 14 pages) ; les annales du polycopié BMCP 13 du Ronéosaure
2024-25 (12 sessions, de 2017/2018 à 2023/2024) et le sujet de 2024/2025, sans corrigé
(Q.9, Q.10, QROC 4). Examen : BMCP, mardi 5 janvier
2027.

**Fiche provisoire** (plan C16, décision de Vincent du 02/10) : le cours de
l'année 2026-27 n'est pas encore paru. Chaque carte de cours cite la FC 2025-26
à sa page et porte le badge « Cours 2025-26 » (tag `cours-2025-26`, lu dans
l'auteur de la source) ; le ronéo 2026-27 la corrigera quand il sortira.

Ce chapitre a été repris d'un brouillon laissé par une session interrompue le
03/10 : un `schemas.py` (le RCPG) et 23 figures extraites dans `media/`, sans
`donnees.py` ni `annales.py`. Chaque figure a été vérifiée sur sa page ; le
schéma du RCPG est gardé, corrigé (deux légendes qui se chevauchaient, β et γ
réunis en une zone « dimère βγ », une note de zone sortie du cours ramenée à
lui) ; 22 des 23 figures servent (celle du recrutement des neutrophiles, p. 13,
que le professeur montre sans la détailler, n'illustrait aucune carte : retirée
de `media/`) ; le reste est écrit ici.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 49 | 49 |
| Texte à trous | 11 | 58 |
| QROC | 8 | 8 |
| Recto-verso | 7 | 7 |
| Lexique | 10 | 10 |
| Schéma cliquable | 2 | 17 |

Dont **28 annales** sur 13 sessions : les 25 QCM du polycopié, et, du sujet de 2024/2025
(examen du 09/01/2025, sans corrigé, déposé le 15/10/2026), les Q.9 et Q.10 et le QROC 4
(un recto-verso) ; et 22 QCM de cours.

Sept thèmes, dans l'ordre du cours. `signalisation` existe déjà (« Cascade de
signalisation », chapitre de l'insuline) et son libellé dit vrai ici ; les six
autres clés sont nouvelles, et leurs libellés sont dans `THEME_LABELS` (`app/src/med_engine/application/scopes.py`) depuis l'intégration du 05/10 :

| Clé | Libellé | Notes (dont annales) |
|---|---|---|
| `communication-cellulaire` | Modes de communication et messagers | 9 (1) |
| `ionotropes` | Récepteurs ionotropes | 3 |
| `rcpg` | Récepteurs couplés aux protéines G | 26 (12) |
| `rtk` | Récepteurs à activité tyrosine kinase | 20 (11) |
| `signalisation` *(existante)* | Cascade de signalisation | 6 (3) |
| `integrines` | Intégrines et adhérence | 7 |
| `recepteurs-nucleaires` | Récepteurs nucléaires | 6 (1) |

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-bmcp-rsc-2526` — « FC n°14 - Récepteurs et signalisation cellulairepdf.pdf » (14 p.) | 2025-26 | le cours ; `SRC["fiche"]`, ses 22 figures ; chemin `BMCP/…` (nom NFC ; le disque l'écrit en NFD) |
| `src-annales-bmcp-13-signalisation-et-recepteurs` — « BMCP 13 - Signalisation et récepteurs » | 2024-25 | 12 sessions, 28 QCM, table p. 10 ; déclarée avec les seuls champs communs du plan C16 |
| `src-sujets-bmcp-2425` — « Sujets de BMCP 2024/2025, session 1 » (30 p.) | 2024-25 | le sujet de l'examen du 09/01/2025, **sans corrigé** (dépôt `Annales_15102026/`, 15/10/2026) : Q.9, Q.10 et QROC 4 ; `SRC["sessions"]["2024/2025 S1"]` ; déclaré à l'identique dans tous les chapitres de BMCP qui en cartent une question |

Lus en appoint, sans être déclarés : la FC n°13 2024-25 du même professeur
(« Récepteurs et signalisation cellulaire ») et le cours 2023-24 n°19
(« Communication cellulaire », Charonéo) — c'est ce dernier qui porte le domaine
PH, le PIP3, les STAT, les deux dimérisations et le trastuzumab anticorps
(p. 13-17) ; la FC n°11 (p. 6) et la FC n°12 (p. 3-4) 2025-26 pour la règle
-mab/-nib, le trastuzumab et PTEN ; l'errata des cours 2025-26 (une seule ligne
pour la FC 14, « image coupée p. 12 », déjà corrigée dans le PDF) et l'errata
des annales (une ligne : 2023/2024 Q1, « E est vraie »).

Les en-têtes des ronéos, des polycopiés et des erratas portent des noms
d'étudiants : aucun n'est repris.

## Ce que le cours a dicté

- **Le rouge** (dimérisation, tyrosine, trans-autophosphorylation, protéines
  adaptatrices, SH2, PTB, RAS, MAP kinases, PLC, IP3, DAG, interaction
  protéine-protéine, cascade de phosphorylation, internalisation, AP2,
  ubiquitinylation, AKT, mTOR, BAD, TKI, intégrines, protéines
  glycosylées, α et β, cations divalents, protéines d'ancrage, taline,
  α-actinine, I-CAM, cross-talk, convergence, cinétique, co-activateurs,
  co-répresseurs ; et la phrase de la p. 6 sur α-GTP et βγ) a chacun sa carte.
  Le suffixe « -ib ou -nib » des TKI, rouge lui aussi, est seulement cité
  (`rsc-fa-tki`) : la règle -mab / -nib est la part de `bmcp_senescence`
  (FC n°11, p. 6), d'après les frontières du plan C16.
- **Le gris où le professeur dit de laisser** n'a pas de carte : le tableau des
  médicaments des récepteurs muscariniques (p. 7), les associations α-β des
  intégrines une à une (p. 11), le détail de la diapédèse (p. 12), les
  facteurs de transcription et le NO (p. 14), le lapatinib et le trastuzumab
  (p. 10 — l'annale 2023/2024 Q.1 les carte pourtant). La figure montrée
  « pour illustrer » (les effets non génomiques, p. 14) illustre une
  correction, sans carte qui l'interroge ; celle du recrutement des
  neutrophiles (p. 12-13) n'est pas reprise.
- **Ce qui n'est pas carté ici** (plan C16) : le récepteur de l'insuline et sa
  voie (`bmcp_insuline`), la règle -mab / -nib et l'imatinib
  (`bmcp_senescence`), HER2 et les tests compagnons (`bmcp_tests_biologiques`).
  Les cartes les citent.

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| RCPG : voies dépendantes et indépendantes des protéines G | 2022/2023 S1 Q.1, S2 Q.6 ; 2021/2022 S1 Q.12, S2 Q.1 ; 2020/2021 S1 Q.18, S2 Q.21 ; 2019/2020 S1 Q.16 ; 2018/2019 S2 Q.16 ; 2017/2018 S1 Q.10, S2 Q.10 |
| Classification des protéines G par la sous-unité α ; Gs contre Gq | 2021/2022 S1 Q.12, S2 Q.1 ; 2020/2021 S1 Q.18, S2 Q.21 ; 2019/2020 S1 Q.16 ; 2017/2018 S1 Q.10, S2 Q.10 |
| Site du ligand selon la classe de RCPG | 2022/2023 S2 Q.6 ; 2020/2021 S2 Q.21 ; 2019/2020 S1 Q.16 ; 2018/2019 S2 Q.16 ; 2017/2018 S2 Q.10 |
| Spécificité : isoformes, AKAP | 2022/2023 S2 Q.7 ; 2018/2019 S1 Q.15 (mot pour mot) ; 2020/2021 S2 Q.21 ; 2019/2020 S1 Q.16 ; 2017/2018 S1 Q.10, S2 Q.10 |
| SH2, PTB, PH | 2022/2023 S1 Q.2, S2 Q.8 ; 2021/2022 S1 Q.13, S2 Q.2 ; 2020/2021 S1 Q.19, S2 Q.22 ; 2018/2019 S2 Q.17 ; 2017/2018 S2 Q.5, Q.11 |
| JAK2, récepteur de l'EPO, JAK2 V617F | 2022/2023 S1 Q.2, S2 Q.8 ; 2021/2022 S1 Q.13, S2 Q.2 ; 2020/2021 S1 Q.19, S2 Q.22 ; 2018/2019 S2 Q.17 |
| Convergence vers un même lot de gènes | 2021/2022 S2 Q.2 ; 2020/2021 S1 Q.19, S2 Q.22 ; 2017/2018 S1 Q.11 ; (ramification : 2021/2022 S1 Q.12) |
| PTEN, PI3K, STAT | 2021/2022 S1 Q.13 ; 2017/2018 S1 Q.11, S2 Q.5, Q.11 |
| Classes de récepteurs ; récepteurs nucléaires | 2023/2024 Q.1, Q.2 ; récepteurs stéroïdiens « d'emblée nucléaires » : 2022/2023 S2 Q.8, 2021/2022 S2 Q.2, 2020/2021 S1 Q.19 |
| Hypoxie, HIF, VHL | 2019/2020 S1 Q.17 |
| Premiers messagers : hormones, neurotransmetteurs, prostaglandines, ligands hydrophiles | 2024/2025 S1 Q.9 |
| RCPG : 800 gènes, protéine G trimérique active liée au GTP, adénylate cyclase ; le nicotinique ionotrope ; les étapes de la signalisation | 2024/2025 S1 Q.10 et QROC 4 |

**Les questions répétées** d'une session à l'autre ont chacune leur carte, et
l'explication renvoie aux autres. **Non cartées ici**, rangées par leur contenu
(plan C16) : 2019/2020 S2 Q.17 (régulation des CDK-cyclines,
`bmcp_cycle_cellulaire`), 2018/2019 S1 Q.16 (copie de BMCP 9,
`bmcp_cycle_cellulaire`), 2017/2018 S2 Q.6 (copie de BMCP 2, `bmcp_insuline`).
Les Q.1 et Q.2 de 2023/2024, recopiées dans BMCP 11, ont une seule carte
chacune, ici.

## Les erreurs du ronéo 2025-26

Le Ronéosaure n'est pas le ronéo de l'année : chaque erreur est portée par un
**ATTENTION nu** dans la carte qui tient la notion, la sorte dite dans le texte,
et rien n'entre dans `contenu/ERRATA_RONEOS_2026-27.md`.

| Page | Le ronéo dit | Retenu | Sorte | Carte |
|---|---|---|---|---|
| 3 | facteur de croissance « des cellules endothéliales : EGF » | VEGF (Vascular Endothelial Growth Factor, cours 2024-25 p. 15) ; l'EGF est épidermique | prise de notes | `rsc-qc-ligands` B |
| 4 | « Récepteur nicotinique et muscarinique à l'acétylcholine » parmi les ionotropes, « canal sodique » | seul le nicotinique est ionotrope ; le muscarinique est un RCPG (p. 7 ; cours 2023-24 p. 12) | prise de notes | `rsc-qc-ionotropes` D, `rsc-rv-nicotinique` |
| 4 | « sérotonine (5AT3) » | 5-HT3 | prise de notes | `rsc-fa-ionotropes` |
| 5 | « dans les années 1990, Fischer et Krebs montrent que l'AMPc active la PKA » | Fischer et Krebs : phosphorylation réversible (années 1950), Nobel 1992 ; la PKA découverte en 1968 (Walsh, Perkins, Krebs ; cours 2023-24 p. 8) | point douteux | `rsc-qc-historique` (explication) |
| 10 | inhibiteurs en « -ib ou -nib » : « le Lapatinib, Trastuzumab » | le trastuzumab est un anticorps (-mab) contre la partie extracellulaire de HER2 (FC n°12 p. 4, FC n°11 p. 6) | prise de notes | `rsc-fa-tki`, annale 2023/2024 Q.1 E |
| 12 | intégrines leucocytaires « regroupant la E-cadhérine ou […] V-CAM, I-CAM » | ce sont leurs ligands, des molécules d'adhérence (cours 2024-25 p. 17) | prise de notes | `rsc-qc-integrines-familles` D |

Sans ATTENTION, dites dans la carte comme des imprécisions : « connexions » pour
connexons (p. 3, `rsc-fa-modes`) ; « phosphoryler le glycogène » pour la
glycogène phosphorylase (p. 7, `rsc-fa-glucagon`) ; « l'intégrine qui lie les
chaînes α5 et β1 du récepteur à la fibronectine » (p. 11 : α5β1 est le
récepteur de la fibronectine, `rsc-fa-integrines`). Sans carte, parce que c'est
du gris que le professeur n'a pas traité : « le viagra qui est un récepteur du
NO » (p. 14) — le sildénafil inhibe la phosphodiestérase 5, il n'est pas un
récepteur.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2020/2021 S1 Q.18 | aucune (« pas de correction ») | DE, `officielle=False` | mot pour mot 2021/2022 S2 Q.1, clé DE |
| 2020/2021 S1 Q.19 | aucune (« pas de correction ») | DE, `officielle=False` | A, B, C, E cotées comme dans les autres sessions ; D (modifications post-traductionnelles des récepteurs nucléaires) justifiée sur la p. 14 et Anbalagan et al., Nucl Recept Signal 2012 |
| 2024/2025 S1 Q.9 | aucune (sujet sans corrigé) | **ABCDE**, `officielle=False` | tout est au cours : communication endocrine (p. 2), nature des hormones, ligands hydrophiles et récepteurs membranaires (p. 3), neurotransmetteurs et prostaglandines (p. 4) |
| 2024/2025 S1 Q.10 | aucune (sujet sans corrigé) | **CD**, `officielle=False` | A fausse, 800 gènes (p. 5) ; B fausse, protéine G trimérique (p. 5) ; C, Gαs et Gαi (p. 6) ; D, active liée au GTP (p. 5-6) ; E fausse, le nicotinique est ionotrope (p. 4), le muscarinique est un RCPG (p. 7) |
| 2024/2025 S1 QROC 4 | aucune (sujet sans corrigé) | verso déduit du cours | les étapes du RCPG : ligand, échange GDP-GTP, dissociation α-GTP / βγ, effecteurs et seconds messagers selon Gαs, Gαi, Gαq, PKA, arrêt par la GTPase, la phosphodiestérase et l'arrestine (p. 5-7) |

Deux points sont discutés dans la carte (`ATTENTION`, déclarés dans
`CONFLITS`), **sans changer la clé** :

| Question | Clé | Le point | À l'examen |
|---|---|---|---|
| 2023/2024 Q.1 E | CD (BMCP 13) | BMCP 11 imprime « CD(E) » et l'errata des annales dit « E est vraie ». **Rejeté** (plan C16) : le trastuzumab est un anticorps contre la partie extracellulaire de HER2 (FC n°12 2025-26 p. 4), pas contre l'activité kinase | faux |
| 2017/2018 S1 Q.10 A | ABCD | « 50 % des médicaments » ciblent les RCPG : le chiffre classique ; environ un tiers en 2017 (Hauser et al., Nat Rev Drug Discov 2017) | vrai, comme la clé |

**Lettres grecques perdues** à l'impression (le PDF lui-même ne les a pas) :
« sous-unité G » (2021/2022 S2 Q.1 E, 2020/2021 S2 Q.21 B) rétablie en « Gα »
d'après 2020/2021 S1 Q.18 E qui l'imprime ; « HIF1-HIF1 » (2019/2020 S1 Q.17 A)
rétabli en « HIF1α-HIF1β » ; « les chaines des protéines G trimériques »
(2017/2018 S2 Q.11 D) rétabli en « chaines βγ », seule lecture que la clé
admette (Touhara et al., J Biol Chem 1994). « seule la sous-unité des protéines
G » (2018/2019 S2 Q.16 B) reste tel quel : α comme γ, toutes deux ancrées par
une liaison covalente, rendent la proposition fausse, et la justification le
dit. Chaque restauration est signalée dans la justification de la proposition.

**Les propositions absentes du ronéo 2025-26**, reprises comme la clé et
justifiées sur le cours 2023-24 ou une source sûre nommée : JAK2, le récepteur
de l'EPO (Witthuhn et al., Cell 1993), JAK2 V617F (James et al., Nature 2005 ;
Kralovics et al., N Engl J Med 2005), le domaine PH et le PIP3 (cours 2023-24
p. 15 ; Touhara 1994 pour βγ), les STAT (cours 2023-24 p. 15), les AKAP (Wong
et Scott, Nat Rev Mol Cell Biol 2004), les isoformes d'adénylate cyclase
(Sadana et Dessauer, Neurosignals 2009), la découverte des protéines G sur le
mutant cyc⁻ de la lignée S49 (Ross et Gilman, J Biol Chem 1977), les voies
indépendantes des protéines G (Lefkowitz et Shenoy, Science 2005), le site du
ligand selon la classe (Lagerström et Schiöth, Nat Rev Drug Discov 2008), les
deux dimérisations (Lemmon et Schlessinger, Cell 2010), l'ancrage covalent de
α et γ (Wedegaertner et al., J Biol Chem 1995). **PTEN** n'est pas absent : il
est sur la figure de la p. 8 (voie de la PI3 kinase) et dans la FC n°12 2025-26
(p. 4).

## Les schémas et les figures

**22 figures de la FC 2025-26**, extraites en PNG (captures de diapositives, au
plus 1000 px de large), chacune déclarée avec sa page : communication (p. 2),
modes (p. 3), grands principes (p. 4), RCPG et sous-unités, voies des RCPG
(p. 6), hormones et tissus, glucagon (p. 7), activation d'un RTK, EGF-R (p. 8),
MAP kinases, voies des RTK (p. 9), diversité des RTK, TKI (p. 10), structure et
familles des intégrines (p. 11), conformation et signalisation bidirectionnelle
(p. 12), convergence, récepteur nucléaire et ses domaines (p. 13),
arbre des récepteurs nucléaires, effets génomiques (p. 14). Aucune photographie
de patient.

**Deux schémas cliquables** (`schemas.py`), chacun avec sa version légendée en
correction :

| Fichier | Ce qu'on clique | Pourquoi ce dessin |
|---|---|---|
| `rcpg-proteine-g.svg` | N-terminal, boucles extracellulaires, sept hélices, boucles intracellulaires, C-terminal, Gα, dimère βγ, adénylate cyclase, phospholipase C (9 zones) | le RCPG de la p. 5 et la figure de la p. 6 ; β et γ forment une seule zone, « le dimère βγ », comme le cours les nomme |
| `recepteur-nucleaire.svg` | région A/B (AF1), DBD, région charnière (NLS), LBD, hormone, élément de réponse, co-activateur, gène cible (8 zones) | en haut la carte des domaines de la figure de la p. 13 (positions 1, 183, 263, 302, 549, 595 à l'échelle) ; en bas la voie du résumé de la p. 14 : le récepteur attend dans le cytoplasme (estompé, tireté, sans zone), puis le complexe hormone-récepteur passe dans le noyau (translocation) ; plein, il n'est dessiné qu'une fois, d'un bloc, pour qu'un seul tracé passe sous chaque zone |

**Pourquoi un schéma cliquable plutôt que la planche à légender du plan**
(`rsc-pl-recepteur-nucleaire`) : la figure de la p. 13 est une capture floue,
dont les légendes (AF1, AF2, DBD, LBD, NLS) tiennent en quelques pixels, et qui
ne porte ni élément de réponse, ni co-activateur, ni noyau — ce que le plan
voulait faire légender. Le schéma redessiné porte tout cela, et la figure du
cours reste en illustration de deux corrections.

**48 QCM sur 49 illustrés (98 %)** — les 22 du cours, 26 des 27 annales —, 72
notes sur 87. Sans figure : l'annale de l'hypoxie (2019/2020 S1 Q.17), qu'aucun
cours n'illustre.

## Le lexique

Dix termes. Le plan C16 en proposait dix ; **deux étaient déjà pris** dans la
bibliothèque, par l'immunologie : `lex-heterodimere` (`immuno_thymus`) et
`lex-diapedese` (`immuno_reponse_t`). Un second terme du même identifiant
déplacerait la note d'un chapitre à l'autre chez les collègues ; ils sont donc
remplacés par **Trimérique** et **Transduction**, deux termes du cours que les
annales emploient (« protéines G trimériques », « voies de transduction », dix
fois). Pages mesurées dans le PDF de la FC 2025-26 (`chercher_pages.py`), la
page 1 (le plan) exclue :

| Terme | Origine | Pages |
|---|---|---|
| Endocrine | grec éndon + krínō | 2 |
| Paracrine | grec pará + krínō | 2 |
| Juxtacrine | latin juxta + grec krínō | 2 |
| Autocrine | grec autós + krínō | 3 |
| Ionotrope | grec ión + trópos | 2, 4 |
| Trimérique | grec tri- + méros | 4, 5, 6 |
| Transduction | latin transductio | 8 |
| Dimérisation | grec di- + méros | 8 |
| Ubiquitinylation | latin ubique (anglais ubiquitin, 1975) | 9 |
| Intégrine | latin integer (anglais integrin, 1986) | 2, 4, 11, 12, 13 |

Racines enseignées par la FC de sémantique, qui la citent : `endo-` (1/2, p. 2),
`-trope` (2/2, p. 4), `-mère` (2/2, p. 10), `trans- (latin)` (2/2, p. 11).
Racines existantes reprises sans page : `para- (grec)`, `aut(o)- (grec)`,
`tri-`, `di-`. **Racines nouvelles**, proposées à la table commune avec les dix
termes (`scratchpad/etym/bmcp_signalisation.json`, sans toucher à
`etymologies.json`) : `-crine`, `juxta (latin)`, `ion (grec)`, `ducere
(latin)`, `ubique (latin)`, `integer (latin)`. Les textes du lexique sont déjà
écrits dans la forme que `appliquer_etymologies.py` produirait.

## Questions pour Vincent

1. **L'annale de l'hypoxie** (2019/2020 S1 Q.17 : HIF, VHL, PHD, EPO, VEGF ;
   clé BDE) : aucun cours de 2023-24 à 2025-26 n'en parle. Le plan propose de
   la garder, justifiée sur des sources sûres (la voie du prix Nobel 2019) et
   marquée `a-relire` — c'est ce qui est fait. La garder, ou l'écarter ?
2. **2023/2024 Q.1 E** : l'errata des annales (et BMCP 11, « CD(E) ») donne le
   trastuzumab « ciblant l'activité kinase » vrai ; la carte retient CD, comme
   BMCP 13 et le plan. D'accord ?
3. **Le lexique** : Hétérodimère et Diapédèse, déjà dans les chapitres
   d'immunologie, remplacés par Trimérique et Transduction. D'accord, ou
   préfères-tu d'autres termes ?
4. **La planche du récepteur nucléaire** devenue un schéma cliquable (voir
   plus haut). D'accord ?

## Décisions prises en route

- **`EXAMENS` n'est pas déclaré** (plan C16) : la date du 5 janvier 2027 se
  règle dans l'application.
- **Une carte par session** pour les questions répétées ; l'explication
  renvoie aux autres.
- **Les deux schémas** sont des simplifications : la protéine G est dessinée à
  côté du récepteur, ses sous-unités séparées pour pouvoir les cliquer ; la
  carte des domaines est à l'échelle des positions de la figure, la voie du bas
  ne l'est pas.
- **Relecture contradictoire** (chaque carte contre sa page de la FC, chaque
  clé contre la table p. 10 du polycopié et les erratas, les figures et les
  zones rendues). Corrigé :
  - le schéma du récepteur nucléaire montrait l'hormone filant droit au
    récepteur du noyau, ce qui contredit le cours (« le récepteur se trouve
    dans le cytoplasme de base », p. 13) et la correction de trois annales
    (« d'emblée nucléaires », faux) ; le récepteur au repos est maintenant
    dessiné dans le cytoplasme, estompé et sans zone, avec la translocation ;
  - deux justifications illustraient « une déphosphorylation peut activer »
    par PTEN, qui éteint au contraire la voie AKT (et déphosphoryle un lipide) :
    l'exemple est désormais BAD, p. 10 (2022/2023 S2 Q.6 B, 2021/2022 S2 Q.1 C,
    et 2020/2021 S1 Q.18 C) ;
  - le texte à trous du glucagon donnait la réponse d'un trou (« RCPG »)
    dans sa première phrase ;
  - le trou « -ib » du texte des TKI, part de `bmcp_senescence`, est devenu du
    texte cité ;
  - une note de zone (« la région la plus variable ») ne citait aucune source :
    retirée.

## À relire

**Une carte `a-relire`** : `rsc-an-1920s1-q17` (l'hypoxie, hors des cours),
jusqu'à la réponse de Vincent. Toutes les autres citent une page de la FC
2025-26, une clé imprimée ou une source sûre nommée ; les clés du sujet de 2024/2025,
sans corrigé, sont déduites chacune sur une page de la FC. Reste aussi :

- quand le ronéo 2026-27 paraîtra, relire chaque carte sur lui et retirer le
  badge « Cours 2025-26 » ;
- `copier_les_cours.py` avec le dossier `…/examen janvier/BMCP` du Ronéosaure
  2025-26, hors du bac à sable, pour que la fiche s'ouvre dans l'application.

## Intégration (05/10)

- Les libellés de thèmes sont dans `THEME_LABELS`
  (`app/src/med_engine/application/scopes.py`), bloc « BMCP FC n°6 à 22 ».
- Les étymologies proposées (racines et termes) sont versées dans
  `.claude/skills/nouveau-chapitre/scripts/etymologies.json` ;
  `appliquer_etymologies.py` n'a rien réécrit, les textes du lexique étant
  déjà à sa forme.

## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier (BMCP) ou du 6 janvier (SSH, papier). Sous les annales, 30 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 7 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu ; les annales qui n'ont aucune lettre à poser (`rsc-an-1920s1-q17`) reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `communication-cellulaire` | 5 | 1 | 1 |
| `rcpg` | 12 | 2 | 12 |
| `rtk` | 7 | 2 | 11 |
| `signalisation` | 3 | 1 | 3 |
| `recepteurs-nucleaires` | 3 | 1 | 1 |

**Le schéma** `ech-signalisation`, « Récepteurs et signalisation · du messager à la réponse », donne 64 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_SIGNALISATION`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- rsc-an-1920s1-q17 A-E (hypoxie, HIF, VHL, PHD) : aucun cours disponible n'en parle (2023-24, 2024-25, 2025-26), la carte est a-relire ; ni lettre ni Simple ne sont possibles, le schéma ne pouvant rien dessiner de la voie HIF sans l'inventer : l'annale reçoit le schéma nu (qroc_schema).
- Voies indépendantes des protéines G (rsc-an-2223s1-q1 E, 2223s2-q6 E, 2122s1-q12 E, 2122s2-q1 D, 2021s1-q18 D, 2021s2-q21 D, 1920s1-q16 E, 1819s2-q16 D, 1718s1-q10 E, 1718s2-q10 E) : le ronéo 2025-26 ne présente l'arrestine que comme un frein (p. 6) ; la voie de l'arrestine n'est justifiée que par Lefkowitz et Shenoy (Science 2005).
- Isoformes d'adénylate cyclase (2223s2-q7 C, 1819s1-q15 C, 1920s1-q16 D, 1718s1-q10 D, 1819s2-q16 E) et isoformes d'AMPc (2223s2-q7 D, 1819s1-q15 D) : absentes du cours.
- AKAP, protéines d'ancrage de la PKA (2223s2-q7 E, 1819s1-q15 E, 2021s2-q21 E, 1718s2-q10 D) : absentes du cours (le ronéo ne parle de protéines d'ancrage que pour les intégrines).
- JAK2, récepteur de l'EPO, JAK2 V617F (2223s1-q2 D, 2223s2-q8 C D, 2122s1-q13 D, 2122s2-q2 B C, 2021s1-q19 B, 2021s2-q22 B D, 1819s2-q17 C D E) : absents du ronéo 2025-26, justifiés sur des sources extérieures.
- Domaine PH (2223s1-q2 E, 2223s2-q8 B, 2021s1-q19 A, 2021s2-q22 C, 1819s2-q17 B, 1718s2-q11 C D) : absent du ronéo 2025-26 (cours 2023-24 seulement, hors des sources du dossier).
- Découverte des protéines G sur un mutant de lymphome (2122s1-q12 B, 1819s2-q16 C) et ancrage membranaire des sous-unités (1819s2-q16 B) : absents du cours.
- rsc-an-1718s1-q10 A (50 % des médicaments) : le cours ne donne aucun chiffre (culture générale, p. 7) ; point douteux de la clé (CONFLITS).
- STAT (1718s1-q11 B, 1718s2-q11 A), modifications post-traductionnelles des récepteurs nucléaires (2021s1-q19 D), antihormones (1718s2-q11 E) : absents du ronéo 2025-26.
- rsc-an-2324s1-q1 E (trastuzumab) : « le prof ne s'y attarde pas » (p. 10), la justification vient de la FC n°12, hors des sources du dossier ; clé contestée (CONFLITS).
- rsc-an-1718s2-q5 C (PTEN suppresseur de tumeurs : la FC n°9 le range parmi les gatekeepers, p. 22, chapitre bmcp_cycle_cellulaire ; hors des sources de ce chapitre, lettre posée sur pip), D et E (GLUT3, GLUT4, captation musculaire du glucose, chapitre de l'insuline) : hors des sources du dossier.

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```
