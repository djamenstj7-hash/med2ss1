# Morts cellulaires — paquet BMCP

117 notes, 180 cartes. Chapitre `chap-ue-bmcp-fc10` de l'UE BMCP, ordre 10.
**Cours du 02/10/2026, de 8 h à 10 h, Pr P. Marchetti, en deux ronéos Ronéo &
Juliette 2026-27** : la partie 1 (8 h-9 h : introduction, apoptose, nécroptose) et la
partie 2 (9 h-10 h : l'autophagie). Réaligné sur elles le 11/10/2026 ; il était carté
depuis le 02/10 (C16) sur la FC n°10 du Ronéosaure 2025-26, qui n'est plus qu'un
appoint. Annales : 45 questions sur 18 sessions (polycopié BMCP 10 du Ronéosaure
2024-25, et la Q1 du sujet 2024/2025, sans corrigé). Examen : mardi 5 janvier 2027.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 69 | 69 |
| QRU | 1 | 1 |
| Texte à trous | 14 | 70 |
| QROC | 10 | 10 |
| Recto-verso | 8 | 8 |
| Schéma cliquable | 1 | 8 |
| Planche à légender | 2 | 2 |
| Lexique | 12 | 12 |

Dont **45 annales** sur 18 sessions : 43 QCM et le QROC 4 de 2023/2024 S1
(C. elegans, corrigé imprimé) du polycopié, et la Q1 du sujet de 2024/2025 (session 1,
examen du 09/01/2025, sans corrigé : clé déduite). Les 20 autres questions du polycopié portent sur la
sénescence : elles sont dans `bmcp_senescence`. **70 QCM sur 70 illustrés (100 %)**,
104 notes sur 117. **Aucune carte absente du cours 2026-27** ; une seule carte de
cours, `mce-qr-lc3`, n'est pas confirmée par le ronéo de l'année et garde le badge
« Cours 2025-26 ». **12 cartes portent un piège du ronéo** (thème « Pièges des
ronéos »).

Sept thèmes, dans l'ordre du cours, déjà dans `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) depuis le 05/10 ; le réalignement n'en
ajoute aucun :

| Clé | Libellé | Notes (dont annales) |
|---|---|---|
| `apoptose-necrose` | Apoptose et nécrose : définitions | 23 (11) |
| `apoptose-pathologies` | L'apoptose en physiologie et en pathologie | 14 (7) |
| `c-elegans` | C. elegans et gènes de l'apoptose | 7 (1) |
| `voie-mitochondriale` | La voie mitochondriale de l'apoptose et les caspases | 13 (6) |
| `therapeutiques-apoptose` | Moduler l'apoptose : annexine V, inhibiteurs, vénétoclax | 7 (0) |
| `necroptose` | Nécroptose et morts régulées | 14 (8) |
| `autophagie` | Autophagie | 27 (12) |

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-bmcp-mce-2627-1` — « Morts cellulaires (partie 1) » (12 p.), `BMCP/MORT CELLULAIRE 1.pdf` | **2026-27** | **partie 1**, 8 h-9 h : introduction et définitions (p. 2-3), l'apoptose — bases, membranes, rôles, tableau (p. 3-5), C. elegans et la famille Bcl-2 (p. 6-8), annexine V, inhibiteurs de caspases, vénétoclax (p. 8-9) ; la nécroptose (p. 10-12) ; `SRC["fiche"]`, ce que le lecteur ouvre ; 53 notes |
| `src-fc-bmcp-mce-2627-2` — « Morts cellulaires (partie 2) : l'autophagie » (6 p., la dernière vide), `BMCP/MORT CELLULAIRE 2.pdf` | **2026-27** | **partie 2**, 9 h-10 h : généralités, étapes, microscopie électronique (p. 2-3), mécanismes, stimulation (p. 3-4), rôles (p. 4-5), mort cellulaire et cancers (p. 5) ; `fiche=FC2` ; 18 notes |
| `src-fc-bmcp-mce-2526` — FC n°10, « Morts cellulaires » (18 p.) | 2025-26 | **appoint** (`SRC["cours"]`, sans `chapitre=`) : ce que les ronéos 2026-27 ne reprennent pas (LC3, les souriceaux ATG5, le tableau complet des types de mort, l'annexine après chimiothérapie, les thrombopénies), sept figures, et la source de la carte **LC3**, non confirmée par l'année |
| `src-annales-bmcp-10-…` — « BMCP 10 - Morts cellulaire, sénescence réplicative, thérapies ciblées » | 2024-25 | 17 sessions, table p. 18 ; déclarée sous la forme commune avec `bmcp_senescence` |
| `src-sujets-bmcp-2425` — « Sujets de BMCP 2024/2025, session 1 » (30 p.) | 2024-25 | le sujet de l'examen du 09/01/2025, **sans corrigé** (dépôt du 15/10/2026, `Annales_15102026/`) : sa Q1 ; `SRC["sessions"]["2024/2025 S1"]` ; déclaré à l'identique dans tous les chapitres de BMCP qui en cartent une question |
| tableau d'erreurs BMCP de la promo 2026-27 | 2026-27 | **aucun** au 11/10/2026 (`Ajouts/` n'en contient pas pour la BMCP) |

Les textes citent « partie 1, p. 7 », « partie 2, p. 3 » (ronéo 2026-27),
« FC 2025-26, p. 16 » ou « cours 2024-25, p. 8 ». Lus en appoint, sans être déclarés :
le cours 2024-25 (« Thérapies ciblées, morts cellulaires et sénescence », Pr
Marchetti), rédigé à part, qui tranche le genre de plusieurs erreurs ; le troisième
ronéo du 02/10/2026 (« Thérapie ciblée, mort cellulaire et sénescence cellulaire »),
tout entier sur la sénescence, qui réaligne `bmcp_senescence`. Les deux fiches de
l'année se copient dans le dossier des PDF de l'application par
`outils/copier_les_cours.py`, lancé avec le dossier des ronéos 2026-27
(`Ajouts/[NUMERIQUE] Ronéo & Juliette 26-27 11 10 2026/S1/CM`), hors du bac à sable.

Les en-têtes des ronéos nomment leurs rédacteurs et leurs correcteurs, le polycopié
d'annales son secrétaire : aucun nom n'est repris.

**La ronéo 2026-27 recopie la ronéo 2025-26.** Des paragraphes entiers sont
identiques mot pour mot (C. elegans, les homologies, les nécroses régulées, la
microscopie électronique). Une erreur redite d'une année à l'autre ne prouve donc pas
que le professeur l'a dite : le genre de chaque erreur se lit sur la diapositive et sur
le cours 2024-25, rédigé à part.

## Ce qui correspond à quoi

Les deux ronéos suivent tout le plan de la FC 2025-26 :

| FC 2025-26 | Ronéo 2026-27 |
|---|---|
| I. Introduction, définitions, hépatite fulminante (p. 2-3) | partie 1, p. 2-3 |
| II.A Bases : 1972, Wyllie, l'échelle ; membranes (p. 3-4) | partie 1, p. 3-4 |
| II.B Rôles physiopathologiques ; tableau des défauts et excès (p. 4-6) | partie 1, p. 4-5 |
| II.C C. elegans, homologies, mitochondrie, famille Bcl-2, BH3-only (p. 6-10) | partie 1, p. 6-8 |
| II.D Annexine V, inhibiteurs de caspases, vénétoclax (p. 10-12) | partie 1, p. 8-9 |
| III. Nécroptose : voies communes, 2008, pathologies, nécroses régulées, conclusion (p. 12-14) | partie 1, p. 10-12 |
| Le tableau des types de mort (p. 2 et 14) | sa ligne « autophagie » seule (partie 2, p. 2) |
| IV. Autophagie : étapes, ME, mécanismes, stimulation, rôles, mort, cancers (p. 14-18) | partie 2, p. 2-5 |
| V. Sénescence (p. 18) | le troisième ronéo, carté dans `bmcp_senescence` |
| — | **nouveau** : mort régulée et mort programmée (partie 1, p. 2) ; le gel à trois pistes (p. 3) ; l'intestin sculpté par l'apoptose (p. 4) ; « À bien retenir » (p. 5) ; EGL-1 sur la diapositive des homologies (p. 7) ; la voie TNF-TNFR1-nécrosome-MLKL (p. 10) ; la catalase, la mitophagie qui « empêche l'apoptose ? », le tableau de l'autophagie dans les cancers (partie 2, p. 4-5) |

## Le réalignement du 11/10/2026

Les 51 notes de cours de la version 2025-26 (hors lexique) ont été relues une à une
contre les deux ronéos.

**Relues et confirmées (50), qui citent désormais leur page de l'année** (et perdent le
badge « Cours 2025-26 ») :

| Partie | Notes |
|---|---|
| 1 (39) | `mce-fa-apoptose`, `mce-fa-necrose`, `mce-qc-apoptose-necrose`, `mce-qc-definition-fonctionnelle`, `mce-qc-types-de-mort`, `mce-rv-accidentelle-regulee` (p. 2) ; `mce-fa-echelle`, `mce-qc-signatures`, `mce-qr-kerr` (p. 3) ; `mce-qc-developpement`, `mce-qr-syndactylie` (p. 4) ; `mce-fa-tissus-adultes`, `mce-qc-tissus-adultes`, `mce-qc-defaut` (p. 5) ; `mce-fa-c-elegans`, `mce-qc-c-elegans` (p. 6) ; `mce-fa-voie-intrinseque`, `mce-qc-homologies`, `mce-qc-mitochondrie`, `mce-qr-apaf1`, `mce-qr-cytochrome-c`, `mce-rv-ced-homologues` (p. 7) ; `mce-qc-bh3`, `mce-qr-bax-bak`, `mce-rv-bh3-double-effet`, `mce-zo-voie-mitochondriale` (p. 8) ; `mce-fa-venetoclax`, `mce-qc-annexine`, `mce-qc-moduler`, `mce-qc-venetoclax`, `mce-qr-annexine`, `mce-qr-venetoclax`, `mce-rv-moduler` (p. 9) ; `mce-fa-necroptose`, `mce-qc-voies-communes` (p. 10) ; `mce-qc-necroptose`, `mce-qc-ferroptose` (p. 11) ; `mce-fa-morts-regulees` (p. 12) |
| 2 (11) | `mce-fa-autophagie-etapes`, `mce-qc-autophagie-etapes`, `mce-rv-tableau-morts`, `mce-pl-autophagie` (p. 2) ; `mce-fa-autophagie-induite`, `mce-qc-autophagie-mecanismes`, `mce-qc-autophagie-induction`, `mce-qr-levure`, `mce-qr-mitophagie`, `mce-rv-basale-induite` (p. 3) ; `mce-qc-autophagie-roles` (p. 4) ; `mce-rv-autophagie-mort` (p. 5) |

Dans ces cartes, chaque proposition, trou ou phrase que seul un cours précédent porte
le dit dans sa justification (« FC 2025-26, p. 16 ; le ronéo 2026-27 ne le nomme
pas ») : une carte n'est confirmée que si sa notion centrale est dans le cours de
l'année. Les dix termes du lexique citent désormais leurs pages 2026-27 d'abord.

**Ce que le ronéo 2026-27 dit autrement, et ce qui a été réécrit** :

- **Mort régulée et mort programmée** ne sont plus synonymes : une mort régulée passe
  par des ARN messagers et des protéines ; « programmée », c'est la mort régulée
  apoptotique du développement embryonnaire (partie 1, p. 2) — `mce-rv-accidentelle-regulee`
  le dit au verso, `mce-qc-regulee-programmee` le demande.
- **Les erreurs du Ronéosaure 2025-26 que l'année corrige** perdent leur ATTENTION :
  la sénescence est désormais « vieillissement cellulaire » (partie 1, p. 2 :
  `mce-qc-types-de-mort` E) ; la membrane plasmique n'est plus « double » (p. 4 :
  `mce-qc-signatures` E) ; ce sont les cellules mutées d'un coup de soleil qui meurent,
  non « des cellules de l'immunité » (p. 5 : `mce-qc-tissus-adultes`).
- **C. elegans** : le ronéo 2026-27 inverse la phrase « moins de 959 / plus de 959 »
  du ronéo 2025-26 (comme le proposait le tableau d'erreurs de la promo 2025-26) : il
  parle désormais de l'effet de la MUTATION (« le gène muté provoque l'apoptose »), ce
  qui est juste, là où 2025-26 parlait du rôle du gène avant mutation (« inhibait »).
  Ce n'est donc pas une erreur du ronéo. La carte garde le raisonnement sur le rôle du
  gène invalidé, celui des cours 2024-25 et 2025-26 et du QROC 4, et un ATTENTION nu
  (sans genre) dit que les deux années se lisent à l'envers (`mce-qc-c-elegans` C).
- **Les « plus de 30 ans »** de recherche deviennent « plus de 20 ans » (partie 1,
  p. 9) : l'explication de `mce-qc-venetoclax` cite les deux.
- **Les autres nécroses programmées** « ne sont pas vraiment à savoir mais avoir en
  tête qu'il y en a plusieurs » (partie 1, p. 11) : dit dans `mce-qc-ferroptose` et
  `mce-fa-morts-regulees`, qui restent.
- **Les figures** : partout où le ronéo de l'année a la même diapositive, sa figure
  remplace celle de 2025-26 (voir plus bas), et la planche de l'autophagie est refaite sur la figure de
  l'année (partie 2, p. 2), ses rectangles remesurés.

**Notes nouvelles (11)**, sur ce que le cours 2026-27 apporte :

| Note | Ce qu'elle carte |
|---|---|
| `mce-qc-regulee-programmee` | ARNm et protéines ; programmée = embryonnaire ; acide, coup de soleil intense ; l'apoptose type de la mort régulée ; « BON À SAVOIR » : l'autophagie parfois mort régulée (partie 1, p. 2 ; partie 2, p. 2) |
| `mce-qc-gel-adn` | le gel à trois pistes — ADN intact, en échelle, dégradé ; les endonucléases ; le nucléosome (partie 1, p. 3) |
| `mce-fa-sculpteur` | doigts, intestin, neurones, thymocytes : le « sculpteur général de l'embryon » (partie 1, p. 4) |
| `mce-fa-a-retenir` | « À bien retenir » : physiologique chez l'embryon, le fœtus et l'adulte ; anomalies quantitatives (partie 1, p. 5) |
| `mce-pl-homologies` | la diapositive des homologies, légendes effacées : EGL-1, Ced-9, Ced-4, Ced-3, famille de Bcl-2, BH3-only, Apaf-1, caspases (partie 1, p. 7) |
| `mce-qc-necrosome` | TNF et TNFR1 ; complexe II (caspase-8, FADD) vers l'apoptose ; nécrosome RIPK1-RIPK3 ; pore MLKL et DAMPs ; inhibiteurs en développement (partie 1, p. 10-11) |
| `mce-fa-autophagie-survie` | carence → acides gras, ATP, acides aminés ; « Retenir : Autophagie = survie cellulaire », en rouge (partie 2, p. 4-5) |
| `mce-qc-autophagie-mort` | vésicules autophagiques, excès (massif ou spécifique : la catalase), défaut d'autophagie complète, mitochondries perméables, la mitophagie qui pourrait empêcher l'apoptose (partie 2, p. 4-5) |
| `mce-qc-autophagie-cancers` | rôle ambivalent, suppresseur ou oncogénique ; le GNS561 de GENFIT, inhibiteur, sans efficacité prouvée (partie 2, p. 5) |
| `lex-phagophore`, `lex-pyroptose` | deux termes du lexique (voir plus bas) |

## Ce que le cours a dicté

- **Le rouge** des deux ronéos est celui des titres, et d'une consigne : « Retenir :
  Autophagie = survie cellulaire » (partie 2, p. 5) — `mce-fa-autophagie-survie`,
  `mce-qc-autophagie-roles`.
- **« À bien retenir »** (partie 1, p. 5) : `mce-fa-a-retenir`. **« BON À SAVOIR »**
  (partie 2, p. 2) : `mce-qc-regulee-programmee` E, `mce-qc-ferroptose` E.
- **Le gris** (un seul passage : « Cela a été démontré avec les endoenzymes
  antioxydants tels que les catalases », partie 2, p. 5) est la voix des rédacteurs
  (décision de Vincent du 25/09) et se carte : `mce-qc-autophagie-mort` B,
  `mce-rv-autophagie-mort`. Aucun ronéo ne définit son gris comme hors programme.
- **Ce que le professeur a dit de laisser** : les vingt gènes de l'autophagie « qu'on
  ne verra pas » (partie 2, p. 3) ; les autres nécroses programmées, « pas vraiment à
  savoir » (partie 1, p. 11). Les annales les demandent pourtant (Bécline 1, LC3,
  mTOR) : elles restent cartées en annales, sur la figure de la FC 2025-26 (p. 16) et
  sur des sources sûres.
- **La diapositive de la nécroptose** (partie 1, p. 10), que le texte ne commente pas
  (« de nouvelles protéines, comme les kinases », p. 11), répond enfin aux annales sur
  les kinases, le TNF-α et la caspase-8 : `mce-qc-necrosome`, et les justifications des
  huit annales de nécroptose.

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| L'autophagie : levure, LC3, mTOR, mitophagie, Bécline 1, souriceaux ATG5 | 12 : 2020/2021 S1 Q13, S2 Q15 ; 2019/2020 S1 Q11, S2 Q13 ; 2018/2019 S1 Q11, S2 Q11 ; 2017/2018 S2 Q18 et Q19 ; 2016/2017 S1 Q20, S2 Q20 ; 2015/2016 S1 Q17, S2 Q17 |
| La mort cellulaire, apoptose et nécrose | 11 : 2024/2025 S1 Q1 ; 2023/2024 S1 Q4 ; 2022/2023 S1 Q5, S2 Q1 ; 2021/2022 S1 Q8, S2 Q9 ; 2020/2021 S1 Q11 ; 2019/2020 S2 Q11 ; 2018/2019 S1 Q8 ; 2015/2016 S1 Q15, S2 Q15 |
| La nécroptose : régulée, kinases, phénotype de nécrose, TNF-α | 8 : 2020/2021 S2 Q14 ; 2019/2020 S1 Q10, S2 Q12 ; 2018/2019 S2 Q10 ; 2017/2018 S1 Q17, S2 Q17 ; 2016/2017 S1 Q19, S2 Q19 |
| Défaut ou excès d'apoptose : tout est dans le tableau (partie 1, p. 5) | 7 : 2020/2021 S2 Q13 ; 2019/2020 S1 Q9 ; 2018/2019 S2 Q9 ; 2017/2018 S1 Q15, S2 Q16 ; 2016/2017 S2 Q17 ; 2015/2016 S2 Q16 |
| Les caspases | 2 : 2020/2021 S1 Q12 ; 2018/2019 S1 Q9 |
| La famille Bcl-2 | 2 : 2016/2017 S1 Q18 ; 2015/2016 S1 Q16 |
| L'expérience Bcl-2 / IL-3 | 2 : 2017/2018 S1 Q16 ; 2016/2017 S2 Q18 |
| C. elegans : rôle et ordre des gènes ced | QROC 4 de 2023/2024 S1 |

**Relues le 11/10/2026 sur le cours de l'année** : chaque clé a été confrontée aux
deux ronéos 2026-27, proposition par proposition. Aucune ne contredit le cours de
l'année ; aucune clé n'a changé ; `CONFLITS` garde son unique entrée. Les
justifications citent désormais le ronéo 2026-27 là où il dit la même chose, la
FC 2025-26 ailleurs (LC3, souriceaux ATG5, mécanisme moléculaire, inhibition des
caspases qui fait basculer vers la nécrose).

**Les questions reposées mot pour mot** ont chacune leur carte, et l'explication
renvoie aux autres : 2022/2023 S2 Q1 = 2021/2022 S2 Q9 ; 2019/2020 S2 Q12 =
2019/2020 S1 Q10 ; 2017/2018 S2 Q17 = 2016/2017 S2 Q19 ; 2017/2018 S2 Q18 =
2015/2016 S2 Q17. **La copie d'un autre polycopié** n'est pas recartée :
2023/2024 S1 Q4, imprimée aussi dans BMCP 11 (même numéro, même clé), n'a qu'une
carte, ici.

**Les propositions absentes des cours 2023-24 à 2026-27** (DISC, caspases initiatrices
et effectrices dans le texte, IL-3, mTOR, AIF, domaine BH3 de la Bécline 1, LC3-GFP)
viennent sans doute des cours de 2015-2018 ; chaque justification le dit et cite sa
source : Vaux, Cory et Adams (Nature 1988) pour l'IL-3 ; Alnemri et al. (Cell 1996)
pour la coupure après un aspartate ; Kischkel et al. (EMBO J 1995) pour le DISC ; Susin
et al. (Nature 1999) pour l'AIF ; Pattingre et al. (Cell 2005) et Oberstein et al.
(J Biol Chem 2007) pour la Bécline 1 ; Kabeya et al. (EMBO J 2000) pour le LC3-GFP ;
Kuma et al. (Nature 2004) pour les souriceaux Atg5−/− ; Noda et Ohsumi (J Biol Chem
1998) pour mTOR ; Salvesen et Dixit (PNAS 1999) et Riedl et Shi (Nat Rev Mol Cell Biol
2004) pour les caspases initiatrices ; Sattler et al. (Science 1997) pour la poche
hydrophobe. Aucune ne reste sans source : pas de `a-relire`.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2020/2021 S2 Q15 (autophagie) | ACD | **ACDE**, `officielle=False`, conflit déclaré sur E | « les souriceaux ATG5−/− meurent précocement par inadaptation au stress métabolique » est cotée vraie en 2018/2019 S2 Q11, 2017/2018 S2 Q18 et 2015/2016 S2 Q17, et le cours le disait (FC 2025-26, p. 17 ; cours 2024-25, p. 20 ; Kuma et al., Nature 2004) ; le ronéo 2026-27 ne reprend pas l'expérience |
| 2020/2021 S1 Q11 (mort cellulaire) | aucune (« aucune correction ») | BCE, déduite | A et D cotées fausses ailleurs (2015/2016 S1 Q15 D, 2018/2019 S1 Q8 D), E vraie (2023/2024 S1 Q4 E) ; B, la diapositive TNFR1 (partie 1, p. 10) ; C (p. 10) |
| 2020/2021 S1 Q12 (caspases) | aucune | ABCDE, déduite | A, FC 2025-26, p. 13 ; B, XIAP sur la diapositive (partie 1, p. 8) ; C, D, E : littérature et diapositives |
| 2020/2021 S1 Q13 (autophagie) | aucune | ABDE, déduite | C contredit « autophagie = survie » (partie 2, p. 5) ; la même question est imprimée ABCDE en 2019/2020 S1 Q11 |
| 2019/2020 S2 Q11 (apoptose) | aucune (« pas de correction ») | BCD, déduite | A contredit partie 1, p. 4 ; E, inhiber Bcl-2 favorise la mort (p. 9) |
| 2019/2020 S2 Q12 (nécroptose) | aucune | ABCDE, déduite | mot pour mot 2019/2020 S1 Q10, imprimée ABCDE |
| 2019/2020 S2 Q13 (autophagie) | aucune | ABDE, déduite | C : la mitophagie pourrait empêcher l'apoptose (partie 2, p. 4 ; cours 2024-25, p. 19) |
| 2024/2025 S1 Q1 (mort cellulaire) | aucune (sujet sans corrigé) | **ACE**, déduite | A, partie 1, p. 2 ; B, le vénétoclax est un BH3-mimétique qui INHIBE Bcl-2 (p. 8-9) ; C, p. 10 ; D, la neurodégénérescence est un excès d'apoptose (tableau p. 5) ; E, la famille de Bcl-2 agit sur la mitochondrie (p. 7-8). Le sujet imprime « neurogénératives » (D) : coquille gardée |

Toutes les autres clés sont reprises telles quelles. La table de corrections
étiquette la colonne de 2021/2022 S1 « 2021/2022 Session 2 », comme la suivante : les
énoncés disent Session 1, la carte aussi.

## Les erreurs des ronéos 2026-27

Aucun tableau d'erreurs BMCP de la promo au 11/10/2026 : toutes les erreurs ci-dessous
ont été trouvées en relisant, et vont dans `contenu/ERRATA_RONEOS_2026-27.md`. Aucun
ronéo n'est corrigé ; chaque erreur est portée par une carte, avec son genre. À
l'examen, on répond d'abord comme le professeur.

**Prises de notes fausses** (`ATTENTION (prise de notes)`) :

| Partie, page | Le ronéo dit | Ce qui est juste | Carte |
|---|---|---|---|
| 1, p. 3 | les nucléosomes, « coques protéiques formées d'histones qui protègent le filament d'ADN nucléaire en s'enroulant autour » | l'ADN s'enroule autour d'un octamère d'histones, 146 pb en 1,65 tour (Luger et al., Nature 1997) ; la diapositive du professeur le dessine ainsi (FC 2025-26, p. 4) | `mce-qc-gel-adn` (E), `mce-fa-echelle` |
| 1, p. 6 | « un ver nématode plat » (repris du ronéo 2025-26) | les nématodes sont des vers ronds ; les vers plats sont les plathelminthes ; le cours 2024-25 (p. 8) et la phrase suivante du ronéo disent « le nématode », sans plus ; la diapositive ne qualifie pas le ver | `mce-qc-c-elegans` |
| 1, p. 6 | « 1090 cellules (principalement des neurones) » (repris du ronéo 2025-26) | 302 neurones sur 959 cellules chez l'hermaphrodite adulte (WormAtlas) ; ce sont plutôt les 131 cellules qui meurent dont beaucoup sont les sœurs de futurs neurones (Conradt, Wu et Xue, Genetics 2016) ; diapositive et cours 2024-25 (p. 8) : 1090 cellules, sans neurones | `mce-fa-c-elegans` |
| 1, p. 7 | les caspases « découpent l'ADN et les cellules » (repris du ronéo 2025-26) | des protéases : « famille de protéases caspases », « apoptose (protéolyse) » (diapositive de la même page) ; l'ADN est coupé par une endonucléase (p. 3) | `mce-qc-homologies` (D) |
| 1, p. 9 | Bcl-2 surexprimé dans les « cancer hématologiques (jaune, à gauche) » et les « tumeurs solides (orange, à droite) » (repris du ronéo 2025-26) | l'inverse sur la diapositive de la même page : tumeurs solides en jaune, à gauche (sein, côlon, mélanome, prostate, poumon à petites cellules) ; cancers hématologiques en orange, à droite (LAM, LLC, lymphome, myélome) | `mce-qc-moduler` (D) |
| 1, p. 9 | le vénétoclax, de très bons résultats « sur leucémies myéloïdes chroniques » | la leucémie LYMPHOÏDE chronique : cours 2024-25 (p. 13) et 2025-26 (p. 12), AMM européenne (EMA, Venclyxto : LLC, puis LAM) ; aucune indication dans la LMC, que la diapositive de la même page ne montre pas (CLL et AML) | `mce-qc-venetoclax` (D), `mce-fa-venetoclax` |
| 2, p. 2 | « L'autophagie c'est l'auto-digestion de la cellule (d'origine inconnue) » | c'est la membrane du phagophore dont l'origine est inconnue, réticulum ou Golgi (cours 2024-25, p. 16) | `mce-qc-autophagie-etapes` (A) |
| 2, p. 3 | « Des auteurs japonais ont reçu un prix Nobel en 2016 » (repris du ronéo 2025-26) | le Nobel de physiologie ou médecine 2016 est allé au seul Yoshinori Ohsumi (Fondation Nobel) ; le cours 2024-25 (p. 17) : « Nobel en 2016 par Ohsumi » | `mce-qc-autophagie-mecanismes` (B) |
| 2, p. 3 | des gènes qui permettent « de plier le phagosome » (repris du ronéo 2025-26) | le PHAGOPHORE, que le même ronéo nomme p. 2 ; le phagosome est la vésicule de la phagocytose | `mce-qc-autophagie-mecanismes` |

**C'est le cours lui-même** (`ATTENTION (cours)` : « À l'examen : … », puis « La
référence : … ») :

| Partie, page | Le cours dit | La référence | Carte |
|---|---|---|---|
| 1, p. 10 | l'étude de 2008, une analyse de l'expression des gènes : « 432 gènes régulés dont 7 communs avec l'apoptose » (de même FC 2025-26, p. 13, « transcriptomique », et cours 2024-25, p. 15, « synthèse d'ARNm ») | un crible par ARN interférents de tout le génome : 432 gènes qui RÉGULENT la nécroptose, dont 7 régulent aussi l'apoptose (Hitomi et al., Cell 2008) ; à l'examen, la clé des annales (« activation de plusieurs gènes ») | `mce-fa-necroptose` |

**Points douteux** (`ATTENTION (douteux)`), dits dans la carte sans changer sa clé :

| Partie, page | Le point | Carte |
|---|---|---|
| 1, p. 3 | l'hépatite fulminante « déclenchée par alcool, hépatite B ou C » (l'hépatite C dans les trois cours ; la diapositive dit seulement « infection virale ») : les recommandations européennes (EASL, J Hepatol 2017) citent les hépatites A, E et B, pas la C, exceptionnelle ; l'hépatite alcoolique est une décompensation de maladie chronique, distincte de l'insuffisance hépatique aiguë | `mce-qc-definition-fonctionnelle` |
| 1, p. 10 | « À partir des années 2008, est apparu ce concept de nécroptose », quand la même page dit « à partir des années 2000 » : le mot necroptosis date de 2005 (Degterev et al., Nat Chem Biol 2005), et le cours 2024-25 date les nécroses régulées de 2005 (p. 4) ; mais le professeur rattache aussi le mot à l'étude de 2008 (FC 2025-26, p. 13 ; cours 2024-25, p. 15) : prise de notes ou cours, on ne tranche pas | `mce-fa-necroptose` |

**Relus, et qui ne sont pas des erreurs** :

- « Si le ver adulte fait moins de 959 cellules alors le gène muté provoque
  l'apoptose » (partie 1, p. 6) : c'est l'effet de la mutation, juste ; la FC 2025-26
  parlait du rôle du gène avant mutation (« inhibait »). Les annales demandent ce
  rôle : `mce-qc-c-elegans` C le dit par un ATTENTION nu.
- L'ATU « le 1er septembre 2016 » et l'AMM « en France en 2018 » (partie 1, p. 9 ;
  mêmes dates en 2024-25 et 2025-26) : l'ATU de cohorte, accordée le 22 août 2016, a
  ouvert le traitement le 1er septembre (ANSM) ; l'AMM européenne, conditionnelle le
  5 décembre 2016, est devenue pleine le 20 novembre 2018 (EMA). Une précision dans
  `mce-qr-venetoclax`, sans ATTENTION.

Sans ATTENTION, parce qu'aucune réponse n'en dépend : « R. Horwitz » (p. 6, pour
Horvitz, dit dans `mce-qc-c-elegans`), « Dans cette cellule » pour « ce ver » (p. 6),
le cholangiocarcinome dit « cancer rare du foie » (partie 2, p. 5 : un cancer des voies
biliaires, intra- ou extrahépatiques), le rôle de l'autophagie qui dépendrait « du type
de cancer » (partie 2, p. 5 ; le tableau de la diapositive le range aussi par stade, dit
dans `mce-qc-autophagie-cancers`).

## Les erreurs du Ronéosaure 2025-26

Le Ronéosaure n'est pas le ronéo de l'année : ses erreurs sont dites sans genre, et
n'entrent pas dans `contenu/ERRATA_RONEOS_2026-27.md`. Celles que le ronéo 2026-27
recopie ont pris le genre de l'année (ver plat, neurones, caspases et ADN, couleurs du
graphique de Bcl-2, auteurs japonais, phagosome) ; celles qu'il corrige ont perdu leur ATTENTION et sont dites en une phrase
(vieillissement cellulaire, double membrane, cellules de l'immunité). Reste un
**ATTENTION nu** :

| Page | Le Ronéosaure dit | Sorte | Carte |
|---|---|---|---|
| 12 | l'ABT-737 « induisait des thrombopénies très importantes donc elle n'a pas pu être utilisée » | prise de notes probable : le cours 2024-25 (p. 13) attribue les thrombopénies au navitoclax (ABT-263), comme la littérature (Wilson et al., Lancet Oncol 2010) ; le ronéo 2026-27 n'en parle pas | `mce-qc-venetoclax` B, `mce-fa-venetoclax` |

**L'entrée du tableau d'erreurs de la promo 2025-26 sur la p. 6** (inverser « moins de
959 cellules → le gène muté inhibait l'apoptose ») : le ronéo 2026-27 l'a appliquée.
Les deux formulations sont justes, l'une sur le rôle du gène, l'autre sur l'effet de
la mutation ; la carte raisonne sur le rôle du gène, comme le QROC 4, et le dit.

## Les schémas et les figures

**Vingt et une figures du ronéo 2026-27**, extraites en PNG (captures de diapositives,
1000 px de large au plus, 256 couleurs), déclarées dans `IMAGES` avec leur page :
partie 1 — l'hépatite fulminante et le gel à trois pistes (p. 3), le tableau des
défauts et des excès (p. 5), C. elegans (p. 6), les homologies et la mitochondrie au
centre (p. 7), la voie intrinsèque et l'annexine dans l'infarctus (p. 8), Bcl-2 dans
les cancers (p. 9), les voies communes et la nécroptose TNFR1-nécrosome (p. 10), les
pathologies de la nécroptose et les nécroses régulées (p. 11) ; partie 2 — la ligne
« autophagie » du tableau, les étapes et la microscopie électronique (p. 2), les souris
Atg7−/−, la mitophagie, l'autophagie et la survie (p. 4), l'autophagie et la mort,
l'autophagie et les cancers (p. 5). **Quatorze PNG de 2025-26 qu'elles remplacent ont été
retirés de `media/`** (les mêmes diapositives, moins nettes ; ils restent dans
l'historique git).

**Sept figures de la FC 2025-26 restent**, là où le ronéo de l'année n'a pas
d'équivalent : le tableau complet des types de mort (p. 2 et 14), la diapositive de
l'échelle d'ADN, qui dessine l'ADN enroulé autour des nucléosomes (p. 4), les doigts
(p. 4), l'homéostasie (p. 5), l'annexine après chimiothérapie (p. 11), le mécanisme
moléculaire avec LC3 (p. 16), les souriceaux ATG5 (p. 17). Le ronéo 2026-27 a aussi le
graphique des publications (partie 1, p. 2) et deux planches de microscopie (partie 2,
p. 3) : non reprises, aucune carte ne les demande. Deux figures déclarées ne sont
attachées à aucune carte : la ligne « autophagie » du tableau (partie 2, p. 2), que le
tableau complet de 2025-26 contient, et l'annexine après chimiothérapie (FC 2025-26,
p. 11), remplacée sur `mce-qc-annexine` par l'infarctus de l'année ; elles partent
avec le chapitre sans être montrées.

**Un schéma cliquable** (`schemas.py`), avec sa version légendée en correction :

| Fichier | Ce qu'on clique | Pourquoi ce dessin |
|---|---|---|
| `voie-mitochondriale-nue.svg` | la BH3-only, la protéine anti-apoptotique Bcl-2, le canal Bax/Bak, le cytochrome c libéré, Apaf-1 (l'apoptosome), la caspase-9, la caspase-3, XIAP (8 zones) | la diapositive en anglais de la voie intrinsèque (partie 1, p. 8 ; FC 2025-26, p. 9), redessinée nue ; le canal est planté dans la membrane EXTERNE, le piège de 2016/2017 S1 Q18 E |

**Deux planches à légender** (`scripts/planche_depuis_image.py`, aperçus de contrôle
relus) :

- `mce-pl-autophagie` — la diapositive des étapes de l'autophagie, **refaite sur la
  figure du ronéo 2026-27** (partie 2, p. 2) : cinq numéros (phagophore,
  autophagosome, lysosome, fusion avec le lysosome, dégradation), quatre intrus
  (phagosome, endosome, corps apoptotique, protéasome).
- `mce-pl-homologies` (**nouvelle**) — la diapositive des homologies (partie 1, p. 7) :
  huit numéros (EGL-1, Ced-9, Ced-4, Ced-3, famille de Bcl-2, BH3-only, Apaf-1,
  caspases), quatre intrus (cytochrome c, Bax et Bak, XIAP, procaspase-9). La
  définition imprimée à côté d'Apaf-1 est effacée avec lui ; le cercle de la BH3-only
  est blanchi en entier, ses lettres touchant le trait.

**70 QCM sur 70 illustrés (100 %)**, 104 notes sur 117. Chaque figure est du côté de la
correction ; seuls la voie nue et les deux planches numérotées sont devant la question.

## Le lexique

Douze termes ; pages mesurées dans le texte des deux ronéos 2026-27 (en-têtes et plans
exclus), puis dans la FC 2025-26 :

| Terme | Identifiant | Origine | Pages 2026-27 |
|---|---|---|---|
| Apoptose | `lex-apoptose-bmcp` | grec ἀπόπτωσις | partie 1, p. 2-12 ; partie 2, p. 2-5 |
| Nécrose | `lex-necrose-bmcp` | grec νέκρωσις | partie 1, p. 2, 4, 5, 10, 11, 12 |
| Phagocytose | `lex-phagocytose-bmcp` | grec φάγος + κύτος + -ωσις | partie 1, p. 4 ; partie 2, p. 4 |
| Syndactylie | `lex-syndactylie` | grec σύν + δάκτυλος | partie 1, p. 4 |
| Caspase | `lex-caspase` | acronyme anglais (cysteine-aspartic protease, 1996) : κύστις + asparagus + -ase | partie 1, p. 3, 7, 9 |
| Nécroptose | `lex-necroptose` | grec νεκρός + πτῶσις | partie 1, p. 10, 11, 12 |
| Ferroptose | `lex-ferroptose` | latin ferrum + grec πτῶσις | partie 1, p. 11 |
| Autophagie | `lex-autophagie` | grec αὐτός + φαγεῖν | partie 1, p. 2 ; partie 2, p. 2-5 |
| Autophagosome | `lex-autophagosome` | grec αὐτός + φάγος + σῶμα | partie 2, p. 2, 3, 4 |
| Mitophagie | `lex-mitophagie` | grec μίτος + χονδρίον + φαγεῖν | partie 2, p. 3, 4 |
| **Phagophore** (nouveau) | `lex-phagophore` | grec φάγος + -φορος (le nom est dû à P. O. Seglen) | partie 2, p. 2 |
| **Pyroptose** (nouveau) | `lex-pyroptose` | grec πῦρ + πτῶσις (Cookson et Brennan, 2001) | partie 1, p. 11 |

Les deux termes nouveaux reprennent des racines de la table commune (`phag(o)-`,
`-phore`, `pyr(o)-`, `-ptose`, cette dernière citant la FC de sémantique 1/2, p. 3) ;
leurs deux entrées sont proposées à `etymologies.json` (brouillon
`etym/bmcp_morts_cellulaires.json`, qui garde aussi les entrées déjà versées le
05/10), et leurs textes sont écrits dans la forme que `appliquer_etymologies.py`
produirait (vérifié : il ne toucherait rien). Aucun des deux n'existait dans un autre
paquet.

**Trois termes existent déjà dans une autre UE** : `lex-apoptose`
(`immuno_temporelle`), `lex-necrose` (`semio_osteo`), `lex-phagocytose`
(`immuno_innee`). L'identifiant d'une note est global : ils gardent ici le suffixe
`-bmcp` (question pour Vincent, plus bas).

## Absent du cours 2026-27

**Aucune carte** (`ABSENTS_2026` vide). Relu le 11/10/2026 : `mce-qr-lc3` (LC3,
marqueur de l'autophagosome, six annales le demandent) avait d'abord été rangée
absente, parce que la partie D (« Mécanismes moléculaires », partie 2, p. 3) ne nomme
plus LC3. Mais la même phrase parle des mécanismes moléculaires « (potentiellement
marqueurs) » de l'autophagie, et la FC 2025-26 disait déjà « une vingtaine de gènes
(qu'on ne verra pas) » avant de nommer LC3 : le cours n'a pas clairement abandonné le
marqueur, le ronéo ne l'a pas transcrit. La carte reste sur la FC 2025-26 (`fiche=FC2526`,
`page=16`) : badge « Cours 2025-26 · p. 16 », sans le tag `absent-2026`.

Les propositions isolées d'une autre année le disent dans leur propre justification :
les souriceaux ATG5 (`mce-qc-autophagie-roles` C), les thrombopénies (`mce-qc-venetoclax`
B), l'annexine après chimiothérapie (`mce-qc-annexine` D, E), l'expérience du TNF-α et
de l'inhibiteur de caspases (`mce-qc-necroptose` B, `mce-qc-voies-communes` E), le Nobel
2002 (`mce-qc-homologies`), le domaine unique des BH3-only (`mce-qc-mitochondrie` E).

## En attente des ronéos suivantes

**Rien.** Les deux ronéos du 02/10/2026 couvrent tout le plan de la FC 2025-26 de
l'introduction à l'autophagie ; la partie 2 (« Morts cellulaires PT2 ») clôt le cours
sur le rôle de l'autophagie dans la mort et dans les cancers. Le troisième ronéo du même
jour, la sénescence, appartient à `bmcp_senescence`. Aucune carte de ce chapitre
n'attend un ronéo à paraître.

## Décisions prises en route

- **Une carte n'est confirmée que si sa notion centrale est dans le cours de
  l'année** ; ses propositions d'une autre année le disent une à une.
  `mce-rv-tableau-morts` et `mce-qc-types-de-mort` sont confirmées : le ronéo 2026-27
  garde la ligne « autophagie » du tableau (partie 2, p. 2) et décrit les quatre morts
  (partie 1, p. 2) ; le tableau complet reste celui de la FC 2025-26.
  `mce-qr-bax-bak` et `mce-rv-bh3-double-effet` sont confirmées par la diapositive de la
  voie intrinsèque (partie 1, p. 8 : BAK et BAX sur la mitochondrie, BIM qui active
  BAX), le texte de l'année ne les nommant pas.
- **La carte LC3 cite la FC 2025-26 à sa page** (`fiche=FC2526`, `page=16`) : le
  badge dit « Cours 2025-26 · p. 16 », et la carte ne cite jamais la fiche de l'année.
  Elle n'est pas `absent-2026` : le ronéo évoque des marqueurs sans les nommer.
- **Les figures remplacées sont retirées de `media/`** : les mêmes diapositives, moins
  nettes, n'avaient plus de carte.
- **Les genres se tranchent sur la diapositive et le cours 2024-25**, parce que la
  ronéo 2026-27 recopie la ronéo 2025-26 : une erreur redite deux ans n'est « le cours
  lui-même » que si un témoin indépendant la porte (le crible de 2008, dit en
  expression de gènes par les trois années).
- **Une seconde relecture, le même jour**, a repris chaque erreur sur les ronéos, les
  diapositives et des sources sûres : la phrase des 959 cellules n'est plus une
  erreur (ATTENTION nu) ; les dates de l'ATU et de l'AMM du vénétoclax non plus
  (précision) ; la date « 2008 » de la nécroptose passe en point douteux ; les couleurs
  inversées du graphique de Bcl-2 (p. 9) sont ajoutées ; LC3 sort d'`ABSENTS_2026` ; le
  nucléosome compte 146 pb (Luger 1997), la diapositive de C. elegans ne dit pas
  « nématode », celle de la p. 9 montre l'expression de Bcl-2 et non l'indication du
  vénétoclax.
- **`EXAMENS` n'est pas déclaré**, comme dans les autres chapitres BMCP : le
  5 janvier 2027 se règle dans l'application.

## Questions pour Vincent

- (11/10) LC3 (mce-qr-lc3) : la ronéo 2026-27 ne nomme pas LC3, mais elle parle, au même endroit, des mécanismes moléculaires « (potentiellement marqueurs) ». La carte reste donc sur la FC 2025-26, avec le badge « Cours 2025-26 » et sans absent-2026. Si le professeur a vraiment retiré LC3 cette année, il suffit de remettre « mce-qr-lc3 » dans ABSENTS_2026. D'accord avec ce choix ?
- (11/10) Le crible de 2008 est rangé en « le cours lui-même », parce que les trois années le présentent comme une étude d'expression des gènes. Faut-il le garder ainsi, ou le ramener en point douteux ? La date du concept (« à partir des années 2008 ») est, elle, rangée en point douteux.
- (11/10) Apoptose, Nécrose et Phagocytose restent au lexique de la BMCP sous des identifiants -bmcp, en doublon avec l'immunologie et la sémiologie. Faut-il garder ce doublon, ou retirer ces termes d'ici ?

1. **LC3** (`mce-qr-lc3`) : le ronéo 2026-27 ne la nomme pas, mais parle de
   « marqueurs » au même endroit ; la carte reste, badge « Cours 2025-26 », sans
   `absent-2026`. Si le professeur a vraiment retiré LC3 cette année, il suffit de
   remettre `"mce-qr-lc3"` dans `ABSENTS_2026`. Laquelle des deux ?
2. **Le crible de 2008** est rangé en « le cours lui-même » (trois années le disent en
   expression de gènes) : à garder ainsi, ou à ramener en point douteux ? La DATE du
   concept (« à partir des années 2008 ») est, elle, un point douteux.
3. **Apoptose, Nécrose, Phagocytose au lexique de la BMCP** : toujours repris sous
   `-bmcp` ; garder ce doublon d'une UE à l'autre, ou les retirer d'ici ?

## À relire

**Aucune carte `a-relire`** : chaque note de cours cite une page de l'une des deux
parties du ronéo 2026-27 ou, pour LC3, de la FC 2025-26 ; chaque annale a
une clé imprimée vérifiée, ou une clé déduite qui le dit. Reste à faire, hors de ce
chapitre :

- `copier_les_cours.py` avec le dossier des ronéos 2026-27, hors du bac à sable, pour
  que les deux fiches s'ouvrent dans l'application ;
- verser les erreurs de l'année dans `contenu/ERRATA_RONEOS_2026-27.md` et les deux
  étymologies dans `etymologies.json`.

## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier (BMCP) ou du 6 janvier (SSH, papier). Sous les annales, 46 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 7 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `apoptose-necrose` | 14 | 1 | 11 |
| `apoptose-pathologies` | 6 | 1 | 7 |
| `c-elegans` | 3 | 1 | 1 |
| `voie-mitochondriale` | 6 | 1 | 6 |
| `necroptose` | 5 | 1 | 8 |
| `autophagie` | 12 | 2 | 12 |

**Le schéma** `ech-morts-cellulaires`, « Les morts cellulaires · apoptose, nécroptose, autophagie », donne 98 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_MORTS_CELLULAIRES`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- mce-an-2021s1-q12 C, E : la coupure après un aspartate et le DISC sont absents des cours 2023-24 à 2026-27 (justifiés par Alnemri 1996 et Kischkel 1995) ; lettres posées sur les caspases et le complexe II
- mce-an-1819s1-q9 C : l'auto-activation des caspases initiatrices, absente des cours (Salvesen et Dixit 1999)
- mce-an-1617s1-q18 B, C, D : la caspase-8 en amont de la caspase-3, l'AIF (seulement sur la diapositive des voies communes, sans texte) et les pro-domaines des initiatrices, absents du texte des cours
- mce-an-1516s1-q16 B, D, E : le domaine BH3 de la Bécline 1, la poche hydrophobe des anti-apoptotiques et l'activation transcriptionnelle des BH3-only (cours 2024-25, hors des sources), absents des ronéos 2025-26 et 2026-27
- mce-an-1718s1-q16 A, C, D, E et mce-an-1617s2-q18 A, B, C, D : l'expérience des lignées dépendantes de l'IL-3 (Vaux, Cory et Adams 1988), absente des cours ; seul le rôle protecteur de Bcl-2 (B, E) a sa marche
- mce-an-2021s1-q13 E, mce-an-1920s1-q11 E, mce-an-1920s2-q13 B, mce-an-1819s1-q11 A : mTOR, absent des cours
- mce-an-1819s1-q11 E, mce-an-1718s2-q19 D, mce-an-1617s2-q20 D, mce-an-1516s1-q17 D : la liaison Bcl-2 / Bécline 1 par le domaine BH3 et la « poche » d'ATG8, absentes du texte des cours
- mce-an-1617s1-q20 D : la Bécline 1 au début du processus n'est que sur la figure de la FC 2025-26 (p. 16) ; la ligne « Atg6 (Bécline 1) : début » porte la lettre, sans marche
- mce-an-1718s1-q17 A, mce-an-1617s1-q19 A : les « 432 gènes » de la nécroptose, que le chapitre marque d'un ATTENTION (cours) — l'étude de 2008 est un crible par ARN interférents, non une étude d'expression — : pas de marche (règle 11), lettre posée sur la nécroptose
- mce-an-1516s2-q15 D : les endonucléases (partie 1, p. 3) n'ont pas de ligne sur le schéma, déjà plein ; la notion est cartée dans mce-fa-echelle et mce-qc-gel-adn

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```
