# Bases de l'imagerie — paquet BMCP

72 notes, 151 cartes. Chapitre `chap-ue-bmcp-fc20` de l'UE BMCP, vingtième de
l'UE. Cours du **Pr Xavier Demondion, le 10/12/2025, de 8 h à 9 h**, dans le
**Ronéosaure 2025-26** (FC n°20, 11 pages) ; les annales de deux polycopiés du
Ronéosaure 2024-25 (10 QCM, 7 sessions). Examen : mardi 5 janvier 2027.

**Fiche provisoire** (C16, décision de Vincent du 02/10) : le cours de l'année
2026-27 n'est pas encore paru. Chaque carte de cours cite la FC 2025-26 à sa
page, et porte le badge « Cours 2025-26 » (l'année est lue dans l'auteur de la
source) ; la ronéo 2026-27 la corrigera quand elle sortira.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 34 | 34 |
| QRU | 1 | 1 |
| Texte à trous | 14 | 87 |
| QROC | 8 | 8 |
| Recto-verso | 6 | 6 |
| Schéma cliquable | 1 | 7 |
| Lexique | 8 | 8 |

Dont **10 annales** (QCM) sur 7 sessions, de 2017/2018 à 2023/2024, et 25 QCM
de cours.

Sept thèmes. `modalites-imagerie` et `produits-contraste` sont partagés avec
`bmcp_bases_physiques` (plan C16, § 0.9), au même libellé. Toutes les clés sont
nouvelles ; leurs libellés sont dans `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) depuis l'intégration du 05/10 :

| Clé | Libellé | Notes |
|---|---|---|
| `modalites-imagerie` | Les modalités d'imagerie | 11 |
| `radiographie-standard` | Radiographie standard | 13 |
| `produits-contraste` | Produits de contraste | 6 |
| `scanner-densites` | Scanner : densités, fenêtres et injection | 9 |
| `echographie-semiologie` | Échographie : sémiologie et indications | 4 |
| `irm-semiologie` | IRM : intensités, gadolinium, Fat Sat | 8 |
| `structures-observables` | Ce que voit chaque technique | 13 |

Le plan nommait trois de ces clés `radiographie`, `scanner` et `echographie` :
des mots qu'une autre UE voudra dans un autre sens (une radiographie de thorax en
sémiologie, une échographie en anatomie). Elles prennent ici une forme précise —
voir les questions pour Vincent.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-bmcp-bdi-2526` — Ronéosaure, « FC n°20 - Bases de l_imagerie » (11 p.) | 2025-26 | le cours ; `SRC["fiche"]`, ses 26 figures |
| `src-annales-bmcp-15-bases-physiques-de-l-imagerie-medicale` — « BMCP 15 - Bases physiques de l’imagerie médicale » | 2024-25 | les 10 questions (instance principale, plan § 0.11) ; table p. 6 ; accolades = correction non officielle |
| `src-annales-bmcp-20-bases-de-l-imagerie` — « BMCP 20 - Bases de l_imagerie » | 2024-25 | le polycopié de ce cours, qui recopie les dix ; déclaré, aucune carte ne le cite |

Les deux polycopiés sont déclarés avec les seuls champs convenus pour les
chapitres écrits en parallèle (id tiré du nom de fichier, titre, chemin, auteur),
pour que `bmcp_bases_physiques` et `bmcp_scanner`, qui puisent dans BMCP 15, les
déclarent à l'identique.

Lus en appoint, sans être déclarés, et cités dans les justifications quand une
annale sort du cours 2025-26 : le cours du même professeur en **2024-25**
(Ronéosaure, FC n°20, 16 p.) et en **2023-24** (Charonéo n°21, 14 p.) ; les FC
n°16, 19 et 21 de 2025-26 pour un renvoi ; les deux erratas BMCP (aucune entrée
pour ce cours ni pour ses annales).

Les en-têtes des ronéos, des polycopiés (« Secrétaire : … ») et des erratas
portent des noms d'étudiants : aucun n'est repris.

## Ce que le cours a dicté

- **Quatre tableaux « à retenir »** (p. 3, 6, 9, 11) : ce que la radiographie,
  le scanner, l'échographie et l'IRM voient de l'os cortical, de l'os
  trabéculaire, de la moelle, du cartilage, des muscles, des nerfs et des
  artères. C'est la grille des annales : quatre textes à trous
  (`bdi-fa-voit-*`), quatre QCM, la matrice redessinée (`bdi-matrice.svg`) et
  le schéma cliquable.
- **Le rouge** : la notion de distance et la nature de la structure en
  échographie (p. 8), le contraste augmenté par l'iode, qui met en évidence le
  tissu tumoral (p. 7), la désinsertion myo-aponévrotique (p. 10),
  l'échographie et sa résolution spatiale (p. 11), le gadolinium hyperintense
  en T1, l'inflammation et la tumeur hyperintenses en T2, le Fat Sat (p. 11).
  Chacun a sa carte.
- **Le gris** : il n'y en a pas. La « précision du prof pas au programme »
  (p. 4 : une ostéolyse mal délimitée évolue vite) n'a pas de carte.
- **Ce qui n'est pas carté ici** (plan § 0.7) : la physique du tube et du
  scanner (`bmcp_bases_physiques`), le réglage des fenêtres et les phases
  hépatiques (`bmcp_scanner`), la physique de l'échographie et de la RMN, dont
  la paire cône d'ombre / renforcement et son schéma cliquable
  (`bmcp_echographie_irm`), les séquences IRM (`bmcp_contrastes_irm`). Les
  cartes y renvoient. La paire calcification et cône d'ombre, kyste et
  renforcement (p. 9) n'est ici que citée : `eci-qc-echogenicite`,
  `eci-rv-cone-renforcement` et `eci-zo-artefacts` la cartent ; ce chapitre en
  garde le vocabulaire des gris, technique par technique (`bdi-qc-blanc-noir`,
  `bdi-rv-hyper-hypo`). La date de la première radiographie et l'histoire du
  scanner (Hounsfield, EMI) sont à `bmcp_bases_physiques` (`bpi-qr-roentgen`,
  `bpi-qr-hounsfield`) ; 1895 reste ici dans `bdi-qc-historique`.

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| Le scanner pour l'os cortical | 2023/2024 S1 Q.29 A, 2020/2021 S2 Q.27 B, 2019/2020 S2 Q.25 A, 2017/2018 S1 Q.29 B |
| La moelle : invisible au scanner et à l'échographie, domaine de l'IRM | 2023/2024 S1 Q.29 B D, 2021/2022 S1 Q.23 C, 2020/2021 S2 Q.27 D, 2019/2020 S2 Q.25 B D, 2017/2018 S2 Q.26 B |
| La radiographie, peu sensible à l'ostéolyse et aux métastases | 2023/2024 S1 Q.29 C, 2021/2022 S1 Q.23 A, 2020/2021 S2 Q.26 E, 2019/2020 S2 Q.25 C |
| Les nerfs : échographie et IRM, pas le scanner | 2023/2024 S1 Q.30 D E, 2022/2023 S2 Q.26 B, 2021/2022 S1 Q.23 B |
| Gadolinium, iode : quel contraste pour quelle technique | 2022/2023 S2 Q.26 D E, 2021/2022 S1 Q.23 D, 2020/2021 S2 Q.27 E, 2019/2020 S2 Q.26 E, 2017/2018 S2 Q.26 D E |
| Les gris : graisse hypodense, liquides, gris de la radiographie | 2023/2024 S1 Q.30 C, 2022/2023 S2 Q.26 C, 2020/2021 S2 Q.26 A B, 2019/2020 S2 Q.26 C |
| Résolution spatiale et en contraste | 2023/2024 S1 Q.30 A B, 2019/2020 S2 Q.26 B, 2017/2018 S1 Q.29 C, 2017/2018 S2 Q.26 A |
| L'arthroscanner, l'artériographie par voie veineuse | 2023/2024 S1 Q.29 E, 2022/2023 S2 Q.26 A, 2020/2021 S2 Q.27 C, 2019/2020 S2 Q.25 E, 2017/2018 S2 Q.26 C |

**Les copies, non recartées** : les dix questions sont aussi dans BMCP 20
(la 2020/2021 S2 Q.26 y est numérotée « Q. 6 ») ; la 2023/2024 S1 Q.30 est
aussi dans BMCP 18 (même clé). Chaque explication nomme ses copies.

## Les erreurs du ronéo 2025-26

Le Ronéosaure n'est pas le ronéo de l'année : chaque erreur est portée par un
**ATTENTION nu** dans la carte qui tient la notion, la sorte dite dans le texte,
et rien n'entre dans `contenu/ERRATA_RONEOS_2026-27.md`.

| Page | Le ronéo dit | Retenu | Sorte | Carte |
|---|---|---|---|---|
| 5 | « Le faisceau a une certaine épaisseur qu'on appelle la matrice » | l'épaisseur du faisceau fait l'épaisseur de coupe ; la matrice est la grille de pixels (FC n°16, p. 8) | prise de notes probable | `bdi-qc-scanner-principe` C |
| 2 | les radiologues de la scopie ont eu des « cancers auto-induits » | radio-induits | prise de notes | `bdi-qc-historique` D |

Sans carte, parce qu'aucune n'en dépend : « le cours du Dr. Ernest » (p. 5),
c'est le Pr Olivier Ernst (FC n°21) ; « P1 », « P2 » (p. 10) pour les
pondérations T1, T2.

**Le soupçon du plan, levé** : le plan lisait au tableau de la p. 3 des
« artères calcifiées à la fois visibles et invisibles ». Relu sur la page, le
tableau range les artères **calcifiées** parmi les visibles et les artères **non
calcifiées** parmi les invisibles ; c'est l'extraction du texte qui coupait la
case. Pas d'erreur, pas d'ATTENTION.

Une phrase est reprise avec prudence, sans ATTENTION faute de preuve : « le
temps tardif permet de voir cette néovascularisation » (p. 7). Aucune carte ne
demande le temps ; elles cartent la phrase en rouge, le contraste augmenté entre
la tumeur et les tissus.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2017/2018 S1 Q.29 | BCDE (BMCP 15 et BMCP 20) | **BDE**, `officielle=False`, ATTENTION sur C, `CONFLITS` | C, « l'échographie possède une excellente résolution en contraste » : le professeur enseigne l'inverse, deux années de suite — l'échographie a la meilleure résolution **spatiale** mais « n'a pas une bonne résolution en contraste » (cours 2023-24, p. 12) ; « la résolution en contraste varie beaucoup », « la meilleure résolution en contraste est en IRM » (cours 2024-25, p. 10-11). La session suivante donne aussi fausse l'« excellente résolution en contraste » du scanner. |
| 2019/2020 S2 Q.25 | {AE}, entre accolades (non officielle) ; BMCP 20 : « pas de correction » | AE, `officielle=False` | clé confirmée par le cours, et officielle pour la même question en 2023/2024 S1 |
| 2019/2020 S2 Q.26 | {ABD}, entre accolades ; BMCP 20 : « pas de correction » | ABD, `officielle=False` | clé confirmée par le cours |

Toutes les autres clés sont reprises telles quelles. La table de BMCP 20 pour
2023/2024 S1 recopie « Q.20) CDE », la clé d'une question de 2022/2023, et ne
donne rien pour la Q.30 : les cartes prennent la table de BMCP 15 (Q.29 AE,
Q.30 ACD), que BMCP 18 confirme pour la Q.30.

Quatre propositions d'annales ne sont pas dites en toutes lettres par le cours
2025-26 et s'appuient sur le cours du même professeur des années précédentes :
la radiographie insensible à l'ostéolyse (« au moins 30 % de masse osseuse
disparue », 2023-24 p. 4-5 ; « les radios normales n'éliminent pas les
ostéolyses », 2024-25 p. 5), la résolution en contraste du scanner
(« moyenne », 2024-25 p. 11) et de l'échographie, l'IRM multiplanaire (2023-24
p. 13), la fréquence de sonde et la profondeur (2024-25 p. 11 ; FC n°19 p. 2).

## Les schémas et les figures

**26 figures de la FC 2025-26**, en PNG : la main de Mme Röntgen (p. 2), les
quatre tableaux (p. 3, 6, 9, 11), l'ostéolyse, l'arthrite et l'arthrose,
l'ostéochondromatose, le kyste poplité, l'artériographie (p. 4), l'estomac, les
contre-indications, le « bonhomme patate » du scanner (p. 5), l'ostéolyse du
petit trochanter, le fenêtrage (p. 6), l'injection, la reconstruction 3D, les
indications du scanner (p. 7), le principe de l'échographie (p. 8),
l'échogénicité, les indications de l'échographie (p. 9), le nerf, la pennation,
les intensités IRM (p. 10), la résolution, le gadolinium et le Fat Sat (p. 11).
Aucune photographie de patient : des clichés d'imagerie, la matière du cours.

**L'image en question** : `bdi-qc-osteochondromatose`, une QRU où lire
l'arthrographie de hanche (p. 4) *est* la question ; l'image ne porte aucune
légende.

**Un schéma cliquable** (`schemas.py`) :

| Fichier | Ce qu'on clique | Pourquoi ce dessin |
|---|---|---|
| `bdi-structures.svg` | os cortical, os trabéculaire, moelle, cartilage, muscle, nerf, artère (7 zones) — on clique la structure dont on lit le **profil** dans les tableaux (« invisible en radiographie, absente du tableau du scanner, que l'échographie voit bien quand elle est superficielle » : le nerf) | une extrémité de fémur coupée dans sa diaphyse : la corticale en U, la moelle et l'os trabéculaire dedans à 2 px de son bord, le cartilage sous les condyles ; le tibia estompé ne porte pas de zone. La correction montre la matrice des quatre tableaux. |

**Trois figures redessinées** pour les corrections : `bdi-matrice.svg` (les
quatre tableaux côte à côte), `bdi-quatre-techniques.svg` (rayonnement, image,
mots-clés, contraste, ordre des résolutions), `bdi-gris-densites.svg` (blanc ou
noir selon la technique).

**35 QCM sur 35 illustrés (100 %)**, 61 notes sur 72.

## Le lexique

Huit termes. Le plan en proposait neuf ; trois existent déjà dans la
bibliothèque, un terme n'y vit qu'une fois (548 termes, aucun double), et ne
sont donc pas repris : **Arthrite** et **Arthrose** (`semio_osteo`),
**Néovascularisation** (`biostat_irm_prostate`). Deux termes du cours les
remplacent, **Myélome** (p. 5) et **Aponévrose** (p. 10). Pages mesurées dans
le texte de la FC 2025-26 (`chercher_pages.py`) :

| Terme | Origine | Pages |
|---|---|---|
| Radiotransparent | latin radius + transparens | 3, 4 |
| Trabéculaire | latin trabecula | 3, 4, 6, 9, 11 |
| Ostéolyse | grec ostéon + lúsis | 4, 6 ; sémantique 1/2 p. 9, 2/2 p. 3 |
| Ostéochondromatose | grec ostéon + khóndros + -ōma + -ōsis | 4 |
| Hystérographie | grec hustéra + gráphein | 4 |
| Pennation | latin pennatus, par l'anglais | 10 |
| Myélome | grec muelós + -ōma | 5 |
| Aponévrose | grec aponeúrōsis | 10 |

Les racines que les FC de sémantique enseignent les citent : `ostéo-`,
`chondr-`, `apo-`, `neur(o)-` (1/2, p. 6, 6, 3, 4), `-lyse` (1/2, p. 9),
`myél(o)-` (2/2, p. 8), `-ose` (2/2, p. 9), `trans- (latin)` (2/2, p. 11),
`radi- (latin)` (2/2, p. 12 du PDF). Les racines nouvelles (`parere (latin)`,
`trabécul- (latin)`, `hystér(o)-`, `penna (latin)`) et `radi- (latin)` — à la
clé exacte que propose `bmcp_medecine_nucleaire` — sont proposées, avec les huit
termes, dans `scratchpad/etym/bmcp_bases_imagerie.json`, vérifiées sur le
Wiktionnaire, le Bailly, le LSJ et le Gaffiot (Logeion) ; le CNRTL, devenu une
application JavaScript, ne se lit plus hors navigateur. Les textes du lexique
sont déjà écrits dans la forme que `appliquer_etymologies.py` produirait
(vérifié terme par terme).

## Questions pour Vincent

1. **2017/2018 S1 Q.29 C** (« l'échographie possède une excellente résolution
   en contraste ») : la clé imprimée, officielle, la dit vraie ; le cours du
   professeur, en 2023-24 comme en 2024-25, dit le contraire. Retenu : fausse,
   clé BDE, `officielle=False`, comme répondrait le professeur aujourd'hui.
   Le point n'est pas tranché hors du cours : les sources générales donnent à
   l'IRM la meilleure résolution en contraste, mais des textes de physique
   prêtent à l'échographie une grande sensibilité aux différences
   d'impédance, et la clé de 2017/2018 a pu suivre un autre enseignement.
   À confirmer.
2. **Les clés de thème** `radiographie-standard`, `scanner-densites`,
   `echographie-semiologie` au lieu des `radiographie`, `scanner`,
   `echographie` du plan : d'accord ?
3. **Le lexique** : Arthrite, Arthrose et Néovascularisation restent à leurs
   chapitres d'autres UE (un terme par bibliothèque) ; Myélome et Aponévrose
   prennent leur place ici. D'accord ?

## Décisions prises en route

- **`EXAMENS` n'est pas déclaré** (plan § 0.2) : l'examen du 5 janvier se règle
  dans l'application.
- **Les cartes d'annales citent BMCP 15**, l'instance principale du plan ;
  BMCP 20, le polycopié de ce cours, est déclaré et nommé dans chaque
  explication.
- **L'icône** est `layers` (les coupes) ; l'ordre, 20, le numéro de la FC
  2025-26.

## Relecture du 05/10

Chaque carte relue contre la page de la FC qu'elle cite, chaque clé d'annale
contre la table de BMCP 15 (et de BMCP 20, BMCP 18), les deux erratas (aucune
entrée pour ce cours) et les cours 2024-25 et 2023-24 du même professeur ; les
figures sur leur page ; le schéma rendu avec ses zones. Corrigé :

- **`bdi-qc-echogenicite` remplacée par `bdi-qc-blanc-noir`** : elle cartait
  la paire calcification et cône d'ombre, kyste et renforcement, que le plan
  donne à `bmcp_echographie_irm` (presque mot pour mot `eci-qc-echogenicite`).
  La nouvelle QCM demande le blanc et le noir des quatre techniques (p. 2, 7,
  9, 11) ;
- **`bdi-qr-1895` et `bdi-qr-emi` retirées** : doublons de `bpi-qr-roentgen`
  et de l'histoire du scanner de `bpi-qr-hounsfield` (`bmcp_bases_physiques`) ;
- l'ATTENTION des cancers « auto-induits » dit sa sorte (prise de notes) et
  cite le cours 2024-25, p. 2 ;
- 2023/2024 S1 Q.30 B : le renvoi à la FC n°19 devient « p. 2 et 4 » (la
  p. 2 ne dit que la résolution ; l'atténuation plus forte est p. 4) ; sa
  figure devient le nerf en échographie (p. 10) ;
- 2017/2018 S1 Q.29 : l'explication ne tire plus de la session 2 une
  confirmation qu'elle ne donne pas, et dit le point ouvert ;
- « à peine visible en radiographie » (petit trochanter) cite sa source, le
  cours 2024-25, p. 7 ;
- `bdi-structures.svg` : la légende de l'os cortical, posée dans la bande
  corticale, tombait sur celle de la moelle ; elle passe dans le vide, à
  droite de la diaphyse ;
- `bdi-quatre-techniques.svg` : la case du nom de chaque technique prenait
  les couleurs « visible / difficile / absent » de la matrice, sans ce sens
  ici ; elle est neutre.

## Le brouillon du 03/10

Le dossier contenait un brouillon d'une exécution interrompue : `schemas.py`
et 26 PNG, sans `donnees.py` ni `annales.py`. Tout a été relu sur les pages :

- les 26 figures sont les bonnes et à leur page ; deux recadrages étaient
  fautifs et ont été refaits depuis le PDF — `bdi-echo-principe.png` (des
  bribes de texte, « lités », « trasons : », sur les bords : c'est maintenant
  l'image incorporée elle-même) et `bdi-echogenicite.png` (dernière ligne
  coupée, bordures de tableaux) ;
- `schemas.py` : la géométrie était juste ; trois indices de zone étaient
  ambigus et ont été réécrits — l'os trabéculaire et le muscle partageaient le
  même profil (difficile en radiographie, visible au scanner), la moelle et le
  nerf aussi (invisibles en radiographie), le muscle et le nerf encore (bien
  vus en échographie) ; la phrase sous la matrice débordait du cadre (coupée en
  deux lignes) ; « Hyperéchogène » débordait de sa case (cases élargies) ; la
  version légendée du schéma, que rien n'employait, a été retirée ; « tout l'os »
  du scanner, dans la matrice, est devenu « l'os cortical et trabéculaire ».

## À relire

**Aucune carte `a-relire`** : chaque note cite une page de la FC 2025-26, ou le
cours du même professeur d'une année passée quand une annale en sort. Reste à
Vincent :

- quand le ronéo 2026-27 paraîtra, relire chaque carte sur lui et retirer le
  badge « Cours 2025-26 » ;
- `copier_les_cours.py` avec le dossier `…/examen janvier/BMCP` du Ronéosaure
  2025-26, hors du bac à sable, pour que la fiche s'ouvre dans l'application.

## Intégration (05/10)

- Les libellés de thèmes sont dans `THEME_LABELS`
  (`app/src/med_engine/application/scopes.py`), bloc « BMCP FC n°6 à 22 ».
- Les étymologies proposées (racines et termes) sont versées dans
  `.claude/skills/nouveau-chapitre/scripts/etymologies.json` ;
  `appliquer_etymologies.py` n'a rien réécrit, les textes du lexique étant
  déjà à sa forme.
- `radi- (latin)` n'a qu'une entrée, commune avec `bmcp_radioprotection`,
  `bmcp_medecine_nucleaire` et `bmcp_bases_physiques`.

## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier (BMCP) ou du 6 janvier (SSH, papier). Sous les annales, 30 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 6 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `modalites-imagerie` | 11 | 2 | 4 |
| `radiographie-standard` | 4 | 1 | 1 |
| `produits-contraste` | 4 | 1 | 1 |
| `structures-observables` | 11 | 2 | 4 |

**Le schéma** `ech-techniques`, « Les techniques d'imagerie · ce que chacune voit et montre », donne 47 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_TECHNIQUES`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```
