# Pharmacologie du système immunitaire — paquet BMCT

117 notes, 190 cartes. Chapitre `chap-ue-bmct-fc6` de l'UE BMCT, sixième de
l'UE. **Cours du Pr Devos, le 12/10/2026, de 10 h à 11 h, dans la ronéo
Ronéo & Juliette 2026-27** « Pharmacologie du système immunitaire » (12 p.,
dépôt du 19/10/2026). Réaligné sur elle le 19/10/2026 ; il était carté depuis le
02/10 (C14) sur la FC n°6 du Ronéosaure 2025-26 (Pr Devos, 14/10/2025, 8 p.), qui
n'est plus qu'un appoint. Annales : le polycopié du Ronéosaure 2024-25 (16
sessions, 17 QCM) et deux questions du sujet 2024/2025 (déposé le 15/10/2026).
Examen : partiel du mercredi 4 novembre 2026.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 53 | 53 |
| QRU (marches Simple de l'échelle) | 21 | 21 |
| Texte à trous | 11 | 71 |
| QROC | 12 | 12 |
| Recto-verso | 9 | 9 |
| Lexique | 8 | 8 |
| Schéma cliquable | 2 | 15 |
| Planche à légender | 1 | 1 |

Dont **19 annales** sur 17 sessions (2015/2016 S1 à 2024/2025 S1), **27 QCM du
cours** et **28 marches de l'échelle** (21 Simple, 7 Moyen). Les deux annales de
2024/2025 sont les Q6 et Q7 du sujet, session 1 (`imt-an-2425s1-q6`,
`imt-an-2425s1-q7`), sans corrigé : clés déduites du cours. Le PDF du sujet porte
une correction surlignée en bleu, officieuse et d'origine inconnue (le même
surligneur reproduit 37 des 40 clés officielles de 2023-24) : non déclarée, elle
sert de seconde opinion, et donne les mêmes clés (CE, ACDE). La clé de 2023/2024
S1 Q5 (ACE) est confirmée par la grille officielle de la faculté (dépôt du
15/10/2026). **74 QCM sur 74 illustrés (100 %)**, 108 notes sur 117. **3 cartes
absentes du cours 2026-27** (tag `absent-2026`), **23 cartes portent un piège de
ronéo** (thème « Pièges des ronéos »).

Six thèmes (plan C14), déjà dans `THEME_LABELS` ; le réalignement n'en ajoute
aucun :

| Clé | Libellé |
|---|---|
| `cibles-immunitaires` | Réponse immunitaire et cibles des médicaments |
| `anti-cytokines` | Inhibition des cytokines |
| `antiproliferatifs` | Antimétabolites et cytotoxiques |
| `anticorps-cibles` | Anticorps anti-CD et anti-migration |
| `immunostimulants` | Immunostimulants |
| `risques-immunosuppression` | Risques des immunosuppresseurs |

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-bmct-imt-2627` — « Pharmacologie du système immunitaire » (12 p., la dernière vide), `BMCT/PHARMACOLOGIE DU SYSTÈME IMMUNITAIRE.pdf` | **2026-27** | **le cours** : `SRC["fiche"]`, ce que le lecteur ouvre ; 95 notes la citent à leur page (les 19 annales citent leur polycopié ou leur sujet) |
| `src-fc-bmct-imt-2526` — FC n°6, « Pharmacologie du système immunitaire » (8 p.) | 2025-26 | **appoint** (`SRC["cours"]`, sans `chapitre=`) : ce que la ronéo 2026-27 ne reprend pas, **les figures nettes** (`SRC["medias"]`), et la source des **3 cartes absentes** |
| `src-annales-bmct-pharmacologie-du-systeme-immunitaire` — « BMCT - Pharmacologie du système immunitaire » (7 p.) | 2024-25 | 16 sessions, table de corrections p. 6-7 |
| `src-sujets-bmct-2425` — Sujets de BMCT 2024/2025, session 1 (20 p.) | 2024-25 | les Q6 et Q7, sujet sans corrigé ; `SRC["sessions"]["2024/2025 S1"]` ; déclaré à l'identique par tous les chapitres de BMCT qui en cartent une question |
| tableau d'erreurs BMCT de la promo 2026-27 | 2026-27 | rien sur ce ronéo au 19/10/2026 (deux entrées, sur la pharmacocinétique 2 et la pharmacodynamie) |

Les textes citent « p. 4 » pour la ronéo 2026-27, « FC 2025-26, p. 4 » pour le
Ronéosaure ; les annales écrivent « ronéo 2026-27, p. 4 » en toutes lettres. Lus
en appoint, sans être déclarés : la FC n°8 2024-25 du même cours (Ronéosaure
2024-25) et le cours 2023-24 (Charonéo, n°4), pour comprendre une annale ;
l'errata des cours 2025-26 et celui des annales. La fiche de l'année se copie
dans le dossier des PDF de l'application par `outils/copier_les_cours.py`, lancé
avec le dossier des ronéos du 19/10 (`Ajouts/[NUMERIQUE] Ronéo & Juliette 26-27
19 10 2026/S1/CM`), hors du bac à sable.

Les en-têtes des ronéos, des erratas et du polycopié portent des noms
d'étudiants : aucun n'est repris.

## Ce qui correspond à quoi

La ronéo 2026-27 suit, dans l'ordre, tout le plan de la FC 2025-26 (8 pages), et
l'allonge à 11 pages :

| FC 2025-26 | Ronéo 2026-27 |
|---|---|
| I-III. Introduction, réponses innée et acquise (p. 2) | p. 2 |
| IV.A Schéma, réponses insuffisante et excessive, stratégies, risques (p. 3) | p. 3 |
| Anti-CD3, IL-1, ciclosporine, mTOR, récepteur de l'IL-2, TNF (p. 3-4) | p. 3-5 |
| IL-6, antimétabolites (p. 5) | p. 5-6 |
| Alkylants, intercalants, poisons du fuseau, rituximab (p. 6) | p. 5-7 |
| Natalizumab (p. 6-7) | p. 7 |
| Immunoglobulines, vaccins (p. 7) | p. 8 |
| Checkpoints (p. 7-8) | p. 9-10 |
| CAR-T, IL-2, interférons (p. 8) | p. 10-11 |
| — | **nouveau** : l'abatacept (p. 4), NFAT (p. 4), l'étanercept récepteur soluble (p. 4), les JAK, les anti-IL-17 et anti-IL-5 (p. 5), la sélectivité des traitements (p. 6), le méthotrexate antifolate (p. 6), les anti-CD20 dans la SEP et les anti-CD19 (p. 6-7), la LEMP et le virus JC (p. 7), le fingolimod (p. 8), les vaccins (p. 8, « pas détaillés »), le mécanisme de CTLA-4 (p. 9), les CAR-T anti-CD19 (p. 10) |

## Le réalignement du 19/10/2026

Les 102 notes de la version 2025-26 ont été relues une à une contre la ronéo, et
leurs figures avec elles.

**Relues et confirmées (74 notes de cours et marches, et les 6 termes du
lexique), qui citent désormais leur page de l'année** et perdent le badge « Cours
2025-26 » :

| Page | Notes |
|---|---|
| 2 | `imt-qc-inne`, `imt-qc-acquise`, `imt-rv-humorale-cellulaire`, `imt-fa-inne`, `imt-fa-acquise` ; `imt-ech-s1`, `imt-ech-s2` |
| 3 | `imt-qc-reponses`, `imt-qc-strategies`, `imt-qc-anti-cd3`, `imt-qc-risques`, `imt-fa-reponses`, `imt-fa-strategies`, `imt-zo-cibles` ; `imt-ech-m7`, `-s7`, `-s9`, `-s10`, `-s11`, `-m6` |
| 4 | `imt-qc-il1`, `imt-qc-ciclosporine`, `imt-qc-il2-voie`, `imt-qc-anti-tnf`, `imt-qr-il1`, `imt-qr-calcineurine`, `imt-qr-mtor`, `imt-rv-gc-ciclosporine`, `imt-rv-anti-tnf`, `imt-fa-il2`, `imt-fa-anti-tnf`, `imt-pl-ciclosporine` ; `imt-ech-s4`, `-s5`, `-s6`, `-m1`, `-m2`, `-s8` |
| 5 | `imt-qc-il6`, `imt-qc-antimetabolites`, `imt-qc-antimetabolites-risques`, `imt-qr-impdh`, `imt-qr-dhodh`, `imt-rv-purine-pyrimidine`, `imt-fa-antimetabolites`, `imt-fa-alkylants`, `imt-zo-antiproliferatifs` ; `imt-ech-s12`, `-m3` |
| 6 | `imt-qc-alkylants`, `imt-qc-rituximab`, `imt-qr-dhfr`, `imt-qr-cd20`, `imt-rv-cd3-cd20` ; `imt-ech-s13`, `-s16` |
| 7 | `imt-qc-natalizumab` ; `imt-ech-s20`, `-m5` |
| 8 | `imt-qc-immunoglobulines` ; `imt-ech-s15` |
| 9 | `imt-qc-checkpoints`, `imt-rv-suppresseur-stimulant`, `imt-fa-checkpoints` ; `imt-ech-s17`, `-s18` |
| 10 | `imt-qc-cytokines-therapeutiques`, `imt-qr-sep`, `imt-qr-il2-rein`, `imt-rv-ifn`, `imt-fa-car-t`, `imt-fa-interferons` ; `imt-ech-s14`, `-m4` |

Une carte n'est confirmée que si sa notion centrale est dans le cours de l'année ;
chaque proposition ou chaque trou que seul le cours 2025-26 porte le dit dans sa
justification (« FC 2025-26, p. 3 ; la ronéo 2026-27 n'en parle pas ») : les
réactions d'hypersensibilité et le cortisol (`imt-qc-acquise` C, D), les
anti-inflammatoires « moins forts » et l'immunité innée peu visée
(`imt-qc-reponses` D, E), les sels d'or (`imt-qc-il1` C, D ; `imt-ech-s5`,
`imt-ech-m1` B), le léflunomide et les pyrimidines (`imt-qc-antimetabolites` C,
`imt-qr-dhodh`, `imt-qc-antimetabolites-risques` C-E), le rituximab dans le
lymphome (`imt-qc-rituximab` C), le cyclophosphamide des cancers
(`imt-qc-alkylants` E).

**Ce que la ronéo 2026-27 dit autrement, et ce qui a été réécrit** :

- **La réponse innée** est « rapide », non plus « immédiate » ; le macrophage est
  une « sentinelle » ; le complément participe à l'opsonisation, à
  l'inflammation et à la lyse, sans l'histamine : `imt-fa-inne` (deux trous
  changent : opsonisation, et les leucotriènes « favorisent » le
  chimiotactisme), `imt-qc-inne` A, B, E (le macrophage « libère », la bradykinine
  « participe » à la douleur, le complément sans l'histamine), `imt-ech-s2` B, la case « inne » du schéma de
  l'échelle et `reponses-innee-acquise.svg`, redessiné.
- **La réponse acquise** : une cellule présentatrice d'antigène présente un
  peptide sur le CMH, CD4 → CMH II, CD8 → CMH I ; les plasmocytes ; les Th1 et Th2
  ; « les CD4 ne produisent pas eux-mêmes les anticorps » : `imt-fa-acquise` (le
  sixième trou devient « anticorps »), `imt-rv-humorale-cellulaire`.
- **Les stratégies** : limiter l'activation (CD, costimulation), agir sur les
  cytokines à quatre niveaux (synthèse, cytokine, récepteur, signalisation),
  limiter la prolifération ou détruire ; les cancers « selon le traitement et la
  durée » : `imt-fa-strategies` (trous « activation », « détruire »,
  « cancers »).
- **Les glucocorticoïdes** diminuent l'IL-1, l'IL-2 et l'IL-6, et sont
  anti-inflammatoires ET immunosuppresseurs ; les sels d'or disparaissent :
  `imt-qr-il1` (question réécrite), `imt-rv-gc-ciclosporine`, la légende de
  `cibles-immunosuppresseurs-legende.svg`.
- **La voie de l'IL-2** : NFAT nommé, l'IL-2 qui « favorise la prolifération »
  (et non plus « grand booster »), les trois niveaux synthèse, récepteur,
  signalisation : `imt-fa-il2` (un trou ajouté, NFAT), `imt-qc-il2-voie`.
- **Le TNF** : l'étanercept est un récepteur soluble de fusion, pas un
  traitement de la maladie de Crohn ; le certolizumab neutralise le TNF ; la
  tuberculose est réactivée, pas créée : `imt-qc-anti-tnf`, `imt-rv-anti-tnf`,
  `imt-fa-anti-tnf`.
- **Les antimétabolites** : l'azathioprine devient mercaptopurine et métabolites
  thiopuriniques ; le mycophénolate agit par l'acide mycophénolique, sur les
  nucléotides guanyliques ; le méthotrexate est un antifolate (p. 6) :
  `imt-fa-antimetabolites` (le trou des bases puriques devient « guanyliques »),
  `imt-zo-antiproliferatifs`, `imt-ech-s12`, `-s13`, `-m3`.
- **Les anti-CD20** entraînent une déplétion des lymphocytes B, « un point
  important à retenir ++ », et se citent dans la SEP (ocrélizumab), non plus dans
  la polyarthrite : `imt-qc-rituximab`, `imt-qr-cd20`, `imt-rv-cd3-cd20` ;
  `imt-ech-s19` est absente.
- **Le natalizumab** est un anti-intégrine α4 qui bloque α4β1–VCAM-1, avec la
  LEMP : `imt-qc-natalizumab` (le Ronéosaure le fixait « sur les récepteurs
  VCAM-1 »).
- **Les CAR-T** sont modifiés « génétiquement », et certains visent CD19 :
  `imt-fa-car-t` (le troisième trou devient « génétiquement », un trou ajouté).
- **Les interférons** font entrer dans un état pseudo-grippal, « déprime »
  comprise : `imt-fa-interferons` (un trou ajouté), une marche neuve
  (`imt-ech-s21`), et la justification de l'annale 2021/2022 S1 Q. 6 A, qui
  trouve sa réponse dans le cours de l'année.
- **Les erreurs du Ronéosaure 2025-26 que la ronéo 2026-27 dit juste** ne sont
  plus portées par les cartes, qui suivent l'année : « PI1 », la calmoduline
  bloquée, « l'IL-2 va attaquer le target of rapamycine », l'azathioprine qui
  « permet » la duplication, le natalizumab sur « les récepteurs VCAM-1 », « on
  boost la réponse de la CPA », « bloquer IL-2 » dans le cancer du rein,
  « il n'existe pas d'anti IL-6 » (dit sans ATTENTION dans `imt-qc-il6` A).

**Notes nouvelles (15)**, sur ce que le cours 2026-27 apporte :

| Note | Ce qu'elle carte |
|---|---|
| `imt-qc-anti-tnf-il6` | l'étanercept récepteur soluble, pas dans la maladie de Crohn ; la tuberculose réactivée ; l'IL-6R et non l'IL-6 ; les glucocorticoïdes sur IL-1, IL-2, IL-6 (p. 4-5) |
| `imt-qc-cibles-maladie` | les inhibiteurs de JAK, petites molécules ; les anti-IL-17 (psoriasis, candidoses, pas de MICI) ; les anti-IL-5 (asthme sévère éosinophilique) (p. 5) |
| `imt-qc-selectivite` | la muqueuse digestive, la thérapie ciblée qui « n'existe pas réellement », l'anticorps qui n'agit pas que sur l'organe malade, la génétique, les traitements conventionnels (p. 5-6) |
| `imt-qc-methotrexate` | molécule ancienne, psoriasis, antifolate, folates réduits, faibles doses (p. 6) |
| `imt-qc-anti-cd20` | la déplétion des LB, l'ocrélizumab dans la SEP, les anti-CD19 des neuromyélites optiques (p. 6-7) |
| `imt-qc-natalizumab-lemp` | α4β1–VCAM-1, la LEMP et le virus JC, les anticorps anti-JC, l'IRM de contrôle, l'anti-α4β7 de la maladie de Crohn (p. 7) |
| `imt-qc-fingolimod` | S1P1, les lymphocytes retenus dans les ganglions, la voie orale, la bradycardie (p. 8) |
| `imt-qc-costimulation` | CD28 et B7, CTLA-4 d'affinité supérieure, l'abatacept, l'anti-CTLA-4 et le mélanome (p. 4, 9) |
| `imt-qr-jak`, `imt-qr-virus-jc` | deux QROC : les Janus kinases (p. 5), le virus JC (p. 7) |
| `imt-rv-abatacept-ipilimumab` | abatacept et anti-CTLA-4 : l'un freine, l'autre relance (p. 4, 9) |
| `imt-rv-shingrix` | le vaccin du zona, recombinant adjuvanté, non vivant (p. 8) |
| `imt-ech-s21` | une marche Simple : l'état pseudo-grippal des interférons (p. 10) |
| `lex-antifolate`, `lex-calcineurine` | deux termes du lexique (p. 6 ; p. 3-4) |

## Ce que le cours a dicté

- **« Il faut surtout retenir les schémas et les mécanismes, plutôt que tous les
  noms de médicaments et toutes leurs indications »** (p. 2) ; « à retenir :
  situer la cible, comprendre le mécanisme et relier l'immunosuppression au
  risque infectieux » (p. 5, 8) ; « les noms des médicaments (ceux sur lesquels il
  a le plus insisté mais sinon pas important) » (p. 11). D'où deux schémas à
  cliquer, une planche, une figure du cours sur chaque QCM, et des cartes qui
  demandent le mécanisme ; les noms que posent les annales (azathioprine,
  méthotrexate, ciclosporine, interférons, natalizumab) se cartent.
- **« Le prof insiste sur cela ++ »** : ce que les traitements peuvent faire
  (p. 3) — `imt-fa-strategies`, `imt-qc-strategies`.
- **« Un point important à retenir ++ »** : les anti-CD20 (p. 6) —
  `imt-qc-anti-cd20`, `imt-qc-rituximab`, `imt-qr-cd20`.
- **Le gris** : deux « précisions du prof » (p. 6 : la thérapie ciblée « n'existe
  pas réellement » ; p. 7 : la SEP plus fréquente chez les femmes). La ronéo ne
  définit pas son gris comme hors programme : il se carte (`imt-qc-selectivite`
  B ; la SEP chez la femme n'a pas de carte, faute de question qui la demande).
- **Les vaccins**, « le prof n'a pas détaillé cette partie » (p. 8) : une seule
  carte, `imt-rv-shingrix`, pour l'erreur de la ronéo.
- **Les immunoglobulines antilymphocytaires** : « sans demander d'en retenir les
  détails » (p. 6) — pas de carte, comme en 2025-26.
- **Ce qui n'est pas carté ici** (plan C14) : la physiologie de l'immunité (UE
  d'immunologie ; ce chapitre n'en carte que ce qui sert de cible), les
  glucocorticoïdes du diabète et de l'os (FC n°7), le méthotrexate de la
  pharmacocinétique (FC n°2) et de la variabilité (FC n°5) ; ni la myasthénie, ni
  le suivi des maladies neurologiques (Parkinson, Alzheimer, schizophrénie,
  p. 7), cités en passant.

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| L'inhibition du TNF « sur la cytokine et sur son récepteur » | 9 : 2024/2025 S1, 2022/2023 S1, 2021/2022 S2, 2020/2021 S1, 2019/2020 S1, 2018/2019 S1, 2017/2018 S1, 2016/2017 S2, 2015/2016 S2 |
| Checkpoints (CTLA-4, PD-1), natalizumab et SEP, anti-CD20 et polyarthrite, risque infectieux des anti-intégrines | 2024/2025 S1 Q7 |
| Le méthotrexate et les folates (vitamine B9, piège B12) | 8 : 2023/2024 S1, 2022/2023 S2, 2021/2022 S1, 2020/2021 S2, 2018/2019 S2, 2017/2018 S1, 2016/2017 S2, 2015/2016 S2 |
| Les interférons dans la SEP (bêta vrai ; alpha et gamma faux) | 8 sessions |
| L'interleukine des glucocorticoïdes, des sels d'or, de la ciclosporine (IL-1, IL-2 ; pièges IL-8, IL-17, TNF) | 13 propositions, 13 sessions |
| L'interaction antigène-cellule dont l'ACTIVATION immunosupprimerait | 5 : 2019/2020 S1, 2018/2019 S1, 2017/2018 S2, 2016/2017 S1, 2015/2016 S1 |
| L'azathioprine « anti-pyrimidine » (toujours faux) | 4 : 2023/2024 S1, 2022/2023 S2, 2021/2022 S1, 2020/2021 S2 |
| Infection et cancer, risques de l'immunosuppression | 2018/2019 S1, 2017/2018 S2, 2016/2017 S1 et les questions du TNF |
| Alkylants, DHODH, muromonab-CD3, interférons et dépression | 2021/2022 S1 Q. 6 |
| Les AINS (axe corticotrope, antiagrégation) | 2015/2016 S1 Q6 |

Chaque session a sa carte, même quand la question se répète ; l'explication
renvoie aux autres. Relues sur la ronéo 2026-27 : aucune clé ne change ; les
justifications citent la ronéo 2026-27 à sa page, ou la FC 2025-26 quand la notion
n'est plus qu'à elle (le cortisol, les sels d'or, le léflunomide, le rituximab
dans la polyarthrite).

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2022/2023 S2 Q5 | CE | **ACE**, `officielle=False` | le A (« la diminution de synthèse du TNF-alpha et de l'IL-2 favorise les complications infectieuses ») manque : vrai en 2023/2024 S1 et 2021/2022 S1, errata des annales de la promo, ronéo 2026-27 p. 3 et 5 |
| 2020/2021 S2 Q.5 | CE | **ACE**, `officielle=False` | même cas (« l'inhibition de la synthèse… ») |
| 2024/2025 S1 Q6 (`imt-an-2425s1-q6`) | aucune (sujet sans corrigé) | **CE**, `officielle=False` | reprise de 2022/2023 S1 Q. 5 (BCE), le cortisol devenu « immunostimulant » : il calme le jeu (FC 2025-26, p. 3) ; l'IL-2 est l'acquis, pas l'inné (p. 2, 4) ; les sels d'or, l'IL-1 seule (FC 2025-26, p. 4) ; le TNF « sur son récepteur », vrai comme ailleurs (ATTENTION (cours), CONFLITS) |
| 2024/2025 S1 Q7 (`imt-an-2425s1-q7`) | aucune (sujet sans corrigé) | **ACDE**, `officielle=False` | checkpoints CTLA-4 et PD-1 (p. 9 ; « CT8 » et « PQ-1 » n'existent pas) ; natalizumab dans la SEP et ses infections (p. 7), anti-CD20 dans la polyarthrite (FC 2025-26, p. 6) |

Toutes les autres clés sont reprises telles quelles. Dix points sont discutés
dans la carte (`ATTENTION`, déclarés dans `CONFLITS`), sans changer la clé :

| Question | Clé | Le point | À l'examen |
|---|---|---|---|
| 2024/2025 S1 E, 2022/2023 S1 E, 2021/2022 S2 E, 2020/2021 S1 E, 2019/2020 S1 E, 2018/2019 S1 B, 2017/2018 S1 A, 2016/2017 S2 A, 2015/2016 S2 A | vrai | l'inhibition du TNF « sur son récepteur » : c'est le cours (le certolizumab sur la diapositive, 2025-26 comme 2026-27), mais aucun médicament ne bloque le récepteur du TNF, et le texte de la ronéo 2026-27 le corrige ; **ATTENTION (cours)** depuis le 19/10 | vrai |
| 2019/2020 S1 Q. 6 A | faux | « la réponse innée peut survenir après la réponse acquise » : la chronologie du cours dit non, mais l'acquis réemploie des effecteurs innés (complément, macrophages) — point douteux, ATTENTION nu | faux |

Sans objet : l'errata des annales croit la table de 2019/2020 S1 fautive sur le
D (ciclosporine et TNF) ; elle imprime CE, D faux. Et il range 2021/2022 S1
parmi les tables qui oublieraient le A : elle imprime ACE.

Les propositions absentes des deux cours, reprises comme la clé et justifiées :
l'IL-8 et l'IL-17 (les glucocorticoïdes visent l'IL-1, l'IL-2 et l'IL-6,
p. 4) ; les AINS de 2015/2016 S1, absents aussi des cours 2023-24 et 2024-25 du
même professeur — la FC n°3 2025-26 (p. 8, l'aspirine et la COX-1 plaquettaire)
et la FC n°7 (p. 7, l'axe CRH-ACTH-cortisol) répondent. La dépression sous
interféron, absente du ronéo 2025-26, est dans la ronéo 2026-27 (« déprime »,
p. 10).

## Les erreurs de la ronéo 2026-27

Le tableau d'erreurs BMCT de la promo ne dit rien de ce ronéo au 19/10 : toutes
les erreurs ci-dessous ont été trouvées en relisant, et vont dans
`contenu/ERRATA_RONEOS_2026-27.md` (à reporter). Aucun ronéo n'est corrigé ;
chaque erreur est portée par une carte, avec son genre. À l'examen, on répond
d'abord comme le professeur.

**Prises de notes fausses** (`ATTENTION (prise de notes)`) :

| Page | La ronéo dit | Ce qui est juste | Carte |
|---|---|---|---|
| 8 | les immunoglobulines non spécifiques « dans le cas d'un déficit en anticorps, quand le système immunitaire est défaillant (Ex : le syndrome de Guillain-Barré) » | la diapositive de la même page sépare le déficit immunitaire et la « maladie résultant d'une agression infectieuse (PTI, Guillain-Barré) » ; la même ronéo dit le Guillain-Barré une réponse « inadaptée » (p. 3) ; les Ig y modulent une réponse pathologique | `imt-qc-immunoglobulines` (A), `imt-ech-s15` (B) |
| 8 | « Vaccin contre le zona recombinant adjuvanté (Shingrix) : Vaccin vivant atténué » | non vivant : une protéine du virus (glycoprotéine E) et un adjuvant (EMA) ; c'est pourquoi il se donne à l'immunodéprimé, à qui le vaccin vivant Zostavax était contre-indiqué (Vidal ; HAS 2024) | `imt-rv-shingrix` |

**C'est le cours lui-même** (`ATTENTION (cours)` : « À l'examen : … », puis « La
référence : … ») — quatre diapositives que la ronéo reproduit, et que son texte
corrige :

| Page | Le cours dit | La référence | Carte |
|---|---|---|---|
| 4 | la diapositive place le certolizumab sur le récepteur du TNF ; huit sessions corrigées du polycopié, et le sujet 2024/2025, donnent vraie l'inhibition du TNF « sur son récepteur » (le texte de la ronéo corrige) | aucun médicament ne bloque le récepteur du TNF ; l'étanercept est un récepteur soluble (p75-Fc), le certolizumab pegol un Fab' anti-TNF (RCP Enbrel, Cimzia) ; à l'examen : vrai | `imt-qc-anti-tnf`, `imt-rv-anti-tnf`, `imt-ech-s6`, `imt-ech-m2`, et les neuf annales (`imt-an-2425s1-q6`, `-2223s1-q5`, `-2122s2-q6`, `-2021s1-q6`, `-1920s1-q6`, `-1819s1-q3`, `-1718s1-q5`, `-1617s2-q5`, `-1516s2-q6`) |
| 4 | la ciclosporine, « Origine végétale (champignon) » (la ronéo corrige : « d'origine fongique ») | un peptide cyclique isolé du champignon Tolypocladium inflatum ; les champignons ne sont pas des végétaux ; à l'examen : comme la diapositive, et « fongique » si les deux s'opposent | `imt-qc-ciclosporine` (A), `imt-fa-il2` |
| 3 | le schéma de gauche range le syndrome de Guillain-Barré et le PTI sous la réponse INSUFFISANTE (la ronéo corrige : « réponse immunitaire inadaptée ») | deux maladies auto-immunes : auto-anticorps antiplaquettes (PNDS PTI, HAS), auto-anticorps antigangliosides par mimétisme moléculaire (Yuki et Hartung, NEJM 2012) ; à l'examen : le schéma, ou « inadaptée » si la question oppose les deux | `imt-fa-reponses` |
| 3 | le schéma de droite range « inh mTOR » avec l'anticalcineurine sous « ↓ Σ (Il-1, Il-2) » (la ronéo corrige : les inhibiteurs de mTOR ne diminuent pas la synthèse d'IL-2) | le sirolimus inhibe mTOR sans agir sur la calcineurine et bloque la prolifération induite par l'IL-2 (notice de Rapamune, FDA) ; à l'examen : mTOR, en aval du récepteur | `imt-qc-il2-voie` (C) |

**Points douteux** (`ATTENTION (douteux)`), dits dans la carte sans changer sa clé :

| Page | Le point | Carte |
|---|---|---|
| 8 | l'anti-VRS, « traitement utilisé chez tous les nouveau-nés prématurés » : c'est une prévention, et le palivizumab est réservé aux enfants à haut risque (≤ 35 SA et < 6 mois, dysplasie bronchopulmonaire, cardiopathie ; RCP Synagis, EMA) ; le nirsévimab se donne à tous les nourrissons depuis 2023 | `imt-qc-immunoglobulines` (C) |
| 9 | « avant, un mélanome trop gros pour être retiré ne pouvait pas être traité par chimiothérapie » : la dacarbazine le traitait, sans gain de survie ; l'ipilimumab est le premier à l'avoir allongée (Hodi et al., NEJM 2010) | `imt-qc-costimulation` |
| 10 | le nivolumab « ne marche pas très bien » dans les cancers « du poumon et du pancréas » : vrai du pancréas, pas du poumon, l'une de ses grandes indications (cancer bronchique non à petites cellules, EMA 2015) | `imt-qc-checkpoints` |
| 11 | « pour l'hépatite B on a maintenant le vaccin qui est plus efficace » : le vaccin prévient, il ne traite pas ; l'hépatite B chronique se traite par l'entécavir ou le ténofovir, l'interféron alpha pégylé restant une option (Manuel MSD) | `imt-fa-interferons` |

Sans ATTENTION : les coquilles de la diapositive, « Basixilimab, Dacliximab »
(p. 4), que la ronéo corrige (`imt-qc-il2-voie` E) ; « B7-fi » pour B7-1
(p. 9) ; « PTI (purpura thrombopénique idiopathique) » (p. 3), l'ancien nom du
purpura thrombopénique immunologique (dit dans `imt-fa-reponses`) ; « anti-CTL4 »
(p. 9) ; les vaccins à ARN « pour tous les virus à COVID » (p. 8), imprécis et
sans carte.

## Les erreurs du Ronéosaure 2025-26

Le Ronéosaure n'est pas le ronéo de l'année : ses erreurs sont dites par un
**ATTENTION nu**, et n'entrent pas dans `contenu/ERRATA_RONEOS_2026-27.md`.
Celles que la ronéo 2026-27 dit juste ne sont plus portées (voir plus haut).
Restent, parce que leur carte suit encore le cours 2025-26 :

| Page | Le Ronéosaure dit | Retenu | Carte |
|---|---|---|---|
| 5 | léflunomide : « les mêmes toxicités classiques sauf ici l'hépatotoxicité » | avec, en plus, l'hépatotoxicité (diapositive ; RCP Arava) | `imt-qc-antimetabolites-risques` D |
| 5 | « Zophren (anti-H3) » | ondansétron, antagoniste 5-HT3 | `imt-qc-antimetabolites-risques` E |

## Les schémas et les figures

**Les figures.** Les diapositives que la ronéo 2026-27 reproduit aux p. 3-7 (les
deux schémas, le muromonab, la ciclosporine, le sirolimus, l'anti-récepteur de
l'IL-2, l'anti-TNF, le mycophénolate, l'azathioprine, le natalizumab) sont celles
de 2025-26, en 410 px de large : on garde les extractions nettes de la FC 2025-26
(1000 px), et la légende cite les deux pages. Celles des p. 8-10
(immunoglobulines, anti-CTLA-4, anti-PD-1, CAR-T, interférons) sont plus nettes
dans la ronéo 2026-27 (1100 à 1350 px) : elles ont remplacé les fichiers de
2025-26, sous le même nom, réduites à 1000 px et en 256 couleurs ; leur source est
la ronéo 2026-27. Les huit diapositives que la ronéo 2026-27 n'a plus (synthèse
des cytokines, IL-1, anti-IL-6, léflunomide, méthotrexate, alkylants, rituximab,
IL-2) restent celles de 2025-26, et leur légende le dit. Le muromonab de la
ronéo 2026-27 est coupé en bas (l'efalizumab, le bélatacept, l'abatacept) : la
version 2025-26 est entière.

**Deux schémas cliquables** (`schemas.py`), chacun avec sa version légendée en
correction :

| Fichier | Ce qu'on clique | Pourquoi ce dessin |
|---|---|---|
| `cibles-immunosuppresseurs.svg` | où agit : l'anti-CD3 (activation), la ciclosporine ou un glucocorticoïde (synthèse), l'anti-TNF (cytokine libre), l'anti-récepteur de l'IL-2 ou de l'IL-6, le sirolimus (mTOR), un antimétabolite ou un alkylant (prolifération), l'anti-CD20 (lymphocyte B), le natalizumab (BHE) — 8 zones | le schéma général « à retenir » (p. 3), déplié en étapes ; le dessin nu nomme les structures, jamais les médicaments ; la version légendée nomme aussi le fingolimod (p. 8) et les glucocorticoïdes sur IL-1, IL-2, IL-6 (p. 4) |
| `antiproliferatifs.svg` | où agit : le méthotrexate (DHFR), le mycophénolate (IMPDH), le léflunomide (DHODH), l'azathioprine (nucléotides puriques), un alkylant (ADN), un intercalant (réplication), un poison du fuseau (mitose) — 7 zones | les p. 5-6 et les diapositives de la FC 2025-26 (p. 5-6) ; sur le dessin nu, les trois enzymes sont des cases vides |

**Une planche à légender**, `imt-pl-ciclosporine` : la diapositive de la
ciclosporine (FC 2025-26 et ronéo 2026-27, p. 4), sept légendes effacées et six
intrus ; son titre dit désormais « issu d'un champignon », et ses notes suivent
la ronéo 2026-27 (NFAT, la cyclophiline « pas un autre médicament »).

**Une figure redessinée** pour les corrections : `reponses-innee-acquise.svg`,
refaite sur la ronéo 2026-27 (p. 2-3), le cortisol et l'hypersensibilité marqués
« FC 2025-26 ».

**74 QCM sur 74 illustrés (100 %)** — 27 du cours, 19 des annales, 28 marches —,
108 notes sur 117 (les huit termes de lexique et `imt-rv-shingrix` n'ont pas
d'image).

## Le lexique

Huit termes ; pages mesurées dans le texte de la ronéo 2026-27 (en-têtes
exclus), puis de la FC 2025-26 :

| Terme | Origine | Pages 2026-27 |
|---|---|---|
| Immunosuppresseur | latin immunis + supprimere | 1, 2, 3 (les p. 5, 8 et 11 disent « immunosuppression ») |
| Immunostimulant | latin immunis + stimulare | 1, 2, 8 |
| Immunomodulateur | latin immunis + modulari | 1, 3, 6 |
| Antimétabolite | grec antí + metabolḗ | 3, 5 |
| Alkylant | latin des alchimistes alcohol (de l'arabe kuḥl) + grec húlē | 3, 5 |
| Intercalant | latin intercalare | 5 |
| **Antifolate** (nouveau) | grec antí + latin folium | 6 |
| **Calcineurine** (nouveau) | latin calx + grec neûron (Klee et al., PNAS 1979) | 3, 4 |

Les deux termes nouveaux reprennent des racines de la table commune (`anti-`,
`calc- (latin)`, `neur(o)-`, qui cite la FC de sémantique 1/2, p. 4) ; une racine
(`folium (latin)`) et les deux termes sont proposés à `etymologies.json`
(brouillon `etym/bmct_immunitaire.json`), que Claude fusionne ; les textes du
lexique sont déjà écrits dans la forme que `appliquer_etymologies.py` produirait.
Aucun des deux n'existait dans un autre paquet. Cytokine, interleukine,
interféron, costimulation, intégrine, anergie, leucoencéphalopathie et
opsonisation restent à l'UE d'immunologie ou de virologie, qui les accueille.

## Absent du cours 2026-27

Trois cartes **entières** que la ronéo du 12/10/2026 ne porte plus. Elles restent,
citent la FC n°6 2025-26 (sans `page`, donc avec le badge « Cours 2025-26 »),
prennent le tag `absent-2026` et la phrase « Absent du cours 2026-27 » en tête de
l'explication (`ABSENTS_2026`, `ORIGINE_ABSENTS`) :

| Carte | Ce que le cours 2026-27 ne dit plus |
|---|---|
| `imt-ech-s3` | le cortisol qui monte pendant une infection « pour calmer le jeu » (la marche prépare toujours le B des annales du cortisol) |
| `imt-ech-s19` | l'anti-CD20 qui « a révolutionné la polyarthrite rhumatoïde » (la marche prépare toujours le D de 2024/2025 S1 Q7) |
| `imt-qr-risque-allergique` | le risque allergique qui « marche toujours » ; la ronéo 2026-27 rappelle au contraire que les effets indésirables dépendent de la molécule (p. 5) |

## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026 ; relue le 19/10)

L'échelle du pilote de l'immunité innée, étendue à la BMCT pour l'examen du 4/11
(Vincent, 16/10 : « on continue pour les chapitres que je vais avoir à
l'examen »). Sous les annales, 21 cartes Simple (`niveau-simple`, une idée, trois
choix, le schéma troué dans la question) et 7 cartes Moyen (`niveau-moyen`, une
paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde
la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `cibles-immunitaires` | 0 | 1 | 1 |
| `anti-cytokines` | 6 | 2 | 8 |
| `antiproliferatifs` | 6 | 2 | 6 |
| `anticorps-cibles` | 4 | 1 | 1 |
| `risques-immunosuppression` | 5 | 1 | 3 |

**Le schéma** `ech-immunomodulateurs`, « Les immunomodulateurs · où agit chaque
classe », donne 48 fichiers (complet, troués, à lettres). Il est décrit dans
`schemas.py` (`ECH_IMMUNOMODULATEURS`, `TROUS_*`, `LETTRES_*`) et dessiné par
`echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à
la fin de `donnees.py`, entre deux marqueurs.

**Relue sur la ronéo 2026-27 (19/10)** : chaque marche cite sa page de l'année, et
ses justifications la suivent. Trois lignes du schéma changent, avec les cartes
qui s'y appuient : la réponse innée « rapide » (et non « immédiate » :
`imt-ech-s2` B), l'IL-2 « moteur de leur prolifération » (et non « booster de
l'acquis »), et l'effet des interférons, « pseudo-grippal : fièvre, déprime »
(et non « fièvre, fatigue »), sur lequel se pose la marche neuve **`imt-ech-s21`**
(clé C), qui prépare l'annale 2021/2022 S1 Q. 6 A. Les clés Simple restent
réparties (7 A, 7 B, 7 C) ; la légende du schéma cite la ronéo 2026-27 et la FC
2025-26. Deux marches sont absentes du cours 2026-27 (`imt-ech-s3`, `imt-ech-s19`,
voir plus haut) : leurs lignes, vraies, restent sur le schéma (le cortisol, la
polyarthrite rhumatoïde de l'anti-CD20). Les marches `imt-ech-s6` et `imt-ech-m2`
(le TNF « sur son récepteur ») portent l'ATTENTION (cours), `imt-ech-s15`
l'ATTENTION (prise de notes) des immunoglobulines.

**Sans marche** :
- imt-an-1516s1-q6 A, B : les AINS (axe hypothalamo-hypophysaire, antiagrégation)
  ne sont dans aucun des deux cours du chapitre, la FC n°3 et la FC n°7 2025-26
  répondent ; A est posée sur la case du cortisol, B n'a pas de case et reste sans
  lettre.

## À relire

**Aucune carte `a-relire`** : chaque note cite une page de la ronéo 2026-27 ou,
pour les trois absentes, de la FC 2025-26 ; chaque annale du polycopié a une clé
imprimée vérifiée, et les deux du sujet 2024/2025 une clé déduite page par page.
Reste à Vincent :

- `copier_les_cours.py` avec le dossier des ronéos du 19/10, hors du bac à sable,
  pour que la fiche de l'année s'ouvre dans l'application ;
- les deux termes et la racine nouvelle à fusionner dans `etymologies.json` ;
- les erreurs de la ronéo à reporter dans `contenu/ERRATA_RONEOS_2026-27.md`.

## Décisions prises en route

- **Une carte n'est confirmée que si sa notion centrale est dans le cours de
  l'année** ; ses propositions de 2025-26 le disent une à une. Trois cartes sont
  absentes ; aucune n'est supprimée.
- **Le TNF « sur son récepteur » reste vrai** : la diapositive de 2026-27 est celle
  de 2025-26, et c'est elle que suivent les annales ; le texte de la ronéo qui la
  corrige n'est pas attribué au professeur (voir les questions). L'ATTENTION
  devient « (cours) » sur les treize cartes qui le portent.
- **Les figures identiques** restent celles de la FC 2025-26, plus nettes ; les
  cinq figures plus nettes en 2026-27 remplacent les anciennes sous le même nom.
- **La ciclosporine « d'origine végétale (champignon) »** (`imt-qc-ciclosporine`
  A) reste vraie, comme la diapositive ; la planche dit « issu d'un champignon ».
- **`EXAMENS` n'est pas déclaré** (décision de FC1) : le partiel du 4/11 se règle
  dans l'application.
- **Les deux A manquants** (2022/2023 S2, 2020/2021 S2) restent rétablis : trois
  preuves concordantes (deux sessions, l'errata, le cours).
- **Aucune carte ne demande un nom en -imab** ; les noms apparaissent dans les
  justifications. Le rituximab, le natalizumab et le fingolimod nomment leur carte,
  parce que la question porte sur le mécanisme.

## Contre-relecture du 19/10/2026

Un sceptique a relu chaque carte nouvelle ou changée contre la page de la ronéo
qu'elle cite (texte et image), les clés d'annales, les figures, les schémas et le
lexique. Aucune clé ne change, aucune note n'est retirée ; il a corrigé :

- `imt-qc-il6` E : « comme l'IL-2 » venait du cours 2025-26 ; la ronéo 2026-27 dit
  l'IL-6 « autre cible importante » après le TNF-α, et la justification le dit ;
- `imt-qc-acquise` A et `imt-ech-m1` D : le macrophage, les LT « naïfs » et
  « de manière extrêmement puissante » sont des formules de 2025-26, qui le disent ;
- `imt-ech-s6`, `imt-ech-m2` : « les neuf sessions » devient « les huit sessions
  corrigées, comme le sujet 2024/2025 » ;
- `imt-fa-interferons` : la diapositive range aussi un interféron bêta en
  intramusculaire (Avonex), à côté du sous-cutané de la ronéo ;
- le lexique : « immunosuppresseur » est aux p. 1-3 de la ronéo (mesuré) ; les
  p. 5, 8 et 11 disent « immunosuppression » ;
- les renvois de l'échelle aux annales : « (B, ,,  , C) », un reste de l'outil du
  pilote, devient « (B, C) ».

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```

## Questions pour Vincent

1. (19/10) **Les quatre « précisions sur le diapo » de la ronéo 2026-27** (le
   certolizumab qui neutralise le TNF-α « et non son récepteur », la ciclosporine
   « d'origine fongique », le Guillain-Barré et le PTI en réponse « inadaptée »,
   les inhibiteurs de mTOR qui ne diminuent pas la synthèse d'IL-2) ne disent pas
   si elles viennent du professeur ou des rédacteurs, alors que la ronéo marque
   ailleurs ses « précisions du prof ». Les cartes répondent comme la diapositive
   et les annales (le TNF « sur son récepteur » : vrai). Si le Pr Devos l'a dit en
   cours, la réponse attendue au partiel pourrait changer : le sais-tu ?
2. (19/10) **Les vaccins**, « pas détaillés » par le professeur : une seule carte,
   `imt-rv-shingrix`, pour l'erreur de la ronéo (« vivant atténué »). La garder ?
3. (19/10) **Les cinq figures des p. 8-10** (immunoglobulines, anti-CTLA-4,
   anti-PD-1, CAR-T, interférons) ont été remplacées par leurs versions 2026-27,
   plus nettes, sous le même nom de fichier. D'accord ?
4. (02/10, toujours ouverte) **Le squelette numérote l'UE à la 2024-25** :
   `chap-ue-bmct-fc6` y est « Pharmacodynamie de la neurotransmission », `fc8` le
   système immunitaire. Ce chapitre suit la numérotation 2025-26 (`fc6` =
   immunitaire) ; le paquet de contenu l'emporte à l'import.
