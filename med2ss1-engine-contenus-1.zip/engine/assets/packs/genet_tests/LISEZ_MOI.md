# Tests génétiques : interprétation, règles de bonne pratique et législation — paquet Génétique

101 notes, 166 cartes. Chapitre `chap-ue-genetique-fc1` de l'UE Génétique,
premier de l'UE. Cours du **Pr Florence Petit, le 17/11/2025, de 8 h à
9 h 30**, dans le **Ronéosaure 2025-26** (FC n°1, 17 pages) ; les annales de
trois polycopiés du Ronéosaure 2024-25 (17 sessions). Examen : mercredi
16 décembre 2026.

**Fiche provisoire** (C15, décision de Vincent du 02/10) : le ronéo 2026-27 de
ce cours n'est pas encore paru. Chaque carte de cours cite la FC 2025-26 à sa
page et porte le badge « Cours 2025-26 » ; le ronéo 2026-27 la corrigera quand
il sortira. Aucune carte n'est « Absent du cours 2026-27 ».

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 66 | 66 |
| Texte à trous | 13 | 68 |
| QROC | 8 | 8 |
| Recto-verso | 4 | 4 |
| Schéma cliquable | 2 | 12 |
| Lexique | 8 | 8 |

Dont **46 annales** sur 17 sessions (2015/2016 à 2023/2024), toutes des QCM :
43 du polycopié des tests génétiques, 3 du polycopié des maladies mendéliennes
(la surdité de 2019/2020 S1 Q. 29-30, Pierre de 2019/2020 S2 Q. 1). 20 QCM de
cours. **63 QCM sur 66 sont illustrés** (95 %).

Huit thèmes, dans l'ordre du cours, tous nouveaux ; leurs libellés restent à
ajouter à `THEME_LABELS` (`app/src/med_engine/application/scopes.py`). Trois
sont partagés avec les chapitres de cytogénétique et de séquençage (plan C15).

| Clé | Libellé | Notes | dont annales |
|---|---|---|---|
| `genome-humain` | Le génome humain : chromosomes, gènes, exons | 8 | 4 |
| `resolution-couverture` *(partagée)* | Résolution et couverture des tests génétiques | 16 | 7 |
| `interpretation-variants` *(partagée)* | Interpréter une variation génétique | 8 | 2 |
| `donnees-additionnelles` *(partagée)* | Données incidentes et données secondaires | 16 | 8 |
| `bioethique` | Lois de bioéthique et encadrement des tests | 11 | 7 |
| `consentement-rendu` | Consentement, rendu du résultat, information de la parentèle | 19 | 15 |
| `diagnostic-prenatal` | Diagnostic prénatal, préimplantatoire et IMG | 8 | 0 |
| `medecine-predictive` | Conseil génétique et médecine prédictive | 7 | 3 |

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-genet-tst-2526` — Ronéosaure, « FC n°1 -Tests génétiques _ Interprétation, règles de bonne pratique et législation .docx-3.pdf » (17 p.) | 2025-26 | le cours ; `SRC["fiche"]`, ses figures |
| `src-annales-1-tests-genetiques-interpretation-regles-de-bonne-pratique-et-legislation` — « 1 - Tests génétiques _ interprétation règles de bonne pratique et législation » | 2024-25 | 43 questions, table p. 15 ; toutes les annales le citent |
| `src-annales-5-maladies-genetiques-de-transmission-mendelienne` — « 5. Maladies génétiques de transmission mendélienne » | 2024-25 | la vignette et l'arbre de la surdité (p. 15) et de Pierre (p. 16), table p. 20-21 |
| `src-annales-2-methodes-d-etudes-en-cytogenetique-conventionnelle-et-moleculaire` — « 2 - Méthodes d'études en cytogénétique conventionnelle et moléculaire » | 2024-25 | le caryotype de la Q12 de 2016/2017 S1 (p. 16) |

Le nom de la FC est en NFD sur le disque ; `chemin_relatif` l'écrit en NFC,
comme `outils/copier_les_cours.py` le compare. Les deux polycopiés partagés sont
déclarés exactement comme `genet_mendelien` et `genet_cytogenetique`.

**Une source par session** : le modèle ne connaît qu'une source par session, et
2019/2020 S1 et S2 mêlent des questions des polycopiés 1 et 5. Les trois
questions du polycopié 5 citent donc le polycopié 1 ; leur explication dit où
elles sont imprimées, et leurs arbres citent le polycopié 5.

Lus en appoint, sans être déclarés : l'errata des cours 2025-26 (« Erratas
Génétique.docx »), l'errata des annales 2024-25 (aucune entrée pour ce cours),
l'errata des cours 2024-25, les cours 2024-25 et 2023-24 du même cours. Les
en-têtes des ronéos, des erratas et des polycopiés portent des noms d'étudiants :
aucun n'est repris.

## Ce que le cours a dicté

- **Le rouge** : les seuls mots en rouge du ronéo sont ceux de la loi sur
  l'interruption de grossesse (p. 14) — à toute époque, deux médecins, forte
  probabilité, particulière gravité, incurable, centre de diagnostic prénatal
  multidisciplinaire. Tous sont des trous de `gte-fa-img`.
- **Le gris** est la voix des rédacteurs et se carte (décision du 25/09), sauf
  ce que la professeure a dit de laisser : le locus de DiGeorge (« pas à
  retenir », p. 2), les techniques épigénétiques (p. 2), le nom de STK11 (« ne
  pas retenir les noms », p. 8), les tests pharmacogénétiques (p. 10) et à des
  fins non médicales (p. 11), le DPI en détail (p. 15), la médecine prédictive
  en détail (p. 17), la dernière diapositive (p. 17). Ces notions ne sont citées
  que pour situer une carte.
- **Ce qui n'est pas carté ici** (plan C15, frontières) : ce que voit chaque
  technique de cytogénétique et DiGeorge (`genet_cytogenetique`), Sanger, haut
  débit et classes actionnables (`genet_sequencage`), translocations et
  Klinefelter (`genet_chromosomes`), modes de transmission et mucoviscidose
  (`genet_mendelien`), FMR1 (`genet_instables`), la pharmacogénétique
  (`bmct_variabilite`). Les cartes les citent.
- **Aucune photographie de patient** (Waardenburg, p. 6 et 12 ; Nail-patella,
  p. 12) ; les diapositives, le formulaire de consentement, la lettre aux
  apparentés et les dessins des prélèvements vont en correction.

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| Le test chez le malade : bioéthique, consentement écrit, attestation, rendu par le prescripteur en consultation, secret, parentèle | 2023/2024 S1 Q13, S2 Q1 ; 2022/2023 S2 Q1 ; 2021/2022 S1 Q25, S2 Q17 ; 2020/2021 S1 Q6 ; 2019/2020 S1 Q8 ; 2018/2019 S1 Q18 ; 2017/2018 S1 Q28, Q29, Q30, S2 Q30 ; 2016/2017 S1 Q11, S2 Q2, Q3 ; 2015/2016 S1 Q3, S2 Q2 |
| Données incidentes et secondaires | 2023/2024 S1 Q12, S2 Q13 ; 2022/2023 S1 Q16, S2 Q2 ; 2021/2022 S1 Q24, S2 Q7, Q8 ; 2020/2021 S1 Q8 |
| Résolution, couverture, ciblé ou pangénomique, ACPA | 2023/2024 S2 Q12 ; 2022/2023 S1 Q15 ; 2021/2022 S2 Q19 ; 2020/2021 S2 Q11 ; 2017/2018 S2 Q29 ; 2016/2017 S2 Q1 ; 2015/2016 S1 Q2 |
| Le génome humain, le capital génétique | 2022/2023 S1 Q4 ; 2015/2016 S1 Q1, Q24 ; 2015/2016 S2 Q1 |
| Situations autorisées, mineurs | 2021/2022 S1 Q27 ; 2016/2017 S1 Q14 E ; 2019/2020 S1 Q. 30 D |
| Médecine prédictive | 2020/2021 S2 Q9 ; 2018/2019 S1 Q17 |
| Cas cliniques | Pierre, 2019/2020 S2 Q. 1, Q2, Q3 ; la surdité CRYM, 2019/2020 S1 Q. 29-30 ; le couple, 2016/2017 S1 Q13-Q14 |

**Les copies**, une carte par session, l'explication renvoie aux autres :
2023/2024 S1 Q12 = 2020/2021 S1 Q8 ; 2023/2024 S1 Q13 ≈ 2021/2022 S1 Q25 ;
2016/2017 S2 Q2 = 2015/2016 S1 Q3 ; 2016/2017 S2 Q3 = 2015/2016 S2 Q2 ;
2016/2017 S2 Q1 ≈ 2015/2016 S1 Q2 ; 2017/2018 S1 Q28 ≈ 2019/2020 S1 Q8 ≈
2021/2022 S2 Q17.

**« Tout médecin peut prescrire »** se lit selon sa raison : vrai en
2022/2023 S1 Q15 E et 2019/2020 S1 Q. 29 D (s'il sait en expliquer les
impacts), faux en 2017/2018 S2 Q30 B (« dès lors que disponible ») et 2019/2020
S2 Q2 B (« une simple prise de sang »). Les justifications le disent.

### Les cas coupés entre deux polycopiés

- **Pierre (2019/2020 S2)** : la vignette, l'arbre et la Q. 1 sont au polycopié 5
  (p. 16), les Q2 et Q3 au polycopié 1 (p. 7-8), sans vignette. Les trois
  cartes portent l'arbre en question ; Q2 et Q3 reprennent la vignette en tête
  d'énoncé, entre crochets et dite telle.
- **La surdité CRYM (2019/2020 S1 Q. 29-30)** : vignette et arbre au polycopié 5
  (p. 15) ; les deux cartes portent l'arbre en question.
- **Le couple (2016/2017 S1 Q12-Q14)** : la Q12 (caryotype) est au polycopié de
  cytogénétique et se carte dans `genet_chromosomes` ; les Q13 et Q14 sont au
  polycopié 1 (p. 11), et **aucun polycopié n'imprime leur vignette ni leur
  arbre** (II1, II2, III1). Les deux cartes portent le caryotype de la Q12 en
  question et, en tête d'énoncé, un rappel entre crochets de ce qu'on sait du
  cas (fausses couches répétées, translocation réciproque équilibrée t(4;12)
  sur le caryotype féminin, III1 mineur en bonne santé).

## Les erreurs du ronéo 2025-26

Le Ronéosaure n'est pas le ronéo de l'année : chaque erreur est portée par un
**ATTENTION nu** dans la carte qui tient la notion, la sorte dite dans le texte,
et rien n'entre dans `contenu/ERRATA_RONEOS_2026-27.md`.

| Page | Le ronéo dit | Retenu | Sorte | Carte |
|---|---|---|---|---|
| 2 | DiGeorge, « une délétion du gène 11.2 » | la région 22q11.2 (FC2, p. 7) ; locus « pas à retenir » | prise de notes | `gte-qc-resolution` |
| 3 | caryotype pour « les anomalies de structure comme les aneuploïdies » | une aneuploïdie est une anomalie de nombre ; le caryotype voit les deux (FC2, p. 3) | prise de notes | `gte-qc-resolution` A |
| 3 | FISH « environ 1 Mb » (diapositive comprise) | la FC2 donne 200 à 400 kb (p. 6, quiz p. 9) ; deux enseignants, deux chiffres | point douteux | `gte-qc-resolution` E, `gte-fa-resolution` |
| 3 | les maladies monogéniques réunies touchent « 5 % de la population » | la FC5 (même professeure, en rouge) dit environ 1 % pour les mendéliennes ; maladies rares 3,5-5,9 % (Nguengang Wakap, Eur J Hum Genet 2020) ; à l'examen, 5 % pour « les maladies génétiques » (clé 2017/2018 S1 Q29 A) | le cours lui-même | `gte-qc-maladies` E, `lex-monogenique`, annale 2017/2018 S1 Q29 A |
| 3 | la maladie rare définie par son « incidence » | la définition européenne (Orphanet) parle de prévalence, inférieure à 1/2 000 ; à l'examen, 1/2 000 | le cours lui-même | `gte-qc-maladies` A, `gte-qr-maladie-rare` |
| 10 | « des difficultés ethniques » | éthiques (errata 2025-26) | prise de notes | `gte-qc-donnees-secondaires` E |
| 10 | la définition des tests pharmacogénétiques en tiret séparé | même tiret (errata 2025-26) | mise en page | `gte-qc-fins-medicales` B |
| 11 | laboratoires « accrédités par les ARS » | autorisés par l'ARS ; l'accréditation est celle du COFRAC (L1131-2-1 CSP, Légifrance) | le cours lui-même | `gte-fa-bioethique`, `gte-qc-bioethique` C |
| 11 | « d'une infection grave » (formulaire de consentement) | « affection grave », comme le formulaire de la même page | prise de notes | `gte-qc-consentement` |
| 12-13 | « seul le médecin prescripteur est habilité à communiquer les résultats », cité comme l'article L1131-1 CSP | la règle est à l'article L1131-1-3 CSP (Légifrance) | le cours lui-même | `gte-qc-consentement` D, `gte-qc-annonce`, `gte-qr-rendu` |
| 14 | « la loi du 9 juillet 2011 » | loi n° 2011-814 du 7 juillet 2011 (diapositive de la p. 11) | prise de notes | `gte-qc-img` |
| 14 | « pas autorisables au-delà de 24 semaines » | l'IMG, « à toute époque » (loi citée sur la même page, aujourd'hui L2213-1 CSP) ; l'IVG, 14 semaines de grossesse (L2212-1) | point douteux | `gte-qc-img` A, `gte-fa-img` |
| 15 | trophoblaste 11-13 SA, amniocentèse ≥ 16 SA | la FC2 dit 12 SA et 14 semaines (p. 4) ; ameli.fr, 11-14 SA et 15-17 SA ; la carte suit la diapositive de ce cours | point douteux | `gte-qc-prenatal` A-B, `gte-fa-prenatal` |
| 16 | « ne peut servir de fondement à une action en responsabilité », cité comme l'article L1131-1-2 de 2011 | la phrase est de la loi de 2004 (ancien L1131-1) ; depuis 2011, la personne est « tenue d'informer » (L1131-1 en vigueur, Légifrance) ; l'errata 2025-26 la complète par « dès lors qu'il a demandé au médecin de procéder à cette information » | le cours lui-même | `gte-qc-conseil-genetique` |

Rien n'est dit sans ATTENTION : « incidence », « accrédités par les ARS » et
« infection grave » ont été relevés le 02/10 sur Orphanet, Légifrance et le
formulaire de la p. 11, et portent leur ATTENTION nu.

## Les schémas cliquables

| Fichier | Ce qu'on clique | Cartes | Pourquoi ce dessin |
|---|---|---|---|
| `gte-resolution-couverture.svg` | sept cases vides : caryotype, puce, FISH, génome, exome, panel, Sanger | 7 | les deux diapositives de la p. 3 réunies : la résolution en abscisse, graduée (10 Mb, 1 Mb, 100 kb, 1 pb), la couverture en ordonnée (ciblé, pangénomique) ; les annales posent les deux axes séparément (2021/2022 S2 Q19) |
| `gte-cinq-classes.svg` | cinq cases numérotées, vides | 5 | on clique la classe qui répond à une définition (« à réinterpréter avec les connaissances », « rendue de façon non équivoque ») |

Leurs versions légendées (`-legende.svg`) illustrent la correction.

## Les clés qui ne sont pas reprises telles quelles

Aucune : les 46 clés sont reprises telles qu'imprimées, `CONFLITS` est vide.
L'errata des annales 2024-25 n'a aucune entrée pour ce polycopié.

Points discutés dans la carte, sans changer la clé :

| Question | Clé | Le point |
|---|---|---|
| 2017/2018 S1 Q29 A | ACDE | « 5 % » : vrai selon cette FC, 1 % pour les mendéliennes selon la FC5 (ATTENTION sur le cours) |
| 2023/2024 S2 Q13 C, 2021/2022 S2 Q7 C | ACE, C | « non autorisée en France » : le cours 2025-26 dit « pas recommandé », le cours 2023-24 « interdite » ; vrai à l'examen |
| 2015/2016 S1 Q1 E | BD | l'épissage, donné faux « lors de la transcription » : la clé oppose transcription et maturation ; en réalité il commence souvent pendant la transcription |
| 2016/2017 S1 Q13 D | CDE | un généticien « sollicité pour expliquer » (vrai), à distinguer du généticien qui rendrait à la place d'un prescripteur incompétent (2017/2018 S1 Q30 C, faux) et de l'obligation d'adresser en génétique (2019/2020 S1 Q. 30 C, faux) |

Propositions hors du cours 2025-26, reprises comme la clé et justifiées sur des
sources sûres : l'arrêté du 27 mai 2013 sur les bonnes pratiques et
« l'individu au centre des préoccupations » (2017/2018 S1 Q30 A-B, Légifrance) ;
l'assurance (L1141-1 CSP, 2020/2021 S2 Q9 E) ; le test de paternité (article
16-11 du Code civil, 2021/2022 S1 Q27 D) ; le génome mitochondrial (2015/2016
S1 Q24 B).

## Le lexique

Huit termes, pages mesurées dans le PDF de la FC (même règle que
`chercher_pages.py`, mot entier, pluriel permis) :

| Terme | Pages | Racines |
|---|---|---|
| Monogénique | 3, 4 | mono-, géno- |
| Bioéthique | 11, 16 | bi(o)-, êthos (grec) *(nouvelle)* |
| Présymptomatique | 8, 10, 17 | pré- (latin), sumptôma (grec) |
| Parentèle | 11, 15, 16, 17 | parens (latin) *(nouvelle)* |
| Apparenté | 11, 12, 16 | ad- (latin), parens (latin) *(nouvelles)* |
| Préimplantatoire | 10, 14, 15 | pré- (latin), implantare (latin) *(nouvelle)* |
| Amniocentèse | 15 | amni(o)-, -centèse *(nouvelles)* |
| Trophoblaste | 15 | troph(o)-, -blaste *(nouvelles)* |

« Bioéthique » apparaît aussi au plan du cours (p. 1), non compté ;
« apparentés au Gold-Standard » (p. 6) n'est pas le sens du terme, non compté ;
« préimplantatoire » est écrit « préimplantoire » p. 10 et 14, comptées. Les
étymologies nouvelles sont proposées dans `scratchpad/etym/genet_tests.json`
(TLFi, Wiktionnaire, Bailly, Gaffiot), écrites déjà dans `donnees.py` comme
`appliquer_etymologies.py` les écrirait. « troph(o)- » a le même étymon que
« -trophie » de la table, sous sa forme de préfixe.

## Questions pour Vincent

1. **Le couple de 2016/2017 S1 Q13-Q14**, sans vignette ni arbre dans aucun
   polycopié : la proposition du plan est appliquée — les cartes montrent le
   caryotype de la Q12 (polycopié de cytogénétique) et rappellent, entre
   crochets, ce qu'on sait du cas. Le caryotype est tenu pour celui de II2
   (féminin, « la patiente ») : est-ce bien le cas sur le sujet d'origine ?
2. **5 % ou 1 %** : la carte retient la proposition du plan — 5 % pour « les
   maladies génétiques » (FC1, clé de 2017/2018), 1 % pour les maladies
   mendéliennes (FC5). Le ronéo 2026-27 dira si la professeure a changé de
   chiffre.
3. **La phrase « ne peut servir de fondement à une action en responsabilité »**
   (p. 16) vient de la loi de 2004 ; la carte répond comme les annales (« tenue
   d'informer », vrai) et cite la loi en vigueur. À revoir quand le ronéo 2026-27
   paraîtra.

## À relire

Aucune carte ne porte `a-relire` : toutes ont leur page dans la FC 2025-26 ou,
pour les propositions d'annales hors cours, une source sûre citée.


## L'échelle : Simple → Moyen → Annale (C20, 18/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 16 décembre. Sous les annales, 43 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 9 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `genome-humain` | 5 | 1 | 4 |
| `resolution-couverture` | 10 | 2 | 7 |
| `interpretation-variants` | 3 | 1 | 2 |
| `donnees-additionnelles` | 6 | 2 | 8 |
| `bioethique` | 6 | 1 | 7 |
| `consentement-rendu` | 9 | 1 | 15 |
| `medecine-predictive` | 4 | 1 | 3 |

**Le schéma** `ech-tests`, « Les tests génétiques · outils, découvertes, cadre », donne 99 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_TESTS`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- gte-an-2223s1-q4 B : les gonosomes (une paire) ne sont pas dans le cours 2025-26, qui ne compte que 23 paires de chromosomes ; A est préparée par le nombre de paires (gte-ech-s1), dont la justification dit les 22 paires d'autosomes
- gte-an-1516s1-q1 A, E : codons et épissage, hors du cours 2025-26 (la justification de l'annale le dit)
- gte-an-1516s2-q1 A, D : codons et maturation de l'ARN nucléaire, hors du cours 2025-26
- gte-an-1516s1-q24 B : le génome mitochondrial, hors du cours 2025-26 de ce chapitre
- gte-an-1920s2-q1 A, B : les modes de transmission relèvent du chapitre des maladies mendéliennes
- gte-an-1920s2-q3 D : le risque pour la descendance des sœurs (hors consanguinité) n'est pas dans le cours 2025-26
- gte-an-1920s1-q29 A, B : mode de transmission et risque de récurrence, chapitre des maladies mendéliennes ; D : « tout médecin peut prescrire », que le cours 2025-26 ne dit pas (les annales le jugent selon la raison donnée, LISEZ_MOI)
- gte-an-1920s1-q30 E : I.1, non atteint, ne relève d'aucune règle du cours
- gte-an-1920s2-q2 B, gte-an-2223s1-q15 E, gte-an-2324s1-q13 E, gte-an-2122s1-q25 E : qui peut prescrire (« tout médecin », « seul un généticien ») : le cours 2025-26 ne le dit pas ; les annales le jugent selon la raison donnée (LISEZ_MOI). 2017/2018 S2 Q30 B, elle, est préparée par gte-ech-s28 (la disponibilité ne justifie pas)
- gte-an-1718s1-q29 A : le chiffre de 5 % diverge entre la FC1 et la FC5 de la même professeure ; l'ATTENTION de l'annale le porte, et un chiffre douteux ne s'écrit pas sur le schéma
- gte-an-1718s1-q30 A, B : l'arrêté du 27 mai 2013, hors du cours 2025-26
- gte-an-1819s1-q18 B : le prélèvement sanguin, que le cours 2025-26 ne dit pas
- gte-an-2021s2-q9 E : l'assurance (article L1141-1 CSP), hors du cours
- gte-an-1617s1-q14 B : le cours ne dit pas qui sont les apparentés concernés
- gte-an-2122s2-q8 D, E : le syndrome de Turner, cause de petite taille, est hors de ce cours ; E (« aucune ») se déduit des autres
- gte-an-2122s2-q7 E : le cours ne dit pas quelle analyse peut ou non révéler une fausse paternité ; la justification de l'annale l'explique (gte-ech-s24 prépare la proposition voisine, 2023/2024 S2 Q13 E)

## Régénérer

```powershell
cd contenu\chapitres\genet_tests
..\..\..\app\.venv\Scripts\python.exe generer.py
```
