# Pharmacologie — paquet ECL Remédiation

80 notes, 128 cartes. Chapitre `chap-remed-pharmaco` de l'UE ECL Remédiation
(identifiant du squelette `contenu/squelettes/remediation`), séance 5 du
22/10. Cours : les **diapositives de la séance de pharmacologie de 2025**
(27 pages) ; annales : le **test intermédiaire 2 du 24/10/2024**, questions 21
à 35, et celui du **30/10/2025**, questions 28 à 36, tous deux sans corrigé.
Épreuve visée : le test intermédiaire 2 du **29/10/2026** (`exam-remed-ti2`,
déclaré par le squelette ; QCM avec degré de certitude).

**Un cours d'une année passée, sans ronéo.** Les diapositives sont celles de
2025 : la source porte « ECL Remédiation 2025-26 » dans son auteur, et chaque
carte de cours le tag `cours-2025-26` (badge « Cours 2025-26 »). Aucune carte
ne dit « Absent du cours 2026-27 », et rien n'entre dans
`contenu/ERRATA_RONEOS_2026-27.md`, qui ne concerne que les ronéos 2026-27.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 36 | 36 |
| QRU | 10 | 10 |
| Texte à trous | 8 | 44 |
| QROC | 7 | 7 |
| Recto-verso | 5 | 5 |
| Schéma cliquable | 2 | 14 |
| Lexique | 12 | 12 |

Dont **24 annales** (10 QRU, 14 QRM) sur deux sessions : « 2024/2025 TI2 »,
15 questions (9 QRU, 6 QRM ; la Q31, posée en QRU, est une QRM, voir plus bas),
et « 2025/2026 TI2 », 9 questions (1 QRU, 8 QRM). Côté cours :
22 QCM, chacun avec une justification par proposition qui commence par « Vrai »
ou « Faux », de une à quatre vraies (une : 1 QCM ; deux : 4 ; trois : 14 ;
quatre : 3), les lettres justes réparties sur A à E (A 13, B 13, C 11, D 13,
E 13 après la relecture, qui a réordonné quatre QCM où A et B dominaient).

Dix thèmes, tous des clés que l'application libelle déjà et dont le libellé
dit vrai ici (BMCT pour la pharmacologie, BMCP pour l'insuline) : aucun libellé
à ajouter à `THEME_LABELS`.

| Clé | Libellé | Notes |
|---|---|---|
| `agonistes` | Agonistes et antagonistes | 8 |
| `puissance` | Puissance et relation dose-effet | 10 |
| `modulation-synaptique` | Moduler une synapse | 9 |
| `antidiabetiques` | Médicaments du diabète | 15 |
| `secretion` | Insuline : nature et actions | 3 |
| `effets-snv` | Effets sympathiques et parasympathiques | 6 |
| `variabilite` | Variabilité de la réponse | 3 |
| `interactions` | Interactions médicamenteuses | 6 |
| `pharmacocinetique` | Pharmacocinétique | 4 |
| `prescrire-risque` | Évaluer le risque avant de prescrire | 4 |

La fenêtre thérapeutique (p. 26) est rangée dans `puissance` (deux courbes
concentration-effet, deux EC50) : la clé `marge-therapeutique` de la BMCT dit
« Marge thérapeutique étroite », trop étroit pour une seule carte. La Q35 de
2025-26, sur la fenêtre, l'y rejoint ; aucun thème nouveau.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-remed-pharmaco` — « Séance pharmacologie 2025.pdf » (27 p.), `Remediation/…` | 2025-26 | **le cours** : `SRC["fiche"]`, chaque carte porte sa page ; c'est ce que le lecteur ouvre (`chapitre=`) |
| `src-remed-ti2-2425` — test intermédiaire 2 du 24/10/2024, photographié | 2024-25 | les questions 21 à 35 ; déclaré mot pour mot comme dans `remed_immuno`, qui en prend les questions 1 à 20 |
| `src-remed-ti2-2526` — test intermédiaire 2 du 30/10/2025, imprimé (7 p.) | 2025-26 | les questions 28 à 36, session « 2025/2026 TI2 » ; déclaré à l'identique dans `remed_immuno` (questions 1 à 18) et `remed_souches` (19 à 27) |

Le PDF est presque tout en image : vingt pages sur vingt-sept n'ont pas de
texte, ou seulement leur titre. Chaque page a été lue rendue (1600 px), et
chaque carte cite la page de la diapositive où se lit sa réponse.

Cités dans le texte des cartes, sans être déclarés (ce sont les fiches d'autres
chapitres) : le cours de pharmacodynamie de BMCT (ronéo 2026-27, partie 1, p. 4
et 5 ; partie 2, p. 2) pour l'agoniste inverse, l'indépendance de l'affinité et
de l'activité, la DE50 ; le cours de variabilité de BMCT (Ronéosaure 2025-26,
p. 5) pour la puissance chez l'enfant ; le cours de suivi thérapeutique
pharmacologique de BMCT (ronéo 2026-27, p. 2-3) pour la fenêtre large de la
plupart des médicaments (Q35 E de 2025-26). Hors programme et cités : la
nomenclature de l'IUPHAR (Neubig et al., Pharmacol Rev 2003 ; 55 : 597-606)
pour le modulateur allostérique ; la revue de Kenakin et Christopoulos (Nat Rev
Drug Discov 2013 ; 12 : 205-16) pour l'agoniste biaisé (biais de
signalisation) ; le RCP de la metformine pour son effet intestinal.

## Ce que le cours a dicté

- **p. 3-6, la pharmacodynamie** : affinité, sélectivité, activité ; efficacité
  = Emax, puissance = DA50 ou EC50 ; α = 1, < 1, 0 ; les trois courbes A, B, C.
  Une carte par diapositive, et la p. 6 deux fois (QCM, recto-verso), parce que
  la question 24 de l'annale en est la lecture.
- **p. 7-9, la synapse** : les deux diapositives « Activation » et
  « Inhibition » se cartent l'une contre l'autre (deux QCM, deux textes à
  trous, un recto-verso sur le récepteur présynaptique, qui change de camp) et
  un schéma cliquable. La diapositive dit « inhibition canaux » ; les annales,
  « canaux calciques » (2024-25) puis « canaux voltage-dépendants » (2025-26) :
  le canal voltage-dépendant de la terminaison, dont le calcium déclenche la
  libération.
- **p. 10-12, les antidiabétiques** : la cellule β (un texte à trous, un schéma
  cliquable), les sulfonylurées et glinides, la metformine et les glitazones,
  les incrétines, les gliflozines, la diapositive « Patient diabétique » (p. 11)
  qui range chaque classe face à un mécanisme de l'hyperglycémie, les îlots
  (p. 12).
- **p. 13-14, le système nerveux autonome** : le tableau des récepteurs
  adrénergiques et ses deux cadres rouges (β2 du pancréas, β2 du foie), le
  schéma de l'homéostasie énergétique, le tableau des antihypertenseurs (le
  diabète encadré : IEC en cas de protéinurie).
- **p. 15-27** : la variabilité (PK), les interactions PK et PD, le RCP du
  Diamicron 60 mg (gliclazide) et ses chiffres, la forme libre, le
  déplacement, l'inhibition enzymatique et le pro-médicament, les interactions
  du RCP, la fenêtre thérapeutique, les facteurs de risque iatrogène.

Le cours n'a ni rouge ni gris à trier : seulement des cadres et des flèches
rouges sur les diapositives (p. 13, 14, 17, 19, 20, 22, 25), repris dans les
cartes.

**Trois points des diapositives, sans ATTENTION parce qu'aucune carte n'en
dépend** :

- p. 12 : une flèche (−) va du glucagon des cellules α à la cellule β ; le
  glucagon stimule en fait la sécrétion d'insuline par voie paracrine. La
  flèche du bas, « Glucagon (−) INSULINE », dit l'antagonisme des deux
  hormones ; aucune carte ne prête au glucagon un effet sur la cellule β.
- p. 26 : le numéro « 42 » d'un autre diaporama est resté en bas à droite.
- p. 14, tableau des antihypertenseurs : « créatininémie ≥ à 265,2 mmol/l »
  pour l'insuffisance rénale ; l'unité juste est le µmol/l (265 µmol/l, soit
  30 mg/l). Aucune carte ne porte ce seuil.

**Pages sans carte à elles** : p. 1 (le titre, dont le pamplemousse annonce
sans le dire l'inhibition enzymatique) et p. 2 (les objectifs) ; p. 21, 22 et
23, étapes du même schéma de distribution, sont citées dans le texte des cartes
des p. 20 et 24 et illustrent deux d'entre elles (p. 21). La p. 18, la même
rubrique 5.2 que la p. 19 sans le soulignement, est la page du texte à trous du
RCP.

## Ce que les annales ont dicté

| Savoir | 2024-25 | 2025-26 |
|---|---|---|
| Affinité, sélectivité, activité, agonistes, antagoniste, ligands biaisés, inverses, allostériques | Q21, Q22, Q23 | Q28 |
| Puissance et efficacité, DA50 | Q24 (le graphique), Q25 | Q29 |
| Activation et inhibition synaptiques | Q26, Q27 | Q30 |
| Organes de la glycémie et cibles des antidiabétiques, sulfamides, gliflozines, metformine, analogues du GLP-1 | Q28, Q29, Q30, Q33, Q34 | Q31 |
| Défaillance β du diabète de type 2 | Q32 | — |
| Système nerveux autonome, effets métaboliques du sympathique | Q31 | Q32 |
| Facteurs de variabilité de la réponse | Q35 | Q33 (la seule pharmacocinétique) |
| Interactions médicamenteuses | — | Q34 |
| Fenêtre thérapeutique | — | Q35 |
| Facteurs de risque iatrogène | — | Q36 |

Les questions du test de 2025-26 sont détaillées plus bas, dans leur section.

**La question 21 ouvre la page 7 du sujet** (IMG_8037, en haut) ; la question
20, la dernière d'immunologie, ferme la page 6 (IMG_8036). La question 35 est
seule sur la page 10 (IMG_8040), dont le reste est blanc. Chaque question est
recopiée mot pour mot, apostrophes droites ou courbes comme le sujet les
imprime ; les énoncés imprimés sur deux lignes (Q25, Q30, Q32, Q33, Q34 : « La DE50 est
principalement utilisée pour : », etc.) sont réunis en une phrase.

**La question 24 est la lecture d'un graphique** : il est redessiné en SVG
(`rpha-q24-graphique.svg`, `schemas.py`) d'après la photographie du sujet — deux
paliers « Emax », la DA50 de A marquée (tirets et flèche), un tiret commun à B
et C — et posé devant l'énoncé (`illustration_question`). La diapositive p. 6,
qui porte en plus « Puissance : DA 50 / Efficacité : Emax », est en correction.

**Les anomalies du sujet**, dans `annales.py` (docstring, `CONFLITS`, ATTENTION
dans la justification) :

- **Q24 E** — « Le médicament C est le moins puissant » : B et C ont la même
  DA50 ; C n'est pas le moins puissant à lui seul. Clé B.
- **Q28 E** — « Le cerveau » : absent de la figure des organes (p. 11), mais le
  système nerveux autonome règle la glycémie (p. 12, 14). Retenu faux, cas
  ouvert.
- **Q31** — une question à réponse unique où le cours rend deux propositions
  vraies : A (baisse de l'insuline, Σ α2, p. 12-13) et C (lipolyse,
  p. 13-14). Retenu AC ; la carte est une QRM, et le dit. Cas ouvert.
- **Q33 C** — la flèche (−) de la metformine vers le glucose intestinal
  (p. 10) : un effet secondaire, pas le « mécanisme principal ». Clé B.
- Sans conflit, la clé n'en dépendant pas : Q30 E (« la production de glucagon
  par le foie » : il vient des cellules α, p. 12 ; faux deux fois), Q30 D
  (« Stimule », hors construction), Q34 B (« réduit », au singulier), Q27
  (« relative », sans s), Q25 (« DE50 » pour la DA50 du cours), Q29 et Q30 (le
  glibenclamide, la dapagliflozine, que les diapositives ne nomment pas).
- Q23 B, C et D portent sur l'agoniste biaisé (nommé p. 8, sans définition),
  l'agoniste inverse et le modulateur allostérique (absents des diapositives) :
  leurs justifications citent la BMCT, l'IUPHAR (modulateur allostérique) et
  Kenakin et Christopoulos, 2013 (agoniste biaisé).

## Les clés de 2024-25 : toutes déduites, et celles qui s'écartent de la copie

**Aucun corrigé n'existe** : toute annale porte `officielle=False`, et son
explication commence par « Clé déduite du cours, absente de la table de
corrections. », puis dit où le cours tranche et ce que montre la copie annotée
(lettres entourées : le choix de l'étudiant ; traits devant les lettres : ce
qu'il écarte ; surlignages ; « −0,5 », « −1 » en marge). La copie n'est jamais
prise pour une clé.

| Question | La copie annotée | Clé retenue | Pourquoi |
|---|---|---|---|
| Q21 | les cinq lettres entourées au crayon (B d'un trait en plus) ; B, C, E surlignés ; « −0,5 » | ACDE | B confond efficacité et affinité (p. 3-4) ; une seule discordance sur la réponse ABCDE, ce qui s'accorde avec quatre vraies |
| Q24 | E entourée | **B** | A et C au même palier (p. 6) ; E ambiguë, B et C à égalité de DA50 — ATTENTION et conflit sur E |
| Q25 | B et D entourées ; en marge droite, un rond en face de C | **C** | la dose de la moitié de l'effet mesure la puissance (p. 4, p. 6) |
| Q27 | C seule entourée ; B et E barrées | **BCE** | « Inhibition canaux », « Agoniste » présynaptique, « Antagonistes » postsynaptiques (p. 9) |
| Q28 | A, B, C entourées ; D barrée et surlignée | **ABCD** | le foie produit le glucose (p. 11, 13-14) ; E, le cerveau, cas ouvert — conflit, `a-relire` |
| Q30 | C entourée ; B barrée ; un rond étoilé en marge | **B** | les gliflozines bloquent la réabsorption rénale du glucose (p. 10-11) |
| Q31 | A entourée ; C barrée, mais une flèche montante en face de la lipolyse | **AC** | deux vraies dans une QRU — conflits sur A et C, `a-relire` |
| Q33 | les cinq lettres barrées, un rond léger en marge en face de D, « GLP-1 » griffonné | **B** | l'insulinorésistance (p. 11) ; C, effet secondaire — conflit sur C |

Même lecture que la copie : Q22 (B), Q23 (ACE), Q26 (D, avec « −1 » en
marge), Q29 (C), Q32 (C), Q34 (A), Q35 (BCDE).

Cas ouverts : **Q28 E** et **Q31** (A ou C) ; leurs cartes le disent et portent
`a-relire`.

## Le test de 2025-26 (26/10)

Le sujet du **30/10/2025** (10 h-11 h 15, MED2), imprimé, sans corrigé ni copie
annotée : 36 QCM, l'immunologie de 1 à 18 (`remed_immuno`), les tissus et
cellules souches de 19 à 27 (`remed_souches`), la pharmacologie de 28 à 36, ici.
Les questions 28 à 34 tiennent sur une page, sous le titre « Pharmacologie » ;
35 et 36 ouvrent la suivante. Session « 2025/2026 TI2 », source
`src-remed-ti2-2526`, ids `remed-ti2-2526-q28` à `q36`. Chaque énoncé et chaque
proposition sont recopiés mot pour mot, apostrophes courbes comme le sujet les
imprime, et vérifiés par un script contre le texte du sujet.

**Six questions sur neuf reprennent un thème de 2024-25**, et leur explication
le dit, proposition par proposition quand elle revient : Q28 (sa D est la B du
QCM 22, mot pour mot, même verdict), Q29 (le QCM 25 retourné : ce qui mesure la
puissance), Q30 (les QCM 26 et 27 réunis en une QRM), Q31 (le QCM 28 ; les
muscles à la place du foie, et une question qui demande où l'on peut agir par
un médicament), Q32 (le QCM 31, dont la A revient sans son ambiguïté : le
récepteur α2 est nommé), Q33 (le QCM 35, restreint à la pharmacocinétique). Q34
(interactions), Q35 (fenêtre thérapeutique) et Q36 (risque iatrogène) sont
neuves, sur les p. 16, 26 et 27.

**Coquilles gardées** (listées dans la docstring d'`annales.py`) : Q32 B « est
associé une dépense d'énergie » (le « à » manque) ; « bêta adrénergiques » sans
trait d'union (Q32 A) ; « entraine » sans circonflexe (orthographe rectifiée) ;
le « ? » de la Q28, rejeté seul à la ligne, rattaché à l'énoncé ; Q35 A, « une
dose […] est une fenêtre », un raccourci.

**Les anomalies** (ATTENTION dans la justification, `CONFLITS`) :

- **Q31 B** — « Le cerveau » : aucune classe des diapositives ne le vise
  (p. 10-11) ; hors du cours, les analogues du GLP-1 agissent sur
  l'hypothalamus (l'appétit). Retenu faux, comme la Q28 E de 2024-25 ; la
  question, qui demande où agir par un médicament, se lit plus nettement sur
  les diapositives que celle de 2024-25.
- **Q33 A** — « L'allaitement » : absent des « principaux facteurs de variation
  PK » (p. 15), où les états physiologiques se réduisent à la grossesse, quand
  les quatre autres propositions y sont mot pour mot. Retenu faux ; c'est
  pourtant un état physiologique.
- **Q35 E** — « La plupart des médicaments ont une fenêtre thérapeutique
  large » : les diapositives ne le disent pas. Retenu vrai, avec le cours de
  suivi thérapeutique de BMCT (le suivi, rarement appliqué aux médicaments de
  ville, et d'abord pour les marges étroites).
- **Q36 B** — « L'entourage familial » : absent des quatre cadres de la p. 27 ;
  hors du cours, c'est l'isolement, l'absence d'entourage, qui expose au
  risque iatrogène. Retenu faux.
- Sans conflit, la clé n'en dépendant pas : Q30 C dit « canaux
  voltage-dépendants » où 2024-25 disait « canaux calciques » (même canal de
  la libération, p. 9 ; la justification note qu'un canal potassique bloqué
  ferait l'inverse, hors du cours) ; Q32 A, « sympathomimétique », mot que les
  diapositives n'écrivent pas.

Deux de ces conflits portent `a-relire` (26/10, pour suivre la règle de
`remed_immuno`) : la Q33 A et la Q36 B, dont la justification finit sur
« Point discutable, sans corrigé ». Les deux autres se lisent sur une page
précise (la liste des p. 10-11, ou le cours de BMCT pour la Q35 E) ; la carte
dit la lecture contraire.

**Les clés, toutes déduites** (`officielle=False`, « Clé déduite du cours,
absente de la table de corrections. » en tête de l'explication) :

| Question | Clé retenue | Pourquoi |
|---|---|---|
| Q28 | **CD** | l'activité est la réponse biologique (p. 3) ; A l'affinité, B la sélectivité ; E oublie l'agoniste partiel (p. 5) |
| Q29 (QRU) | **B** | « Puissance = … DA50 ou EC50 » (p. 4, p. 6) ; A est l'efficacité |
| Q30 | **ABDE** | quatre des cinq leviers de la diapositive « Activation » (p. 8) ; C est sur « Inhibition » (p. 9) |
| Q31 | **ACDE** | rein, tube digestif, muscle, cellule β : les cibles des classes (p. 10-11) ; B, le cerveau — conflit |
| Q32 | **ACDE** | α2 baisse l'insuline, foie qui libère le glucose, β1 du cœur (p. 13) ; B, le parasympathique économise (p. 14) |
| Q33 | **BCDE** | la liste des « principaux facteurs de variation PK » (p. 15) ; A, l'allaitement — conflit |
| Q34 | **CD** | interactions PK (dont la distribution, p. 21, 25) et PD (p. 16) ; A définit la pharmacodynamie, E oublie la baisse d'efficacité |
| Q35 | **ABDE** | proximité dose thérapeutique / dose toxique, concentration plasmatique, suivi (p. 26) ; E — conflit |
| Q36 | **ACDE** | les quatre cadres de la p. 27 ; B, l'entourage familial — conflit |

Les neuf portent une diapositive en correction : propriétés (p. 3), courbe
effet-dose (p. 4), activation synaptique (p. 8), antidiabétiques (p. 10),
activation adrénergique (p. 13), facteurs de variation PK (p. 15), interactions
PK et PD (p. 16), fenêtre thérapeutique (p. 26), risque iatrogène (p. 27).

## Les schémas

| Fichier | Ce qu'on fait | Cartes |
|---|---|---|
| `rpha-synapse-nue.svg` (`rpha-zo-synapse`) | on clique : précurseur, vésicules, canal, libération, enzyme, recapture, autorécepteur, récepteurs ionotrope et métabotrope | 9 |
| `rpha-cellule-beta-nue.svg` (`rpha-zo-cellule-beta`) | on clique : GLUT-2, Krebs et ATP, canal K+ sensible à l'ATP, canal Ca2+, granules d'insuline | 5 |
| `rpha-q24-graphique.svg` | la question 24, devant l'énoncé | 1 |

La synapse est redessinée d'après les p. 7-9 (Neuropsychopharmacologie,
Elsevier-Masson, 2019), sans un mot : ce sont les formes qui se lisent (le canal
et son éclair, le croissant de l'enzyme, la pompe de recapture, le récepteur à
sept passages et sa protéine G). Chaque zone dit le levier qui active ou
inhibe, et la question d'annale qui le demande. La cellule β est celle de la
p. 10, du glucose aux granules. Les versions légendées, tirées des mêmes
constantes (`schemas.py`), sont en correction ; rendues avec leurs zones
superposées, aucune ne déborde sur une autre. Palette, `_entete` et `_texte` :
ceux d'`immuno_innee`.

**Illustrations** : 46 QCM sur 46 portent une diapositive ou un schéma en
correction (100 %), 68 notes sur 80. Vingt-deux diapositives sont extraites en
PNG, la p. 17 sans le bandeau du site de la base de données publique ; elles
sont réduites à 256 couleurs et à 1200 px de large au plus (19/10), relues après.

## Le lexique

Douze termes : agoniste, antagoniste, affinité, hypoglycémiant, incrétine,
insuline, glucagon, somatostatine, pharmacocinétique, pharmacodynamique,
iatrogène, pro-médicament. Les termes nus existent déjà dans d'autres UE
(`lex-agoniste`…) : ceux-ci portent le suffixe `-remed`.

Les pages ont été mesurées par `chercher_pages.py` sur le texte du PDF, et
complétées des pages où le mot se lit sur l'image de la diapositive, parce que
vingt pages n'ont pas de texte :

| Terme | Mesurées (texte PDF) | Lues sur la diapositive |
|---|---|---|
| Agoniste | 10 | 4, 5, 8, 9 |
| Antagoniste | — | 5, 8, 9 |
| Affinité | — | 3 |
| Hypoglycémiant | 10 | 25 |
| Incrétine | 10 | — |
| Insuline | 10, 12 | 11, 14, 25 |
| Glucagon | 12 | 14 |
| Somatostatine | 12 | — |
| Pharmacocinétique | 16, 27 | 17, 18, 19 |
| Pharmacodynamique | 5, 6, 16 | — |
| Iatrogène | 27 | — |
| Pro-médicament | 24 | — |

Les étymologies sont écrites dans les définitions et les racines, et versées
dans `.claude/skills/nouveau-chapitre/scripts/etymologies.json` : sept entrées recopiées de la table sous l'identifiant
`-remed` (agoniste, antagoniste, affinité, pharmacocinétique, pharmacodynamie
pour « pharmacodynamique », iatrogène, promédicament), cinq nouvelles
(hypoglycémiant, incrétine, insuline, glucagon, somatostatine) et deux racines
nouvelles (`insula (latin)`, `agō (grec)`, distincte d'`agôn (grec)`).
Insuline et glucagon sont vérifiés sur le TLFi (portail lexical) : insula
« île », d'après les îlots de Langerhans (J. de Meyer, 1909) ; ἄγων, participe
de ἄγειν, l'hormone qui « amène » le sucre. Somatostatine : -statine, du grec
στάσις (Wiktionary anglais). L'origine d'« incrétine » reste **incertaine**
(`"origine": "à vérifier"`, et « Origine incertaine : » dans la définition) :
le mot est de J. La Barre, 1932 (Rehfeld, Front Endocrinol 2018) ; le
Wiktionnaire en fait un mot-valise d'ingestion et de sécrétine, une partie de la
littérature « INtestine seCRETion INsulin », et le TLFi n'a pas d'entrée.

## La relecture contre les diapositives et le sujet (18/10)

Les 71 notes ont été relues carte par carte contre les 27 pages rendues et les
photos IMG_8036 à IMG_8040 (la question 21 ouvre bien la page 7, IMG_8037) :
énoncés et propositions des quinze annales conformes mot pour mot, clés
recalculées (dont la lecture des DA50 du graphique de la Q24 : B et C au même
trait), figures et zones regardées. Ce qui a changé :

- `rpha-qc-rcp-interactions` : l'explication disait « quatre niveaux » ; le RCP
  de la p. 25 en a trois (contre-indiqué, déconseillé, précautions d'emploi).
- `rpha-qc-inhibition-enzymatique` C : « son excrétion augmente » se lisait
  deux fois (le médicament inchangé, ou son métabolite) ; la flèche ↘ de la
  p. 23 est sur la voie du métabolite, la proposition dit maintenant
  « l'excrétion de son métabolite ».
- `rpha-qc-cibles-antidiabetiques` : l'explication confondait les quatre
  mécanismes de la colonne de droite (p. 11) et les organes ; réécrite.
- `rpha-qc-courbe-effet-dose`, `rpha-qc-incretines`, `rpha-qc-ilots`,
  `rpha-qc-snv-energie` : propositions réordonnées (notes avec), pour que les
  lettres justes ne se concentrent plus sur A et B (16 et 17 sur 63 avant).
- `remed-ti2-2425-q23` B et `rpha-qc-ligands` B : l'agoniste biaisé était
  rattaché à la nomenclature IUPHAR de 2003, qui ne le définit pas ; la source
  est la revue de Kenakin et Christopoulos (2013). Q23 D et `rpha-qc-ligands` C :
  la définition IUPHAR du modulateur allostérique est citée telle quelle, avec
  l'exemple des benzodiazépines et la réserve des agonistes allostériques.
- `remed-ti2-2425-q21` D : la citation « deux paramètres indépendants » prêtée
  au ronéo de BMCT n'en est pas une ; la justification dit ce que dit la p. 5
  du ronéo. L'explication note que le « −0,5 » de la copie (réponse ABCDE)
  s'accorde avec une clé à quatre vraies, ACDE.
- `remed-ti2-2425-q31` : l'explication dit, pour l'examen, laquelle cocher s'il
  n'en faut qu'une — C, que les diapositives portent sans réserve, quand A se
  lit dans les deux sens au tableau de la p. 13. La carte garde AC.
- `remed-ti2-2425-q33` : la copie porte aussi un rond en marge, en face de D.
- `rpha-rv-efficacite-puissance` : l'explication ajoute que B et C ont la même
  puissance (le trait commun de la p. 6, et le piège de la Q24 E).
- Lexique : pages ajoutées (agoniste p. 4, insuline p. 14 et 25,
  pharmacocinétique p. 17, lues sur l'image) ; glucagon, « qui amène » le sucre
  (TLFi) ; incrétine, origine incertaine.

## La critique d'ensemble (19/10)

Un critique a relu les quatre chapitres de l'ECL ensemble. Ici :
- **`rpha-qc-synapse-activation` A et E** recopiaient presque mot pour mot les
  annales Q27 A et Q26 E : elles sont reformulées (« fournir au neurone la
  molécule de départ… », « bloquer le récepteur que porte la cellule cible »).
- **`rpha-qr-da50`** n'accepte plus « DE50 » ni « dose efficace 50 » : en
  BMCT, la DE50 est une autre mesure, la dose à laquelle 50 % des sujets
  répondent (`bmct_pharmacodynamie`). « La dose active 50 » passe dans les
  réponses exactes.
- **Le poids des figures** : de 9,3 à 3,6 Mo (256 couleurs).
- **Le nombre de pages du sujet** : `src-remed-ti2-2425` dit 10 pages (la Q35
  est seule sur la page 10), à l'identique dans `remed_immuno`.

## À relire

Quatre cartes `a-relire`, les cas ouverts : `remed-ti2-2425-q28` (le
cerveau est-il un organe régulant la glycémie ?), `remed-ti2-2425-q31` (une
seule réponse attendue, deux vraies), `remed-ti2-2526-q33` (l'allaitement)
et `remed-ti2-2526-q36` (l'entourage familial). Le tag se retire quand un corrigé du
test 2 ou la séance de 2026 tranche.

Dix cartes tirées au hasard ont été relues contre les diapositives
(`rpha-qr-miconazole`, `lex-promedicament-remed`, `rpha-qc-adrenergique`,
`remed-ti2-2425-q27`, `rpha-fa-cellule-beta`, `lex-pharmacocinetique-remed`,
`remed-ti2-2425-q22`, `rpha-rv-efficacite-puissance`, `rpha-qc-snv-energie`,
`rpha-qr-iec-diabete`) : chacune retrouve sa page.

À la séance de 2026, relire tout le chapitre contre les diapositives de
l'année : pages, chiffres du RCP, et les trois points des p. 12, 14 et 26.

## Régénérer

```powershell
cd contenu\chapitres\remed_pharmaco
..\..\..\app\.venv\Scripts\python.exe generer.py
```

`generer.py` est la copie exacte de
`.claude/skills/nouveau-chapitre/scripts/generer_modele.py`.
