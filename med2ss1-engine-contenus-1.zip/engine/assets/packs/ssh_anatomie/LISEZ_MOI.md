# Histoire de la médecine : anatomie et révolutions — paquet SSH

94 notes, 182 cartes. Chapitre `chap-ue-ssh-fc1` de l'UE SSH (identifiant du
squelette). Cours du **Pr Devinant, les 16 et 18/09/2026** (semaine 2), en quatre
ronéos ; annales de six sessions (huit questions rédactionnelles), dont la QROC 6
du sujet de 2024/2025, déposé le 15/10/2026.

**18/10/2026** : 1 recto-verso du sujet de SSH 2025/2026 (examen du
09/01/2026, sans corrigé) — QROC 1 ; voir « Le sujet 2025/2026 ».

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QROC | 28 | 28 |
| Texte à trous | 18 | 98 |
| QRM | 17 | 17 |
| Recto-verso | 20 | 20 |
| Lexique | 10 | 10 |
| Schéma cliquable | 1 | 9 |

Dont **9 annales** (recto-verso, `ANNALES_QROC`) sur 7 sessions : 2021/2022, 2021/2022 S2, 2022/2023, 2022/2023 S2, 2023/2024, 2024/2025 S1, 2025/2026 S1.

**Un schéma cliquable** (`schemas.py`, `hist-zo-galien`) : le système de Galien
redessiné sans légende, disposé comme la figure du ronéo 2026-27 (partie 2, p. 5)
— foie, veine porte, veine cave inférieure, ventricule droit, septum, ventricule
gauche, veine artérieuse, artère veineuse, rete mirabile, neuf zones. Deux annales
portent sur ces pièces (2021/2022 Q7, 2022/2023 Q6), et le ronéo lui-même inverse
une fois l'artère veineuse et la veine artérieuse (partie 3, p. 2) : c'est
l'erreur que ce clic attrape. La figure légendée du ronéo est en correction.

Huit thèmes, dans l'ordre du cours : histoire des sciences (`histoire-sciences`),
Antiquité, Galien, Moyen Âge, Renaissance, Harvey, épistémologie (Bachelard,
Popper), Kuhn. Leurs libellés sont dans `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`, bloc « ssh ») et sont
**génériques** (« Antiquité », « Moyen Âge », « Épistémologie »…) : un libellé
de thème est partagé entre toutes les UE, et les autres chapitres de SSH
réemploieront ces clés.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-ssh-hm1` à `hm4` — Ronéo & Juliette, « Histoire de la médecine 1 » à « 4 » (7, 6, 7, 7 p.) | **2026-27** | **la base** : chaque note relue porte sa page (`page`, et `fiche` pour les parties 2 à 4) ; c'est ce que le lecteur ouvre (Partie 1 à 4) |
| `src-annales-ssh` — Ronéosaure, « SSH 1 - Anatomie et révolutions » (4 p.) | 2024-25 | 7 questions et leur corrigé : officiel pour 2022/2023 S2 seulement |
| `src-sujets-ssh-2425` — « Sujets de SSH 2024/2025, session 1 » (examen du 10/01/2025, 1 QR et 10 QROC, sans corrigé), déposés le 15/10/2026 | 2024-25 | la source de la session 2024/2025 S1 (`SRC["sessions"]`), la QROC 6 ; déclarée à l'identique dans tous les chapitres de SSH qui en cartent une question |
| `src-cours-ssh-2425` — Ronéosaure, FC n°1 (AC) (27 p.) | 2024-25 | appoint ; source des 2 cartes absentes du cours 2026-27 |
| `src-roneo-ssh-2324-1` et `-2` — Charonéos 2023-24 (16 et 8 p.) | 2023-24 | appoint ; la consigne sur les dates et les lieux (p. 5) ; les deux manières de mettre fin à une crise (partie 2, p. 6) |
| tableau d'erreurs SSH 2023-24 (Ronéosaure) | 2023-24 | trois entrées sur ce cours : veine cave supérieure → inférieure, la phrase confuse sur les valvules, « procepteur » → prosecteur |
| tableau d'erreurs SSH 2026-27 (Ronéo & Juliette) | 2026-27 | vide au 26/09/2026 ; au **11/10/2026**, une entrée sur ce cours : Colombo nie les pores du septum, pas le septum (partie 3, p. 5) ; au **19/10/2026**, une seconde : le pape Sixte IV, pas « VI » (partie 3, p. 3), déjà portée en prise de notes |

Une fiche de révision d'étudiant (2024-25) a été lue en appoint, sans être
déclarée ; aucune carte ne la cite. Elle recopie les erreurs de la FC n°1 (Kuhn
1942, capillaires « fin du XIXe »).

Les vérifications faites hors du cours (dates, citations, historiographie) sont
citées dans la carte qui s'en sert : De motu cordis (trad. Willis, Internet History
Sourcebook, Fordham), la biographie de Harvey par R. Willis (1847, Wikisource),
Britannica (Colombo), l'université de Padoue (le théâtre anatomique), College of
Physicians of Philadelphia et Wikipedia (Mondino), Encyclopedia.com (les
anatomistes de Salerne, Dioclès), AABB (histoire de la transfusion), J Am Coll
Cardiol 2014 (Vésale et le septum), Stanford Encyclopedia of Philosophy (Popper,
Kuhn), la préface de Celse (LacusCurtius).

**La source des figures.** Chaque figure nomme sa partie du ronéo dans `IMAGES`
(troisième élément, que le modèle sait lire depuis le 26/09) : le système
galénique et son schéma redessiné viennent de la partie 2 (p. 5), la leçon
d'anatomie, la Fabrica et la ligature de Harvey de la partie 3, le lapin-canard
de la partie 4 (p. 6).

## Ce que le cours a dicté

- **Le format de l'examen** : « examen = 10 QROC + 1 QR » et « 1 livre à lire »,
  qui fait partie des attendus (partie 1, p. 7). D'où un chapitre de QROC, de
  textes à trous et de recto-verso ; les QCM du cours portent les pièges.
- **Le rouge** du ronéo (partie 2 seulement) a chaque fois une carte qui le
  demande : « inefficaces dans la pratique », « médecine humorale
  hippocratique », « il faut donc attendre Galien » (`hist-fa-trois-raisons`) ;
  fonctionnement, nature bien faite, rôle social (`hist-qc-galien-anatomie`) ;
  fonction spécifique (`hist-fa-galien-anatomie`) ; rete mirabile
  (`hist-qr-rete`, `hist-qc-galien-erreurs`) ; relation cœur-poumon,
  refroidissement cardiaque, vecteur thermique (`hist-fa-coeur-poumon`) ;
  fonctions vitales, nutrition, dominé par un organe, sang sombre et épais,
  veines artérieuses et artères veineuses, tunique pulsatile
  (`hist-fa-trois-systemes`, `hist-fa-sang-galenique`, `hist-rv-critere`,
  `hist-zo-galien`) ; simplification du système, manque d'instrumentation,
  disponibilité des corps, force explicative (`hist-fa-obstacles`,
  `hist-qc-moyen-age`).
- **Le gris.** Les quatre ronéos 2026-27 ne définissent pas leur gris ; il n'y en
  a qu'un passage (partie 4, p. 4, Popper et la métaphysique). Il est donc carté
  comme le reste, sans tag `edn` — et il est faux sur Popper : voir plus bas
  (`hist-qc-popper` E).
- **La consigne de 2023-24** (Charonéo, p. 5) : les dates et les lieux d'origine
  de Dioclès, Hérophile et Érasistrate (de Caryste, de Chalcédoine, de Céos) ne
  sont pas à retenir ; seuls leurs noms et l'époque comptent. Aucune carte ne les
  demande ; « -280 », l'époque, est un trou de `hist-fa-alexandrie`.
- **Un seul plan pour les redites** : la partie 2 (II.C) et la partie 3 (III.A)
  disent deux fois le système galénique, le galénisme médiéval, Ibn an-Nafis et
  les obstacles. Chaque savoir a une carte, citée à la page la plus complète.
- **Les détails qu'une relecture a trouvés sans carte** (26/09) en ont une
  désormais : la grande révolution de Copernic et Galilée (`hist-qr-copernic`),
  la symétrie des cartographies hippocratiques (`hist-qr-symetrie`), l'anatomie
  « fixe, évidente » de Galien (`hist-fa-galien-anatomie`), le « boum » du XVe
  siècle, Jean Fernel et Padoue (`hist-fa-renouveau`), les ligatures sur le
  serpent (`hist-rv-serpents`), la vision naïve du progrès et le théorème de
  Thalès (`hist-rv-progres-naif`), Eddington et l'éclipse de 1919
  (`hist-qr-eddington`).

## Ce que les annales ont dicté

Huit questions ouvertes, deux par thème ou presque :

| Savoir | Questions |
|---|---|
| Le système galénique et ses dénominations | 2021/2022 Q7, 2022/2023 Q6 |
| Deux erreurs anatomiques de Galien, et ce qui en rend compte | 2024/2025 S1 QROC 6 |
| Le passage pulmonaire, la circulation | 2021/2022 S2 Q7, 2022/2023 S2 Q8 |
| L'épistémologie : obstacle (Bachelard), crise (Kuhn) | 2023/2024 Q7, 2022/2023 Q7 |
| La première dissection humaine et l'analogie avant elle | 2022/2023 S2 Q7 |

Chaque annale a son recto-verso : la question mot pour mot, la bonne réponse au
verso, et chacun de ces savoirs a aussi ses cartes du cours (texte à trous, QROC,
QCM, schéma cliquable), pour qu'on sache répondre avant d'avoir vu la question.

## Les contresens signalés

Chacun est dit par **ATTENTION** dans la carte, là où il se joue ; la carte retient
la bonne lecture. À l'examen, on répond d'abord comme le professeur (règle de
Vincent, 28/09) : quand la formule est celle du Pr Devinant lui-même — la même
phrase dans le Charonéo 2023-24 ou la FC n°1 2024-25 —, ce n'est pas une prise
de notes fausse, et l'ATTENTION dit « c'est le cours lui-même », d'où vient la
formule, « À l'examen : » ce qu'on répond, puis « La référence : » le fait juste
et sa source. Ces lignes commencent par **c'est le cours lui-même** ;
**prise de notes** marque une erreur de la ronéo, et **point douteux** un doute
que les sources ne tranchent pas. Dans la carte, le genre s'écrit juste après le
mot, comme dans `contenu/ERRATA_RONEOS_2026-27.md` : « ATTENTION (cours) »,
« ATTENTION (prise de notes) », « ATTENTION (douteux) » (C11, 28/09). Une ligne
sans genre (une autre année qui se trompe, un corrigé imprécis) garde un
ATTENTION nu, qui reste un avertissement ordinaire.

| Point | Lectures | Retenu | Cartes |
|---|---|---|---|
| Le pape de la dissection | **prise de notes** — **tableau de la promo, 19/10/2026** : ronéo 2026-27 « Sixte VI » (partie 3, p. 3) ; FC n°1 2024-25 « Sixte IV » (p. 17) | **Sixte IV** (1471-1484) ; il n'y a jamais eu de Sixte VI | `hist-qr-pape`, `hist-qc-moyen-age` A |
| La veine du foie | **c'est le cours lui-même** : « veine cave supérieure », lapsus du Pr Devinant noté par trois promotions — Charonéo 2023-24 (partie 1, p. 10, corrigé par son tableau d'erreurs), FC n°1 (p. 14), ronéo 2026-27 (partie 2, p. 5) | à l'examen, la veine cave **inférieure** : c'est elle qui passe par le foie (StatPearls, « Inferior Vena Cava ») | `hist-qr-veine-cave`, `hist-zo-galien` (note de la zone) |
| Artère veineuse | **prise de notes** : ronéo 2026-27 partie 3 (p. 2) : « appeler l'artère veineuse, artère pulmonaire » ; FC n°1 (p. 15), Charonéo 2023-24 (p. 11), corrigé proposé, figure p. 5 : veine pulmonaire | **artère veineuse = veine pulmonaire, veine artérieuse = artère pulmonaire** | `hist-qc-denominations` A, `hist-rv-denominations`, `hist-an-2223-q6`, `hist-zo-galien` |
| Celse | **point douteux** : ronéo 2026-27 (partie 2, p. 2) : il critique dissection et vivisection ; FC n°1 (p. 8) : il défend la dissection des morts | les deux : sa préface **rapporte** l'argument des Empiriques contre les deux (§ 40-44), puis **conclut** que la vivisection est cruelle et inutile, la dissection des morts nécessaire (§ 74-75) | `hist-qc-celse` C, `hist-qr-celse` |
| P.C.A. Louis | **c'est le cours lui-même** : « fin du XIXe », la datation du Pr Devinant dans le Charonéo 2023-24 (partie 2, p. 4) et le ronéo 2026-27 (partie 3, p. 7) | à l'examen, un item « fin du XIXe siècle » se tient pour vrai, et l'essentiel est la méthode numérique ; la référence : **années 1830** (Recherches sur les effets de la saignée, 1835) | `hist-qr-louis` |
| Les capillaires | **point douteux** : ronéo 2026-27 « fin du 17e » (partie 3, p. 7) ; FC n°1 « fin du XIXe » (p. 23) ; Charonéo « XVIIe » | **Malpighi, 1661** (De pulmonibus) | `hist-qr-malpighi` |
| Kuhn | FC n°1 (p. 25) et la fiche d'étudiant : 1942 ; ronéo 2026-27 et Charonéo : 1962 | **1962** | `hist-qr-kuhn-livre` |
| L'utérus vagabond | ronéo 2026-27 : « jusqu'au 19ème siècle » (partie 1, p. 4) ; FC n°1 : « une bonne partie de l'Antiquité » (p. 5) | une théorie hippocratique, rejetée par Galien et Soranos ; c'est le lien utérus-hystérie qui dure jusqu'au XIXe. Aucune carte ne demande de date | `hist-qc-antiquite` E |
| L'embaumement | ronéo 2026-27 : contexte qui « a peut-être pu » ouvrir les corps (partie 1, p. 6) ; FC n°1 : « ne convainc pas les historiens » (p. 6) ; Charonéo : « peu probable » | un contexte possible, **jamais une explication suffisante** | `hist-qc-alexandrie` C |
| Les planches de la Fabrica | FC n°1 (p. 19) et Charonéo (p. 13) : Vésale emploie Léonard, Raphaël, Dürer ; ronéo 2026-27 : les grands artistes ont œuvré à l'anatomie (p. 4) | **impossible** : Léonard (mort en 1519), Raphaël (1520) et Dürer (1528) sont morts avant 1543 ; planches traditionnellement attribuées à Jan van Calcar, aujourd'hui à l'atelier de Titien | `hist-qc-vesale` E |
| Popper et le sens | **prise de notes** : passage gris du ronéo 2026-27 (partie 4, p. 4) : une thèse métaphysique invérifiable est « dépourvue de sens » selon Popper | **faux** : c'est la thèse du Cercle de Vienne ; la falsifiabilité de Popper est un critère de démarcation, pas de sens | `hist-qc-popper` E |
| L'exploit de Galien | **prise de notes** : ronéo 2026-27 : ouvrir la « cavité thoracique » d'un singe pour en sortir les intestins (partie 2, p. 3) | des intestins, c'est l'abdomen ; la carte ne demande pas la cavité | `hist-rv-galien` |
| Le sang au bout du doigt | **prise de notes** : ronéo 2026-27 : un passage « des veines aux artères » (partie 3, p. 7) ; Charonéo 2023-24 : des artères aux veines (partie 2, p. 3) | **des artères aux veines**, par les capillaires | `hist-qc-reception` D, `hist-rv-objections` |
| Harvey, « révolution de la thérapeutique » | **point douteux** : ronéo 2026-27 (partie 3, p. 7), qui ajoute aussitôt qu'il ne change rien aux pratiques ; Charonéo 2023-24 : révolution des théories physiologiques, pas de la médecine (partie 2, p. 4) | **une révolution de la physiologie**, pas de la thérapeutique | `hist-rv-harvey-galeniste` |
| La transfusion | **c'est le cours lui-même** : « standard au 19ème siècle », dit par le Pr Devinant trois années de suite — Charonéo 2023-24 (partie 2, p. 4), FC n°1 (p. 23), ronéo 2026-27 (partie 3, p. 7) | à l'examen, un item qui la dit standard au XIXe se tient pour vrai ; la référence : essais dès 1665-1667, Blundell en 1818, mais **courante au XXe** (groupes ABO 1901, citrate 1914, banques de sang 1937 ; AABB) | `hist-qc-reception` E |
| « Aucun médecin de plus de 40 ans » | **point douteux** : ronéo 2026-27 (partie 3, p. 7) et Charonéo (p. 3) : Harvey le prédit | sans doute **un mot rapporté après lui** (Willis, 1847, « it is said ») ; l'option ne demande plus que sa conscience de la portée de ses travaux ; à l'examen, un item qui lui prête la phrase suit le cours (Charonéo, partie 2, p. 3 : « Il prédit ») | `hist-qc-reception` A |
| Colombo et le septum | **prise de notes** — **tableau de la promo, 11/10/2026** : ronéo 2026-27, Colombo « déclare franchement que les septums n'existent pas » (partie 3, p. 5) ; FC n°1 2024-25 (p. 20) : « les perforations du septum n'existent pas » | Colombo nie les **pores** invisibles du septum interventriculaire, pas la cloison : le sang passe par les poumons (De re anatomica, 1559) | `hist-qr-colombo`, `hist-qc-breches` (explication) |
| Servet et les perforations | **prise de notes**, relevée à la relecture du 11/10/2026 : ronéo 2026-27, « les perforations du système ne sont pas nécessaires » (partie 3, p. 5) ; FC n°1 2024-25 (p. 20) : « les perforations du septum ne sont absolument pas nécessaires » | les perforations **du septum**, les pores invisibles de Galien ; la même partie 3 dit aussi « les septums » pour ces pores, à propos de Vésale (p. 4-5) et de Colombo (p. 5) | `hist-qr-servet` (explication) |
| Realdo Colombo | ronéo 2026-27 : (1510-1559) (partie 3, p. 5) ; Britannica : vers 1516 | **date incertaine** : 1510 est aussi celle du Museo Galileo et du Galileo Project (le DBI dit entre 1510 et 1520) ; relu le 28/09/2026, ce n'est pas une erreur du ronéo | `hist-qr-colombo`, `hist-an-2122s2-q7` |
| Les 250 L/h | ronéo 2026-27 (partie 3, p. 6), FC n°1 (p. 22), corrigé officiel 2022/2023 S2 Q8 : Harvey « aboutit » à 250 L/h | gardé **comme ordre de grandeur** : c'est la reconstruction moderne (2 onces × 72/min × 60) ; au chap. IX du De motu cordis, Harvey reste volontairement bas et dépasse déjà en une demi-heure tout le sang du corps | `hist-fa-quantification`, `hist-qc-quantification` A-B, `hist-an-2223s2-q8` |
| La dissection médiévale | **prise de notes** : ronéo 2026-27 : institutionnelle dès le XIIe, peut-être le XIe « à Salerne, où on a des témoignages … de Mondino » (partie 3, p. 3) | vrai au sens large ; mais Salerne dissèque **le porc** (XIe-XIIe) ; dissections humaines attestées fin XIIIe ; **Mondino, Bologne, 1315**, et il disséquait lui-même | `hist-qc-moyen-age` B, `hist-qr-mondino` |
| La seconde édition de la Fabrica | **c'est le cours lui-même** : elle « ne mentionne pas » les pores (ronéo 2026-27, partie 3, p. 4-5), le récit du Pr Devinant que la FC n°1 faisait déjà (p. 19, note 12 : les perforations « gommées ») | à l'examen, les deux formules vont dans le même sens : « ne mentionne plus les pores » suit le cours, « nie tout passage » reste vrai (Charonéo 2023-24, p. 14) ; la référence : en 1555, Vésale **nie** tout passage à travers le septum ; en 1543, il avouait déjà ne pas le voir | `hist-qc-vesale` D, `hist-qr-pores`, `hist-qc-galien-erreurs` C |
| Dioclès | corrigé officiel 2022/2023 S2 : « première dissection animale » ; ronéo 2026-27 : « le premier à avoir accordé du temps à la dissection » (partie 1, p. 5) | la formule du ronéo ; Aristote disséquait aussi des animaux ; Galien attribue à Dioclès le premier traité d'anatomie | `hist-an-2223s2-q7` |
| La crise de l'astronomie | **point douteux** : ronéo 2026-27 : « à l'époque de Kepler et Galilée » (partie 4, p. 6) | chez Kuhn, **avant Copernic**, au début du XVIe siècle (Structure, chap. VII) ; Kepler et Galilée sont la révolution. Le paradigme de Ptolémée dominait encore de leur temps : une imprécision de date plus qu'une erreur | `hist-rv-crise`, `hist-an-2223-q7` |
| Les « étoiles » qui rétrogradent | **c'est le cours lui-même** : le mot du Pr Devinant, dans le Charonéo 2023-24 (partie 2, p. 6) et le ronéo 2026-27 (partie 4, p. 6) | à l'examen, on ne rejette pas un item parce qu'il dit « étoiles » ; la référence : ce sont les **planètes** (planêtês, « errant ») qui rétrogradent, les étoiles fixes non (Britannica) | `hist-rv-crise` (explication) |
| Kuhn, le progrès et l'incommensurabilité | **point douteux** : ronéo 2026-27 : pas de progrès d'un paradigme à l'autre ; « incommensurabilité (= incomparabilité) » (partie 4, p. 7) | la lecture du cours est gardée pour l'examen, avec la nuance de Kuhn : **un progrès en capacité à résoudre des énigmes, pas vers la vérité ; incommensurable ≠ incomparable** (SEP) ; l'option D ne dit plus que « pas de mesure commune » | `hist-qc-kuhn` D-E, `hist-qr-incommensurabilite`, `hist-rv-popper-kuhn`, `lex-incommensurabilite` |
| Le théâtre anatomique de Padoue | ronéo 2026-27 : Vésale à Padoue, « première université avec un théâtre de dissection au monde » (partie 3, p. 4) | vrai de Padoue, mais le premier théâtre permanent date de **1594-1595** (Acquapendente) : Vésale n'y a pas disséqué | `hist-fa-renouveau` |

Et, sans ATTENTION parce qu'aucune carte n'en dépend : « George Canguilem »
(partie 1, p. 1-2) pour Georges Canguilhem ; les 30 cL par systole,
que le ronéo dit faux lui-même, ne sont demandés nulle part ; Descartes soutient
Harvey « en privé » selon le ronéo, mais aussi publiquement dans le Discours de
la méthode (1637), dit comme hors cours (`hist-qc-reception` C) ; les 13 L
d'urine de Galien ne sont retrouvés que dans le cours, et la carte le dit.

## Le sujet 2025/2026 (18/10/2026)

Les sujets de SSH de l'examen du 09/01/2026 (1 QR, 10 QROC,
`src-sujets-ssh-2526`, sans corrigé), déposés le 18/10/2026, apportent 1
recto-verso à ce chapitre (QROC 1). Aucun n'était déjà en cartes. Au verso, la
bonne réponse, tirée du ronéo 2026-27 quand il couvre la notion, sinon du
cours 2025-26, celui de l'année de l'examen ; ce qui dépasse le cours est dit
« hors cours », avec sa source (`officielle=False`). Rédigés et
contre-vérifiés le 18/10/2026 : un rédacteur, un sceptique, un critique de
complétude.

| Question | Ce que le verso répond | Voisine de |
|---|---|---|
| 2025/2026 S1 QROC 1 (`hist-an-2526s1-qroc1`) | deux lectures des valvules : les écluses d'Acquapendente dans le système de Galien, la preuve de la circulation chez Harvey ; l'obstacle épistémologique (Bachelard) ; l'anomalie réduite, puis la révolution (Kuhn) | `hist-an-2324-q7` |

Ce qui est signalé :

- La QROC 1 applique Bachelard (l'obstacle épistémologique) et Kuhn (paradigme,
  anomalie, révolution) aux valvules veineuses, qu'Acquapendente et Harvey
  lisent différemment ; voisine de 2023/2024 Q7 (l'obstacle) et de 2022/2023
  Q7 (la crise selon Kuhn).
- « Fabrizio d'Acquapendente », la forme italienne, est gardé ; le ronéo 2026-27
  écrit « F. d'Acquapendente », la FC n°2 2025-26 « Aquapendente ». La date de
  De venarum ostiolis (1603) est hors cours.

## Les clés qui ne sont pas reprises telles quelles

Aucune annale n'est un QCM : `CONFLITS` est vide, et chaque écart se dit dans
l'`explain` de la carte. Le polycopié ne donne de corrigé officiel que pour
2022/2023 S2 ; les cinq autres réponses sont une « proposition de corrigé »
d'étudiant, non officielle. Le sujet de 2024/2025, déposé le 15/10/2026, n'a
aucun corrigé.

| Question | Corrigé imprimé | Retenu | Pourquoi |
|---|---|---|---|
| 2023/2024 Q7 (obstacle épistémologique) | non officiel : obstacle dû « à sa familiarité, ou à la réputation de la personne qui l'a émise » | familiarité **et surtout force explicative** ; l'autorité de Galien comme facteur secondaire | imprécis plutôt que faux : l'influence de Galien a joué (partie 2, p. 4), mais « ce n'est pas prioritairement une question de respect » (partie 3, p. 3 ; FC n°1, p. 16). ATTENTION dans la carte |
| 2021/2022 Q7 (trois systèmes) | non officiel : « le poumon charge le sang de pneuma » | le mélange se fait **dans le cœur gauche**, le poumon fournit l'air | ronéo 2026-27 (partie 2, p. 5), FC n°1 (p. 14). ATTENTION dans la carte |
| 2022/2023 Q6 (dénominations) | non officiel, juste sur les identités ; « sang désoxygéné » ; les poumons « chargent en pneuma » | les identités, sans l'oxygène, et le mélange dans le cœur gauche | anachronisme : l'oxygène est inconnu avant le XVIIIe siècle ; même erreur de lieu que 2021/2022 Q7 |
| 2022/2023 Q7 (crise selon Kuhn) | non officiel : deux issues | les deux issues, **plus la troisième de Kuhn**, dite hors ronéo (problème mis de côté) ; la crise datée d'avant Copernic | les deux issues sont celles de la FC n°1 (p. 26) et du Charonéo (p. 6) ; le ronéo 2026-27 ne dit en toutes lettres que la révolution ; Structure, chap. VII et VIII |
| 2022/2023 S2 Q7 | officiel, avec « (de Chalcédoine) », « (de Céos) », « de Cariste », et « première dissection animale » | officiel, sans demander les lieux ; Dioclès « le premier à consacrer du temps à la dissection » | consigne du professeur, Charonéo 2023-24 p. 5 ; Aristote disséquait aussi des animaux. La clé reste officielle : ses quatre éléments sont repris |
| 2022/2023 S2 Q8 | officiel : 250 L/h | officiel, avec la réserve : 250 L/h est une reconstruction, l'argument est l'ordre de grandeur | De motu cordis, chap. IX |
| 2021/2022 S2 Q7 | non officiel : Colombo, Ibn al-Nafis | juste ; Servet ajouté ; Colombo né vers 1510 | troisième nom du cours ; date incertaine (1510-1516 selon les sources) |
| 2024/2025 S1 QROC 6 (deux erreurs de Galien) | aucune (sujet sans corrigé) | **clé déduite** : les pores invisibles du septum, le rete mirabile ; la dissection animale et l'anatomie fonctionnelle ; leur survie par l'autorité et la force du système | le ronéo 2026-27 les donne en toutes lettres (partie 2, p. 4-5 ; partie 3, p. 3-4) |

Cas ouvert : aucun.

## Absent du cours 2026-27

Deux cartes n'ont **pas de version 2026-27** et le disent, en tête de leur
explication. Elles citent la FC n°1 2024-25 à sa page (`fiche` = `src-cours-ssh-2425`) :

| Carte | Ce qui manque au ronéo 2026-27 | Source restée |
|---|---|---|
| `hist-qr-teleologie` | le mot « téléologique », le De usu partium, la nature « providentielle » ; le ronéo dit l'idée sans le mot (partie 2, p. 3) | FC n°1 2024-25, p. 11 |
| `hist-qr-prosecteur` | le mot « prosecteur » ; le ronéo dit « un subalterne » (partie 3, p. 3) | FC n°1 2024-25, p. 17 ; Charonéo 2023-24, p. 13 |

`hist-qr-veine-porte` n'en fait plus partie : le texte du ronéo 2026-27 ne nomme
pas la veine porte, mais sa figure la montre (« Portal vessel », partie 2, p. 5) ;
la carte cite cette page. Seul le **chyle** est absent du cours 2026-27 (FC n°1
2024-25, p. 14 ; Charonéo 2023-24, p. 10), et son explication le dit.

Détails de la FC n°1 gardés **dans des explications** de cartes par ailleurs
vérifiées, et dits comme tels : l'horloge à eau d'Hérophile (`hist-fa-herophile`),
Celse source tardive (`hist-qc-celse` D), la date de 1938 pour Bachelard
(`hist-qr-bachelard`), le traité de Fernel de 1542 (`hist-fa-renouveau`), la
ligature de la veine cave (`hist-rv-serpents`).

## Les figures du ronéo

Extraites telles quelles des PDF 2026-27 (PyMuPDF), en PNG — seul le lapin-canard,
un dessin au trait de 1029 × 947 px, a été passé en gris et réduit de moitié
(520 Ko → 73 Ko) ; toujours du côté de la correction. **9 QCM sur 17 illustrés
(53 %)**, 31 notes sur 94.

| Fichier | Partie, page | Ce qu'elle montre | Cartes |
|---|---|---|---|
| `systeme-galenique.png` | 2, p. 5 | foie, veine cave, ventricules, arteria venalis et vena arterialis, rete mirabile, veine porte | 14 : `hist-fa-trois-systemes`, `hist-fa-sang-galenique`, `hist-qc-galien-erreurs`, `hist-qc-systeme`, `hist-qc-denominations`, `hist-qr-rete`, `hist-qr-pores`, `hist-qr-veine-cave`, `hist-qr-veine-porte`, `hist-rv-denominations`, `hist-zo-galien`, `hist-an-2223-q6`, `hist-an-2122-q7`, `hist-an-2425s1-qroc6` |
| `lecon-anatomie-medievale.png` | 3, p. 3 | le maître en chaire, le subalterne qui dissèque | 3 : `hist-fa-lecon-medievale`, `hist-qc-moyen-age`, `hist-qr-prosecteur` |
| `fabrica-frontispice.png` | 3, p. 4 | Vésale au centre, les mains sur le corps | 3 : `hist-qc-vesale`, `hist-rv-deux-lecons`, `hist-fa-renouveau` |
| `fabrica-planches.png` | 3, p. 4 | les écorchés de la Fabrica | 1 : `hist-fa-fabrica` |
| `harvey-ligature.png` | 3, p. 6 | la ligature du bras, la veine gonflée jusqu'à la valvule | 3 : `hist-fa-harvey-coeur`, `hist-qc-breches`, `hist-qc-harvey` |
| `lapin-canard.png` | 4, p. 6 | le lapin-canard de la Gestalt-théorie | 6 : `hist-fa-kuhn`, `hist-qc-kuhn`, `hist-qc-harvey-kuhn`, `hist-qr-incommensurabilite`, `hist-qr-lapin-canard`, `hist-an-2223-q7` |
| `systeme-galenique-nu.svg` | 2, p. 5 (redessiné) | le même système, sans légende, pour le clic | la question de `hist-zo-galien` |

La figure du système galénique est légendée en anglais et numérotée (1 foie,
2 veine cave, 3 ventricule droit, 4 ventricule gauche) : elle ne va que du côté de
la réponse ; le schéma redessiné, lui, n'a aucune légende. Les pages de couverture
et les bandeaux des quatre ronéos n'ont pas été repris. Les QCM non illustrés
(Canguilhem, Antiquité, Alexandrie, Celse, anatomie de Galien, quantification,
réception, Popper) n'ont pas de figure dans le ronéo.

## Le lexique

Dix termes, les concepts que les annales et le cours emploient, chacun avec son
**origine grecque ou latine** dans la définition et dans ses racines (demande de
Vincent, 26/09) ; pages mesurées dans le texte des quatre ronéos 2026-27 :

| Terme | Origine | Pages (partie, page) |
|---|---|---|
| Paradigme | grec paradeigma, « exemple » | 4 p. 5-7 ; 3 p. 5 |
| Science normale | latin scientia, norma | 4 p. 5-7 |
| Anomalie | grec anômalia (a- privatif, homalos) | 4 p. 5-7 |
| Crise scientifique | grec krisis, « décision » | 4 p. 6-7 |
| Révolution scientifique | latin revolutio (revolvere) | 4 p. 2, 5-7 ; 1 p. 2 ; 3 p. 5 |
| Incommensurabilité | latin in-, cum, mensura | 4 p. 7 |
| Falsifiabilité | latin falsus, par l'anglais | 4 p. 3-4 |
| Obstacle épistémologique | latin obstaculum ; grec epistêmê, logos | 2 p. 6 ; 3 p. 3, 5 |
| Pneuma | grec pneuma, « souffle » | 2 p. 5 |
| Autopsie | grec autos, opsis | 1 p. 3 ; 3 p. 4 |

Aucun autre chapitre de l'UE SSH n'existe encore : aucun terme n'a été laissé
ailleurs. **Une seule racine est enseignée par la FC de sémantique** : le
privatif `a-/an-` d'« anomalie », qui cite `src-fc-semio-semantique-1`, p. 3,
comme dans les chapitres de sémiologie ; l'écran l'ouvre et relie le terme à la
racine. Les autres (paradeigma, homalos, krisis, epistêmê, pneuma…) ne sont pas
dans ses tableaux : elles s'affichent en gris, « hors FC », et portent
« (grec) » ou « (latin) » dans leur forme, faute de champ langue dans le modèle
des racines. « Démarcation », d'origine germanique (marka, « frontière »),
n'est pas un terme du lexique mais a sa QROC. Les étymologies reviennent aussi
dans les explications des cartes (sphygmologie, rete mirabile, récurrent,
vivisection, dissection, épicycle, planète, symétrie, chyle, prosecteur,
téléologique, péripatéticien — de peripatos, les allées couvertes du Lycée, et non
d'un Aristote qui enseignerait en marchant, légende plus tardive).

## À relire

**0 carte `a-relire`** : chaque note cite une page du ronéo 2026-27 (73 notes du
cours — 15 de la partie 1, 21 de la 2, 24 de la 3, 13 de la 4 — et les 10 termes
du lexique) ou de la FC n°1 2024-25 (les deux absentes), et les huit annales
disent d'où vient leur réponse. Reste à Vincent :

- les deux cartes « Absent du cours 2026-27 » : les garder ?
- le « livre à lire » annoncé partie 1, p. 7 : le ronéo ne le nomme pas ; s'il
  entre au programme, il appellera ses propres cartes.
- Kuhn et le progrès : la carte garde, pour l'examen, la lecture du cours (pas de
  progrès d'un paradigme à l'autre) et dit la nuance de Kuhn. Si le professeur
  attend la lecture stricte du cours, rien à changer ; sinon, la carte le dit déjà.
- le tableau d'erreurs SSH 2026-27 ne relève que Colombo (11/10) et Sixte VI
  (19/10) : y signaler l'artère veineuse inversée, « des veines aux artères », les
  « perforations du système » de Servet ? La veine cave « supérieure »
  n'est pas une prise de notes fausse mais un lapsus du professeur, redit
  chaque année : le signaler, s'il l'est, comme tel.

## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier (BMCP) ou du 6 janvier (SSH, papier). Sous les annales, 31 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 7 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `antiquite` | 4 | 1 | 1 |
| `galien` | 10 | 2 | 3 |
| `renaissance` | 3 | 1 | 1 |
| `harvey` | 3 | 1 | 1 |
| `epistemologie` | 7 | 1 | 2 |
| `kuhn` | 4 | 1 | 1 |

**Le schéma** `ech-galien-harvey`, « De Galien à Harvey · voir, ne pas voir », donne 39 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_GALIEN_HARVEY`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Constantes ajoutées** à `annales.py` (`_SCHEMA_LETTRES`, `_SCHEMA_NU`) : les annales de SSH sont toutes des QROC, rangées dans `ANNALES_QROC` ; chacune reçoit le schéma nu, et les marches la préparent sans lettre.

**Sans marche** :
- hist-an-2223-q7, l'exemple de crise (l'astronomie de Ptolémée et ses épicycles) : pas de marche, la date que le ronéo 2026-27 lui donne (« à l'époque de Kepler et Galilée ») est un point douteux que l'annale signale.
- hist-an-2324-q7 et hist-an-2425s1-qroc6, les 300 erreurs de Vésale : seulement en justification (hist-ech-s23), la seconde édition de la Fabrica étant une erreur signalée du ronéo.

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```

## Questions pour Vincent

- (11/10) SSH : signaler aussi au tableau de la promo les « perforations du système » de Servet (p. 5), une erreur de prise de notes prouvée par la FC n°1 2024-25 (p. 20) ? J'ai traité le « septums » mis pour les pores à propos de Vésale (p. 4-5) comme le même glissement que pour Colombo, sans entrée à part : hist-qc-vesale lit déjà « septums » comme les pores.
