# Sémiologie digestive normale — paquet d'exemple

70 notes, 112 cartes. Deux sources : la fiche de cours, et les annales des dix
dernières sessions avec leur table de corrections officielle.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 41 | 41 |
| QROC | 11 | 11 |
| Texte à trous | 10 | 33 |
| Repérage sur schéma | 4 | 21 |
| QRU | 2 | 2 |
| Recto-verso | 2 | 2 |

Plus 17 images : 15 tirées du cours, 2 redessinées.

**25 QRM sont des annales** : 23 du polycopié, de 2015/2016 à 2023/2024, et 2
du sujet 2025/2026. Leurs énoncés sont reproduits tels qu'imprimés ; elles
portent l'étiquette « Annales » et la session dont elles viennent. Les autres
sont écrites depuis la fiche et ne prétendent à aucune clé officielle.

## Les clés non reprises telles quelles

**La clé retenue est la bonne, pas la clé imprimée** (règle de Vincent,
26/09/2026) : celle du cours de l'année, ou celle de l'analyse vérifiée sur des
sources sûres quand le cours se trompe. Chaque écart est déclaré dans
`CONFLITS` (`annales.py`) et dit dans la justification de l'item, qui commence
par `ATTENTION` ; le générateur refuse d'écrire si l'une d'elles perd son
avertissement. Revu le 26/09/2026 (tâche C7).

Cinq items imprimés ne sont pas repris. Les quatre questions en cause sont
marquées **non officielles**.

| Question | Item | Clé imprimée | Retenu | Pourquoi | Source |
|---|---|---|---|---|---|
| 2022/2023 S2 Q25 | E | ADE (E vrai : marge anale en genu pectorale) | AD (E faux) | la fiche et le ronéo 2026-27 (p. 12) : « décubitus latéral plutôt que genu pectorale », bien moins inconfortable ; aucune position n'est imposée | SNFCP, « Petits conseils pour un examen proctologique sans malentendu » |
| 2018/2019 Q21 | A | BDE (A faux : le toucher rectal serait systématique) | ABDE (A vrai) | la fiche et le ronéo 2026-27 (p. 12) : « pas réalisé systématiquement », consentement d'abord | CCNE, avis 142 (2023) : pertinence réinterrogée au cas par cas, consentement explicite |
| 2016/2017 S2 Q15 | D | ACDE (D vrai : quadrants de bas en haut) | AE (D faux) | la fiche et le ronéo 2026-27 (p. 5) : « de haut en bas », en terminant par la région inguinale ; ce qui part d'en bas est la palpation du bord du foie, un geste, pas l'ordre des quadrants | Patient.info, « Hepatomegaly » (fiche professionnelle) |
| 2016/2017 S2 Q15 | C | ACDE (C vrai : douleur gynécologique péri-ombilicale) | AE (C faux) | la douleur gynécologique est pelvienne, sous-ombilicale (hypogastre, fosses iliaques) ; la douleur viscérale de l'ovaire (T10) peut débuter autour de l'ombilic, mais c'est l'exception, pas l'« habituellement » de l'énoncé ; la fiche digestive n'en parle pas | ronéo de sémiologie gynécologique 2026-27, p. 5-6 ; CNGOF, référentiel 2018, douleur pelvienne aiguë |
| 2016/2017 S2 Q14 | A | AE (A vrai : taille / poids) | E (A faux) | taille / poids n'est pas l'IMC : la coquille est dans la table | OMS, aide-mémoire « Obésité et surpoids » |

Et une question **ouverte**, clé gardée, carte officielle :

| Question | Item | Clé imprimée | Retenu | Les deux lectures | Sources |
|---|---|---|---|---|---|
| 2019/2020 S2 Q14 | C | ABCE (mérycisme : régurgitation « volontaire », vrai) | la clé, ABCE | volontaire : la définition française classique ; involontaire : l'erratum du Charonéo 2023-24 (avis du bureau : OK), comme Rome IV (contraction apprise mais inconsciente) ; le ronéo 2026-27 ne parle plus du mérycisme | Larousse médical ; FMC-HGE, Postu 2024 ; Halland, Pandolfino, Barba, *Clin Gastroenterol Hepatol* 2018 ; FMC-HGE, Postu 2019 (F. Mion : contraction « volontaire » mais non perçue par le patient) |

## Les cartes de repérage

Quatre schémas cliquables, parce qu'une localisation ne se révise pas en prose.

1. **Les neuf quadrants** — 9 cartes. « Clique sur l'épigastre. »
2. **Les cicatrices abdominales** — 4 cartes. Médiane, sous-costale droite,
   lombotomie, Mac Burney.
3. **Les orifices herniaires** — 4 cartes. Ligne blanche, ombilicale, inguinale,
   crurale.
4. **Les points douloureux** — 4 cartes. Murphy, Mac Burney, sigmoïde, Troisier,
   chacun avec la maladie qu'il désigne.

Le fond des deux schémas est redessiné en SVG, nu : ceux du cours portent déjà
leurs légendes et donneraient la réponse. Ils reviennent en illustration de la
correction.

**La latéralité est le piège, et il est assumé.** Le schéma se lit de face :
la droite du patient est à gauche de l'image. La correction le rappelle sur
chaque zone concernée.

## Les cartes dont la question est une photographie

Deux, et deux seulement : l'angiome stellaire et la hernie ombilicale. Ce sont
les seules images du cours qui ne portent pas déjà leur propre légende. Toutes
les autres restent du côté de la réponse.

## Ce que les annales ont corrigé dans les cartes de cours

Trois cartes écrites depuis la fiche ont été reprises après lecture des clés :

- la palpation du foie — la fiche dit qu'elle est difficile, les annales
  demandent quatre fois que le bord inférieur **est** palpable chez le sujet
  sain ; la proposition a été réécrite pour coller à ce qui est marqué ;
- l'ordre des quatre temps — les annales tranchent : on ausculte avant de
  palper, on percute après ;
- l'examen de la marge anale — les deux désaccords ci-dessus y sont signalés,
  et les annales en cause suivent désormais la fiche.

## Comment la fiche a été lue

Le code couleur de l'auteur fait foi :

- **rouge** — à savoir, prioritaire ;
- **gris** — hors programme, annoncé tel quel par le professeur ;
- **commentaires en marge** — précisions de l'auteur.

La section IV, « Vocabulaire pathologique », est entièrement grise : aucune
carte n'en sort. Le paragraphe sur l'ascite l'est aussi, à ceci près que le
signe du flot et le signe du glaçon y sont écrits en rouge. Le rouge l'emporte,
mais la carte le signale (`dig-flot-glacon`).

Les sept commentaires ont été relus un à un. Deux portent sur ce qui tombe à
l'examen et ont produit des cartes directement :

- « À l'examen : examen de l'abdomen normal est tympanique sauf le foie sauf en
  sus-pubien » → `dig-percussion`, où la proposition correspondante est marquée
  **indispensable** : l'oublier annule la question.
- « Retrouver les maladies associées » → la carte de repérage des points
  douloureux, où chaque point nomme son diagnostic.

Deux autres ont écarté du contenu : « pas interrogé » sur le schéma des douleurs
épigastriques, et « osef » sur les perturbations du transit.

Trois sujets ne sont **que** dans les annales, parce que la fiche les range en
gris : les hémorragies digestives (méléna, hématémèse, rectorragie), le
vocabulaire des signes fonctionnels majeurs, et la définition OMS de la
diarrhée. Ils ont pourtant produit six questions d'examen. Ils sont donc là,
sous les thèmes « Hémorragies digestives » et « Vocabulaire digestif », faciles
à écarter d'une session si le programme de cette année les exclut vraiment.

## Erreurs du ronéo 2026-27

Relevées à la relecture du 28/09/2026 ; aucune n'est dans le tableau d'erreurs
de la promo, et les cours ne seront pas modifiés. Elles sont aussi dans
`contenu/ERRATA_RONEOS_2026-27.md`. Chacune est triée (règle de Vincent : à
l'examen, on répond d'abord comme le professeur) : une prise de notes fausse,
que la carte corrige, ou le cours lui-même, auquel la carte répond comme le
professeur en donnant la référence.

| Page | Imprimé | À lire | Carte |
|---|---|---|---|
| p. 2 | IMC = « (poids en kg / taille) au carré » | poids / taille², en kg/m² (OMS) | `dig-imc` (ATTENTION) |
| p. 7 | l'hippocratisme digital se rencontre dans « la BPCO à un stade avancé » — **c'est le cours lui-même** : déjà dans le ronéo 2025-26 du Pr Veziant, et « ou un BPCO » dans le Charonéo 2023-24 du Pr Piessen | à l'examen, un item de sémiologie digestive qui le reprend se coche ; la référence : la BPCO seule n'en donne pas, chez un BPCO il fait chercher un cancer bronchique ou une dilatation des bronches (Sarkar et al., *Lung India* 2012 ; CEP, item 209) | `dig-hippocratisme` : la réponse cite le cours, BPCO avancée et MICI (ATTENTION) |

## Le corrigé officiel 2023-24

Le sujet de sémiologie générale 2023-24 et son corrigé officiel (une clé par question) sont arrivés le 15/10/2026. Les cartes de cette session venaient du polycopié et en gardent la source ; leur clé est vérifiée :

- 2023/2024 Q16 (`dig-an-2324-q16`, ACD) : clé confirmée par le corrigé officiel 2023-24, dépôt du 15/10/2026.
- 2023/2024 Q17 (`dig-an-2324-q17`, C) : clé confirmée par le corrigé officiel 2023-24, dépôt du 15/10/2026.


## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026)

L'échelle du pilote de l'immunité innée, étendue à la sémiologie pour l'examen du 4/11 (Vincent, 16/10 : « on continue pour les chapitres que je vais avoir à l'examen »). Sous les annales, 32 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 11 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `topographie` | 3 | 1 | 3 |
| `interrogatoire` | 2 | 1 | 1 |
| `douleur` | 2 | 1 | 2 |
| `inspection` | 2 | 1 | 1 |
| `palpation` | 6 | 1 | 5 |
| `percussion` | 3 | 1 | 1 |
| `auscultation` | 4 | 1 | 1 |
| `hernies` | 3 | 1 | 2 |
| `foie-rate` | 1 | 0 | 1 |
| `marge-anale` | 2 | 1 | 1 |
| `hemorragies` | 1 | 1 | 3 |
| `vocabulaire` | 3 | 1 | 4 |

**Le schéma** `ech-abdomen`, « L'examen de l'abdomen · interroger, situer, examiner », donne 69 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_ABDOMEN`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sources.** `SRC` n'a pas de clé `fiche` : chaque marche nomme la sienne (`fiche="src-fc-semio-dig"`, la ronéo 2026-27), et les images de l'échelle sont déclarées sous `SRC["cours"]`.

**La section IV « Vocabulaire pathologique »**, grise dans la FC n°3 2025-26, ne l'est plus dans le ronéo 2026-27 (p. 13-14) : ses marches ne portent pas le tag `edn` ; Vincent tranche s'il veut l'écarter.

**Sans marche** :
- dig-an-2324-q16 B — les repères de la ligne de Malgaigne (épine iliaque antéro-supérieure, pubis) ne sont écrits que dans les énoncés d'annales ; le ronéo 2026-27 trace la ligne sur sa figure (p. 10) sans les nommer.
- dig-an-2324-q17 C, dig-an-2223s2-q24 C, dig-an-1819-q22 E, dig-an-1920s1-q22 E — cæcum, côlon gauche et côlon transverse à la palpation profonde : absents du ronéo 2026-27 (lettres posées sur la case Palpation).
- dig-an-2223s2-q25 B, dig-an-1920s2-q13 E — le rein gauche à la palpation : absent du ronéo 2026-27.
- dig-an-2223s2-q24 B — péristaltisme visible chez le sujet maigre : le ronéo ne rattache « les sujets maigres » qu'aux battements aortiques (p. 6).
- dig-an-1920s1-q21 A — le sens de percussion de la flèche hépatique : le ronéo ne donne que la ligne et la norme (p. 11) ; la marche s16 (médio-claviculaire droite) ne la prépare pas, elle ferait croire la proposition vraie.
- dig-an-1920s2-q14 A — « percussion après la palpation » : seul l'ordre de la liste des quatre étapes le dit (p. 6), liste qui met aussi l'auscultation en dernier quand le cours la fait en premier (p. 12), et la palpation du foie part de la limite inférieure de la matité hépatique (p. 9) ; une marche le trancherait en inventant.
- dig-an-1920s2-q14 B — la matité de la splénomégalie à la place du tympanisme de l'estomac et du côlon : absente du ronéo 2026-27.
- dig-an-1920s2-q14 C — le mérycisme : absent du ronéo 2026-27, et conflit resté ouvert dans CONFLITS.
- dig-an-1718-q24 E, dig-an-1617s2-q12 C, dig-an-1516-q12 B — le méléna « proximal » : le ronéo ne donne que la couleur du sang au doigtier (p. 12).
- dig-an-1617s2-q12 E, dig-an-1516-q12 D — les hémorragies non extériorisées : absentes du ronéo 2026-27.
- dig-an-1617s2-q13 B — les borborygmes : absents du ronéo 2026-27.
- dig-an-1617s2-q15 A — le nombre de quadrants est le titre de la case et se recompte sur ses lignes (trois étages de chaque côté et au milieu) : une case vide n'y cacherait rien.
- dig-an-1617s2-q15 C — la douleur gynécologique : hors du ronéo digestif (ronéo de sémiologie gynécologique 2026-27, p. 5-6), et conflit déclaré.
- dig-an-1617-q13 A, B, C et dig-an-1516s2-q14 B, D, E — le statut de « signe fonctionnel majeur », l'halitose et la dyspepsie : absents du ronéo 2026-27 ; s28, s29 et m7 ne préparent que le vocabulaire de 2016/2017 Q13 D, E et de 2015/2016 S2 Q14 A, C.
- dig-an-1516-q13 C, D et dig-an-1516s2-q13 C — appendicite à début épigastrique, salpingite, infarctus du myocarde : absents du ronéo digestif 2026-27.

## Régénérer

```powershell
python generer.py
```

Réécrit les deux schémas SVG puis `paquet.json`. Le script valide avant
d'écrire et refuse d'écrire s'il trouve une erreur : proposition sans
justification, zone sans phrase explicative, zones qui se recouvrent, image
déclarée mais absente, thème inconnu.

## Charger dans l'application

Le paquet est découvert au premier démarrage, avec tous ceux de
`contenu/chapitres/`. Sur une bibliothèque qui contient déjà des notes, les
réglages le proposent (« Chapitres livrés »), et une fois installé il se met à
jour seul au démarrage d'une version qui le corrige.
