# Développement d'un médicament et études cliniques de phase III — paquet Biomédecine quantitative

81 notes, 124 cartes. Chapitre `chap-ue-biomed-quanti-fc9` de l'UE Biomédecine
quantitative, ordre 6. Cours du **Pr N. Penel et du Pr G. Ficheur, le
14/11/2025**, « Développement d'un médicament — études cliniques de phase III —
exemple des anticancéreux » (FC n°6 du Ronéosaure 2025-26, en deux parties :
8 h-9 h, 11 pages ; 9 h-10 h, 10 pages) ; annales des polycopiés « 9. Essais
thérapeutiques de phase III » (24 questions) et « 8.Essais de phases 1 et 2 »
(1 question) du Ronéosaure 2024-25, 25 questions sur 10 sessions. Examen du
16 décembre 2026.

**Une fiche provisoire.** Le ronéo 2026-27 de ce cours n'est pas paru au
02/10/2026 : le chapitre est carté sur le Ronéosaure 2025-26 (tâche C15,
décision de Vincent du 02/10), et le ronéo de l'année corrigera les cartes à sa
parution. Les deux sources portent leur année dans leur auteur (« Ronéosaure
2025-26 ») : chaque carte de cours prend le tag `cours-2025-26` et montre
« Cours 2025-26 ». Aucune carte ne dit « Absent du cours 2026-27 », et les
erreurs du Ronéosaure sont dites par un ATTENTION sans genre : la liste des
erreurs de la promo, `contenu/ERRATA_RONEOS_2026-27.md`, ne concerne que les
ronéos 2026-27.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 46 | 46 |
| QRU | 1 | 1 |
| Texte à trous | 11 | 52 |
| QROC | 7 | 7 |
| Recto-verso | 6 | 6 |
| Schéma cliquable | 1 | 3 |
| Planche à légender | 1 | 1 |
| Lexique | 8 | 8 |

Dont **25 annales** (QRM), sur 10 sessions, de 2015/2016 S1 à 2023/2024 S1. Les
22 QCM du cours ont, comme les annales, une justification par proposition.

Huit thèmes, dans l'ordre du cours :

| Clé | Libellé |
|---|---|
| `developpement-medicament` | Développement d'un médicament (partagé avec `biostat_phases_1_2`) |
| `non-inferiorite` | Supériorité et non-infériorité (partagé avec `biostat_dispositifs_medicaux`) |
| `critere-jugement` | Critère de jugement principal — **nouveau** |
| `protocole` | Protocole et analyses pré-spécifiées (partagé avec `biostat_phases_1_2`) |
| `randomisation` | Randomisation, placebo et aveugle (partagé avec `biostat_dispositifs_medicaux`) |
| `facteurs-confusion` | Facteurs de confusion et ajustement — **nouveau** |
| `nombre-sujets` | Nombre de sujets nécessaires (partagé avec `biostat_phases_1_2`) |
| `ethique-biais` | Ambivalence, équipoise et biais — **nouveau** |

Trois libellés nouveaux, à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) : tant qu'ils n'y sont pas,
`test_tout_theme_du_paquet_a_son_libelle` échoue pour ce chapitre. Les clés
sont celles du plan C15 ; aucune ne porte de chiffre.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-biomed-ec3a-2526` — Ronéosaure, « FC n°6 développement médicament, phase essai 3 » (11 p.), `BIOMEDECINE QUANTI/…` | **2025-26** | **la base**, première heure : chaque note qui la cite porte sa page ; le lecteur l'ouvre (`chapitre=`) ; `SRC["fiche"]` |
| `src-fc-biomed-ec3b-2526` — Ronéosaure, « FC n°6 partie 2 développement médicament et essai clinique phase 3 » (10 p.) | **2025-26** | **la base**, seconde heure : ses cartes portent `fiche=` ; le lecteur l'ouvre aussi (`chapitre=`) |
| `src-annales-9-essais-therapeutiques-de-phase-iii` — « 9. Essais thérapeutiques de phase III » (14 p., table p. 14) | 2024-25 | 24 des 35 questions ; les 11 autres (phases I-II) sont au chapitre `biostat_phases_1_2` |
| `src-annales-8-essais-de-phases-1-et-2` — « 8.Essais de phases 1 et 2 » | 2024-25 | sa 2019/2020 S1 Q6 (méthodologie générale) |
| errata des cours 2025-26 (`Erratas Biomédecine Quanti.docx`) et errata des annales 2024-25 | — | deux entrées sur la FC n°6 partie 2 (p. 3, p. 6), reprises ; rien sur le polycopié 9 |
| cours 2024-25 (FC phase III, Ronéosaure 2024-25) | 2024-25 | lu pour comprendre les annales (la clause d'ambivalence, l'essai « contrôlé »), non déclaré : aucune carte n'en dépend |

**Les deux polycopiés d'annales sont déclarés exactement comme dans
`biostat_phases_1_2`** (même identifiant, mêmes champs), qui les déclarait le
premier. Les en-têtes des deux fiches (correcteurs, binômes) ne sont repris nulle
part.

**Une session, un polycopié.** Le générateur ne cite qu'une source par session
(`SRC["sessions"]`). La 2019/2020 S1 Q6, seule question du polycopié 8 dans une
session dont le polycopié 9 donne les Q7 à Q10, cite donc le polycopié 9 ; son
explication dit où elle est vraiment imprimée. Le polycopié 8 reste déclaré.

**Les figures.** Dix-huit diapositives extraites en PNG. Celles de la partie 1
(p. 2 et 6) sont, dans le PDF, des captures d'écran de tablette (plateforme
vidéo, onglets, nom de la personne qui a déposé la vidéo) : elles sont
recadrées sur la seule diapositive, rien d'autre n'est gardé. L'image
d'immunohistochimie (partie 2, p. 10) est réduite à 700 px de large ; elle
n'illustre que la QROC qui la commente.

Vérifications hors du cours, citées dans la carte qui s'en sert : de Bono et
al., N Engl J Med 2011 (abiratérone : randomisation 2 pour 1, 797 contre 398
patients, 14,8 contre 10,9 mois, HR 0,65 [0,54-0,77]) ; Kaufman et al., J Clin
Oncol 2015 (éribuline : 15,9 contre 14,5 mois, p = 0,056, la courbe de la
fiche) ; l'étymologie (TLFi, Gaffiot, Wiktionnaire, Etymonline).

## Ce que le cours a dicté

- **Le rouge** n'est que dans les titres, et le point final de « la
  randomisation est l'allocation aléatoire des traitements » (p. 8) : la phrase
  a sa carte (`ec3-qc-randomisation` A) et revient dans trois annales
  (2016/2017 S1 Q23, 2016/2017 S2 Q31, 2015/2016 S1 Q31).
- **Le gris** : « la notion d'analyse de survie sera revue … dans un cours
  ultérieur sur la méthode de Kaplan Meier » (partie 2, p. 3). Une carte dit le
  principe de la survie comme critère (`ec3-qc-survie`) ; la construction de
  Kaplan-Meier et le modèle de Cox sont au chapitre `biostat_survie` (plan
  C15). Le triple aveugle, « pour notre curiosité » (p. 9), n'est qu'une
  proposition fausse (« fréquent ») et une ligne du recto-verso de l'aveugle.
- **Les frontières du plan C15** : les phases I-II, la puissance et le nombre
  de sujets en phase II sont dans `biostat_phases_1_2` ; ici, le schéma général
  et la phase III, les risques et le nombre de sujets **en phase III**, le SAP,
  CONSORT, l'intention de traiter. L'ajustement en épidémiologie n'apparaît
  que pour l'opposer à la randomisation (`ec3-qc-epidemiologie`, sur « maître
  de l'exposition » et le niveau de preuve, partie 1, p. 7-8 ;
  `ec3-rv-ajustement-randomisation`) : l'ajustement lui-même, son nom et le
  modèle multivarié se cartent au chapitre de la régression logistique
  (`rlg-fa-confusion`, `rlg-qc-randomisation`, `lex-ajustement`). La QROC
  « comment appelle-t-on… l'ajustement ? » de la première rédaction a été
  retirée à la relecture pour cette raison ; à la seconde relecture, la
  proposition « c'est l'ajustement » du QCM (alors `ec3-qc-ajustement`) a cédé
  la place à « un seul essai randomisé peut suffire, l'épidémiologie demande
  plusieurs études » (p. 8), et le QCM a pris le nom `ec3-qc-epidemiologie`.
- **Le préclinique** (in vitro, in vivo) reste sans trou dans `ec3-fa-phases` :
  il se révise au chapitre des phases I et II (`ec1-fa-in-vitro`), qui laisse
  de même les phases 3 et 4 sans trou pour ce chapitre. Le tableau « Y
  binaire → régression logistique, Y quantitatif → régression linéaire, Y
  survie → modèle de Cox » (partie 2, p. 4) n'est cité que dans une
  explication.
- **Les trois exemples réels** (abiratérone, éribuline, erlotinib) ont chacun
  leur QCM, avec la courbe de survie de la fiche en correction, et un texte à
  trous les rassemble.

## Les erreurs du Ronéosaure 2025-26

| Page | Ce que dit le Ronéosaure | Ce qui est juste | Sorte | Carte |
|---|---|---|---|---|
| P1 3 | « essais de non-infériorité et de non-équivalence » | d'équivalence (p. 2, deux fois) | prise de notes | `ec3-qc-types` C, `ec3-fa-types` (explication) |
| P1 4 | « Contrôler : on va décider exactement quelle est la dose du médicament, la durée, le rythme » | un essai contrôlé est un essai comparatif : diapositive p. 6, « faire une étude comparative (essai contrôlé) » ; les annales interrogent ce sens | point douteux | `ec3-qc-design` E |
| P1 8 | « l'industriel pharmaceutique est incorruptible » | c'est la randomisation qui est incorruptible (la phrase suivante : « la randomisation n'est pas contournable ») | prise de notes | `ec3-qc-randomisation` E |
| P2 2 | « plus la différence est élevée, plus la puissance sera élevée et plus le nombre de sujets sera élevé » | plus la différence attendue est grande, **moins** il faut de sujets (P2 p. 5 ; P1 p. 11 ; annale 2018/2019 S1 Q5 D) | prise de notes | `ec3-qc-effet-effectif` C ; `ec3-an-1819s1-q5` D |
| P2 2 | α : « on accepte ici de se tromper 5 fois sur 100 quand on fait une découverte » | α = P(rejeter H0 / H0 vraie) ; la part de découvertes fausses dépend aussi de la puissance | le cours lui-même (même phrase en FC n°5) — à l'examen : α = 5 %, risque de première espèce ; relevé en relisant | `ec3-qc-risques` (explication) |
| P2 3 | taille de l'effet « déterminée par la phase III » | par la phase II (errata 2025-26 ; P1 p. 11) | prise de notes | `ec3-qc-nombre-sujets` B |
| P2 4 | « la méthode de Kaplan Meier est très astucieuse car ce modèle de Cox ne fait pas d'hypothèse sur l'allure de la courbe » | Kaplan-Meier estime la courbe sans hypothèse sur sa forme ; le modèle de Cox compare les groupes en supposant les risques proportionnels (FC n°12, p. 3) | prise de notes | `ec3-qc-survie` E |
| P2 5 | « un traitement de référence qui est à 5 % de décès » contre 10 % | la diapositive parle de **réponse** au traitement (à 5 % de décès contre 10 %, le nouveau traitement serait pire) | prise de notes ; relevé en relisant | `ec3-qc-effet-effectif` A |
| P2 6 | « avance plus vite que … » | « … que l'étude faite aux États-Unis » (errata 2025-26) | prise de notes | `ec3-qc-equipoise` (explication) |
| P2 8 | « Randomisation 1/2 : 1 patient sur 2 recevra l'abiratérone et 1 patient sur 2 le placebo » | randomisation 2 pour 1 : 797 contre 398 sur la courbe de la même page (de Bono 2011) | point douteux : la diapositive écrit « Randomisation 1/2 » pour les trois exemples, randomisés 2 pour 1 (abiratérone, erlotinib) ou 1 pour 1 (éribuline) ; relevé en relisant | `ec3-qc-abiraterone` (explication) |
| P2 8 | diapositive : 10,3 mois de survie médiane sous placebo | 10,9 mois dans l'article dont la courbe est tirée (de Bono, N Engl J Med 2011, vérifié ; même HR) | le cours lui-même, la diapositive — à l'examen, les chiffres du cours ; relevé en relisant | `ec3-qc-abiraterone` (explication) |
| P2 9 | capécitabine : « en réalité, on est à 14 mois » | 14,5 mois sur la courbe de la même page (Kaufman 2015) | prise de notes ; relevé en relisant | `ec3-qc-eribuline` (explication) |

Sans ATTENTION, parce qu'aucune réponse n'en dépend : « comité de protection
des patients » (P1 p. 3) pour le Comité de protection des **personnes** (P2
p. 2), dit dans `ec3-qc-types` E ; les en-têtes donnent « Semaine n°10 » à la
partie 1 et « n°8 » à la partie 2, pour le même cours.

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| L'étude de l'éribuline (900 patients, 12 → 15 mois, p = 0,08) | 2023/2024 S1 Q16, 2021/2022 S2 Q14, 2020/2021 S1 Q40, 2019/2020 S2 Q17, 2018/2019 S1 Q7 (cinq) |
| L'hormonothérapie 45 → 60 mois (345 par groupe, p = 0,670) | 2019/2020 S1 Q7, 2016/2017 S1 Q22, 2016/2017 S2 Q29, 2015/2016 S1 Q29 (quatre) |
| Le facteur de confusion | 2019/2020 S1 Q8, 2016/2017 S1 Q24, 2016/2017 S2 Q32, 2015/2016 S1 Q32 (quatre) |
| Les éléments du calcul du nombre de sujets | 2016/2017 S1 Q21, 2016/2017 S2 Q30, 2015/2016 S1 Q30 (trois) |
| La randomisation | 2016/2017 S1 Q23, 2016/2017 S2 Q31, 2015/2016 S1 Q31 (trois) |
| Le cancer du sein à maladie stabilisée (40 → 55 %, 900 patientes) | 2021/2022 S1 Q15, 2018/2019 S1 Q3 |
| Les caractéristiques d'une phase III ; un essai bronchique négatif (p = 0,22) | 2019/2020 S1 Q9 et Q10 |
| Le calcul d'une phase III sur un critère binaire (10 → 30 %, 60 par bras) | 2018/2019 S1 Q5 |
| La méthodologie générale : phase IV, ambivalence, protocole, essai contrôlé (polycopié 8) | 2019/2020 S1 Q6 |

Une carte par question et par session (convention BMCT), même quand l'énoncé
revient mot pour mot : l'explication dit la récurrence. Les huit questions de
phases I-II que le polycopié 9 recopie du polycopié 8, et ses trois questions
de phases I-II nouvelles, sont au chapitre `biostat_phases_1_2`.

## Le schéma cliquable et la planche

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `confusion-triangle.svg` (`ec3-zo-confusion`) | la flèche du lien que l'essai veut démontrer (traitement → critère), celle du lien que la randomisation rompt (facteur ↔ traitement), celle du lien qui fait le facteur de confusion et que la randomisation ne supprime pas (facteur ↔ critère) | 3 |

Redessiné d'après la diapositive « Plan d'expérience : facteurs de confusion »
(partie 1, p. 6). **Les trois boîtes gardent leur nom** (traitement, critère
de jugement, facteur de confusion) : ce ne sont pas elles qu'on clique, mais
les trois flèches, qui ne portent rien sur la version nue ; sans les noms, la
carte ne testerait que la place des boîtes. Les trois libellés demandés sont
des fonctions, pas des extrémités : « le lien que l'essai veut démontrer »,
« le lien que la randomisation rompt », « le lien que la randomisation ne
supprime pas, mais rend égal dans les deux bras » (ce dernier remplace, à la
relecture, « le lien qui fait d'une variable un facteur de confusion »,
inexact : il faut les deux liens obliques pour confondre, annale 2016/2017 S2
Q32 B). Les flèches obliques sont des
bandes de 48 px tirées des mêmes constantes que le dessin. La version légendée,
`confusion-triangle-legende.svg`, nomme chaque flèche (« l'effet étudié »,
« rompu par la randomisation », « persiste, mais égal dans les deux bras ») ;
elle illustre la zone, `ec3-qc-epidemiologie` et `ec3-rv-ajustement-randomisation`.

**La planche** `ec3-pl-phase3` : la diapositive « Phase 3 » (partie 2, p. 7),
légendes effacées par `scripts/planche_depuis_image.py` — six numéros :
population X, randomisation, les deux populations X/2 (même légende), les
interventions A et B ; cinq intrus : critères d'inclusion, double aveugle,
cross-over, population 2X, groupe historique. **« Placebo », intrus proposé par
le plan C15, n'est pas repris** : l'intervention B peut être un placebo, ce
serait presque un synonyme d'une légende. L'image numérotée a été relue : aucun
reste de lettre, les cases vidées restent dans leurs formes.

**Illustrations** : 44 QCM sur 47 (94 %) portent une diapositive de la fiche en
correction ; 62 notes sur 81. Les trois QCM sans figure : `ec3-qc-aveugle`,
`ec3-qc-equipoise`, `ec3-qc-biais` — la fiche n'a pas de diapositive sur
l'aveugle, l'ambivalence, l'équipoise ni les biais (pages de texte).

## Les clés qui ne sont pas reprises telles quelles

Aucune : les 25 clés imprimées vont avec leurs énoncés et ont été vérifiées
proposition par proposition contre le cours 2025-26. Toutes portent
`officielle=True`.

Reprises telles quelles, avec une remarque dans la carte :

- **2019/2020 S1 Q8 D** — « on réalise des essais de grande taille (nombre de
  sujets importants) pour gommer l'effet des facteurs de confusion », donnée
  fausse ; la diapositive du cours (partie 1, p. 6) écrit « Équilibrer les
  facteurs de confusion ! → Randomisation + nombre de sujets suffisants ». Clé
  ACE reprise : la taille d'un essai se calcule pour la puissance ; un nombre
  suffisant rend fiable l'équilibre que crée le tirage au sort, il ne le crée
  pas. ATTENTION sur D, conflit déclaré (`CONFLITS`).
- **Numérotation de la table** : la 2023/2024 S1 Q16 y est imprimée « 17 », la
  2021/2022 S1 Q15 « 14 » (une deuxième fois) ; clés ABD et AC reprises, dit
  dans l'explication.
- **H0 écrite « référence ≤ nouveau »** (2016/2017 S1 Q22 A, 2016/2017 S2 Q29 B,
  2015/2016 S1 Q29 C) : l'inégalité est à l'envers d'une hypothèse nulle de
  supériorité ; l'item est faux de toute façon (p = 0,670, rien n'est rejeté),
  et la justification le dit.
- **« Survie avec maladie stabilisée »** (2021/2022 S1 Q15 C, 2018/2019 S1 Q3 C)
  pour un pourcentage de patientes stabilisées à 12 mois : le libellé de
  l'énoncé, gardé ; l'hypothèse d'égalité est vraie.
- **2018/2019 S1 Q5** : l'objectif dit « l'activité » (un mot de phase II) d'un
  essai randomisé à deux bras ; lu comme une phase III, dit dans l'explication.

Cas ouvert : la 2019/2020 S1 Q8 D, tenue fausse avec la clé contre la
lettre de la diapositive (question 1 pour Vincent).

## Le lexique

Huit termes, aux pages mesurées dans les deux fiches 2025-26
(`chercher_pages.py`, page du plan exclue ; « confirmatoire » s'y écrit avec la
ligature « ﬁ ») : randomisation (P1 2, 7, 8 ; P2 6, 7, 8, 10), confirmatoire
(P1 2), multicentrique (P1 4, 9), ambivalence (P2 6), équipoise (P2 6),
attrition (P2 7), castration (P2 7, 8), immunohistochimie (P2 10) — ceux du
plan C15. Chacun dit son origine ; « randomisation » n'a pas d'étymon grec ni
latin (anglais random, de l'ancien français randon, d'origine francique) et le
dit.

Les étymologies nouvelles — huit racines (`random (anglais)`, `firmus (latin)`,
`multi- (latin)`, `ambi- (latin)`, `équi- (latin)`, `pensum (latin)`,
`terere (latin)`, `castrare (latin)`) et les huit termes — sont **proposées**
pour `scripts/etymologies.json` (fichier `etym/biostat_phase_3.json` du
brouillon de la tâche C15), avec leurs sources ; la table n'est pas modifiée par
ce chapitre. Les définitions et les racines disent déjà, mot pour mot, ce
qu'`appliquer_etymologies.py` en écrira (vérifié en le simulant sur la table
fusionnée : rien ne change). Les racines réemployées gardent la clé de la
table : `cum (latin)`, `centrum (latin)`, `valere (latin)`, `immun(o)-`,
`hist(o)-`, `chimi(o)-`. `hist(o)-` cite la FC de sémantique (1/2, p. 8).

## Questions pour Vincent

Les propositions du plan sont appliquées ; ce qui reste à trancher est signalé
sur les cartes :

1. **2019/2020 S1 Q8 D** : la clé (D fausse) contre la diapositive
   « randomisation + nombre de sujets suffisants ». La carte garde la clé et
   l'explique ; à confirmer.
2. **« Essai contrôlé »** : le Ronéosaure (p. 4) glose « contrôler » par la
   maîtrise de la dose et du rythme, et le Ronéosaure 2024-25 (« 4. Contrôlée »)
   par le double aveugle ; la diapositive 2025-26 (p. 6, « faire une étude
   comparative (essai contrôlé) ») l'entend « comparatif », le sens usuel. Les
   deux annales (2019/2020 S1 Q6 E et Q9 C) ne tranchent pas : leurs items
   (« autorisation », « consentement ») sont faux dans tous les sens. Les cartes
   suivent la diapositive, le Ronéosaure en point douteux ; à vérifier sur le
   ronéo 2026-27.
3. **Une source par session** : la 2019/2020 S1 Q6 cite le polycopié 9 alors
   qu'elle est imprimée dans le polycopié 8 (même question que pour
   `biostat_phases_1_2` : faut-il une source par note dans le modèle ?).
4. **Le schéma cliquable garde le nom de ses boîtes** : on y clique des
   flèches, pas des lieux. Cet écart à la règle « jamais de légende sur le
   schéma cliquable » est-il acceptable ?
5. **Les trois libellés de thèmes nouveaux** (`critere-jugement`,
   `facteurs-confusion`, `ethique-biais`) à ajouter à `THEME_LABELS`.

## À relire

Aucune carte `a-relire` : chaque carte de cours porte sa page dans sa fiche
2025-26, chaque annale sa clé vérifiée proposition par proposition. À la
parution du ronéo 2026-27 de ce cours, relire toutes les cartes contre lui :
pages, chiffres (100-4 000 patients, 2 × 500, 2 × 20 000, 45 → 55 % et 219 par
groupe, 620 → 33 par bras, 12 → 15 mois et 1 200 patients, 1 000, 4 → 6 mois
et 700), et les erreurs ci-dessus.

## L'échelle : Simple → Moyen → Annale (C20, 18/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 16 décembre. Sous les annales, 29 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 6 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `critere-jugement` | 7 | 2 | 8 |
| `randomisation` | 4 | 1 | 3 |
| `facteurs-confusion` | 6 | 1 | 4 |
| `nombre-sujets` | 9 | 1 | 9 |
| `ethique-biais` | 3 | 1 | 1 |

**Le schéma** `ech-phase3`, « La phase III · le plan, l'effectif, la conclusion », donne 61 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_PHASE3`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- ec3-an-1920s1-q6 C : à moitié — s6 dit le protocole fixé d'avance ; « dès la phase I » n'est que dans la FC n°5 (biostat_phases_1_2), hors des sources.
- ec3-an-1617s1-q21 A, D ; ec3-an-1617s2-q30 C, D ; ec3-an-1516s1-q30 A, C (critère principal ou secondaires) : pas de Simple propre, le mot écrit ailleurs trahirait le trou de s14 ; m4 les prépare.

## Régénérer

```powershell
cd contenu\chapitres\biostat_phase_3
..\..\..\app\.venv\Scripts\python.exe generer.py
```

La planche se refait depuis `app/`, si ses rectangles changent (Pillow n'est
pas une dépendance du projet) :
`uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/biostat_phase_3 ec3-pl-phase3 --apercus <brouillon>`.
