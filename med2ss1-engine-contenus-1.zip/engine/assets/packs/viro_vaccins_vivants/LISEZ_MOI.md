# Vaccins viraux : les vaccins vivants atténués — paquet Virologie

87 notes, 152 cartes. Chapitre `chap-ue-virologie-fc11` de l'UE Virologie
(ordre 11). Cours du **Pr Hober, le 08/12/2025** (10 h-11 h), « Vaccins
viraux » (FC n°11 du Ronéosaure 2025-26, 10 pages), et l'introduction des
vaccins du cours 2024-25 ; annales du polycopié VIROLOGIE 10 du Ronéosaure
2024-25 (26 questions, 15 sessions) et du sujet de l'examen du 09/01/2025
(2024/2025 Q21 et Q22, sans corrigé). Examen de virologie du **5 janvier 2027**
(`exam-viro-jan-2027`, portée sur l'UE, identique dans les dix paquets).

**18/10/2026** : 2 questions du sujet de virologie 2025/2026 (examen du
08/01/2026, sans corrigé) — Q.22, Q.30 ; voir « Le sujet 2025/2026 ».

**Une fiche provisoire.** Aucun ronéo 2026-27 de virologie n'est paru (cours à
partir du 06/10/2026) : le chapitre est carté sur le Ronéosaure 2025-26
(décision de Vincent du 02/10), et le ronéo de l'année corrigera les cartes à
sa parution. Les cartes de cours portent le tag `cours-2025-26` (badge « Cours
2025-26 ») ou, pour l'introduction, `cours-2024-25`. Aucune carte ne dit
« Absent du cours 2026-27 », et les erreurs du Ronéosaure sont dites par un
ATTENTION sans genre : la liste des erreurs de la promo,
`contenu/ERRATA_RONEOS_2026-27.md`, ne concerne que les ronéos 2026-27.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 48 | 48 |
| Texte à trous | 13 | 69 |
| QROC | 11 | 11 |
| Recto-verso | 5 | 5 |
| Schéma cliquable | 2 | 11 |
| Lexique | 8 | 8 |

Dont **30 annales** (QRM), sur 17 sessions, de 2015/2016 S1 à 2025/2026.
Les 18 QCM du cours ont, comme les annales, une justification par proposition.
**Les 48 QCM sont illustrés**, du côté de la correction.

Six thèmes :

| Clé | Libellé | Partagé avec |
|---|---|---|
| `vaccins-types` | Types de vaccins viraux | `viro_vaccins`, même libellé |
| `vaccins-vivants` | Vaccins vivants atténués : principe et risques | — |
| `variole` | Variole et vaccine | — |
| `ror` | Oreillons, rougeole, rubéole et vaccin ROR | — |
| `mere-enfant` | Transmission mère-enfant et infections congénitales | `viro_multiplication`, `viro_pathogenes_3`, même libellé |
| `gastro-enterites` | Virus des gastro-entérites | `viro_pathogenes_1`, même libellé |

Les six libellés sont à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) ; c'est le seul échec du test des
paquets tant qu'ils n'y sont pas. La clé `vaccins` (« Vaccins et types de
vaccins ») de `biostat_medico_economie` n'est pas réemployée : elle parle de
politique vaccinale.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-viro-fc11` — Ronéosaure, « FC n°11 Vaccins viraux » (10 p.), `VIROLOGIE/FC n°11 Vaccins viraux.pdf` | **2025-26** | **la base** : chaque note du cours porte sa page ; c'est ce que le lecteur ouvre (`chapitre=`) |
| `src-cours2425-viro-fc10` — Ronéosaure, « FC n°10 - Vaccins viraux » (9 p.), `S1/COURS/COURS exam janvier/Virologie/…` | 2024-25 | appoint : l'introduction que le ronéo 2025-26 n'a pas transcrite (p. 2) ; ses cartes portent `fiche=` et le badge « Cours 2024-25 » |
| `src-annales-virologie-10-vaccins-viraux` — Ronéosaure, « VIROLOGIE 10 - Vaccins viraux » (31 p.) | 2024-25 | les 26 questions ; table de corrections p. 28, captures de 2019/2020 S1 p. 17-18 et 29-30 ; déclaré à l'identique dans `viro_antiviraux` et `viro_vaccins` |
| `src-sujet-viro-2425` — « Sujet de virologie 2024/2025, session 1 » (examen du 09/01/2025, 16 p., 30 QCM) | 2024-25 | 2024/2025 Q21 et Q22 ; `SRC["sessions"]["2024/2025"]` ; sujet sans corrigé ; déclaration identique dans tous les chapitres de virologie qui en prennent une question |
| FC n°10 2025-26 (parties 1 et 2, chapitre « Vaccins viraux »), FC n°9 2025-26 (« La lutte contre les virus ») | 2025-26 | citées dans le texte des justifications, à la page, sans être déclarées : ce sont les fiches d'autres chapitres |

Le partage du cours suit le plan de l'UE : la FC n°11 entière, plus
l'introduction de la vaccinologie (immunisation active, types de vaccins) ;
les vaccins inactivés, à antigènes, à pseudo-particules, recombinants, à
réplicons, à ADN et à ARN (FC n°10) sont dans `viro_vaccins`.

## Ce que le cours a dicté

- **Ni gris ni rouge** dans cette FC.
- **Le principe des vaccins vivants atténués** (p. 2) : trois façons d'atténuer
  (passages, mutants thermosensibles, réassortiment), la charge antigénique,
  les contre-indications, la réversion, la chaîne du froid, la liste des
  vaccins. Trois textes à trous, trois QCM, un recto-verso (vivant atténué /
  inactivé).
- **La variole** (p. 2-3) : vaccin hétérologue, Orthopoxvirus, formes majeure
  et mineure. **Les oreillons, la rougeole, la rubéole** (p. 3-7) : le gros du
  cours et des annales — seize notes de cours, dont les deux complications
  neurologiques de la rougeole en recto-verso.
- **Les infections congénitales, périnatales, postnatales** (p. 7-9) : CMV,
  B19, VZV, HSV — une frise cliquable de la grossesse.
- **Le rotavirus** (p. 9-10) : structure (un rotavirus en coupe, cliquable),
  NSP4, immunité muqueuse, vaccins vivants réassortants.
- La ligne « 2ème cause de méningite virale après les EV 10 à 15 % des MLA :
  50 % sans parotidite » (p. 4, recopiée de la diapositive) est confuse :
  seule la 2e place après les entérovirus est cartée, aucun pourcentage.
- **L'introduction manque** (errata de la promo : « Manque l'introduction de
  "Vaccins viraux" », les dix dernières minutes du cours du 05/12) : elle est
  prise dans le cours 2024-25, p. 2 — un QCM, deux textes à trous, et le
  tableau `immunisation-active.svg`.

## Les erreurs du Ronéosaure 2025-26

Aucune n'est dans l'errata du cours (sa seule ligne sur ce cours est
l'introduction manquante) ; toutes trouvées en lisant. Chacune est dite par
un ATTENTION sans genre dans la carte qui porte la notion.

| Page | Ce que dit le ronéo | Ce qui est juste | Carte |
|---|---|---|---|
| 6 | vaccin rougeoleux « dès l'âge de 6 mois chez un sujet ayant été en contact avec la rubéole » (déjà ainsi en 2024-25, p. 9) | avec la **rougeole** : le nourrisson de 6 à 11 mois reçoit une dose dans les 72 h qui suivent un contage (calendrier vaccinal) | `vva-qc-rougeole-vaccin` C |
| 7 | le CMV, « virus qu'on voit beaucoup moins grâce à la vaccination » | aucun vaccin contre le CMV ; le cours dit lui-même, p. 8, qu'on est « désarmé » | `vva-qc-congenitales` D |
| 8 et 9 | ganciclovir et aciclovir, « analogue de nucléotide » | analogues de **nucléoside** (FC n°9 2025-26, p. 3) | `vva-qc-cmv` D, `vva-qc-vzv-hsv` E |
| 9 | « Infection congénitale = contamination lors du passage de la filière génitale » | c'est l'infection **périnatale** ; la congénitale est contractée in utero (p. 7) | `vva-qc-perinatales` A, `vva-rv-congenitale-perinatale` |
| 10 | « produisent en structurale la protéine NSP4 », puis « NPS4 » | NSP4, protéine **non** structurale | `vva-qc-rotavirus-pathogenie` B |

Sans ATTENTION, parce qu'aucune réponse n'en dépend : « souche Schwartz »
(Schwarz, p. 6), « exsanguino transfusion » pour la transfusion in utero de
concentrés érythrocytaires de la diapositive (p. 8 ; `vva-qr-b19-traitement`
l'accepte sans en faire la réponse), « les métallisations cellulaires »
(p. 10), « un rotavirus isolé d'un patient que l'on va activer jusqu'à ce
qu'il soit atténué » (p. 10).

**Une recommandation qui a changé** : la contraception « un mois avant et deux
mois après » la vaccination antirubéoleuse (p. 7 et 9) ; le calendrier vaccinal
actuel demande d'éviter une grossesse dans le mois qui suit (CRAT, Ameli).
Dit dans `vva-qc-rubeole` E, sur une proposition fausse pour une autre raison :
aucune clé n'en dépend.

## Ce que les annales ont dicté

Le polycopié VIROLOGIE 10 compte 87 questions ; ce chapitre prend celles de
l'introduction et des vaccins vivants atténués (le plan de l'UE, §12) :

| Sujet | Questions |
|---|---|
| Types de vaccins et un exemple de chacun | 8 (2019/2020 S1 Q32, 2018/2019 S1 Q.10, les six Q.24 de 2015/2016 à 2017/2018) |
| Rougeole, son vaccin, le ROR | 6 (les Q.25 de 2021/2022 à 2022/2023, les deux Q.29 de 2015/2016) |
| Principe des vaccins vivants atténués | 4 (2020/2021 S1 et S2 Q.10, 2019/2020 S1 Q33, 2018/2019 S1 Q.11) |
| Immunisation active | 2 (2019/2020 S1 Q31, 2018/2019 S1 Q.9), plus deux propositions « à chaud » |
| Synthèse : ROR, rotavirus, grippe, polio, hépatite A | 4 (2020/2021 S1 et S2 Q.15, 2019/2020 S1 Q34, 2018/2019 S1 Q.12) |
| Oreillons et rubéole ; vaccins anti-rotavirus | 4 (2023/2024 S1 Q.21 et Q.22 ; leurs reprises, 2024/2025 Q21 et Q22) |

Ce qui revient : **le type de chaque vaccin** (rage et grippe inactivés, ROR,
rotavirus, varicelle et fièvre jaune vivants atténués, HPV en pseudo-particules,
VHB en antigène recombinant) ; les contre-indications des vivants atténués
(femme enceinte, immunodéprimé) ; la chaîne du froid ; la rougeole
(immunodépression de 4 semaines, complications, diagnostic par les IgM du
sérum et de la salive, vaccin obligatoire depuis 2018).

| Session | n° | Clé imprimée | Retenue | Sujet |
|---|---|---|---|---|
| 2023/2024 S1 | Q.21 | ABC | ABC | oreillons, rubéole, ROR (titre imprimé « 2022/2023, session 2 ») |
| 2023/2024 S1 | Q.22 | ABE | ABE | vaccins anti-rotavirus (idem) |
| 2024/2025 (sujet du 09/01/2025) | 21) | aucune (sans corrigé) | **ABE** | oreillons (voie aérienne, méningite, pas d'otite purulente), ROR (contre-indiqué pendant la grossesse, obligatoire depuis 2018) |
| 2024/2025 (sujet du 09/01/2025) | 22) | aucune (sans corrigé) | **D** | rotavirus (infection localisée), vaccin vivant atténué oral, dès 6 semaines et avant 3 mois, IgA |
| 2022/2023 S2 | Q.25 | ABC | ABC | rougeole et son vaccin |
| 2022/2023 S1 | Q.25 | ADE | ADE | rougeole |
| 2021/2022 S2 | Q.25 | ABD | ABD | rougeole, œuf embryonné |
| 2021/2022 S1 | Q.25 | ABCE | ABCE | rougeole, œuf embryonné |
| 2020/2021 S2 | Q.10 | ADE | ADE | vivants atténués, adjuvants, SARS-CoV-2, œufs, variole |
| 2020/2021 S2 | Q.15 | BD | BD | ROR, rotavirus, grippe, « à chaud », hépatite A |
| 2020/2021 S1 | Q.10 | ABC | ABC | vivants atténués, VLP, grippe, variole |
| 2020/2021 S1 | Q.15 | ACD | ACD | ROR, rotavirus, grippe, « à chaud », hépatite A |
| 2019/2020 S1 | Question 31 | ABC | ABC | immunisation active (captures p. 17, corrigé p. 29) |
| 2019/2020 S1 | Question 32 | ABC | ABC | types de vaccins |
| 2019/2020 S1 | Question 33 | ABC | ABC | vivants atténués, rage post-exposition (corrigé p. 30) |
| 2019/2020 S1 | Question 34 | ABD | ABD | varicelle, rotavirus, ROR, grippe, polio injectable |
| 2018/2019 S1 | Q.9 | ABC | ABC | immunisation active |
| 2018/2019 S1 | Q.10 | ABC | ABC | types de vaccins |
| 2018/2019 S1 | Q.11 | ABCE | ABCE | vivants atténués, fièvre jaune |
| 2018/2019 S1 | Q.12 | BC | BC | varicelle, rotavirus, ROR, grippe, Sabin |
| 2017/2018 S2 | Q.24 | CDE | CDE | rage, oreillons, HPV, variole, tiques |
| 2017/2018 S1 | Q.24 | ABD | **ABCD** | idem, HPV « protéines virales recombinantes » — voir plus bas |
| 2016/2017 S2 | Q.24 | ABCD | ABCD | types de vaccins |
| 2016/2017 S1 | Q.24 | CD | CD | types de vaccins |
| 2015/2016 S2 | Q.24 | AD | AD | types de vaccins |
| 2015/2016 S2 | Q.29 | CDE | CDE | oreillons, rougeole, rubéole |
| 2015/2016 S1 | Q.24 | — | **ABCE** | types de vaccins — clé déduite |
| 2015/2016 S1 | Q.29 | — | **ABC** | oreillons, rougeole, rubéole — clé déduite |

## Le sujet 2025/2026 (18/10/2026)

Le sujet de virologie de l'examen du 08/01/2026 (cahier de 30 QCM,
`src-sujet-viro-2526`, sans corrigé), déposé le 18/10/2026, apporte 2
questions à ce chapitre (Q.22, Q.30) ; les autres questions vont aux chapitres
de leur cours. Aucune n'était déjà en cartes. Chaque clé est déduite du cours
2025-26, l'année de l'examen, proposition par proposition et page à l'appui
(`officielle=False`) ; les propositions déjà posées d'autres années ont servi
de contre-épreuve, et l'explication dit chaque reprise. Rédigées et
contre-vérifiées le 18/10/2026 : un rédacteur, un sceptique qui a refait
chaque clé sur le cours, un critique de complétude. Le profil des clés — A
souvent vraie, trois ou quatre vraies par question — est celui des sessions 1
officielles du Pr Hober (2021/2022 S1, 2023/2024 S1).

| Question | Clé imprimée | Retenue | Lecture |
|---|---|---|---|
| 2025/2026 Q.22 (`vva-an-2526-q22`) | aucune (sujet sans corrigé) | **ABDE** | Trois voies d'atténuation — passages en culture, mutants thermosensibles, réassortiment de virus segmentés — et une contre-indication, la grossesse comme l'immunodépression ; la variole a été vaincue par un vaccin hétérologue, la vaccine, qui protège de tout le genre Orthopoxvirus. |
| 2025/2026 Q.30 (`vva-an-2526-q30`) | aucune (sujet sans corrigé) | **ABCD** | Le ROR : trois vivants atténués, obligatoire à 12 mois depuis 2018 ; la rougeole donne la PESS, mortelle ; les oreillons, une otalgie sans otite purulente. |

Ce qui est signalé :

- Q.30 B, « 1 ans », gardé tel qu'imprimé.
- Q.30 C, **le cours lui-même, point douteux** : la FC n°11 range l'allergie à
  l'œuf parmi les contre-indications des vaccins des oreillons (p. 4) et de la
  rougeole (p. 6), cultivés sur œufs embryonnés ; la FC n°1 partie 2 (p. 4) le
  redit, et le professeur cote vraie la production du vaccin rougeoleux sur
  œuf (2021/2022 S1 Q.25 E). La référence n'en fait qu'une précaution d'emploi
  (RCP de M-M-RVaxPro et de Priorix ; ACIP, qui vaccine les allergiques à
  l'œuf sans test). Retenu vrai, comme le professeur ; ATTENTION nu, à la
  convention des chapitres de virologie, et conflit déclaré. La carte de cours
  `vva-qc-rougeole-vaccin` D renvoie désormais à cette proposition.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2017/2018 S1 Q.24 | ABD | ABCD | C, « le vaccin contre les HPV est constitué de protéines virales recombinantes », cotée fausse : le vaccin est la protéine L1 produite par génie génétique (recombinante) et assemblée en capsides vides (FC n°10 2025-26 partie 1, p. 2, sous « Vaccins à base d'antigènes viraux » ; RCP « recombinant, adsorbé ») ; l'annale 2024/2025 Q25 B, « un vaccin à base de protéines recombinantes », est cotée vraie (correction du ronéo). `officielle=False`, `CONFLITS`, ATTENTION en tête de la justification de C, qui dit aussi le point douteux à l'examen : le professeur range le HPV dans les pseudo-particules et cote fausse la « L1 recombinante soluble » (2021/2022 S1 Q.27 A, dans `viro_vaccins`). |
| 2015/2016 S1 Q.24 | — | ABCE | La table n'a pas de colonne 2015/2016 S1 : clé déduite du cours (`officielle=False`). B à E retournent les items de 2015/2016 S2 Q.24 (clé AD). |
| 2015/2016 S1 Q.29 | — | ABC | Même cause ; la jumelle de 2015/2016 S2 Q.29 (clé CDE), items retournés. |
| 2024/2025 Q21 (`vva-an-2425-q21`) | aucune (sujet sans corrigé) | ABE | clé déduite du cours : oreillons par voie aérienne, méningite, « pas purulents » (FC n°11, p. 3-4) ; ROR contre-indiqué chez la femme enceinte (p. 4, 6), obligatoire depuis le 1er janvier 2018 (p. 6-7). `officielle=False` |
| 2024/2025 Q22 (`vva-an-2425-q22`) | aucune (sujet sans corrigé) | D | clé déduite du cours : infection digestive localisée ; vaccin vivant atténué (pas de pseudo-particules), oral, dès 6 semaines et avant 3 mois (p. 10). **E** (« induisent la production d'IgG ») retenue fausse, point douteux : le cours ne nomme que les IgA (p. 10), mais ne dit pas que le vaccin ne fait aucune IgG. `officielle=False`, ATTENTION sur E, `CONFLITS` |

Sessions : **2023/2024 S1 Q.21 et Q.22** sont imprimées sous le titre « Année
2022/2023, session 2 », mais la table de corrections les range sous 2023/2024
session 1 (avec Q.23 à Q.28, dans « Vaccins viraux ») : retenu, la table. Le
vrai 2022/2023 S2 commence à Q.25.

Des **propositions hors du ronéo 2025-26** : l'immunisation active (« à
froid », « à chaud », dès le contact, vaccins thérapeutiques) vient du cours
2024-25 (FC n°10, p. 2) — chaque justification le dit ; les vaccins inactivés,
recombinants, à pseudo-particules, à réplicons, à ADN et à ARN sont cités dans
la FC n°10 2025-26, à la page. Les propositions sur l'ADN nu (2015/2016 Q.24 E,
2018/2019 Q.10 E, 2019/2020 Q32 E) suivent le cours (« encore l'objet
d'investigations », FC n°10 partie 1, p. 14) et notent qu'un vaccin à ADN
anti-SARS-CoV-2 a été autorisé en urgence en Inde en 2021, hors du cours.

## Les schémas cliquables et les figures

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `rotavirus-nu.svg` (correction : `rotavirus-legende.svg`) | les spicules de VP4, la couche externe de VP7, la couche intermédiaire de VP6, le core et ses 11 segments d'ARN double brin | 4 |
| `grossesse-frise-nue.svg` (correction : `grossesse-frise.svg`) | sur une frise en semaines d'aménorrhée : embryopathie (1er trimestre), fœtopathie (dès le 4e mois), périnatal (accouchement + 48 h), postnatal ; et la varicelle de la mère : avant 19 SA, de 20 à 38 SA, périnatale | 7 |

Le rotavirus est le « virion à triple feuillet » de la diapositive p. 9 ; ses
anneaux sont séparés par un liseré de quelques pixels, pour qu'un clic tombe
dans une seule zone. La frise ne porte que sa règle (semaines, naissance) et
le nom de ses deux bandes. Deux tableaux redessinés illustrent l'introduction :
`immunisation-active.svg` et `vaccins-types-intro.svg`.

**Les figures du cours** : quatorze diapositives de la FC n°11, photographiées
pendant la retransmission du cours (le ronéo les imprime en photos d'écran),
**redressées** (perspective corrigée, cadre du lecteur vidéo et du navigateur
retirés), fond éclairci et palette réduite pour un dossier `media/` de 1,8 Mo :
variole (deux), oreillons, rougeole (trois), rubéole, transmission congénitale,
parvovirus B19, anasarque, herpès néonatal, virus des gastro-entérites,
rotavirus, vaccin réassortant. Les deux diapositives de la variole, faites de
photographies en noir et blanc, gardent leur fond. La diapositive des
réassortants montre un rotavirus **simien** (RRV) recevant le gène de VP7 de
rotavirus humains ; le ronéo parle d'un rotavirus **bovin** : les deux sont des
vaccins réassortants, la légende le dit.

## Le lexique

Huit termes, pages mesurées dans les PDF (FC n°11 ; FC n°10 parties 1 et 2 ;
FC n°7) :

| Terme | Pages | Racines |
|---|---|---|
| Atténuation | FC11 2, 4, 6, 7, 10 (« atténué ») | attenuare (latin) — proposée |
| Hétérologue | FC11 2 | hétéro- (FC de sémantique 2/2, p. 5), -logue (grec) — proposée |
| Réversion | FC11 2 ; FC10 partie 1, 5 | revertere (latin) — proposée |
| Thermosensible | FC11 2 ; FC10 partie 2, 5, 6 | therm(o)-, sensibilis (latin) — proposée |
| Parotidite | FC11 3, 4 | para- (grec), ot(o)-, -ite |
| Orchite | FC11 4 | orchi-, -ite |
| Anasarque | FC11 8 ; FC7 3 | ana- (grec) (sémantique 2/2, p. 10), sarco- |
| Tératogène | FC11 8 | térat(o)-, -gène (sémantique 1/2, p. 6) |

« Tératogène » existe déjà dans `bmcp_lipides` (`lex-teratogene`, UE BMCP) : il
est repris ici sous `lex-teratogene-viro`, pour ne pas déplacer la note de BMCP
à l'import. Les étymologies sont proposées dans le fichier de la vague
(`etym/viro_vaccins_vivants.json`), vérifiées sur le TLFi (API cnrtl.fr) et le
Wiktionnaire ; le Bailly (λόγος, ἀνά) et le Gaffiot (attenuo, reverto,
sensibilis) n'y sont cités que par leur lien Logeion, sans avoir été ouverts.
Les définitions portent déjà les étymologies. Les
termes que d'autres chapitres de l'UE accueillent (embryopathie, fœtopathie,
exanthème, énanthème, entérotoxine, virémie) ne sont pas repris.

## Questions pour Vincent

1. **L'introduction 2024-25** (plan de l'UE, §14) : l'immunisation active et
   les types de vaccins ne sont pas dans le ronéo 2025-26 (introduction non
   transcrite). Proposition appliquée : les cartes sont faites sur le cours
   2024-25 (badge « Cours 2024-25 », chaque justification le dit), et les
   annales qui en dépendent (2019/2020 S1 Q31 et Q32, 2018/2019 S1 Q.9 et
   Q.10, 2020/2021 S1 et S2 Q.15 D) restent ici. À garder jusqu'au ronéo
   2026-27 ?
2. **2017/2018 S1 Q.24 C** (HPV « constitué de protéines virales
   recombinantes ») : retenu vrai contre la clé imprimée, sur la FC n°10
   2025-26, le RCP et l'annale 2024/2025 (Q25 B cotée vraie par la correction
   du ronéo). La clé de 2017/2018 oppose sans doute les pseudo-particules
   (HPV) aux protéines recombinantes (VHB), comme 2021/2022 S1 Q.27 A cote
   fausse la « L1 recombinante soluble » ; la carte dit qu'à l'examen, si les
   deux catégories sont opposées, le HPV est « pseudo-particules virales ».
   D'accord ? (Les deux sessions se contredisent : la carte 2024/2025 Q25 de
   `viro_vaccins` ne porte pas, elle, de conflit déclaré.)
3. **La contraception autour du vaccin antirubéoleux** : la carte donne la
   formule du cours (1 mois avant, 2 mois après) et la référence actuelle (le
   mois qui suit). Faut-il une carte dédiée, ou cette mention suffit-elle ?

## À relire

Aucune carte `a-relire` : chaque carte de cours porte sa page de la FC n°11
(ou du cours 2024-25), chaque annale sa clé imprimée ou sa clé déduite dite
comme telle. Un cas ouvert : 2024/2025 Q22 E, les IgG du vaccin anti-rotavirus,
retenues fausses sans corrigé pour le confirmer.

## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier. Sous les annales, 33 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 8 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `vaccins-types` | 8 | 4 | 14 |
| `vaccins-vivants` | 7 | 1 | 5 |
| `ror` | 13 | 2 | 9 |
| `gastro-enterites` | 5 | 1 | 2 |

**Le schéma** `ech-vaccins`, « Vacciner contre les virus · quand, avec quoi, contre qui », donne 72 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_VACCINS`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- vva-an-2021s2-q10 D — la grippe produite sur œufs embryonnés : FC n°10 2025-26, partie 2, p. 5, hors des sources du chapitre ; lettre posée sur la case des inactivés (la grippe), sans marche.
- vva-an-2021s1-q10 D — le vaccin grippal dosé en hémagglutinine, pas en lipides : FC n°10 2025-26, partie 2, p. 6, hors des sources du chapitre ; lettre posée sur la case des inactivés, sans marche.
- vva-an-2021s2-q15 C et vva-an-2021s1-q15 C — la composition du vaccin grippal (deux souches A, une ou deux B) : FC n°10 2025-26, partie 2, p. 5 ; seule sa nature inactivée a une marche (vva-ech-s1, vva-ech-m1).
- vva-an-2021s2-q15 E — l'âge du vaccin anti-hépatite A (dès 1 an, pas 6 semaines) : FC n°10 2025-26, partie 2, p. 7 ; seule sa nature inactivée a une marche, la lettre est posée sur la case des inactivés.
- vva-an-1819s1-q10 D, vva-an-1516s2-q24 C, vva-an-1516s1-q24 C — virus recombinants vivants et virus chimériques par recombinaison (la dengue sur le 17D) : FC n°10 2025-26, partie 1, p. 11-12, hors des sources ; le « virus chimérique » de la FC n°11 (p. 2) est un réassortant, pas une recombinaison de gènes : pas de marche, pour ne pas les confondre. Lettres posées, sans marche, sur la case des vivants atténués : la chimère 17D-dengue est un vaccin vivant atténué (FC n°10 2025-26, partie 1, p. 12).

## Régénérer

```
..\..\..\app\.venv\Scripts\python.exe generer.py
```

`generer.py` est la copie exacte de
`.claude/skills/nouveau-chapitre/scripts/generer_modele.py`.
