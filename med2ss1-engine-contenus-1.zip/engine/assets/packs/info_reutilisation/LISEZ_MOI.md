# Réutilisation des données en médecine — paquet Informatique médicale

62 notes, 112 cartes. Chapitre `chap-ue-info-medicale-fc3` de l'UE
Informatique médicale, troisième de l'UE. Cours du **Pr Ficheur, le
31/10/2025, de 9 h à 10 h**, dans le **Ronéosaure 2025-26** (FC n°3, 5 pages) ;
les annales du polycopié du Ronéosaure 2024-25 (4 sessions) et les trois QCM
que la fiche 2025-26 reproduit p. 5. Examen : partiel du mercredi
16 décembre 2026.

**Fiche provisoire** (C15, décision de Vincent du 02/10) : le cours de l'année
2026-27 n'est pas encore paru. Chaque carte de cours cite la FC 2025-26 à sa
page et porte le badge « Cours 2025-26 » (`ANNEE_COURS = "2025-26"`) ; le ronéo
2026-27 la corrigera quand il sortira.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 30 | 30 |
| QRU | 1 | 1 |
| Texte à trous | 12 | 56 |
| QROC | 9 | 9 |
| Recto-verso | 5 | 5 |
| Schéma cliquable | 2 | 8 |
| Lexique | 3 | 3 |

Dont **15 annales** sur 5 sessions : les 12 QCM du polycopié (2018/2019 à
2023/2024, session 1) et les 3 QCM en capture d'écran de la fiche (session
2024/2025 présumée, voir les questions).

Six thèmes. `types-etudes` et `niveaux-preuve` existent déjà (biomédecine
quantitative, régression linéaire multiple), et leurs libellés disent vrai
ici : le plan C15 (0.6) demandait que la clé de FC3 se range sur la leur.
`reutilisation-donnees` est partagée avec `biostat_phase_4_eim`, écrit en
parallèle (FC n°10 de biomédecine quantitative), au même libellé, vrai dans
les deux chapitres. Quatre clés n'ont pas encore de libellé dans
`THEME_LABELS` (`app/src/med_engine/application/scopes.py`) :
`reutilisation-donnees`, `reutilisation-limites`, `bases-donnees-sante` et
`chainage-anonyme`.

| Clé | Libellé | Notes | dont annales |
|---|---|---|---|
| `types-etudes` *(existante)* | Types d'études | 8 | 0 |
| `niveaux-preuve` *(existante)* | Niveaux de preuve | 14 | 0 |
| `reutilisation-donnees` *(partagée)* | Réutilisation des données de santé | 12 | 5 |
| `reutilisation-limites` | Avantages et limites des données réutilisées | 9 | 4 |
| `bases-donnees-sante` | Bases de données de santé : SNDS, PMSI, entrepôts | 12 | 6 |
| `chainage-anonyme` | Identifiant anonyme et chaînage des séjours | 4 | 0 |

Le plan proposait `types-etudes-preuve`, `reutilisation` et `bases-sante` :
la première se fond dans les deux clés existantes ; les deux autres prennent
une clé plus précise, qu'une autre UE ne voudra pas (« réutilisation » des
dispositifs médicaux, par exemple).

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-info-reutilisation-2526` — Ronéosaure, « FC n°3 Réutilisation des données en médecine » (5 p.) | 2025-26 | le cours ; `SRC["fiche"]`, `SRC["cours"]`, `SRC["medias"]` ; et la source des trois QCM de la p. 5 (`SRC["sessions"]["2024/2025"]`) |
| `src-annales-fc-n3-reutilisation-de-donnees-en-medecine` — « FC n°3 - Réutilisation de données en médecine » (5 p.) | 2024-25 | 4 sessions, 12 QCM, table p. 5 |

La source d'annales est déclarée dans la forme commune aux chapitres de C15
(id tiré du nom du fichier, cinq champs) ; aucun autre chapitre ne la déclare.
Lus en appoint, sans être déclarés, et cités à la page dans le texte des
cartes : le cours 2024-25 du même professeur (Ronéosaure 2024-25, 10 p.) et le
cours 2023-24 (Charonéo, 12 p.) ; les erratas des cours 2025-26 et des annales
2024-25 (vides), celui des cours 2023-24 (« haut débit », « antidiabétique » :
des phrases absentes du ronéo 2025-26).

Les en-têtes des ronéos, des erratas et du polycopié portent des noms
d'étudiants : aucun n'est repris.

## Ce que le cours a dicté

- **Ni rouge ni gris de contenu** : le seul rouge est un point après « le plus
  haut niveau de preuve » (p. 2), et le gris est celui des titres de
  sous-parties. Ce point rouge ne marque aucune phrase (la phrase elle-même
  est noire) : tout se carte.
- **Aucune figure de cours** : les trois images de la p. 5 sont des QCM. Les
  corrections s'illustrent par cinq dessins (plus bas).
- **Ce qui n'est pas carté ici**, parce qu'un autre chapitre le tient (plan
  C15, 0.5) : le PMSI en détail (FC4), la fonction de hachage (FC6), les grades
  de la HAS et la méta-analyse (FC5), le test diagnostique et la courbe ROC
  (biomédecine quantitative). Les cartes les citent ; le chapitre carte le PMSI
  réutilisé, le SNDS, le numéro ANO, le CépiDc, les entrepôts hospitaliers et
  l'échelle des preuves.
- **Ce que le ronéo 2025-26 ne dit plus et que les annales demandent** : l'open
  data, la puissance « incomparable », le codage orienté par la facturation
  (cours 2024-25, p. 8-9) ; la cohorte rétrospective qui reste une cohorte, le
  cas-témoins rétrospectif, le biais d'observation chez le médecin (cours
  2023-24, p. 10-11). Ces propositions disent leur année dans leur propre
  justification ; aucune carte entière n'en dépend.

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| Le SNDS : PMSI, remboursements de ville, CépiDc ; ni saisi par le patient, ni transmis par un particulier | 2023/2024 Q2, 2021/2022 Q4, 2019/2020 Q19, 2018/2019 Q16 ; 2024/2025 b et c |
| Donnée ouverte et réutilisation : définition, open data, biologie et effets indésirables, complications | 2023/2024 Q9, 2021/2022 Q5, 2019/2020 Q18, 2018/2019 Q17 ; 2024/2025 a |
| Cohortes rétrospectives, qualité orientée, numéro ANO, puissance statistique | 2023/2024 Q8, 2019/2020 Q14, 2018/2019 Q18 ; 2021/2022 Q6 |

| Session | N° | Clé | Thème | Carte |
|---|---|---|---|---|
| 2023/2024 S1 | Q2 | BCE | bases-donnees-sante | `reu-an-2324s1-q2` |
| 2023/2024 S1 | Q8 | ABD | reutilisation-limites | `reu-an-2324s1-q8` |
| 2023/2024 S1 | Q9 | BCDE | reutilisation-donnees | `reu-an-2324s1-q9` |
| 2021/2022 S1 | Q4 | BCE | bases-donnees-sante | `reu-an-2122s1-q4` (point douteux sur C) |
| 2021/2022 S1 | Q5 | BCDE | reutilisation-donnees | `reu-an-2122s1-q5` |
| 2021/2022 S1 | Q6 | BE | reutilisation-limites | `reu-an-2122s1-q6` |
| 2019/2020 S1 | Q14 | ABD | reutilisation-limites | `reu-an-1920s1-q14` |
| 2019/2020 S1 | Q18 | BCDE | reutilisation-donnees | `reu-an-1920s1-q18` |
| 2019/2020 S1 | Q19 | BCE | bases-donnees-sante | `reu-an-1920s1-q19` |
| 2018/2019 S1 | Q16 | BCE | bases-donnees-sante | `reu-an-1819s1-q16` |
| 2018/2019 S1 | Q17 | BCDE | reutilisation-donnees | `reu-an-1819s1-q17` |
| 2018/2019 S1 | Q18 | ABCD | reutilisation-limites | `reu-an-1819s1-q18` |
| 2024/2025 (présumée) | a | ACDE | reutilisation-donnees | `reu-an-2425-a` |
| 2024/2025 (présumée) | b | ABCD | bases-donnees-sante | `reu-an-2425-b` |
| 2024/2025 (présumée) | c | BCD | bases-donnees-sante | `reu-an-2425-c` |

La légende du polycopié annonce des corrections non officielles « {…} » ;
aucune clé n'en porte. Les trois QCM de la fiche n'ont pas de table : leur clé
est lue sur les couleurs de la capture (vert exact, rouge faux), et
l'explication le dit. Les questions répétées d'une session à l'autre ont
chacune leur carte, et l'explication renvoie aux autres. Les coquilles
imprimées sont reprises telles quelles (« espèce),ce », « scientifiques,mais »,
« permettrela »).

## Les clés qui ne sont pas reprises telles quelles

**Aucune.** Toutes les clés imprimées sont justes et reprises. Un point est
discuté dans la carte (`ATTENTION`, déclaré dans `CONFLITS`), sans changer la
clé :

| Question | Clé | Le point | À l'examen |
|---|---|---|---|
| 2021/2022 S1 Q4 C | BCE | « les achats de médicaments en ville » donnés vrais : le SNDS ne connaît que les achats remboursés, présentés avec la carte Vitale (les trois autres sessions écrivent « remboursements ») | vrai, comme la clé |

Deux propositions s'appuient sur une source extérieure au Ronéosaure : la RNIPH
de 2024/2025 a, E (Code de la santé publique, art. L1121-1 ; CNIL,
méthodologie de référence MR-004) ; la « troisième espèce » de 2023/2024 Q8 C
(et de ses copies), donnée fausse : une notion qu'aucun cours ne cite, un
leurre.

## Les erreurs du ronéo 2025-26

Le Ronéosaure n'est pas le ronéo de l'année : une erreur s'y signale par un
**ATTENTION nu**, la sorte dite dans le texte, et rien n'entre dans
`contenu/ERRATA_RONEOS_2026-27.md`. **Aucune erreur prouvée** ; un point
douteux et deux imprécisions :

| Page | Le ronéo dit | Retenu | Sorte | Carte |
|---|---|---|---|---|
| 4 | « C'est le code H qui est unique et irréversible », puis « un 2eme code H » | sans doute le hash, le résultat du hachage : le cours 2023-24 (p. 12) dit le numéro de sécurité sociale « transformé en HASH », à sens unique ; le ronéo décrit lui-même deux codes successifs, le second intraçable. À l'examen, c'est le numéro ANO | point douteux (ATTENTION) | `reu-qc-code` |
| 3 | Framingham : « on regarde leurs expositions tous les ans » | la cohorte originale (1948) est revue tous les deux ans | imprécision, dite sans ATTENTION | `reu-qr-framingham` |
| 4 | l'article sur la thrombose compare « 1 an avant l'accouchement » ; risque « multiplié par 4 » dans les six semaines | l'article (Kamel et al., N Engl J Med 2014) compare chaque femme à la même période un an plus tard, et donne un odds ratio de 10,8 sur les six premières semaines, 2,2 entre la 7e et la 12e ; le « ×4 » vise sans doute les semaines 4 à 6 | imprécision, dite sans ATTENTION ; aucune carte ne demande ces chiffres | `reu-qc-thrombose` |

Trois formulations dites justes dans les cartes, sans ATTENTION : le niveau de
preuve « similaire aux cohortes prospectives » (p. 4) reste sous l'essai de
phase III (p. 3) ; la « régression linéaire multiple » de la phase IV (p. 2)
est, pour un événement binaire, une régression logistique (cours 2024-25,
p. 7) ; le SNDS « c'est un guichet unique (health data hub) » (p. 5) : le
guichet est le Health Data Hub, la Plateforme des données de santé, qui ouvre
l'accès, et le SNDS la base elle-même (`reu-fa-snds`, `reu-qc-snds`, le dessin
`snds.svg`).

## Les schémas et les figures

**Un schéma cliquable** (`schemas.py`), avec sa version légendée en
correction :

| Fichier | Ce qu'on clique | Pourquoi ce dessin |
|---|---|---|
| `niveaux-preuve.svg` | les quatre étages de la pyramide : essai de phase III, cohorte, cas-témoins, étude de cas | la phrase de la p. 3 ; deux cartes la lisent, `reu-zo-preuve` (chaque étude par sa définition) et `reu-zo-preuve-exemples` (par un exemple du cours : tirer au sort, la cohorte rétrospective de la thrombose, une maladie rare, un effet indésirable isolé). Les étages pavent la pyramide ; la version légendée (`niveaux-preuve-legende.svg`) ajoute l'accolade interventionnel / observationnel |

**Quatre figures redessinées** pour les corrections, le ronéo n'en ayant
aucune : `cohortes-temps.svg` (prospective, rétrospective, cas-témoins : ce qui
s'est déjà produit au début de l'étude, p. 3-4), `usage-donnees.svg` (usage
primaire et secondaire de la carte Vitale, des prescriptions et de la
biologie, du PMSI, p. 2-4), `snds.svg` (ce que contient le SNDS et ce qu'il ne
contient pas, p. 5), `chainage-ano.svg` (le code à sens unique qui chaîne les
séjours, p. 4-5).

**31 QCM sur 31 illustrés (100 %)**, 56 notes sur 62. Sans figure : les trois
termes du lexique et trois QROC (`reu-qr-confusion`, `reu-qr-student`,
`reu-qr-nejm`), qu'aucun dessin n'aide.

## Le lexique

Trois termes, des cinq du plan C15 ; aucun n'existait (vérifié contre les
`lex-*` de tous les paquets). Pages mesurées dans le texte de la FC 2025-26,
page de plan exclue :

| Terme | Origine | Pages |
|---|---|---|
| Observationnel | latin observatio, de observare | 2, 3, 4 |
| Interventionnel | latin interventio, de intervenire | 2, 4 |
| Prospectif | latin tardif prospectivus | 3, 4 |

**Laissés à biomédecine quantitative**, comme le plan le prévoyait pour un
terme pris ailleurs : *Cohorte* et *Rétrospectif*, que son plan (chapitre 7)
accueille ; les termes d'épidémiologie (sensibilité, prévalence, biais,
facteur de confusion) y sont aussi.

Les racines : `observare (latin)` et `inter (latin)` reprennent les clés de la
table commune ; `venire (latin)`, `pro- (latin)` et `specere (latin)` sont
nouvelles, et proposées avec les trois termes dans
`scratchpad/etym/info_reutilisation.json` (TLFi, Gaffiot, Wiktionnaire). `pro-
(latin)` cite la FC de sémantique (2/2, p. 10 : « pro- et pré-, avant »). Les
textes du lexique sont déjà écrits dans la forme que `appliquer_etymologies.py`
produirait.

## Questions pour Vincent

1. Les trois QCM en capture d'écran de la FC n°3 2025-26, p. 5 (sans en-tête
   ni numéro, réponses en couleur), ont le gabarit des sujets 2024-25 sur
   tablette. Je les ai cartés comme annales de la session 2024/2025, présumée
   (`reu-an-2425-a`, `-b`, `-c`), et chaque carte le dit. Tu confirmes ?

## À relire

**Aucune carte `a-relire`** : chaque note cite une page de la FC 2025-26, et
les compléments des cours 2023-24 et 2024-25 ou des sources extérieures sont
cités dans le texte. Reste à Vincent :

- quand le ronéo 2026-27 paraîtra, relire chaque carte sur lui et retirer le
  badge « Cours 2025-26 » ;
- `copier_les_cours.py` avec le dossier `…/examen décembre` du Ronéosaure
  2025-26, hors du bac à sable, pour que la fiche s'ouvre dans l'application.


## L'échelle : Simple → Moyen → Annale (C20, 18/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 16 décembre. Sous les annales, 16 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 5 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `reutilisation-donnees` | 4 | 2 | 5 |
| `reutilisation-limites` | 7 | 2 | 4 |
| `bases-donnees-sante` | 5 | 1 | 6 |

**Le schéma** `ech-reutilisation`, « La réutilisation des données · principe, sources, limites », donne 37 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_REUTILISATION`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- 2024/2025 a E (la RNIPH) : aucun cours du chapitre ne la porte, ni la fiche 2025-26 ni les cours 2024-25 et 2023-24 ; sa justification repose sur le Code de la santé publique (art. L1121-1) et la CNIL (MR-004). Pas de marche ; la lettre est posée sur la case du principe (def).
- 2021/2022 Q6 E, moitié « ne permet pas de répondre à toutes les questions » : elle n'est que dans le cours 2023-24 (p. 11), hors de la fiche. L'autre moitié (peu onéreuses, grande puissance) est préparée par reu-ech-s13 et reu-ech-s14.

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```
