# Mode de transmission mitochondriale — paquet Génétique

77 notes, 153 cartes. Chapitre `chap-ue-genetique-fc7` de l'UE Génétique.
Cours du **Dr J. Ghoumid, le 01/12/2025**, « Mode de transmission
mitochondriale » (FC n°7 du Ronéosaure 2025-26, 10 pages) ; annales du
polycopié n°7 du Ronéosaure 2024-25 (11 questions sur cinq sessions). Examen
du 16 décembre 2026.

**Une fiche provisoire.** Le ronéo 2026-27 de ce cours n'est pas paru au
02/10/2026 : le chapitre est carté sur le Ronéosaure 2025-26 (tâche C15,
décision de Vincent du 02/10), et le ronéo de l'année corrigera les cartes à
sa parution. La source porte son année dans son auteur : chaque carte de cours
(hors lexique) a le tag `cours-2025-26` et montre « Cours 2025-26 ». Aucune
carte ne dit « Absent du cours 2026-27 » ; les erreurs du Ronéosaure sont
dites par un ATTENTION sans genre, et n'entrent pas dans
`contenu/ERRATA_RONEOS_2026-27.md`, qui ne concerne que les ronéos 2026-27.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 36 | 36 |
| QRU | 2 | 2 |
| Texte à trous | 13 | 81 |
| QROC | 9 | 9 |
| Recto-verso | 6 | 6 |
| Schéma cliquable | 2 | 10 |
| Planche à légender | 1 | 1 |
| Lexique | 8 | 8 |

Dont **11 annales** (QRM), sur cinq sessions de 2021/2022 S2 à 2023/2024 S2.
**27 QCM du cours** (25 QRM, 2 QRU), dont un arbre à lire (`gmt-qc-arbre`) ;
chaque QCM a une justification par proposition. **37 QCM sur 38 sont
illustrés** (le hook : 97 %), 66 notes sur 77 ; le seul QCM sans figure est
`gmt-qc-maladies` (épidémiologie, rien à montrer).

Six thèmes, dans l'ordre du cours. Cinq sont nouveaux (plan C15, 0.6), **à
ajouter à `THEME_LABELS`** (`app/src/med_engine/application/scopes.py`) ;
`mitochondrie` existe déjà (`remed_biochimie`), avec le même libellé :

| Clé | Libellé | Notes (dont annales) |
|---|---|---|
| `mitochondrie` *(existante)* | Mitochondrie | 8 (0) |
| `genome-mitochondrial` | Le génome mitochondrial | 14 (3) |
| `cytopathies` | Cytopathies mitochondriales : clinique | 9 (2) |
| `diagnostic-mitochondrial` | Diagnostic des maladies mitochondriales | 20 (2) |
| `heteroplasmie` | Hétéroplasmie et effet goulot | 8 (3) |
| `transmission-maternelle` | Transmission maternelle et conseil génétique | 10 (1) |

(et les 8 termes du lexique, tag `lexique`).

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-genet-mit-2526` — Ronéosaure, « FC n°7 Mode de transmission mitochondriale » (10 p.), `GÉNÉTIQUE/…` | **2025-26** | **la base** : chaque note du cours porte sa page ; c'est ce que le lecteur ouvre (`chapitre=`) ; ses figures illustrent les corrections |
| `src-annales-7-transmission-mitochondriale` — « 7 - Transmission mitochondriale » (5 p., table p. 5) | 2024-25 | les 11 cartes d'annales ; déclaration à cinq champs, la règle des chapitres écrits en parallèle (aucun autre chapitre ne déclare ce fichier) |
| cours 2024-25 (Ronéosaure) et 2023-24 (Charonéo), même enseignant | — | cités dans le texte, sans être déclarés : l'endosymbiose (2024-25), « le complexe I est constitué de 45 protéines » et « glycolyse aérobie » (2023-24), 16 569 pb, le risque théorique de 100 %, Kearns-Sayre et son risque d'environ 1/24 (2023-24) ou 5 % (2024-25), « on mesure la taille de l'ADNmt » (2024-25), la biopsie de trophoblaste (2023-24) |
| erratas : cours 2025-26 (`Erratas Génétique.docx`), annales 2024-25, cours 2024-25 | — | **aucune entrée** sur la FC n°7 ni sur le polycopié n°7 |

Vérifications hors du cours, citées dans la carte qui s'en sert :
- **GeneReviews, « Single Large-Scale Mitochondrial DNA Deletion Syndromes ».**
  Trois points :
  - la recherche d'une délétion : Southern blot (la méthode historique), PCR
    longue, et aujourd'hui de préférence le séquençage haut débit
    (2022/2023 S2 Q14 E) ;
  - 25 à 33 % dans le muscle, cité comme hétéroplasmie « basse » chez des
    patients symptomatiques (2023/2024 S2 Q3 E) ;
  - le syndrome de Pearson, une atteinte de la moelle et du pancréas
    (`gmt-qc-organes` C).
- **GeneReviews, « Primary Mitochondrial Disorders Overview »** : les formes
  nucléaires sont surtout autosomiques récessives ; les formes liées à l'X sont
  rares (2022/2023 S1 Q14 D).
- **Molecular Genetics and Metabolism, 2025 (vol. 146, 109260)** : une
  délétion unique à moins de 10 % dans le muscle s'accompagne d'un déficit de
  la chaîne dans sept cas sur 1 104 biopsies (2023/2024 S2 Q3 E).
- **Chinnery et al., Lancet 2004** : un risque de 4 %, une naissance sur 24
  (2023/2024 S2 Q3 D).
- **MITOMAP** : m.8993T>G est dans MT-ATP6 (zone du complexe V).
- **L'étymologie** : TLFi, Bailly, Gaffiot, LSJ, Wiktionnaire.

## Ce que le cours a dicté

- **Le rouge du ronéo** : une seule phrase, « UNIQUEMENT LES MITOCHONDRIES
  MATERNELLES SONT TRANSMISES AU FŒTUS » (p. 4). Elle est la proposition A,
  `indispensable`, de `gmt-qc-transmission`.
- **Aucun gris**, et rien que l'enseignant ait dit de laisser. « Il y en a une
  importante à connaître : la neuropathie optique de Leber » (p. 10) devient
  la proposition A, `indispensable`, de `gmt-qc-leber`.
- **Les noms des protéines** des complexes (ND1 à ND6, COX I à III…) sont sur
  la diapositive de la p. 3 ; les cours 2023-24 et 2024-25 disent qu'ils ne
  sont « pas à connaître ». Les cartes demandent les nombres (7, 1, 3, 2, et
  aucune pour le II), pas les noms.
- **Ce qui appartient à d'autres chapitres n'est pas carté** (plan C15, 0.5) :
  la biochimie de la chaîne respiratoire, ses pompes et ses fuites
  (`bmcp_stress_oxydant`, `bmcp_metabolisme`) ; les techniques de DPN et l'IMG
  en général (`genet_tests`) ; les hérédités mendéliennes (`genet_mendelien`).
  Ils sont cités dans les justifications.
- **Aucune photographie de patient** dans ce cours. Les coupes histologiques
  (Gomori, SDH, COX), les spectres, les courbes de polarographie, l'arbre et le
  schéma du bottleneck vont.

## Les erreurs du Ronéosaure 2025-26

Chacune est dite par **ATTENTION**, sans genre, dans la carte qui porte la
notion. Aucune n'est à l'errata 2025-26 : toutes ont été trouvées en relisant.

| p. | Ce que dit le ronéo | Ce qui est retenu | Sorte | Carte |
|---|---|---|---|---|
| 2 | « son propre génome (via phagocytose d'autres organites) » | l'endosymbiose d'une bactérie : des eucaryotes « ont phagocyté des cellules procaryotes » (cours 2024-25) ; un ADN de type bactérien (p. 4) | prise de notes | `gmt-qc-dynamique` D |
| 2 | une fission qui fait des mitochondries jeunes, puis « à la fin de leur vie une fusion, ce qui les amène à faire de l'autophagie » | « fusion et fission constantes » (diapositive de la même page ; cours 2023-24 : « en permanence ») | point douteux | `gmt-qc-dynamique` A |
| 3 | les complexes, « constituées de 45 sous-unités » | 45 : le complexe I seul (cours 2023-24) | prise de notes | `gmt-qc-chaine` C |
| 3 | « Chaque complexe pompe des protons, sauf le complexe V » | les pompes sont les complexes I, III et IV ; le II n'en pompe pas | le cours lui-même, probable (la phrase est déjà dans le Ronéosaure 2024-25) ; aucune carte ne le demande | `gmt-qc-chaine` (explication) |
| 3 | le NADH produit « par la glycolyse anaérobie dans le cytoplasme » | la glycolyse (aérobie) ; en anaérobie, le NADH est réoxydé en faisant le lactate (cours 2023-24 : « glycolyse aérobie ») | prise de notes probable (déjà dans le Ronéosaure 2024-25) | `gmt-qc-substrats` B |
| 10 | Leber : « Malgré l'omniprésence de la maladie » | de la **mutation**, homoplasmique | prise de notes | `gmt-qc-leber` (explication) |

Sans ATTENTION, parce qu'aucune réponse n'en dépend, mais dit dans la carte :
la délétion unique qui « inclut toujours une région d'environ 5 000 pb »
(p. 8) — les cours 2023-24 et 2024-25 parlent de la « délétion commune » de
4,9 kb (`gmt-qc-deletions` A) ; « il existe un taux d'hétéroplasmie élevé,
c'est-à-dire que le taux de mutation varie d'un tissu à l'autre » (p. 9) —
c'est la variation, non l'élévation, que les cartes retiennent ; « présent
chez tous les eucaryotes excepté les hématies » (p. 2) — dans toutes les
cellules sauf les hématies.

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| L'ADN mitochondrial : génome à part, circulaire, copies multiples, 13 + 22 + 2 gènes, anomalies ponctuelles ou de structure | 2023/2024 S2 Q2, 2022/2023 S1 Q13, 2021/2022 S2 Q28 |
| Maladie mitochondriale ≠ transmission mitochondriale : nucléaire et mendélienne (surtout récessive), ou mitochondriale et maternelle ; ni liée à l'X | 2022/2023 S1 Q14, 2021/2022 S2 Q29 |
| L'hétéroplasmie : définition, variation d'un tissu à l'autre, sévérité qui en dépend « parfois », pas « toujours » | 2022/2023 S2 Q13, 2021/2022 S2 Q30, 2023/2024 S1 Q19 |
| Le diagnostic : lactate, IRM-spectroscopie, recherche ciblée puis séquençage | 2022/2023 S2 Q14 |
| Le conseil génétique d'une femme porteuse : bottleneck, 100 %, DPN | 2023/2024 S1 Q20 |
| Une délétion unique : sporadique, dans le muscle, risque faible mais non nul | 2023/2024 S2 Q3 |

### Les annales, session par session (clé retenue = clé imprimée)

| Session | Polycopié n°7, pages | Questions |
|---|---|---|
| 2023/2024 S1 | p. 1-2 | Q19 BE, Q20 ABDE (vignette MELAS, reprise en tête de la Q20) |
| 2023/2024 S2 | p. 2 | Q2 AC, Q3 A |
| 2022/2023 S1 | p. 2-3 | Q13 BE, Q14 ABE |
| 2022/2023 S2 | p. 3-4 | Q13 ADE, Q14 ABCD |
| 2021/2022 S2 | p. 4-5 | Q28 BCE, Q29 ABCE, Q30 ABD |

Trois paires presque identiques, une carte par session, chacune renvoyant à
l'autre : 2022/2023 S1 Q13 et 2021/2022 S2 Q28 (ADN mitochondrial),
2022/2023 S1 Q14 et 2021/2022 S2 Q29 (la C inversée : ADN nucléaire,
fausse ; ADN mitochondrial, vraie), 2022/2023 S2 Q13 et 2021/2022 S2 Q30
(« toujours » / « peut être », « varie » / « est constant »).

L'en-tête du polycopié est un gabarit non rempli (« BMCP - Annales »,
« Professeur X », « Matière », « Titre du cours ») : ce sont bien les annales
de génétique du Dr Ghoumid, dont le nom est sur la page de garde.

**Propositions hors du cours 2025-26**, justifiées sur leur source :
- **2022/2023 S2 Q14 E**, la recherche des grands réarrangements. On mesure
  la taille de l'ADNmt (cours 2024-25 p. 9), par Southern blot, PCR longue ou
  séquençage haut débit (GeneReviews), pas par séquençage direct.
- **2022/2023 S1 Q14 D**, les formes liées à l'X, rares (GeneReviews).
- **2023/2024 S2 Q3 A, D, E**, la délétion unique :
  - le tableau d'ophtalmoplégie et de ptosis (Kearns-Sayre, cours 2023-24) ;
  - le risque d'environ 1/24 (cours 2023-24, Chinnery 2004), « autour de
    5 % » selon le cours 2024-25 ;
  - le taux d'hétéroplasmie bas qui peut suffire (GeneReviews ; Molecular
    Genetics and Metabolism 2025).

## Les clés qui ne sont pas reprises telles quelles

Aucune. Les onze clés imprimées ont été relues proposition par proposition
contre le cours 2025-26 ; elles sont justes, et l'errata des annales 2024-25
n'a aucune entrée pour ce polycopié. `CONFLITS` est vide.

Un cas gardé à la clé imprimée, et dit dans la carte : **2023/2024 S2 Q3**
(clé A) tient pour cause des signes une grande délétion trouvée à 5 %
d'hétéroplasmie dans le muscle. Le cours 2025-26 ne donne aucun seuil pour
une délétion ; le tableau (ophtalmoplégie, ptosis, sans autre cas dans la
famille) est celui des délétions uniques, souvent sporadiques. Le taux est
bas : GeneReviews cite 25 à 33 % comme hétéroplasmie « basse » chez des
patients symptomatiques. Mais une délétion unique à moins de 10 % dans le
muscle peut suffire à un déficit de la chaîne (Molecular Genetics and
Metabolism, 2025). La clé n'est donc pas fausse, et la justification de E le
dit, sources à l'appui ; rien n'entre dans `CONFLITS`.

## Les schémas cliquables et la planche

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `mitochondrie-coupe.svg` (`gmt-zo-mitochondrie`) | le cytoplasme, la membrane externe, l'espace intermembranaire, la membrane interne et ses crêtes, la matrice | 5 |
| `complexes-genomes.svg` (`gmt-zo-complexes`) | les complexes I à V, chacun par son origine génétique ou son marquage : sept sous-unités de l'ADNmt (I), aucune (II, marquage SDH), une, le cytochrome b (III), les fibres COX négatives (IV), deux, les ATPases 6 et 8 (V) | 5 |

La mitochondrie est redessinée en coupe, d'après les diapositives de la
p. 2 : cinq compartiments qui pavent le dessin, tracés avec les polygones mêmes
qui corrigent le clic. Les anneaux suivent la règle pair-impair de
`geometry.annulus`, écrite pour une ellipse ; une crête appartient à la
membrane interne, pas à la matrice. Le pont de chaque anneau, que la
correction trace avec le contour des zones, est un court segment horizontal
au bord droit, le même pour les quatre anneaux (celui du cytoplasme partait
d'un coin du cadre et barrait la mitochondrie en diagonale : corrigé à la
relecture). Les complexes sont numérotés de I à V : le numéro n'est pas la
réponse, la question demande le complexe par ses deux génomes ou par son
marquage (diapositive p. 3, p. 6), jamais par sa fonction. La biochimie de
la chaîne a son propre schéma dans `bmcp_stress_oxydant` ; celui-ci ne
demande que la génétique. Les versions légendées, tirées des mêmes
constantes, sont en correction.

**Planche à légender** `gmt-pl-bottleneck` (le schéma de la p. 9, une image) :
huit numéros — cellule germinale, goulot d'étranglement (l'entonnoir, sans
légende sur la figure), ovocyte primaire, maturation ovocytaire, ovocyte
mature, et les trois descendances (> 80 %, intermédiaire, < 20 %), à
reconnaître à la part de mitochondries rouges de chaque ovocyte ; trois intrus
(spermatozoïde, blastomère, zygote). Les rectangles effacés sont dans
`donnees.py` ; l'image numérotée a été écrite par
`scripts/planche_depuis_image.py` (numéros de 44 px) et relue avec son aperçu
de contrôle. Le titre « Descendance » reste : il ne donne aucune réponse.

## Le lexique

Huit termes, tous accueillis ici (plan C15, 0.7), pages remesurées dans le
PDF 2025-26 avec `chercher_pages.py` (la p. 1, le plan, n'est pas comptée) :
**Mitochondrie** (2-10), **Hétéroplasmie** (4, 7-10), **Homoplasmie** (4),
**Cytopathie** (3, 5-9), **Phosphorylation oxydative** (3),
**Polycistronique** (4), **Spectroscopie** (6), **Rétinopathie** (5). Aucun
n'existait dans un autre paquet (« Spectrométrie », de
`bmct_suivi_therapeutique`, est un autre mot).

Chaque définition finit par son étymologie et chaque racine dit la sienne.
- **Racines reprises** de `etymologies.json` sous leur clé exacte :
  `mit(o)-`, `chondr-`, `hétéro-`, `homo-`, `plasm(o)-`, `cyt(o)- / -cyte`,
  `-pathie`, `poly-`, `trans- (latin)`, `spectrum (latin)`, `-scopie`, et
  `ox-` pour l'« oxydative » (même étymon ὀξύς ; la relecture a retiré une
  clé `oxy-` qui la doublait).
- **Racines nouvelles** (`phosph(o)-`, `cis- (latin)`,
  `retina (latin médiéval)`) et les huit termes : proposés, vérifiés, dans
  `scratchpad/etym/genet_mitochondrial.json`. La table n'est pas modifiée.
- **Textes** : déjà écrits comme `appliquer_etymologies.py` les écrirait, ce
  qu'un script a vérifié terme par terme avec la table ainsi complétée.
- **Racines qui citent la FC de sémantique**, pages relues dans le texte des
  deux PDF le 02/10 :
  - 1/2 : `cyt(o)- / -cyte` (p. 8), `-pathie` (p. 5), `ox-` (p. 6,
    « oxygène : qui génère de l'acidité (oxy- : piquant, aigre) ») ;
  - 2/2 : `hétéro-` et `homo-` (p. 5), `trans- (latin)` (p. 11),
    `phosph(o)-` (p. 12, « -phos : lumière ➢ phosphore »).
- **Les autres racines** ne sont pas dans les deux FC et restent « hors FC ».
- **« Hétéroplasmie » et « homoplasmie »** ne sont ni au TLFi ni au
  Wiktionnaire français. Leur formation est prise au Wiktionary anglais
  (hetero- / homo- + -plasmy) et au TLFi de « cytoplasme ».

## À relire

Aucune carte `a-relire` : chaque carte du cours cite sa page de la FC
2025-26, et les propositions d'annales hors de ce cours (2022/2023 S2 Q14 E,
2023/2024 S2 Q3) citent leur source dans leur justification.

## Questions pour Vincent

Le plan C15 ne posait pas de question ouverte pour ce chapitre ; voici les
décisions prises en route, chacune dite dans la carte qui la porte.

1. **2023/2024 S2 Q3** : la clé imprimée (A seule) est gardée, la délétion à
   5 % dans le muscle tenue pour cause des signes, comme le veut le
   professeur. Le cours 2025-26 ne donne pas de seuil ; la littérature décrit
   des délétions uniques à moins de 10 % dans le muscle avec un déficit de la
   chaîne (Molecular Genetics and Metabolism, 2025). D'accord ?
2. **La glycolyse « anaérobie »** (p. 3) : rangée en prise de notes probable,
   comme le proposait le plan, bien que la phrase soit aussi dans le
   Ronéosaure 2024-25 (le cours 2023-24 dit « aérobie »). Elle n'est dite que
   dans une justification ; le ronéo 2026-27 tranchera.
3. **Un second schéma cliquable**, en plus de celui du plan : les cinq
   complexes et leurs deux génomes (`gmt-zo-complexes`). Il recoupe le dessin
   de `bmcp_stress_oxydant`, mais ne demande que la génétique (sous-unités
   codées par l'ADNmt, SDH, COX). Le garder ?
4. **`phosph(o)-` cite la FC de sémantique 2/2, p. 12**, où la racine est
   écrite « -phos : lumière », avec le phosphore pour exemple. La forme diffère
   de la clé, mais l'étymon est le même (φῶς, dans φωσφόρος). Garder la
   citation, ou laisser la racine « hors FC » ?


## L'échelle : Simple → Moyen → Annale (C20, 18/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 16 décembre. Sous les annales, 25 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 7 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `genome-mitochondrial` | 7 | 2 | 3 |
| `cytopathies` | 4 | 1 | 2 |
| `diagnostic-mitochondrial` | 4 | 1 | 2 |
| `heteroplasmie` | 6 | 2 | 3 |
| `transmission-maternelle` | 4 | 1 | 1 |

**Le schéma** `ech-mitochondrial`, « L'ADN mitochondrial en pathologie · génome, maladie, transmission, diagnostic », donne 44 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_MITOCHONDRIAL`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- gmt-an-2324s2-q3 E — le seuil d'hétéroplasmie qui rend une délétion à 5 % dans le muscle compatible avec les signes n'est pas dans le cours 2025-26 (GeneReviews ; Molecular Genetics and Metabolism 2025, cités par la justification) ; la lettre est posée sur « Les anomalies de l'ADNmt », sans marche. La lettre A n'est préparée que par l'existence des délétions (s7) et par le choix du muscle (s24).
- gmt-an-2223s2-q14 E — la recherche des grands réarrangements (Southern blot, PCR longue, séquençage haut débit) est hors du cours 2025-26 (cours 2024-25 p. 9, GeneReviews) ; lettre posée sur « Les anomalies de l'ADNmt », sans marche.

## Régénérer

```powershell
cd contenu\chapitres\genet_mitochondrial
..\..\..\app\.venv\Scripts\python.exe generer.py
```

`generer.py` est la copie exacte de
`.claude/skills/nouveau-chapitre/scripts/generer_modele.py`. Les figures de
`media/` ont été extraites du PDF par PyMuPDF : à résolution native pour les
images nettes (biopsie, polarographie, arbre, bottleneck), rendues à 2,5-3×
et découpées au rectangle près pour les captures de diapositives ; elles se
versionnent et partent avec le chapitre. La planche numérotée se refait,
depuis `app/`, par
`uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/genet_mitochondrial gmt-pl-bottleneck --taille 44 --apercus <brouillon>`.
