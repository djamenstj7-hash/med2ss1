# Informatique, stockage et accès à l'information — paquet Informatique médicale

79 notes, 146 cartes. Chapitre `chap-ue-info-medicale-fc2` de l'UE Informatique
médicale, deuxième de l'UE. Cours du **Pr Chazard, le 31/10/2025, de 8 h à
9 h**, dans le **Ronéosaure 2025-26** (FC n°2, 13 pages). **Aucune annale** :
voir plus bas. Examen : partiel du mercredi 16 décembre 2026, sur tablette.

**Fiche provisoire** (décision de Vincent du 02/10) : le cours de l'année
2026-27 n'est pas encore paru. Chaque carte de cours cite la FC 2025-26 à sa
page ; le ronéo 2026-27 la corrigera quand il sortira. `donnees.py` porte
`ANNEE_COURS = "2025-26"`, et chaque carte le tag `cours-2025-26` (badge
« Cours 2025-26 »).

## Le cours 2026-27 : en attente des CM suivants (19/10/2026)

Le dépôt du 19/10/2026 de Ronéo & Juliette n'a, pour l'informatique médicale,
que les deux ronéos du **06/10/2026 du Dr Gérard**, « Informatique en santé » 1
et 2 (8 h-10 h). Ils sont le cours de la FC n°1 et réalignent le chapitre
`info_sante`. **Aucun ne traite ce cours-ci** — système de fichiers, formatage,
chemin d'accès, extensions et formats, cloud, codage binaire. La partie 2 parle
de « stockage » au sens du partage des données de santé (Mon espace santé,
entrepôts, SNDS, p. 9-10), et du cloud seulement comme cadre juridique de
l'hébergement des données de santé (p. 8). Le CM du Pr Chazard n'a pas encore de
ronéo 2026-27.

Rien ne change donc dans les cartes : la FC 2025-26 reste la fiche provisoire
(`chapitre=`), le badge « Cours 2025-26 » reste, aucune page ne cite le ronéo
2026-27. Seul ajout : l'explication de `ist-qc-patriot-act` renvoie au cours de
Gérard (partie 2, p. 7-8 : un stockage « cloud » n'est pas neutre juridiquement)
et à la carte `isn-qc-hds-cloud` du chapitre Informatique en santé, qui porte le
point douteux du ronéo sur les données « qui appartiennent aux États-Unis ».

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 34 | 34 |
| QRU | 4 | 4 |
| Texte à trous | 12 | 66 |
| QROC | 12 | 12 |
| Recto-verso | 9 | 9 |
| Schéma cliquable | 1 | 14 |
| Planche à légender | 1 | 1 |
| Lexique | 6 | 6 |

Sept thèmes, dans l'ordre du cours, tous nouveaux (plan C15) ; leurs libellés
restent à ajouter à `THEME_LABELS` (`app/src/med_engine/application/scopes.py`) :

| Clé | Libellé | Notes |
|---|---|---|
| `systeme-physique-logique` | Information : système physique, système logique | 7 |
| `systeme-fichiers` | Clusters, formatage et défragmentation | 10 |
| `rangement-fichiers` | Nommer, ranger, sauvegarder ses fichiers | 4 |
| `chemin-acces` | Chemins d'accès absolus et relatifs | 15 |
| `types-fichiers` | Fichiers, extensions et archives | 12 |
| `cloud` | Le cloud et ses limites | 3 |
| `codage-binaire` | Coder en binaire : bases, octets, texte, couleurs | 22 |

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-info-stockage-2526` — Ronéosaure, « FC n°2 - Informatique, stockage et accès à l’information » (13 p.) | 2025-26 | le cours ; `SRC["cours"]`, `SRC["fiche"]`, `SRC["medias"]` ; ses 27 diapositives |

Le chemin relatif est le nom exact du disque, en NFC, avec l'apostrophe
typographique (U+2019) : `INFORMATIQUE MÉDICALE/FC n°2 - Informatique, stockage
et accès à l’information.pdf`.

Lus en appoint, sans être déclarés : le cours 2024-25 du même professeur
(Ronéosaure 2024-25, même titre), pour la phrase « il y a de l'informatique
lorsque… », la date de modification, le « patriot act » et Unicode « sur deux
octets » (ces deux derniers déjà dans le cours 2024-25 : c'est le cours
lui-même) ; l'errata des cours 2025-26 (vide) ; l'errata des cours 2024-25,
dont la seule entrée (« ordre alphabétique » et non « ordre informatique »)
vise une phrase que le ronéo 2025-26 n'a plus. Aucun nom d'étudiant n'est
repris des en-têtes.

## Les annales

**Aucune.** Le cours a été repris en 2024-25 après dix ans d'arrêt (p. 2) ; le
dossier des annales de décembre du Ronéosaure 2024-25 n'a pas de polycopié pour
lui (FC3 à FC7 seulement), et aucune fiche 2025-26 ne reproduit de question de
2024-25 sur ce cours. Pas d'`annales.py`, pas de clé imprimée : **aucune clé
n'est reprise autrement que telle quelle**, faute de clé. Le professeur renvoie
pourtant aux annales pour le chemin d'accès (« LE PLUS IMPORTANT DU COURS (VOIR
ANNALES) », p. 6) : le chapitre le compense par l'arborescence cliquable, trois
QCM et quatre recto-verso d'écriture de chemins (voir la question 1 plus bas).

## Ce que le cours a dicté

- **Le chemin d'accès**, « LE PLUS IMPORTANT DU COURS » et « IL FAUT SAVOIR
  ÉCRIRE LES DEUX TYPES DE CHEMINS » (p. 6) : 15 notes, 36 cartes —
  `ist-zo-arborescence` (14 zones), `ist-qc-chemin-structure`, `ist-qc-absolu`,
  `ist-qc-relatif-temp`, `ist-qc-relatif-monimage`, `ist-qc-guillemets`,
  `ist-qc-windows`, `ist-fa-chemin`, deux QROC et cinq recto-verso, dont quatre
  où l'on écrit un chemin (absolu, relatif qui remonte, relatif qui remonte
  puis redescend, relatif entre guillemets). **Un chemin ne se tape pas en
  QROC** : la correction ignore la ponctuation (`domain/scoring.normalise`),
  si bien que `.\temp.txt` et `..\..\temp.txt` y seraient égaux ; l'écriture se
  vérifie donc en recto-verso, auto-évalué, et la lecture en QCM et en zones.
- **L'arborescence et les répertoires** (« À VRMT CONNAÎTRE », p. 4), le
  système logique « à bien maîtriser » (p. 5) : `ist-qc-haut-niveau`, la
  planche, le terme `lex-arborescence`.
- **« À RETENIR »** : la version la plus complète « jamais chez nous » (p. 11),
  proposition inacceptable de `ist-qc-cloud` ; l'octet, 8 bits, 256 valeurs, de
  0 à 255 (p. 12), proposition indispensable de `ist-qc-octet`.
- **Le gris du ronéo** n'est que celui des titres, sauf deux passages : la
  « description technique du disque à ne pas apprendre » (plateaux, cylindres,
  secteurs, p. 3), **sans carte**, et l'anecdote de l'école Centrale (p. 9),
  sans carte. Le reste se carte comme le reste (règle du gris des ronéos).
- **Les diapositives départagent** le texte du ronéo : elles sont citées comme
  preuve dans chaque ATTENTION.

## Les schémas et les figures

**Vingt-sept diapositives de la FC 2025-26**, extraites en PNG (1000 px de large
au plus, 128 couleurs), toutes du côté de la correction : les fichiers (p. 2),
les supports et le formatage de bas niveau (p. 3), le parallèle physique-logique,
le formatage de haut niveau et la fragmentation (p. 4), le défragmenteur et le
rangement (p. 5), le chemin d'accès et les répertoires de Windows (p. 6), les
autres moyens (p. 7), les noms courts et les extensions (p. 8), le ZIP et le
.docx (p. 9), les types de fichiers et le cloud (p. 10), le décimal, le nombre
à virgule, l'hexadécimal, le binaire et le nombre non entier (p. 11), l'octet,
la table ASCII et Unicode (p. 12), les couleurs RVB et leurs notations (p. 13).
Aucune photographie de patient.

**Un schéma cliquable** (`schemas.py`), avec sa version légendée en correction :

| Fichier | Ce qu'on clique | Pourquoi ce dessin |
|---|---|---|
| `arborescence.svg` | quatorze éléments d'un lecteur C: — le lecteur, cinq dossiers, huit fichiers —, chacun désigné par un chemin absolu ou relatif depuis le dossier courant `C:\Cours\2025-10-31_informatique` | la présentation de l'explorateur des p. 4 et 6. **Les noms sont écrits, et c'est voulu** : ils sont les données du problème, la réponse est la résolution du chemin. Pour que lire le nom ne suffise pas, trois `monimage.png`, deux `temp.txt` et deux `these finale.docx` ; un clic sur l'homonyme vaut zéro. Les deux exemples de la diapositive (`../../temp.txt`, `./images/monimage.png`) y sont ; `Mes theses` porte une espace pour les guillemets |

`arborescence-legende.svg` écrit à côté de chaque élément son chemin relatif :
c'est la correction de la zone, des trois QCM de chemins et des quatre
recto-verso d'écriture, dont l'arborescence nue est l'énoncé
(`illustration_question` : le schéma ne donne aucun chemin).

**Une planche** (`ist-pl-physique-logique`, figure image,
`planche_depuis_image.py`), la diapositive de la p. 4 : six cases vidées —
disque physique, adressage LBA ou CHS, secteurs de 512 octets, lecteurs logiques
(partitions), arborescence de dossiers, fichiers. Intrus : clusters, système
d'exploitation, extension. Les bandeaux « Système physique » et « Système
logique » restent : ils sont l'énoncé. Le bas du « ) » de « variable) » mordait
le cadre de la case 5 : un second rectangle l'efface, d'où une petite encoche
dans le cadre.

**37 QCM sur 38 illustrés (97 %)**, 71 notes sur 79. Sans figure :
`ist-qc-piece-jointe`, qu'aucune diapositive ne montre.

## Les erreurs du ronéo 2025-26

Le Ronéosaure n'est pas le ronéo de l'année : chaque erreur est portée par un
**ATTENTION nu** dans la carte qui tient la notion, la sorte dite dans le texte,
et rien n'entre dans `contenu/ERRATA_RONEOS_2026-27.md`.

| Page | Le ronéo dit | Retenu | Sorte | Carte |
|---|---|---|---|---|
| 2 | « il y a de l'**information** dès l'instant où existe » un système physique et un ou plusieurs systèmes logiques | il y a **informatique** : le contre-exemple du livre qui suit, et le cours 2024-25 (p. 2) | prise de notes probable | `ist-qc-informatique` C, `ist-fa-informatique` |
| 3 | clusters « de 512 octets ou 4 Mo » | la diapositive de la même page : « 512 à 4048 octets » ; NTFS : 4 Ko par défaut, 512 octets à 2 Mo (Microsoft, MS-FSA) | point douteux (« 4 Mo » sans doute « 4 Ko ») | `ist-qc-clusters` E, `ist-fa-formatage-bas` |
| 3 | un cluster entamé « ne pourra pas être utilisé pour un autre cluster » | « pour un seul fichier » (diapositive p. 3) | prise de notes | `ist-qc-formatage-bas` D |
| 4 | les lecteurs « (CD, EF…) » | « montés C: D: E: » (diapositive p. 4) | prise de notes | `ist-qc-haut-niveau` C |
| 5 | « quand on ouvre un fichier, on met à jour sa date de modification » | c'est l'enregistrement qui la change (l'ouverture change la date de dernier accès) ; le cours 2024-25 disait qu'on peut ouvrir un fichier sans que l'OS change sa date ; l'idée tient : seule la date du nom est fiable | point douteux | `ist-qc-nommer` C |
| 6 | le chemin « commence avec : un nombre de lecteurs » | un lecteur : [lecteur]/[dossiers…]/[fichier] (diapositive p. 6) | prise de notes | `ist-qc-chemin-structure` A, `ist-fa-chemin` |
| 7 | « Canti:users/emmanuel/OneDrive/desktop », « cusersmmanuel.drive » | `C:\Users\vous\OneDrive\Desktop`, `…\Documents` (diapositive p. 6) | prise de notes | `ist-qc-windows` C |
| 9 | « bmt (image à format non compressé) » | BMP (diapositive p. 8) | prise de notes | `ist-qc-images` E |
| 10 | ressources « (DML…) » | DLL (ApacheCore.dll, diapositive p. 4) | prise de notes | `ist-qc-executables` |
| 11 | 2056 = « 2x10³ + 0x10² + 5x10⁵ + 6x10⁰ » | 5 × 10¹ (diapositive p. 11) | prise de notes | `ist-qc-bases` A |
| 11 | 542 = « 2x10¹⁶ + 1x10⁵ + 14x10⁰ » | 2 × 16² + 1 × 16¹ + 14 × 16⁰ (diapositive p. 11) | prise de notes | `ist-qc-bases` C, `ist-qr-hex-542` |
| 11 | 1,3 = « 1,00100111001… » en binaire | 1,0100110011… (diapositive p. 11 ; vérifié par le calcul) | prise de notes | `ist-qc-non-entier` A |
| 11 | le « PATRIOT ACT » donne au gouvernement américain l'accès aux données des entreprises américaines | c'est le cours lui-même (déjà en 2024-25) ; à l'examen, le Patriot Act. La référence : le Patriot Act était déjà invoqué pour cet accès ; la loi qui oblige expressément les fournisseurs américains à livrer les données stockées hors des États-Unis est le CLOUD Act du 23/03/2018 (CRS, R45173) | le cours lui-même | `ist-qc-patriot-act` A |
| 12 | deux octets « jusqu'à 65 635 » | 65 535 = 2¹⁶ − 1 | prise de notes | `ist-qc-entiers` C, `ist-qr-deux-octets` |
| 12 | « le caractère a = 16x1+4 » | code = seize × X + Y (diapositive p. 12) : « A » = 65, « a » = 97 | prise de notes | `ist-qc-ascii-code`, `ist-qr-a-minuscule` |
| 12-13 | Unicode « 2 octets au lieu d'un », « table étendue sur 16 bits » | c'est le cours lui-même (Unicode 1.0, 1991) ; aujourd'hui plus d'un million de points de code, 1 à 4 octets en UTF-8 | le cours lui-même | `ist-qc-texte` D |
| 13 | #ff0000 « se décode en 255 00 qui se décode en 111 00 » | 255, 0, 0 ; 11111111 00000000 00000000 (diapositive p. 13) | prise de notes | `ist-qr-rouge-hex` |

Dites sans ATTENTION, parce qu'elles ne changent rien au savoir : « xslx » pour
.xlsx (p. 8 ; `ist-qc-formats` A) ; « crypter » pour chiffrer (p. 11 ;
`ist-fa-cloud`, `ist-qc-patriot-act` C) ; la diapositive de la p. 6 qui range
`../../temp.txt` sous « Dossier » alors que c'est un fichier
(`ist-rv-absolu-relatif`) ; le bit de signe (−127 à +127), juste en
représentation signe et valeur absolue, quand les processeurs emploient le
complément à deux (`ist-qc-entiers`).

Sans carte, parce qu'aucune n'en dépend : « Plus le service est plein » pour le
disque (p. 5) ; les dossiers « forcément dans le lecteur C car c'est le seul
lecteur physique » (p. 7 ; la diapositive montre aussi D: et E:) ; « avant sur
Windows et Linux 2 » pour la convention 8.3 de MS-DOS et des premiers Windows
(p. 8) ; « Il existe aussi les clusters de 500 » (p. 12) ; le signal électrique
« +5V ou -5V » (p. 12 ; les cartes disent seulement deux niveaux de tension).

## Le lexique

Six termes, ceux du plan C15 ; aucun n'existait (vérifié contre les `lex-*` de
tous les `donnees.py` et `paquet.json`). « Binaire », marqué d'un astérisque au
plan, n'est pris par aucun chapitre de biomédecine quantitative. Pages mesurées
dans le texte de la FC 2025-26 (`pages_termes.py`, en-têtes et sommaire de la
p. 1 exclus) :

| Terme | Origine | Pages |
|---|---|---|
| Arborescence | latin arborescens (arbor) | 4, 6, 9 |
| Défragmentation | latin de- + fragmentum | 4, 5 |
| Hexadécimal | grec héx + latin decimus | 11, 13 |
| Binaire | latin binarius | 8, 10, 11, 12, 13 |
| Octet | latin octo | 3, 4, 9, 12, 13 |
| Compression | latin compressio | 9 |

Les racines nouvelles (`arbor (latin)`, `fragmentum (latin)`, `hex(a)-`,
`decimus (latin)`, `binarius (latin)`, `oct(o)-`, `comprimere (latin)`) et les
six termes sont proposés à la table commune dans
`scratchpad/etym/info_stockage.json`, vérifiés sur le TLFi (API cnrtl.fr,
02/10/2026), le Gaffiot et le Bailly ; `dé- (latin)` reprend la clé existante.
Les textes du lexique sont déjà écrits dans la forme que
`appliquer_etymologies.py` produirait (vérifié : la table fusionnée ne les
change pas). « Défragmentation » est absent du TLFi : il se dit formé sur
fragment(ation), d'après le Wiktionnaire.

## Décisions prises en route

- **Pas d'`annales.py`** : rien à y mettre. Le générateur s'en passe.
- **`EXAMENS` n'est pas déclaré** (convention des chapitres de BMCT) : le
  partiel du 16/12 se règle dans l'application.
- **La phrase « il y a de l'information… »** est cartée « il y a
  informatique… », avec l'ATTENTION ; le libellé du thème reste celui du plan.
- **Les chemins s'écrivent en recto-verso**, pas en QROC (la normalisation de
  la correction efface la ponctuation qui fait le chemin).
- **Le PATRIOT ACT** reste la réponse d'examen, comme le professeur l'enseigne ;
  la carte donne le CLOUD Act comme référence.

## Questions pour Vincent

1. Le professeur renvoie aux annales pour le chemin d'accès (« VOIR
   ANNALES », p. 6), mais le Ronéosaure 2024-25 n'a aucune annale de ce cours,
   et la page d'annales 2024-25 de la FC1 commence à la question 3 : **as-tu le
   sujet 2024-25 (questions 1 et 2), ou celui de 2025-26 ?** Ils porteraient
   sans doute sur ce cours ; ils deviendraient les annales du chapitre.

Les trois questions ouvertes du plan C15 (annales d'IA, QCM de la FC3 p. 5,
« disponibilité » en cryptographie) ne touchent pas ce chapitre. La lecture
« il y a informatique » (p. 2) et le Patriot Act sont tranchés par les preuves
et la règle du cours lui-même (voir le tableau des erreurs), sans question.

## Absent du cours 2026-27

Aucune carte (`ABSENTS_2026` n'est pas déclaré) : le cours 2026-27 de ce chapitre
n'a pas encore eu de ronéo.

## En attente des CM suivants

**Les 79 notes**, tout le chapitre. Elles gardent leur page de la FC n°2 2025-26
et se reliront à la parution du ronéo 2026-27 du CM du Pr Chazard : alors, chaque
carte confirmée prendra `page=` sur le ronéo de l'année, les autres
`ABSENTS_2026`, comme `info_sante` le 19/10.

## Sans illustration

Sans objet : 37 QCM sur 38 sont illustrés.

## À relire

**Aucune carte `a-relire`** : chaque note cite une page de la FC 2025-26, et
ses diapositives départagent le texte du ronéo quand il se trompe. Reste à
Vincent :

- quand le ronéo 2026-27 paraîtra, relire chaque carte sur lui et retirer le
  badge « Cours 2025-26 » ;
- `copier_les_cours.py` avec le dossier `…/examen décembre` du Ronéosaure
  2025-26, hors du bac à sable, pour que la fiche s'ouvre dans l'application ;
- ajouter les sept libellés de thèmes à `THEME_LABELS`.

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```

Pour la planche, depuis `app/` (Pillow) :
`uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/info_stockage ist-pl-physique-logique --apercus <brouillon> --taille 34`.
