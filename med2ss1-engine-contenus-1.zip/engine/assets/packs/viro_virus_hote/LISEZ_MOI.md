# Virus et hôte — paquet Virologie

61 notes, 112 cartes. Chapitre `chap-ue-virologie-fc3` de l'UE Virologie
(ordre 3). Cours du **Pr Hober, le 15/10/2025** (10 h-11 h), « Virus et hôte
partie 2 » — FC n°3 du Ronéosaure 2025-26, 10 pages ; deux questions
d'annales du Ronéosaure 2024-25 (VIRO n°1 et VIRO n°6) et une du sujet de
l'examen du 09/01/2025 (2024/2025 Q2, sans corrigé). Examen de virologie
du 5 janvier 2027 (`exam-viro-jan-2027`, portée sur l'UE, identique dans les
dix paquets de virologie).

**18/10/2026** : 1 question du sujet de virologie 2025/2026 (examen du
08/01/2026, sans corrigé) — Q.7 ; voir « Le sujet 2025/2026 ».

**Une fiche provisoire.** Aucun ronéo 2026-27 de virologie n'est paru (cours
à partir du 06/10/2026) : le chapitre est carté sur le Ronéosaure 2025-26
(décision de Vincent du 02/10), et le ronéo de l'année corrigera les cartes à
sa parution. La source porte son année dans son auteur (« Ronéosaure
2025-26 ») : chaque carte de cours prend le tag `cours-2025-26` et le badge
« Cours 2025-26 ». Aucune carte ne dit « Absent du cours 2026-27 », et les
erreurs du Ronéosaure sont dites par un ATTENTION sans genre (précédent
d'`immuno_innee`) : la liste des erreurs de la promo,
`contenu/ERRATA_RONEOS_2026-27.md`, ne concerne que les ronéos 2026-27 et
n'est pas touchée.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 25 | 25 |
| QRU | 1 | 1 |
| Texte à trous | 10 | 51 |
| QROC | 10 | 10 |
| Recto-verso | 6 | 6 |
| Schéma cliquable | 1 | 11 |
| Lexique | 8 | 8 |

Dont **4 annales** (QRM), sur 4 sessions : 2025/2026, 2024/2025, 2023/2024 S1 et 2016/2017 S1. Les 22 QCM du cours ont une justification par proposition, comme les annales.
**18 QCM sur 26 sont illustrés** (69 %), par douze figures de la fiche et le
génome redessiné.

Six thèmes, dans l'ordre du cours :

| Clé | Libellé | Partagé avec |
|---|---|---|
| `resistance-hote` | Résistance et défense de l'hôte | `viro_multiplication`, même libellé |
| `inne-adaptatif` | Immunité innée et immunité adaptative | `immuno_innee`, `immuno_temporelle` (déjà dans `THEME_LABELS`) |
| `anticorps-antiviraux` | Rôle des anticorps dans l'infection virale | — |
| `immunopathologie-virale` | Immunopathologie et facilitation de l'infection | — |
| `echappement-viral` | Échappement des virus aux défenses | — |
| `variations-antigeniques` | Glissements et cassures antigéniques | `viro_pathogenes_1`, même libellé |

Cinq libellés sont à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) : tous sauf `inne-adaptatif`.
Le test `test_tout_theme_du_paquet_a_son_libelle` échoue d'ici là, et lui
seul. Le plan C16 nommait deux de ces thèmes `immunopathologie` et
`echappement` : deux mots que l'immunologie voudrait aussi (l'hypersensibilité,
l'échappement tumoral), avec un autre libellé. Ils sont devenus
`immunopathologie-virale` et `echappement-viral` à la relecture ; aucun autre
paquet ne les emploie.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-viro-fc3` — Ronéosaure, « FC n°3 Virus et hôte » (10 p.), `VIROLOGIE/FC n°3 Virus et hôte.pdf` | **2025-26** | **la base** : chaque note du cours porte sa page ; c'est ce que le lecteur ouvre (`chapitre=`) |
| `src-annales-virologie-1-structure-et-replication-des-virus` — « VIROLOGIE 1 - Structure et réplication des virus » | 2024-25 | 2023/2024 S1 Q.2 (table p. 7) ; déclaration identique à celle de `viro_structure` |
| `src-annales-virologie-6-pathogenes-viraux-ii` — « VIROLOGIE 6 - Pathogènes viraux II » | 2024-25 | 2016/2017 S1 Q21 (table p. 24) ; déclaration recopiée de `viro_pathogenes_1` |
| `src-sujet-viro-2425` — « Sujet de virologie 2024/2025, session 1 » (examen du 09/01/2025, 16 p., 30 QCM) | 2024-25 | 2024/2025 Q2 ; sujet sans corrigé ; déclaration identique dans tous les chapitres de virologie qui en prennent une question |
| Cours 2024-25, « Virus et hôte II » (Ronéosaure 2024-25, Pr Hober) | 2024-25 | cité dans le texte des cartes, à la page, pour trancher une formule du ronéo de cette année ; non déclaré |
| FC n°2, 5, 6, 7, 8, 9 et 10 du Ronéosaure 2025-26 | 2025-26 | citées dans le texte, à la page ; le lexique cite FC n°2, 6 et 9 par leurs identifiants (`src-fc-viro-fc2`, `-fc6`, `-fc9`), déclarés dans leurs chapitres |
| Erratas du Ronéosaure : cours 2025-26 (`Erratas Virologie.docx`) et annales 2024-25 | — | trois entrées sur la FC n°3, reprises (tableau plus bas) ; aucune sur les deux annales |

Vérifications hors du cours, citées dans la carte qui s'en sert : Stremlau et
al., Nature 2004 (TRIM5α, macaque rhésus, restriction avant la
rétrotranscription) ; la famille des gènes de l'IFN α (14 gènes dont un
pseudogène) ; l'immunité incomplète contre le VRS (revues PMC/NIH) ; la
chronicité du VHB (OMS) ; la taille du génome du CMV humain ; le premier essai
de l'interféron contre l'hépatite B (Greenberg et al., 1976) ; l'étymologie
(TLFi par l'API du CNRTL, Bailly, Gaffiot, Wiktionnaire).

Le PDF de la fiche n'est lisible dans l'application qu'une fois copié dans le
dossier des PDF de cours : depuis `app/`, hors du bac à sable,
`uv run python ../outils/copier_les_cours.py "<dossier des ronéos>"`.

## Ce que le cours a dicté

- **La FC n°3 est la suite de la FC n°2** (« Virus et hôte partie 2 »). Ses
  parties I.A (défense non spécifique) et I.B (résistance génétique) renvoient
  au cours précédent : `viro_multiplication` les carte (FC n°2, p. 18). Ce
  chapitre ne les reprend que dans les deux annales, qui les citent.
- **Pas de rouge, pas de gris** dans la FC n°3 : tout se carte.
- **Ce qui appartient à d'autres chapitres n'est pas carté ici** (plan C16) :
  la particule et le cycle du VIH (FC n°8, `viro_pathogenes_3`), la dengue et
  la grippe comme maladies (`viro_pathogenes_2`, `viro_pathogenes_1`), les
  interférons et les immunoglobulines comme traitements (FC n°9,
  `viro_antiviraux`), la distinction virokine / viroceptor (FC n°2,
  `viro_multiplication`). Ils sont cités dans les justifications, à la page.
  Le génome du VIH, que la FC n°3 décrit p. 2, reste ici, comme le plan le
  range : un texte à trous et le schéma cliquable, dont les phrases citent
  aussi la FC n°8 (p. 15).
- **Deux recoupements voulus par le plan**, chacun sur sa propre fiche :
  `pv3-fa-vih-genes` (FC n°8) troue aussi gag, pol et env, et
  `pv1-rv-glissement-cassure` (FC n°6) oppose aussi le glissement et la
  cassure. À la relecture, la carte `hot-rv-virokine-viroceptor`, qui
  reprenait la distinction de la FC n°2 (`mul-rv-virokine-viroceptor`), a été
  remplacée par `hot-rv-ebv-poxvirus` : l'IL-10 de l'EBV et les viroceptors
  des poxvirus, les deux exemples de la FC n°3 (p. 9-10).
- Le cours enchaîne les exemples sans les hiérarchiser ; les cartes suivent
  son plan : défenses de la cellule (TRIM5α, APOBEC3G), défense de l'hôte
  (aiguë, chronique, vaccins), immunité innée (senseurs, interférons, MDA5),
  défenses spécifiques (LT, CMH, anticorps, isotypes, séroprophylaxie),
  phénomènes néfastes (complexes immuns, mimétisme, facilitation), puis les
  sept mécanismes d'échappement et leur résumé.

## Les erreurs du Ronéosaure 2025-26

Chacune est dite par **ATTENTION**, sans genre, dans la carte qui porte la
notion.

| Page | Ce que dit le Ronéosaure | Ce qui est juste | Carte | D'où |
|---|---|---|---|---|
| 2 | « il n'y a pas de transcription de l'ADN » (TRIM5α) | pas de rétrotranscription de l'ARN viral en ADN, la capside étant prise en charge avant | `hot-qc-trim5` D | errata du cours |
| 4 | « pour activer l'immunité innée il faut les composants viraux + la réponse immune naturelle (cellules dendritiques) » | l'immunité **adaptative** (cours 2024-25, p. 6) | `hot-qc-acteurs-innes` B | errata du cours |
| 6 | « le complexe anti-Anticorps » | le complexe antigène-anticorps | `hot-qc-anticorps-modes` B | errata du cours |
| 5 | les LB portent des récepteurs « prédisposés à reconnaître les LT » (déjà en 2024-25, p. 7) | le récepteur du LB reconnaît l'antigène ; le LT ne fait que l'activer | `hot-qc-immunite-humorale` B | en relisant |
| 9 | le glissement « ne se transmet pas » | ses virus circulent et font les infections récidivantes de chaque saison (FC n°10 partie 2, p. 5 ; cours 2024-25, p. 12) | `hot-qc-glissement-cassure` B | en relisant |
| 4 | l'IFN α « à cette époque » (les années 50) produit et utilisé contre les hépatites chroniques | découvert en 1957 ; essayé contre l'hépatite B chronique en 1976, sous forme leucocytaire (Greenberg et al., N Engl J Med 1976), puis recombinant (cours 2024-25, p. 5) | `hot-qc-ifn-alpha` (explication) | en relisant |
| 3 | « les herpèsvirus » parmi les virus sans vaccin | vrai de HSV, CMV, EBV ; le VZV a son vaccin vivant atténué (FC n°10 partie 1, p. 10) | `hot-qc-vaccins` D | en relisant |

**Le cours lui-même**, et la carte répond comme le professeur : le VRS rangé
avec la rougeole et les oreillons parmi les virus constants, « une seule
infection est immunisante » (p. 8 ; FC n°5, p. 11 : « immunité à vie car le
VRS ne varie pas »), quand le cours 2024-25 ne citait que la rougeole et les
oreillons (p. 11). `hot-qc-apparence` C est cotée vraie, avec « À l'examen : »
et « La référence : » (l'immunité contre le VRS est partielle et brève, les
réinfections jalonnent la vie).

Sans ATTENTION, parce qu'aucune réponse n'en dépend, mais dit dans la carte :
« syndrome de purtilo » pour syndrome de Purtilo (p. 3, `hot-qc-aigue-chronique`
E) ; « CHM » pour CMH (p. 1, 7, 8 ; `hot-fa-echappement-cmh`) ; « grands
singes » pour TRIM5α, quand l'expérience princeps porte sur le macaque rhésus,
un singe de l'Ancien Monde (`hot-qc-trim5`, explication) ; « choc septique »
pour le choc de la dengue sévère (`hot-qc-facilitation` D) ; « 40 gènes pour
fabriquer des particules et 40 pour manipuler » pour le CMV, dont le génome en
compte plus de 160 (`hot-qc-nk-leurre`, explication) ; les 14 sous-types d'IFN
α, chiffre du cours (les deux années), quand la littérature compte 14 gènes
dont un pseudogène, 13 actifs (`hot-fa-ifn-alpha`).

**Des chiffres qui changent d'un cours à l'autre**, dits dans la carte sans
être tranchés (`hot-fa-tolerance`) : la chronicité du VHB, « presque 100 % »
chez le nouveau-né ici (p. 9), 90 % dans la FC n°2 (p. 16), 90 à 100 % dans la
FC n°8 (p. 7) ; 5 à 10 % chez l'adulte ici et dans la FC n°2, 10 à 20 % dans la
FC n°8 (p. 7) et la FC n°10 partie 2 (p. 7), 20 % dans le cours 2024-25. Les
annales cotent vrais les deux fourchettes. À la relecture, la carte a cessé de
trouer « 5 » et « 10 » (un trou aurait tranché) : elle écrit les deux
fourchettes et troue « chronique » à la place ; la référence de l'OMS
(80 à 90 % des nourrissons, moins de 5 % des adultes) est dans l'explication.

## Ce que les annales ont dicté

| Poly | Session | N° | Clé imprimée | Retenue | Sujet |
|---|---|---|---|---|---|
| VIRO n°1 | 2023/2024 S1 | Q.2 | ABCD | ABCD | barrières, résistance génétique au B19, défenses des cellules, signes venus de l'hôte, anticorps tardifs |
| VIRO n°6 | 2016/2017 S1 | Q21 | BCE | BCE | pH acide, hyperthermie, antigène P, IFN α, APOBEC3G et Vif |
| Sujet du 09/01/2025 | 2024/2025 | 2) | aucune (sujet sans corrigé) | BCE | peau saine, CCR5 et VIH, défenses des cellules, signes « uniquement » viraux, anticorps de la primo-infection |

Deux questions de synthèse sur la « résistance et défense », à cheval sur la
FC n°2 et la FC n°3 ; leurs pièges (l'IFN α qui « se lie aux virus », les
anticorps qui « apparaissent quelques heures après ») ont chacun leur
proposition dans les QCM du cours (`hot-qc-ifn-alpha` D,
`hot-qc-immunite-humorale` C). Ni doublon, ni décalage de table (la colonne
2016-2017 S1 de VIRO n°6 est hors du décalage des sessions 2019-2021 que
signale l'errata des annales).

**2024/2025 Q2**, du sujet de l'examen du 09/01/2025 (`Annales_15102026`), est
la reprise de 2023/2024 S1 Q.2 : C à l'identique, D et E retournées, A (la
peau saine) et B (CCR5 et le VIH au lieu du parvovirus B19) neuves. Le sujet
n'a pas de corrigé et aucun ronéo n'imprime la question : la clé est déduite
du cours.

## Le sujet 2025/2026 (18/10/2026)

Le sujet de virologie de l'examen du 08/01/2026 (cahier de 30 QCM,
`src-sujet-viro-2526`, sans corrigé), déposé le 18/10/2026, apporte 1 question
à ce chapitre (Q.7) ; les autres questions vont aux chapitres de leur cours.
Aucune n'était déjà en cartes. Chaque clé est déduite du cours 2025-26,
l'année de l'examen, proposition par proposition et page à l'appui
(`officielle=False`) ; les propositions déjà posées d'autres années ont servi
de contre-épreuve, et l'explication dit chaque reprise. Rédigées et
contre-vérifiées le 18/10/2026 : un rédacteur, un sceptique qui a refait
chaque clé sur le cours, un critique de complétude. Le profil des clés — A
souvent vraie, trois ou quatre vraies par question — est celui des sessions 1
officielles du Pr Hober (2021/2022 S1, 2023/2024 S1).

| Question | Clé imprimée | Retenue | Lecture |
|---|---|---|---|
| 2025/2026 Q.7 (`hot-an-2526-q7`) | aucune (sujet sans corrigé) | **ACD** | Le devenir de l'infection et ce qui le règle : latence des Herpesviridae, infection aiguë des Picornaviridae, virulence (VIH-2, gènes d'origine cellulaire) ; et l'IFN α, qui agit sur les cellules et non sur les virus. |

Ce qui est signalé :

- Q.7 B : le poliovirus persiste chez certains (syndrome post-polio, FC n°2, p.
  16) ; la clé (faux) vise la règle, que la justification dit avec son
  exception. La phrase du ronéo sur le VIH-2 qui « ne se transmet pas de la
  mère à l'enfant » (FC n°2, p. 17, déjà signalée dans `viro_multiplication`)
  n'est pas reprise.
- Aucune coquille imprimée.

## Les clés qui ne sont pas reprises telles quelles

Les deux clés imprimées sont justes et reprises (`CONFLITS = []`). Une clé est
déduite, faute de corrigé :

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| `hot-an-2425-q2` (2024/2025 Q2) | aucune (sujet sans corrigé) | BCE | la peau saine est une barrière que les virus ne franchissent pas (FC n°2, p. 7) ; la mutation homozygote de CCR5 protège du VIH (p. 18) ; les signes viennent aussi des réponses de l'hôte (FC n°3, p. 3) ; les anticorps, tardifs, comptent peu dans la primo-infection (p. 6). Aucune proposition douteuse ; `officielle=False` |

## Le schéma cliquable

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `hot-genome-vih-nu.svg` (`hot-zo-genome-vih`) | les deux LTR, gag, pol, env, vif, vpr, tat, rev, vpu, nef | 11 |

Redessiné d'après la diapositive p. 2 (VIH-1) : trois rangées de cadres de
lecture, les gènes de structure en rose, les petits gènes en couleur, un LTR à
chaque extrémité. On ne demande pas le nom du gène mais sa fonction (« le
gène de la protéine qui entraîne APOBEC3G vers la dégradation »), ce que le
plan proposait (« où est codée la transcriptase inverse, la gp120, la protéine
qui détourne APOBEC3G ? »). tat et rev sont en deux exons : seul le premier
porte la zone, le second est estompé (la règle des organes pairs). La version
légendée, `hot-genome-vih.svg`, tirée des mêmes constantes, est en
correction ; chaque zone a sa phrase, qui cite la FC n°3 p. 2 et la FC n°8
p. 15. Pas de planche à légender : la figure du glissement et de la cassure
(p. 9) est légendée en anglais, un texte à trous la remplace (plan C16).

## Le lexique

Huit termes, pages mesurées dans le texte des FC (pymupdf, même règle que
`chercher_pages.py` : mot entier, pluriel permis, accents ignorés) :

| Terme | Pages |
|---|---|
| Interféron (`lex-interferon-viro`) | FC n°3 p. 3, 4, 10 ; FC n°9 p. 9, 11, 12, 13 |
| Séroprophylaxie | FC n°3 p. 3, 6 ; FC n°9 p. 13 |
| Immunopathologie | FC n°3 p. 3, 7 |
| Mimétisme moléculaire | FC n°3 p. 7 |
| Glissement antigénique | FC n°3 p. 8, 9 ; FC n°6 p. 3 |
| Cassure antigénique | FC n°3 p. 8, 9 ; FC n°6 p. 3, 4 |
| Réassortiment | FC n°3 p. 9 ; FC n°6 p. 3 |
| Viroceptor | FC n°3 p. 10 ; FC n°2 p. 17, 18 |

« Interféron » est déjà le terme `lex-interferon` d'`immuno_infectieux` (UE
Immunologie) : il est repris ici sous un identifiant propre, l'identifiant
d'une note étant global, avec la même étymologie. « Latence » est accueillie
par `viro_multiplication`. Chaque définition finit par son étymologie, et
chaque racine par la sienne ; les racines enseignées par les FC de sémantique
citent leur page (`-pathie`, `-logie`, `-gène`, `pro-`, `-phylaxie`). Les
entrées nouvelles — huit termes, cinq racines (`glisser (français)`,
`moles (latin)`, `quassare (latin)`, `sors (latin)`, `recipere (latin)`) et
`virus (latin)`, la même que celle que propose `viro_multiplication` — sont
proposées dans `scratchpad/etym/viro_virus_hote.json`, au format
d'`etymologies.json`, qui n'est pas modifié ; vérifié : une fois la
proposition versée, `appliquer_etymologies.py` ne changerait aucun texte.

## À relire

Aucune carte `a-relire` : chacune a été relue contre sa page de la FC n°3.

## Questions pour Vincent

1. **La chronicité du VHB de l'adulte** : 5 à 10 % (FC n°2, FC n°3) ou 10 à
   20 % (FC n°8, FC n°10 partie 2) ? Le plan propose de ne pas trancher, de le
   dire dans la carte et d'accepter les deux, comme les annales : c'est ce que
   fait `hot-fa-tolerance`, qui écrit les deux fourchettes sans les trouer.
   Faut-il attendre le ronéo 2026-27 pour fixer un chiffre ?
2. **Le VRS « virus constant »** : la carte `hot-qc-apparence` C répond comme
   le professeur (vrai) et donne la référence (réinfections fréquentes). Le
   garder ainsi, ou le passer en « point douteux » si le cours 2026-27 ne le
   redit pas ?
3. **Cinq libellés de thèmes** à verser dans `THEME_LABELS` (liste plus haut),
   dont les deux clés renommées à la relecture (`immunopathologie-virale`,
   `echappement-viral`, au lieu des clés génériques du plan) : les garder
   ainsi ?
4. `contenu/COUVERTURE.md` et le `CHANGELOG.md` ne sont pas mis à jour par
   cette tâche (une des dix de la vague) : à faire avec la vague.
5. Le PDF de la FC n°3 reste à copier dans le dossier des PDF de
   l'application (`outils/copier_les_cours.py`, hors du bac à sable) pour que
   le lecteur l'ouvre.

## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier. Sous les annales, 15 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 4 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `resistance-hote` | 11 | 3 | 3 |
| `echappement-viral` | 4 | 1 | 1 |

**Le schéma** `ech-virus-hote`, « Le virus face aux défenses · barrières, cellule, issue », donne 24 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_VIRUS_HOTE`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Source déclarée en plus** : `src-fc-viro-fc2`, à l'identique de `viro_multiplication`, pour `hot-ech-s1` à `hot-ech-s5` et `hot-ech-m4`.

## Régénérer

```powershell
cd contenu\chapitres\viro_virus_hote
..\..\..\app\.venv\Scripts\python.exe generer.py
```

`generer.py` est la copie exacte de
`.claude/skills/nouveau-chapitre/scripts/generer_modele.py`.
