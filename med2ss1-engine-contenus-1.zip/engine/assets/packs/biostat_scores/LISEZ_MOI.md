# Scores cliniques — paquet Biomédecine quantitative

82 notes, 136 cartes. Chapitre `chap-ue-biomed-quanti-fc5` de l'UE
Biomédecine quantitative, premier de l'UE. Cours du **Pr S. Leteurtre et du
Pr G. Ficheur, le 08/10/2025, de 8 h à 10 h**, dans le **Ronéosaure 2025-26**
(FC n°1, 18 pages) ; les annales de cinq polycopiés du Ronéosaure 2024-25
(26 questions, 13 sessions). Examen : partiel du mercredi 16 décembre 2026.

**Fiche provisoire** (C15, décision de Vincent du 02/10) : le cours de l'année
2026-27 n'est pas encore paru. Chaque carte de cours cite la FC 2025-26 à sa
page et porte le badge « Cours 2025-26 » ; le ronéo 2026-27 corrigera les cartes
quand il sortira. `donnees.py` porte `ANNEE_COURS = "2025-26"`. Aucune carte ne
dit « Absent du cours 2026-27 », et les erreurs du Ronéosaure sont dites par un
ATTENTION sans genre : la liste des erreurs de la promo,
`contenu/ERRATA_RONEOS_2026-27.md`, ne concerne que les ronéos 2026-27.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 47 | 47 |
| QRU | 2 | 2 |
| Texte à trous | 9 | 60 |
| QROC | 9 | 9 |
| Recto-verso | 5 | 5 |
| Schéma cliquable | 1 | 4 |
| Planche à légender | 1 | 1 |
| Lexique | 8 | 8 |

Dont **26 annales** sur 13 sessions (2017/2018 S1 à 2023/2024 S2) : 18 du
polycopié « 5. Scores cliniques » (toutes), 5 du polycopié « 14 - Analyses de
survie », une de chacun des polycopiés « 2. Régression linéaire »,
« 6. Tests diagnostiques » et « 13 - Régression logistique ». Les 23 autres QCM
sont des questions de cours.

Huit thèmes, dans l'ordre du cours (plan C15). `variables` et `tests` existent
déjà (ECL Remédiation) ; les six autres restent à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) :

| Clé | Libellé | Notes |
|---|---|---|
| `scores-definition` | Scores : définition et exemples | 14 |
| `usage-scores` | Scores de gravité et performance des services | 18 |
| `variables` *(existante)* | Types de variables | 2 |
| `statut-variables` | Variable explicative, variable à expliquer | 4 |
| `tests` *(existante)* | Tests statistiques | 11 |
| `multivarie` | Analyses multivariées | 10 |
| `construction-score` | Construire un score | 4 |
| `validation-score` | Valider un score : discrimination et calibration | 11 |

`multivarie` est partagée avec la régression logistique et les analyses de
survie, où son libellé dit vrai aussi.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-biomed-scr-2526` — Ronéosaure, « FC n°1 - Scores cliniques » (18 p.) | 2025-26 | le cours ; `SRC["fiche"]`, ses 23 figures ; fiche provisoire en attendant le ronéo 2026-27 |
| `src-annales-5-scores-cliniques` — « 5. Scores cliniques » (8 p.) | 2024-25 | 18 QCM, 10 sessions, table p. 8 ; `SRC["annales"]` |
| `src-annales-6-tests-diagnostiques` — « 6. Tests diagnostiques » | 2024-25 | la 2017/2018 S1 QCM n° 10 (validation d'un score) |
| `src-annales-2-regression-lineaire` — « 2. Régression linéaire » | 2024-25 | la 2023/2024 Q22 (méthodes d'analyse multivariée) |
| `src-annales-13-regression-logistique` — « 13 - Régression logistique » | 2024-25 | la 2020/2021 S2 Q32 |
| `src-annales-14-analyses-de-survie` — « 14 - Analyses de survie » | 2024-25 | cinq questions sur les méthodes d'analyse multivariée |

Les polycopiés n° 2 et 6 sont déclarés à l'identique de
`biostat_regression_lineaire` et `biostat_tests_diagnostiques` ; les n° 5, 13
et 14 dans la forme commune de C15 (id tiré du nom du fichier, titre, chemin,
auteur, rien d'autre) — les chapitres de régression logistique et d'analyses de
survie déclarent les n° 13 et 14 mot pour mot pareil (vérifié).

**Le modèle de générateur ne connaît qu'une source d'annales par session.** Trois
sessions ne viennent que d'un autre polycopié et le citent (`SRC["sessions"]` :
2017/2018 S1 → tests diagnostiques ; 2022/2023 S2 et 2023/2024 S2 → analyses de
survie). Les cinq questions d'un autre polycopié posées à une session du
polycopié des scores (2023/2024 S1 Q22, 2021/2022 S2 Q20, 2020/2021 S1 Q32,
2020/2021 S2 Q32, 2019/2020 S2 Q24) citent le polycopié des scores ; leur puce
(« Annales 2020/2021 S1 · Q32 ») reste juste, et leur explication finit par
le nom de leur vrai polycopié (voir les questions pour Vincent).

Lus en appoint, sans être déclarés : le cours 2024-25 des scores (FC n°5, Pr
Ficheur), pour comprendre une annale (« explicatif », p. 3 ; le SMR, p. 22 ; la
validation externe « à une autre période », p. 20) ; la FC n°8 2025-26 (p. 4,
le Student « cas particulier de la régression linéaire multiple ») et la FC n°7
2025-26 (p. 3, les variables qualitatives en effectifs et pourcentages), citées
dans le texte des cartes ; l'errata des cours 2025-26 (trois entrées pour cette
FC) et celui des annales 2024-25 (une entrée).

Les pages citées sont celles du PDF ; la p. 1 est la page de garde et le plan.
Les en-têtes des ronéos, des erratas et des polycopiés portent des noms
d'étudiants : aucun n'est repris. Les polycopiés de régression logistique et
d'analyses de survie attribuent leurs annales au « Pr Décaudin » :
l'attribution n'est pas reprise.

## Ce que le cours a dicté

- **Le rouge** est celui des titres et de « examen +++ » (II, les variables, et
  II.B, leur statut) : le type et le statut des variables ont leurs cartes
  (`scr-qc-types-variables`, `scr-fa-types-variables`, `scr-qc-statut`,
  `scr-rv-type-statut`), et le tableau des croisements son schéma cliquable.
- **Le gris** est la voix des rédacteurs : les trois typologies d'études (p. 2),
  « vu en 1re année » (p. 6), la formule des effectifs théoriques (p. 7),
  l'homogénéité des variances, « notion passée par le prof » (p. 8), « notion
  abordée dans un cours spécifique » (p. 10). Il se carte comme le reste
  (décision du 25/09) : la formule, complétée par l'errata, est dans
  `scr-fa-khi2` ; l'homogénéité des variances n'est citée qu'en justification
  (`scr-qc-student` B, `scr-fa-student`), jamais interrogée seule. Les trois
  typologies d'études de la p. 2 (statistique descriptive et tests
  diagnostiques ; évaluation d'un médicament ; épidémiologie) n'ont pas de
  carte ici : c'est le survol de l'UE par lequel le professeur ouvre son cours,
  aucun thème de ce chapitre ne dit vrai pour elles, et chacune a son chapitre
  (analyse descriptive et tests diagnostiques, phases I à III, pharmacovigilance).
  « Notion vue en 1re année » (p. 6) et « abordée dans un cours spécifique »
  (p. 10) sont des remarques, sans contenu à carter.
- **Ce que le professeur a dit de ne pas retenir** : l'analyse « pas à pas »
  (p. 12). Aucune carte ne la demande ; elle n'est qu'un intrus de la planche.
- **Ce qui n'est pas carté ici** (plan C15) : le détail des types de variables
  (continue, discrète, Likert : `biostat_analyse_descriptive`) ; la régression
  linéaire (`biostat_regression_lineaire`) et la régression logistique
  (`biostat_regression_logistique`) — ici, les trois familles et la raison du
  modèle logistique ; la courbe ROC pour elle-même (`biostat_tests_diagnostiques`)
  — ici, la discrimination d'un score ; les « modèles multivariés » des annales
  (ajustement, p > 0,05, l'âge quantitatif ou qualitatif), cartés avec la
  régression logistique.

## Les erreurs du Ronéosaure 2025-26

Le Ronéosaure n'est pas le ronéo de l'année : chaque erreur est portée par un
**ATTENTION nu** dans la carte qui tient la notion, la sorte dite dans le texte,
et rien n'entre dans `contenu/ERRATA_RONEOS_2026-27.md`.

| Page | Le ronéo dit | Retenu | Sorte | Carte |
|---|---|---|---|---|
| 2 | « le coma n'est pas une binaire » | « pas une variable binaire » (errata des cours 2025-26) | prise de notes | `scr-qc-glasgow` B |
| 7 | la formule des effectifs théoriques, en mots seulement (gris) | effectif théorique = total ligne × total colonne / effectif total (errata 2025-26, image) | ajout de l'errata | `scr-fa-khi2` |
| 7 | « 1er cas : p-valeur > 5 % (0,05) : la variable est laissée de côté » | au-delà de 0,20 ; le 2e cas de la même page garde 0,05 < p < 0,20 | prise de notes (trouvée en relisant) | `scr-qc-seuil-bivarie` A |
| 7 | « test du Khi² : test paramétrique » | on le range souvent parmi les tests non paramétriques | point douteux | sans carte : aucune proposition n'en dépend |
| 9 | « Y Décès ~ X1 PAS + X2 PAS » | X2 = PAD (la ligne d'avant ; p. 5) | prise de notes | `scr-qc-multivariee` C |
| 9-10 | la pente et l'ordonnée à l'origine : « pente a, ordonnée b » en régression linéaire (corrigé par l'errata), « pente b, ordonnée a » en régression logistique | les lettres changent d'une diapositive à l'autre | à dire | aucune carte ne demande la lettre ; l'explication de `scr-qc-familles` le dit |
| 10 | « on modélise le logarithme du rapport des probabilités → 1/1-P » | logit = log[P / (1 − P)] (diapositive de la même page) | prise de notes | `scr-qc-familles` E |
| 16 | « la probabilité de mortalité est donc de 70 % durant les 12 h suivant l'admission » | 12 h est le délai de calcul du PRISM ; la probabilité prédite est celle du décès pendant le séjour, confrontée à la sortie (même page : la « vraie valeur » s'enregistre à la fin de l'hospitalisation ; cours 2024-25, p. 21) | prise de notes (trouvée à la relecture) | `scr-qc-individuel` B |
| 17 | « que ce soit avant ajustement ou avec ajustement, le SMR du service se situe dans l'intervalle de confiance [0,88 ; 1,09] » | avant : 0,66 [0,46 ; 0,88] (diapositive p. 16 ; cours 2024-25, p. 22) ; après recalibrage : 0,91 [0,88 ; 1,09] (diapositive p. 17) | prise de notes (trouvée en relisant) | `scr-qc-smr` C |
| 18 | « TAMOF : thrombocytémie associée à une défaillance multiviscérale » | thrombopénie (« thrombocytopenia-associated multiple organ failure », titre de la diapositive) | prise de notes | `scr-qc-etudes` E |

Trois de ces erreurs ne sont pas dans le plan C15 (« trouvée en relisant », « à
la relecture ») : le premier cas de la p. 7, que la page contredit elle-même ;
les « 12 h » de la p. 16, que la même page dément ; l'intervalle de confiance
du SMR p. 17, que les deux diapositives démentent.

Une phrase ambiguë, sans erreur avérée : le PIM3 « vise à donner la probabilité
de décès de l'enfant dans la 1ère heure suivant l'admission » (p. 15). La carte
`scr-qc-individuel` (E) la tourne sans ambiguïté — « le PIM3 se calcule plus tôt
que le PRISM, sur la 1re heure suivant l'admission » (« mechanical ventilation
in the first hour », diapositive p. 15) — et sa justification précise qu'il
prédit le décès en réanimation, pas un décès dans l'heure.

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| La définition d'un score : plusieurs paramètres faciles à obtenir, un poids chacun, simple et explicatif | 7 : clé AE en 2023/2024 S1 Q20, 2022/2023 S1 Q12, 2021/2022 S2 Q16, 2020/2021 S1 Q13 et S2 Q12, 2019/2020 S2 Q20 (clé imprimée ABD, corrigée) ; variante ACD en 2018/2019 S2 Q20 |
| Les scores en réanimation : dysfonctions d'organes répétées, comparaison admission-sortie, scores spécifiques | 8 : clé AD sept fois (2023/2024 S1 Q21 à 2018/2019 S2 Q21) ; 2018/2019 S1 Q35 (prédire, objectiver, recalibrer : ACE) |
| Les méthodes d'analyse multivariée : simultanément, une variable à expliquer, trois familles, pas le Student | 7 : 2023/2024 S1 Q22 (clé corrigée) et S2 Q26, 2022/2023 S2 Q16, 2021/2022 S2 Q20, 2020/2021 S1 et S2 Q32, 2019/2020 S2 Q24 |
| La validation : discrimination (AUC > 0,8), calibration (non significative), validation externe | 2 : 2021/2022 S1 Q6, 2017/2018 S1 Q10 |
| Le statut et le type des variables, le test qui va avec | 2 : 2021/2022 S1 Q7, 2019/2020 S1 Q11 |

Chaque session a sa carte, et l'explication renvoie aux autres. Les énoncés sont
recopiés tels qu'imprimés, coquilles comprises (« l'ensembles », « pas de score
de gravité spécifiques »), apostrophes typographiques remplacées par des
droites.

## Le schéma cliquable et la planche

**Un schéma cliquable** (`schemas.py`), avec sa version légendée en correction :

| Fichier | Ce qu'on clique | Pourquoi ce dessin |
|---|---|---|
| `tests-croisements.svg` | les quatre cases du tableau des croisements : Khi², Student ou Mann-Whitney (deux cases, nommées par ce qu'elles comparent), test de nullité du coefficient de corrélation — 4 zones | le tableau de la p. 8, que les annales interrogent (2019/2020 S1 Q11 : Khi² pour les nausées-vomissements, Student pour l'IMC) ; les en-têtes restent écrits comme sur la diapositive, les cases sont vides : savoir quel test va avec quel croisement est toute la question |

**Une planche à légender**, `scr-pl-construction` (`planche_depuis_image.py`) :
la diapositive « Construction d'un score : les différentes étapes » (p. 11),
ses sept étapes effacées dans leurs cadres (analyses bivariées, sélection avec
accord des experts, analyses multivariées, simplification, mode de calcul,
validité interne, validité externe) ; quatre intrus du plan (validation
croisée, analyse pas à pas, calibration, randomisation). L'image numérotée a
été regardée : les cadres sont vides, aucun reste de lettre, la flèche
« processus réitéré si performances faibles » reste visible.

**Vingt-trois figures de la FC 2025-26**, extraites en PNG (captures de
diapositives), en 256 couleurs ; la figure du score d'appendicite est rognée de
24 px à gauche, où débordaient des lettres du texte du ronéo. **49 QCM sur 49
illustrés**, 70 notes sur 82.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2019/2020 S2 Q20 | ABD | AE (`officielle=False`, CONFLITS B, D, E) | l'errata des annales 2024-25 : « AE et non ABD (cf moodle) » ; ABD est la clé de la Q11 voisine de la table, et la question est mot pour mot celle de cinq autres sessions, toutes AE ; la variante de 2018/2019 S2 (ACD) compte aussi « simple et explicatif » vrai |
| 2023/2024 Q22 (polycopié de régression linéaire, recopié dans celui de survie) | ACDE | ACD (`officielle=False`, CONFLITS E) | elle compterait « le test t de Student est un type d'analyse multivariée » vrai ; la 2020/2021 S1 et S2 (Q32 D) le comptent faux, le cours le range parmi les analyses bivariées (p. 8), et la FC n°8 en fait un cas particulier de la régression linéaire « quand il n'y a qu'une seule variable » (p. 4) |

Les autres anomalies, sans effet sur les clés : la 2019/2020 Q11 imprimée sous
« session 2 » et rangée en S1 par la table ; la 2023/2024 S2 Q26 imprimée sous
« 2022/2023 ( Session 1 ) » dans le polycopié de survie et rangée en 2023/2024 S2
par sa table ; la 2023/2024 Q22 sans session dans le polycopié de régression
linéaire, rangée en S1 comme dans celui de survie ; les colonnes « 2018/2019 »
du polycopié de survie, recopie des 2020/2021, sans énoncés (rien à carter).
Chaque explication le dit.

**Les doublons** (une seule carte) : la 2023/2024 S1 Q22 du polycopié de survie
(celle du polycopié de régression linéaire) et sa 2020/2021 S2 Q32 (celle du
polycopié de régression logistique).

## Le lexique

Huit termes, ceux du plan C15 ; aucun n'existait (vérifié contre les `lex-*`
de tous les paquets). Pages mesurées dans le texte de la FC 2025-26 (PyMuPDF,
même règle que `chercher_pages.py` : mot entier, pluriel permis, accents
ignorés), page de plan exclue :

| Terme | Origine | Pages |
|---|---|---|
| Pronostic | grec προγνωστικόν, par le latin prognosticum | 3 |
| Calibration | origine incertaine (calibre : italien calibro, arabe qālib, peut-être du grec καλαπούς) | 13, 14 |
| Discrimination | latin discriminatio (discrimen, discernere) | 14 |
| Bivarié | formé sur le latin bis + variare | 5, 6, 9, 12 |
| Multivarié | formé sur le latin multus + variare | 5-10, 12 |
| Dysfonction | formé sur le grec δυσ- et le latin functio | 3, 15, 18 |
| Appendicite | formé sur le latin appendix et le grec -ῖτις | 2-4, 15, 16, 18 |
| Coma | grec κῶμα | 2, 3 |

Les racines nouvelles (`pro- (grec)`, `-gnose`, `dis- (latin)`,
`cernere (latin)`, `multi- (latin)`, `functio (latin)`, `appendix (latin)`,
`coma (grec)`) et les huit termes sont proposés à la table commune
(`etymologies.json`, proposition dans le brouillon `etym/biostat_scores.json`),
vérifiés sur le Wiktionnaire (qui cite le Gaffiot pour le latin) et renvoyant au
Bailly et au Gaffiot ; les textes du lexique sont déjà écrits dans la forme que
`appliquer_etymologies.py` produirait. `bi- (latin)`, `variare (latin)`,
`dys-` et `-ite` reprennent les clés existantes ; `multi- (latin)` et
`dis- (latin)` reprennent l'étymon que proposent `biostat_phase_3`,
`biostat_irm_prostate` et `biostat_phase_4_eim`. `pro- (grec)`, `dis- (latin)`
et `dys-` citent la FC de sémantique (2/2, p. 10, p. 4 et p. 6) : elle les
enseigne (prophylaxie ; dissection, l'écartement ; dyspnée). « Calibration » n'a ni étymon grec ni
étymon latin assuré : il est proposé « à vérifier », comme `lex-matite`, et sa
définition dit « Origine incertaine ». D'autres chapitres proposent
`pro- (latin)` (proportion, prospectif) : le pro- de pronostic est grec, d'où
une clé distincte.

## Questions pour Vincent

1. **La source des annales d'un second polycopié** : le modèle de générateur ne
   connaît qu'une source par session, si bien que cinq annales (polycopiés de
   régression linéaire, de régression logistique et de survie) citent le
   polycopié des scores ; leur explication nomme le vrai. Une clé `source=`
   par question, dans le modèle, le réglerait (même question que les
   dispositifs médicaux).
2. **Trois erreurs du ronéo hors du plan** : le « 1er cas » de la p. 7, les
   « 70 % durant les 12 h » de la p. 16 et l'intervalle de confiance du SMR
   p. 17, classées « prise de notes » parce que la même page (p. 7, p. 16) et
   les diapositives (p. 16-17) disent juste. À confirmer sur le ronéo 2026-27.
3. **« Calibration », d'origine incertaine** : le garder au lexique (plan C15,
   appliqué ici), avec « Origine incertaine », ou le remplacer par un terme
   d'origine grecque ou latine assurée ?
4. **Le point douteux de la p. 7** (« test du Khi² : test paramétrique ») :
   signalé ici, sans carte (plan C15) ; à trancher sur le ronéo 2026-27.

## À relire

**Aucune carte `a-relire`** : chaque carte cite une page de la FC 2025-26, et
chaque clé d'annale a été vérifiée proposition par proposition contre son
énoncé et sa table (relue en image : p. 8 du polycopié des scores, p. 13 de
celui de survie, la table du polycopié de régression linéaire et celle des
tests diagnostiques).

Relecture contradictoire (02/10) : chaque carte relue sur sa page de la FC, les
26 clés sur les tables, l'errata des annales et les cours ; les 23 figures
regardées (bonne page, côté réponse, aucun nom d'étudiant) ; le schéma rendu
zones superposées. Corrigé : les justifications en conflit commencent par
l'ATTENTION (2019/2020 S2 Q20 B, D, E ; 2023/2024 S1 Q22 E) ; « clé constante
sur sept sessions » précisé (la 2019/2020 S2 l'est par l'errata) ; la
proposition E de `scr-qc-individuel` sur le PIM3, ambiguë, reformulée ; la
2017/2018 S1 numérotée « QCM n° 10 » comme le polycopié et le chapitre des
tests diagnostiques.

Reste à Vincent :

- quand le ronéo 2026-27 paraîtra, relire chaque carte sur lui et retirer le
  badge « Cours 2025-26 » ;
- `copier_les_cours.py` avec le dossier `…/S1 25-26/examen décembre` du
  Ronéosaure 2025-26, hors du bac à sable, pour que la fiche s'ouvre dans
  l'application ;
- les six libellés de thème à ajouter à `THEME_LABELS`.

## L'échelle : Simple → Moyen → Annale (C20, 18/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 16 décembre. Sous les annales, 32 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 6 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `scores-definition` | 6 | 1 | 7 |
| `usage-scores` | 8 | 2 | 8 |
| `statut-variables` | 6 | 1 | 2 |
| `multivarie` | 5 | 1 | 7 |
| `validation-score` | 7 | 1 | 2 |

**Le schéma** `ech-score`, « Le score clinique · construire, valider, utiliser », donne 65 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_SCORE`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```

La planche numérotée se refait depuis `app/` (Pillow n'est pas une dépendance
du projet) :

```powershell
uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/biostat_scores scr-pl-construction --apercus <brouillon>
```
