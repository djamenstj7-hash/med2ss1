# Définition du parasitisme, classification des parasites d'intérêt médical — paquet Parasitologie et mycologie

76 notes, 134 cartes. Chapitre `chap-ue-parasito-fc1` de l'UE Parasitologie et
mycologie (`ue-parasito`), ordre 1. Cours du **Pr Sendid, le 21/10/2025**
(10 h-11 h, semaine 7), FC n°1 du Ronéosaure 2025-26 (10 pages) ; une annale
du polycopié n°1 du Ronéosaure 2024-25 et une du sujet 2024/2025 de l'UE.
Examen du 5 janvier 2027.

**Une fiche provisoire.** Le ronéo 2026-27 de ce cours n'est pas paru (rien en
parasitologie dans les dépôts d'`Ajouts/` au 05/10/2026) : le chapitre est
carté sur le Ronéosaure 2025-26 (décision de Vincent du 02/10), et le ronéo de
l'année corrigera les cartes à sa parution. La source porte son année dans son
auteur (« Ronéosaure 2025-26 ») : chaque carte de cours prend le tag
`cours-2025-26` et le badge « Cours 2025-26 ». Aucune carte ne dit « Absent du
cours 2026-27 », et les erreurs du Ronéosaure sont dites par un ATTENTION sans
genre (précédent d'`immuno_cmh` et d'`immuno_innee`) : la liste des erreurs de
la promo, `contenu/ERRATA_RONEOS_2026-27.md`, ne concerne que les ronéos
2026-27.

**Le brouillon du 03/10.** Une exécution interrompue avait laissé
`schemas.py` et seize figures dans `media/`. Tout a été relu : les figures
sont les bonnes, à leur page ; dans `schemas.py`, la seconde liste de l'arbre
plaçait les leishmanies chez les flagellés, ce que la FC n°1 ne dit pas — elle
a été refaite sur les parasites du plan (Toxoplasma, Enterobius, Schistosoma,
T. solium), une troisième liste ajoutée (Cryptosporidium, Strongyloides), et
les signes et deux légendes du schéma des niveaux, qui se chevauchaient,
remis en place.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 33 | 33 |
| QRU | 1 | 1 |
| Texte à trous | 11 | 55 |
| QROC | 10 | 10 |
| Recto-verso | 7 | 7 |
| Schéma cliquable | 4 | 18 |
| Lexique | 10 | 10 |

Dont **2 annales** (2019/2020 S2 Q1 et 2024/2025 S1 5), QRM, clés déduites). Le chapitre est un chapitre de
cours, comme le prévoyait le plan C16 : 31 QRM et 1 QRU de cours, chacun avec
une justification par proposition.

Six thèmes, dans l'ordre du cours :

| Clé | Libellé |
|---|---|
| `agents-infectieux` | Le monde des agents infectieux |
| `niveaux-parasitisme` | Parasitisme, commensalisme, symbiose |
| `classification-parasites` | Classification des parasites |
| `stades-evolution` | Stades évolutifs des parasites |
| `cycle-parasitaire` | Cycle parasitaire et hôtes (partagé dans l'UE : FC n°4, n°6) |
| `diagnostic-biologique` | Diagnostic biologique (partagé dans l'UE) |

Les six libellés sont à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) : le seul test rouge du chapitre
est celui-là (`test_tout_theme_du_paquet_a_son_libelle`). Les clés `diagnostic`
(semio_thanato) et `clinique` (sang_anemies) ne sont pas réemployées.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-parasito-parasitisme` — Ronéosaure, « FC n°1 parasitologie et mycologie.pdf » (10 p.), `PARASITO-MYCOLOGIE/…` | **2025-26** | **la base** : chaque note de cours porte sa page ; c'est ce que le lecteur ouvre (`chapitre=`) ; le nom de fichier ne dit pas le titre, `titre` le dit |
| `src-annales-1-definition-du-parasitisme-classification-des-pathogenes-d-interet-medical` — Ronéosaure, polycopié « 1 - Définition du parasitisme, classification des pathogènes d_intérêt médical » (3 p.) | 2024-25 | l'annale, sans clé dans la table (p. 3) |
| FC n°3, n°5 et n°6 2025-26 (parasitoses autochtones, exotiques, toxoplasmose) | 2025-26 | citées dans le texte, à la page, sans être déclarées : ce sont les fiches d'autres chapitres |
| `src-cours-parasito-parasitisme-2425` — Ronéosaure 2024-25, « FC n°1 - Définition du parasitisme… » (11 p., Pr Sendid), `S1/COURS/COURS exam janvier/Parasitologie & Mycologie/…` | 2024-25 | appoint, déclaré sans `chapitre` : les diapositives des cycles d'Enterobius, de Trichuris (p. 9), de Taenia et de Loa loa (p. 10), les mêmes que celles de la fiche 2025-26 mais nettes ; la légende « pas d'auto infestation » de Trichuris, illisible en 2025-26 ; le cycle de la douve (p. 11), qui confirme le mollusque obligatoire |
| erratas : cours 2025-26 (`Erratas de Parasitologie mycologie.docx`), annales 2024-25 | — | une entrée sur la FC n°1 (l'examen des selles, p. 10), reprise et contredite ; l'errata des annales est vide |
| `src-sujets-parasito-2425` — sujets de parasitologie-mycologie 2024/2025, session 1 (examen du 10/01/2025, 14 p.), sans chemin | 2024-25 | 2024/2025 S1 Q5, par `SRC["sessions"]` ; **aucun corrigé**, clé déduite du cours ; déclaration commune aux dix chapitres de l'UE, champ pour champ |

**La déclaration du polycopié n°1 est partagée** avec les chapitres des FC n°3
et n°4, qui en prennent sept et deux questions : elle suit la règle commune
(identifiant `src-annales-<nom du fichier>`, ces cinq champs et aucun autre,
le titre étant le nom du fichier sans extension, espace finale comprise).

Vérifications hors du cours, citées dans la carte qui s'en sert : CDC DPDx
(Fascioliasis, Schistosomiasis, Loiasis, Trichuriasis) ; l'étymologie (TLFi,
Bailly, Gaffiot, Wiktionnaire).

## Ce que le cours a dicté

- **Une consigne** : « le prof insiste sur le fait de ne pas confondre
  helminthes et protozoaires ! » (p. 7). Elle est portée des deux côtés sur
  `par-qc-helminthe-ou-protozoaire` : en `indispensables` (A, C, E : oublier
  un helminthe annule la question), comme le voulait le plan C16 (§0.4), et en
  `inacceptables` (B, D : cocher Giardia ou Plasmodium comme helminthe
  l'annule aussi) ; et par les trois cartes de l'arbre. Une autre
  insistance du cours, « l'Homme n'est pas toujours l'hôte définitif ! »
  (p. 9), est portée en `inacceptables` sur `par-qc-acteurs` B (cocher
  « l'Homme est toujours l'hôte définitif » annule la question).
- **Le gris** n'est que celui des titres et d'une précision des rédacteurs
  (« pour le taenia solium, l'hôte intermédiaire sera le porcin (non précisé
  par le prof) », p. 8) : carté, et dit tel quel. Pas de rouge.
- **Le partage avec les autres chapitres** (plan C16, §2) : ici les notions
  générales et les sept cycles exemples au niveau « type de cycle et hôtes ».
  La clinique et le diagnostic de l'oxyurose et du téniasis sont en FC n°3,
  ceux de l'amoebose et des schistosomoses en FC n°5, la toxoplasmose en FC
  n°6, le paludisme en FC n°4 ; les cartes y renvoient sans les reprendre. Le
  diagnostic de la p. 10 tient en un QCM, un texte à trous et une QROC.
- **Pas de carte** pour l'illustration de jeu vidéo de la p. 10, ni pour le
  détail du tableau de la p. 4 (hôtes du schistosome), repris par les cycles,
  ni pour la cascade règne, embranchement, classe, ordre, famille de la p. 6 :
  « cette année, on ne prendra en compte que genre et espèce ». Le texte à
  trous de la nomenclature ne troue que le genre, l'espèce et « sp. » ; la
  cascade reste en figure de correction.

## Les erreurs du Ronéosaure 2025-26

Chacune est dite par **ATTENTION**, sans genre, dans la carte qui porte la
notion.

| Page | Ce que dit le Ronéosaure | Ce qui est juste | Carte |
|---|---|---|---|
| 10 | l'examen parasitologique des selles « à 3 reprises, espacé de 3 semaines » ; l'errata de la promo propose « 2 semaines », sans avis du bureau | 3 fois, sur un intervalle de 7 à 10 jours, jamais 3 jours de suite — FC n°5 2025-26, p. 4 et 12 (diapositive ✪) ; FC n°3 2025-26, p. 7 ; corrigé de l'annale 2022/2023 S1 QROC 2 | `par-qc-diagnostic` B, `par-fa-diagnostic` |
| 9 | Fasciola : les œufs « ingérés par les bovins », et le passage qui « parfois […] nécessite un autre hôte : un mollusque » | le mollusque (la limnée) est obligatoire ; herbivores et Homme mangent les métacercaires sur le cresson (CDC DPDx) ; le cours 2024-25 du même professeur le disait (p. 11) | `par-qc-fasciola` D |
| 4 | les œufs de schistosome « ingérés par des mollusques », puis éclos dans le mollusque | l'œuf éclot dans l'eau douce, le miracidium pénètre le mollusque — la p. 9 le dit juste (CDC DPDx) | `par-qc-schistosoma-stades` C |
| 9 | « La loa Loa est une microfilaire […] Elle peut passer sous la conjonctive » | la microfilaire circule dans le sang ; c'est le ver adulte qui passe sous la conjonctive (CDC DPDx) | `par-qc-loa-loa` C |

Sans ATTENTION, parce qu'aucune réponse n'en dépend, mais dits dans la carte
voisine : « le sarcome de la gale » (p. 2 : le sarcopte, `par-qc-groupes` D) ;
« Schistosoma Mansourni », « faucocercaire » (p. 4 : mansoni, furcocercaire) ;
« Spozoaires » (p. 7) ; « Entebovirus vermicularis » (p. 8 : Enterobius,
`par-qc-oxyure`) ; « Trichuris trichura » (p. 8) ; « embryophores de Toxocara
canis » (p. 6 : des œufs, `par-qc-toxocara`) ; « monoxème » sur les deux
diapositives de cycles directs (p. 7-8).

## Ce que les annales ont dicté

Une seule question du polycopié n°1 porte sur la FC n°1 : **2019/2020 S2 Q1**,
« laquelle (ou lesquelles) est (ou sont) responsable(s) de la présence d'œufs
dans les selles humaines ? » — l'oxyurose, la giardiose, la toxocarose, le
téniasis, la toxoplasmose. Elle demande de savoir quel parasite est un
helminthe adulte dans l'intestin de l'Homme, hôte définitif : c'est la FC n°1
(protozoaires et kystes, impasse de Toxocara, hôte définitif du toxoplasme).

Les dix autres questions du polycopié sont dans le chapitre de leur sujet
(docstring d'`annales.py`) : sept en FC n°3 (oxyurose, ténias), deux QROC de
paludisme en FC n°4.

Le sujet 2024/2025 en ajoute une : **2024/2025 S1 5)**, « certaines font l'objet
d'un cycle parasitaire qui n'impliquent pas d'autres hôtes que l'Homme » — les
schistosomoses, l'anguillulose, le paludisme, l'amoebose, le téniasis. C'est la
notion de cycle direct, monoxène (p. 8), appliquée aux parasites des FC n°4 et
n°5. L'énoncé imprime « n'impliquent » : coquille gardée.

## Les schémas cliquables

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `arbre-parasites-nu.svg` (`par-zo-arbre`) | la feuille d'Entamoeba histolytica, Giardia intestinalis, Balantidium coli, Plasmodium falciparum, Ascaris lumbricoides, Fasciola hepatica, Taenia saginata | 7 |
| `arbre-parasites-nu.svg` (`par-zo-arbre-bis`) | celle de Toxoplasma gondii, Enterobius vermicularis, Schistosoma mansoni, Taenia solium | 4 |
| `arbre-parasites-nu.svg` (`par-zo-arbre-ter`) | celle de Cryptosporidium, Strongyloides stercoralis | 2 |
| `niveaux-parasitisme-nus.svg` (`par-zo-niveaux`) | la case d'un arbre, d'Aspergillus sur un fruit gâté, de la flore cutanée, du microbiote intestinal, d'Entamoeba histolytica | 5 |

**L'arbre** redessine les tableaux des p. 6-7 : protozoaires (rhizoflagellés —
amibes, flagellés —, ciliés, sporozoaires) à gauche, helminthes
(némathelminthes, plathelminthes — trématodes, cestodes) à droite. Sans un
nom : chaque feuille porte la forme de son groupe (pseudopodes et hématies de
l'amibe, cerf-volant du flagellé, cils, hématie parasitée, ver rond, ver en
feuille, ver segmenté). Une feuille ne porte qu'une zone par carte, d'où trois
listes pour les onze parasites du plan et Balantidium (diapositive p. 7).
Strongyloides et le schistosome sont rangés d'après la FC n°5 2025-26 (p. 2).

**Les niveaux** : dans chaque case, l'être vivant étudié à gauche, ce dont il
vit à droite (rien, de la matière morte, un hôte), le sens des échanges et le
signe de ce que chacun y gagne — c'est la définition de chaque niveau (p. 5).

Les versions légendées, `arbre-parasites.svg` et `niveaux-parasitisme.svg`,
tirées des mêmes constantes, sont en correction. Les quatre SVG ont été rendus
et regardés.

**Illustrations** : 32 QCM sur 34 (94 %) portent une figure de la fiche ou un
schéma légendé en correction ; 62 notes sur 76. L'annale 2024/2025 prend la
diapositive des acteurs du cycle (p. 8). Les deux QCM sans figure
(`par-qc-relation-hote`, `par-qc-diagnostic`) n'en ont pas dans la fiche. Les
seize figures (`media/par-*.png`) sont déclarées avec leur page. Douze sont
extraites de la FC n°1 2025-26. Les quatre cycles d'Enterobius, de Trichuris,
de Taenia et de Loa loa (`par-cycle-*-2425.png`) sont les mêmes diapositives,
prises dans le cours 2024-25 (p. 9-10) : le PDF 2025-26 ne les imprime qu'en
vignettes de 120 à 175 pixels, dont les légendes sont illisibles — celle de
Trichuris, « pas d'auto infestation », porte la clé de `par-qc-trichuris` D.
Les cycles de Schistosoma et de Toxocara restent ceux de 2025-26, plus nets.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2024/2025 S1 5) (cycle sans autre hôte que l'Homme) | aucune (sujet sans corrigé) | **BD**, `officielle=False` | clé déduite du cours : l'anguillule va de l'Homme au sol et du sol à l'Homme (FC n°5 2025-26, p. 6), l'amibe d'un homme à l'autre par les kystes (FC n°5, p. 3-4) ; le schistosome a son mollusque (p. 9), le Plasmodium son anophèle (p. 8), le ténia son bœuf ou son porc (p. 8) |
| 2019/2020 S2 Q1 (œufs dans les selles) | aucune : la table de la p. 3 ne cite pas cette session | **AD**, `officielle=False` | clé déduite du cours : le ténia (embryophores dans les selles, FC n°3 2025-26 p. 16) ; l'oxyure, dont les œufs sont « rarement » vus dans les selles « mais ça reste parfois possible » (FC n°3 2025-26 p. 14). Giardia donne des kystes, Toxocara reste larve chez l'Homme, le toxoplasme émet ses oocystes chez le chat |

**Cas ouvert : la proposition A** (oxyurose). Retenue vraie, avec un
ATTENTION « point douteux » dans sa justification : si la question vise les
parasitoses dont on cherche les œufs dans les selles, l'oxyurose, qui se
diagnostique au scotch-test, serait fausse. `CONFLITS` est vide : aucune clé
imprimée n'est contestée, puisqu'il n'y en a pas.

## Le lexique

Dix termes, aux pages mesurées dans le texte de la fiche 2025-26 (en-têtes
courants exclus) : parasitisme (p. 2, 3, 5), commensalisme (5, 6),
saprophytisme (5), hôte définitif (4, 8, 9), hôte intermédiaire (8, 9),
impasse parasitaire (10), monoxène (8), hétéroxène (8), helminthe (3, 4, 7),
protozoaire (2, 3, 6, 7). Chacun dit son origine grecque ou latine.

« Helminthe » est accueilli ici, comme le proposait le plan C16 : le chapitre
`immuno_infectieux` l'a déjà laissé à la parasitologie (voir son LISEZ_MOI).

Les racines `para- (grec)` (FC de sémantique 2/2, p. 8), `mono-` (1/2, p. 8),
`hétéro-` (2/2, p. 5), `proto-` (2/2, p. 10), `sapro-` (1/2, p. 9) et
`xén(o)- / -xène` (1/2, p. 9) citent la FC de sémantique 2026-27, pages
vérifiées dans le texte du PDF ; les autres sont « hors FC ». `-phyte` n'y est
pas rattachée : la FC de sémantique l'enseigne au sens d'« excroissance »
(1/2, p. 10), pas de « plante ».

Les étymologies nouvelles — dix racines (`-site (grec)`, `mensa (latin)`,
`sapro-`, `hospes (latin)`, `definitivus (latin)`, `intermedius (latin)`,
`passare (latin)`, `xén(o)- / -xène`, `helminth(o)-`, `zo(o)-`) et les dix
termes — sont **proposées** pour `scripts/etymologies.json`, avec leurs
sources ; la table n'est pas modifiée par ce chapitre. `-site (grec)` et
`zo(o)-` reprennent la clé et le texte que proposent aussi les chapitres
voisins de l'UE (ectoparasitoses ; parasitoses autochtones, paludisme) : une
racine, une clé, le même sens partout. Les définitions et les
racines disent déjà, mot pour mot, ce qu'`appliquer_etymologies.py` en
écrira (vérifié en appliquant la proposition à une copie de la table). Les
racines réemployées gardent la clé de la table : `para- (grec)`,
`cum (latin)`, `-phyte`, `in- (latin)`, `mono-`, `hétéro-`, `proto-`.

## Questions pour Vincent

1. **« Helminthe »** : le plan C14 le mettait au lexique d'« Réponse aux agents
   infectieux » ; le plan C16 propose de l'accueillir ici (dix emplois dans
   les annales de parasitologie), et `immuno_infectieux` l'a déjà laissé. Il
   est ici : d'accord ?
2. **L'examen parasitologique des selles** : la FC n°1 p. 10 écrit « espacé de
   3 semaines », l'errata de la promo propose « 2 semaines », les FC n°3 et
   n°5 et le corrigé de 2022/2023 S1 QROC 2 disent « 3 fois sur 7 à 10
   jours ». Les cartes suivent la FC n°5 (✪) et signalent les deux autres :
   d'accord ?
3. **2019/2020 S2 Q1 A** (l'oxyurose donne-t-elle des œufs dans les selles ?) :
   clé déduite AD, A tenue pour vraie et signalée « point douteux ». Préfères-tu
   D seul ?
4. **La consigne « ne pas confondre helminthes et protozoaires »** : le plan la
   voulait en `indispensables` ; elle est portée des deux côtés sur
   `par-qc-helminthe-ou-protozoaire` (oublier un helminthe ou cocher un
   protozoaire annule la question), ce qui fait de cette carte un tout ou
   rien. Préfères-tu un seul des deux côtés ?

## À relire

Aucune carte `a-relire` : chaque carte de cours porte sa page dans la fiche
2025-26, et les deux annales disent leur clé déduite (et son point douteux pour
2019/2020 S2 Q1). À la parution du
ronéo 2026-27 de ce cours, relire toutes les cartes contre lui : pages,
exemples de chaque niveau du parasitisme, rythme de l'examen des selles, et les
quatre erreurs ci-dessus.


## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier. Sous les annales, 12 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 2 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `cycle-parasitaire` | 12 | 2 | 2 |

**Le schéma** `ech-cycles-parasitaires`, « Le cycle parasitaire · ses hôtes, ses exemples », donne 17 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_CYCLES_PARASITAIRES`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- par-an-2425s1-q5 B : l'anguillulose n'est pas dans la FC n°1 2025-26 (ni dans le cours 2024-25 du même professeur) ; son cycle sans autre hôte que l'Homme se prépare avec les parasitoses digestives exotiques (FC n°5). Sa lettre est posée sur la case « Cycle direct (monoxène) », la notion qu'elle met en jeu.

## Régénérer

```powershell
cd contenu\chapitres\parasito_parasitisme
..\..\..\app\.venv\Scripts\python.exe generer.py
```
