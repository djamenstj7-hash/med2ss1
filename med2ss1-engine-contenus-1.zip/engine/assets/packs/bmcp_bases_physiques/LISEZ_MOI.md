# Bases physiques de l'imagerie médicale — paquet BMCP

85 notes, 151 cartes. Chapitre `chap-ue-bmcp-fc15` de l'UE BMCP, ordre 16.
Cours du **Pr Huglo, le 28/11/2025**, dans le **Ronéosaure 2025-26** : la
FC n°16 entière (10 h-11 h, 10 pages) et les **p. 2-5 de la FC n°17**, qui
finissent la scanographie commencée p. 10 de la FC n°16. Annales de quatre
polycopiés du Ronéosaure 2024-25 (BMCP 14, 15, 16, 19) et du **sujet de
2024/2025 S1** (examen du 09/01/2025, sans corrigé, déposé le 15/10/2026),
8 sessions citées. Examen : mardi 5 janvier 2027.

**Fiche provisoire** (C16, décision de Vincent du 02/10) : le cours 2026-27
n'est pas encore paru. Chaque carte de cours cite sa page de la FC 2025-26
(`page=`, et `fiche=` pour la FC n°17) ; l'auteur « Ronéosaure 2025-26 » des
deux sources donne à chaque carte de cours le tag `cours-2025-26`, et l'écran
montre « Cours 2025-26 ». Aucune carte n'est « Absent du cours 2026-27 ».

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 38 | 38 |
| QRU | 4 | 4 |
| Texte à trous | 11 | 72 |
| QROC | 11 | 11 |
| Recto-verso | 9 | 9 |
| Schéma cliquable | 1 | 6 |
| Planche à légender | 1 | 1 |
| Lexique | 10 | 10 |

Dont **14 annales** (QCM) sur 8 sessions. 42 QCM en tout (28 du cours,
14 d'annales), **31 illustrés (74 %)**.

Sept thèmes, tous nouveaux ; leurs libellés sont dans `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) depuis l'intégration du 05/10. Deux sont partagés avec
`bmcp_bases_imagerie` (FC n°20), avec le même libellé :

| Clé | Libellé | Notes |
|---|---|---|
| `modalites-imagerie` | Les modalités d'imagerie | 7 |
| `demande-examen` | Demande et compte rendu d'examen | 5 |
| `tube-rx` | Tube à rayons X : quantité et qualité | 12 |
| `attenuation-contraste` | Atténuation et contraste radiologique | 4 |
| `produits-contraste` | Produits de contraste | 12 |
| `image-radiologique` | Formation et géométrie de l'image | 12 |
| `scanographie` | Scanographie : principe, reconstruction, qualité | 23 |

## Les sources et leurs années

| Source | Identifiant | Rôle |
|---|---|---|
| FC n°16 « Bases physiques de l'imagerie médicale », Ronéosaure 2025-26 | `src-fc-bmcp-bpi16-2526` | fiche du chapitre (`SRC["fiche"]`), 10 p. |
| FC n°17 « Médecine nucléaire », Ronéosaure 2025-26, p. 2-5 | `src-fc-bmcp-bpi17-2526` | seconde fiche, `fiche=` sur les cartes de scanographie |
| BMCP 15 « Bases physiques de l'imagerie médicale », Ronéosaure 2024/2025 | `src-annales-bmcp-15-…` | annales par défaut |
| BMCP 14 « Radioprotection » | `src-annales-bmcp-14-radioprotection` | session 2023/2024 S1 |
| BMCP 16 « Médecine nucléaire » | `src-annales-bmcp-16-medecine-nucleaire` | session 2023/2024 S2, et l'image du cas |
| BMCP 19 « Scanner et Contraste » | `src-annales-bmcp-19-scanner-et-contraste` | session « 2016/2017 S1 (BMCP 19) » |
| Sujets de BMCP 2024/2025, session 1 (examen du 09/01/2025, 30 p., sans corrigé) | `src-sujets-bmcp-2425` | session 2024/2025 S1 (Q. 21 à 24) ; déclarée à l'identique dans tous les chapitres de BMCP qui en tirent une question |

Les deux fiches portent `chapitre="chap-ue-bmcp-fc15"`. La FC n°17 est aussi la
fiche de `bmcp_medecine_nucleaire` (p. 5-10), sous son propre identifiant :
le même PDF, deux sources. BMCP 20 « Bases de l'imagerie » recopie sept de ces
questions (mêmes numéros, mêmes clés) : il n'est pas déclaré, chaque carte cite
l'instance principale et nomme la copie dans son explication.

Les cours 2024-25 et 2023-24 ne sont pas déclarés : chaque annale trouve sa
réponse dans les FC 2025-26 (n°16 et 17 ici ; n°18, 19 et 20 pour les
propositions qui débordent, citées dans le texte). Ils ont servi à trier les
erreurs du ronéo : le ronéo 2023-24 du même cours (p. 11) donne Radon en 1917.
Une exception : la Q. 22 de 2024/2025 (le flou) a une proposition, les écrans
renforçateurs, que seul le cours 2023-24 traite (Charonéo, « Bases physiques
de l'imagerie médicale », 27/10/2023, p. 5 et 10, « les flous ») ; la
justification le cite dans son texte.

## Ce que le cours a dicté

Le ronéo marque en **rouge** ce qui est à savoir ; tout le rouge a sa carte :
les quatre modalités et « plus complémentaires que concurrentes » (p. 2), les
données administratives et « s'il ne peut pas, il refuse l'examen » (p. 3), la
cathode, l'anode, la différence de potentiel qui fixe l'énergie, le rendement
très faible (p. 4), E = K·I·U²·Z·t, les mA·s quantitatifs, le kV qualitatif
(p. 5), le contraste c = (x1 − x2)/(x1 + x2) (p. 5), les examens iodés
(angiographie à radiculographie, p. 6-7), absorbés et diffusés, la
photocathode (p. 8), la source ponctuelle, l'objet non ponctuel, la
téléradiographie (p. 9), la radiologie interventionnelle thérapeutique et les
examens de première intention (p. 10). Seuls les cristaux de BrAg du film
argentique, « historique », n'ont pas de carte à eux.

Le **gris** est la voix des rédacteurs (décision du 25/09) : « aux ECOS on peut
demander de faire une demande d'examen » (p. 3) est repris dans l'explication de
`bpi-qc-demande` ; le renvoi à une image « pas encore disponible sur moodle »
(p. 9, le signe de la silhouette) n'a rien à carter — le texte, lui, est carté.

Ce que le chapitre ne refait pas (plan C16, § 0.7) : unités Hounsfield et
fenêtres n'ont ici qu'un rappel (`bpi-qc-coupes`, `bpi-qr-fenetre-poumon`), le
détail et le calcul sont à `bmcp_scanner` (FC n°21) ; la place de chaque
technique est à `bmcp_bases_imagerie` (FC n°20) ; la médecine nucléaire de la
FC n°17 (p. 5-10) à `bmcp_medecine_nucleaire`.

## Ce que les annales ont dicté

| Polycopié | Session | N° | Clé imprimée | Retenu | Carte | Copie |
|---|---|---|---|---|---|---|
| BMCP 14 | 2023/2024 S1 | Q. 21 | A | A | `bpi-an-2324s1-q21` | BMCP 16, Q. 21 |
| BMCP 16 | 2023/2024 S2 | Q. 11 | ABCDE | ABCDE | `bpi-an-2324s2-q11` | BMCP 20, Q. 11 |
| BMCP 16 | 2023/2024 S2 | Q. 12 | BC | BC | `bpi-an-2324s2-q12` | — |
| BMCP 15 | 2022/2023 S1 | Q. 20 | CDE | CDE | `bpi-an-2223s1-q20` | BMCP 20 |
| BMCP 15 | 2022/2023 S1 | Q. 21 | AB | AB | `bpi-an-2223s1-q21` | BMCP 20 |
| BMCP 15 | 2022/2023 S1 | Q. 22 | BCD | BCD | `bpi-an-2223s1-q22` | BMCP 20 |
| BMCP 15 | 2021/2022 S2 | Q. 27 | BCE | BCE | `bpi-an-2122s2-q27` | BMCP 20 |
| BMCP 15 | 2016/2017 S1 | Q. 27 | ABC | **B** | `bpi-an-1617s1-q27` | BMCP 20 |
| BMCP 19 | 2016/2017 S1 | Q. 28 | B | B | `bpi-an-1617s1-q28` | — |
| BMCP 15 | 2016/2017 S2 | Q. 30 | ABCE | ABCE | `bpi-an-1617s2-q30` | BMCP 20 |
| sujet 2024/2025 | 2024/2025 S1 | Q. 21 | aucune (sujet sans corrigé) | ABCE | `bpi-an-2425s1-q21` | — |
| sujet 2024/2025 | 2024/2025 S1 | Q. 22 | aucune (sujet sans corrigé) | AD | `bpi-an-2425s1-q22` | — |
| sujet 2024/2025 | 2024/2025 S1 | Q. 23 | aucune (sujet sans corrigé) | ABD | `bpi-an-2425s1-q23` | — |
| sujet 2024/2025 | 2024/2025 S1 | Q. 24 | aucune (sujet sans corrigé) | BDE | `bpi-an-2425s1-q24` | — |

Ce qui revient : les **produits de contraste** (baryte digestive sans fuite,
iode et rein, allergie, thyroïde : 2022/2023 Q. 22, 2016/2017 S2 Q. 30) ; la
**quantité et la qualité** des rayons X (2022/2023 Q. 21, 2021/2022 Q. 27) ;
le **scanner** et sa rotation continue (2016/2017 S1, deux fois) ; l'imagerie
**en coupes** et les **modalités** ionisantes (2022/2023 Q. 20, 2023/2024 S1
Q. 21) ; la **demande d'examen** (2023/2024 S2 Q. 11, et 2024/2025 Q. 21,
une demande de TEP-TDM à juger). Les quatre questions de 2024/2025 sont
neuves : aucune ne reprend une session plus ancienne mot pour mot, mais la
Q. 24 rejoue les produits de contraste de 2022/2023 Q. 22 et 2016/2017 S2
Q. 30.

Trois remarques de transcription :

* **2022/2023 S1 Q. 21 C** est illisible dans le PDF de BMCP 15 (« Luantit des
  sayon re la cathode… ») : son texte, « La haute tension entre la cathode et
  l'anode est un paramètre de quantité des rayons X émis », est repris de
  BMCP 20, et la justification le dit.
* **2023/2024 S2 Q. 12** : l'image des trois examens est la question
  (`illustration_question`), la figure (c) de la FC n°16 p. 7 la correction.
  « Questions 12 à 15 : données communes », mais **ni la Q. 14 ni la Q. 15 ne
  sont imprimées**, dans aucun polycopié : rien à carter. La Q. 13 (examen B,
  échographie Doppler) est à `bmcp_echographie_irm`.
* La carte de BMCP 19 porte la session **« 2016/2017 S1 (BMCP 19) »** : le
  générateur cite une source par session, et la 2016/2017 S1 de BMCP 15 en a
  déjà une. C'est la convention des « (poly 5) » de la génétique.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| BMCP 15 (et 20) 2016/2017 S1 Q. 27 | ABC | **B** (`officielle=False`) | Les mêmes cinq propositions sont imprimées dans BMCP 19, sous l'énoncé « scanographie », clé B. Elles décrivent un scanner (anneau, coupes, épaisseur) : A (« analogique ou numérique ») est fausse, le scanner est numérique, image reconstruite par ordinateur (FC n°17 p. 2) ; C (« environ 20 minutes ») est fausse, un tour dure moins d'un quart de seconde (FC n°17 p. 3). ATTENTION sur A et C, CONFLITS. |
| BMCP 19 2016/2017 S1 Q. 28 | B | B | Clé reprise ; ATTENTION sur A et C pour dire que BMCP 15 et 20 donnent l'inverse, CONFLITS (un conflit déclaré sur chacune des deux cartes). |

| sujet 2024/2025, Q. 21 | aucune (sujet sans corrigé) | ABCE (`officielle=False`) | Clé déduite du cours : la demande ne donne pas la date de naissance (A), ni le traceur d'une « TEP-TDM » (B : « dire “TEP” sans précision ne veut pas dire grand-chose », FC n°18 p. 9, en rouge), ni question ni histoire (C), ni coordonnées du demandeur (E) ; elle donne un délai, « dans les 10 prochains jours » (D faux) — FC n°16 p. 3. |
| sujet 2024/2025, Q. 22 | aucune (sujet sans corrigé) | AD (`officielle=False`) | Clé déduite du cours : à mA·s constants, moins d'intensité veut dire une pose plus longue, donc un flou de mouvement (A) ; la grille et la source ponctuelle diminuent le flou (C, E). D, les écrans renforçateurs, n'est plus dans le cours 2025-26 : la clé vient du cours 2023-24 (Charonéo, 27/10/2023, p. 10), qui les range parmi les flous du détecteur, et la justification le dit. |
| sujet 2024/2025, Q. 23 | aucune (sujet sans corrigé) | ABD (`officielle=False`) | Clé déduite du cours : contraste naturel du thorax et de l'os, énergie basse de la mammographie ; UIV et coronarographie sont iodées (FC n°16 p. 6). |
| sujet 2024/2025, Q. 24 | aucune (sujet sans corrigé) | BDE (`officielle=False`) | Clé déduite du cours : la baryte ne sert qu'au tube digestif, l'arthrographie est iodée (A faux) ; bouffée de chaleur physiologique, iodé hydrosoluble en cas de fuite digestive, thyroïde saturée environ six semaines ; « toujours sans gravité » est faux (FC n°16 p. 6-7). |

**Cas ouvert** : l'énoncé « radiologie avec administration intraveineuse de
produit de contraste » et la clé ABC de la Q. 27 viennent sans doute d'une
autre question de la session, perdue, recollée aux propositions de la Q. 28.
Rien ne permet de retrouver la vraie Q. 27. Les deux cartes le disent.

## Les erreurs du ronéo 2025-26

ATTENTION nu (convention du Ronéosaure) : rien n'entre dans
`contenu/ERRATA_RONEOS_2026-27.md`. Ni le tableau d'erreurs de la promo
2025-26 (`Erratas BMCP.docx`) ni l'errata des annales n'ont d'entrée pour ces
deux fiches ou ces questions : toutes ces erreurs ont été trouvées en relisant.

| Page | Le ronéo | Retenu | Sorte | Carte |
|---|---|---|---|---|
| FC n°16 p. 5 | « N = coefficient d'atténuation linéique » | µ est le coefficient (la formule de la diapositive, juste au-dessus : « N = N₀·e^(−µ·x) avec µ en cm⁻¹ ») ; N est le nombre de photons transmis | prise de notes | `bpi-qc-attenuation` (B) |
| FC n°16 p. 7 | « Si > 60 ml/min, il faut prendre des précautions ou déconseiller » | c'est un DFG **bas** qui fait prendre des précautions (« en dessous d'un certain seuil », même page) ; 60 est l'ancien seuil, la SFR-CIRTACI (V2.4, 2020) dit < 30 mL/min par voie veineuse, < 45 par voie artérielle de premier passage | prise de notes | `bpi-qc-rein` (C) |
| FC n°16 p. 7 ; FC n°17 p. 4 | on arrête la metformine après toute injection | à l'examen, comme le professeur ; la SFR-CIRTACI (2020) ne l'arrête que si DFG < 30, voie artérielle de premier passage ou insuffisance rénale aiguë | le cours lui-même | `bpi-qc-rein` (D), `bpi-fa-iode-precautions` |
| FC n°16 p. 7 | l'image (c), vessie et sonde avec reflux, rangée après l'urographie intraveineuse | une cystographie : en UIV, le produit injecté dans une veine descend des reins à la vessie | point douteux | `bpi-an-2324s2-q12` (explication) |
| FC n°17 p. 2 | la transformée de Radon « au 19e siècle » | 1917 : le ronéo 2023-24 du même cours l'écrit (p. 11, « J. Radon en 1917 ») ; Berichte über die Verhandlungen der Königlich-Sächsischen Gesellschaft der Wissenschaften zu Leipzig, t. 69 | prise de notes | `bpi-qr-radon` |
| FC n°17 p. 3 | la reconstruction itérative : « il n'y a plus d'artefacts » | elle les réduit ; la p. 5 montre encore des artefacts métalliques, corrigés par logiciel | point douteux | `bpi-qc-reconstruction` (C) |
| FC n°17 p. 3 | la figure « Épandage » (2 à 32 projections), rangée sous la reconstruction itérative | elle montre la rétroprojection simple | point douteux | `bpi-qc-reconstruction` (D) |
| FC n°17 p. 5 | « plus la coupe est fine […] il y aura moins de bruit » | moins de volume partiel, mais **plus** de bruit à dose égale | prise de notes | `bpi-qc-qualite` (C) |

La plupart de ces phrases sont reprises mot pour mot du ronéo 2024-25 (« > 60
ml/min », la metformine, « au 19e siècle », « plus d'artefacts », « moins de
bruit ») ; le ronéo 2023-24 du même cours ne les a pas, sauf la metformine, et
donne Radon en 1917.

**Deux cours, deux chiffres** (ATTENTION nu dans `bpi-qc-doses`, C) : la
diapositive des doses (FC n°17 p. 5) porte une « irradiation annuelle » de
2,5 mSv ; la radioprotection donne 4,5 mSv par an en moyenne en France (FC n°15,
partie 1, p. 6, figure de l'IRSN). La carte ne fait plus dire « quatre fois
l'irradiation annuelle » au scanner du thorax, et retient 4,5 mSv pour
l'exposition moyenne. La radiographie du thorax, 0,1 mSv sur la diapositive,
vaut 0,06 mSv sur la figure de l'IRSN : même ordre de grandeur, dit dans B.

## Les schémas et les figures

| Fichier | Ce que c'est | Cartes |
|---|---|---|
| `scanographe.svg` / `scanographe-legende.svg` | un scanographe en coupe, redessiné d'après la FC n°17 p. 2-3 ; six zones : tube, couronne de détecteurs, patient, table, rotor, stator | `bpi-zo-scanographe` |
| `bpi-tube-rx-numerote.png` / `bpi-tube-rx.png` | le tube à rayons X de la FC n°16 p. 4, ses neuf légendes effacées (`planche_depuis_image.py`) ; quatre intrus d'autres appareils (grille anti-diffusante, photocathode, couronne de détecteurs, dynode) | `bpi-pl-tube-rx` |
| `attenuation-contraste.svg` | N = N₀·e^(−µx) à faible et haute énergie, le contraste calculé (coefficients fictifs, dits sur la figure) | 2 QCM |
| `retroprojection.svg` | l'exemple chiffré de la FC n°17 p. 2, pas à pas | `bpi-fa-retroprojection` |
| 21 figures des FC (PNG) | captures de diapositives, chacune avec sa page | 46 notes |
| `bpi-an-enfant-examens.png` | les examens A, B, C de BMCP 16 p. 3 : la question de 2023/2024 S2 Q. 12 | 1 annale |

Le dessin et les zones du scanographe lisent les mêmes constantes. Les anneaux
du rotor et du stator sont dessinés en cercles et corrigés par les polygones
de `geometry.annulus`, aux mêmes rayons. Le tube et la couronne, montés sur le
rotor, sont dessinés contre son bord intérieur pour qu'aucun clic ne tombe dans
deux zones. Sur la version légendée, le rotor et le stator sont nommés hors des
anneaux, avec un trait, pour qu'aucune légende ne coupe un tracé. Les figures de la FC n°16 sont de basse résolution dans le PDF :
extraites agrandies, elles restent lisibles. La figure « Épandage » s'appelle
`bpi-epandage-projections.png` (le brouillon du 03/10 la nommait
`bpi-iteratif.png`, d'après le ronéo).

## Le lexique

Dix termes, dans l'ordre du cours, chacun avec son étymologie et ses pages
mesurées par `chercher_pages.py` dans les deux PDF : Angiographie,
Phlébographie, Urographie (p. 6), Arthrographie, Fécalome (p. 7), Radioscopie
(p. 8 et 1), Voxel (FC n°16 p. 8, FC n°17 p. 4), Téléradiographie (p. 9),
Tomographie (FC n°16 p. 10, FC n°17 p. 6), Tomodensitométrie (FC n°16 p. 10
et 2, FC n°17 p. 2). Aucun n'est déjà dans l'UE.

Racines citées dans les FC de sémantique 2026-27 : angi(o)- (1/2 p. 7),
phléb(o)- (2/2 p. 3), -métrie (2/2 p. 7, « métr- : mesure »), radi- (latin)
(2/2 p. 12). Les autres sont
« hors FC ». Les étymologies sont écrites dans `donnees.py` ; les racines et
termes nouveaux (phléb(o)-, tom(o)-, radi- (latin), densus, faex, volumen,
pixel ; les dix termes) sont dans `etymologies.json` depuis l'intégration du
05/10.

## Questions pour Vincent

1. **2016/2017 S1, Q. 27 (BMCP 15 et 20) et Q. 28 (BMCP 19)** : la proposition
   du plan est appliquée — deux cartes, chacune telle qu'imprimée, clé B pour
   les deux, la Q. 27 non officielle, ATTENTION et CONFLITS sur A et C de
   chacune. Faut-il plutôt ne garder que la carte de BMCP 19, la seule dont
   l'énoncé et la clé collent aux propositions ?
2. **La session « 2016/2017 S1 (BMCP 19) »** : pour que la carte cite son
   polycopié (une source par session dans le générateur). Elle produit le tag
   de session `2016-2017-s1-(bmcp-19)`, comme les « (poly 5) » de la génétique.
3. **La metformine** : les cartes répondent comme le cours (on l'arrête après
   une injection iodée) et donnent la référence actuelle (SFR-CIRTACI 2020)
   sous « La référence ». Cela te va pour le partiel ?
4. **La FC n°17 déclarée deux fois** (ici `src-fc-bmcp-bpi17-2526`, et sous
   l'identifiant de `bmcp_medecine_nucleaire`), chaque fois avec `chapitre=` :
   le lecteur l'ouvre depuis les deux chapitres. Le plan l'a voulu ; à
   confirmer.

## À relire

Aucune carte `a-relire` : chaque carte de cours cite sa page de la FC n°16 ou
n°17, chaque annale sa réponse dans le cours — les quatre de 2024/2025, sans
corrigé, comprises (la proposition D de la Q. 22 sur le cours 2023-24). L'identification de l'examen A
(une cystographie) est un raisonnement sur l'image, dit dans la carte ; la clé
BC n'en dépend pas.

## Intégration (05/10)

- Les libellés de thèmes sont dans `THEME_LABELS`
  (`app/src/med_engine/application/scopes.py`), bloc « BMCP FC n°6 à 22 ».
- Les étymologies proposées (racines et termes) sont versées dans
  `.claude/skills/nouveau-chapitre/scripts/etymologies.json` ;
  `appliquer_etymologies.py` n'a rien réécrit, les textes du lexique étant
  déjà à sa forme.
- La racine du latin *radius*, proposée ici sous « radi(o)- », est fondue sous
  « radi- (latin) », la clé des autres chapitres et la forme de la FC de
  sémantique ; les deux termes qui l'emploient (Radioscopie, Téléradiographie)
  citent maintenant la FC de sémantique 2/2, p. 12.
- `densus (latin)` et `tom(o)-` n'ont qu'une entrée, communes avec
  `bmcp_scanner` et `bmcp_tep`.

## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier (BMCP) ou du 6 janvier (SSH, papier). Sous les annales, 36 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 8 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `modalites-imagerie` | 5 | 1 | 3 |
| `demande-examen` | 6 | 1 | 2 |
| `tube-rx` | 6 | 1 | 2 |
| `produits-contraste` | 12 | 3 | 4 |
| `image-radiologique` | 3 | 1 | 1 |
| `scanographie` | 4 | 1 | 2 |

**Le schéma** `ech-rayons-x`, « Faire une image aux rayons X · de la demande au scanner », donne 59 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_RAYONS_X`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- 2024/2025 S1 Q. 21 B (bpi-an-2425s1-q21) : une TEP sans traceur n'est pas un examen précis — le fait est dans la FC n°18 (bmcp_tep), hors des sources de ce chapitre ; la lettre est posée sur « Qui prescrit l'examen ».
- 2024/2025 S1 Q. 22 D (bpi-an-2425s1-q22) : les écrans renforçateurs ne sont plus dans le cours 2025-26 (ni 2024-25), seulement dans le Charonéo 2023-24 ; lettre posée sur « Les causes du flou ».
- 2023/2024 S1 Q. 21 C, D, E (bpi-an-2324s1-q21) : scintigraphie planaire, contre-indications de l'IRM, Doppler — FC n°18 et n°19 (bmcp_medecine_nucleaire, bmcp_echographie_irm), hors des sources de ce chapitre ; lettres posées sur « Quatre modalités ».
- 2023/2024 S2 Q. 12 E (bpi-an-2324s2-q12) : la fonction séparée des reins se mesure en médecine nucléaire (FC n°18) ; lettre posée sur « Quatre modalités ».
- 2022/2023 S1 Q. 20 D, E (bpi-an-2223s1-q20) : l'IRM et l'échographie en coupe sont des faits de la FC n°20 (bmcp_bases_imagerie, dont l'échelle porte la marche de l'IRM, bdi-ech-s29) ; lettres posées sur « Quatre modalités ».

## Régénérer

```powershell
cd contenu\chapitres\bmcp_bases_physiques
..\..\..\app\.venv\Scripts\python.exe generer.py
```

La planche numérotée, si les rectangles de `PLANCHES` changent (depuis `app/`,
Pillow n'étant pas une dépendance du projet) :

```powershell
uv run --with pillow python ..\.claude\skills\nouveau-chapitre\scripts\planche_depuis_image.py ..\contenu\chapitres\bmcp_bases_physiques bpi-pl-tube-rx --apercus <brouillon> --taille 30
```
