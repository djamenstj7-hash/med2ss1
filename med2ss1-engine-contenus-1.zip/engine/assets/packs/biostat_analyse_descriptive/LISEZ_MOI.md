# Analyse descriptive — paquet Biomédecine quantitative

68 notes, 143 cartes. Chapitre `chap-ue-biomed-quanti-fc1` de l'UE
Biomédecine quantitative, septième de l'UE. Cours du **Pr G. Ficheur, le
17/11/2025, de 8 h à 9 h**, dans le **Ronéosaure 2025-26** (FC n°7, 7 pages) ;
les annales d'un polycopié du Ronéosaure 2024-25 (une question, 2023/2024).
Examen : partiel du mercredi 16 décembre 2026.

**Fiche provisoire** (C15, décision de Vincent du 02/10) : le cours de l'année
2026-27 n'est pas encore paru. Chaque carte de cours cite la FC 2025-26 à sa
page et porte le badge « Cours 2025-26 » ; le ronéo 2026-27 corrigera les cartes
quand il sortira. `donnees.py` porte `ANNEE_COURS = "2025-26"`. Aucune carte ne
dit « Absent du cours 2026-27 », et les erreurs du Ronéosaure sont dites par un
ATTENTION sans genre : la liste des erreurs de la promo,
`contenu/ERRATA_RONEOS_2026-27.md`, ne concerne que les ronéos 2026-27.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 22 | 22 |
| QRU | 5 | 5 |
| Texte à trous | 14 | 84 |
| QROC | 11 | 11 |
| Recto-verso | 6 | 6 |
| Schéma cliquable | 1 | 6 |
| Planche à légender | 1 | 1 |
| Lexique | 8 | 8 |

Dont **une annale** (2023/2024 S1, QCM n° 6). Les 26 autres QCM sont des
questions de cours : avec une seule annale, le chapitre se carte sur le cours,
comme le plan C15 le prévoyait.

Six thèmes, dans l'ordre du cours :

| Clé | Libellé | Notes | Statut |
|---|---|---|---|
| `variables` | Types de variables | 12 | existante (`remed_biostats`) |
| `description` | Décrire une variable | 12 | existante (`remed_biostats`) |
| `intervalle-de-confiance` | Intervalle de confiance | 6 | existante (`remed_biostats`) |
| `kaplan-meier` | Kaplan-Meier et censure | 13 | **nouvelle**, partagée avec les analyses de survie (FC n°12) |
| `types-etudes` | Types d'études | 12 | existante (régression linéaire) |
| `tableau-descriptif` | Lire le tableau descriptif d'une étude | 5 | **nouvelle** |

`kaplan-meier` et `tableau-descriptif` restent à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) : c'est le seul test rouge du
chapitre. Le plan proposait `tableau-1` ; une clé qui porte un chiffre n'est pas
un thème (et un libellé n'en porte pas), d'où `tableau-descriptif`.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-biomed-dsc-2526` — Ronéosaure, « FC n°7 Analyse descriptive » (7 p.) | 2025-26 | le cours ; `SRC["fiche"]`, ses 7 figures ; fiche provisoire en attendant le ronéo 2026-27 |
| `src-annales-1-analyse-descriptive` — « 1. Analyse descriptive » (1 p.) | 2024-25 | la QCM n° 6 de 2023/2024 et sa clé |

Le polycopié d'annales est déclaré dans la forme commune de C15 (id tiré du nom
de fichier, titre = nom sans extension, chemin, auteur). La fiche est déclarée
sous l'identifiant du plan, `src-fc-biomed-dsc-2526`, et dans la forme
exacte où le chapitre des analyses de survie la déclare pour citer la FC n°7
p. 4-5 (mêmes champs, vérifié). Lus en appoint, sans
être déclarés : le cours 2024-25 du même professeur (FC n°1 « Analyse
descriptive », Ronéosaure 2024-25), qui tranche les erreurs du ronéo et confirme
le calcul de la courbe de Kaplan-Meier (« on chute la courbe de moitié », p. 7) ;
l'errata des cours 2025-26 (trois entrées pour la FC n°7) ; l'errata des annales
2024-25 (aucune entrée pour ce polycopié).

Les pages citées sont celles du PDF ; la p. 1 est la page de garde et le plan ;
le numéro imprimé en pied de page est celui du PDF. Les en-têtes du ronéo, des erratas et du
polycopié portent des noms d'étudiants : aucun n'est repris.

## Ce que le cours a dicté

- **Le rouge** ne marque que les titres des quatre parties.
- **Le gris** est la voix des rédacteurs (la définition de l'analyse
  descriptive et la liste des types de variables, p. 2 ; Q2 = la médiane, p. 3 ;
  la multivaluée décomposée en binaires 0/1, p. 4) : il se carte comme le reste
  (décision du 25/09) — `dsc-fa-definitions`, `dsc-qc-quartiles` C,
  `dsc-qu-multivaluee`.
- **« QCM +++ »** (p. 4), sur la méthode de Kaplan-Meier : une zone cliquable,
  deux textes à trous, quatre QCM, deux QROC dont un calcul.
- **Ce qui n'est pas carté ici** (plan C15) : le statut des variables et le
  choix d'un test (`biostat_scores`) ; transversal et longitudinal, le
  cross-over, le RR en cas-témoins, les niveaux de preuve
  (`biostat_regression_lineaire`) ; le modèle de Cox au-delà de « il compare deux
  courbes » (`biostat_survie`) ; la non-infériorité (FC n°2 et n°6), seulement
  définie dans une proposition.
- **Les tables des p. 6-7** se lisent sur leurs captures, chiffres vérifiés sur
  l'image : âge médian 52 ans et étendue 16-89 / 16-91 (vaccin ARN), 65,6 ± 16,5
  ans (C. difficile), 49,1 (6,6) ans et Charlson en classes (chirurgie
  bariatrique), courbe du gastric bypass vers 0,97 en fin de suivi (t = 8 ; la
  capture ne dit pas l'unité du temps) sur un axe de 0,95 à 1. L'étude bariatrique est celle de Paccou et al. (J Bone Miner Res, 2020),
  appariée 1:1 sur l'âge, le sexe, le Charlson, l'année et la classe d'obésité,
  ce qui explique ses deux premières colonnes identiques.

## Les erreurs du Ronéosaure 2025-26

Le Ronéosaure n'est pas le ronéo de l'année : chaque erreur est portée par un
**ATTENTION nu** dans la carte qui tient la notion, la sorte dite dans le texte,
et rien n'entre dans `contenu/ERRATA_RONEOS_2026-27.md`.

| Page | Le ronéo dit | Retenu | Sorte | Carte |
|---|---|---|---|---|
| 2 | variables quantitatives exprimées par « la moyenne, ou la médiane et l'écart type » | moyenne et écart type, ou médiane et intervalle interquartile (p. 3 ; tables p. 6-7 ; cours 2024-25, p. 5) | prise de notes | `dsc-fa-parametres`, `dsc-rv-moyenne-mediane` |
| 3 | l'intervalle de confiance « devrait encadrer toutes les moyennes obtenues » sur d'autres échantillons ; en 2024-25 (p. 6), en d'autres mots, « un intervalle théorique où se trouve toutes les moyennes » | 95 % des intervalles contiennent la vraie valeur ; un IC à 95 % ne contient en moyenne qu'environ 83 % des moyennes d'autres échantillons (Cumming et Maillardet, 2006). À l'examen : la définition des 95 % d'intervalles, que le même cours donne juste | le cours lui-même | `dsc-qc-ic` (explication ; aucune proposition n'en dépend) |
| 3 | « 38 % de HTA, 25 % de diabétiques, et x % d'autres choses… des modalités dont la somme finale = 100 % » | la règle des 100 % ne vaut que pour des modalités qui s'excluent ; des antécédents se cumulent (variable multivaluée, p. 4 ; cours 2024-25, p. 4 : « si on somme toutes les situations on peut dépasser 100 % ») | prise de notes | `dsc-qc-qualitative` E |
| 5 | à Framingham, « on leur pose des questions tous les 6 mois » (même phrase en 2024-25, p. 9) | la cohorte d'origine (1948) est examinée tous les deux ans (Framingham Heart Study, « Epidemiological background ») ; à l'examen, le rythme du cours | le cours lui-même | `dsc-qc-cohorte`, `dsc-qr-framingham` (explications ; aucune réponse n'en dépend) |
| 5 | « ¼ décès n'est pas la même chose que   décès » : le second nombre manque (errata 2025-26) | — | prise de notes | aucune carte sur la phrase tronquée ; le calcul de la figure (1/2 et non 1/3 au temps 4) est dans `dsc-qr-km-calcul` |
| 5 | le titre du III manque dans le texte (errata 2025-26) | « III — Catégorie d'études cliniques », que donne le plan de la p. 1 ; la diapositive de la p. 5 s'intitule « Les différents types d'études cliniques » | mise en page | aucune |
| 6 | « la recolonisation par ces gènes » (même mot en 2024-25) | par ces germes (errata 2025-26) | prise de notes | `dsc-qc-table-cdifficile` C |
| 7 | « si les groupes sont grands, même sans tirage au sort, les contextes sont plutôt bien équilibrés » (paragraphe recopié mot pour mot du ronéo 2024-25, p. 10 : on ne peut pas dire si le professeur l'a redit) | seul le tirage au sort équilibre, en moyenne, tous les facteurs ; la table le dément elle-même (maladies cardiovasculaires 1,0 % contre 2,8 % sur 40 992 patients par groupe) | point douteux | `dsc-qc-table-bariatrique` D |

Sans ATTENTION, parce qu'aucune réponse n'en dépend : « NON PARAMÉTRIQUE = le
test compare des groupes » (p. 5) — Kaplan-Meier estime, le log-rank compare ;
les cartes le disent ainsi. Les censures « représentent les patients perdus de
vue » (p. 4) : aussi les patients encore vivants à la fin du suivi, que la zone
`censure-5` montre.

## Ce que les annales ont dicté

| Polycopié | Session | N° | Clé imprimée | Retenue | Carte |
|---|---|---|---|---|---|
| « 1. Analyse descriptive » | 2023/2024 S1 | 6 | ABCE | ABCE | `dsc-an-2324s1-q6` |

Une seule question, qui parcourt tout le cours de description : la courbe de
Kaplan-Meier, la moyenne et l'écart type, l'effectif et la fréquence d'une
variable qualitative, la couleur des yeux (nominale), le nombre d'enfants
(discrète). Ses cinq propositions sont dans la FC 2025-26. L'en-tête dit
« Année 2023-2024 » sans session : la question est rangée en session 1, comme les
questions 2023/2024 sans session du polycopié des tests diagnostiques.

## Les schémas cliquables et la planche

**Un schéma cliquable** (`schemas.py`), avec sa version légendée en correction :

| Fichier | Ce qu'on clique | Pourquoi ce dessin |
|---|---|---|
| `km.svg` | le point de départ, les trois décès (des marches), la censure de t = 3, la censure du dernier patient, et le décès qui donne la survie médiane — 6 zones | la courbe de la p. 4 recalculée sur ses cinq patients (0,8 ; 0,6 ; censure ; 0,3 ; censure), sans la ligne 0,5 ni les effectifs à risque : distinguer une marche d'un rond, et lire soi-même où la courbe passe sous 0,5, c'est la question. La version légendée (`km-legende.svg`) écrit chaque calcul, les effectifs à risque (5, 5, 4, 3, 2, 1) et ce que la marche de t = 4 aurait été sans la censure (0,4) |

**Une planche à légender**, `dsc-pl-types-variables`
(`planche_depuis_image.py`) : la diapositive « Identifier d'abord le type de la
variable » (p. 2), **neuf cases vidées** — les quatre types de départ
(quantitative, qualitative, binaire, multivaluée), la discrète à très peu de
valeurs, les trois façons de traiter (quantitative, qualitative, survie) et les
événements temps-dépendants ; trois intrus (variable censurée, variable
explicative, traiter comme paramétrique). Le plan en proposait douze :
« Continue », « Discrète », « Nominale » et « Ordonnée » restent écrites, parce
que l'ordre des deux paires sur la diapositive ne se déduit d'aucune flèche (une
inversion y serait comptée fausse sans être une erreur de compréhension) ; elles
servent de repères. L'image numérotée a été regardée, agrandie : aucun reste de
lettre (le jambage du « p » de « possibles » a demandé un rectangle plus bas).

**Une figure de principe**, `sejour-asymetrique.svg` : l'exemple de la p. 3 (une
durée de séjour « très asymétrique », pic à 0 ou 1 jour) n'a pas de figure dans
le cours ; elle est dessinée sur 200 séjours **fictifs**, ce que dit sa légende,
avec Q1 = 1, médiane = 3, moyenne ≈ 4,9, Q3 = 6 calculés sur ces données. Elle
illustre les corrections de la moyenne, de la médiane et des quartiles, et ne se
clique pas.

**Sept figures de la FC 2025-26**, extraites en PNG (captures de diapositives et
de tables d'articles), réduites à 1000 px de large au plus et en 256 couleurs.
**25 QCM sur 27 illustrés** (les deux QCM de l'intervalle de confiance n'ont pas
de figure dans le cours), 50 notes sur 68.

## Les clés qui ne sont pas reprises telles quelles

Aucune : la clé imprimée ABCE de l'unique annale est juste, proposition par
proposition. `CONFLITS` est vide.

## Le lexique

Huit termes, ceux du plan C15, aucun déjà présent dans un autre chapitre ; pages
mesurées dans le PDF de la FC (`chercher_pages.py`) :

| Terme | Pages | Racines |
|---|---|---|
| Médiane | 2, 3, 5, 6, 7 | medius (latin) |
| Quartile | 3 | quartus (latin) |
| Cohorte | 5 | cohors (latin) |
| Registre | 5 | regerere (latin) |
| Rétrospectif | 5 | retro, spectare (latin) |
| Nominal | 3 | nomen (latin) |
| Asymétrique | 2, 3 | a-/an-, syn- (grec), -métrie |
| Histogramme | 2 | hist(o)-, -gramme |

« Registre » n'est écrit, p. 5, que dans le titre en image (`chercher_pages.py`
ne le trouve que dans le plan, p. 1) : la page citée est celle où le lecteur le
voit. Les étymologies (TLFi, Wiktionnaire, Gaffiot, Bailly) sont proposées dans
`scratchpad/etym/biostat_analyse_descriptive.json` : sept racines nouvelles
(medius, quartus, cohors, regerere, retro, spectare, -gramme) ; cinq racines de
la table sont reprises à l'identique (nomen, a-/an-, syn-, -métrie, hist(o)-).
Les textes du `LEXIQUE` sont déjà écrits comme `appliquer_etymologies.py` les
écrirait avec cette proposition.

## Questions pour Vincent

1. **La clé de thème `tableau-descriptif`** (« Lire le tableau descriptif d'une
   étude ») remplace le `tableau-1` du plan, qu'une règle des thèmes interdit
   (pas de chiffre). Le libellé te va-t-il ?
2. **La planche à neuf cases au lieu de douze** : garder « Continue »,
   « Discrète », « Nominale » et « Ordonnée » écrites comme repères (proposé et
   appliqué), ou les vider aussi ?
3. **Une figure à données fictives** (`sejour-asymetrique.svg`), dite telle sur
   la carte : acceptable comme schéma de principe, ou préfères-tu les seules
   figures du cours ?
4. **Trois phrases du ronéo, tranchées à la relecture** : l'IC qui « encadre
   toutes les moyennes » est classé « le cours lui-même » (le ronéo 2024-25 le
   dit aussi, en d'autres mots) ; les 100 % des antécédents, « prise de notes »
   (le cours 2024-25 dit qu'on peut dépasser 100 %) ; « si les groupes sont
   grands, même sans tirage au sort », reste « point douteux » (le paragraphe
   est recopié mot pour mot du ronéo 2024-25). Aucune réponse ne repose sur ces
   phrases ; à confirmer quand le ronéo 2026-27 paraîtra.
5. **La session de l'unique annale** : l'en-tête dit « Année 2023-2024 » sans
   session. Elle est rangée en 2023/2024 S1 (proposition du plan : numérotation
   QCM n° 6, à la suite des questions 1 à 5 des tests diagnostiques, elles aussi
   rangées en S1). Est-ce bien la session 1 ?

## À relire

Aucune carte `a-relire` : chaque carte cite une page de la FC 2025-26, chaque
chiffre des tables a été relu sur l'image, et la clé de l'unique annale a été
vérifiée proposition par proposition.

## L'échelle : Simple → Moyen → Annale (C20, 18/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 16 décembre. Sous les annales, 5 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 1 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `variables` | 5 | 1 | 1 |

**Le schéma** `ech-variables`, « Analyse descriptive · le type de la variable, puis ses paramètres », donne 8 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_VARIABLES`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

## Régénérer

```powershell
cd contenu\chapitres\biostat_analyse_descriptive
..\..\..\app\.venv\Scripts\python.exe generer.py
```

Puis, depuis `app/` :
`uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/biostat_analyse_descriptive dsc-pl-types-variables --apercus <brouillon> --taille 30`
si les rectangles de la planche changent.
