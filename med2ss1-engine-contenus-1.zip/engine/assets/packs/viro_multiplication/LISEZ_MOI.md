# Multiplication des virus dans l'organisme — paquet Virologie

113 notes, 169 cartes. Chapitre `chap-ue-virologie-fc2` de l'UE Virologie
(ordre 2). Cours du **Pr Hober, le 10/10/2025**, « Multiplication des virus
dans l'organisme » (FC n°2 du Ronéosaure 2025-26, 18 pages) ; annales du
Ronéosaure 2024-25 et sujet de l'examen du 09/01/2025 (47 questions, 19 sessions,
de 2015/2016 S1 à 2024/2025).
Examen de virologie le **5 janvier 2027**.

**18/10/2026** : 4 questions du sujet de virologie 2025/2026 (examen du
08/01/2026, sans corrigé) — Q.4, Q.5, Q.6, Q.13 ; voir « Le sujet 2025/2026 ».

**Une fiche provisoire.** Vincent a demandé le 02/10/2026 de carter tout le
Ronéosaure 2025-26 ; le ronéo 2026-27 de ce cours n'est pas paru (la
virologie 2026-27 commence le 06/10) et corrigera les cartes à sa parution.
La source porte son année dans son auteur (« Ronéosaure 2025-26 ») : chaque
carte de cours prend le tag `cours-2025-26` et le badge « Cours 2025-26 ».
Aucune carte ne dit « Absent du cours 2026-27 », et les erreurs du Ronéosaure
sont dites par un ATTENTION sans genre : la liste des erreurs de la promo,
`contenu/ERRATA_RONEOS_2026-27.md`, ne concerne que les ronéos 2026-27.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 74 | 74 |
| Texte à trous | 13 | 64 |
| QROC | 10 | 10 |
| Recto-verso | 6 | 6 |
| Schéma cliquable | 1 | 6 |
| Planche à légender | 1 | 1 |
| Lexique | 8 | 8 |

Dont **51 annales** (QRM, verbatim, une justification par proposition) sur 20
sessions. Les 23 QCM du cours ont aussi une justification par proposition.

Huit thèmes, dans l'ordre du cours :

| Clé | Libellé |
|---|---|
| `virus-cellule` | Interactions virus-cellule : effet cytopathique, apoptose |
| `reservoirs-transmission` | Réservoirs et transmission des virus |
| `portes-entree` | Portes d'entrée et dissémination |
| `tropisme` | Tropisme : peau, organes cibles |
| `snc` | Infections virales du système nerveux central (partagé avec `viro_pathogenes_3`) |
| `mere-enfant` | Transmission mère-enfant et infections congénitales (partagé avec `viro_pathogenes_3`, `viro_vaccins_vivants`) |
| `modes-evolution` | Modes d'évolution et expression clinique |
| `resistance-hote` | Résistance et défense de l'hôte (partagé avec `viro_virus_hote`) |

Les huit libellés sont nouveaux, à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) : jusque-là, le test
`test_tout_theme_du_paquet_a_son_libelle` échoue pour ce chapitre, et lui seul.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-viro-fc2` — Ronéosaure, « FC n°2 Multiplication des virus dans l'organisme » (18 p.), `VIROLOGIE/…` (apostrophe courbe, espace avant `.pdf`) | **2025-26** | **la base** : chaque note du cours porte sa page (index du PDF ; les p. 11-18 portent les numéros imprimés 1-8) ; c'est ce que le lecteur ouvre (`chapitre=`) |
| `src-annales-virologie-7-pathogenes-viraux-iii` — « VIROLOGIE 7 - Pathogènes viraux III » | 2024-25 | 34 questions (SNC, mère-enfant, persistance) et la table p. 32 ; source des sessions par défaut |
| `src-annales-virologie-2-3-multiplication-des-virus` — « VIROLOGIE 2_3 - Multiplication des virus » | 2024-25 | sessions 2022/2023 S1 et 2021/2022 S1 (table p. 8) |
| `src-sujet-viro-2425` — « Sujet de virologie 2024/2025, session 1 » (examen du 09/01/2025, 16 p., 30 QCM) | 2024-25 | source de la session 2024/2025 (`SRC["sessions"]`) : Q1, Q4, Q11, Q12 ; sujet sans corrigé ; déclaration identique dans tous les chapitres de virologie qui en prennent une question |
| `src-fc-viro-fc5` — Ronéosaure, « FC n°5 Marqueurs viraux 2 » | 2025-26 | imprime l'annale 2024/2025 Q1 avec un verdict (p. 12), que cite l'explication de la carte ; source de la session jusqu'au 15/10/2026, qui pointe désormais vers le sujet ; déclarée avec `chapitre="chap-ue-virologie-fc4"`, la fiche de « Marqueurs viraux », à l'identique de `viro_pathogenes_1` (`pages=12` compris) |
| `src-fc-viro-fc8` — Ronéosaure, « FC n°8 - Pathogènes viraux III » | 2025-26 | la carte `mul-rv-encephalites` cite son tableau des infections du SNC (`fiche=`, p. 3) ; déclarée avec `chapitre="chap-ue-virologie-fc7"`, à l'identique de `viro_pathogenes_3` |
| VIRO n°1 (« Structure et réplication des virus ») | 2024-25 | 2023/2024 S1 Q1 ; la session cite VIRO n°7, l'explication de la carte nomme VIRO n°1 |
| FC n°1, 3, 5, 6, 7, 8, 10 et 11 2025-26 ; cours 2024-25 de la FC n°2 | — | citées dans le texte des justifications, à la page : surtout la FC n°8 (voies d'invasion du SNC, tableau des infections du SNC, congénitales et périnatales, p. 2-6, 11) et la FC n°11 (oreillons, PESS, lait, p. 3-5, 8-9) |
| erratas du Ronéosaure : cours 2025-26 (`Erratas Virologie.docx`) et annales 2024-25 | — | deux entrées sur la FC n°2 (p. 10, p. 15), reprises ; aucune sur les annales de ce chapitre |

Les annales sont déclarées avec les seuls champs communs (identifiant tiré du
nom du fichier) pour que les autres chapitres de virologie qui citent VIRO
n°7 ou VIRO n°2_3 les déclarent à l'identique. **Les FC n°5 et n°8 sont
partagées** : `viro_marqueurs` et `viro_pathogenes_1` déclarent aussi la
première, `viro_pathogenes_3` la seconde ; les déclarations doivent rester
identiques (sinon le dernier import écrase les autres).

Vérifications hors du cours, citées dans la carte : la transmission
mère-enfant du VIH-2 (revue systématique, Trans R Soc Trop Med Hyg 2022 ;
OMS), la transmission respiratoire du parvovirus B19 (CDC, HAN 00514, 2024) ;
l'étymologie (TLFi, Bailly, Gaffiot, Wiktionnaire, Académie française).

## Ce que le cours a dicté

- **Le rouge** : un seul mot, « libres » (p. 12) — les virus neurotropes
  arrivent libres du sang. Il est dans `mul-qc-snc-voies` A.
- **Le gris** est la voix des rédacteurs (« Pourquoi le virus infecte un organe
  particulier ? », « Le zona, c'est quoi ? », « Comment le SN peut-il être
  envahi ? ») : rien n'est « hors programme », tout est carté.
- **Ce qui n'est pas carté** : l'anecdote du mouton et du menton (p. 6), les
  « esquimaux » du VIH (p. 6), les entérovirus « éliminés sans destruction
  cellulaire » (p. 2, une phrase isolée que rien d'autre ne soutient), le
  virus Sindbis et le « clivage de Bcl-2 » (p. 4, dont le ronéo ne dit pas le
  mécanisme). La balance elle-même — p53 pro-apoptotique, Bcl-2
  anti-apoptotique — est cartée (`mul-qc-mort-cellulaire` D).
- **Ce que la FC n°2 ne détaille pas mais que ses annales demandent** —
  l'encéphalite post-infectieuse, la PESS et ses anticorps du LCR, la liste
  des virus congénitaux et périnataux, le dépistage de l'Ag HBs au 6e mois —
  est cité dans les justifications depuis la FC n°8 et la FC n°11 2025-26,
  et résumé par une carte de cours, `mul-rv-encephalites`, qui cite le
  tableau de la FC n°8 avec `fiche=` (p. 3), comme le prévoit le plan. Pour
  les annales, `fiche=` ne change rien (leur source est le polycopié de la
  session) : elles nomment la FC n°8 dans leur texte.

## Les erreurs du Ronéosaure 2025-26

Chacune est dite par **ATTENTION**, sans genre, dans la carte qui porte la
notion.

| Page | Ce que dit le Ronéosaure | Ce qui est juste | Carte | D'où |
|---|---|---|---|---|
| 5 | « les virus résistants sont le plus souvent enveloppés » | NON enveloppés (la phrase précédente ; cours 2024-25, p. 7 ; 2023/2024 S1 Q1 B, cotée vraie) | `mul-qc-reservoir-humain` B, `mul-an-2526-q4` D | en relisant |
| 6 | les moustiques, tiques et mouches piqueuses « ne sont pas des insectes » | moustiques et mouches sont des insectes (diptères), les tiques des acariens ; tous des arthropodes | `mul-qc-iatrogene-arthropodes` C | en relisant |
| 10 | « une trachéite, voire une laryngite » | la laryngite, puis la trachéite (cours 2024-25, p. 13) | `mul-qc-dissemination` E | errata de la promo |
| 15 | une des deux molécules d'ARN « rétro-transcrite en ARN » | en ADN | `mul-qc-vih-provirus` B | errata de la promo |
| 17 | « Exemple (herpès) : virus à ARN » | l'herpès est un virus à ADN | `mul-qc-virokines` A | en relisant (déjà dans le cours 2024-25) |
| 17 | le VIH-2 « ne se transmet pas de la mère à l'enfant » | point douteux : il se transmet beaucoup moins (environ 0,2 % sans traitement), mais il se transmet | `mul-qc-facteurs` D | en relisant |

Sans ATTENTION, parce qu'aucune réponse n'en dépend : « HPV (cancer côlon) »
(p. 5 : le col de l'utérus ; dit dans `mul-fa-excretion`), « HPLV » (p. 5,
HTLV), « arborivrus » (p. 6), « virémie (= virus sans le sang) » (p. 10 ; dit
dans `mul-fa-viremie`), « Koplick » (p. 12), « CMB » (p. 14, CMV), « VKJC »
(p. 14, virus JC et BK), « corps pileux de la nuque » (p. 13).

**Un chiffre que le cours 2025-26 donne de deux façons** : la chronicité de
l'hépatite B de l'adulte, 5 à 10 % (FC n°2 p. 16, FC n°3 p. 9) et 10 à 20 %
(FC n°8 p. 7, FC n°10 partie 2 p. 7). Les annales cotent vrais les deux
(2022/2023 S2 Q11 B ; 2021/2022 S2 Q11 E). Les cartes le disent sans trancher
(`mul-fa-chronicite`, `mul-qc-persistance` E, les deux annales).

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| Le SNC : voies sanguine et nerveuse (rage, HSV, poliovirus, entérovirus, arbovirus), méningites, encéphalites aiguë, post-infectieuse, chronique (PESS, LEMP) | 19 : 2024/2025 Q11 ; 2023/2024 S1 Q11, S2 Q11 ; 2022/2023 S1 Q. 10, S2 Q10 ; 2021/2022 S1 Q. 10, S2 Q10 ; 2020/2021 S1 Q24, S2 Q9 ; 2019/2020 S1 Q9, S2 Q9 ; 2018/2019 S1 Q24, S2 Q24 ; 2017/2018 S1 Q24, S2 Q24 ; 2016/2017 S1 Q26, S2 Q26 ; 2015/2016 S1 Q26, S2 Q26 |
| La transmission mère-enfant : congénitale (virémie, placenta), périnatale (filière génitale), lait maternel ; CMV, VZV, VIH, VHB, VHC, HSV-2, HTLV-1, B19 | 17 : 2024/2025 Q12 ; 2023/2024 S1 Q12, S2 Q12 ; 2022/2023 S1 Q. 8, S2 Q8 ; 2021/2022 S1 Q. 8, S2 Q8 ; 2020/2021 S1 Q29, S2 Q15 ; 2019/2020 S1 Q14, S2 Q14 ; 2018/2019 S1 Q29, S2 Q29 ; 2017/2018 S1 Q29, S2 Q29 ; 2016/2017 S1 Q30, S2 Q30 |
| Persistance et latence : provirus du VIH, polyomavirus, ganglions sensitifs, chronicité VHB / VHC | 4 : 2022/2023 S1 Q. 11, S2 Q11 ; 2021/2022 S1 Q. 11, S2 Q11 |
| Virus et cellule : permissivité, Tax, protéase 2A, apoptose, nécrose (Ebola) | 3 : 2024/2025 Q4 ; 2022/2023 S1 Q. 6 ; 2021/2022 S1 Q. 6 |
| Portes d'entrée : localisé ou systémique | 2 : 2022/2023 S1 Q. 7 ; 2021/2022 S1 Q. 7 |
| Transmission selon l'enveloppe ; infection localisée ou disséminée | 2 : 2023/2024 S1 Q1 (VIRO n°1) ; 2024/2025 Q1 (sujet ; verdict de la FC n°5, p. 12) |

**Rangement** : les 36 questions du SNC et de la mère-enfant sont ici, non
dans `viro_pathogenes_3`, parce que la FC n°2 porte ces deux sujets (§ III.D,
§ IV.B) et que le professeur les rangeait lui-même dans « Multiplication des
virus » (VIRO n°2_3, 2021-2024). **Doublons** : 2023/2024 S1 Q11-Q12, 2022/2023
S1 Q8, Q10, Q11 et 2021/2022 S1 Q8, Q10, Q11 sont imprimées dans VIRO n°2_3 et
VIRO n°7, avec la même clé : une seule carte chacune, et l'explication nomme
l'autre polycopié. Les autres questions de VIRO n°2_3 (grippe, gastro-entérites,
éruptions, sites de réplication) sont dans les chapitres de leur sujet.

## Le schéma cliquable et la planche

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `voies-snc-nu.svg` (`mul-zo-snc`) | les vaisseaux méningés, le plexus choroïde, le nerf olfactif, le ganglion sensitif, la corne antérieure de la moelle, les filets nerveux périphériques | 6 |

Une tête de profil (méninges et leurs vaisseaux, ventricule et plexus
choroïde, nerf olfactif, moelle) et la moelle en coupe (ganglion sensitif sur
la racine dorsale, corne antérieure et ses motoneurones, filets nerveux jusqu'à
une peau mordue), redessinées d'après la FC n°2 (p. 12-13) et la FC n°8 (p. 2).
La paire (cornes, racines) est dessinée des deux côtés, seul le droit porte
des zones. Chaque zone dit dans sa phrase quel virus prend cette route : les
annales échangent les routes d'un virus à l'autre (la rage au plexus choroïde,
l'HSV au ganglion lymphatique, le poliovirus par les nerfs). La version
légendée, `voies-snc.svg`, tirée des mêmes constantes, est en correction de la
zone et de 18 QCM. Repris du brouillon du 03/10 et relu : deux légendes qui se
chevauchaient ont été déplacées, une page corrigée.

**La planche** `mul-pl-evolution` : la diapositive des trois schémas
d'infection persistante (p. 15), légendes effacées par
`scripts/planche_depuis_image.py` — persistance avec réplication permanente,
latence et réactivation, virus lent ; deux intrus (infection aiguë
résolutive, infection abortive). L'aperçu de contrôle a été relu ; un reste
de « VHB VHC » sous le numéro 1 a été effacé en agrandissant le rectangle. La
question dit ce que le cours légende — en bleu la quantité de virus, en rouge
les signes cliniques (p. 14) — et rien des barres horizontales au-dessus des
courbes, que ni le ronéo ni la figure d'origine (Flint, *Principles of
Virology*) ne légendent.

**Illustrations** : 69 QCM sur 74 (93 %) portent une figure de la fiche ou le
schéma légendé en correction ; 91 notes sur 113. Les seize figures de
`media/` (extraites au brouillon du 03/10) ont été vérifiées une à une contre
leur page. Les cinq QCM sans figure (`mul-qc-attachement-transcription`,
`mul-qc-iatrogene-arthropodes`, `mul-qc-persistance-cancer`,
`mul-qc-facteurs`, `mul-qc-resistance`) n'en ont pas dans la fiche.

## Le sujet 2025/2026 (18/10/2026)

Le sujet de virologie de l'examen du 08/01/2026 (cahier de 30 QCM,
`src-sujet-viro-2526`, sans corrigé), déposé le 18/10/2026, apporte 4
questions à ce chapitre (Q.4, Q.5, Q.6, Q.13) ; les autres questions vont aux
chapitres de leur cours. Aucune n'était déjà en cartes. Chaque clé est déduite
du cours 2025-26, l'année de l'examen, proposition par proposition et page à
l'appui (`officielle=False`) ; les propositions déjà posées d'autres années
ont servi de contre-épreuve, et l'explication dit chaque reprise. Rédigées et
contre-vérifiées le 18/10/2026 : un rédacteur, un sceptique qui a refait
chaque clé sur le cours, un critique de complétude. Le profil des clés — A
souvent vraie, trois ou quatre vraies par question — est celui des sessions 1
officielles du Pr Hober (2021/2022 S1, 2023/2024 S1).

| Question | Clé imprimée | Retenue | Lecture |
|---|---|---|---|
| 2025/2026 Q.4 (`mul-an-2526-q4`) | aucune (sujet sans corrigé) | **ABCD** | Le virus tue la cellule (apoptose, nécrose) ou l'en protège selon son intérêt ; puis deux lignes de « Réservoirs et transmission ». |
| 2025/2026 Q.5 (`mul-an-2526-q5`) | aucune (sujet sans corrigé) | **ABE** | Porte d'entrée et devenir du virus : l'aérosol des déjections de rongeurs, la voie respiratoire sans signe respiratoire, l'épithélium où restent les HPV, la voie génitale du VHB, le placenta du VZV. |
| 2025/2026 Q.6 (`mul-an-2526-q6`) | aucune (sujet sans corrigé) | **ABE** | Comment le virus voyage : par le sang (poliovirus, plexus choroïde), libre ou associé aux cellules, ou par les nerfs seuls (rage, sans virémie) ; et les macules, immunopathologiques, sans virus. |
| 2025/2026 Q.13 (`mul-an-2526-q13`) | aucune (sujet sans corrigé) | **ABC** | Le tableau des infections du système nerveux central (FC n°8 2025-26, p. 3), colonne par colonne — méningite (entérovirus), encéphalite post-infectieuse (virus absent), encéphalite chronique (JC), myélite (HTLV-1, EBV, CMV, VZV) —, puis l'ESB, transmise à l'homme. |

Ce qui est signalé :

- Q.4 D, « transmis pas contacts étroits » : « pas » pour « par », gardé tel
  qu'imprimé. La justification porte un ATTENTION sur l'erreur du Ronéosaure
  qui suit la phrase juste (« les virus résistants sont le plus souvent
  enveloppés », p. 5), carte ajoutée à sa ligne du tableau des erreurs.
- Q.6 A, « moëlle », gardé tel qu'imprimé.
- Q.13 est rangée ici (thème `snc`), sur le précédent de 2024/2025 Q11. Sa
  figure est le tableau des infections du SNC de la FC n°8 (p. 3), qui répond
  à A-D : `pv3-tableau-snc.png`, copiée de `viro_pathogenes_3` et déclarée
  dans `IMAGES` avec la FC n°8 pour source. B ne dit pas « post-infectieuse »
  : la proposition est vraie par l'encéphalite post-infectieuse. Le chiffre de
  « 23 décès » de l'ESB (FC n°8, p. 4) n'est pas repris : aucune source sûre
  ne le confirme, et la clé n'en dépend pas.

## Les clés qui ne sont pas reprises telles quelles

Aucune clé imprimée n'est changée (`CONFLITS = []`).

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2024/2025 Q1 (FC n°5, p. 12) | « Vrai » / « Faux » du ronéo pour A-D, rien pour E | **C** (E fausse) | pas de table de corrections ; les verdicts A-D sont ceux du ronéo, E (les norovirus « se disséminent ») est déduite du cours : infection localisée. `officielle=False`. Énoncé vérifié mot pour mot sur le sujet du 09/01/2025 : identique |
| 2024/2025 Q4 (`mul-an-2425-q4`) | aucune (sujet sans corrigé) | **ABCD** | clé déduite du cours : Tax du HTLV-1 et l'IL-2 (p. 3), protéase 2A et eIF-4G (p. 3-4), nécrose par la glycoprotéine d'Ebola et apoptose induite (p. 4), E1B qui inhibe l'apoptose (p. 4-5). `officielle=False` |
| 2024/2025 Q11 (`mul-an-2425-q11`) | aucune (sujet sans corrigé) | **ADE** | clé déduite du cours : la rage, « jamais de virémie » (FC n°10 partie 2, p. 3) ; virus absent du SNC dans l'encéphalite post-infectieuse (FC n°8, p. 3) ; LEMP et PESS. `officielle=False` |
| 2024/2025 Q12 (`mul-an-2425-q12`) | aucune (sujet sans corrigé) | **CDE** | clé déduite du cours : congénitale par virémie maternelle, périnatale surtout par la filière génitale (FC n°8, p. 5) ; HTLV-1 rétrovirus transmis par le lait (FC n°2, p. 3 ; FC n°11, p. 9). `officielle=False` |

Clés gardées, avec un ATTENTION dans la justification :

- **2022/2023 S1 Q. 10 E** : « des anticorps spécifiques du virus ne sont
  retrouvés dans le LCR » — une négation tronquée. Lue « sont retrouvés », la
  proposition est fausse, comme la cote la table, et comme 2021/2022 S2 Q10 E
  et 2018/2019 S2 Q24 D ; la lecture « ne sont pas retrouvés » la rendrait
  vraie (2021/2022 S1 Q. 10 E). La carte dit les deux lectures.
- **2021/2022 S2 Q11 E** : le VHB chronique « dans 10 à 20 % » des cas, coté
  vrai — le chiffre de la FC n°8 ; la FC n°2 dit 5 à 10 %.
- **2022/2023 S2 Q11 B** : le même VHB chronique « dans 5 à 10 % » des cas,
  coté vrai aussi — le chiffre de la FC n°2 ; l'ATTENTION renvoie à l'autre
  fourchette, comme le font les cartes de `viro_pathogenes_3`.

Énoncés gardés tels qu'imprimés, à l'espacement près : « HSV1chemineparvoie… »
(VIRO n°2_3, mots collés à l'extraction) est rendu avec l'espacement de VIRO
n°7 ; « anti- virus », « post- infectieuse » perdent leur espace parasite ;
« plexus choroïdes », « moëlle », « des d'anticorps » restent.

## Le lexique

Huit termes, aux pages mesurées dans la fiche 2025-26 : syncytium (p. 2),
tropisme (11), virémie (9, 10), neurotrope (12, 13), iatrogène (5, 8),
endémique (6), latence (13, 15), arthropode (6). Le plan de cours (p. 1)
nomme aussi « tropisme » et « arthropodes » : cette page n'est pas comptée.
Chacun dit son origine grecque ou latine ; les racines enseignées par les FC
de sémantique (syn-, cyt(o)-, -trope, -émie, neur(o)-, iatr(o)-, -gène) les
citent à leur page.

**Iatrogène** existe déjà dans le lexique de la BMCT (`lex-iatrogene`,
`bmct_risques`) : l'identifiant d'une note étant global, il est repris ici
sous `lex-iatrogene-viro` (précédent : `lex-apoptose-bmcp`).

Les étymologies nouvelles (huit termes ; quatre racines : `virus (latin)`,
`en- (grec)`, `latere (latin)`, `-pode`) sont proposées dans le brouillon
`etym/viro_multiplication.json`, à verser dans `scripts/etymologies.json` ;
le texte écrit dans `donnees.py` est celui qu'écrirait
`appliquer_etymologies.py` (vérifié). `virus (latin)`, `en- (grec)` et
`-pode` sont aussi proposées par `viro_pathogenes_2` (et `virus (latin)` par
`viro_vaccins`), sous les mêmes clés et avec le même étymon : une seule entrée
chacune à verser.

## Questions pour Vincent

1. **La chronicité du VHB de l'adulte** : 5 à 10 % (FC n°2, FC n°3) ou 10 à
   20 % (FC n°8, FC n°10) ? Proposition du plan, appliquée : les deux sont
   acceptés, dit sur chaque carte qui en parle, jamais 70 à 80 %. Le ronéo
   2026-27 tranchera peut-être.
2. **2022/2023 S1 Q. 10 E**, la négation tronquée : lue « des anticorps …
   sont retrouvés » (fausse, clé imprimée gardée). D'accord ?
3. **2024/2025 Q1 E** : clé déduite (fausse : les norovirus restent dans le
   tube digestif). D'accord ?
4. **Le rangement** des 34 annales du SNC et de la mère-enfant dans ce
   chapitre plutôt que dans « Pathogènes viraux III » (proposition du plan) :
   d'accord ?
5. **Le VIH-2 et la transmission mère-enfant** (p. 17) : signalé comme point
   douteux ; le ronéo 2026-27 dira si le professeur le dit ainsi.

## À relire

0 carte `a-relire` : chaque carte de cours cite sa page de la fiche, chaque
annale sa session, son numéro et sa clé. Dix cartes tirées au hasard ont été
relues contre le texte du PDF et ses figures (`mul-qc-protease-2a`, `mul-qc-rage`,
`mul-fa-organes`, `mul-qr-lat`, `mul-qc-vih-provirus`, `mul-an-2122s2-q10`,
`mul-an-1718s1-q29`, `mul-an-2223s1-q7`, `mul-pl-evolution`,
`lex-viremie`).


## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier. Sous les annales, 57 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 13 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `virus-cellule` | 8 | 2 | 4 |
| `reservoirs-transmission` | 3 | 1 | 2 |
| `portes-entree` | 10 | 2 | 4 |
| `snc` | 13 | 3 | 20 |
| `mere-enfant` | 12 | 3 | 17 |
| `modes-evolution` | 11 | 2 | 4 |

**Les schémas** sont au nombre de 2 : `ech-multiplication`, « Le virus dans l'organisme · de la cellule au cerveau » (34 Simple, 8 Moyen, 30 annales ; 73 fichiers), et `ech2-mere-persistance`, « La mère et l'enfant · les virus qui restent » (23 Simple, 5 Moyen, 21 annales ; 50 fichiers). Une carte ou une annale va au schéma de son mécanisme. Ils sont décrits dans `schemas.py` (`ECH_MULTIPLICATION`, `ECH2_MERE_PERSISTANCE`, avec leurs `TROUS_*` et `LETTRES_*`, un `FICHIERS.update` chacun) et dessinés par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Source déclarée en plus** : `src-fc-viro-fc11`, à l'identique de `viro_vaccins_vivants`, pour `mul-ech-s22` et `mul-ech-s31`.

**Sans marche** :
- mul-an-2223s1-q7 A — « Les paramyxovirus provoquent des infections du tractus respiratoire » : la FC n°2 2025-26 ne nomme pas les Paramyxoviridae, la FC n°5 ne les cite que pour le métapneumovirus (p. 10) ; la justification de l'annale repose sur la FC n°11 (p. 3) et l'ICTV. Lettre posée sur « Voie respiratoire ».
- mul-an-1718s2-q24 E — les arbovirus « première cause d'encéphalite à l'échelle mondiale » : ce rang n'est écrit que dans la FC n°10 2025-26 (partie 1, p. 8), que le chapitre ne déclare pas ; s28 et m6 D préparent le reste (virus présent, voie sanguine). Lettre posée sur « Encéphalite aiguë ».

## Régénérer

```powershell
cd contenu\chapitres\viro_multiplication
..\..\..\app\.venv\Scripts\python.exe generer.py
```

`generer.py` est la copie exacte de
`.claude/skills/nouveau-chapitre/scripts/generer_modele.py`. La planche
numérotée se refait depuis `app/` :
`uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/viro_multiplication mul-pl-evolution --apercus <brouillon>`.
