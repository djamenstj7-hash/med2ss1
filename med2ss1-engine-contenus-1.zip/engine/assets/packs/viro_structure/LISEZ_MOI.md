# Structure et comportement des virus — paquet Virologie

87 notes, 157 cartes. Chapitre `chap-ue-virologie-fc1` de l'UE Virologie,
le premier des dix. Cours du **Pr Didier Hober, le 08/10/2025**, en deux
heures et deux fiches du Ronéosaure 2025-26 : « FC n°1 partie 1 » (10 h-11 h,
12 pages) et « FC n°1 partie 2 » (11 h-12 h, 14 pages). Annales du Ronéosaure
2024-25 : 17 questions, 6 sessions ; et deux du sujet de l'examen du 09/01/2025
(2024/2025 Q3 et Q6, sans corrigé). Examen de virologie le **5 janvier 2027**
(`EXAMENS`, portée sur l'UE, identique dans les dix paquets).

**18/10/2026** : 3 questions du sujet de virologie 2025/2026 (examen du
08/01/2026, sans corrigé) — Q.1, Q.2, Q.3 ; voir « Le sujet 2025/2026 ».

**Une fiche provisoire.** Aucun ronéo 2026-27 de virologie n'est paru (cours à
partir du 06/10/2026) : le chapitre est carté sur le Ronéosaure 2025-26
(décision de Vincent du 02/10), et le ronéo de l'année corrigera les cartes à
sa parution. Les deux sources portent leur année dans leur auteur
(« Ronéosaure 2025-26 ») : chaque carte de cours prend le tag
`cours-2025-26` et la puce « Cours 2025-26 ». Aucune carte ne dit « Absent du
cours 2026-27 », et les erreurs du Ronéosaure sont dites par un ATTENTION sans
genre (précédent d'`immuno_innee`) : la liste de la promo,
`contenu/ERRATA_RONEOS_2026-27.md`, ne concerne que les ronéos 2026-27.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 43 | 43 |
| QRU | 1 | 1 |
| Texte à trous | 15 | 80 |
| QROC | 9 | 9 |
| Recto-verso | 7 | 7 |
| Schéma cliquable | 2 | 7 |
| Planche à légender | 1 | 1 |
| Lexique | 9 | 9 |

Dont **22 annales** (toutes des QRM, la virologie n'a pas de QROC) sur 8
sessions, de 2018/2019 S1 à 2025/2026, et **22 QCM du cours** (21 QRM, une
QRU). Une justification par proposition, partout.

Huit thèmes, dans l'ordre du cours, tous nouveaux :

| Clé | Libellé |
|---|---|
| `taille-observation` | Taille des virus et méthodes d'observation |
| `classification-virale` | Classification des virus |
| `capside` | La capside et ses symétries |
| `genome-viral` | Le génome viral |
| `enveloppe-virale` | L'enveloppe virale : origine et fragilité |
| `types-infection` | Infections productive, abortive, persistante |
| `cycle-viral` | Le cycle de multiplication virale |
| `virus-cancer` | Virus et cancer |

Les huit libellés sont à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`), bloc « virologie » : le test
`test_tout_theme_du_paquet_a_son_libelle` échoue tant qu'ils n'y sont pas.
Aucune clé ne porte de chiffre ; `structure`, prise ailleurs avec un autre
libellé, est évitée.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-viro-fc1a` — Ronéosaure, « FC n°1 partie 1 - Structure et comportement » (12 p.), `VIROLOGIE/…` | **2025-26** | **la base**, fiche par défaut (`SRC["fiche"]`) ; `chapitre=` |
| `src-fc-viro-fc1b` — Ronéosaure, « FC n°1 partie 2 - Structure et comportement » (14 p. ; une espace avant `.pdf`), `VIROLOGIE/…` | **2025-26** | **la base**, citée par `fiche=FC1B` sur chaque carte de la partie 2 ; `chapitre=` |
| `src-annales-virologie-1-structure-et-replication-des-virus` — « VIROLOGIE 1 - Structure et réplication des virus » (7 p.) | 2024-25 | 14 cartes ; source de session du paquet (`SRC["annales"]`) |
| `src-annales-virologie-5-pathogenes-viraux` — « VIROLOGIE 5 - Pathogènes viraux » | 2024-25 | 2023/2024 S1 Q6, nommée dans son explication ; déclaration copiée de `viro_pathogenes_1` |
| `src-annales-virologie-2-3-multiplication-des-virus` — « VIROLOGIE 2_3 - Multiplication des virus » | 2024-25 | 2022/2023 S1 Q.5 et 2021/2022 S1 Q.5, nommées dans leur explication ; déclaration copiée de `viro_multiplication` |
| `src-sujet-viro-2425` — « Sujet de virologie 2024/2025, session 1 » (examen du 09/01/2025, 16 p., 30 QCM) | 2024-25 | 2024/2025 Q3 et Q6, `SRC["sessions"]["2024/2025"]` ; sujet sans corrigé ; déclaration identique dans tous les chapitres de virologie qui en prennent une question |
| cours 2024-25 (FC n°1 « Structure et réplication des virus », Pr Hober) | 2024-25 | appoint, cité dans le texte seulement : la polymérase « incluse dans le virion » (p. 7 et 9), l'ADN du VIH qui « se circularise » (p. 22), le VIH « hélicoïdal » (p. 24) |
| FC n°3, n°8, n°9 et n°10 partie 1 et 2 du Ronéosaure 2025-26 | 2025-26 | citées dans le texte, à la page, sans être déclarées (fiches d'autres chapitres) : neutralisation (FC n°3, p. 6), VIH et lymphocytes T CD4 (FC n°8, p. 14), « ARN polymérase embarquée » (FC n°9, p. 9), genres des Picornaviridae (FC n°10 partie 1, p. 3), anticorps anti-hémagglutinine (FC n°10 partie 2, p. 5) |
| `Erratas Virologie.docx` (cours 2025-26) et `ERRATAS ANNALES VIROLOGIE.docx` | — | trois entrées sur la FC n°1 et une sur VIROLOGIE 1, reprises (voir plus bas) |

VIROLOGIE 1 n'était déclaré par aucun autre chapitre : sa déclaration suit la
forme commune (`id`, `kind`, `titre`, `chemin_relatif`, `auteur`), que
`viro_multiplication` et `viro_virus_hote` doivent copier à l'identique s'ils
le citent. Les pages citées sont l'index des PDF (la couverture est la p. 1).

## Ce que le cours a dicté

- **Pas de gris** dans la FC n°1. **Le rouge** de la partie 2 (VIH, poxvirus,
  les trois types d'infection, les virus à ADN et à ARN, herpès,
  entérovirus, adénovirus, décapsidation, bourgeonnement, libération, les six
  étapes et leurs six mots, les trois cycles, les symétries hélicoïdale et
  icosaédrique) a chacun sa carte : `str-fa-types-infection`,
  `str-fa-six-etapes`, `str-qc-herpes`, `str-qc-enterovirus`,
  `str-qc-vih-cycle`, `str-qc-virus-complexes`, `str-qc-assemblage`,
  `str-zo-cellule`, `str-qr-decapsidation`.
- **« ATTENTION : étape clé »** (partie 2, p. 7), sur l'attachement : dans
  `str-fa-six-etapes` et `str-qc-entree` E.
- **« À ne pas confondre avec la forme de la capside ! »** (partie 1, p. 5) :
  `str-fa-criteres`, `str-qc-criteres`, `str-qr-premier-critere` — c'est le
  piège de six annales.
- **Les vidéos** (partie 2, p. 13-14), données « à titre de précision » : un
  QCM (`str-qc-videos`).
- **La virothérapie** (partie 2, p. 13) : une proposition (`str-qc-cancer` E)
  et un trou ; ni les gènes (IL-12, hNIS) ni les récepteurs (CD46, SLAM) ne
  sont cartés à part.

## Les erreurs du Ronéosaure 2025-26

Dites par un ATTENTION sans genre dans la carte qui porte la notion :

| Page | Le Ronéosaure écrit | Juste, et la source | Carte | Origine |
|---|---|---|---|---|
| partie 1, p. 4-5 | « lipoprotéines » à la surface de la grippe et de l'herpès | glycoprotéines virales, les spicules (p. 11 du même cours) | `str-qc-nus-enveloppes` E | errata de la promo |
| partie 2, p. 2 | le génome diploïde du VIH, « 2 segments identiques avec 2 fois la même information génétique » | deux copies du même ARN, un génome non segmenté : le tableau de la partie 1, p. 7, écrit « 2 copies » et réserve « seg. » aux génomes faits de segments différents (ICTV, Retroviridae) ; point douteux sur ce que le professeur répondrait | `str-an-2526-q1` E | trouvée en lisant |
| partie 2, p. 3 | les virus latents « provoquent des immunodépressions » | des pathologies qui apparaissent en cas d'immunodépression | `str-qc-types-infection` E | errata de la promo |
| partie 2, p. 5-6 | les schémas « virus à ADN » et « virus à ARN » sont échangés | celui de l'entérovirus est imprimé p. 5, celui de l'herpès p. 6 | légendes de `str-multiplication-enterovirus.png` et `str-multiplication-herpes.png` ; `str-qc-herpes` | errata de la promo |
| partie 2, p. 6 | le VIH « sort de ce lymphocyte B » | lymphocytes T CD4+ et macrophages (p. 14 du même cours ; FC n°8, p. 14) | `str-qc-vih-cycle` E | trouvée en lisant |
| partie 2, p. 9 | « une des deux molécules d'ARN (la positive) » | les deux sont identiques (p. 2), de polarité positive (tableau de la partie 1, p. 7 : « (+) ss, 2 copies ») | `str-qc-vih-cycle` A | trouvée en lisant |
| partie 2, p. 9 (et 2024-25, p. 22) | l'ADN du VIH « se circularise, rentre dans le noyau et va s'intégrer » | l'ADN intégré est linéaire ; les formes circulaires sont des impasses (Bin Hamid et al., AIDS Res Ther 2017) | `str-qc-vih-cycle` C | trouvée en lisant |
| partie 2, p. 10 (et 2024-25, p. 24) | le VIH parmi les virus « à symétrie hélicoïdale » | capside en cône tronqué (partie 2, p. 2 ; partie 1, p. 5) ; le tableau de la partie 1, p. 7, range les Retroviridae parmi les icosaédriques ; les annales cotent fausse « capside hélicoïdale » (VIROLOGIE 7 : 2023/2024 S1 Q5 A, 2019/2020 S2 Q15 A, 2018/2019 S1 Q30 A) | `str-qc-assemblage` C | trouvée en lisant |
| partie 1, p. 7 (et 2024-25, p. 9) | « les virus à ARN sont monocaténaires » ; ARN de sens positif traduit « sauf Retroviridae et Reoviridae » | les Reoviridae sont bicaténaires (p. 9 ; « ds » au tableau p. 7) | `str-qc-architecture` B | trouvée en lisant |
| partie 1, p. 11 | le VRS garde « son pouvoir muqueux » 30 minutes sur une blouse | son pouvoir infectieux (p. 7) | `str-qc-fragilite` D | trouvée en lisant |
| partie 1, p. 6, diapositive | le trait « Papillomavirus » mène à la plus petite particule | le tableau de la p. 7 la nomme Parvo ; le papillomavirus (Papova) est l'icosaèdre voisin | `str-pl-arn-adn`, numéro 10 | trouvée en lisant |

Sans ATTENTION, parce qu'aucune réponse n'en dépend : « capsule tubulaire »
(partie 1, p. 7), « péril féco-oral » (p. 7, dit dans `str-qc-fragilite`),
« Nicosae » pour icosaèdre (partie 2, p. 10), « EPV » pour EBV (p. 13, dit
dans `str-qc-cancer` et `str-fa-cancer`), « poliose » (p. 5).

Deux chiffres du cours, gardés tels quels et nuancés dans la carte : **20 %**
des cancers dus aux virus (partie 2, p. 13 ; le CIRC estime à environ 13 % la
part des cancers attribuables aux infections, de Martel et al., Lancet Glob
Health 2020) ; le poxvirus à **375 kpb** (partie 2, p. 2), au-delà de la
fourchette « 3,2 à 235 kbp » de la partie 1 (p. 10) et des « 130-280 kb » du
tableau (p. 7) — la QROC ne demande que son rang de géant.

## Ce que les annales ont dicté

| Poly | Session | N° | Clé imprimée | Retenue | Sujet | Carte |
|---|---|---|---|---|---|---|
| Sujet du 09/01/2025 | 2024/2025 | 3) | aucune (sans corrigé) | ACE | critères de classification, variabilité | `str-an-2425-q3` |
| Sujet du 09/01/2025 | 2024/2025 | 6) | aucune (sans corrigé) | C | polymérases embarquées, enveloppes, anticorps neutralisants | `str-an-2425-q6` |
| VIROLOGIE 1 | 2023/2024 S1 | Q.3 | ABDE | ABDE | critères de classification, Picornaviridae | `str-an-2324s1-q3` |
| VIROLOGIE 5 | 2023/2024 S1 | Q6 | AB | AB | polymérases embarquées, enveloppes, anticorps neutralisants | `str-an-2324s1-q6` |
| VIROLOGIE 1 | 2022/2023 S1 | Q.1 | E | **ACD** | grippe ARN–, polymérase, critères | `str-an-2223s1-q1` |
| VIROLOGIE 1 | 2022/2023 S1 | Q.2 | ACD | **AD** | capsides rage, HSV1, entérovirus | `str-an-2223s1-q2` |
| VIROLOGIE 1 | 2022/2023 S1 | Q.3 | AD | **CD** | génomes ADN, VHB, VIH, entérovirus | `str-an-2223s1-q3` |
| VIROLOGIE 1 | 2022/2023 S1 | Q.4 | CD | — | recopie de Q.3 | pas de carte |
| VIROLOGIE 2_3 | 2022/2023 S1 | Q.5 | D | D | lieux de réplication | `str-an-2223s1-q5` |
| VIROLOGIE 1 | 2021/2022 S1 | Q.1 | CDE | CDE | virus partout, taille, AFM, coxsackie, rage | `str-an-2122s1-q1` |
| VIROLOGIE 1 | 2021/2022 S1 | Q.2 | ABC | ABC | polymérases, critères | `str-an-2122s1-q2` |
| VIROLOGIE 1 | 2021/2022 S1 | Q.3 | ABCE | ABCE | capsides | `str-an-2122s1-q3` |
| VIROLOGIE 1 | 2021/2022 S1 | Q.4 | ABD | ABD | génomes | `str-an-2122s1-q4` |
| VIROLOGIE 2_3 | 2021/2022 S1 | Q.5 | C | C | lieux de réplication, phases de HSV1 | `str-an-2122s1-q5` |
| VIROLOGIE 1 | 2020/2021 S1 | Q.16 | D | D | génomes, forme de la particule | `str-an-2021s1-q16` |
| VIROLOGIE 1 | 2020/2021 S1 | Q.17 | C | C | origine des enveloppes | `str-an-2021s1-q17` |
| VIROLOGIE 1 | 2019/2020 S1 | Q.16 | B | B | génomes, forme non critère | `str-an-1920s1-q16` |
| VIROLOGIE 1 | 2019/2020 S1 | Q.17 | ABCE | ABCE | enveloppes, capsides | `str-an-1920s1-q17` |
| VIROLOGIE 1 | 2018/2019 S1 | 16) | CD | CD | génomes | `str-an-1819s1-q16` |
| VIROLOGIE 1 | 2018/2019 S1 | Q.17 | B | B | enveloppes, génomes segmentés ou circulaires | `str-an-1819s1-q17` |

Ce qui revient : les critères de classification (la taille de la
**particule** est un critère, sa **forme** non, la taille de la **capside**
non : sept questions) ; ADN ou ARN, mono- ou bicaténaire (neuf) ; VIH par la
membrane plasmique, herpès par la membrane nucléaire (six) ; rage
hélicoïdale, herpès et entérovirus icosaédriques (cinq) ; le lieu de
réplication de chacun (quatre) ; la polymérase dans la particule — oui pour la
grippe, non pour l'entérovirus (quatre). D'où `str-qc-criteres`,
`str-rv-adn-arn-lieux`, `str-rv-polarite` et le schéma de la cellule.

Les deux autres questions de VIROLOGIE 1 sont dans le chapitre de leur sujet,
selon le plan : 2023/2024 S1 Q.1 (transmission, EBV, VRS, astrovirus) dans
`viro_multiplication`, Q.2 (défenses de l'hôte) dans `viro_virus_hote`.

Énoncés altérés, gardés tels qu'imprimés et lus dans la justification :
2021/2022 Q.2 B « n'obtient pas » (ne contient pas), Q.2 E « BirnCDEaviridae »,
2019/2020 Q.17 C « nonocaténaire », 2022/2023 Q.1 A « le virus de le grippe »,
2021/2022 Q.4 B « hépatiteB », 2022/2023 Q.5 « (sont)exacte(s) ». Les titres
d'énoncé sans session (« Année 2022/2023 », « Année 2020-2021 ») prennent le
libellé de la table : « Session 1 ».

## Les schémas cliquables et la planche

| Fichier | Ce qu'on clique | Cartes | Pourquoi ce dessin |
|---|---|---|---|
| `icosaedre-axes-nu.svg` (`str-zo-icosaedre`) | trois points gris sur un icosaèdre vu dans l'axe d'une face : l'axe 5 (un sommet), l'axe 3 (le centre d'une face), l'axe 2 (le milieu d'une arête) | 3 | partie 1, p. 8 ; l'icosaèdre est calculé (vingt faces réelles, ombrées), et les trois points sortent des mêmes constantes que les zones. La correction, `icosaedre-axes.svg`, porte les symboles du cours (pentagone, triangle, ellipse) |
| `cellule-compartiments-nue.svg` (`str-zo-cellule`) | le noyau, la membrane nucléaire, le cytoplasme, la membrane plasmique : où l'herpès réplique son ADN et assemble sa capside, où il s'enveloppe, où l'entérovirus réplique son ARN, où bourgeonnent le VIH et la grippe | 4 | partie 1, p. 11-12 ; partie 2, p. 4-11 ; quatre lieux concentriques (`geometry.annulus`, et le noyau en polygone des mêmes sommets : les zones se touchent sans se recouvrir). La correction, `cellule-compartiments.svg`, nomme les virus de chaque lieu |

Le plan proposait une quatrième zone sur l'icosaèdre, « une face (hexons) » :
elle n'est pas faite, parce qu'une face n'est pas un lieu unique du dessin
(dix faces visibles, dont le centre de l'une porte l'axe 3) ; un clic juste
aurait été corrigé faux. Les hexons et les pentons ont leur texte à trous, leur
QROC et leur recto-verso (voir les questions pour Vincent).

**La planche** `str-pl-arn-adn` : les deux diapositives « ARN » et « ADN » de
la partie 1, p. 6, réunies en une image, légendes effacées par
`scripts/planche_depuis_image.py` — quatorze numéros (rotavirus, entérovirus,
VHC, chikungunya, VIH, Ebola, rage, grippe, VRS et ROR ; papillomavirus,
adénovirus, VHB, herpès et varicelle, variole), quatre intrus (coronavirus et
hantavirus, dessinés sans nom sur la diapositive ; virus de la mosaïque du
tabac, bactériophage). Les intrus du plan, « coronavirus, parvovirus B19 »,
ont perdu le parvovirus : le trait « Papillomavirus » de la diapositive mène à
l'icône que le tableau de la p. 7 nomme Parvo, et le parvovirus B19 aurait été
une réponse défendable au numéro 10 ; le virus de l'hépatite A et le
polyomavirus, envisagés, ont la même icône qu'un numéro (Picorna, Papova). Les
titres « ARN » et « ADN » restent. L'image numérotée et l'aperçu de contrôle
ont été relus ; les restes de lettres (jambages de « rage » et « grippe », un
reste de flèche, le bord de la photo d'ADN) ont été effacés.

**Illustrations** : 39 QCM sur 44 (89 %) portent une figure de la fiche ou un
schéma légendé en correction ; 66 notes sur 87. Vingt-cinq figures de la
fiche, extraites en PNG (réduites à 1 000 px, 256 couleurs : 4,1 Mo en tout),
toutes employées. Les cinq QCM sans figure (`str-qc-virus-partout`,
`str-qc-observation`, `str-qc-fragilite`, `str-qc-types-infection`,
`str-qc-cancer`) n'ont pas de schéma dans la fiche, ou seulement des photos
sans valeur de correction.

## Le sujet 2025/2026 (18/10/2026)

Le sujet de virologie de l'examen du 08/01/2026 (cahier de 30 QCM,
`src-sujet-viro-2526`, sans corrigé), déposé le 18/10/2026, apporte 3
questions à ce chapitre (Q.1, Q.2, Q.3) ; les autres questions vont aux
chapitres de leur cours. Aucune n'était déjà en cartes. Chaque clé est déduite
du cours 2025-26, l'année de l'examen, proposition par proposition et page à
l'appui (`officielle=False`) ; les propositions déjà posées d'autres années
ont servi de contre-épreuve, et l'explication dit chaque reprise. Rédigées et
contre-vérifiées le 18/10/2026 : un rédacteur, un sceptique qui a refait
chaque clé sur le cours, un critique de complétude. Le profil des clés — A
souvent vraie, trois ou quatre vraies par question — est celui des sessions 1
officielles du Pr Hober (2021/2022 S1, 2023/2024 S1).

| Question | Clé imprimée | Retenue | Lecture |
|---|---|---|---|
| 2025/2026 Q.1 (`str-an-2526-q1`) | aucune (sujet sans corrigé) | **ABC** | Le début du cours — 100 nm, trois outils d'observation, virus nus et enveloppés — et un piège : le génome diploïde du VIH (deux copies du même ARN), que le texte du ronéo appelle « 2 segments identiques », pris pour un génome segmenté. |
| 2025/2026 Q.2 (`str-an-2526-q2`) | aucune (sujet sans corrigé) | **BCDE** | Quatre phrases du cours de structure — classification, capsides hélicoïdale et icosaédrique, enveloppe — et un piège : « ne … que » des gènes structuraux, quand le génome de l'entérovirus porte aussi les protéines non structurales de sa réplication. |
| 2025/2026 Q.3 (`str-an-2526-q3`) | aucune (sujet sans corrigé) | **DE** | Un lieu par type de virus : les virus à ARN dans le cytoplasme (sauf la grippe), les virus à ADN dans le noyau (sauf les poxvirus), la membrane nucléaire pour l'herpès, virus à ADN ; et la décapsidation pour tous. |

Ce qui est signalé :

- Q.1 E, « le génome du VIH est segmenté » : le Ronéosaure 2025-26 écrit « 2
  segments identiques » (partie 2, p. 2), la diapositive « 2 copies » (tableau
  de la partie 1, p. 7), qui réserve « seg. » aux génomes faits de segments
  différents. Retenu faux, sur la diapositive, qui fait foi ; point douteux,
  puisque le professeur a dit « segments » selon le ronéo et que le sujet n'a
  pas de corrigé. ATTENTION et conflit déclarés ; ligne ajoutée au tableau des
  erreurs.
- Q.2 D, « 12 sommets » : le ronéo dit la symétrie cubique « icosaèdre dans la
  plupart des cas » (partie 1, p. 5) ; retenu vrai sur la p. 8 (12 sommets) et
  sur le tableau de la p. 7, qui ne connaît que l'icosaèdre hors des symétries
  hélicoïdale et complexe. Nuance dite dans la justification.
- Aucune coquille imprimée dans ces trois questions.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2022/2023 S1 Q.1 | E | **ACD** | la table de 2022/2023 S1 est décalée d'un cran : la clé imprimée sous chaque numéro est celle de la question suivante (errata des annales du Ronéosaure, vérifié proposition par proposition sur le cours et sur les autres sessions). Conflits sur A, C, D, E |
| 2022/2023 S1 Q.2 | ACD | **AD** | idem ; C (capside de HSV1 tubulaire) est fausse, 2021/2022 S1 Q.3 C le confirme. Conflit sur C |
| 2022/2023 S1 Q.3 | AD | **CD** | idem ; A (ADN généralement monocaténaire) est fausse, C (VIH, deux brins d'ARN identiques) vraie. Conflits sur A, C |
| 2022/2023 S1 Q.4 | CD | pas de carte | recopie mot pour mot les propositions de Q.3 ; sa clé imprimée, CD, est la vraie clé de Q.3 |
| 2024/2025 Q3 (`str-an-2425-q3`) | aucune (sujet sans corrigé) | ACE | clé déduite du cours : l'enveloppe et la dimension de la particule SONT des critères (partie 1, p. 6), la symétrie aussi (p. 5) ; E, la variabilité selon le génome, n'est pas dite en une phrase mais ses deux mécanismes le sont (erreurs des virus à ARN, réassortiment des génomes segmentés : FC n°3, p. 8-9) |
| 2024/2025 Q6 (`str-an-2425-q6`) | aucune (sujet sans corrigé) | C | clé déduite du cours : polymérase dans la particule de la grippe, pas dans celle de l'entérovirus ; HSV1 enveloppé à la membrane nucléaire ; entérovirus nu ; anticorps neutralisants anti-hémagglutinine |

Les trois cartes de 2022/2023 S1 portent `officielle=False`, un ATTENTION en
tête de chaque justification qui change, et `CONFLITS` dans `annales.py`
(7 lignes). Les deux de 2024/2025 portent `officielle=False` et le disent dans
leur explication (« Clé déduite du cours ») ; aucune de leurs propositions
n'est douteuse, aucun conflit.

Cas ouvert : aucun.

## Le lexique

Neuf termes, aux pages mesurées dans les deux fiches 2025-26 : capside
(partie 1 : 4, 5, 8-10 ; partie 2 : 2, 4, 5, 8-10, 14), capsomère (1 : 4, 5,
8, 9 ; 2 : 5, 9), icosaèdre (1 : 5, 8 ; 2 : 11), nucléocapside (2 : 2, 4, 6,
9, 10), monocaténaire (1 : 7, 9, 10), bicaténaire (1 : 9, 10), virion (2 : 2,
3, 5-7, 9, 10), décapsidation (2 : 4, 6), bourgeonnement (1 : 11, 12 ; 2 : 6,
10, 11). Chacun dit son origine grecque ou latine.

Les étymologies nouvelles sont **proposées** dans
`scratchpad/etym/viro_structure.json`, avec leurs sources (TLFi par l'API du
CNRTL, Wiktionnaire, Gaffiot, Bailly) ; `etymologies.json` n'est pas modifié
par ce chapitre. Racines nouvelles : `capsa (latin)`, `icosa-`, `-èdre`,
`bourgeon (français)` ; reprises des propositions sœurs, à la même clé et au
même texte : `catena (latin)` (`viro_antiviraux`), `virus (latin)`
(`viro_multiplication`) ; de la table : `mono-`, `bi- (latin)`, `-mère`,
`nuclé(o)-`, `dé- (latin)`. Les définitions et les racines disent déjà, mot
pour mot, ce qu'`appliquer_etymologies.py` en écrira.

## Questions pour Vincent

1. **Le VIH « à symétrie hélicoïdale »** (partie 2, p. 10, déjà dans le cours
   2024-25) contre « capside en cône tronqué » (partie 1, p. 5 ; partie 2,
   p. 2) et trois annales qui cotent fausse « une capside hélicoïdale » pour
   le VIH. Proposition du plan, appliquée : la carte suit les annales et le
   reste du cours (cône tronqué), et l'ATTENTION le dit
   (`str-qc-assemblage` C). À confirmer.
2. **La quatrième zone de l'icosaèdre** (« une face, les hexons ») n'est pas
   faite : un clic sur une autre face, juste, aurait été corrigé faux. Les
   hexons sont cartés autrement. Faut-il un second schéma, une capside en
   capsomères (pentons et hexons dessinés), pour les cliquer ?
3. **Le numéro 10 de la planche** : la diapositive mène « Papillomavirus » à
   l'icône du parvovirus. La planche garde la légende de la diapositive et le
   dit dans la phrase du numéro. Préfères-tu déplacer le numéro sur l'icône
   Papova, voisine, au risque de s'écarter de la diapositive du professeur ?

## À relire

Aucune carte `a-relire` : chaque carte de cours porte sa page dans l'une des
deux fiches 2025-26, chaque annale une clé vérifiée sur le cours. À la
parution du ronéo 2026-27 de ce cours, relire toutes les cartes contre lui :
pages, chiffres (100 nm, 162 et 252 capsomères, 3,2 et 235 kbp, 375 kpb, 20 %,
10 000 virions), et les erreurs du tableau ci-dessus.

## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier. Sous les annales, 38 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 6 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `taille-observation` | 3 | 1 | 2 |
| `classification-virale` | 6 | 1 | 4 |
| `capside` | 6 | 1 | 3 |
| `genome-viral` | 11 | 1 | 7 |
| `enveloppe-virale` | 5 | 1 | 3 |
| `cycle-viral` | 7 | 1 | 3 |

**Le schéma** `ech-virus-types`, « Le virus · le voir, le classer, le reconnaître », donne 67 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_VIRUS_TYPES`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Une citation précisée** (C29, 19/10) : 2021/2022 S1 Q2 E cite désormais la FC n°10 partie 1 2025-26, p. 3, qui range les entérovirus parmi les Picornaviridae ; la partie 1, p. 6, ne nomme que la famille.

**Sans marche** :
- str-an-2425-q3 E — la variabilité selon la nature et la structure du génome n'est dite que par la FC n°3 2025-26 (p. 8-9), hors des sources de ce chapitre ; lettre posée, sans marche, sur la case des critères (nature et architecture du génome).
- str-an-2324s1-q3 E — les genres Enterovirus et Hepatovirus dans la famille des Picornaviridae : tableau de la FC n°10 partie 1 2025-26 (p. 3), hors des sources ; la FC n°1 ne nomme pas le genre de l'entérovirus ni sa famille. Lettre posée, sans marche, sur la case des noms (picornaviridae).
- str-an-2223s1-q1 E et str-an-2122s1-q2 E — l'entérovirus rangé chez les Polyomaviridae ou les « BirnCDEaviridae » : la FC n°1 ne relie pas le genre Enterovirus à sa famille (le tableau dit « Picorna », sans genre ; la figure de nomenclature de la partie 2, p. 12, prend l'exemple de l'herpès) ; str-ech-s38 dit seulement ce que signifie picornaviridae. Lettres posées, sans marche, sur la case des noms ; E de 2223s1-q1 figure aussi dans CONFLITS (table décalée), et sa carte d'annale porte déjà l'ATTENTION.

## Régénérer

```powershell
cd contenu\chapitres\viro_structure
..\..\..\app\.venv\Scripts\python.exe generer.py
```

La planche se refait depuis `app/`, si ses rectangles changent :
`uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/viro_structure str-pl-arn-adn --apercus <brouillon>`.
Les figures ont été extraites des deux PDF de la FC n°1 (images incorporées,
réduites à 1 000 px de large et 256 couleurs ; la planche garde ses
1 149 × 1 082 px, celles de ses repères).
