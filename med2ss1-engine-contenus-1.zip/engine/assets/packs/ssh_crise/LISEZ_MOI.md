# Santé mentale : psychologie de la crise — paquet SSH

74 notes, 162 cartes. Chapitre `chap-ue-ssh-fc7` de l'UE SSH (`ordre=10`, le
numéro de la FC 2025-26). Cours du **Pr Vaiva, le 29/10/2025, de 11 h à 12 h**,
dans le **Ronéosaure 2025-26** (FC n°10 « Santé mentale », 9 pages) ; l'annale
du Ronéosaure 2024-25 (polycopié SSH 7, une session) et la QROC 10 du sujet de
SSH 2024/2025, déposé le 15/10/2026. Examen : écrit de SSH du
6 janvier 2027 (« 10 QROC + 1 QR »).

**Fiche provisoire** (décision de Vincent du 02/10) : le ronéo 2026-27 de ce
cours n'est pas encore paru. Chaque carte de cours cite la FC 2025-26 à sa page
et porte le badge « Cours 2025-26 » (tag `cours-2025-26`, lu dans l'auteur de la
source) ; le ronéo 2026-27 la corrigera quand il sortira. Aucune carte n'est
« Absent du cours 2026-27 ».

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 15 | 15 |
| Texte à trous | 16 | 99 |
| QROC | 22 | 22 |
| Recto-verso | 11 | 11 |
| Lexique | 8 | 8 |
| Schéma cliquable | 1 | 6 |
| Planche à légender | 1 | 1 |

Dont **2 annales** (2022/2023 S1 et 2024/2025 S1, recto-verso). Six thèmes, dans l'ordre du
cours ; les six clés sont nouvelles, et leurs libellés restent à ajouter à
`THEME_LABELS` (`app/src/med_engine/application/scopes.py`) :

| Clé | Libellé | Notes |
|---|---|---|
| `crise-definition` | La crise : définition et types | 11 |
| `crise-progression` | La progression d'une crise | 12 |
| `psychotraumatisme` | Le psychotraumatisme | 10 |
| `crise-changement` | La crise, occasion de changement | 11 |
| `intervention-crise` | Les dix principes de l'intervention de crise | 11 |
| `palo-alto` | La grille de Palo Alto | 10 |

`crise-changement` tient toute la partie « Vision de la crise » (p. 5-6) : la
crise vue comme une photo (l'impasse) n'y est que le premier temps de la crise
vue comme un film, qui en fait une occasion de changement.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-ssh-crise` — Ronéosaure, « FC n°10 Santé mentale » (9 p.) | 2025-26 | le cours ; `SRC["fiche"]`, ses trois figures ; fiche provisoire en attendant le ronéo 2026-27 |
| `src-annales-ssh-7-psychologie-de-la-crise` — « SSH 7 - Psychologie de la crise » (1 p.) | 2024-25 | l'annale de 2022/2023 ; déclarée ici pour la première fois, avec les seuls champs convenus (id, kind, titre, chemin_relatif, auteur) |
| `src-sujets-ssh-2425` — « Sujets de SSH 2024/2025, session 1 » (examen du 10/01/2025, 1 QR et 10 QROC, sans corrigé), déposés le 15/10/2026 | 2024-25 | la source de la session 2024/2025 S1 (`SRC["sessions"]`), la QROC 10 ; déclarée à l'identique dans tous les chapitres de SSH qui en cartent une question |

Les pages citées sont celles du PDF ; la p. 1 est la couverture et le plan. Lus
en appoint, sans être déclarés : le cours 2024-25 du même professeur
(Ronéosaure, FC n°7), pour vérifier l'annale et trancher les erreurs du ronéo
2025-26 ; l'errata des cours SSH 2025-26 (deux entrées pour cette FC) et celui
des annales 2024-25 (vide pour ce polycopié).

Les en-têtes du ronéo, de l'errata et du polycopié portent des noms
d'étudiants : aucun n'est repris.

## Ce que le cours a dicté

- **Le rouge** (« aiguës », « transitoires », p. 2) fait la définition :
  `crise-fa-definition`, `crise-qr-adjectifs`, `crise-qc-definition`.
- **Le gris** n'est que la voix des rédacteurs : il se carte. Une seule
  consigne du professeur retire une notion du partiel : la confrontation à sa
  propre mort, « il ne nous interrogera pas là-dessus » (p. 5). Elle porte le
  tag `edn` (`crise-rv-representation`), avec l'abstraction de la mort qui la
  prolonge (`crise-rv-abstraction`, p. 5) — proposition du plan C16, que
  l'explication de la seconde carte donne pour un choix du chapitre.
- **Les dix principes** sont donnés « pas dans l'ordre » : aucune carte n'exige
  leur ordre (l'annale non plus). **La grille de Palo Alto**, au contraire, a
  « un ordre chronologique » : sa carte à trous, ses QCM et l'annale de
  2024/2025 (« dans le bon ordre ») le demandent.
- **Pas de carte** pour l'échiquier de la p. 9 (un jeu des rédacteurs), ni pour
  les anecdotes qui n'enseignent rien (l'interne et l'adultère, la formation au
  Québec, sinon comme source du principe 8).

## Ce que les annales ont dicté

| Poly | Session | N° | Corrigé imprimé | Sujet | Carte |
|---|---|---|---|---|---|
| SSH 7 | 2022/2023 S1 | QROC X | « Pas de correction. Voir cours. » | citer au moins 8 des 10 « commandements » de l'intervention de crise | `crise-an-2223s1-qroc` (recto-verso) |
| sujet 2024/2025 | 2024/2025 S1 | QROC 10 | aucun (sujet sans corrigé) | citer dans le bon ordre les 5 questions de la grille de Palo Alto | `crise-an-2425s1-qroc10` (recto-verso) |

Les « commandements » de l'énoncé sont les dix « principes » du cours (FC n°10
2025-26, p. 6-8), les mêmes, dans le même ordre, qu'en 2024-25 (FC n°7,
p. 8-11). Ils ont aussi leurs deux textes à trous, deux QCM, quatre QROC et
deux recto-verso, et le schéma `dix-principes.svg` en correction. Les cinq
questions de Palo Alto sont les mêmes, dans le même ordre, en 2025-26 (FC n°10,
p. 8-9) et en 2024-25, l'année de la question (FC n°7, p. 12) ; elles ont leur
texte à trous, deux QCM, cinq QROC, deux recto-verso et le schéma
`grille-palo-alto.svg`.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2022/2023 S1 QROC X (dix commandements) | aucune (« Pas de correction. Voir cours. ») | verso déduit des p. 6-8, `officielle=False` | la table ne donne rien ; « clé déduite du cours, absente de la table de corrections » ouvre l'explication |
| 2024/2025 S1 QROC 10 (grille de Palo Alto) | aucune (sujet sans corrigé) | verso déduit des p. 8-9, dans l'ordre, `officielle=False` | le sujet n'a pas de corrigé ; « communication de crise » du sujet = la « grille systématique » du cours |

Aucun QCM d'annale : `CONFLITS` est vide.

## Les erreurs du ronéo 2025-26

Le Ronéosaure n'est pas le ronéo de l'année : chaque erreur est portée par un
**ATTENTION nu** dans la carte qui tient la notion, et rien n'entre dans
`contenu/ERRATA_RONEOS_2026-27.md`.

| Page | Le ronéo dit | Retenu | Sorte | Carte |
|---|---|---|---|---|
| 2 | « On définit une situation **triste** comme l'ensemble des manifestations aiguës de l'histoire d'un patient » | deux lectures, dites dans la carte : « situation de crise » (errata de la promo, sans avis du bureau), ou une opposition voulue entre la crise et la situation triste (les rédacteurs soulignent « crise » puis « triste »). Le cours 2024-25 n'a pas cette phrase (FC n°7, p. 2) : la carte s'en tient à la définition de la crise, et le lexique ne reprend pas la phrase | point douteux | `crise-fa-definition` |
| 2 | « des manifestations émises **conditionnelles** et aiguës » | aiguës et transitoires, les deux adjectifs en rouge, déjà en 2024-25 (FC n°7, p. 2) | point douteux | `crise-fa-definition` |
| 3 | « La situation de crise c'est tout ce qu'il y a **à droite du pic** » | le cours 2024-25 dit « le sommet de la courbe » (FC n°7, p. 3) ; la figure met la phase aiguë au pic, la récupération à sa droite | point douteux | `crise-zo-progression` |
| 4 | « Trauma = rupture de la continuité **en grec** » | le grec τραῦμα veut dire « blessure » (TLFi, Bailly) ; la rupture de continuité est la définition médicale de la plaie. C'est le cours lui-même (FC n°7 2024-25, p. 5) : à l'examen, psychotrauma = rupture de la continuité psychique | le cours | `crise-fa-effraction` ; l'étymologie du lexique (`lex-psychotraumatisme`, `lex-traumatogene`) |
| 6 | « Le professeur montre un **kanji japonais** » ; ce signe « veut aussi bien dire danger, impasse, rupture qu'occasion d'évoluer » | l'errata propose « idéogramme chinois » (sans avis du bureau) ; les deux se défendent, 危機 s'écrivant de même en chinois (wēijī) et en japonais (kiki). La lecture « danger + opportunité » est une légende : 機 jī y est le moment décisif (V. Mair, pinyin.info). C'est le cours lui-même (FC n°7 2024-25, p. 8) : à l'examen, la crise a deux faces ; l'idée de danger et d'occasion est celle de Caplan (Feinstein, J Psychiatr Pract 2021) | le cours | `crise-qc-changement` D, `crise-qr-ideogramme` |

Sans carte, parce qu'aucune n'en dépend : la crise de l'adolescence que « les
pédopsychiatres l'estiment à 25-30 ans » (p. 3, phrase incompréhensible, plan
C16) ; les personnes vulnérables qui « vont avoir une maladie mentale » (p. 4 :
c'est la maladie qui rend vulnérable, comme le disait le cours 2024-25) ; la
durée de 6 à 12 semaines (p. 3), qui est bien le cours (le même en 2024-25) —
Caplan disait six semaines environ, une ligne d'explication le rappelle dans
`crise-fa-duree` et `crise-qc-duree` ; le plan mal numéroté (p. 1), « Palo
ALT », la grille « systématique » (l'école de Palo Alto est systémique).

## Les schémas et les figures

**Trois figures de la FC 2025-26**, extraites en PNG (256 couleurs) : la
progression de la crise (p. 3, 923 × 654), les types de crise (p. 4, agrandie
trois fois, à 894 × 582, depuis une image de 298 × 194), l'idéogramme (p. 6).
Pas l'échiquier de la p. 9.

**Un schéma cliquable** (`schemas.py`), la figure du cours en correction :

| Fichier | Ce qu'on clique | Pourquoi ce dessin |
|---|---|---|
| `progression-nu.svg` | les trois états sur l'axe de gauche (équilibre, vulnérabilité, crise) et les trois phases sur la courbe (désorganisation, phase aiguë - passage à l'acte, récupération) : 6 zones | la courbe de la p. 3 redessinée, sans une légende ; les états se lisent de bas en haut, les phases de gauche à droite ; la récupération est un polygone en L (la redescente dans la bande de crise et la place de sa légende dans la bande de vulnérabilité), séparé des deux autres phases par deux pixels |

**Une planche à légender** (`crise-pl-types`, `scripts/planche_depuis_image.py`) :
la figure de la p. 4, ses cinq légendes blanchies et numérotées — crise
psychosociale, crise psychiatrique, état de crise, état de vulnérabilité, état
d'équilibre — avec deux intrus du même champ, « Crise psychotraumatique » et
« Phase de récupération ». Le titre de la figure reste ; l'aperçu de contrôle a
été regardé : aucun reste de lettre.

**Quatre schémas redessinés** pour les corrections : `psychotraumatique.svg`
(« de la cave au grenier », p. 4), `photo-film.svg` (p. 5-6),
`dix-principes.svg` (p. 6-8), `grille-palo-alto.svg` (p. 8-9).

**13 QCM sur 15 illustrés (87 %)**, 36 notes sur 74. Sans figure :
`crise-qc-compulsion` et `crise-qc-types` — aucune figure du cours ne montre la
compulsion de répétition ni la provenance des crises.

## Le lexique

Huit termes, ceux du plan C16 ; aucun n'existait (vérifié contre les `lex-*` de
tous les chapitres). « Crise » seul est évité : `ssh_anatomie` accueille « Crise
scientifique ». Pages mesurées dans le texte de la FC 2025-26 (motif de
`chercher_pages.py`, plan de la p. 1 exclu). Trois pages viennent du plan C16
et non de la forme exacte : « Intervention de crise » p. 6 (la FC écrit
« Intervention de la crise », titre du IV) ; « Psychotraumatisme » p. 5 (la FC
y écrit « Psycho-trauma ») ; « Vulnérabilité » p. 3 (« vulnérables », et
« État de vulnérabilité » dans la figure, qui est une image).

| Terme | Origine | Pages |
|---|---|---|
| Situation de crise | latin situs + grec krísis | 2, 3, 6, 7, 8 |
| Intervention de crise | latin intervenire + grec krísis | 6 |
| Psychotraumatisme | grec psukhḗ + traumatismós | 4, 5 |
| Traumatogène | grec traûma + -genḗs | 4 |
| Compulsion de répétition | latin compulsio + repetitio | 2 |
| Vulnérabilité | latin vulnerabilis | 3, 4 |
| Diachronique | grec diá + khrónos | 5 |
| Minimal change | latin minimus + cambiare | 9 |

Trois racines sont enseignées par la FC de sémantique et la citent :
`psych(o)-` et `-gène` (1/2, p. 6), `dia-` (2/2, p. 11). Racines reprises de la
table commune : `krisis (grec)` (même sens que dans `ssh_anatomie`),
`inter (latin)`, `venire (latin)`, `psych(o)-`, `-gène`, `dia-`. Racines
nouvelles proposées à `etymologies.json` : `situs (latin)`, `traumat(o)-`,
`compellere (latin)`, `repetere (latin)`, `vulnus (latin)`, `chron(o)-`,
`minimus (latin)`, `cambiare (latin)`, et les huit termes ; vérifiées sur le
TLFi (CNRTL), le Bailly et le Gaffiot. Les textes du lexique sont déjà écrits
dans la forme que `appliquer_etymologies.py` produirait (vérifié en appliquant
la proposition à une copie).

## Questions pour Vincent

- **L'abstraction de la mort** (III.C, p. 5) : le professeur n'a exclu du
  partiel que la confrontation à sa propre mort (« il ne nous interrogera pas
  là-dessus ») ; le plan C16 étend le tag `edn` à l'abstraction de la mort, qui
  la prolonge. Appliqué, et dit dans l'explication de la carte. Faut-il la
  remettre au programme du partiel ?
- **L'idéogramme** : la carte répond comme le professeur (danger et occasion de
  changer) et dit la référence dans l'ATTENTION. Le garder ainsi pour l'écrit ?
- **« Situation triste »** (p. 2) : l'errata de la promo lit « situation de
  crise », mais le soulignement des rédacteurs peut opposer la crise à une
  simple situation triste. La carte de définition dit les deux lectures et ne
  carte pas cette phrase. Le ronéo 2026-27 tranchera-t-il ?
- **Le PDF** de la fiche : `outils/copier_les_cours.py` doit connaître le
  dossier « ROneosaure 2025-2026 sans annles/S1 25-26/examen janvier » et le
  préfixe `SSH/` du `chemin_relatif` (même question que pour BMCT et
  l'immunologie).

## À relire

**Aucune carte `a-relire`** : chaque note cite une page de la FC 2025-26 ou une
source sûre. Quand le ronéo 2026-27 de ce cours paraîtra, relire chaque carte
sur lui et retirer le badge « Cours 2025-26 ».

## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier (BMCP) ou du 6 janvier (SSH, papier). Sous les annales, 15 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 2 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `intervention-crise` | 10 | 1 | 1 |
| `palo-alto` | 5 | 1 | 1 |

**Le schéma** `ech-crise`, « La personne en crise · dix principes, une grille », donne 18 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_CRISE`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Constantes ajoutées** à `annales.py` (`_SCHEMA_LETTRES`, `_SCHEMA_NU`) : les annales de SSH sont toutes des QROC, rangées dans `ANNALES_QROC` ; chacune reçoit le schéma nu, et les marches la préparent sans lettre.

**Sans marche** :
- crise-an-2223s1-qroc : les détails de chaque principe (les structures de protection du principe 9, l'exemple du prisonnier) restent dans les notes, sans marche propre

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```

Pour refaire l'image numérotée de la planche, depuis `app/` :
`uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/ssh_crise crise-pl-types --apercus <brouillon>`.
