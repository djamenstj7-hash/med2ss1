# Régression linéaire multiple — paquet Biomédecine quantitative

98 notes, 129 cartes. Chapitre `chap-ue-biomed-quanti-fc12` de l'UE
Biomédecine quantitative, huitième de l'UE. Cours du **Pr G. Ficheur, le
18/11/2025, de 9 h à 10 h**, dans le **Ronéosaure 2025-26** (FC n°8, 8 pages) ;
les annales de deux polycopiés du Ronéosaure 2024-25 (18 sessions citées).
Examen : partiel du mercredi 16 décembre 2026.

**Fiche provisoire** (C15, décision de Vincent du 02/10) : le cours de l'année
2026-27 n'est pas encore paru. Chaque carte de cours cite la FC 2025-26 à sa
page, et l'application montre « Cours 2025-26 » ; le ronéo 2026-27 la corrigera
quand il sortira. Aucune carte n'est « Absent du cours 2026-27 ».

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 73 | 73 |
| QRU | 2 | 2 |
| Texte à trous | 7 | 34 |
| QROC | 5 | 5 |
| Recto-verso | 3 | 3 |
| Lexique | 7 | 7 |
| Schéma cliquable | 1 | 5 |

Dont **63 annales** sur 18 sessions (61 du polycopié « 2. Régression
linéaire », 2 du polycopié « 12 - Régression linéaire multiple »), et 12 QCM de
cours.

Huit thèmes. `regression` et `correlation` (ECL Remédiation) et `hors-fiche`
(sémiologie) existent, et leur libellé dit vrai ici ; les cinq autres clés sont
nouvelles et leurs libellés restent à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) :

| Clé | Libellé | Notes |
|---|---|---|
| `types-etudes` | Types d'études | 7 |
| `niveaux-preuve` | Niveaux de preuve | 2 |
| `regression` *(existante)* | Régression linéaire | 23 |
| `moindres-carres` | Moindres carrés, résidus et hypothèses | 17 |
| `coefficients` | Lire les coefficients d'un modèle | 20 |
| `qualite-modele` | Qualité du modèle et parcimonie | 14 |
| `correlation` *(existante)* | Corrélation | 8 |
| `hors-fiche` *(existante, tag en plus du thème)* | Tombé en annales, absent de la fiche | 46 |

Le plan C15 proposait pour `qualite-modele` « R², parcimonie et individus
influents » : le « ² » est un chiffre pour Python (`"²".isdigit()` est vrai), et
un libellé de thème n'en porte aucun (`test_le_chapitre_se_decoupe_en_themes_lisibles`).

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-biomed-rlm-2526` — Ronéosaure, « FC n°8 Régression linéaire multiple » (8 p.) | 2025-26 | le cours ; `SRC["fiche"]`, 11 de ses figures et l'arbre des types d'études redessiné |
| `src-fc-biomed-rlm-2425` — Ronéosaure, « FC n°12-Régression linéaire multiple » (9 p.) | 2024-25 | le cours de l'an passé du même professeur, pour l'analyse des résidus (p. 9) et la linéarité d'une variable quantitative (p. 8-9), que la FC 2025-26 annonce sans les faire ; deux cartes de cours le citent (`fiche=`) |
| `src-annales-2-regression-lineaire` — « 2. Régression linéaire » (32 p.) | 2024-25 | 17 sessions de 2015/2016 S1 à 2023/2024 ; table p. 31-32 |
| `src-annales-12-regression-lineaire-multiple` — « 12 - Régression linéaire multiple » (24 p.) | 2024-25 | la session 2023/2024 S2 (`SRC["sessions"]`) ; table p. 24 |

Les deux sources d'annales sont déclarées selon la règle commune de C15 (id tiré
du nom du fichier, cinq champs, rien d'autre) : tout chapitre qui les cite
(`biostat_scores`, `biostat_regression_logistique`) doit les déclarer **à
l'identique**. Lus en appoint sans être déclarés : le cours n°2 2024-25
(« Régression linéaire ») et le Charonéo 2023-24 (n°12), l'errata des cours
2025-26 (une entrée pour la FC n°8, p. 3) et celui des annales 2024-25 (aucune
entrée pour la régression linéaire).

Les en-têtes des ronéos, des erratas et des polycopiés portent des noms
d'étudiants : aucun n'est repris. Le polycopié n°12 attribue le cours au
« Pr Décaudin » : c'est le Pr Ficheur, on ne reprend pas l'attribution.

## Ce que le cours a dicté

- **Le rouge** ne marque que les deux titres de parties (I. Types d'études,
  II. Régression linéaire multiple) ; **pas de gris**. Tout se carte, dans la
  limite des frontières du plan.
- **Les frontières (plan C15)** : les cohortes, les registres et les
  cas-témoins comme types d'études, la lecture d'une table 1 et les courbes de
  Kaplan-Meier sont au chapitre de l'analyse descriptive (FC n°7, thèmes
  `tableau-1` et `kaplan-meier` du plan) ; le facteur de confusion et
  l'ajustement aux chapitres 6 et 11 ; la régression logistique au chapitre 11 ;
  les trois familles de modèles au chapitre 1. Ici : transversal contre
  longitudinal, le cross-over, l'équipoise, le RR impossible en cas-témoins, les
  niveaux de preuve, puis toute la régression linéaire multiple. Les deux
  cartes d'abord écrites sur Framingham et sur le registre lillois des MICI ont
  été retirées pour cette raison ; à la relecture, les deux QCM sur les tables
  d'exemple des p. 3-4 (table 1 du vaccin ARN, C. difficile ; fractures après
  chirurgie bariatrique et leurs courbes de Kaplan-Meier) l'ont été aussi : la
  FC n°7 reprend ces quatre exemples aux p. 6-7, et son chapitre les carte.
  Les notions restent citées dans les explications.
- **L'analyse des résidus** : la diapositive de la p. 5 dit « non vu dans ce
  cours ». Neuf annales interrogent pourtant le graphique des résidus : une
  QROC (`rlm-qr-heteroscedasticite`) et le schéma `residus-lecture.svg` la
  reprennent du cours 2024-25 du même professeur, tag `hors-fiche`.
- **L'article de la p. 7** (JAMA Netw Open 2025) : la carte retient l'étude
  transversale, le score de 5 à 30, l'ajustement, les 10 participants par
  variable et la lecture de la figure de la p. 8 (−4,89 points pour les plus de
  65 ans) ; le passage sur l'édition scientifique (relecteurs, accès ouvert)
  n'a pas de carte.

## Les erreurs du ronéo 2025-26

Le Ronéosaure n'est pas le ronéo de l'année : chaque erreur est portée par un
**ATTENTION nu** dans la carte qui tient la notion, la sorte dite dans le texte,
et rien n'entre dans `contenu/ERRATA_RONEOS_2026-27.md`.

| Page | Le ronéo dit | Retenu | Sorte | Carte |
|---|---|---|---|---|
| 3 | le facteur de confusion « n'est visible que dans les ECR car on ne peut pas tirer au sort un patient avec un LDL cholestérol élevé » | c'est HORS des ECR que la confusion pose problème : faute de pouvoir tirer au sort le LDL, on ajuste (FC n°6 partie 1, p. 7-8 ; FC n°11, p. 8-9) | prise de notes | `rlm-qc-equipoise` (explication) |
| 3 | « le LDL cholestérol augmente le risque IDM » | « d'infarctus du myocarde » (errata 2025-26) | formulation, dite sans ATTENTION | `rlm-qc-equipoise` (explication) |
| 5 | « on trace une droite qui va minimiser chaque point » | la droite rend minimale la somme des carrés des distances verticales (même page ; diapositive p. 6) | prise de notes | `rlm-qc-moindres-carres` (explication) |

Sans carte, parce qu'aucune n'en dépend : « sleeve bypass » pour les obèses non
opérés (p. 4 ; la figure compare quatre techniques à l'absence de chirurgie),
« Kaplan Meyer » (p. 4), et le passage confus sur l'accès ouvert, « celui qui
l'a soumis doit payer pour accéder à l'article » (p. 7).

## Ce que les annales ont dicté

| Savoir | Questions | Clé |
|---|---|---|
| Définition : Y quantitative, résidu, nombre de variables, pas d'exponentielle | 2020/2021 S1 Q26 et S2 Q24, 2021/2022 S2 Q26, 2022/2023 S1 Q18 et S2 Q21, 2023/2024 S1 Q26 et S2 Q29 | AC |
| Définition, versions anciennes (supervisée, linéaire, R², Cook) | 2015/2016 S1 Q1 et S2 Q1, 2016/2017 S2 Q1, 2017/2018 S1 Q30 et S2 Q23, 2018/2019 S1 Q9, 2019/2020 S1 Q26 et S2 Q33, 2021/2022 S1 Q21 | variable |
| Hypothèses et tests : erreurs normales, test de chaque coefficient, test global | 2020/2021 S1 Q25 et S2 Q23, 2021/2022 S2 Q23, 2022/2023 S1 Q17 et S2 Q19 ; résidus, 2023/2024 S1 Q24 | CDE ; CD |
| Conditions de validité | 2015/2016 S1 Q2 et S2 Q2, 2016/2017 S1 Q2, 2017/2018 S1 Q31 et Q32, 2018/2019 S1 Q10 et S2 Q34, 2019/2020 S1 Q27 et S2 Q34, 2020/2021 S1 Q27 et S2 Q26, 2021/2022 S1 Q22 | CD le plus souvent |
| Le graphique des résidus (le même à chaque session) | 2015/2016 S1 Q3 et S2 Q3, 2016/2017 S1 Q3 et S2 Q2, 2020/2021 S2 Q25, 2021/2022 S1 Q23 et S2 Q22, 2022/2023 S2 Q18, 2023/2024 S2 Q28 | variable |
| Le tableau de régression du poids (le même à chaque session) | 2015/2016 S1 Q4 et S2 Q4, 2016/2017 S1 Q4 et S2 Q3, 2017/2018 S1 Q33 et S2 Q25, 2018/2019 S1 Q12 et S2 Q35, 2019/2020 S1 Q28, 2020/2021 S2 Q27, 2021/2022 S1 Q24 | variable |
| Lire un coefficient | 2018/2019 S1 Q11 | ABDE |
| Coefficient de détermination et corrélation | 2016/2017 S2 Q4, 2017/2018 S2 Q24, 2018/2019 S1 Q8, 2019/2020 S1 Q25 et S2 Q32 ; Pearson : 2020/2021 S1 Q24 et S2 Q22, 2022/2023 S1 Q16 | variable |

**Les images d'énoncé** : un seul graphique des résidus et un seul tableau de
régression (intercept −122,0 ; treize variables explicatives — douze tours et
la taille —, dont quatre non significatives : tour_nombril, tour_biceps,
tour_cheville, tour_poignet),
identiques à toutes les sessions (vérifié sur les images des deux polycopiés).
Extraits une fois (`rlm-an-residus.png`, `rlm-an-sortie-tour.png`), ils vont en
`illustration_question` des 20 questions qui les lisent : lire l'image est la
question.

**Non cartées ici** (plan C15) : six questions du polycopié n°2 vont à d'autres
chapitres — 2023/2024 Q22 (méthodes multivariées, `biostat_scores`), Q23, Q25,
Q27, 2022/2023 S2 Q26 et 2021/2022 S2 Q33 (`biostat_regression_logistique`).
La 2018/2019 S2 Q33 n'a pas d'énoncé (clé « C ») : non cartée. Le polycopié
n°12 recopie 52 questions du n°2, cartées une fois sous leur référence du n°2 ;
ses blocs « 2018/2019 » (Q25-28, Q32-34) sont la recopie des 2019/2020 S1 et S2.

**Les notions hors fiche** (tag `hors-fiche`, 44 annales et 2 cartes de cours),
justifiées sur des sources citées dans chaque carte : le coefficient de
détermination et son lien au r de Pearson (Penn State STAT 462, 2.5-2.6), la
distance de Cook (Cook, Technometrics 1977 ; STAT 462, 9.5), la
multicolinéarité (STAT 501, leçon 12), le test global du modèle (STAT 462, 5.7),
le graphique des résidus et l'hétéroscédasticité (FC n°12 2024-25, p. 9 ;
Charonéo 2023-24, p. 6), la linéarité d'une variable quantitative (FC n°12
2024-25, p. 8-9). Le supervisé (FC n°10 2025-26, p. 8), le surajustement et la
parcimonie (FC n°1 2025-26, p. 12 ; FC n°11 2025-26, p. 11) et l'exponentielle
des coefficients (FC n°11) sont dans d'autres fiches 2025-26 de l'UE : ils ne
font pas, à eux seuls, porter le tag.

## Les annales, une par une

Clé imprimée, clé retenue (en gras quand elle diffère), thème, identifiant.

| Session | N° | Imprimée | Retenue | Thème | Carte | Remarque |
|---|---|---|---|---|---|---|
| 2015/2016 S1 | Q1 | ACD | ACD | `regression` | `rlm-an-1516s1-q1` | hors fiche |
| 2015/2016 S1 | Q2 | CD | CD | `qualite-modele` | `rlm-an-1516s1-q2` | hors fiche |
| 2015/2016 S1 | Q3 | BD | BD | `moindres-carres` | `rlm-an-1516s1-q3` | image d'énoncé ; hors fiche |
| 2015/2016 S1 | Q4 | AE | AE | `coefficients` | `rlm-an-1516s1-q4` | image d'énoncé |
| 2015/2016 S2 | Q1 | CD | CD | `regression` | `rlm-an-1516s2-q1` | hors fiche |
| 2015/2016 S2 | Q2 | CD | CD | `qualite-modele` | `rlm-an-1516s2-q2` | hors fiche |
| 2015/2016 S2 | Q3 | E | E | `moindres-carres` | `rlm-an-1516s2-q3` | image d'énoncé ; hors fiche |
| 2015/2016 S2 | Q4 | AB | AB | `coefficients` | `rlm-an-1516s2-q4` | image d'énoncé |
| 2016/2017 S1 | Q2 | CD | CD | `qualite-modele` | `rlm-an-1617s1-q2` | hors fiche |
| 2016/2017 S1 | Q3 | BE | BE | `moindres-carres` | `rlm-an-1617s1-q3` | image d'énoncé ; hors fiche |
| 2016/2017 S1 | Q4 | CDE | CDE | `coefficients` | `rlm-an-1617s1-q4` | image d'énoncé |
| 2016/2017 S2 | Q1 | C | C | `regression` | `rlm-an-1617s2-q1` | hors fiche |
| 2016/2017 S2 | Q2 | CE | CE | `moindres-carres` | `rlm-an-1617s2-q2` | image d'énoncé ; hors fiche |
| 2016/2017 S2 | Q3 | BCDE | BCDE | `coefficients` | `rlm-an-1617s2-q3` | image d'énoncé |
| 2016/2017 S2 | Q4 | BD | BD | `correlation` | `rlm-an-1617s2-q4` | hors fiche |
| 2017/2018 S1 | Q30 | AD | AD | `regression` | `rlm-an-1718s1-q30` | A et B fusionnées dans le n°2 : énoncé du n°12 ; hors fiche |
| 2017/2018 S1 | Q31 | CD | CD | `qualite-modele` | `rlm-an-1718s1-q31` | hors fiche |
| 2017/2018 S1 | Q32 | ABCDE | ABCDE | `qualite-modele` | `rlm-an-1718s1-q32` | hors fiche |
| 2017/2018 S1 | Q33 | ADE | ADE | `coefficients` | `rlm-an-1718s1-q33` | amorce fusionnée à A dans le n°2 : énoncé du n°12 ; image d'énoncé |
| 2017/2018 S2 | Q23 | AD | AD | `regression` | `rlm-an-1718s2-q23` | hors fiche |
| 2017/2018 S2 | Q24 | BD | BD | `correlation` | `rlm-an-1718s2-q24` | hors fiche |
| 2017/2018 S2 | Q25 | ADE | ADE | `coefficients` | `rlm-an-1718s2-q25` | image d'énoncé |
| 2018/2019 S1 | Q8 | BCE | BCE | `correlation` | `rlm-an-1819s1-q8` | hors fiche |
| 2018/2019 S1 | Q9 | C | C | `regression` | `rlm-an-1819s1-q9` |  |
| 2018/2019 S1 | Q10 | AE | AE | `qualite-modele` | `rlm-an-1819s1-q10` | hors fiche |
| 2018/2019 S1 | Q11 | ABDE | ABDE | `coefficients` | `rlm-an-1819s1-q11` | hors fiche |
| 2018/2019 S1 | Q12 | CDE | CDE | `coefficients` | `rlm-an-1819s1-q12` | image d'énoncé |
| 2018/2019 S2 | Q34 | CD | CD | `qualite-modele` | `rlm-an-1819s2-q34` | hors fiche |
| 2018/2019 S2 | Q35 | AE | AE | `coefficients` | `rlm-an-1819s2-q35` | D et E fusionnées : rétablies d'après 2020/2021 S2 Q27 ; image d'énoncé |
| 2019/2020 S1 | Q25 | BCE | BCE | `correlation` | `rlm-an-1920s1-q25` | hors fiche |
| 2019/2020 S1 | Q26 | AB | AB | `regression` | `rlm-an-1920s1-q26` | hors fiche |
| 2019/2020 S1 | Q27 | CD | CD | `qualite-modele` | `rlm-an-1920s1-q27` | hors fiche |
| 2019/2020 S1 | Q28 | B | B | `coefficients` | `rlm-an-1920s1-q28` | image d'énoncé ; hors fiche |
| 2019/2020 S2 | Q32 | BD | BD | `correlation` | `rlm-an-1920s2-q32` | hors fiche |
| 2019/2020 S2 | Q33 | C | C | `regression` | `rlm-an-1920s2-q33` |  |
| 2019/2020 S2 | Q34 | CD | CD | `qualite-modele` | `rlm-an-1920s2-q34` | hors fiche |
| 2020/2021 S1 | Q24 | AD | **D** | `correlation` | `rlm-an-2021s1-q24` | CONFLIT : r = −0,6 ; hors fiche |
| 2020/2021 S1 | Q25 | CE | **CDE** | `regression` | `rlm-an-2021s1-q25` | CONFLIT : D vraie ailleurs et au cours ; hors fiche |
| 2020/2021 S1 | Q26 | AC | AC | `regression` | `rlm-an-2021s1-q26` | D et E fusionnées dans le n°2 : énoncé du n°12 |
| 2020/2021 S1 | Q27 | CD | CD | `qualite-modele` | `rlm-an-2021s1-q27` | hors fiche |
| 2020/2021 S2 | Q22 | AD | **D** | `correlation` | `rlm-an-2021s2-q22` | CONFLIT : r = −0,6 ; hors fiche |
| 2020/2021 S2 | Q23 | CDE | CDE | `regression` | `rlm-an-2021s2-q23` | hors fiche |
| 2020/2021 S2 | Q24 | AC | AC | `regression` | `rlm-an-2021s2-q24` |  |
| 2020/2021 S2 | Q25 | BE | BE | `moindres-carres` | `rlm-an-2021s2-q25` | image d'énoncé ; hors fiche |
| 2020/2021 S2 | Q26 | CD | CD | `qualite-modele` | `rlm-an-2021s2-q26` | hors fiche |
| 2020/2021 S2 | Q27 | AE | AE | `coefficients` | `rlm-an-2021s2-q27` | image d'énoncé |
| 2021/2022 S1 | Q21 | AB | AB | `regression` | `rlm-an-2122s1-q21` | hors fiche |
| 2021/2022 S1 | Q22 | ADE | ADE | `qualite-modele` | `rlm-an-2122s1-q22` | hors fiche |
| 2021/2022 S1 | Q23 | B | B | `moindres-carres` | `rlm-an-2122s1-q23` | image d'énoncé ; hors fiche |
| 2021/2022 S1 | Q24 | AE | AE | `coefficients` | `rlm-an-2122s1-q24` | image d'énoncé ; hors fiche |
| 2021/2022 S2 | Q22 | B | B | `moindres-carres` | `rlm-an-2122s2-q22` | image d'énoncé ; hors fiche |
| 2021/2022 S2 | Q23 | CDE | CDE | `regression` | `rlm-an-2122s2-q23` | hors fiche |
| 2021/2022 S2 | Q26 | AC | AC | `regression` | `rlm-an-2122s2-q26` |  |
| 2022/2023 S1 | Q16 | AD | **D** | `correlation` | `rlm-an-2223s1-q16` | CONFLIT : r = −0,6 ; hors fiche |
| 2022/2023 S1 | Q17 | CDE | CDE | `regression` | `rlm-an-2223s1-q17` | hors fiche |
| 2022/2023 S1 | Q18 | AC | AC | `regression` | `rlm-an-2223s1-q18` |  |
| 2022/2023 S2 | Q18 | B | B | `moindres-carres` | `rlm-an-2223s2-q18` | image d'énoncé ; hors fiche |
| 2022/2023 S2 | Q19 | CDE | CDE | `regression` | `rlm-an-2223s2-q19` | imprimée « 2. » dans le n°2 ; hors fiche |
| 2022/2023 S2 | Q21 | AC | AC | `regression` | `rlm-an-2223s2-q21` |  |
| 2023/2024 S1 | Q24 | CD | CD | `moindres-carres` | `rlm-an-2324s1-q24` |  |
| 2023/2024 S1 | Q26 | AC | AC | `regression` | `rlm-an-2324s1-q26` |  |
| 2023/2024 S2 | Q28 | B | B | `moindres-carres` | `rlm-an-2324s2-q28` | polycopié n°12 seulement ; image d'énoncé ; hors fiche |
| 2023/2024 S2 | Q29 | AC | AC | `regression` | `rlm-an-2324s2-q29` | polycopié n°12 seulement |

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2020/2021 S1 Q24 (Pearson) | AD | **D**, `officielle=False` | « Poids = −36 × Âge + 4500 », R² = 0,36 : \|r\| = 0,6, mais r a le signe de la pente, négative : r = −0,6. A, « le coefficient de corrélation de Pearson […] est égal à 0,6 », est fausse (Penn State STAT 462, 2.6). ATTENTION sur A, CONFLITS |
| 2020/2021 S2 Q22 (Pearson) | AD | **D**, `officielle=False` | la même question, la même raison |
| 2022/2023 S1 Q16 (Pearson) | AD | **D**, `officielle=False` | la même question, la même raison |
| 2020/2021 S1 Q25 | CE | **CDE**, `officielle=False` | D, « l'évaluation de la significativité de chacun des coefficients est réalisée par un test statistique », est donnée vraie aux quatre autres sessions qui posent la question (2020/2021 S2 Q23, 2021/2022 S2 Q23, 2022/2023 S1 Q17 et S2 Q19) et par le cours (p. 8) ; les deux polycopiés impriment CE. ATTENTION sur D, CONFLITS |

Toutes les autres clés sont reprises telles quelles. Un point est discuté dans
les cartes sans changer la clé : **« le coefficient de détermination doit être
suffisamment élevé »**, compté parmi les conditions de validité à toutes les
sessions. Au sens strict, le R² mesure la qualité de l'ajustement plutôt
qu'une hypothèse du modèle ; la clé du professeur est constante, elle est
reprise, et la justification le dit (« à l'examen, on le coche »).

**« Le modèle le plus parcimonieux retiendrait 13 variables explicatives »**
(2015/2016 S2 Q4 E, 2018/2019 S2 Q35 D, 2020/2021 S2 Q27 D) : fausse, clé
reprise. Le tableau compte treize variables (le plan C15 en annonçait quatorze,
à tort) : en retenir 13, c'est garder le modèle complet ; le plus parcimonieux en
retient neuf. La justification le dit.

**Les propositions fusionnées à l'impression**, rétablies sans toucher à la
clé : 2017/2018 S1 Q30 (A et B) et Q33 (l'amorce dans A), 2020/2021 S1 Q26 (D et
E), d'après le polycopié n°12 qui les imprime en entier ; 2018/2019 S2 Q35 (D et
E), d'après la même question de 2020/2021 S2 (Q27).

## Les schémas et les figures

**Onze figures de la FC 2025-26**, extraites en PNG à leur taille
d'origine (captures de diapositives) : le nuage en population (p. 4), le modèle et son système d'équations, les hypothèses, la même
loi normale le long de la droite (p. 5), population contre échantillon, les
moindres carrés, le plan à deux variables, la sortie du logiciel (p. 6), la
variable binaire, l'exemple d'article (p. 7), la figure des coefficients de
l'article (p. 8). Les autres captures du ronéo (logo, tables du vaccin ARN, de
C. difficile, des adénomes, de la chirurgie bariatrique et ses courbes de
Kaplan-Meier — au chapitre de la FC n°7 —, la droite et l'erreur εᵢ, le jeu de
données) n'illustrent aucune carte et ne sont pas reprises. La capture des types
d'études (p. 2) ne fait que 288 × 187 px et ses cases ne se lisent pas : elle est
**redessinée** boîte pour boîte (`types-etudes.svg`). Deux images
d'énoncé des annales (le graphique des résidus, le tableau de régression).
Aucune photographie de patient.

**Un schéma cliquable** (`schemas.py`), avec sa version légendée en
correction :

| Fichier | Ce qu'on clique | Pourquoi ce dessin |
|---|---|---|
| `droite-regression.svg` | la valeur observée du patient en rouge, la valeur prédite (Ŷ), son résidu, l'ordonnée à l'origine, ce qui mesure la pente (5 zones) | d'après les p. 5-6 : dix-sept annales demandent ce qu'est un résidu (Y − (b + a1.X1 + …)), neuf ce qu'est l'intercept ; le résidu est le segment VERTICAL, et sa zone s'arrête à 2 px des deux points qu'elle relie, pour qu'aucun clic ne tombe dans deux zones ; la droite est prolongée jusqu'à l'axe des Y pour que l'ordonnée à l'origine se voie |

**Deux figures redessinées** pour les corrections : `residus-lecture.svg`
(homoscédasticité et hétéroscédasticité sur le graphique des résidus, d'après
la FC n°12 2024-25, p. 9), qui illustre les neuf questions du graphique et la
QROC de l'hétéroscédasticité ; `types-etudes.svg` (l'arbre de la diapositive de
la p. 2), qui illustre les neuf cartes des types d'études. Les nuages des
schémas sont tirés d'un générateur à graine fixe : le dessin est le même à
chaque génération. Les légendes de la correction du schéma cliquable tombent
dans des rectangles où aucun point du nuage n'est tiré.

**75 QCM sur 75 illustrés (100 %)**, 91 notes sur 98 (le lexique n'en porte pas). Les 20 questions qui
lisent le graphique ou le tableau de l'énoncé les portent en
`illustration_question`, et une figure du cours en correction.

## Le lexique

Sept termes, ceux du plan C15 ; aucun n'existait (vérifié contre les `lex-*` de
tous les paquets). Pages mesurées dans le texte de la FC 2025-26, page de garde
et en-tête courant exclus :

| Terme | Origine | Pages |
|---|---|---|
| Régression | latin regressio ; le sens statistique vient de Galton (1886) | 4-8 |
| Résidu | latin residuum | 5 |
| Estimateur | latin aestimator | 5, 6 |
| Transversal | latin transversalis | 2, 7, 8 |
| Longitudinal | latin longitudo | 2 |
| Amylose | grec ámulon + -ōsis ; le nom vient de Virchow (1854) | 2 |
| Variance | latin variantia | 5 |

Deux racines sont enseignées par la FC de sémantique et la citent : `trans-
(latin)` (2/2, p. 11) et `-ose` (2/2, p. 9). `re- (latin)`, `trans- (latin)` et
`-ose` reprennent les clés existantes de `etymologies.json`. Sept racines
nouvelles (`gradi`, `sedere`, `aestimare`, `vertere`, `longus`, `amyl(o)-`,
`variare`) et les sept termes sont proposés à la table commune, vérifiés sur le
Wiktionnaire et le Gaffiot ou le Bailly (fichier de proposition dans le
brouillon de C15, `etym/biostat_regression_lineaire.json`) ; les textes du
lexique sont déjà écrits dans la forme que `appliquer_etymologies.py`
produirait.

## Décisions prises en route

- **`EXAMENS` n'est pas déclaré** (décision de BMCT FC1) : le partiel du 16/12
  se règle dans l'application.
- **Une carte par session** : les questions répétées d'une session à l'autre ont
  chacune leur carte, et l'explication renvoie aux autres ; seules les recopies
  d'un polycopié à l'autre ne sont pas recartées.
- **Les énoncés imprimés** sont repris tels quels, coquilles comprises
  (« régression linaire simple », « surajouté », « (ea) » du polycopié n°12) ;
  seuls les blancs perdus à l'extraction du texte sont rétablis (« une
  augmentation », « de variables »), et « e^a » note l'exposant du polycopié
  n°2.
- **Le cours 2024-25 est déclaré** comme source (sans `chapitre=`) parce que
  deux cartes de cours en dépendent (`rlm-qr-heteroscedasticite`,
  `rlm-rv-age-quantitatif`) : elles le citent à sa page, et portent le badge
  « Cours 2024-25 ».

## Questions pour Vincent

1. **La clé de Pearson** (2020/2021 S1 Q24, S2 Q22, 2022/2023 S1 Q16) : la table
   compte vraie « r = 0,6 » pour une pente de −36 g par an. Les cartes retiennent
   la clé juste, D seule (r = −0,6), et le disent sur A ; le professeur pensait
   sans doute à |r|. Faut-il, à l'examen, cocher A comme la table ?
2. **Le chapitre vide du squelette** `chap-ue-biomed-quanti-fc2` « Régression
   linéaire » : il n'a pas de FC 2025-26, son contenu et ses annales sont ici.
   Le masquer, le fusionner avec celui-ci ou le laisser (plan C15, 19.2) ?

## À relire

**Aucune carte `a-relire`** : toutes les notes citent une page de la FC
2025-26 ou du cours 2024-25, chaque annale sa clé imprimée ou la raison de s'en
écarter. Reste à Vincent :

- quand le ronéo 2026-27 paraîtra, relire chaque carte sur lui et retirer le
  badge « Cours 2025-26 » ;
- `copier_les_cours.py` avec le dossier `…/S1 25-26/examen décembre` du
  Ronéosaure 2025-26, hors du bac à sable, pour que la fiche s'ouvre dans
  l'application ;
- ajouter les cinq libellés de thème à `THEME_LABELS` (le test
  `test_tout_theme_du_paquet_a_son_libelle` les attend).

## L'échelle : Simple → Moyen → Annale (C20, 18/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 16 décembre. Sous les annales, 32 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 10 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `regression` | 8 | 3 | 21 |
| `moindres-carres` | 4 | 2 | 10 |
| `coefficients` | 9 | 2 | 12 |
| `qualite-modele` | 7 | 1 | 12 |
| `correlation` | 4 | 2 | 8 |

**Les schémas** sont au nombre de 2 : `ech-modele-lineaire`, « La régression linéaire · le modèle, ses erreurs, ses résidus » (12 Simple, 5 Moyen, 31 annales ; 49 fichiers), et `ech2-lire-juger`, « Lire un modèle, puis le juger · le tableau, les conditions, le R² » (20 Simple, 5 Moyen, 32 annales ; 58 fichiers). Une carte ou une annale va au schéma de son mécanisme. Ils sont décrits dans `schemas.py` (`ECH_MODELE_LINEAIRE`, `ECH2_LIRE_JUGER`, avec leurs `TROUS_*` et `LETTRES_*`, un `FICHIERS.update` chacun) et dessinés par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Source déclarée en plus** : `src-fc-biomed-scr-2526`, à l'identique de `biostat_scores`, pour `rlm-ech2-s16` et `rlm-ech2-s17` (le surapprentissage, FC n°1 p. 12).

**Sans marche** :
- rlm-an-1516s1-q1 D, rlm-an-1516s2-q1 D, rlm-an-1617s2-q1 C, rlm-an-1718s1-q30 D, rlm-an-1718s2-q23 D, rlm-an-2122s1-q21 D — le coefficient de détermination R² n'est dans aucun des deux cours (FC n°8 2025-26, FC n°12 2024-25) ; leurs justifications s'appuient sur Penn State STAT 462. Lettres posées sur la case du résidu.
- rlm-an-1617s2-q1 E, rlm-an-1920s1-q26 E, rlm-an-1516s1-q3 A et E, rlm-an-1516s2-q3 A, rlm-an-1617s1-q3 D, rlm-an-1617s2-q2 D, rlm-an-2021s2-q25 D, rlm-an-2122s1-q23 D, rlm-an-2122s2-q22 D, rlm-an-2223s2-q18 D, rlm-an-2324s2-q28 D — la distance de Cook et les individus trop influents sont hors des deux cours (Cook 1977 ; Penn State STAT 462, 9.5). Lettres posées sur « Analyser les résidus ».
- rlm-an-1617s2-q1 D — la multicolinéarité est hors des deux cours (Penn State STAT 501). Lettre posée sur la case des Xi.
- rlm-an-2021s1-q25 E, rlm-an-2021s2-q23 E, rlm-an-2122s2-q23 E, rlm-an-2223s1-q17 E, rlm-an-2223s2-q19 E — le test global du modèle est hors des deux cours (Penn State STAT 462, 5.7). Lettre posée sur la case des tests.
- rlm-an-1516s2-q3 C — « 12 individus » se lit en comptant les cercles de l'image de l'énoncé, pas dans le cours. Lettre posée sur la case du résidu (un point par individu).
- rlm-an-2122s1-q24 D (« certainement issu d'une procédure stepwise ») : la sélection « pas à pas » n'est que citée par la FC n°1 2025-26, « pas à retenir d'après le professeur » (p. 12) ; aucune marche n'est bâtie dessus (elle porterait edn), la lettre est posée sur la case « Pour un modèle plus simple » et la justification de l'annale suffit.
- rlm-an-1819s1-q8 E (le résidu est la différence entre Y et Yp) : la définition du résidu relève des thèmes regression et moindres-carres, que prépare l'autre rédacteur avec son propre schéma ; la lettre est posée sur la case « Résidus, Y − Ŷ », dont le titre la porte.

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```
