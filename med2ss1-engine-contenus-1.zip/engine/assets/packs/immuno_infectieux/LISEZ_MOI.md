# Réponse immunitaire aux agents infectieux — paquet Immunologie

71 notes, 116 cartes. Chapitre `chap-ue-immunologie-fc11` de l'UE Immunologie.
Cours du **Pr Lefèvre**, semaine 7, 8 h-10 h, « Réponse aux agents
infectieux » (FC n°11 du Ronéosaure 2025-26, 15 pages ; l'en-tête imprime
« 22/09/2025 », la semaine 7 tombe le 22/10/2025) ; annales des polycopiés
IMMUNO n°11 et n°7 du Ronéosaure 2024-25 (11 questions, 10 sessions) et du sujet
2024/2025 déposé le 15/10/2026 (2 questions). Examen de novembre.

**Une fiche provisoire.** Le ronéo 2026-27 de ce cours n'est pas paru au
02/10/2026 : le chapitre est carté sur le Ronéosaure 2025-26 (tâche C14,
décision de Vincent du 02/10), et le ronéo de l'année corrigera les cartes à
sa parution. La fiche porte son année dans son auteur (« Ronéosaure
2025-26 ») : chaque carte de cours prend le tag `cours-2025-26`, et l'écran
montre « Cours 2025-26 ». Aucune carte ne dit « Absent du cours 2026-27 », et
les erreurs du Ronéosaure sont dites par un ATTENTION sans genre (précédent
d'`immuno_cmh`) : la liste des erreurs de la promo,
`contenu/ERRATA_RONEOS_2026-27.md`, ne concerne que les ronéos 2026-27.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 35 | 35 |
| QRU | 2 | 2 |
| Texte à trous | 12 | 52 |
| QROC | 7 | 7 |
| Recto-verso | 6 | 6 |
| Schéma cliquable | 2 | 7 |
| Lexique | 7 | 7 |

Dont **13 annales** : 12 QCM (QRM) et 1 QROC (recto-verso), sur 11 sessions,
de 2015/2016 S1 à 2024/2025 S1. Les 25 QCM du cours ont une justification par
proposition, comme les annales.

Six thèmes, dans l'ordre du cours :

| Clé | Libellé |
|---|---|
| `pathogenicite-bacteries` | Classification et pathogénicité des bactéries |
| `bacteries-extracellulaires` | Réponse aux bactéries extracellulaires |
| `bacteries-intracellulaires` | Réponse aux bactéries intracellulaires |
| `immunite-tuberculose` | Immunité antituberculeuse : granulome et tests |
| `immunite-antivirale` | Immunité antivirale |
| `parasites-champignons` | Parasites et champignons |

Les six libellés sont à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`), bloc « immunologie ». Le plan
C14 proposait `tuberculose` et `antiviral` : deux mots qu'une autre UE voudra
(la pneumologie, les antiviraux de la pharmacologie) ; les clés disent donc
l'immunité. Deux cartes portent aussi `edn` (hors du partiel, à savoir pour
les EDN).

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-immuno-infectieux` — Ronéosaure, « FC n°11 réponse aux agents infectieux .pdf » (15 p.), `IMMUNOLOGIE/…` | **2025-26** | **la base** : chaque note du cours porte sa page ; c'est ce que le lecteur ouvre (`chapitre=`) |
| `src-annales-immuno-n11-reponse-immunitaire-aux-agents-infectieux-2` — Ronéosaure, « IMMUNO n°11- Réponse immunitaire aux agents infectieux-2 » (7 p.) | 2024-25 | 9 QCM et leur table de corrections (p. 7) ; déclaré avec les seuls cinq champs convenus, pour que tout chapitre qui le citera le déclare à l'identique |
| `src-annales-immuno-innee` — Ronéosaure, « IMMUNO n°7 - Immunité innée et réponses inflammatoires » (12 p.) | 2024-25 | 1 QCM et 1 QROC (`SRC["sessions"]` : 2015/2016 S1, 2021/2022 S2) ; **déclaration copiée à l'identique de celle d'`immuno_innee`** |
| `src-sujets-immuno-2425` — sujet de système immunitaire 2024/2025, session 1 (3 p.) | 2024-25 | dépôt du 15/10/2026 : les Q9 et Q10 (`SRC["sessions"]["2024/2025 S1"]`) ; sujet sans corrigé, clés déduites du cours ; déclaré à l'identique dans chaque chapitre d'immunologie qui en a une question |
| grille officielle des QCM 2023/2024 (02/11/2023) | 2023-24 | dépôt du 15/10/2026 : confirme la clé de la Q10 de cette session ; citée, pas déclarée |
| `src-cours-immuno-infectieux-2425` — Ronéosaure, FC n°11 (AC), Pr Lefèvre (20 p.) | 2024-25 | appoint, cité dans le texte des cartes : sepsis et choc septique (p. 3), IDR et ELISPOT (p. 14-15), boucle TNF/IFN-γ du granulome (p. 16), interférons (p. 17-18), IgA des muqueuses (p. 19) |
| FC n°7 et n°10 2025-26 (immunité innée ; mode d'action des anticorps) | 2025-26 | citées dans le texte, à la page, sans être déclarées : ce sont les fiches d'autres chapitres |
| erratas du Ronéosaure : cours 2025-26 (`Erratas Immuno.docx`) et annales 2024-25 | — | aucune entrée sur la FC n°11 ; une entrée d'annales sur IMMUNO n°11 (2020/2021 S1 Q.10), déjà intégrée dans le PDF lu |

Vérifications hors du cours, citées dans la carte qui s'en sert : Janeway et
Abbas (IgA et voie classique, acide sialique et facteur H, protéases à IgA,
IL-12/IL-23 et mycobactéries, antigènes ESAT-6/CFP-10 des mycobactéries
atypiques) ; Oppmann et al., *Immunity* 2000 (l'IL-23 fait produire l'IFN-γ
aux LT mémoires) ; l'étymologie (TLFi par l'API du CNRTL, Wiktionnaire,
Bailly, Gaffiot).

## Ce que le cours a dicté

- **Trois passages hors du partiel** ; deux ont une carte, avec le tag `edn` :
  les procédés d'échappement des bactéries intracellulaires, « pas à
  apprendre » (p. 9) — `inf-qc-echappement` ; les parasitoses, « vu
  rapidement, pas interrogé » (p. 14) — `inf-qc-parasites`. Les noms des antigènes de l'IGRA (ESAT-6,
  « CSP10 », « pas à apprendre », p. 12) n'ont pas de carte : ils ne paraissent
  que dans la légende du schéma IGRA et dans une justification.
- **La ligne rouge** — l'interféron de type II, γ, « interféron immunitaire »,
  produit par les NK et les LT, à ne pas confondre avec ceux de type I (p. 13)
  — a sa QRU (`inf-qru-ifn-gamma`), son trou (`inf-fa-ifn`) et son recto-verso
  (`inf-rv-ifn-types`).
- **Le gris** (p. 11, la voix des rédacteurs : le nodule d'une primo-infection
  peut être invisible au scanner) est carté comme le reste
  (`inf-qc-latente-maladie` E).
- **La conclusion « à retenir »** (p. 15) a ses cartes : l'antigène spécifique
  de l'IGRA (`inf-qc-igra`, `inf-rv-idr-igra`), pourquoi l'IDR réagit pour
  plusieurs raisons (`inf-rv-idr-positive`), latente contre maladie
  (`inf-fa-latente`, `inf-qc-latente-maladie`, `inf-rv-latente-maladie`), les
  interférons I et III (`inf-qr-ifn-viraux`, `inf-qc-interferons`).
- **Le rôle des LT γδ** est « non développé dans ce cours » (p. 10) : il n'est
  qu'un distracteur (`inf-qc-cooperation-macrophage` E).
- **Ce qui appartient à d'autres chapitres n'est pas carté** (plan C14) : le
  complément, la phagocytose, les NK et le « missing self », les barrières
  (FC n°7) ; les signaux d'activation des LT et la polarisation générique
  (FC n°8) ; la réponse primaire et secondaire des anticorps (FC n°6) ; la rate
  et les bactéries encapsulées (`immuno_organes`). Les cartes d'ici les citent
  quand une stratégie contre un pathogène les emploie : Th17 et neutrophiles
  contre les bactéries extracellulaires, Th1 et IFN-γ contre les
  intracellulaires, la courbe primaire/secondaire en illustration seulement.
  Le fait « Th17 contre les bactéries extracellulaires et les champignons » a
  sa carte dans `immuno_reponse_t` (`rpt-fa-th17`) : il n'a pas de QROC ici,
  seulement des propositions dans les QCM de la stratégie antibactérienne
  (`inf-qc-lt-extracellulaires`, `inf-qc-champignons` E).

## Les erreurs du Ronéosaure 2025-26

Chacune est dite par **ATTENTION**, sans genre, dans la carte qui porte la
notion.

| Page | Ce que dit le Ronéosaure | Ce qui est juste | Carte |
|---|---|---|---|
| 4 | la voie classique activée par « un IgM, voire IgG et IgA très rarement » | les IgA n'activent pas la voie classique : IgM, IgG1 à IgG3 (FC n°7 2025-26, p. 6 ; cours 2024-25 de la FC n°7, p. 7 ; Janeway) | `inf-qc-anticorps-extra` D |
| 5 | un déficit en C7, « défaut du complexe d'attaque qui peut être causé par une méningite par méningocoque à répétitions » | causalité inversée : le déficit expose aux méningites, qui le font rechercher (FC n°7 2025-26, p. 7) | `inf-qc-deficits` C |
| 7 | « les lymphocytes T folliculaires CD4 TH17 » | les Th17 ne sont pas les LT folliculaires (Tfh), que la même page nomme pour l'aide aux LB | `inf-qc-lt-extracellulaires` C |
| 13 | l'IFN-α agit « de manière autocrine » et l'IFN-β « paracrine » | point douteux : les deux sont autocrines et paracrines — la même page le dit plus bas, le cours 2024-25 aussi (p. 17-18) | `inf-qc-interferons` D, `inf-an-2223s1-q10` C |

Sans ATTENTION, parce qu'aucune réponse n'en dépend : la date de l'en-tête
(22/09 pour 22/10) ; « CSP10 » pour CFP-10 (p. 12) ; les perforines appelées
« enzymes » (p. 9 : la perforine perce, les granzymes sont les enzymes — dit
dans `inf-qc-cd8`) ; « dans ces follicules secondaires, des LT et des LB vont
être maturés et éduqués » (p. 6 : les LT sont activés dans le cortex profond,
l'éducation est thymique — notion de la FC n°8, non cartée ici) ; « les PRR1
de la cellule, les TLR2 » (p. 13 : des appels de note, pas le TLR2).

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| Les anticorps et les LB contre les bactéries extracellulaires : neutralisation, opsonisation, voie classique | 2022/2023 S1 Q9, 2020/2021 S1 Q.10, 2018/2019 S1 Q.6, 2018/2019 S2 Q.7, 2015/2016 S1 Q8 |
| Les mécanismes de défense contre ces bactéries : TLR, Th17, phagocytes, nétose, burst oxydatif | 2024/2025 S1 Q9, 2023/2024 S1 Q10, 2017/2018 S1 Q.6 |
| La capsule, facteur de virulence | 2019/2020 S1 Q.10 |
| L'immunité anti-mycobactéries, le granulome, les tests | 2024/2025 S1 Q10, 2020/2021 S2 Q.10 |
| L'immunité antivirale : interférons de type I et III, CD8 et NK | 2022/2023 S1 Q10, 2021/2022 S2 QROC 4 |

Les sept autres questions d'IMMUNO n°11 sont dans le chapitre de leur sujet :
2023/2024 Q8 et Q9, 2022/2023 Q7 et QROC 5, 2021/2022 Q.10 dans « Immunité
innée et réponse inflammatoire » ; 2022/2023 Q8 et QROC 4 dans « Activation et
différenciation des cellules B par l'antigène ». 2018/2019 S1 Q.6 et
2017/2018 S1 Q.6, aussi imprimées dans IMMUNO n°7, ne sont cartées qu'ici.

## Les schémas cliquables

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `granulome-tuberculeux-nu.svg` (`inf-zo-granulome`) | la nécrose caséeuse, la couronne de macrophages et de cellules épithélioïdes, la cellule géante, la couronne de LT | 4 |
| `igra-elispot-nu.svg` (`inf-zo-igra`) | le puits sans antigène, le puits du mitogène, les puits des antigènes spécifiques du BK | 3 |

**Le granulome** est redessiné d'après la diapositive de la p. 10, en coupe,
sans une légende : ce sont les couches qui se reconnaissent — un centre pâle
et grumeleux semé de bacilles, des cellules allongées en couronne, une grande
cellule violette à plusieurs noyaux, des petits lymphocytes ronds tout autour.
**Une seule cellule géante** est dessinée : deux cellules feraient deux zones
pour une même réponse, et un clic juste sur l'une serait compté faux. L'anneau
des macrophages est un polygone percé à la place de la cellule géante (pont
radial, règle pair-impair, comme `geometry.annulus`) ; deux pixels séparent les
anneaux voisins.

**La plaque d'IGRA** montre le résultat d'un patient qui a rencontré le BK :
aucun spot sans antigène, beaucoup avec le mitogène, un nombre moyen avec les
deux antigènes spécifiques, que couvre une seule zone. C'est le nombre de spots
qui dit le puits, et c'est ce que le cours demande de savoir lire.

Les versions légendées, `granulome-tuberculeux.svg` et `igra-elispot.svg`,
tirées des mêmes constantes, sont en correction. Les zones ont été relues
superposées au dessin : aucune ne déborde sur sa voisine.

**Illustrations** : 35 QCM sur 37 (95 %) portent une diapositive de la fiche ou
un schéma légendé en correction ; 57 notes sur 71. Les deux QCM sans figure
(`inf-qru-choc-septique`, `inf-an-1920s1-q10` sur la capsule) n'en ont pas dans
la fiche. Quatorze diapositives de la fiche sont extraites dans `media/`
(réduites à 1 100 pixels de large au plus).

## Les annales du dépôt du 15/10/2026

- **2023/2024 S1 Q10** (`inf-an-2324s1-q10`) : clé ABCD, **confirmée par la
  grille officielle (dépôt du 15/10/2026)**.
- **2024/2025 S1 Q9** (`inf-an-2425s1-q9`) : **reprise de 2023/2024 S1 Q10**,
  comme l'annonçait la comparaison — D mot pour mot ; C et E reprises, une notion
  changée, devenues fausses (« voie alterne » pour « classique », Th2 pour
  Th17) ; A reprise, les fractions changées (C3a et C5a pour « C5a-C9 »), fausse
  comme en 2023/2024 ; B (les NK) nouvelle. Une seule vraie : D.
- **2024/2025 S1 Q10** (`inf-an-2425s1-q10`) : voisine de 2020/2021 S2 Q.10,
  dont elle retourne la proposition sur l'IL-12 et l'IL-23 (produites par le LT ou
  le NK : faux). L'IL-23 est hors du cours 2025-26 : la justification cite la
  littérature (Oppmann et al. 2000), comme pour 2020/2021 S2.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2021/2022 S2 QROC 4 (antiviral, IMMUNO n°7) | corrigé imprimé sous « QROC5 » | ce corrigé, rattaché au QROC 4 | les corrigés des QROC 4 et 5 sont intervertis dans la table (le « QROC 4 » imprimé répond au QROC 5 sur la voie classique, carté dans `immuno_innee`) ; non marqué officiel |
| 2024/2025 S1 Q9 (`inf-an-2425s1-q9`) | aucune (sujet sans corrigé) | **D**, déduite, non officielle | C3b opsonise, C3a et C5a attirent (p. 5) ; les NK ne sont pas dans la conclusion sur les bactéries extracellulaires (p. 15), ils visent tumeurs et cellules infectées par un virus (p. 14) ; l'IgM active la voie classique (p. 4) ; TLR4 et TLR2 (p. 5) ; Th17, pas Th2, pour les PNN (p. 7) |
| 2024/2025 S1 Q10 (`inf-an-2425s1-q10`) | aucune (sujet sans corrigé) | **AD**, déduite, non officielle | IFN-γ et activation du macrophage (p. 9-10) ; anti-TNF et tuberculose maladie (p. 11) ; IL-12 produite par le macrophage, pas par le LT ou le NK (p. 10) ; CD8 par le CMH I (p. 9), mémoire (p. 10) ; l'IGRA mesure l'IFN-γ, pas le TNF-α (p. 12) |

Reprises, avec une remarque dans la carte : **2020/2021 S1 Q.10** (la première
version du polycopié imprimait ABE, la clé de la question voisine ; l'errata
des annales l'a corrigée en CD, que porte la version numérique lue ; clé
officielle) ; **2017/2018 S1 Q.6** (IMMUNO n°7 imprime un « C » parasite à la
fin de B ; la carte suit IMMUNO n°11) ; **2015/2016 S1 Q8 E** (l'IgM opsonise
surtout en activant le complément, dit) ; **2020/2021 S2 Q.10 D-E** (cellules
épithélioïdes : sur la seule diapositive ; IL-23 : hors des deux cours,
littérature) ; **2019/2020 S1 Q.10 A et E** (acide sialique et facteur H,
protéases à IgA : hors des deux cours, littérature) ; **2023/2024, 2022/2023,
2017/2018** : la table imprime l'année sans session, l'énoncé dit « session
1 » ; les cartes portent la session de l'énoncé.

`CONFLITS` est vide : aucune clé imprimée n'est contestée. Cas ouvert : aucun.

## Le lexique

Sept termes, aux pages mesurées dans la fiche 2025-26 : granulome (p. 10, 11),
interféron (7, 9, 10, 12-15), nécrose caséeuse (10), tuberculine (11),
intradermoréaction (11, 12, 15 — « IDR » compris), mycose (14), sepsis (3).
Chacun dit son origine grecque ou latine. « Helminthe », que le plan C14
proposait, est laissé à la parasitologie (FC n°1).

Les racines `nécr(o)-` et `intra- (latin)` citent la FC de sémantique 2026-27
(2/2, p. 8), `-ose` (2/2, p. 9), `sept- / sepsi- (grec)` (1/2, p. 9) : leur
page y a été vérifiée dans le texte du PDF. Les autres sont « hors FC ».

Les étymologies nouvelles — dix racines (`granul- (latin)`, `inter (latin)`,
`ferire (latin)`, `caseus (latin)`, `tuberculum (latin)`, `intra- (latin)`,
`derm(o)-`, `actio (latin)`, `myc(o)-`, `sept- / sepsi- (grec)`) et les sept
termes — sont **proposées** pour `scripts/etymologies.json`, avec leurs
sources ; la table n'est pas modifiée par ce chapitre. Les définitions et les
racines disent déjà, mot pour mot, ce qu'`appliquer_etymologies.py` en
écrira. Les racines réemployées gardent la clé de la table : `-ome`,
`nécr(o)-`, `-ose`, `re- (latin)`.

## Questions pour Vincent

Le plan C14 laissait ces points ouverts ; sa proposition est appliquée, et
chaque carte concernée le dit.

1. **Les clés de thèmes** : `immunite-tuberculose` et `immunite-antivirale` à
   la place des `tuberculose` et `antiviral` du plan (deux mots qu'une autre
   UE voudra). D'accord ?
2. **Les IgA et la voie classique** (plan, § 12.6) : la FC n°11 dit « IgA très
   rarement » (p. 4), la FC n°7 ne les cite pas, la littérature dit qu'elles
   ne l'activent pas. La carte répond comme la FC n°7 et le dit
   (`inf-qc-anticorps-extra` D).
3. **IFN-α « autocrine », IFN-β « paracrine »** (p. 13) : tenu pour un point
   douteux ; la carte répond « les deux, autocrines et paracrines », comme la
   même page plus bas et le cours 2024-25 (`inf-qc-interferons` D).
4. **Les propositions hors du cours 2025-26** (plan, § 11) : l'IL-23
   (2020/2021 S2 Q.10 E, 2024/2025 S1 Q10 C), l'acide sialique (2019/2020 S1 Q.10 A), les
   protéases à IgA (même question, E) sont justifiées par la littérature, et la
   justification dit « hors du cours 2025-26 ».
5. **La nuance ESAT-6/CFP-10** : le cours dit ces antigènes absents de « toute
   autre mycobactérie » ; `inf-qc-igra` B ajoute que quelques mycobactéries
   atypiques (M. kansasii, M. marinum, M. szulgai) les portent. Garder la
   nuance, ou s'en tenir au cours ?
6. **Le schéma IGRA** montre un test positif (le patient a rencontré le BK) :
   c'est ce qui rend les trois puits reconnaissables. Faut-il une seconde
   plaque, négative ?

## À relire

Aucune carte `a-relire` : chaque carte de cours porte sa page dans la fiche
2025-26, chaque annale sa clé vérifiée. À la parution du ronéo 2026-27 de ce
cours, relire toutes les cartes contre lui : pages, chiffres (6 à 12 semaines,
induration de 15-20 mm, prophylaxie de 3 mois), les quatre erreurs ci-dessus,
et les directives « pas à apprendre » (tag `edn`).

## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026)

Le pilote de l'immunité innée, étendu au reste de l'immunologie pour l'examen du 4/11 (choix de Vincent, 15/10). Sous les annales, 31 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 7 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `pathogenicite-bacteries` | 1 | 1 | 1 |
| `bacteries-extracellulaires` | 16 | 4 | 8 |
| `immunite-tuberculose` | 8 | 1 | 2 |
| `immunite-antivirale` | 6 | 1 | 2 |

**Le schéma** `ech-infectieux`, « Réponse aux agents infectieux · une réponse par pathogène », donne 51 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_INFECTIEUX`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu les dix chapitres ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Un désaccord entre cours** : la source de l'IFN-γ (CD et NK pour la FC n°8 ; NK et LT pour la FC n°11, p. 13). Les marches de ce chapitre suivent la FC n°11 ; rpt-ech-m3, dans la réponse T, dit le désaccord.

**Sans marche** :
- inf-an-1920s1-q10 A : l'acide sialique de la capsule, qui limite le complément — absent des cours 2025-26 et 2024-25 (la justification cite Janeway et Abbas). Lettre posée sur la case de la capsule.
- inf-an-1920s1-q10 C : les sucres de la capsule, antigènes thymo-indépendants sans LB mémoire — un fait de la FC n°10 2025-26 (p. 12-15), qui a sa marche dans immuno_anticorps (anc-ech-s20, anc-ech-s21). Lettre posée sur la case de la capsule.
- inf-an-1920s1-q10 E : les protéases à IgA des bactéries des muqueuses — absentes des cours (la justification cite Janeway). Lettre posée sur la case de la capsule.
- inf-an-1819s2-q7 A : le BCR reconnaît l'antigène sans CMH — un fait de la FC n°10 2025-26 (p. 12), que la FC n°11 ne dit pas ; sa marche est dans immuno_anticorps (anc-ech-s22). Lettre posée sur la case du LB.

## Régénérer

```powershell
cd contenu\chapitres\immuno_infectieux
..\..\..\app\.venv\Scripts\python.exe generer.py
```

`generer.py` est la copie exacte du modèle du skill. Les figures se tirent du
PDF de la fiche (xref des images, réduites à 1 100 pixels) ; les schémas sont
réécrits par `generer.py` depuis `schemas.py`.
