# Sémiologie clinique gynécologique — paquet d'exemple

56 notes, 103 cartes. Deux sources : la fiche de cours et les annales de dix
sessions.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 27 | 27 |
| Texte à trous | 12 | 49 |
| QROC | 9 | 9 |
| Repérage sur schéma | 3 | 13 |
| Recto-verso | 5 | 5 |

Sur les 27 QRM, **14 sont des annales** de 2015/2016 à 2023/2024.

## La fiche la plus annotée du corpus

**Dix-sept commentaires en marge.** Deux ont directement décidé du contenu :

- **« Pas de question ici »**, sur la section V — l'examen abdominal. **Aucune
  carte n'en est tirée.** C'est le premier commentaire du corpus qui exclut
  explicitement un passage, et il est suivi à la lettre.
- **« A savoir par cœur »**, sur *toute femme qui vient aux urgences en aménorrhée
  est enceinte jusqu'à preuve du contraire*. C'est le marqueur le plus fort
  rencontré jusqu'ici, et la proposition correspondante est déclarée
  **indispensable** : la manquer annule la question, comme elle annulerait le
  raisonnement clinique. Le commentaire voisin pousse la règle jusqu'à l'absurde,
  et c'est ce qui la rend inoubliable : *« même si c'est une bonne sœur qui s'est
  fait ligaturer les trompes »*.

Les autres « A savoir » ont fixé la hiérarchie du reste : les durées de cycle,
les troubles du volume menstruel, la palpation des seins, l'écoulement
mamelonnaire. Deux notent une performance plutôt qu'un fait — la palpation
mammaire est peu sensible, le toucher rectal n'est pas de routine.

## Une coquille de la fiche, corrigée avec son auteur

La fiche notait en rouge : *« Exemple de question : parmi les termes suivants
lesquels correspondent à des douleurs de règles : dysménorrhée et **aménorrhée**
(il faut mettre les deux) »*.

Les annales **2023/2024 et 2022/2023** posent exactement cette question, et la clé
y est **DE — dysménorrhées et ALGOménorrhées**. « Aménorrhée » était un lapsus
pour « algoménorrhée » — d'autant que l'aménorrhée est l'*absence* de règles, qui
ne saurait faire mal. **Dysménorrhée = algoménorrhée** : un seul et même terme, et
c'est celui des annales que les cartes emploient.

## Le spéculum et les parois du vagin, corrigé le 16/10/2026

La FC6 2025-26 disait que les lames du spéculum écartent les parois antérieure
et postérieure du vagin, et donc les cachent. Le ronéo 2026-27 les fait voir au
retrait : on retire doucement le spéculum « et on verra apparaître les parois
antérieures et postérieures » (p. 13). La carte de cours `gyn-qc-speculum` passe
de ABD à **ABDE**, avec un `ATTENTION` sur E, et l'explication de 2022/2023 S2
QCM 4 ne dit plus que le spéculum cache les parois qu'il écarte (aucune de ses
propositions n'en parle, sa clé ne change pas).

## Ce que les annales ont dicté

Quatorze questions, mais **plusieurs sont identiques d'une année sur l'autre** :
deux fois la même sur les douleurs de règles, deux fois la même sur les
métrorragies, deux fois la même sur l'examen gynécologique. Quatre savoirs
couvrent treize questions sur quatorze :

| Le savoir | Questions |
|---|---|
| **dysménorrhée = algoménorrhée** | 2 |
| Le couple **ménorragies / métrorragies** | 4 |
| Les quatre caractères des **leucorrhées physiologiques** | 3 |
| La conduite du **spéculum** et du **toucher vaginal** | 3 |

Les préfixes suffisent presque à tout : **dys-** et **algo-** pour la douleur,
**a-** pour l'absence, **spanio-** pour la rareté, **-ragie** pour le saignement,
**-dynie** pour la douleur mammaire, **méno-** pour les règles, **métro-** pour
l'utérus.

Un chiffre n'est nulle part dans le cours et vient des seules annales : les
ménorragies sont des règles **de plus de 80 mL**.

## Les trois schémas cliquables

| Fichier | Ce qu'on y clique | Cartes |
|---|---|---|
| `quadrants-sein.svg` | les quatre quadrants et la PAM | 5 |
| `durees-cycles.svg` | cinq seuils sur un axe en jours | 5 |
| `col-speculum.svg` | exocol, zone de jonction, endocol | 3 |

Deux points de méthode :

- **Les quadrants sont des secteurs annulaires**, pas des rectangles. Un
  rectangle mordrait sur la plaque aréolo-mamelonnaire au centre et déborderait
  du sein aux angles ; les sommets des secteurs sont calculés sur le cercle.
- **Le col emploie deux anneaux**, produits par `geometry.annulus`. Un anneau
  contient son pourtour et pas son trou, pour le navigateur comme pour la
  correction, parce que les deux appliquent la règle pair-impair. C'est ce qui
  permet aux trois zones concentriques de se toucher sans se recouvrir.

Le schéma du sein précise sous le dessin qu'il s'agit du **sein droit vu de
face** : sans cela, « supéro-externe » n'aurait pas de réponse décidable.

## Une coquille des annales, et aucune clé changée

En 2020/2021 S2 QCM 21, la dernière proposition est imprimée « A. E; perte de
poids… » : la lettre A est répétée et le E rabattu dans le texte. Les morceaux
sont recollés et la carte le signale (`CONFLITS`).

**Clés non reprises telles quelles : aucune.** Relue le 26/09/2026 (règle de
Vincent : la clé retenue est la bonne, pas la clé imprimée), la clé C de cette
question est juste : le ronéo 2026-27 fait préciser la consistance (élastique ?
indurée ?) et la forme de tout nodule (p. 17), et c'est le nodule dur,
irrégulier et adhérent qui inquiète, le nodule mou qui rassure ; la perte de
poids de la proposition E, elle, est un signe général de cancer évolué, donc en
faveur (Manuel MSD pro, « Nodules mammaires »).

## Une erreur du ronéo 2026-27, non cartée

Relevée à la relecture du 28/09/2026, absente du tableau d'erreurs de la promo :
les « ménométrorragies : règles longues et douloureuses + saignements en
dehors des règles » (p. 9). La douleur n'entre pas dans la définition : ce
sont des ménorragies, règles anormalement abondantes ou prolongées, associées
à des métrorragies. Aucune carte ne définit les ménométrorragies ; l'erreur
est dans `contenu/ERRATA_RONEOS_2026-27.md`.

## Le corrigé officiel 2023-24

Le sujet de sémiologie générale 2023-24 et son corrigé officiel (une clé par question) sont arrivés le 15/10/2026. Les cartes de cette session venaient du polycopié et en gardent la source ; leur clé est vérifiée :

- 2023/2024 QCM 22 (`gyn-an-2324-q22`, DE) : clé confirmée par le corrigé officiel 2023-24, dépôt du 15/10/2026.
- 2023/2024 QCM 23 (`gyn-an-2324-q23`, C) : clé confirmée par le corrigé officiel 2023-24, dépôt du 15/10/2026.


## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026)

L'échelle du pilote de l'immunité innée, étendue à la sémiologie pour l'examen du 4/11 (Vincent, 16/10 : « on continue pour les chapitres que je vais avoir à l'examen »). Sous les annales, 19 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 5 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `douleurs` | 2 | 1 | 3 |
| `cycles` | 6 | 1 | 6 |
| `leucorrhees` | 4 | 1 | 2 |
| `examen` | 3 | 1 | 3 |
| `seins` | 4 | 1 | 2 |

**Le schéma** `ech-gyneco`, « La sémiologie gynécologique · des mots et des gestes », donne 41 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_GYNECO`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sources.** `SRC` n'a pas de clé `fiche` : chaque marche nomme la sienne (`fiche="src-fc-semio-gyneco"`, la ronéo 2026-27), et les images de l'échelle sont déclarées sous `SRC["cours"]`. La relecture de l'échelle a corrigé `gyn-qc-speculum` (plus haut, « Le spéculum et les parois du vagin »).

**Sans marche** :
- gyn-an-1819-q20 et gyn-an-1516-q21 A (le spéculum précède le toucher vaginal) : le ronéo 2026-27 décrit l'un puis l'autre (p. 13-15) sans poser l'ordre en règle ; aucune flèche ne relie les deux cases
- gyn-an-1819-q20 et gyn-an-1516-q21 B (axe du vagin) : absent du cours, l'explication de l'annale le dit déjà
- gyn-an-1819-q20 et gyn-an-1516-q21 C (éviter la fourchette) : le ronéo définit la fourchette, entrée du vagin (p. 12-13), sans consigne de l'éviter
- gyn-an-1819-q20 et gyn-an-1516-q21 D (éviter la zone urétrale au toucher vaginal) : absent du ronéo 2026-27
- gyn-an-2223s2-q4 D (aspect des leucorrhées au spéculum) : écrit sur la case du spéculum (ligne 2, p. 13-14), sans carte qui la troue
- gyn-an-1920s2-q25 et gyn-an-1718-q22 A (saignement au moment de l'ovulation) : le ronéo 2026-27 ne parle pas de l'ovulation ; la clé tient à la lecture des annales, « une circonstance, pas la définition », et gyn-ech-s8, qui définit la métrorragie hors des règles, ne la prépare pas
- gyn-an-2223s2-q5 E (mousseuses) et gyn-an-2122s2-q19 B (adhérentes) : absents du ronéo 2026-27 (venus de l'ancienne fiche FC6)
- gyn-an-2021s2-q21 A (seins asymétriques) : le ronéo cite voussure, rétraction cutanée et rétraction du mamelon (p. 16-17), pas l'asymétrie
- gyn-an-2021s2-q21 C (nodule mou) : le ronéo fait préciser la consistance, « élastique ? induré ? » (p. 17), sans dire laquelle rassure ; la case nod porte la lettre, aucune marche ne tranche
- gyn-an-2021s2-q21 E (perte de poids) : hors du cours (justifiée par le Manuel MSD) et prise dans le CONFLITS de mise en page

## Régénérer

```powershell
python generer.py
```
