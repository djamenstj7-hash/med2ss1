# Métabolisme lipidique — paquet BMCP

75 notes, 164 cartes. Chapitre `chap-ue-bmcp-fc8` de l'UE BMCP (identifiant du
squelette). Cours du **Pr Benlian, le 23/09/2026** (semaine 3), un ronéo de 14
pages ; trois questions d'annales : le QROC 4 de 2023/2024, et les Q.11 et Q.12 du sujet
de 2024/2025, sans corrigé.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 18 | 18 |
| QRU | 2 | 2 |
| Texte à trous | 15 | 86 |
| QROC | 10 | 10 |
| Recto-verso | 11 | 11 |
| Lexique | 16 | 16 |
| Schéma cliquable | 3 | 21 |

Dont **3 annales** sur 2 sessions : le QROC 4 de 2023/2024 S1 (`ANNALES_QROC`,
recto-verso) et deux QCM du sujet de 2024/2025 (examen du 09/01/2025, sans corrigé,
déposé le 15/10/2026), la Q.11 (lipogenèse) et la Q.12 (cholestérol).
**16 QCM sur 20 illustrés** (80 %) : dix figures du ronéo 2026-27 et la FAS
redessinée. **7 cartes absentes du cours 2026-27** (tag `absent-2026`).

Huit thèmes, dans l'ordre du cours :

| Clé | Libellé | Statut |
|---|---|---|
| `lipides` | Métabolisme des lipides | existe déjà (FC 1) |
| `absorption-lipides` | Absorption et transport des lipides | **nouveau** |
| `triglycerides` | Triglycérides : synthèse et stockage | **nouveau** |
| `lipogenese` | Lipogenèse | **nouveau** |
| `acides-gras` | Acides gras | existe déjà (remédiation) |
| `lipolyse` | Lipolyse | **nouveau** |
| `beta-oxydation` | Bêta-oxydation | existe déjà (remédiation) |
| `cholesterol` | Cholestérol | **nouveau** |

Les cinq nouveaux libellés sont à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) ; tant qu'ils n'y sont pas,
`test_tout_theme_du_paquet_a_son_libelle` échoue sur ce chapitre, et lui seul.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-bmcp-lipides` — Ronéo & Juliette, « Métabolisme lipidique » (14 p.) | **2026-27** | **la base** : chaque note relue porte sa page ; c'est ce que le lecteur ouvre |
| `src-cours-lipides` — Ronéosaure, FC n°8 (AC) (11 p.) | 2024-25 | appoint ; source de 4 cartes absentes du cours 2026-27 |
| `src-roneo-lipides-2324` — Charonéo 2023-24 (10 p.) | 2023-24 | appoint ; la consigne du professeur (p. 1) ; source de 3 cartes absentes |
| `src-annales-lipides` — Ronéosaure, « BMCP 8 - Métabolisme des lipides » (2 p.) | 2024-25 | 2 QCM (déjà dans FC 1) et le QROC 4 |
| `src-sujets-bmcp-2425` — « Sujets de BMCP 2024/2025, session 1 » (30 p.) | 2024-25 | le sujet de l'examen du 09/01/2025, **sans corrigé** (dépôt `Annales_15102026/`, 15/10/2026) : Q.11 et Q.12 ; `SRC["sessions"]["2024/2025 S1"]` ; déclaré à l'identique dans tous les chapitres de BMCP qui en cartent une question |
| tableau d'erreurs BMCP 2024-25 (« Erratas BMCP ») | 2024-25 | cinq entrées sur ce cours, toutes intégrées à la version AC (SREBP au lieu de « CPT II », désaturation, géranyl pyrophosphate…) |
| tableau d'erreurs BMCP 2026-27 | 2026-27 | **n'existe pas encore** au 28/09/2026 |

Les vérifications faites hors du cours sont citées dans la carte qui s'en sert :
UniProt P21695 (GPD1), Lowe, J Lipid Res 2002 (lipase pancréatique),
StatPearls (chylomicrons, cholestérol, néoglucogenèse), Chirala et Wakil, Lipids
2004, et Liu et al., Int J Biochem Mol Biol 2010, PMC2919769 (FAS), Carta et al.,
Front Physiol 2017, et Kokatnur et al., Am J Clin Nutr 1979 (palmitate et acide
oléique), Linus Pauling Institute (acides gras essentiels), Beaty et Lane 1983
(citrate et ACC), Hogenboom et al. 2004 (mévalonate kinase et phosphomévalonate
kinase cytosoliques), PubChem (lanostérol, C30H50O), Brown et Goldstein, Cell
1997 (SREBP), FDA 2021 et RCP de l'atorvastatine (statines et grossesse),
Schönfeld et Reiser 2013 (cerveau et acides gras), Pinkosky et al. 2016 et Ray
et al., NEJM 2019 (acide bempédoïque).

## Ce que le cours a dicté

- **Pas de formule** : « l'évaluation de ce cours ne portera pas sur les
  formules chimiques des lipides » (p. 2). Aucune carte n'en demande.
- **Les enzymes à leur étape** : le Charonéo 2023-24 rapporte la consigne du
  professeur, « savoir à quelles étapes les enzymes agissent » (p. 1). D'où les
  cartes sur les quatre enzymes des triglycérides (`lip-fa-tg-etapes`), les
  domaines de la FAS (`lip-zo-fas`, `lip-fa-fas-etapes`), les quatre enzymes de
  la β-oxydation (`lip-zo-beta`) et l'ordre de la voie du cholestérol
  (`lip-zo-cholesterol`).
- **Le compte des carbones** : 2 C, 3 C (malonyl-CoA), 16 C (palmitate, sept
  tours), 6 C, 5 C, 10 C, 15 C, 30 C, 27 C — `lip-fa-carbones-cholesterol`,
  `lip-qr-fas-tours`.
- **Les couples à ne pas inverser** : insuline et catécholamines sur les
  périlipines (`lip-rv-perilipines-hormones`), déphosphorylation et
  phosphorylation de l'ACC (`lip-qc-acc`).
- **Le gris** : le ronéo n'en a pas, et ne définit aucun passage hors
  programme. Les passages en police à chasse fixe (remarques, p. 2, 4, 5, 6, 8,
  9) sont la voix des rédacteurs et se cartent comme le reste.

## Ce que les annales ont dicté

Le polycopié BMCP 8 porte trois questions sur deux sessions. **Les deux QCM
sont déjà dans le chapitre FC 1** (`bmcp_metabolisme`) : 2023/2024 Q.17
(lipolyse, `met-an-2324-q17`) et 2022/2023 Q.11 (corps cétoniques,
`met-an-2223-q11`) ; ils ne sont pas repris ici. Reste le **QROC 4 de 2023/2024**
(statines et projet de grossesse), transcrit mot pour mot, fautes du
polycopié comprises (« activées par les statine », « le déroulement la
grossesse »), en recto-verso (`lip-an-2324-qroc4`) : il demande trois
réponses rédigées et un conseil. Les cartes du cours qui le préparent :
`lip-fa-hmgcoa`, `lip-fa-regulation-transcriptionnelle`,
`lip-rv-statines-srebp`, `lip-qc-statines`, `lip-qc-blocage-terminal`.

**Le sujet de 2024/2025** ajoute deux QCM du professeur, sans corrigé : la Q.11
(`lip-an-2425-q11`) parcourt la lipogenèse — navette citrate et ATP-citrate lyase,
ACC, FAS, carbone β, NADPH2 consommé — et la Q.12 (`lip-an-2425-q12`) la biosynthèse
du cholestérol — les carbones, l'acétyl-CoA de départ, les compartiments, SREBP2, la
DHCR7.

## Les schémas cliquables

| Fichier | Ce qu'on clique | Carte |
|---|---|---|
| `fas-cycle.svg` | les sept domaines de la FAS : MAT, KS, KR, DH, ER sur l'anneau, l'ACP au centre, la TE à part | `lip-zo-fas` |
| `beta-oxydation.svg` | les quatre enzymes d'un tour de β-oxydation | `lip-zo-beta` |
| `cholesterol-voie.svg` | les neuf étapes de l'acétyl-CoA au cholestérol, et la case de l'HMG-CoA réductase parmi huit | `lip-zo-cholesterol` |

**Le ronéo n'a aucune figure de la FAS** : le schéma suit son texte (p. 8-9).
Aucun nom de domaine n'y est écrit, seulement ce qui entre et sort (malonyl-CoA,
CO2, NADPH, eau, palmitate) : reconnaître le domaine à ce qu'il fait est la
question. Une version légendée (`fas-cycle-legende.svg`) illustre la correction
des cartes de la FAS. Pour la β-oxydation et le cholestérol, la figure légendée
du ronéo (p. 11, p. 13) est en correction. **Aucun compartiment n'est dessiné**
sur la voie du cholestérol : voir ci-dessous. La navette carnitine n'a pas de
schéma ici, FC 1 en a déjà un (`met-zo-carnitine`).

## Les erreurs du ronéo 2026-27

Le ronéo n'est pas corrigé ; chaque erreur est portée par une carte, avec un
`ATTENTION` qui dit son genre — `(prise de notes)`, `(cours)` ou `(douteux)`,
selon le tableau où elle se range —, et la carte retient la bonne lecture.
L'écran de correction en fait un encadré, et la carte entre dans le thème
« Pièges des ronéos ». Les deux erreurs du Ronéosaure 2024-25, plus bas, gardent
un `ATTENTION` sans genre. Chaque erreur s'inscrit aussi
dans `contenu/ERRATA_RONEOS_2026-27.md`. À l'examen, on répond d'abord comme le
professeur (règle de Vincent, 28/09) : chaque erreur a été triée, preuves à
l'appui, entre une prise de notes fausse (ce tableau) et le cours lui-même (le
tableau suivant).

| Page | Le ronéo dit | Ce qui est juste | Carte |
|---|---|---|---|
| 4 | la digestion donne « des acides gras ou des diacylglycérols » | des acides gras et des 2-monoacylglycérols (la figure de la même page montre le MAG) | `lip-qc-chylomicrons` (A) |
| 4 | « les chylomicrons sont des protéines majoritairement composés de l'ApoB » | des lipoprotéines à plus de 75 % de triglycérides, 2 % de protéines ; l'ApoB-48 est leur protéine de structure | `lip-qc-chylomicrons` (B) |
| 5 | « le glycérol devient glycérol-3-phosphate par la dihydroxyacétone phosphate » | la DHAP devient glycérol-3-phosphate, réduite par la glycérol-3-phosphate déshydrogénase ; la diapositive p. 6 part bien de la DHAP, comme le cours 2024-25 (FC n°8, p. 4) | `lip-qc-tg-synthese` (B) |
| 5 | le triglycéride est « constitué de 3 acides gras activés » | l'acyl-CoA est la forme activée ; dans le triglycéride, les acides gras sont estérifiés, sans CoA | `lip-qc-tg-synthese` (A) |
| 6 | « suppression d'un phosphore » (lipine) | c'est un groupement phosphate qui part (phosphatase de l'acide phosphatidique, figure p. 6) | `lip-qc-tg-synthese` (D) |
| 7 | l'acétyl-CoA « produit ... par le cycle de l'acide citrique (cycle de Krebs) » | le cycle de Krebs le consomme ; il vient de la pyruvate déshydrogénase (p. 3), de la β-oxydation, des acides aminés | `lip-qc-lipogenese` (E), `lip-fa-citrate` |
| 7 | le palmitate, « l'acide gras le plus répandu dans notre organisme » | le plus répandu des acides gras SATURÉS (20 à 30 %) ; le plus abondant de tous est l'acide oléique | `lip-qr-palmitate` |
| 11 | cinq tirets pour un tour de β-oxydation (« déshydrogénation », puis « 1er oxydation ») | une seule et même réaction : un tour en compte quatre, comme la figure de la même page | `lip-qc-beta-ox` (B), `lip-fa-beta-ox`, `lip-zo-beta` |
| 14 | « protealyse » | protéolyse | `lip-fa-regulation-transcriptionnelle` |

**C'est le cours lui-même** : la formule est sur la diapositive de la professeure,
et le ronéo la reproduit fidèlement. L'`ATTENTION` dit, dans l'ordre, « c'est le
cours lui-même » et d'où vient la formule, « À l'examen : » ce qu'on répond,
puis « La référence : » le fait juste et sa source.

| Page | Ce qui est écrit | D'où vient la formule | À l'examen | La référence | Carte |
|---|---|---|---|---|---|
| 6 (figure) | « GPDH : Glyceraldehyde 3-Phosphate Deshydrogénase » | la diapositive de la Pr Benlian reproduite p. 6 : la légende est dans l'image, de la même main que ACS, GPAT, AGPAT, LIPIN PAP et DGAT, pas dans le texte des rédacteurs | la GPDH qui réduit la DHAP en glycérol-3-phosphate est la glycérol-3-phosphate déshydrogénase | GPD1, UniProt P21695 ; la glycéraldéhyde-3-phosphate déshydrogénase est une enzyme de la glycolyse | `lip-qc-tg-synthese` (B), légende de la figure |

**Les points douteux**, dits dans la carte, sans changer sa clé :

| Page | Le point | Carte |
|---|---|---|
| 3 | « on ne fait jamais de sucre avec du gras » : vrai des acides gras pairs ; le glycérol est néoglucogénique, et le propionyl-CoA d'un acide gras impair aussi | `lip-qc-sens-unique` (B) |
| 4 | les micelles mixtes sans sels biliaires | `lip-qc-absorption` (B) |
| 8 | la FAS « composée de 7 sous-unités » : sept domaines d'une chaîne, homodimère | `lip-qc-fas` (A) |
| 9 | les acides gras essentiels « produits en quantité insuffisante » : les précurseurs (linoléique, alpha-linolénique) ne sont pas produits du tout | `lip-qc-essentiels` (A) |
| 11 | 106 ATP pour le palmitate contre 38 pour le glucose : deux comptes différents (30-32 au compte moderne) | `lip-qr-rendement` |
| 12 | les phosphorylations du mévalonate dans le peroxysome : cytosoliques chez l'homme ; le Ronéosaure 2024-25 hésite | `lip-fa-carbones-cholesterol`, `lip-qc-vue-ensemble` (D) ; aucune carte ne demande ce compartiment |
| 13 (figure) | « 27C » imprimé sous le lanostérol, qui a 30 carbones ; il vaut pour le cholestérol, à sa droite | `lip-fa-carbones-cholesterol`, légende de la figure |
| 14 | statines : « contre-indication absolue », « puissant effet tératogène » ; la FDA a levé la contre-indication de principe en 2021, les RCP français la maintiennent | `lip-qc-statines` (D), `lip-an-2324-qroc4` |

Et deux erreurs du Ronéosaure 2024-25, signalées sur les cartes qui s'en
servent : « huit cycles » pour la FAS (p. 6 ; il en faut sept —
`lip-qc-fas`, `lip-qr-fas-tours`, `lip-fa-fas-etapes`) et un cerveau qui « ne
possède pas les CPT » (p. 9 ; `lip-rv-cerveau-hematies`). Le Ronéosaure prête
aussi à l'inhibiteur de l'ATP-citrate lyase une baisse des triglycérides (p. 5) :
la carte `lip-rv-acly-medicament` s'en tient au LDL-cholestérol, que ses essais
abaissent.

**Relecture du 28/09.** Un distracteur a été remplacé : `lip-qc-chylomicrons` E
disait « la vitesse de sécrétion des lipoprotéines riches en ApoB est réglée par
l'insuline », à coter faux d'après le cours ; or l'insuline freine bel et bien la
sécrétion hépatique d'ApoB à court terme, en faisant dégrader l'ApoB-100 (Lewis
et al., J Clin Invest 1995), et un étudiant qui le sait aurait été puni. L'item devient « l'entérocyte sécrète le chylomicron dès que l'ApoB est
synthétisée, chargée ou non », faux par le cours et par la biochimie ; la clé
reste ACD.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2023/2024 S1, QROC 4 | « pas de réponse officielle » | réponse déduite du cours, pages citées (2026-27 p. 12-14 ; 2024-25 p. 10-11) | la table de corrections n'en donne pas ; la carte le dit en tête de son explication |
| 2024/2025 S1, Q.11 (lipogenèse) | aucune (sujet sans corrigé) | **ACE**, déduite | A, l'ATP-citrate lyase libère l'acétyl-CoA dans le cytosol (p. 7-8) ; C, acétyl-CoA, malonyl-CoA, palmitate (p. 7-9) ; D fausse, le NADPH2 est consommé (p. 9) ; E, le carbone β (p. 9). **B discutée** : « enzyme effectrice » n'est pas dans le cours ; l'ACC est l'enzyme clé, limitante (p. 8), la FAS la chaîne de montage — retenue fausse ; ATTENTION, CONFLITS |
| 2024/2025 S1, Q.12 (cholestérol) | aucune (sujet sans corrigé) | **D**, déduite | A fausse, unités à 5 carbones (p. 12) ; B fausse, l'acétyl-CoA est le substrat initial (p. 12) ; D, SREBP (p. 14 ; cours 2024-25, p. 11) ; E fausse, malformations et intermédiaires, pas une hypocholestérolémie isolée (p. 13). **C discutée** : le ronéo 2026-27 met l'étape initiale, l'HMG-CoA réductase, dans le RE (p. 12) — fausse ; les cours 2024-25 (p. 10) et 2023-24 (p. 9-10) envoyaient les dérivés isopréniques au peroxysome, et le professeur a pu l'entendre vraie (clé CD) ; ATTENTION, CONFLITS |

Deux conflits déclarés, tous deux sur le sujet de 2024/2025 : des propositions que le
cours ne tranche pas nettement (Q.11 B, Q.12 C).

## Absent du cours 2026-27

Sept cartes entières viennent des années précédentes ; elles le disent en tête
de leur explication, portent le tag `absent-2026` et citent leur source à la
page, jamais le ronéo de l'année.

| Carte | Source |
|---|---|
| `lip-rv-transporteurs-cible` — bloquer les transporteurs de la bordure en brosse | Charonéo 2023-24, p. 4 |
| `lip-rv-acly-medicament` — l'hypolipémiant qui inhibe l'ATP-citrate lyase, au foie | Ronéosaure 2024-25, p. 5 (et Charonéo p. 5) |
| `lip-rv-dha-premature` — le DHA du prématuré | Charonéo 2023-24, p. 7 |
| `lip-rv-glycerol-devenir` — le glycérol, néoglucogénique | Ronéosaure 2024-25, p. 8 (et Charonéo p. 8) |
| `lip-rv-cerveau-hematies` — les cellules qui ne brûlent pas d'acides gras | Ronéosaure 2024-25, p. 9 |
| `lip-rv-cholesterol-non-degrade` — le noyau stérol, jamais dégradé | Ronéosaure 2024-25, p. 9 (et p. 2) |
| `lip-qr-dhcr7` — la DHCR7 et le syndrome malformatif | Charonéo 2023-24, p. 10 |

## Les figures du ronéo

Dix figures, extraites en PNG (réduites à 900 px de large, 256 couleurs) :
les deux classes de lipides et le schéma sources-besoins (p. 2), les carrefours
(p. 3), l'absorption intestinale (p. 4), l'assemblage sur l'ApoB (p. 5), la
synthèse des triglycérides (p. 6 ; la légende GPDH, fausse, est un lapsus de
la diapositive, dit dans `IMAGES`), la navette citrate (p. 7), la navette
carnitine (p. 10), le cycle de β-oxydation (p. 11), la voie du mévalonate au
cholestérol (p. 13). Elles illustrent la correction, jamais la question. Le
logo de la page 1 n'est pas repris.

## Le lexique

Seize termes, accueillis ici parce que le ronéo les emploie et qu'aucun autre
chapitre de BMCP ne les porte : lipogenèse, lipolyse, triglycéride,
lipoprotéine, apolipoprotéine, chylomicron, micelle, amphiphile, périlipine,
carnitine, thiolyse, palmitate, squalène, cholestérol, tératogène, myopathie.
Pages mesurées dans le texte du ronéo 2026-27. Les racines qu'enseigne la FC de
sémantique citent sa page (-genèse p. 7, -lyse p. 9, apo- p. 3, -phile p. 4,
chol(é)- p. 2, térat(o)- et -gène p. 6, -pathie p. 5) ; les autres sont hors
FC. L'origine grecque ou latine de chaque terme et de chaque racine est
proposée à la table `etymologies.json` du skill (vérifiée sur le Wiktionnaire,
qui cite le TLFi, et sur le Bailly et le Gaffiot), puis écrite par
`appliquer_etymologies.py`.

## À relire

Aucune carte ne porte le tag `a-relire` : chaque carte cite sa page, et les
clés déduites — celle du QROC 4, celles des Q.11 et Q.12 de 2024/2025 — le sont du
cours, pages citées ; les deux propositions discutées ont chacune une page qui les
tranche dans le ronéo de l'année.

## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier (BMCP) ou du 6 janvier (SSH, papier). Sous les annales, 13 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 2 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `lipogenese` | 6 | 1 | 1 |
| `cholesterol` | 7 | 1 | 2 |

**Le schéma** `ech-lipides`, « Lipogenèse et cholestérol · deux voies de synthèse », donne 18 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_LIPIDES`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

## Régénérer

```powershell
cd contenu\chapitres\bmcp_lipides
..\..\..\app\.venv\Scripts\python.exe generer.py
```
