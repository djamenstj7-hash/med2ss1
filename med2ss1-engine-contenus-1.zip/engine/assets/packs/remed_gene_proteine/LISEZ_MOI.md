# Du gène à la protéine — paquet ECL Remédiation

90 notes, 178 cartes. Chapitre `chap-remed-gene-proteine` de l'UE ECL
Remédiation (séances 7 et 8, 19/11 et 26/11 ; test intermédiaire 3 le
03/12/2026, QCM avec degré de certitude). Sources : le diaporama « Du gène à la
protéine » de **2024** (43 diapositives) et le **test intermédiaire 3 de
2024-25** (25/11/2024), questions 1 à 10 et 14.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 38 | 38 |
| QRU | 2 | 2 |
| Texte à trous | 13 | 89 |
| QROC | 13 | 13 |
| Recto-verso | 8 | 8 |
| Schéma cliquable | 2 | 14 |
| Lexique | 14 | 14 |

Dont **11 annales** (11 QRM), une session (`2024/2025 TI3`). **29 QCM du
cours** (27 QRM, 2 QRU), chacun avec une justification par proposition. **40
QCM sur 40 sont illustrés** (le hook : 100 %), 76 notes sur 90.

Neuf thèmes, dans l'ordre du cours :

| Clé | Libellé | Notes (dont annales) |
|---|---|---|
| `acides-nucleiques` | ADN, ARN et génome | 17 (3) |
| `chromosome-structure` | Chromatine et structure du chromosome *(celui de `genet_cytogenetique`)* | 3 (0) |
| `replication-adn` | La réplication de l'ADN | 12 (2) |
| `transcription-maturation` | Transcription et maturation des ARN messagers | 6 (2) |
| `traduction-code` | Traduction et code génétique | 8 (2) |
| `polymorphisme-genetique` | Polymorphisme génétique : macrolésions et microlésions | 7 (0) |
| `lecture-caryotype` | Lire un caryotype : classement et formule *(celui de `genet_cytogenetique`)* | 4 (1) |
| `techniques-moleculaires` | Techniques de biologie moléculaire : hybridation, blots, PCR, Sanger | 16 (1) |
| `mutations-instables` | Mutations instables : seuils, biais parental, mécanismes *(celui de `genet_instables`)* | 3 (0) |

Les six libellés nouveaux sont dans `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`), ajoutés avec ce chapitre (C30).

Aucun ne porte de chiffre ; aucune clé n'en recouvre une existante. Les trois
thèmes repris le sont là où leur libellé dit vrai : la compaction (p. 10), la
lecture des caryotypes (p. 25-26), les expansions de triplets et la famille
Steinert (p. 35-37).

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-remed-gene` — « Du gène à la protéine — ECL Remédiation 2024 », `Remediation/Du gène à la protéine 2024.pdf` (43 p.) | **2024-25** | **la base** : chaque note du cours porte sa diapositive (`page=`), c'est ce que le lecteur ouvre (`chapitre=`) ; ses figures illustrent les corrections |
| `src-remed-ti3-2425` — « Test intermédiaire 3 — 2024-2025 (sujet photographié) » | 2024-25 | les 11 annales ; déclaré mot pour mot comme dans `remed_souches`, qui prend les questions 15 à 21 du même sujet |

**Des diapositives d'une année passée.** Les séances 2026-27 n'ont pas eu lieu
(19/11 et 26/11) : l'auteur de la fiche porte « 2024-25 », et chaque carte de
cours montre le badge « Cours 2024-25 ». Aucune carte ne dit « Absent du cours
2026-27 », et rien n'entre dans `contenu/ERRATA_RONEOS_2026-27.md` : ce n'est
pas une ronéo de l'année. Quand le support 2026-27 paraîtra, relire toutes les
cartes contre lui.

Vérifications hors du cours, citées dans la carte qui s'en sert : Alberts,
Molecular Biology of the Cell (TBP et l'ordre de l'initiation, la boîte TATA à
25-30 pb, les trois ARN polymérases, la coiffe 7-méthylguanosine, les
codons d'initiation non-AUG, le code mitochondrial, l'électrophorèse, la Taq) ;
Lodish (boîte TATA, codons d'initiation) ; International Myotonic Dystrophy
Consortium, Neurology 2000 (seuils de la DM1) ; GeneReviews (Myotonic Dystrophy
Type 1) et la FC n°6 de génétique, Ronéosaure 2025-26, p. 6 (formes congénitales
transmises par la mère) ; Strachan et Read, Human Molecular Genetics (épissage
et cadre de lecture) ; le code IUPAC des bases ambiguës (Y = C ou T).

## Ce que le cours a dicté

- **Un cours fait d'exercices**, aucun corrigé imprimé. Chacun a sa carte, et
  chaque calcul est refait avec sa démarche dans l'explication :
  - p. 5, la « substance » : le dGTP (`rgen-qc-dgtp`, le schéma cliquable
    `rgen-zo-nucleotide`) ;
  - p. 8, extrémités, pourcentages (28,9 % d'adénine → T 28,9 %, G = C =
    21,1 %), dénaturation (`rgen-qc-exercice-adn`, `rgen-qr-pourcentage`) ;
  - p. 19, l'ordre de la transcription : **C-A-B-D-E**, l'ordre 2 de la
    diapositive, retenu d'après Alberts (`rgen-qc-transcription-ordre`, une QRU
    à qui deux ordres ont été ajoutés) ;
  - p. 21, la traduction du fragment de 28 pb : brin complémentaire, ARNm, trois
    cadres (stop UAG au 8e codon du cadre 1, au 2e du cadre 3), cadre 2 utilisé,
    **Arg-Leu-Gly-Ser-Pro-Phe-Arg-Ser-Arg** ; la délétion du « second T de
    l'extrémité 3' » lue comme celui de la position 22 (les T en 25, 22, 19 à
    partir du 3') → **Arg-Leu-Gly-Ser-Pro-Phe-Arg-Val…**, un décalage
    (`rgen-qc-cadres-lecture`, `rgen-qr-brin-complementaire`, `rgen-qr-arnm`,
    `rgen-qr-proteine`, `rgen-qr-deletion`, `rgen-rv-trois-cadres`) ;
  - p. 26, deux caryotypes : A 46,XX normal, B 47,XY,+21 ; la FISH pour le même
    diagnostic (`rgen-qc-caryotypes-cours`) ;
  - p. 35, la famille Steinert : mère 30/30, père 30/65 (sans symptôme), enfant
    30/1 130 (forme grave), fœtus 30/100 (`rgen-qc-steinert`) ;
  - p. 40, la PCR sur ADNc : amorce 1 = l'encadré 14-33 tel quel (A), amorce 2
    = le complémentaire inversé de l'encadré 164-183, GAAGGTGACATTGACGCTGT (D) ;
    B et C sont des complémentaires non inversés ; le fragment fait **170 pb**,
    pas 111 (`rgen-qc-pcr`, `rgen-qr-taille-pcr`, `rgen-qr-amorce-antisens`,
    `rgen-rv-adnc`) ;
  - p. 43, le Sanger du malade : un double pic C/T, noté Y, une substitution
    hétérozygote (`rgen-qc-sanger-application`).
- **Les cinq écarts des diapositives**, dits par un ATTENTION sans genre dans la
  carte qui porte la notion (« À l'examen : », puis « La référence : ») :

| Page | Ce que disent les diapositives | Ce qui est juste | Carte |
|---|---|---|---|
| 18 | la figure du bas range l'ADN polymérase α sur le brin tardif et la δ sur le brin avancé | α, avec la primase, amorce ; δ allonge le brin tardif, ε le brin avancé (Alberts) | `rgen-qc-proteines-fourche` D |
| 31 | l'accolade rattache le « décalage du cadre de lecture » aux sites d'épissage, sans condition | un exon perdu ou un intron gardé ne décale le cadre que si sa longueur n'est pas multiple de trois (Strachan et Read) | `rgen-qc-microlesions-place` E |
| 35 | le père, non malade (65 CTG), transmet 1 130 CTG à l'enfant gravement atteint | l'exercice est construit : les formes congénitales, au-delà de 1 000 CTG, sont presque toujours transmises par la mère (FC n°6 de génétique, Ronéosaure 2025-26, p. 6 ; GeneReviews) | `rgen-qc-steinert` D |
| 36-37 | la figure place la mutation complète de la DM1 au-delà de 100 CTG, la prémutation entre 50 et 150 ; le tableau, des symptômes dès 81 — le fœtus à 100 est à cheval | à l'examen, le tableau de l'application (p. 37) ; la référence : 5-37 normal, 38-49 prémutation, au-delà de 50 mutation complète (IDMC 2000) | `rgen-qc-steinert` E, `rgen-fa-steinert` |
| 36-37 | le père à 65 CTG : « aucun symptôme » au tableau, une prémutation pour la figure | au-delà de 50 CTG, c'est déjà une mutation complète de forme légère (cataracte tardive, ou rien) (IDMC 2000) | `rgen-qc-steinert` B |

  Sans ATTENTION, parce qu'aucune réponse n'en dépend : « Uracyl » (p. 7),
  « boiteTATA » (p. 19), « microphotograhie » (p. 25), « Didéoxyribonucléotide »
  (p. 41). La lettre C de l'exercice p. 5 manque sur l'accolade des
  phosphates : la carte le dit.
- **Ce qui n'est pas sur les diapositives** et que les annales demandent est
  pris dans Alberts et cité : la boîte TATA, les ARN polymérases I et III, la
  coiffe, les codons d'initiation non-AUG. La polymérase thermostable de la
  PCR n'est pas sur la p. 38 : l'explication de `rgen-fa-pcr` la nomme.
- **Pages sans carte** : p. 1 (titre), p. 2 (objectifs : le sommaire), p. 12
  (la question « quelles possibilités pour les brins parentaux ? », dont la
  réponse est la p. 13), p. 32 (intercalaire « Techniques de diagnostic »).
  Les p. 15, 30, 39 et 42 n'ont pas de carte à leur numéro mais illustrent ou
  sont citées : le gradient de CsCl (`rgen-fa-meselson`), le code à une lettre
  (`rgen-qc-code`), le choix des amorces (`rgen-qr-amorce-antisens`), la
  méthode de Sanger (`rgen-qc-sanger`). La p. 31 a désormais la sienne
  (`rgen-qc-microlesions-place`).
- **Ce que la génétique carte déjà au niveau DFGSM2** n'est pas recopié
  (`genet_cytogenetique`, `genet_instables`, `genet_sequencage`) : les cartes
  d'ici sont neuves et restent au niveau de la remédiation.

## Ce que les annales ont dicté

Le test intermédiaire 3 de 2024-25 (25/11/2024) : 36 QCM, dont « du gène à la
protéine » de 1 à 14. **Les questions 11 à 13 manquent** : la page qui les
portait (IMG_8044) n'a pas été photographiée. Les onze autres sont recopiées
mot pour mot des photographies (IMG_8041 à IMG_8043, haut de IMG_8045),
énoncés gardés tels qu'imprimés : les QCM 7 et 8 sans point d'interrogation ni
point final, le QCM 9 sans « laquelle (lesquelles) », « dideoxynucléotides »
sans accent (QCM 6 C).

| Savoir | Questions |
|---|---|
| Structure de l'ADN : antiparallèle, liaisons hydrogène, désoxyribose, Chargaff, liaison N-osidique | QCM 5, QCM 9, QCM 14 |
| Réplication : bidirectionnelle, primase, hélicase, 5'→3', amorce, brin tardif | QCM 3, QCM 7 |
| Transcription et maturation : ARN polymérases, coiffe, TATA, poly(A), épissage | QCM 1, QCM 4 |
| Traduction et code : codon, AUG, ARNt, ARNr, universalité | QCM 2, QCM 8 |
| Techniques : PCR, Southern, ddNTP, FISH, électrophorèse | QCM 6 |
| Caryotype : sexe, trisomie, chromosomes mitotiques, FISH, histones | QCM 10 |

**Le caryotype du QCM 10** a été lu sur la photographie à pleine définition,
ses deux moitiés recollées : 47 chromosomes, un X et un Y, **trois chromosomes
18**, deux 21 — 47,XY,+18. La proposition C (« une trisomie 21 ») est le piège.
La figure est l'image de la question (`illustration_question`), recadrée sous
les chromosomes : le bandeau du laboratoire, qui porte des initiales, est
coupé. Le caryotype du cours (p. 26) va en correction, et une QROC demande la
formule (`rgen-qr-formule-ti3`).

## La copie annotée et les clés

**Aucun corrigé n'existe** : les onze clés sont déduites du cours (ou d'Alberts,
cité), toutes `officielle=False`, et chaque explication commence par « Clé
déduite du cours, absente de la table de corrections. » Elle dit ensuite ce que
montre la copie de l'étudiant : lettres entourées (choisies), barrées
(rejetées), quelques-unes entourées et rayées (ambiguës), mots encerclés, notes
en marge (« trad », « codon stop », « tardif », « Poids », « AAA 3' »), et un
**surlignage rose sur quatorze propositions** (QCM 1 B, 2 B et C, 3 B, 4 B et
D, 5 E, 6 C et E, 7 B et D, 8 B et C, 14 D).

Le rose tombe à chaque fois sur une proposition où le choix de la copie
s'écarte de la clé déduite, et jamais ailleurs : lu comme la marque des erreurs
relevées à la correction, il concorde avec la clé déduite sur les 48
propositions dont la marque est nette. **Sept lettres sont ambiguës**, à la fois
entourées et barrées ou griffonnées (QCM 1 E, 2 C, 4 A, 6 E, 7 A, 7 B, 8 E), et
la même marque s'y lit tantôt choisie, tantôt rejetée : elles sont décrites,
pas interprétées. C'est une contre-épreuve qui concorde, jamais une clé.

| Question | La copie annotée | Clé retenue | Pourquoi l'écart |
|---|---|---|---|
| QCM 1 | entoure A, D ; barre B, C ; E rayée et entourée | **ABD** | B barrée, rose : la coiffe protège bien l'ARNm de la dégradation (Alberts) |
| QCM 2 | entoure D, E ; barre A, B ; C barrée et entourée | **BCDE** | B barrée, C barrée et entourée, roses : AUG est le codon d'initiation (p. 22) ; l'ARNt apporte un acide aminé spécifique (Alberts) — B est le cas discutable ci-dessous |
| QCM 3 | entoure A, E ; barre B, C, D | **ABE** | B barrée, rose : la primase synthétise les amorces d'ARN (p. 18) |
| QCM 4 | entoure A (barrée puis entourée), D ; barre B, C, E | **AB** | B barrée, rose : l'épissage élimine les introns ; D entourée, rose : la poly(A) n'est pas excisée (p. 20) |
| QCM 5 | entoure A, C, D ; barre B, E | **ACDE** | E barrée, rose : la dénaturation par la chaleur est réversible (p. 27, 33) |
| QCM 6 | entoure A, B, C, D ; E rayée et entourée, « Poids » | **ABDE** | C entourée, rose : les ddNTP sont ceux du Sanger (p. 41) ; E, rose : le gel trie par taille |
| QCM 7 | entoure A (griffonnée dans son cercle), E ; B barrée et entourée ; barre C, D | **ADE** | B, rose : le brin neuf s'allonge de 5' vers 3' ; D barrée, rose : la polymérase exige une amorce (p. 18) |
| QCM 8 | entoure A, B ; barre C, D ; E entourée et barrée | **AC** | B entourée, rose : les ARNr ne sont pas traduits (p. 9) ; C barrée, rose : le code est universel (p. 22) |
| QCM 9 | entoure D | **D** | aucun écart |
| QCM 10 | entoure B, D, E ; barre A, C | **BDE** | aucun écart |
| QCM 14 | entoure B, D (d'un trait en croix) ; barre A, C, E | **B** | D, rose : les bases s'apparient de façon complémentaire, jamais au hasard (p. 6) |

**Le cas discutable, déclaré** (`CONFLITS`, ATTENTION dans la justification) :
QCM 2 B, « La traduction des ARNm commence toujours par le codon AUG ». Vraie
pour le cours, qui ne connaît qu'un codon d'initiation (p. 22), et pour la
copie, qui la surligne en rose. Discutable par son « toujours » : GUG et UUG
servent aussi de codons d'initiation chez les bactéries, et de rares ARNm
eucaryotes démarrent sur un CUG ou un ACG (Alberts ; Lodish). Retenue vraie.

Sans ATTENTION, une nuance dite dans la justification : QCM 8 C, « Procaryotes
et Eucaryotes partagent le même code génétique », vraie — le code est
universel ; ses rares variantes (le code mitochondrial, quelques bactéries) ne
changent pas la règle.

## Les schémas cliquables

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `rgen-fourche-nue.svg` (`rgen-zo-fourche`) | l'ADN parental, l'hélicase, les deux brins matrices, le brin tardif, le brin avancé | 6 |
| `rgen-nucleotide-nu.svg` (`rgen-zo-nucleotide`) | le triphosphate, le carbone 5', le désoxyribose, les carbones 1', 2' et 3', la liaison N-osidique, la base | 8 |

**La fourche** est redessinée d'après la p. 18, sans une légende : les brins
parentaux en bleu, les brins neufs en orange, les amorces d'ARN en rouge, la
flèche rouge du sens de progression, les extrémités 5' et 3'. Ce qui distingue
les brins neufs, c'est la pointe des flèches — l'extrémité 3'-OH, qui suit la
fourche sur le brin avancé et s'en éloigne sur chaque fragment d'Okazaki. Les
zones des brins sont des bandes autour des tracés, tirées des mêmes points
(`_bande`, jointures en onglet) ; l'aperçu, zones superposées, a été relu.

**Le nucléotide** est le dGTP de l'exercice p. 5, sans numéro de carbone ni
nom : seuls les atomes (P, O, OH, H, et les quatre azotes de la guanine, N1,
N3, N7, N9) sont écrits, comme dans une formule, avec les doubles liaisons de
la p. 5. Le cycle du sucre est une zone en retrait, pour que les carbones de
ses sommets soient des zones à part ; la zone de la base est un polygone qui
prend le sommet C8 et laisse libre le coin de la liaison N-osidique.

La légende affichée sous chaque schéma pendant la question ne situe rien : elle
donne le code des couleurs (fourche) ou dit que seuls les atomes sont écrits
(nucléotide).

Les versions légendées (`rgen-fourche.svg`, `rgen-nucleotide.svg`), tirées des
mêmes constantes, illustrent les corrections.

**Illustrations** : les 40 QCM portent une figure, 76 notes sur 90. Trente-sept
figures sont extraites des diapositives en PNG (`media/`, 256 couleurs), plus la
photographie du caryotype du sujet (`PHOTOS`, source : le sujet). Trois QCM du
cours montrent leur figure dès la question, parce que la lire est la question :
la substance de la p. 5 (`rgen-qc-dgtp`, légendée sans nommer la molécule), les
caryotypes A et B (`rgen-qc-caryotypes-cours`) et le Sanger du malade
(`rgen-qc-sanger-application`), comme le QCM 10. La p. 33 entre deux fois : la
figure de l'hybridation seule, et la diapositive entière avec ses trois blots,
le portrait d'E. M. Southern effacé (`rgen-hybridation-blots.png`).

## Le lexique

Quatorze termes, aux pages mesurées avec `chercher_pages.py` dans le PDF du
cours : nucléotide (4, 5, 7, 8, 28, 38, 41), nucléoside (4), nucléosome (10),
génome (9), réplication (2, 12, 13, 17), transcription (2, 3, 19, 20, 40), codon
(21, 22, 30), polymorphisme (2, 23, 24, 28, 29, 31), microlésion (28, 29, 31),
caryotype (25, 26, 28), hybridation (27, 33, 34), amorce (38, 39, 40),
didésoxynucléotide (41, mesuré sur « ddNTP » : la diapositive écrit le mot en
image), anticipation (36). Quatre pages portent le mot dans une image et non
dans le texte du PDF, et ont été lues sur la diapositive : réplication p. 13,
transcription p. 3, codon p. 22 et 30, caryotype p. 28. Identifiants suffixés `-remed` : les termes nus
existent dans d'autres UE.

Chacun dit son origine grecque ou latine. Les étymologies sont versées dans
`.claude/skills/nouveau-chapitre/scripts/etymologies.json` : huit termes nouveaux (nucléotide, nucléoside,
nucléosome, génome, réplication, transcription, codon, microlésion, vérifiés
sur le Wiktionnaire, et le TLFi pour génome, nucléotide et nucléoside), six
recopiés de la table sous leur nouvel identifiant (polymorphisme, caryotype,
hybridation, amorce, didésoxynucléotide, anticipation), et deux racines
nouvelles (`laesio (latin)`, `codex (latin)`) ; microlésion prend la racine
`micr(o)-` de la table (FC de sémantique 2, p. 6). Les définitions et les racines disent mot pour mot ce
qu'`appliquer_etymologies.py` en écrit.

« Polymorphisme » n'a qu'une note dans l'UE, ici : `remed_immuno` l'avait
aussi, sous le même identifiant, et l'a laissé à ce chapitre (critique du
19/10). La définition dit donc aussi le sens de l'immunologie : le système HLA
est polymorphique, de nombreux allèles pour une même molécule.

Laissés de côté : « trisomie », absente du texte PDF (la p. 24 l'écrit en
image) ; « dénaturation », une seule page (27) ; « épissage », dont l'origine
n'est ni grecque ni latine (du néerlandais splissen, Wiktionnaire et TLFi).

## La relecture du sceptique (18/10)

Les 88 notes du rédacteur relues contre les 43 diapositives rendues et les
photographies du sujet (IMG_8041 à IMG_8043, haut de IMG_8045) ; les calculs
refaits par programme (brin complémentaire, ARNm, trois cadres, délétion du
T 22, QCM 9, amorces et 170 pb, numérotation de l'ADNc). Les onze énoncés
d'annales sont conformes mot pour mot, et leurs onze clés tiennent. Ce qui a
changé :

- **Annales** — la copie annotée : C du QCM 2 et B du QCM 7 sont barrées *et*
  entourées, E du QCM 8 entourée *et* barrée (et non « entourée ») ; le rose
  couvre quatorze propositions, pas quinze ; sept lettres ambiguës sont dites
  telles.
- **Schémas** — le nucléotide dessinait la guanine sans ses azotes N1, N3, N7
  (des carbones, dans une formule) : ils sont écrits, avec les doubles
  liaisons ; la zone de la base prend le sommet C8 ; la zone du carbone 3' ne
  s'appelle plus « le carbone 3' et son hydroxyle », qui faisait cliquer l'OH
  sans connaître la numérotation ; les deux légendes affichées pendant la
  question ne situent plus le duplex, l'hélicase, le triphosphate, le sucre et
  la base.
- **Questions qui vendaient leur réponse** — `rgen-qc-dgtp` décrivait la
  molécule dans l'énoncé (triphosphate sur le 5', pas d'OH en 2') : la figure de
  la p. 5 est désormais la question, légendée sans le mot dGTP ;
  `rgen-qc-caryotypes-cours` B annonçait la trisomie 18 du QCM 10.
- **Justes en science, reprises** — `rgen-rv-adnc` (l'ADNc porte aussi les
  régions non traduites, de −107 à après le TAA en 454 : il ne « commence » pas
  à l'ATG) ; `rgen-qc-mutations-codantes` D et E, `rgen-fa-microlesions`,
  `rgen-qr-deletion` (la p. 31 rattache le « frameshift » aux sites
  d'épissage, pas aux insertions-délétions) ; `rgen-qc-genome` D (« une
  cellule humaine » : l'hématie n'a ni noyau ni mitochondrie) ;
  `rgen-qc-polymorphisme` D ; `rgen-qc-cadres-lecture` B.
- **Steinert** — B porte un ATTENTION (65 CTG est déjà, pour la référence, une
  mutation complète de forme légère) ; D cite GeneReviews et la FC n°6 au lieu
  d'Ashizawa 1994, qui traite des contractions.
- **Ajouts** — `rgen-qc-proteines-fourche` (p. 18 : topoisomérase, protéines
  du simple brin, primase, polymérases, avec l'ATTENTION sur α et δ) et
  `rgen-qc-microlesions-place` (p. 31, qui n'avait pas de carte) ;
  `rgen-hybridation-blots.png` pour les deux cartes qui demandent les blots.
- **Lexique** — `micr(o)-` au lieu d'une racine `micro-` qui la doublait ;
  nucléoside « formé sur le latin » comme nucléotide (TLFi : issu de NUCLÉ-) ;
  pages de codon, transcription et caryotype complétées.

## La critique d'ensemble (19/10)

Un critique a relu les quatre chapitres de l'ECL ensemble. Ici :
- **`lex-nucleosome-remed`** — « environ 200 paires de bases enroulées autour
  de l'octamère » était faux : environ 147 pb s'enroulent en 1,65 tour, les
  200 pb sont l'unité répétée, ADN de liaison compris (Luger et al., Nature
  1997). La définition le dit maintenant, comme `bmcp_morts_cellulaires`.
- **`lex-didesoxynucleotide-remed`** — « privé de l'hydroxyle du 3' (et de
  celui du 2') » laissait croire qu'un dNTP porte un 2'-OH : il est privé
  *aussi* du 3'-OH.
- **`rgen-qc-sanger` E et `rgen-qc-code` D** — deux propositions recopiaient
  l'annale (TI3 Q6 C et Q2 A) : elles sont reformulées, pour que l'annale
  teste encore autre chose que la reconnaissance.
- **Polymorphisme** — une seule note dans l'UE (ci-dessus).

## À relire

Aucune carte `a-relire` : chaque carte de cours cite sa diapositive, chaque
clé d'annale est déduite du cours ou d'une source citée, et concorde avec la
copie annotée. Toutes les notes ont été relues contre leurs pages (ci-dessus).

À la parution du support 2026-27 (séances du 19/11 et du 26/11) : relire toutes
les cartes contre lui, chiffres compris (28,9 %, 200 à 1000 nucléotides, seuils
CTG), et vérifier si les cinq écarts des diapositives demeurent. Si les
questions 11 à 13 du test 2024-25 sont retrouvées, les carter ici.

## Régénérer

```powershell
cd contenu\chapitres\remed_gene_proteine
..\..\..\app\.venv\Scripts\python.exe generer.py
```
