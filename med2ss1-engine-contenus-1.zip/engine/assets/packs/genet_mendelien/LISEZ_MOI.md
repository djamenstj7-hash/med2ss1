# Maladies génétiques de transmission mendélienne — paquet Génétique

147 notes, 215 cartes. Chapitre `chap-ue-genetique-fc5` de l'UE Génétique.
Cours de la **Pr Florence Petit, le 24/11/2025**, « Maladies génétiques
mendéliennes » (FC n°5 du Ronéosaure 2025-26, 22 pages dont la dernière
blanche) ; annales du polycopié n°5 du Ronéosaure 2024-25 (75 questions sur
neuf sessions) et deux questions du polycopié n°4. Examen du 16 décembre 2026.

**Une fiche provisoire.** Le ronéo 2026-27 de ce cours n'est pas paru au
02/10/2026 : le chapitre est carté sur le Ronéosaure 2025-26 (tâche C15,
décision de Vincent du 02/10), et le ronéo de l'année corrigera les cartes à
sa parution. La source porte son année dans son auteur : chaque carte de cours
(hors lexique) a le tag `cours-2025-26` et montre « Cours 2025-26 ». Aucune carte ne dit
« Absent du cours 2026-27 » ; les erreurs du Ronéosaure sont dites par un
ATTENTION sans genre, et n'entrent pas dans `contenu/ERRATA_RONEOS_2026-27.md`,
qui ne concerne que les ronéos 2026-27.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 76 | 76 |
| QRU | 27 | 27 |
| Texte à trous | 13 | 71 |
| QROC | 12 | 12 |
| Recto-verso | 7 | 7 |
| Schéma cliquable | 2 | 12 |
| Lexique | 10 | 10 |

Dont **76 annales** (50 QRM, 26 QRU), sur neuf sessions de 2018/2019 S1 à
2023/2024 S1, plus le libellé « 2019/2020 S2 (poly 4) » des deux questions du
polycopié n°4. **27 QCM du cours**, dont les cinq cas cliniques des p. 20-21 ;
chaque QCM a une justification par proposition. **103 QCM sur 103 sont
illustrés** (le hook : 100 %), 137 notes sur 147.

Huit thèmes, dans l'ordre du cours, tous nouveaux (plan C15, 0.6), **à
ajouter à `THEME_LABELS`** (`app/src/med_engine/application/scopes.py`) :

| Clé | Libellé | Notes (dont annales) |
|---|---|---|
| `arbre-genealogique` | Arbre généalogique et modes de transmission | 13 (6) |
| `autosomique-dominant` | Hérédité autosomique dominante | 24 (20) |
| `penetrance-expressivite` | Pénétrance et expressivité | 11 (7) |
| `neomutation-mosaicisme` | Néomutations et mosaïcisme | 15 (7) |
| `autosomique-recessif` | Hérédité autosomique récessive et Hardy-Weinberg | 18 (10) |
| `consanguinite` | Consanguinité et calcul de risque | 14 (5) |
| `inactivation-x` | Inactivation du chromosome X | 11 (6) |
| `heredite-liee-x` | Hérédité liée à l'X et à l'Y | 31 (15) |

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-genet-mdl-2526` — Ronéosaure, « FC n°5 Maladies génétiques Mendéliennes » (22 p.), `GÉNÉTIQUE/…` | **2025-26** | **la base** : chaque note du cours porte sa page ; c'est ce que le lecteur ouvre (`chapitre=`) ; ses figures illustrent les corrections |
| `src-annales-5-maladies-genetiques-de-transmission-mendelienne` — « 5. Maladies génétiques de transmission mendélienne » (21 p., table p. 20-21) | 2024-25 | 74 cartes (75 questions) et les sept arbres d'énoncé (`PHOTOS`) |
| `src-annales-4-anomalies-chromosomique-de-nombre-de-structure-mosaiques` — « 4. Anomalies chromosomique de nombre, de structure, mosaïques » (17 p.) | 2024-25 | 2 cartes (2019/2020 S2 Q14, Q15) |
| cours 2024-25 (FC n°5 et FC n°4, Ronéosaure) et 2023-24 (Charonéo) | — | cités dans le texte, sans être déclarés : 2023-24 pour le facteur 3 du 9/64, le « par exemple » des maladies enzymatiques, Huntington à 40-50 ans, l'amas d'hétérochromatine du corpuscule de Barr ; 2024-25 pour « aléatoire, au stade blastocyste, et de façon clonale », l'examen ophtalmologique de la NF1, les 10 % (FC n°5) et les 4 % (FC n°4) du Duchenne |
| FC n°1, n°2, n°4 2025-26 | 2025-26 | citées à la page dans le texte (5 %, caryotype, Prader-Willi et Angelman p. 6, Turner, triploïdie) : ce sont les fiches d'autres chapitres |
| erratas : cours 2025-26 (`Erratas Génétique.docx`), annales 2024-25, cours 2024-25 | — | deux entrées sur la FC n°5 (cas cliniques 1 et 4) et une sur les annales (2018/2019 S1 Q1), reprises |

**Les deux déclarations d'annales sont partagées.** Elles suivent la règle
des chapitres écrits en parallèle (identifiant `src-annales-<slug du nom du
fichier>`, cinq champs exactement) : `genet_tests` et `genet_chromosomes`
prennent des questions du polycopié n°5, `genet_chromosomes` est
propriétaire du n°4 ; ils doivent déclarer ces fichiers à l'identique.

Vérifications hors du cours, citées dans la carte qui s'en sert : Bennett et
al., J Genet Couns 2002 (cousins germains) ; Verebi et al., J Genet Couns
2025, revue de la littérature (mosaïcisme germinal du Duchenne) ;
Barr et Bertram, Nature 1949, et Lyon, Nature 1961 ; Wakeling et al., Nat Rev
Endocrinol 2017 (Silver-Russell) ; la nomenclature des arbres de la NSGC
(Bennett et al., J Genet Couns 2008) ; l'étymologie (TLFi, Bailly, Gaffiot,
Wiktionnaire ; Vogt 1926 d'après l'adresse présidentielle de l'ASHG 2024).

## Ce que le cours a dicté

- **Le rouge du ronéo** (la mise en valeur des rédacteurs) a ses cartes :
  1 % et 0,5-1,5 % (p. 2), les trois distributions (p. 2), les usages de
  l'arbre (p. 3), 70 % de dominantes et les trois mécanismes (p. 3), 50 % et
  « un parent atteint » (p. 4), la pénétrance et « pénétrance ≠ expressivité »
  (p. 5), les néomutations constante, fréquente, rare (p. 6), 1/30 à 1/35
  porteurs (p. 9), Hardy-Weinberg de la mucoviscidose (p. 9), le risque
  relatif (p. 10).
- **Le gris** dit ici ce que la professeure n'interroge pas : la
  neurofibromatose de type 1 « juste un exemple » (p. 4), le gène IKBKG
  (p. 17), l'interférence cellulaire et PCDH19 « pas interrogé dessus »
  (p. 18). Aucune carte ne les prend pour objet. La NF1 reste la bonne
  réponse de cinq annales, en exemple de dominante, et illustre
  l'expressivité ; PCDH19 n'apparaît que dans deux justifications (2018/2019
  S1 Q4 C, `gmd-rv-fabry-ip`) et le récapitulatif, l'interférence cellulaire
  dans une explication (`gmd-qc-transmission-x`) et la définition
  d'« hémizygote ».
- **« La démonstration n'est pas à retenir »** (Haldane, p. 17) : les cartes
  ne demandent que 1/3 et 2/3 (et 1/2 pour les conductrices).
- **Les cinq cas cliniques** (p. 20-21) sont cinq QCM dont l'arbre du cours
  *est* la question (`illustration_question`) : le dessin ne porte aucune
  réponse, seulement des symboles.
- **Ce qui appartient à d'autres chapitres n'est pas carté** (plan C15) : la
  disomie uniparentale, Turner et Klinefelter (FC n°4), le dépistage néonatal
  (`bmcp_depistage`), l'anticipation (FC n°6), la transmission mitochondriale
  (FC n°7). Ils sont cités dans les justifications.
- **Aucune photographie de patient** : ni les mains de la brachydactylie
  (p. 6), ni l'ostéogenèse imparfaite (p. 6), ni les angiokératomes et
  l'incontinentia pigmenti (p. 17), ni la radiographie de Madelung (p. 19).
  Les coupes histologiques du Duchenne et le chat calico vont.

## Les erreurs du Ronéosaure 2025-26

Chacune est dite par **ATTENTION**, sans genre, dans la carte qui porte la
notion.

| p. | Ce que dit le ronéo | Ce qui est retenu | Sorte | Carte |
|---|---|---|---|---|
| 2 | maladies mendéliennes : « environ 1 % » (rouge) | 1 % pour les mendéliennes ; 5 % pour « les maladies génétiques » (FC n°1 p. 3 ; annale 2017/2018 S1 Q29 A) | le cours lui-même, deux chiffres | `gmd-qc-epidemiologie` C, `gmd-fa-epidemiologie` |
| 8 | « les maladies récessives sont toutes des pathologies enzymatiques » | à l'envers : les maladies enzymatiques sont le plus souvent récessives (cours 2023-24, « par exemple ») ; la mucoviscidose est un canal | prise de notes (déjà dans le ronéo 2024-25) | `gmd-qc-ar-mecanismes` B |
| 9 | « 2 allèles sains : p ; mutés : q ; hétérozygotes : pq » | p², q², 2pq (l'équation de la même page) | prise de notes | `gmd-qc-hardy-weinberg` B |
| 9 | « la probabilité d'être porteur = hétérozygotie du père × de la mère × 1/4 » | d'être **atteint** | prise de notes | `gmd-qc-hardy-weinberg` (explication) |
| 11 | « 2 enfants atteints : 1/4 × 1/4 × 3/4 = 9/64 » | × 3, les trois ordres (cours 2023-24) ; de même 27/64 | facteur oublié | `gmd-fa-individu-isole` |
| 11 | les cousins germains augmentent le risque récessif « de 5 % » | sur-risque de 1,7 à 2,8 % (Bennett 2002) ; absent des cours anciens | point douteux | `gmd-qc-consanguinite` B |
| 12 | « Marie Lyon », « corpuscule de Barre », « en microscopie électronique » | Mary F. Lyon (1961) ; Barr ; microscope optique (Barr et Bertram, 1949) | prise de notes ; la phrase de la microscopie est déjà, mot pour mot, dans le ronéo 2024-25 (recopiée, point douteux) | `gmd-qc-inactivation` B |
| 13 | « méthylation de l'ADN des histones » | méthylation de l'ADN et modifications des histones (diapositive p. 12) | prise de notes | `gmd-qc-inactivation` D |
| 15 | Turner « formule : 45 XO » | 45,X | nomenclature | `gmd-an-2122s2-q18` B |
| 16 | mosaïcisme germinal « 10 % » dans le Duchenne | 10 % à l'examen (même chiffre dans la FC n°5 de 2023-24 et 2024-25) ; la FC n°4 de 2024-25 disait 4 % de récidive ; la littérature : 4,3 à 11 %, moyenne 5,8 % (Verebi 2025) | point douteux | `gmd-qc-duchenne` E |
| 20 | cas clinique 1 : « distributions verticale » | horizontale (errata 2025-26) | prise de notes | `gmd-qc-cas-1` B |
| 21 | cas clinique 4 : « chaque transmet à toutes ses filles » | chaque **père** (errata 2025-26) | prise de notes | `gmd-qc-cas-4` B |

Sans ATTENTION, parce qu'aucune réponse n'en dépend, mais dit dans la carte :
« 50 % à 40-0 ans » pour 40-50 ans (p. 5, `gmd-fa-penetrance`) ; « p = 59/60
= 1 » pour ≈ 1 (p. 9, `gmd-fa-hardy-weinberg`) ; « les patientes avec un
Klinefelter » (p. 13 : des hommes, `gmd-qc-shox-par` C) ; « l'immunité
récessive » pour l'hérédité récessive (p. 16, `gmd-qc-duchenne`). Coquilles
sans conséquence : « chat pelicot », « D. Généralités » sous II.

**Deux corrections du plan C15.** Le centre d'inactivation XIC n'est pas hors
du cours 2025-26 : la diapositive de la p. 12 le donne (« XIC en Xq13 ») ;
2020/2021 S2 Q14 D et 2019/2020 S2 Q22 D citent cette page. Et le « 10 % » de
mosaïcisme germinal du Duchenne est celui de la FC n°5 trois années de suite
(2023-24, 2024-25, 2025-26) ; le « 4 % » que relevait le plan vient d'un autre
cours, celui des anomalies chromosomiques de 2024-25 (récidive empirique des
remaniements). La carte garde 10 % et cite les deux, avec la littérature.

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| Le mode de transmission devant un arbre (sept arbres : quatre dominants, deux liés à l'X, un ouvert) et le risque d'un individu | 2023/2024 S1 Q1-5, 2022/2023 S1 Q2-3, 2021/2022 S1 Q1-4, 2020/2021 S1 Q1-4, 2020/2021 S2 Q1-4, 2019/2020 S1 Q4-7, 2018/2019 S1 Q1-2 |
| Les parents sains d'un enfant atteint d'une dominante (néomutation, mosaïcisme germinal, pénétrance) | 2021/2022 S2 Q13, 2020/2021 S2 Q12, 2019/2020 S2 Q17, 2018/2019 S1 Q15 |
| Les affections dominantes | 2021/2022 S1 Q19, 2020/2021 S1 Q9, 2019/2020 S1 Q22, 2019/2020 S2 Q18 |
| Les affections récessives et la mucoviscidose | 2022/2023 S1 Q17, 2021/2022 S1 Q17, 2021/2022 S2 Q15, 2020/2021 S1 Q12, 2020/2021 S2 Q13, 2019/2020 S1 Q1-2 et Q23, 2019/2020 S2 Q19-20, 2018/2019 S1 Q14 |
| Les affections liées à l'X | 2021/2022 S1 Q18, 2021/2022 S2 Q14 et Q18, 2020/2021 S1 Q11, 2020/2021 S2 Q15, 2019/2020 S1 Q24, 2019/2020 S2 Q21, 2018/2019 S1 Q12 |
| L'inactivation de l'X | 2021/2022 S2 Q12, 2020/2021 S1 Q10, 2020/2021 S2 Q14, 2019/2020 S1 Q26, 2019/2020 S2 Q22, 2018/2019 S1 Q13 |
| La pénétrance | 2021/2022 S2 Q9, 2020/2021 S1 Q13, 2020/2021 S2 Q16 (et Q17), 2019/2020 S1 Q25, 2018/2019 S1 Q4 |
| Les néomutations et le mosaïcisme | 2022/2023 S1 Q18, 2021/2022 S2 Q10, 2020/2021 S1 Q14, 2018/2019 S1 Q3 et Q7, 2019/2020 S2 Q14-15 (poly 4) |
| La consanguinité | 2021/2022 S2 Q11, 2019/2020 S1 Q3, 2019/2020 S2 Q16, 2018/2019 S1 Q5 |
| « Héritée d'un parent atteint ? » | 2021/2022 S2 Q6, 2018/2019 S1 Q6 |

### Les annales, session par session (clé retenue)

| Session | Polycopié, pages | Questions cartées ici |
|---|---|---|
| 2023/2024 S1 | n°5, p. 1-2 | Q1 C, Q2 C, Q3 D, Q4 B, Q5 A (arbre p. 1) |
| 2022/2023 S1 | n°5, p. 3 | Q2 A, Q3 D (arbre p. 3), Q17 E, Q18 CD |
| 2021/2022 S1 | n°5, p. 4-5 | Q1 A, Q2 D, Q3 C, Q4 A (arbre p. 4), Q17 ABCD, Q18 BC, Q19 ABCE |
| 2021/2022 S2 | n°5, p. 5-7 | Q6 E, Q9 ADE, Q10 ADE, Q11 B, Q12 BD, Q13 BCD, Q14 BC, Q15 BD, Q18 ABD |
| 2020/2021 S1 | n°5, p. 7-9 | Q1 A, Q2 A, Q3 C, Q4 A (arbre p. 7), Q9 ACD, Q10 BD, Q11 ABD, Q12 E, Q13 DE, Q14 ABCE |
| 2020/2021 S2 | n°5, p. 9-11 | Q1 C, Q2 D, Q3 B, Q4 A (arbre p. 9), Q12 BCD, Q13 AB, Q14 BCD, Q15 AC, Q16 CDE — **Q17, doublon de Q16 imprimé DE, une seule carte** |
| 2019/2020 S1 | n°5, p. 11-14 | Q1 C, Q2 C, Q3 D, Q4 A, Q5 D, Q6 C, Q7 A (arbre p. 12), Q22 AD, Q23 ABC, Q24 ADE, Q25 CD, Q26 AC — Q27 à `genet_chromosomes`, Q29-30 à `genet_tests` |
| 2019/2020 S2 | n°5, p. 16-18 | Q16 BDE, Q17 BCD, Q18 AE, Q19 B, Q20 B, Q21 ACD, Q22 CDE — Q1 (Pierre) à `genet_tests` |
| 2019/2020 S2 (poly 4) | n°4, p. 14 | Q14 ACE, Q15 AB |
| 2018/2019 S1 | n°5, p. 18-20 | **Q1 ADE** (imprimée AE), Q2 BCD (arbre p. 18), Q3 ADE, Q4 BDE, Q5 B, Q6 E, Q7 ABC (aussi dans le n°4, p. 14), Q12 ACD, Q13 BD, Q14 BC, Q15 BCD |

Les questions à une réponse (« quel est le mode le plus probable », « quelle
est la probabilité », « une seule réponse possible ») sont des QRU.
Anomalies d'impression, dites dans les cartes : 2019/2020 S1 Q4 dit « ci-dessus »
pour un arbre imprimé au-dessous ; le bloc « 2018/2019 (session 2) » du
polycopié n°4 est la session 1 de sa table ; les polycopiés n°5 et n°6
impriment chacun une « 2018/2019 S1 » Q1 et Q14 d'énoncés différents (un des
deux en-têtes est faux, chacun garde le sien).

## Les schémas cliquables

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `arbre-symboles.svg` (`gmd-zo-symboles`) | homme atteint, femme atteinte, femme conductrice, hétérozygote d'une récessive, homme décédé, propositus, grossesse en cours, union consanguine | 8 |
| `arbre-lie-x.svg` (`gmd-zo-arbre-x`) | la conductrice obligatoire, la femme conductrice à 1/2, l'enfant au risque nul, la grossesse à 1/8 | 4 |

Les symboles sont rangés dans huit cases qui pavent le schéma : un clic dans
la case voisine vaut zéro ; le cercle pointé (la conductrice de l'X, p. 15) et
le demi-symbole (l'hétérozygote d'une récessive, p. 8, 11) sont côte à côte,
parce que c'est la confusion à prévenir. L'arbre lié à l'X est redessiné
d'après le cas clinique 2 (p. 20) : le cercle de la mère n'est pas pointé sur
le schéma nu — la reconnaître est la question —, et seuls quatre individus,
chacun d'un statut unique, portent une zone. Les versions légendées, tirées
des mêmes constantes, sont en correction ; elles illustrent aussi les annales
de calcul de risque (2023/2024 S1 Q3-4, 2020/2021 S2 Q3).

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2018/2019 S1 Q1 | AE | **ADE** (`officielle=False`) | errata des annales 2024-25 : la grille des enseignants sur Moodle donne ADE ; l'arbre (des garçons atteints reliés par des femmes saines, pas de père-fils) est celui de l'X, et la Q2 (BCD) le traite comme possible |
| 2020/2021 S2 Q17 | DE | **CDE**, carte unique avec Q16 | même énoncé, mêmes propositions que Q16 (CDE) : la pénétrance compte dans le conseil (p. 5, 7) ; doublon d'impression, CONFLITS sur `gmd-an-2021s2-q16` C |

`CONFLITS` : `gmd-an-1819s1-q1` (D), `gmd-an-2021s2-q16` (C). Aucune autre
clé n'a été changée ; toutes ont été relues proposition par proposition
contre le cours 2025-26.

## Le lexique

Dix termes, tous accueillis ici (plan C15, 0.7), pages remesurées dans le
PDF 2025-26 (la p. 1, le plan, n'est pas comptée) : **Pénétrance** (4, 5, 7,
8, 14-21), **Expressivité** (2, 4, 5, 7, 8, 13, 14, 17, 19), **Hétérozygote**
(3, 8-12, 18), **Homozygote** (3, 8, 9, 11), **Hémizygote** (18),
**Consanguinité** (2, 8, 10, 11, 12), **Néomutation** (4, 6, 10, 16, 17),
**Conductrice** (2, 13-17, 20), **Mosaïcisme germinal** (7, 16),
**Lyonisation** (12).

Chaque définition finit par son étymologie et chaque racine dit la sienne.
Les racines déjà dans `etymologies.json` sont reprises sous leur clé exacte
(`hétéro-`, `hémi-`, `néo-`, `mutare (latin)`, `germen (latin)`,
`cum (latin)`) ; les nouvelles (`-zygote`, `homo-`, `penetrare (latin)`,
`exprimere (latin)`, `sanguis (latin)`, `conducere (latin)`) et les dix
termes sont proposés, vérifiés, dans `scratchpad/etym/genet_mendelien.json`
— la table n'est pas modifiée. La racine de « mosaïque » est celle que
`genet_chromosomes` propose pour son terme « Mosaïque », reprise sous sa clé
exacte (`musaicum (latin médiéval)`), pour que la même racine dise la même
chose dans les deux chapitres. Les
textes du lexique sont déjà écrits comme `appliquer_etymologies.py` les
écrirait (vérifié). `Lyonisation` a pour racine un éponyme, « Lyon
(Mary F.) », sans entrée de racine.

## À relire

Aucune carte `a-relire` : chaque carte du cours cite sa page de la FC
2025-26, et les propositions d'annales hors de ce cours (l'empreinte et la
consanguinité, le syndrome de Silver-Russell, 2018/2019 S1 Q5 E et Q6 D)
citent leur source dans leur justification.

## Questions pour Vincent

1. **Le libellé « 2019/2020 S2 (poly 4) ».** Les Q14-Q15 de 2019/2020 S2
   sont imprimées dans le polycopié n°4, les Q16-Q22 de la même épreuve dans
   le n°5 ; le générateur attribue la source d'une annale par sa session. Le
   chapitre a donc pris ce libellé, pour citer le bon polycopié (tag
   `2019-2020-s2-(poly-4)`). Faut-il plutôt que le modèle de générateur
   accepte une source par note ? `genet_tests` et `genet_chromosomes` ont le
   même cas.
2. **Le doublon 2020/2021 S2 Q17** (proposition du plan, appliquée) : une
   seule carte, celle de la Q16 (CDE), qui dit en C que la Q17 est imprimée
   DE et pourquoi cette clé-là est fausse. Faut-il une seconde carte ?
3. **1 % ou 5 %** : la carte répond 1 % pour les maladies mendéliennes (cette
   FC, en rouge) et 5 % pour « les maladies génétiques » (FC n°1, annale
   2017/2018 S1 Q29). D'accord avec ce partage ?
4. **Le mosaïcisme germinal du Duchenne** : la carte garde les 10 % du cours
   (trois années), avec un ATTENTION « point douteux » qui cite aussi les 4 %
   de la FC n°4 2024-25 et la littérature, 4,3 à 11 % (moyenne 5,8 %).
   D'accord ?
5. **Les symboles que le texte du cours n'explique pas** (propositus, décédé,
   union consanguine, grossesse) sont pourtant dessinés dans ses figures :
   le trait oblique p. 5, 15 et 17, la flèche et le losange p. 7 et 11, le
   double trait p. 11, le losange « ? » des cas cliniques p. 20-21. Leur nom
   est pris à la nomenclature de la NSGC et aux arbres des annales ; les
   garder dans la carte de zone ?


## L'échelle : Simple → Moyen → Annale (C20, 18/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 16 décembre. Sous les annales, 59 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 12 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `arbre-genealogique` | 2 | 1 | 6 |
| `autosomique-dominant` | 12 | 2 | 20 |
| `penetrance-expressivite` | 7 | 2 | 7 |
| `neomutation-mosaicisme` | 7 | 2 | 7 |
| `autosomique-recessif` | 10 | 1 | 10 |
| `consanguinite` | 5 | 1 | 5 |
| `inactivation-x` | 7 | 1 | 6 |
| `heredite-liee-x` | 9 | 2 | 15 |

**Les schémas** sont au nombre de 2 : `ech-arbre-dominante`, « L'arbre et la dominante · pénétrance, néomutation, mosaïcisme » (28 Simple, 7 Moyen, 40 annales ; 76 fichiers), et `ech2-recessive-et-x`, « Récessive, consanguinité, X · qui transmet, qui est atteint » (31 Simple, 5 Moyen, 36 annales ; 73 fichiers). Une carte ou une annale va au schéma de son mécanisme. Ils sont décrits dans `schemas.py` (`ECH_ARBRE_DOMINANTE`, `ECH2_RECESSIVE_ET_X`, avec leurs `TROUS_*` et `LETTRES_*`, un `FICHIERS.update` chacun) et dessinés par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- gmd-an-2324s1-q1 D, E ; gmd-an-2122s1-q1 D, E ; gmd-an-1920s1-q4 D — transmission chromosomique et mitochondriale : la FC n°5 ne les décrit pas (FC n°4 et n°7, autres chapitres) ; aucune case ne les porte.
- gmd-an-2021s1-q1 D, E ; gmd-an-2021s2-q1 D, E ; gmd-an-1920s1-q4 E — disomie uniparentale (FC n°4, genet_chromosomes) et maladie multifactorielle : hors de la FC n°5.
- gmd-an-1819s1-q1 E ; gmd-an-1819s1-q2 E — le multifactoriel n'est pas traité par la FC n°5 ; les justifications des annales le disent déjà.
- gmd-an-2122s1-q2 B, E ; gmd-an-2021s1-q2 B, E ; gmd-an-1920s1-q5 A, E ; gmd-an-2223s1-q3 A — trisomie 21 et syndrome de Prader-Willi : anomalies chromosomiques et d'empreinte de la FC n°4 (genet_chromosomes).
- gmd-an-2122s2-q6 B, D ; gmd-an-1819s1-q6 A, B, D — trisomie 21, triploïdie, syndrome d'Angelman (FC n°4) et syndrome de Silver-Russell (hors cours, Wakeling 2017) : accidents ou empreinte, absents de la FC n°5.
- gmd-an-2223s1-q2 B — la récessive en pseudodominance (p. 11-12) est un piège du thème autosomique-recessif, dit dans gmd-ech2-s3 ; E (mitochondriale) relève de la FC n°7.
- gmd-an-2223s1-q3 C — le syndrome de l'X fragile (anticipation, FC n°6) n'est que nommé dans le récapitulatif de l'X (p. 20), thème heredite-liee-x ; posé sur la case de l'X dans le schéma de l'annale, sans marche.
- QRU de risque gmd-an-2122s1-q3, gmd-an-2021s1-q3, gmd-an-1920s1-q6 (A 0 %, E 100 %) et gmd-an-2122s1-q4, gmd-an-2021s1-q4, gmd-an-1920s1-q7 (B à E) — une seule réponse : la marche qui donne la clé (gmd-ech-s9, 1/2 ; gmd-ech-s14, rien de reçu, risque quasi nul) écarte les autres chiffres, qui n'enseignent pas de fait propre.
- gmd-an-2122s2-q15 E : le caryotype et ce qu'il voit sont dans les FC n°1 et n°2, pas dans la FC n°5 qui fait foi ni dans les sources fournies.
- gmd-an-2021s1-q12 E : « aucune de ces propositions », rien à poser sur le schéma ; elle se juge sur A-D, toutes préparées.
- gmd-an-1920s2-q20 A et gmd-an-2021s2-q2 E : le syndrome de Prader-Willi (empreinte parentale) est dans la FC n°4 (genet_chromosomes), hors des sources de ce chapitre.
- gmd-an-1819s1-q5 E : l'empreinte parentale et la consanguinité sont hors du cours 2025-26 (la justification de l'annale cite la FC n°4).
- gmd-an-2324s1-q2 B et gmd-an-2021s2-q2 B : la trisomie 21 n'est pas dans la FC n°5 (FC n°4).
- gmd-an-1920s2-q20 E (lettre non posée) : la NF1, dominante, n'a pas de case sur ce schéma, qui ne couvre pas l'hérédité dominante ; la carte gmd-ech2-s33 la prépare quand même (son distracteur B la dit dominante, récapitulatif p. 20).
- QRU de calcul gmd-an-2324s1-q3 (A, B, C, E), gmd-an-2324s1-q4 (A, E), gmd-an-2324s1-q5 (B à E), gmd-an-2021s2-q3 (A, E), gmd-an-2021s2-q4 (B, C, D), gmd-an-1920s1-q1 (A, B, E), gmd-an-1920s1-q2 (D) et gmd-an-1920s1-q3 (A, E) — une seule réponse : la marche qui donne la clé (gmd-ech2-s26, s28, s24, s25, s9, s16, s15) écarte les autres chiffres ; 1920s1-q2 D, la cousine germaine d'un atteint (1/480, calcul de la p. 10), n'a pas de case sur ce schéma.

## Régénérer

```powershell
cd contenu\chapitres\genet_mendelien
..\..\..\app\.venv\Scripts\python.exe generer.py
```

`generer.py` est la copie exacte de
`.claude/skills/nouveau-chapitre/scripts/generer_modele.py`. Les figures de
`media/` ont été rendues des PDF à 3× (PyMuPDF), découpées à la page et au
rectangle près ; elles se versionnent et partent avec le chapitre.
