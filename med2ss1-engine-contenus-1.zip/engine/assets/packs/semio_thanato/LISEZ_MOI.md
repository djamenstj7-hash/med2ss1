# Sémiologie thanatologique — paquet d'exemple

49 notes, 93 cartes. Deux sources : la fiche de cours et les annales de neuf
sessions.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 25 | 25 |
| Texte à trous | 12 | 49 |
| Repérage sur schéma | 3 | 10 |
| QROC | 7 | 7 |
| Recto-verso | 2 | 2 |

Sur les 25 QRM, **15 sont des annales** de 2015/2016 à 2022/2023.

## Deux sections « pas vues » qui font six questions sur quinze

C'est le point le plus utile de ce chapitre, et il fallait le chercher pour le
voir. La fiche porte **« Pas vu »** sur la déshydratation et **« Pas vu en
coures »** sur la putréfaction. Or ces deux sections font à elles seules **six
des quinze questions d'annales** :

| Section | Questions d'annales |
|---|---|
| Déshydratation | 2019/2020 S1 Q.15, 2019/2020 S2 Q.23, 2016/2017 Q.1 |
| Putréfaction | 2018/2019 Q.5, 2017/2018 S2 Q.10, 2016/2017 S2 Q.24 |

Elles sont donc cartées **comme le reste, sans mention particulière**. Une
annotation dit ce que le cours a traité cette année-là ; elle ne dit pas ce qui
est examinable, et c'est le sujet d'examen qui tranche. Le fait est noté ici, une
fois, parce qu'il explique d'où viennent ces cartes — pas sur les cartes, où il
n'aurait servi qu'à inviter à les négliger.

## L'opposition qui structure tout le chapitre

> **La rigidité est biochimique, donc sensible à la température.
> Les lividités sont purement mécaniques, donc elles ne le sont pas.**

Deux questions de la **même session** (2015/2016 S2) posent exactement ce
contraste : la Q.23 donne **faux** que la température modifie la vitesse
d'apparition des lividités, et la Q.25 donne **vrai** que la cinétique de la
rigidité en dépend. Tenir cette ligne, c'est répondre juste à une bonne moitié du
chapitre.

## Ce que les annales ont dicté

**Cinq questions sur quinze** ne demandent que le tri entre **signes négatifs de
la vie** — ce qui manque chez quelqu'un qu'on peut encore réanimer — et **signes
positifs de la mort** — ce qui apparaît et ne s'en va plus.

| Négatifs de la vie (3) | Positifs de la mort (5) |
|---|---|
| arrêt cardio-circulatoire | rigidité |
| arrêt respiratoire | lividités |
| mydriase | refroidissement |
| *(abolition des réflexes du tronc)* | déshydratation |
| | autolyse et putréfaction |

Et une question de 2016/2017 S2 propose « signes **négatifs de la mort** », une
expression qui n'existe pas : il n'y a que des négatifs de la *vie* et des
positifs de la *mort*.

## Une coquille du ronéo 2026-27, signalée

Le ronéo 2026-27 (Ronéo & Juliette, 14/09/2026, p. 6) définit la rigidité
cadavérique comme une contraction « neurodépendante », puis explique sur la
même page que les muscles se contractent « sans régulation possible de la part
du cerveau ». Les cours 2024-25 et 2023-24 disent neuro-indépendante. Les
cartes gardent **neuro-indépendante**, et `tha-qc-rigidite` (A) comme
`tha-fa-mecanisme` le disent par une ATTENTION (25/09/2026). Aucun tableau
d'erreurs ne relève la coquille.

## Trois notions absentes de la fiche

Elles n'existent que dans les annales :

- la **tache noire sclérale**, signe de déshydratation, posée deux fois ;
- le fait qu'une rigidité rompue **précocement peut se reconstituer** ;
- la **transformation adipocireuse** et le **décollement des phanères**, signes
  très tardifs cités pour être écartés.

## Les trois schémas cliquables

| Fichier | Ce qu'on y clique | Cartes |
|---|---|---|
| `rigidite-phases.svg` | les quatre phases sur un axe des heures | 4 |
| `refroidissement.svg` | trois points sur la courbe de décroissance | 3 |
| `lividites-appui.svg` | lividités, point d'appui, partie haute | 3 |

Le deuxième est le seul schéma du corpus dont la tolérance ne soit pas nulle :
on y vise un point sur une courbe, et non une région qui pave une surface.

**Aucune photographie du cours n'est reproduite** : ce sont des clichés
d'autopsie. Le polycopié d'annales, lui, n'en contient qu'une seule, et elle est
cartée.

### La photographie des annales

**2019/2020 nov S1, Q.15** montre les plaques parcheminées orangées d'un tronc.
Aucun visage n'y figure, rien n'y est identifiant : il n'y a rien à flouter,
contrairement au chapitre « blessures ». Le polycopié avait incorporé la page
entière — énoncé, cliché et propositions dans une seule image — de sorte que la
garder telle quelle aurait donné la réponse avec la question ; `photos.py` la
rogne sur le cliché seul.

**2016/2017 S2, Q.24** parle d'une iconographie que le polycopié n'a pas gardée :
l'énoncé y est, l'image n'y est pas. La carte existe quand même — l'énoncé décrit
assez la lésion pour que la réponse reste atteignable — et elle le dit.

Pour refaire l'image (les deux bibliothèques ne sont pas des dépendances de
l'application) :

```powershell
python -m uv run --with pymupdf --with pillow python photos.py [racine des cours]
```


## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026)

L'échelle du pilote de l'immunité innée, étendue à la sémiologie pour l'examen du 4/11 (Vincent, 16/10 : « on continue pour les chapitres que je vais avoir à l'examen »). Sous les annales, 21 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 5 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `diagnostic` | 6 | 1 | 4 |
| `rigidite` | 4 | 1 | 2 |
| `deshydratation` | 3 | 1 | 3 |
| `refroidissement` | 4 | 1 | 3 |
| `putrefaction` | 4 | 1 | 3 |

**Le schéma** `ech-thanato`, « Le cadavre · signes, phases, délais », donne 42 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_THANATO`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sources.** `SRC` n'a pas de clé `fiche` : les marches relues sur la ronéo 2026-27 nomment la leur (`fiche="src-fc-semio-thanato"`) ; celles qui reposent sur le FC n°10 2025-26, sans page, citent `SRC["cours"]`, comme les images de l'échelle.

**La putréfaction « exogène »** : la ronéo 2026-27 dit la résolution musculaire « exogène car bactéries » (p. 7), le FC n°10 2025-26 écrit que la putréfaction « n'est pas liée à l'action de phénomènes exogènes extérieurs » (p. 11), mais dit lui-même la dernière phase de la rigidité exogène (p. 4). `tha-ech-s9` ne dit plus « exogène » ; le désaccord est aux points douteux de `contenu/ERRATA_RONEOS_2026-27.md`.

**Sans marche** :
- tha-an-1920s1-q15 B, D, E : le délai d'apparition des plaques parcheminées, leur usage pour dater et l'érosion faite avant la mort ne sont pas dans la ronéo 2026-27 ; aucune carte du chapitre ne les tient d'une page du FC n°10.
- tha-an-1920s1-q16 A, B, C et tha-an-1516s2-q24 D : les voies de mesure ne sont ni dans la ronéo 2026-27, ni dans le FC n°10 2025-26 (p. 10), ni dans la FC n°8 2024-25, ni dans le Charonéo 2023-24 ; seules les clés et la carte tha-qc-froid (D) les portent. Lettres posées sur la case du refroidissement.
- tha-an-1920s1-q16 E : délicat. La ronéo compte la perte « suite au décès » (p. 8), la figure montre un plateau initial, et le schéma existant du chapitre dit la décroissance « pas immédiate ». Aucune marche ne tranche, mais la lettre est posée sur la case du refroidissement.
- tha-an-1920s2-q23 C, tha-an-1617-q1 A, tha-an-1718s2-q9 A : la tache noire sclérale est hors fiche.
- tha-an-1920s2-q23 D : le pli cutané, signe de déshydratation du vivant, n'est dans aucun des cours lus.
- tha-an-1718-q11 D, E : « tous les muscles » vient du FC n°10, hors ronéo ; la rigidité qui se reconstitue est hors fiche.
- tha-an-1718s2-q9 D, E : le décollement des phanères et la transformation adipocireuse sont hors fiche.
- tha-an-1617s2-q3 E, tha-an-1516s2-q23 D : l'abolition des réflexes du tronc n'est pas dans la liste des trois signes négatifs de la ronéo 2026-27 (p. 6).
- tha-an-1617s2-q24 D : « on n'utilise pas les critères putréfactifs » pour dater (FC n°10), hors ronéo ; pas de marche.
- tha-an-1516s2-q24 A : l'émission de liquide séminal, par les fibres lisses, vient du FC n°10, hors ronéo.
- tha-an-1516s2-q25 B : les lividités discrètes en cas d'hémorragie viennent du FC n°10 (III), hors ronéo.

## Régénérer

```powershell
python generer.py
```
