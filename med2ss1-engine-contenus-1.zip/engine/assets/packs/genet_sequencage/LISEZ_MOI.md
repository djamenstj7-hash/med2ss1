# Tests génétiques et méthodes de séquençage — paquet Génétique

60 notes, 101 cartes. Chapitre `chap-ue-genetique-fc3` de l'UE Génétique,
troisième de l'UE. Cours du **Pr Thomas Smol, le 17/11/2025, de 11 h à 12 h**,
dans le **Ronéosaure 2025-26** (FC n°3, 6 pages ; l'en-tête de la première page
imprime « 1/7 ») ; les annales du polycopié de séquençage du Ronéosaure 2024-25
(6 sessions). Examen : mercredi 16 décembre 2026.

**Fiche provisoire** (C15, décision de Vincent du 02/10) : le ronéo 2026-27 de
ce cours n'est pas encore paru. Chaque carte de cours cite la FC 2025-26 à sa
page et porte le badge « Cours 2025-26 » ; le ronéo 2026-27 la corrigera quand
il sortira. Aucune carte n'est « Absent du cours 2026-27 ».

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 29 | 29 |
| QRU | 1 | 1 |
| Texte à trous | 10 | 47 |
| QROC | 8 | 8 |
| Recto-verso | 4 | 4 |
| Schéma cliquable | 1 | 5 |
| Planche à légender | 1 | 1 |
| Lexique | 6 | 6 |

Dont **14 annales** sur 6 sessions (2021/2022 à 2023/2024), toutes des QCM, toutes
du polycopié « 3 - Tests génétiques _ méthodes de séquençage ». 16 QCM de cours
(15 QRM, 1 QRU). **27 QCM sur 30 sont illustrés** (90 %) ; les trois autres
portent sur l'encadrement et l'offre de soins, que la FC n'illustre pas.

Huit thèmes, dans l'ordre du cours. Cinq nouveaux, dont les libellés restent à
ajouter à `THEME_LABELS` (`app/src/med_engine/application/scopes.py`) ; trois
partagés avec `genet_tests` (et `genet_cytogenetique`), déjà libellés. Le plan
proposait `haut-debit` : la clé est devenue `sequencage-haut-debit` à la
relecture, parce que « haut débit » est aussi un mot de l'informatique médicale
(les réseaux de la télésanté) et qu'un libellé de thème est partagé entre UE.

| Clé | Libellé | Notes | dont annales |
|---|---|---|---|
| `prelevement-adn-arn` | ADN, ARN et choix du prélèvement | 6 | 0 |
| `sanger` | Le séquençage Sanger | 7 | 0 |
| `genome-reference` | Génome de référence et variations | 6 | 2 |
| `sequencage-haut-debit` | Séquençage haut débit : génome, exome, panels | 11 | 4 |
| `resolution-couverture` *(partagée)* | Résolution et couverture des tests génétiques | 4 | 2 |
| `interpretation-variants` *(partagée)* | Interpréter une variation génétique | 9 | 3 |
| `donnees-additionnelles` *(partagée)* | Données incidentes et données secondaires | 2 | 0 |
| `encadrement-genomique` | Résultat négatif, encadrement, France Médecine Génomique | 9 | 3 |

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-genet-seq-2526` — Ronéosaure, « FC n°3 tests et méthodes de séquençage .pdf » (6 p.) | 2025-26 | le cours ; `SRC["fiche"]`, ses six diapositives |
| `src-annales-3-tests-genetiques-methodes-de-sequencage` — « 3 - Tests génétiques _ méthodes de séquençage » | 2024-25 | les 14 questions, table p. 7 |

Le nom de la FC est en NFC sur le disque, avec une espace avant `.pdf` ;
`chemin_relatif` le recopie tel quel. Aucun autre chapitre ne déclarait le
polycopié 3 : il est déclaré avec les seuls champs convenus (id, kind, titre,
chemin, auteur).

Lus en appoint, sans être déclarés : l'errata des cours 2025-26 (« Erratas
Génétique.docx », une entrée pour ce cours), l'errata des annales 2024-25
(« ERRATAS ANNALES GÉNÉTIQUE.docx », une entrée pour ce polycopié), le cours
2024-25 (Ronéosaure, 11 p.) et le cours 2023-24 (Charonéo, 14 p.) du même
enseignant, plus détaillés : les propositions d'annales hors du cours 2025-26
les citent à leur page. Les en-têtes des ronéos, des erratas et des polycopiés
portent des noms d'étudiants : aucun n'est repris.

## Ce que le cours a dicté

- **Pas de rouge.** **Le gris** est la voix des rédacteurs et se carte (décision
  du 25/09) : la légende d'une visualisation des lectures (p. 4), dont l'image
  n'est plus dans le ronéo 2025-26, et la conclusion « issue de la ronéosaure »
  (p. 6), recopiée du ronéo 2024-25 — coquille comprise (voir plus bas).
- **Rien à laisser** : l'enseignant n'a écarté aucune notion. Il a insisté sur
  deux phrases, cartées en propositions **indispensables** : « pas de
  séquençage Sanger sans hypothèse formulée », « la notion la plus importante »
  (`gsq-qc-sanger-indications` A) ; « un résultat négatif n'exclut jamais
  totalement une maladie génétique », « a bien insisté » (`gsq-qc-resultat` B,
  avec l'inverse en proposition **inacceptable**, D).
- **Les « (important) » du ronéo** ont leur carte : le génome de référence comme
  base de comparaison (`gsq-qc-genome-reference`), les classes 4 et 5 qui
  décident (`gsq-qc-classes`, `gsq-fa-classes`).
- **Ce qui n'est pas carté ici** (plan C15, frontières) : la vue d'ensemble de
  la résolution et de la couverture, le faisceau de critères, la définition des
  cinq classes, les exemples de données incidentes et secondaires
  (`genet_tests`) ; ce que voit chaque technique de cytogénétique
  (`genet_cytogenetique`). Les cartes les citent (« FC1, p. 3 »). Ce chapitre
  carte ce que la FC3 y ajoute : 4-5 actionnables, 3 inutilisable en DPN, RCP
  avant tout rendu. Ainsi `gsq-qc-additionnelles` ne demande pas la différence
  entre donnée incidente et donnée secondaire (FC1) : il porte sur ce que la
  FC3 dit d'elles — plus c'est large, plus il y en a ; le choix du patient en
  amont ; la RCP.
- **Les six diapositives** de la FC (prélèvements, chromatogramme, génome de
  référence, génération et analyse des données, filtrage) vont en correction,
  extraites en PNG de 1 000 px.

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| Les technologies : Sanger ciblé, exome = exons, génome, panel, fragmentation, mosaïque | 2023/2024 S1 Q17 ; 2022/2023 S1 Q11 ; 2021/2022 S1 Q29 ; 2021/2022 S2 Q2 |
| L'interprétation : SNV majoritaires, variation = différence avec la référence, référence non représentative, cinq classes, trio | 2023/2024 S1 Q18 ; 2022/2023 S1 Q12 ; 2021/2022 S1 Q28 ; 2021/2022 S2 Q1, Q3 |
| Ce que voit le génome face à la puce à ADN (taille, équilibré) | 2023/2024 S2 Q7 ; 2022/2023 S2 Q3 ; 2021/2022 S1 Q29 D ; 2021/2022 S2 Q1 A, Q2 C |
| L'offre de soins : France Médecine Génomique, tests en ligne, données secondaires, prescription médicale | 2023/2024 S2 Q8 ; 2022/2023 S2 Q4 ; 2021/2022 S1 Q30 |

**Les copies**, une carte par session, l'explication renvoie aux autres : le
trio (quatre fois), le génome de référence « de plusieurs milliers
d'individus » (trois fois, toujours faux), les SNV majoritaires (quatre fois),
le Sanger et la mosaïque (deux fois), l'hétérochromatine (quatre fois), la
prescription à des fins médicales (trois fois), les données secondaires
systématiques (quatre fois, toujours faux), l'exome à 25 % puis à 50 % (faux :
1,5 %).

**2023/2024 S2 Q8 E est tronquée** dans le polycopié (« Le séquençage du génome
d'un individu doit impérativement faire ») : l'énoncé garde le texte imprimé,
complété entre crochets d'après 2022/2023 S2 Q4 E et dit tel ; la justification
porte un ATTENTION ; la clé ADE est reprise.

### Hors du cours 2025-26

Aucune question n'est entièrement hors du cours ; huit propositions le sont, et
une neuvième en partie (2021/2022 S1 Q28 B), reprises comme la clé et
justifiées, « hors du cours 2025-26 », sur le cours 2023-24 du même enseignant
ou une source sûre :

| Proposition | Source |
|---|---|
| L'hétérochromatine et les centromères, difficiles à séquencer — 2023/2024 S1 Q17 D, 2022/2023 S1 Q11 C, 2021/2022 S1 Q30 C, 2021/2022 S2 Q1 B | cours 2023-24 p. 4 ; consortium T2T (Nurk et al., Science 2022) |
| Les INDEL, moins de 50 pb — 2021/2022 S1 Q28 D | cours 2023-24 p. 3 |
| Un panel pour peu de gènes, exome ou génome au-delà — 2023/2024 S2 Q7 A | cours 2023-24 p. 9 |
| Le caryotype et les troubles du neurodéveloppement — 2021/2022 S1 Q29 E | cours 2023-24 p. 9 (3 % → 40 % de diagnostics) |
| La RCP qui retient l'indication d'un génome — 2023/2024 S2 Q8 D | cours 2023-24 p. 12 ; cours 2024-25 p. 11 |
| Le nombre de SNV selon la population — 2021/2022 S1 Q28 B | p. 3 et FC1 p. 4 ; 1000 Genomes Project, Nature 2015 |

## Le schéma cliquable et la planche

| Fichier | Ce qu'on clique | Cartes | Pourquoi ce dessin |
|---|---|---|---|
| `gsq-chromatogramme-trio.svg` | cinq sites d'un séquençage Sanger en trio : la variation de novo du propositus, la variation héritée chez lui, la même chez la mère, le même site chez le père, la base de référence au site de novo | 5 | la diapositive de la p. 2 (deux variations de novo, pics superposés) redessinée en exercice : lire un pic double, et dire de novo ou hérité en comparant au père et à la mère. Les couleurs sont celles de la diapositive (A vert, C bleu, G noir, T rouge) ; la séquence est inventée, douze positions |
| `gsq-pl-generation` (planche, depuis `gsq-generation-donnees.png`, p. 4) | 7 numéros : sélection de régions d'intérêt, génome complet, identification des régions cibles, fragmentation, enrichissement, amplification clonale, séquençage ; 4 intrus (alignement, annotation, rétrotranscription, électrophorèse capillaire) | 1 | la diapositive des deux branches du haut débit, qui rétablit l'ordre que le ronéo inverse ; la légende « Exome : ensemble de toutes les régions codantes » est effacée avec le n° 5 |

La version légendée du trio (`-legende.svg`) illustre la correction. Une
troisième figure, `gsq-tailles-variations.svg`, n'a pas de zone : elle illustre
les annales qui comparent le génome à la puce (SNV, INDEL sous 50 pb, variations
de structure ; ce que voient le Sanger, l'exome, le génome, l'ACPA et le
caryotype, d'après la FC3, la FC1 p. 3 et le cours 2023-24).

## Les erreurs du ronéo 2025-26

Le Ronéosaure n'est pas le ronéo de l'année : chaque erreur est portée par un
**ATTENTION nu** dans la carte qui tient la notion, la sorte dite dans le texte,
et rien n'entre dans `contenu/ERRATA_RONEOS_2026-27.md`.

| Page | Le ronéo dit | Retenu | Sorte | Carte |
|---|---|---|---|---|
| 4 | génome complet : « amplifier → fragmenter → séquencer » | fragmenter → amplifier → séquencer (errata 2025-26 ; la diapositive et le texte de la même page) | prise de notes | `gsq-qc-haut-debit` B, `gsq-fa-genome-complet`, `gsq-pl-generation` n° 6 |
| 6 | conclusion : « environ 5x109 variations ponctuelles » | 5 × 10⁶, 5 millions (p. 3 et 5) ; la coquille vient de la conclusion du Ronéosaure 2024-25, recopiée | coquille recopiée | `gsq-qc-variations` E, `gsq-fa-variations` |
| 2 | Sanger : « environ 1 000 paires de bases » | la FC1 dit « quelques centaines » (p. 4), le cours 2024-25 500 à 1 000 pb ; tous disent un exon | point douteux (deux enseignants) | `gsq-qc-sanger-principe` E, `gsq-fa-sanger` |

Relevés sans ATTENTION, parce qu'ils ne changent aucune réponse : « chromograme »
(p. 2) et « chromogramme » (diapositive) pour chromatogramme, dit dans les
explications ; les didésoxynucléotides « comme des codons STOP », une image des
rédacteurs (« exemple perso »), dite telle.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenue | Pourquoi |
|---|---|---|---|
| 2021/2022 S1 Q28 | AD | **ACD** | C, « plus d'un millier de variations de structure » par individu, est vraie : environ 10 000 selon le cours (p. 3 ; « 10x 103 » p. 6 ; cours 2023-24 et 2024-25) ; 2 100 à 2 500 (1000 Genomes, Nature 2015), médiane 7 439 (gnomAD-SV, Collins et al., Nature 2020). L'errata des annales 2024-25 relève la contradiction. `officielle=False`, CONFLITS, ATTENTION sur C |

Les 13 autres clés sont reprises telles qu'imprimées.

## Le lexique

Six termes, pages mesurées dans le PDF de la FC (`chercher_pages.py`, mot entier,
pluriel permis) :

| Terme | Pages | Racines |
|---|---|---|
| Séquençage | 2, 3, 4, 5, 6 | sequentia (latin) *(nouvelle)* |
| Exome | 4, 5, 6 | exprimere (latin), -ome (de génome) *(nouvelle)* |
| Propositus | 2, 3 | pro- (latin) *(nouvelle)*, ponere (latin) *(nouvelle)* |
| Didésoxynucléotide | 2 | di-, dé- (latin), ox-, nuclé(o)- *(nouvelle)* |
| Amorce | 2 | ad- (latin), mordere (latin) *(nouvelle)* |
| Bio-informatique | 4 (« bioinformatique » p. 6) | bi(o)-, informare (latin) *(nouvelle)* |

« Séquençage » figure aussi au plan du cours (p. 1), non compté. Les
étymologies nouvelles sont proposées dans `scratchpad/etym/genet_sequencage.json`
(TLFi par l'API du portail CNRTL, Wiktionnaire, Bailly, Gaffiot), écrites déjà
dans `donnees.py` comme `appliquer_etymologies.py` les écrirait. « -ome (de
génome) » est distinct du « -ome » de la table (le suffixe -ωμα des tumeurs) :
le TLFi fait venir la finale de génome de chromosome, donc de σῶμα.
« pro- (latin) » reprend la clé et le sens (« devant, en avant ») de la
proposition d'`info_reutilisation`. L'étymologie d'« exome » suit la racine
« -ome (de génome) » : exon (exprimere) et le -ome de genome, de σῶμα, et non
γένος, qui n'entre pas dans le mot. Au regroupement du 03/10, `ox-` cite la FC
de sémantique 1/2, p. 6 (« oxy- : piquant, aigre »), et `ad- (latin)` la 2/2,
p. 4 (« ad- / af- »), comme dans `genet_mitochondrial` et `biostat_phase_4_eim`.

## Questions pour Vincent

1. **2021/2022 S1 Q28** : la carte retient ACD contre la table (AD), sur le cours
   et les références ; l'errata des annales demandait si AD était « la
   correction du prof ». Si la grille des enseignants sur Moodle donne AD, la
   carte garde ACD mais le dira.
2. **2023/2024 S2 Q8 E**, tronquée dans le polycopié : la fin est complétée entre
   crochets d'après 2022/2023 S2 Q4 E. Le sujet d'origine porte-t-il bien ce
   texte ?
3. **Le trio à cliquer** est une séquence inventée sur le modèle de la
   diapositive de la p. 2 (une variation héritée, une de novo) : un exercice de
   lecture, pas une figure du cours. À garder ?

## À relire

Aucune carte ne porte `a-relire` : toutes ont leur page dans la FC 2025-26 ou,
pour les propositions d'annales hors cours, une source citée.


## L'échelle : Simple → Moyen → Annale (C20, 18/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 16 décembre. Sous les annales, 26 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 6 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `genome-reference` | 4 | 1 | 2 |
| `sequencage-haut-debit` | 6 | 2 | 4 |
| `resolution-couverture` | 5 | 1 | 2 |
| `interpretation-variants` | 5 | 1 | 3 |
| `encadrement-genomique` | 6 | 1 | 3 |

**Le schéma** `ech-sequencage`, « Les tests génétiques par séquençage · Sanger, haut débit, interpréter, encadrer », donne 47 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_SEQUENCAGE`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- gsq-an-2324s1-q17 D, gsq-an-2223s1-q11 C, gsq-an-2122s1-q30 C, gsq-an-2122s2-q1 B — l'hétérochromatine et les centromères, difficiles à séquencer, sont hors du cours 2025-26 (cours 2023-24 p. 4 ; consortium T2T, Science 2022) ; lettres posées sur « Ce que voit le génome », sans marche.
- gsq-an-2122s1-q28 D — le seuil de 50 pb des INDEL est hors du cours 2025-26 (cours 2023-24 p. 3) ; lettre posée sur « Une variation », sans marche.
- gsq-an-2122s1-q29 E — la part du caryotype dans les troubles du neurodéveloppement est hors du cours 2025-26 (cours 2023-24 p. 9) ; lettre posée sur « Ce que voit le génome », sans marche.
- gsq-an-2223s2-q3 E, gsq-an-2122s2-q2 A — la part du génome que couvre l'exome (environ 1,5 %) est dans la FC1 (p. 5, genet_tests), pas dans la FC3 2025-26 ; lettres posées sur « Que séquencer ? », sans marche.
- gsq-an-2324s2-q8 D — la RCP qui retient l'indication d'un génome est hors du cours 2025-26 (cours 2023-24 p. 12, cours 2024-25 p. 11), qui ne place une RCP qu'avant le rendu (p. 5) ; lettre posée sur « Encadrement en France », sans marche.

## Régénérer

```powershell
cd contenu\chapitres\genet_sequencage
..\..\..\app\.venv\Scripts\python.exe generer.py
```

La planche numérotée se refait depuis `app/` :
`uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/genet_sequencage gsq-pl-generation --apercus <brouillon>`.
