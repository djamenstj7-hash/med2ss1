# Les contrastes en IRM — paquet BMCP

75 notes, 122 cartes. Chapitre `chap-ue-bmcp-fc21` de l'UE BMCP, vingt-deuxième
de l'UE (`ordre=22`). Cours du **Pr Kuchcinski, le 10/12/2025, de 10 h à 11 h**,
dans le **Ronéosaure 2025-26** (FC n°22, 13 pages) ; les annales de deux
polycopiés du Ronéosaure 2024-25 (BMCP 21 et BMCP 18, 10 sessions citées).
Examen : mardi 5 janvier 2027.

**Fiche provisoire** (C16, décision de Vincent du 02/10) : le cours de l'année
2026-27 n'est pas encore paru. Chaque carte de cours cite la FC 2025-26 à sa
page, et porte le badge « Cours 2025-26 » (l'année est lue dans l'auteur de la
source) ; le ronéo 2026-27 la corrigera quand il sortira. Aucune carte n'est
« Absent du cours 2026-27 » ; les erreurs du ronéo 2025-26 portent un
`ATTENTION` nu, sans genre, et n'entrent pas dans
`contenu/ERRATA_RONEOS_2026-27.md`.

Ce chapitre a été écrit sur un brouillon laissé par une session interrompue le
03/10 : 22 figures déjà extraites dans `media/`, rien d'autre. Chacune a été
revue contre le PDF (page, cadrage, aucune légende qui vendrait la réponse sur
les coupes nues) et gardée ; deux ont été ajoutées (le T1 avec saturation de
graisse du cours 2024-25).

Relecture critique du 05/10 : chaque carte contre la page de la FC qu'elle
cite, chaque annale contre le polycopié et sa table, les deux erratas, les
figures et le schéma cliquable (zones tracées sur le dessin). Corrigés : un
énoncé d'annale non verbatim (2015/2016 S1 Q.28, « laquelle (ou
lesquelles) »), une citation du cours 2023-24 reformulée qui passait pour
mot à mot, la description de la 1re série de l'annale 2023/2024 S2, la sorte
de l'erreur « réactions osmotiques » (prise de notes probable, non prouvée),
la FLAWS donnée comme hypothèse et non comme certitude, le bruit attribué aux
ondes de radiofréquence aussi par le cours 2024-25 (p. 7).

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 31 | 31 |
| QRU | 6 | 6 |
| Texte à trous | 10 | 55 |
| QROC | 9 | 9 |
| Recto-verso | 8 | 8 |
| Schéma cliquable | 1 | 3 |
| Planche à légender | 1 | 1 |
| Lexique | 9 | 9 |

Dont **15 annales** sur 10 sessions : 11 QCM et les 4 QROC du cas illustré de
2023/2024 S2 (une QROC, trois recto-verso, avec leur corrigé imprimé). 37 QCM
en tout, dont 35 illustrés (95 %).

Six thèmes, dans l'ordre du cours, tous nouveaux ; leurs libellés sont dans `THEME_LABELS` (`app/src/med_engine/application/scopes.py`) depuis l'intégration du 05/10. Deux
sont partagés avec `bmcp_echographie_irm`, au même libellé : `examen-irm` et
`rmn`.

| Clé | Libellé | Notes |
|---|---|---|
| `contrastes-irm` | Reconnaître les contrastes en IRM | 20 |
| `sequences-fonctionnelles` | Angiographie, diffusion et perfusion | 12 |
| `examen-irm` | L'examen IRM et ses contre-indications | 5 |
| `rmn` | Phénomène de RMN : précession, résonance, relaxation | 8 |
| `tr-te` | TR, TE et pondérations | 7 |
| `irm-avc` | L'IRM de l'AVC | 14 |

Le plan C16 proposait `t1-t2` (« T1, T2 et T2* ») et `avc` : une clé chiffrée
n'est pas un thème, un libellé ne porte pas de chiffre, et « avc » est le mot
qu'une autre UE (la neurologie) voudrait. D'où `rmn` — la clé que
`bmcp_echographie_irm` donne à la RMN, son libellé dit vrai ici (B0, bascule,
relaxation) — et `irm-avc`.

## Les sources et leurs années

| Source | Rôle | Déclaration |
|---|---|---|
| FC n°22 « Les contrastes en IRM », Ronéosaure 2025-26 | le cours, la fiche que le lecteur ouvre, 17 figures | `src-fc-bmcp-cir-2526`, `BMCP/FC n°22 - Les contrastes en IRM.pdf`, `chapitre=` |
| BMCP 21 « Contrastes en IRM », Ronéosaure 2024-25 | 10 QCM, 4 QROC, la figure du cas de 2023/2024 S2 (p. 3) | `src-annales-bmcp-21-contrastes-en-irm` |
| BMCP 18 « Échographie et IRM », Ronéosaure 2024-25 | la 2022/2023 S2 Q.28 | `src-annales-bmcp-18-echographie-et-irm` (`SRC["sessions"]`) |
| FC n°21 « Les contrastes de l'IRM », Ronéosaure 2024-25 | la diapositive du T1 avec saturation de graisse (p. 4), que la FC 2025-26 décrit sans la montrer ; cité aussi pour B0 (p. 6), le bruit (p. 7), TR (p. 9), la FLAIR (p. 13) et le cas clinique (p. 15) | `src-cours-bmcp-cir-2425` |
| Cours n°22 2023-24 (Charonéo) | la perfusion (p. 5, 11-12), l'image 5 du cas clinique (p. 12), le bruit (p. 7), B0 (p. 6) | cité dans les justifications seulement |
| FC n°19 « Échographie et IRM », 2025-26 | la RMN (`bmcp_echographie_irm`) : contre-indications absolues (p. 14), pondérations (p. 13), précession (p. 6-7) | citée dans les justifications seulement |

Les deux polycopiés d'annales sont déclarés avec les seuls champs convenus
(id, kind, titre, chemin, auteur), pour que les chapitres écrits en parallèle
qui en tirent des questions les déclarent à l'identique.

## Ce que le cours a dicté

Le ronéo n'a ni rouge ni gris. Le professeur fixe l'objectif (p. 5) :
« reconnaître les différents contrastes, les différentes séquences, c'est un
objectif de rang A pour les EDN ». D'où :

- six cartes **« quelle séquence ? »** (QRU), l'image nue en question : T1, T2,
  FLAIR, T1 avec saturation de graisse, diffusion, TOF ; chaque justification
  dit le critère, dans l'ordre que le cours rend impératif (p. 4) : d'abord le
  contraste entre substance grise et blanche, ensuite le LCS, puis la graisse ;
- la **planche du cas clinique** (p. 13) : cinq images numérotées par le
  professeur, à légender par leur séquence ;
- le **tableau TR × TE** cliquable (p. 8-9) ;
- l'AVC, ses chiffres et ses quatre séquences (p. 9-13), en QCM, textes à trous
  et QROC.

Une nuance du ronéo, dite sur les cartes sans `ATTENTION` : la substance grise
en T1 est « isointense » dans le texte (p. 2), « hypointense » sur la
diapositive (p. 3) — « grise », moins intense que la blanche, dans les deux
cas ; aucune proposition ne se joue sur ce mot.

## Ce que les annales ont dicté

| Session | N° | Polycopié | Clé imprimée | Retenue | Thème |
|---|---|---|---|---|---|
| 2023/2024 S2 | QROC 1 | BMCP 21 | « Imagerie par résonnance magnétique IRM » | IRM (coquille dite) | `examen-irm` |
| 2023/2024 S2 | QROC 2 | BMCP 21 | TE = temps d'écho, TR = temps de répétition ; T1 et T2 | idem | `tr-te` |
| 2023/2024 S2 | QROC 3 | BMCP 21 | « Mouvement de précision », résonance, relaxation | précession (coquille dite) | `rmn` |
| 2023/2024 S2 | QROC 4 | BMCP 21 | pacemaker, stimulateurs, implants cochléaires, corps étrangers ferromagnétiques, prothèses, claustrophobie, agitation | idem | `examen-irm` |
| 2022/2023 S1 | Q.27 | BMCP 21 | — (ligne vide) | **BE**, déduite | `contrastes-irm` |
| 2022/2023 S2 | Q.28 | BMCP 18 (et BMCP 21) | ACE | ACE | `sequences-fonctionnelles` |
| 2020/2021 S2 | Q.29 | BMCP 21 | ABD | ABD | `contrastes-irm` |
| 2020/2021 S2 | Q.30 | BMCP 21 | CD | CD | `sequences-fonctionnelles` |
| 2019/2020 S1 | Q.27 | BMCP 21 | ABDE | ABDE | `sequences-fonctionnelles` |
| 2019/2020 S2 | Q.29 | BMCP 21 | « Pas de correction » | **CE**, déduite | `tr-te` |
| 2018/2019 S1 | Q.28 | BMCP 21 | CD | CD | `sequences-fonctionnelles` |
| 2018/2019 S2 | Q.27 | BMCP 21 | ABDE | ABDE | `contrastes-irm` |
| 2017/2018 S2 | Q.29 | BMCP 21 | BE | BE | `contrastes-irm` |
| 2017/2018 S2 | Q.30 | BMCP 21 | ACE | ACE | `sequences-fonctionnelles` |
| 2015/2016 S1 | Q.28 | BMCP 21 | E | E | `contrastes-irm` |

Ce qui revient : la **diffusion** (sept fois : mouvement brownien, gradients de
déphasage puis de rephasage, infarctus hyperintense), le **TR et le TE** (cinq
fois), la **FLAIR** (quatre fois : LCS annulé par inversion-récupération,
impulsion initiale de 180°), le **T2* et le sang** (trois fois), la
**perfusion** (cinq questions). Deux paires sont mot pour mot la même
question : 2017/2018 S2 Q.29 = 2022/2023 S1 Q.27, et 2017/2018 S2 Q.30 =
2022/2023 S2 Q.28 ; une carte par session, comme ailleurs.

Les autres questions de BMCP 21 sont rangées dans d'autres chapitres (plan
C16) : la TEP-TDM de 2023/2024 S1 (Q.22-24) à `bmcp_tep`, la RMN et
l'examen IRM (2023/2024 S1 Q.25, 2022/2023 S1 Q.26, 2021/2022 S1 Q.22 et
Q.25, 2019/2020 S1 Q.26, 2018/2019 S1 Q.25, 2018/2019 S2 Q.26, 2017/2018 S1
Q.25, 2015/2016 S2 Q.27) à `bmcp_echographie_irm`.

**La perfusion** n'est que nommée dans le cours 2025-26 (p. 5 : cartes
colorées, irrigation sanguine). Le cours 2023-24 du même professeur en disait
davantage : le gadolinium fait chuter le signal T2* (p. 11), la substance
grise est plus vascularisée (p. 5), l'infarctus est hypoperfusé (p. 12). TTP,
TTM et CBV ne sont dans aucun cours : leurs justifications citent Petrella et
Provenzale (« MR perfusion imaging of the brain », AJR 2000), les courbes DSC
de mriquestions.com et Radiopaedia (« DSC perfusion »). Les cinq clés imprimées
s'y accordent ; la proposition « TTM = largeur à mi-hauteur » (2019/2020 S1
Q.27 D) est dite pour ce qu'elle est, la mesure simplifiée du temps de transit
moyen.

## Les erreurs du ronéo 2025-26

Toutes en `ATTENTION` nu, la sorte dite dans le texte. Aucune n'est dans le
tableau d'erreurs de la promo 2025-26 (`Erratas BMCP.docx` n'a pas d'entrée
pour la FC n°22) : toutes ont été trouvées en relisant.

| Page | Le ronéo | Retenu | Sorte | Cartes |
|---|---|---|---|---|
| 8 | « TR (temps de relaxation) », au titre et à la définition | temps de **répétition** (cours 2024-25, p. 9 ; FC n°19, p. 12 ; annales) | prise de notes | `cir-qc-tr-te` (A), `cir-fa-tr-te`, `cir-anq-2324s2-qroc2` |
| 11 | FLAIR : « au moment où le LCS va passer par le 0 […] on commence la séquence avec une impulsion à 180° » ; « c'est une version du signal à 180° » | l'impulsion de 180° **inverse** l'aimantation au départ ; l'excitation à 90° part au temps d'inversion, quand le LCS passe par 0 (diapositive de la p. 11). Même phrase en 2024-25, que l'errata de la promo d'alors proposait de corriger | prise de notes | `cir-qc-flair-avc` (B) |
| 12 | « phénomène d'entrée de couple » | entrée de **coupe** (même page plus bas, diapositive p. 13) | prise de notes | `cir-qc-tof` (B) |
| 10 | « des cytochromes qui permettent de faire des réactions osmotiques » | réactions d'**oxydoréduction** (le fer de l'hème, Fe2+/Fe3+) ; les cours 2023-24 et 2024-25 ne parlent pas des cytochromes, rien ne dit ce que le professeur a dit | prise de notes probable | `cir-qc-t2-etoile` (C) |
| 13 | la patiente a « du mal à bouger le bras **gauche** », puis « une paralysie du visage et du bras **droit** » | la lésion est dans l'hémisphère gauche : déficit **droit**, avec l'aphasie (le cours 2023-24, p. 11, décrit un déficit du membre supérieur droit) ; la phrase fausse est déjà au ronéo 2024-25 (p. 15) | prise de notes | `cir-qc-cas-clinique` |
| 6 | « le bruit caractéristique de l'IRM correspond à ces ondes de radiofréquence » | le cours lui-même (même idée aux cours 2023-24 et 2024-25, p. 7). À l'examen : comme le professeur. La référence : le bruit vient surtout de la commutation des gradients (McJury et Shellock, J Magn Reson Imaging 2000) | le cours lui-même | `cir-qc-relaxation` (A) |
| 6 | B0 « environ 100 000 fois » le champ terrestre | 1,5 T / 50 µT ≈ 30 000 ; 3 T ≈ 60 000 (cours 2023-24, p. 6 ; le cours 2024-25 disait « 10 000 ») | point douteux | `cir-qc-signal-b0` (D), `cir-fa-b0` |
| 5 | « contraste FLOSE » | nom introuvable ; sans doute la **FLAWS** (Tanner et al., J Magn Reson Imaging 2012), qui supprime substance blanche et liquide pour ne garder que la substance grise | point douteux | `cir-qc-fonctionnelles` (E) |

Le plan C16 rangeait le bruit en « point douteux » : la même idée dans les
cours 2023-24 et 2024-25 (p. 7 chacun) en fait le cours lui-même.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2022/2023 S1 Q.27 | — (ligne vide) | BE, `officielle=False` | clé déduite du cours (p. 2-3, 8-9, 11) ; la même question a la clé BE en 2017/2018 S2 Q.29 |
| 2019/2020 S2 Q.29 | « Pas de correction » | CE, `officielle=False` | clé déduite du cours : TR long + TE court n'est pas un T2 (p. 8-9), le sang est en hyposignal en T2* (p. 10), la FLAIR garde le contraste du T2 (p. 4) |
| 2023/2024 S2 QROC 3 | « Mouvement de précision » | précession | coquille de la table, dite dans l'explication ; corrigé gardé officiel |

Aucun conflit : `CONFLITS = []`. Aucune clé imprimée ne contredit le cours ni
une source sûre.

## Les schémas et les figures

| Fichier | Ce qu'on fait | Carte |
|---|---|---|
| `tr-te.svg` (redessiné, `schemas.py`) | clique la case du T1, du T2, de la densité de protons ; la case TR court + TE long n'est pas une zone (peu de signal) | `cir-zo-tr-te` (3 cartes) ; la version légendée illustre 5 cartes |
| `cir-cas-avc.png` (p. 13) | planche à légender : les numéros sont ceux du professeur, il n'y a rien à effacer ; 5 légendes, 3 intrus (T1, T2, T1 avec saturation de graisse) | `cir-pl-cas-avc` |
| `cir-q-*.png` (p. 3, 4, 5 ; 2024-25 p. 4) | l'image est la question (`illustration_question`) : la coupe seule, sans le texte de la diapositive | les six `cir-qu-sequence-*` |
| `cir-an-series-irm.png` (BMCP 21, p. 3) | les six séries de l'annale, données communes des quatre QROC, montrées avant la question | les QROC 1-4 et `cir-qc-series` |

La correction de la planche (`cir-cas-avc-legende.png`) ajoute la clé sous la
diapositive : « 1 Diffusion · 2 FLAIR · 3 T2* · 4 TOF (ARM) · 5 Perfusion ».
Le ronéo ne dit rien de l'image 5 ; c'est une carte colorée, comme la
perfusion de la p. 5, et le cours 2023-24 (p. 12) la nomme sur le même cas. La
légende du média et la note du numéro 5 le disent.

`cir-qc-series` est une question de cours bâtie sur l'image de l'annale
2023/2024 S2 : la règle TR/TE de la p. 9 appliquée aux six séries (SE, IR, GR).
Sa clé est celle du cours ; l'annale ne pose pas cette question.

Les 17 figures de la FC 2025-26 sont des captures de diapositives ; 15 sont
extraites (la page de garde et la diapositive T2 et FLAIR de la p. 11, doublon de celle de la p. 4, ne le sont pas). Le
T1 avec saturation de graisse vient du cours 2024-25 (p. 4), seule figure d'une
autre année. Aucune photographie de patient : les coupes d'IRM sont la matière
du cours.

## Le lexique

Neuf termes, pages mesurées dans le PDF de la FC n°22 : Isointense (p. 2-4),
Hyperintense (p. 2-4), Hypointense (p. 2-4), Pondération (p. 2-4, 8-9),
Brownien (p. 5, 11), Susceptibilité (p. 10, 13), Infarctus (p. 12-13), Aphasie
(p. 13), Thrombectomie (p. 13).

**Ischémie**, proposée par le plan, est déjà au lexique de `semio_osteo`
(`lex-ischemie`) : un identifiant de note est unique dans la bibliothèque, elle
n'est pas reprise. **Infarctus** la remplace (aucun chapitre ne l'a).

Les racines `iso-`, `hyper-`, `hypo-`, `a-/an-` et `-ectomie` reprennent les
clés et les pages des FC de sémantique ; six racines nouvelles (`intensus
(latin)`, `pondus (latin)`, `-phasie`, `thromb(o)-`, `infarcire (latin)`,
`suscipere (latin)`) et les neuf termes sont proposés pour `etymologies.json`
dans `scratchpad/etym/bmcp_contrastes_irm.json`, vérifiés sur le Wiktionnaire,
le Gaffiot et le Bailly. « Brownien » est un éponyme (Robert Brown, 1827),
dit « Mot français », comme la lyonisation.

## Questions pour Vincent

1. **Le bruit de l'IRM** : le professeur l'attribue aux ondes de
   radiofréquence, en 2023-24, 2024-25 et 2025-26 ; c'est la commutation des
   gradients. La carte dit de répondre comme lui à l'examen et donne la
   référence. D'accord ?
2. **L'image 5 du cas clinique** est tenue pour une perfusion (le ronéo 2025-26
   n'en dit rien ; le cours 2023-24 la nomme). D'accord pour la garder dans la
   planche ?
3. **Les clés de thèmes** : `t1-t2` et `avc` du plan sont devenues `rmn`
   (partagée avec `bmcp_echographie_irm`, même libellé) et `irm-avc` (une clé
   ne porte pas de chiffre, « avc » est trop générique). D'accord ?
4. **Ischémie** n'est pas reprise au lexique (déjà dans `semio_osteo`) ;
   Infarctus la remplace. D'accord ?
5. **Le « contraste FLOSE »** (p. 5) : nom introuvable, sans doute la séquence
   FLAWS ; la carte le garde en point douteux. Faut-il le demander au
   professeur ou à la promo ?

## À relire

Aucune carte `a-relire` : chaque carte de cours a sa page dans la FC 2025-26 ;
les propositions d'annales hors du cours (la perfusion) citent le cours
2023-24 et une source de radiologie.

## Intégration (05/10)

- Les libellés de thèmes sont dans `THEME_LABELS`
  (`app/src/med_engine/application/scopes.py`), bloc « BMCP FC n°6 à 22 ».
- Les étymologies proposées (racines et termes) sont versées dans
  `.claude/skills/nouveau-chapitre/scripts/etymologies.json` ;
  `appliquer_etymologies.py` n'a rien réécrit, les textes du lexique étant
  déjà à sa forme.

## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier (BMCP) ou du 6 janvier (SSH, papier). Sous les annales, 26 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 6 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `contrastes-irm` | 11 | 2 | 5 |
| `sequences-fonctionnelles` | 4 | 1 | 5 |
| `examen-irm` | 3 | 1 | 2 |
| `rmn` | 3 | 1 | 1 |
| `tr-te` | 5 | 1 | 2 |

**Le schéma** `ech-contrastes-irm`, « Les contrastes en IRM · reconnaître, fabriquer, régler », donne 44 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_CONTRASTES_IRM`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- cir-an-2223s2-q28 D, E ; cir-an-1718s2-q30 D, E ; cir-an-2021s2-q30 C, D, E ; cir-an-1920s1-q27 C, D, E ; cir-an-1819s1-q28 B, C, D, E — la perfusion (chute du signal T2* au passage du gadolinium, hyperperfusion de la substance grise, TTP, TTM, CBV, carte de l'infarctus) n'est que nommée dans la FC 2025-26 (p. 5 : cartes colorées, irrigation sanguine) et dans le cours 2024-25 (p. 6) ; ses justifications citent le cours 2023-24 et Petrella et Provenzale, absents des sources : aucune marche. Ces lettres se posent sur la case « Perfusion », qui ne porte aucun trou.
- cir-an-1516s1-q28 E — « aucune des propositions précédentes » se déduit des quatre autres, que préparent cir-ech-s2, s3, s11 et s12 ; posée sur la case T2, où tombent B et C.

## Régénérer

```powershell
cd contenu\chapitres\bmcp_contrastes_irm
..\..\..\app\.venv\Scripts\python.exe generer.py
```

`generer.py` est la copie exacte de
`.claude/skills/nouveau-chapitre/scripts/generer_modele.py`. La fiche (FC n°22)
entre dans le dossier des PDF de l'application par
`outils/copier_les_cours.py`, lancé hors du bac à sable.
