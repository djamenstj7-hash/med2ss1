# Organisation temporelle du système immunitaire — paquet Immunologie

63 notes, 120 cartes. Chapitre `chap-ue-immunologie-fc1` de l'UE Immunologie
(identifiant du squelette). Cours du **Pr Dubucquoi, le 21/09/2026** (semaine 3),
« Organisation temporelle des acteurs de la réponse immunitaire », un ronéo de 14
pages ; annales de deux sessions (trois QCM). Examen de novembre.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| Texte à trous | 13 | 66 |
| QRM | 20 | 20 |
| QROC | 12 | 12 |
| Recto-verso | 9 | 9 |
| Lexique | 8 | 8 |
| Schéma cliquable | 1 | 5 |

Dont **3 annales** (QRM) sur 2 sessions : 2019/2020 (Q9) et 2017/2018 (Q2, Q9).

**Un schéma cliquable** (`schemas.py`, `imm-zo-frise`) : la frise du temps de
la diapositive p. 5, redessinée sans légende — le bandeau du temps, l'agression
en rouge, cinq périodes à cliquer : la production en amont, la réponse innée
(quelques heures), l'adaptative (quelques jours à une semaine), l'élimination
(une à quatre semaines), la mémoire (des mois, voire des années). Le professeur
demande l'ordre de grandeur de ces délais dans ses questions de révision ; la
diapositive légendée est en correction.

Huit thèmes, dans l'ordre du cours, aux libellés génériques pour que les
chapitres d'immunologie à venir les réemploient :

| Clé | Libellé |
|---|---|
| `systeme-immunitaire` | Missions du système immunitaire et agresseurs |
| `inne-adaptatif` | Immunité innée et immunité adaptative |
| `chronologie-reponse` | Chronologie de la réponse immunitaire |
| `organes-lymphoides` | Organes lymphoïdes |
| `repertoire` | Répertoire et éducation des lymphocytes |
| `cellules-dendritiques` | Les cellules dendritiques |
| `effecteurs-adaptatifs` | Lymphocytes T, B et mécanismes effecteurs |
| `etapes-reponse` | Expansion, contraction et mémoire |

Leurs libellés sont à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`), bloc « immunologie ». Deux clés
sont partagées avec les chapitres voisins, au même libellé : `organes-lymphoides`
(`immuno_organes`) et `cellules-dendritiques` (`immuno_cmh`, « Les cellules
dendritiques »). `immuno_organes` a renoncé à `systeme-immunitaire` pour lui
laisser le libellé d'ici.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-immuno-temporelle` — Ronéo & Juliette, « 1. Organisation temporelle des acteurs de la réponse immunitaire » (14 p.) | **2026-27** | **la base** : chaque note du cours porte sa page ; c'est ce que le lecteur ouvre |
| `src-annales-immuno-fc1` — Ronéosaure, « IMMUNO n°1 » (2 p.) | 2024-25 | les 3 QCM et leur table de corrections |
| `src-cours-immuno-2425` — Ronéosaure, FC n°1 (15 p.) | 2024-25 | appoint, même professeur ; source des 3 cartes absentes du cours 2026-27 ; les questions de révision du professeur (p. 15) |
| `src-cours-immuno-lb-2425` — Ronéosaure, FC n°8, Ontogenèse des LB | 2024-25 | appoint pour les deux annales sur les LB (p. 3-6, 11) |
| `src-temporelle-renvoi-cd` — Ronéo & Juliette, « Les cellules dendritiques » (10 p.) | 2026-27 | la seule diapositive « Maturation des cellules dendritiques » (p. 9), pour l'annale 2017/2018 Q2. C'est la fiche du chapitre du CMH (`immuno_cmh`, `src-fc-immuno-cmh`) : elle est déclarée ici **sans** `chapitre`, sous un identifiant de renvoi (comme `src-stress-renvoi-*` en BMCP), parce que l'importateur réécrit une source à chaque import et qu'une redéclaration de `src-fc-immuno-cmh` sans `chapitre` effacerait son rattachement |
| tableau d'erreurs Immunologie 2024-25 (Ronéosaure) | 2024-25 | neuf entrées sur ce cours : sept corrections reprises dans la FC (dont « organe de défense non localisable » et les LT produits dans la moelle puis éduqués dans le thymus), une coquille, et une note que « les QCM concernent des cours ultérieurs » |
| tableau d'erreurs Immunologie 2026-27 (Ronéo & Juliette) | 2026-27 | **vide** au 28/09/2026 |

Les vérifications faites hors du cours sont citées dans la carte qui s'en sert :
Rakoff-Nahoum et al., Cell 2004 (microbiote et TLR) ; Flajnik & Kasahara, Nat Rev
Genet 2010 (l'immunité adaptative, il y a environ 500 millions d'années) ; Cui &
Kaech, Immunol Rev 2010 (expansion d'environ 10 000 fois en une semaine, 5 à 10 %
de survivants) ; Bourke et al., Blood 2003 (TLR des LB humains) ; Sims et al.,
Blood 2005 (LB transitionnels) ; Glick 1956 (la bourse de Fabricius).

## Ce que le cours a dicté

- **Le cours est une introduction**, dit le professeur : vocabulaire, acteurs,
  grandes étapes, dynamique. D'où un chapitre de textes à trous qui se récitent
  (missions, agresseurs, stratégies, capteurs, délais, organes, répertoire,
  contrôle de qualité, effecteurs, étapes), de QCM qui portent les couples à ne
  pas inverser (inné / adaptatif, primaire / secondaire, humorale / cellulaire,
  CD4 / CD8), et de QROC de vocabulaire (naturelle, acquise, anamnestique, LPS,
  domiciliation, polarisation, Treg).
- **Les questions de révision du professeur** (FC n°1 2024-25, p. 15) ont chacune
  leur carte : les trois missions (`imm-rv-missions`, `imm-fa-missions`), les
  sources d'agression (`imm-fa-agresseurs`, `imm-qc-agresseurs`), les autres noms
  de l'innée et de l'adaptative (`imm-qr-naturelle`, `imm-qr-acquise`), l'ordre
  de grandeur des délais (`imm-rv-delais`, `imm-fa-frise`, `imm-zo-frise`), le
  rôle de la mémoire (`imm-rv-memoire`).
- **Ni rouge ni gris** dans ce ronéo : rien n'est hors programme.
- **La partie V de 2024-25**, « dynamique de la réponse et biologie médicale »,
  annoncée dans les objectifs 2026-27 (« introduire la démarche de prescription
  des tests biologiques »), n'est pas dans le ronéo, ni cette année ni la
  précédente, où le professeur l'avait passée « très rapidement » : aucune carte.
- **Le ronéo simplifie**, et la carte le dit sans le contredire : le thymus
  « où sont produits/achevés » les LT (p. 9), que la p. 11 précise (le précurseur
  vient de la moelle) — la carte suit la p. 11 (`imm-qc-education` E) ; le LPS
  « chez de nombreuses bactéries », qui est celui des bactéries à Gram négatif.

## Ce que les annales ont dicté

Trois QCM, **aucun sur le cours d'introduction lui-même** : le polycopié les range
sous « Organisation temporelle », le tableau d'erreurs 2024-25 relevait déjà
qu'ils « concernent des cours ultérieurs ».

| Savoir | Questions |
|---|---|
| La lymphopoïèse B : réarrangements, révision du BCR, LB transitionnel, BAFF et APRIL | 2019/2020 Q9, 2017/2018 Q9 |
| La maturation de la cellule dendritique | 2017/2018 Q2 |

Elles restent ici, là où le polycopié les range. Leur correction s'appuie sur ce
que le cours d'introduction en dit (production et éducation dans la moelle, p. 9
et 10 ; la cellule dendritique interprète, p. 11), et cite le cours qui les
traite : la FC n°8 2024-25 (ontogenèse des LB, même professeur, pas encore tenue
en 2026-27) et le ronéo 2026-27 des cellules dendritiques (p. 9). Deux schémas
redessinés les illustrent (`lymphopoiese-b.svg`, `maturation-cd.svg`).

## Les erreurs du ronéo de l'année

Chacune est dite par **ATTENTION**, avec son genre juste après le mot, dans la
carte qui porte la notion. À l'examen, on répond d'abord comme le professeur
(règle de Vincent, 28/09).

| Page | Genre | Ce que dit le ronéo | Ce qui est juste | Carte |
|---|---|---|---|---|
| 13 | **prise de notes** | expansion clonale : « d'une cellule isolée à environ 1 sur 100 000 clones circulants » | deux chiffres mêlés : un clone naïf ≈ 1 lymphocyte sur 100 000 (p. 7) ; une cellule activée donne ≈ 100 000 cellules du même clone (p. 8) ; FC n°1 2024-25 : « x10 à 100 000 » (p. 8), « 10⁵-10⁶ » (p. 12) | `imm-qc-etapes` A |
| 4 | **point douteux** | le microbiote « n'émet pas de signaux de danger, il n'est donc pas combattu » | les commensaux portent LPS, flagelline, peptidoglycane, reconnus en permanence par les TLR (Rakoff-Nahoum, Cell 2004) ; il n'est pas combattu grâce au cloisonnement et à une tolérance active (p. 2) ; juste au sens de la théorie du danger | `imm-qc-capteurs` D |
| 9 | **point douteux** | « La moelle osseuse pour les lymphocytes B (« B » Bone marrow) » | un moyen mnémotechnique, pas l'étymologie : le B vient de la bourse de Fabricius (Glick, 1956) ; les LB humains se développent bien dans la moelle | `imm-qc-organes` B |
| 8 | **point douteux** (trouvé à la relecture) | « Adaptation du récepteur (clé et serrure) » : la clé s'ajuste en trois semaines | vrai du BCR (hypermutation somatique, maturation d'affinité) ; le TCR ne mute pas après le thymus, la réponse T gagne en efficacité par sélection des clones | `imm-qc-forces-adaptative` D |
| 10 | **point douteux** (trouvé à la relecture) | les cellules sortent des organes primaires « matures (…) mais naïves » | exact pour le LT ; le LB sort de la moelle « immature, dans un état transitionnel » (FC n°8 2024-25, p. 5), ce sur quoi joue l'annale 2019/2020 Q9 | `imm-qc-education` D |

Les trois premières sont dans la liste de la promo ; les deux dernières sont à
y ajouter (`contenu/ERRATA_RONEOS_2026-27.md`, section des points douteux).

Et, sans ATTENTION parce qu'aucune carte n'en dépend : l'en-tête écrit
« Pr. Dubocquoi » pour Dubucquoi ; « 2ème lien de défense » (p. 4) pour ligne ;
« 1. … 1. » dans la liste des deux stratégies (p. 3) ; « dangereuse.env » (p. 10),
une coquille.

## Les clés qui ne sont pas reprises telles quelles

Aucune : les trois clés imprimées sont reprises, `officielle` ; `CONFLITS` est vide.

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2019/2020 Q9 | DE | DE | juste (FC n°8 2024-25, p. 3-6) ; « CDE pas vu en cours », note des rédacteurs après la proposition E, est retirée de l'énoncé et dite dans la justification |
| 2017/2018 Q2 | BDE | BDE | juste (diapositive de maturation, ronéo 2026-27 des CD, p. 9) |
| 2017/2018 Q9 | CD | CD | juste ; « (pas vu en cours) » après C, note des rédacteurs, retirée de l'énoncé et périmée (BAFF et APRIL « à retenir », FC n°8 2024-25, p. 6) ; D (les LB expriment des récepteurs de l'immunité innée) n'est pas dans le cours, mais vrai (TLR9 et TLR10 ; Bourke et al., Blood 2003) |

Cas ouvert : aucun.

## Absent du cours 2026-27

Trois cartes n'ont **pas de version 2026-27** et le disent, en tête de leur
explication. Elles citent la FC n°1 2024-25 à sa page (`fiche` = `src-cours-immuno-2425`) :

| Carte | Ce qui manque au ronéo 2026-27 | Source restée |
|---|---|---|
| `imm-rv-non-localisable` | le système immunitaire, « organe de défense non localisable » (ajout du tableau d'erreurs 2024-25) ; le ronéo dit l'idée sans le mot | FC n°1 2024-25, p. 2 |
| `imm-rv-tcr-bcr` | les noms TCR et BCR ; le ronéo dit seulement « récepteur », mais les annales emploient BCR | FC n°1 2024-25, p. 10 |
| `imm-qr-cd3` | CD3, la « carte d'identité » des LT | FC n°1 2024-25, p. 12 |

Détails de la FC n°1 gardés **dans des explications** de cartes par ailleurs
vérifiées, et dits comme tels : le CMV parmi les super-pathogènes
(`imm-qr-super-pathogene`), le « super-héros qui n'a pas sa cape »
(`imm-qc-education`). Non repris : l'exemple du paludisme, la mémoire « apparue il
y a 450 millions d'années avec les requins » (le ronéo 2026-27 dit 100 millions
d'années après l'innée de 540 Ma, avec les poissons cartilagineux, et la carte
suit l'année), la partie V.

## Les figures

Deux diapositives du ronéo 2026-27, extraites en PNG (PyMuPDF, réduites à
1400 px de large) ; six schémas légendés redessinés en SVG ; tous du côté de la
correction. **17 QCM sur 20 illustrés (85 %)**, 32 notes sur 63.

| Fichier | Source, page | Ce qu'elle montre | Cartes |
|---|---|---|---|
| `frise-reponse-immunitaire.png` | ronéo 2026-27, p. 5 | la frise « Relations temps (durée) et réponse immunitaire » | `imm-fa-frise`, `imm-qc-frise`, `imm-rv-delais`, `imm-zo-frise` |
| `frise-reintroduction.png` | ronéo 2026-27, p. 6 | la réintroduction du même pathogène : « Quasi-immédiate ! » | `imm-qc-reintroduction`, `imm-rv-memoire` |
| `frise-nue.svg` | d'après p. 5 | la même frise, sans légende, pour le clic | la question de `imm-zo-frise` |
| `inne-adaptatif.svg` | d'après p. 4-8 | innée et adaptative, côte à côte | `imm-fa-capteurs`, `imm-qc-capteurs`, `imm-qc-innee`, `imm-qc-adaptative`, `imm-qc-forces-innee`, `imm-qc-forces-adaptative` |
| `circuit-organes-lymphoides.svg` | d'après p. 9-11 | OL primaires, secondaires, sites effecteurs ; la CD des tissus au ganglion | `imm-fa-organes`, `imm-fa-controle`, `imm-qc-organes`, `imm-qc-education`, `imm-rv-parcours-lt` |
| `effecteurs-adaptatifs.svg` | d'après p. 12-13 | LT CD4, LT CD8, LB ; cellulaire et humorale | `imm-fa-effecteurs`, `imm-fa-humorale-cellulaire`, `imm-qc-effecteurs`, `imm-qc-humorale-cellulaire`, `imm-qc-conclusion`, `imm-qr-polarisation`, `imm-rv-humorale-cellulaire` |
| `expansion-contraction.svg` | d'après p. 6-8, 11, 13 | expansion, contraction, mémoire, réintroduction, en échelle logarithmique | `imm-fa-etapes`, `imm-qc-etapes`, `imm-rv-contraction` |
| `maturation-cd.svg` | ronéo 2026-27 des CD, p. 9 | CD immature et CD mature | `imm-qc-cellule-dendritique`, `imm-qr-interprete`, `imm-an-1718-q2` |
| `lymphopoiese-b.svg` | FC n°8 2024-25, p. 3-6 | de la moelle au LB mature naïf | `imm-an-1920-q9`, `imm-an-1718-q9` |

Les QCM non illustrés (missions, agresseurs, répertoire) n'ont pas de figure dans
le ronéo, et un schéma n'y apprendrait rien. La page de garde du ronéo (un logo)
n'a pas été reprise. La courbe d'expansion place la mémoire vers 5 % du pic : le
cours dit que 95 % meurent, pas la taille exacte du contingent.

## Le lexique

Huit termes, les mots de l'immunologie que ce cours introduit ; pages mesurées
dans le texte du ronéo 2026-27 (même règle que `chercher_pages.py` : mot entier,
pluriel permis, accents ignorés) :

| Terme | Origine | Pages |
|---|---|---|
| Immunité | latin immunitas (in- + munus) | 1, 3-8, 10, 12, 13 |
| Antigène | grec anti- + -gène | 9-11 |
| Anticorps | anti- + latin corpus | 12 |
| Lymphocyte | latin lympha + grec kutos | 1, 5-12 |
| Anamnestique | grec anamnêstikos | 5 |
| Apoptose | grec apoptôsis, « chute des feuilles » | 10, 13 |
| Clone | grec klôn, « jeune pousse » | 8, 11, 13 |
| Cytotoxique | grec kutos + toxikon | 11, 12 |

Aucun autre chapitre d'immunologie n'existe encore : aucun terme n'a été laissé
ailleurs. Les racines que la FC de sémantique enseigne la citent à sa page :
-gène (1/2, p. 6), cyt(o)- (1/2, p. 8), apo- et -ptose (1/2, p. 3), ana- (2/2,
p. 10). Les autres (munus, corpus, lymph(o)-, clon-, tox(i)-, anti-, -mnèse)
s'affichent en gris, « hors FC ». **Les étymologies des huit termes et de sept
racines nouvelles** (munus, corpus, lymph(o)-, cyt(o)- / -cyte, -ptose, clon-,
tox(i)-) sont proposées pour `etymologies.json` (TLFi, Wiktionnaire, Gaffiot,
Bailly) ; `appliquer_etymologies.py` les écrira dans `LEXIQUE` une fois la table
complétée — les définitions n'en portent pas encore la phrase.

## À relire

**0 carte `a-relire`** : chaque note du cours cite sa page du ronéo 2026-27 (49
notes et les 8 termes du lexique), les trois cartes absentes citent la FC n°1
2024-25, et les trois annales disent d'où vient leur correction. Reste à Vincent :

- les trois cartes « Absent du cours 2026-27 » : les garder ?
- les trois annales portent sur des cours ultérieurs : les laisser ici, où le
  polycopié les range, ou les déplacer dans les chapitres des LB et des cellules
  dendritiques quand ils existeront ?
- le tableau d'erreurs Immunologie 2026-27 est vide : y signaler « 1 sur 100 000
  clones circulants » (p. 13) ?

## Relecture (28/09)

Chaque carte relue contre la page qu'elle cite (ronéo 2026-27, FC n°1 et FC n°8
2024-25, polycopié d'annales), les trois clés d'annales et les chiffres tirés de
la littérature vérifiés (Cui & Kaech, Immunol Rev 2010 : environ 10 000 fois en
une semaine, 5 à 10 % de survivants ; Flajnik & Kasahara, Nat Rev Genet 2010 ;
Bourke et al., Blood 2003 ; Sims et al., Blood 2005). Corrigé à la relecture :

- `imm-qc-missions` B : « il ne s'adapte qu'après exposition » se jugeait faux par
  la p. 2 et vrai par la p. 3 (« il apprend au contact de l'agresseur ») ; remplacé
  par un item sans ambiguïté (la protection contre les seuls agents infectieux).
- `imm-qc-adaptative` B : la justification citait une phrase sans rapport ; elle
  cite maintenant les p. 5 et 8.
- `imm-qc-education` D et l'annale 2017/2018 Q9 A : la FC n°8 ne dit pas « la
  rate » ; la maturation « hors de la moelle » est ce qu'elle dit, la rate est
  la donnée murine (Sims et al. : chez l'Homme, des LB transitionnels circulent).
- `imm-qc-effecteurs` D : la réserve « selon le cours » est expliquée (antigènes
  thymo-indépendants, FC n°8 2024-25, p. 5).
- `lymphopoiese-b.svg` : le LB reconnaît l'antigène natif « sans apprêtement ni
  présentation par le CMH » — et non « sans cellule dendritique ».
- `lex-lymphocyte` : la définition n'exclut plus les NK.
- La source du ronéo des cellules dendritiques prend un identifiant de renvoi, et
  le libellé `cellules-dendritiques` celui du chapitre du CMH.

## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026)

Le pilote de l'immunité innée, étendu au reste de l'immunologie pour l'examen du 4/11 (choix de Vincent, 15/10). Sous les annales, 13 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 3 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `repertoire` | 5 | 1 | 1 |
| `cellules-dendritiques` | 5 | 1 | 1 |
| `effecteurs-adaptatifs` | 3 | 1 | 1 |

**Le schéma** `ech-lb-cd`, « Le LB et la cellule dendritique · deux parcours vers la réponse », donne 20 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_LB_CD`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu les dix chapitres ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Un désaccord entre cours, dit dans la carte** : imm-ech-s2 C porte un ATTENTION, car le ronéo 2026-27 de l'ontogenèse B fait produire IgM puis IgD, « jamais en même temps », alors que la diapositive montre les deux à la membrane du LB qui sort de la moelle.

**Sans marche** :
- imm-an-1718-q9 D : les récepteurs de l'immunité innée des LB (TLR9, TLR10) ne sont dans aucun cours déclaré ; la clé ne tient que par la littérature (Bourke et al., Blood 2003). Pas de lettre posée.

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```
