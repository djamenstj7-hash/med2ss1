# Hémogramme et myélogramme normaux — paquet d'exemple

78 notes, 113 cartes. Troisième chapitre de l'UE **Tissu sanguin**.

## Sources

- **Le cours de l'année, qui fait foi** : le ronéo Ronéo & Juliette 2026-27
  « Myélogramme et hémogramme normaux », N. Duployez, semaine 2, 18/09/2026,
  10 h-11 h, 16 pages (`src-fc-sang-hemogramme`). Le ronéo ne porte pas de
  numéro de cours ; c'était le FC n°3 en 2024-25.
- **Les diapositives transmises pendant ce cours**, le 18/09/2026 : bornes
  d'anomalie, lymphocytose, infiltrations des leucémies aiguës, mécanismes de
  la neutropénie, agranulocytose, lymphopénie, hémodilution, risque
  hémorragique, thrombocytose. Elles sont du cours 2026-27 : ce qu'elles seules
  portent reste du cours, même absent du ronéo.
- **Le polycopié d'annales** HEMATO n°3 (Ronéosaure 2024-25, 6 sessions,
  7 questions dont 3 QROC), dépouillé en entier.
- **Le ronéo 2024-25** du Pr Terriou (FC n°3, 23 pages), sur lequel le chapitre
  avait été bâti. Il reste la source des sept notes que le cours de l'année ne
  porte plus, ou dont il ne porte pas la réponse exacte (voir « Absent du cours
  2026-27 »).

Chaque note relue contre le ronéo 2026-27 cite sa page (`PAGES_2026`, en fin
de `donnees.py`) : 62 notes de cours sur 69, et six annales sur sept, qui y
gagnent leur source secondaire. La septième, `hem-an-2324-q4` (EPO), se lit
dans un autre ronéo, celui des cellules matures (p. 3-4), que ce chapitre ne
déclare pas.

Une note citée sur une page y trouve **l'essentiel** de sa réponse — sa réponse
exacte, ou la plupart de ses clés —, pas forcément tout : une proposition, un
trou ou un détail qui vient du ronéo 2024-25 ou des diapositives le dit dans sa
justification ou son explication, et les tableaux plus bas le listent. Une note
dont la réponse exacte ou la plupart des clés manquent au ronéo de l'année reste
citée sur le ronéo 2024-25.

## La relecture du 25/09/2026 (ROADMAP, C3)

Même plan, même trame, un autre enseignant, et seize pages au lieu de
vingt-trois. Ce qui a changé dans les cartes :

- **Réécrit, parce que 2026-27 dit autre chose.** L'agranulocytose passe de
  0,2 à **0,5 G/L** (`hem-qc-agranulocytose` A, `hem-fa-agranulocytose` c1),
  sa conduite devient l'**arrêt absolu du médicament** et la recherche
  d'alternatives, avec antibiothérapie probabiliste et isolement. La
  pancytopénie n'oriente plus « vers une cause centrale » : elle est centrale
  **ou** périphérique (`hem-qr-pancytopenie`). Les corps de Howell-Jolly sont
  un **signe d'anomalie de la rate**, et non plus « pas pathologiques en soi »
  (`hem-rv-howell`, `hem-qc-morphologie` E réécrite). Un blaste ne « signe »
  plus à lui seul une leucémie aiguë : la moelle normale en contient moins de
  5 % (`hem-qc-blastes` A réécrite). La LLC n'est « pas le premier diagnostic »
  que chez le jeune (`hem-qc-lymphocytose` E réécrite). Le frottis est lié aux
  leucocytes atypiques, et non à « toute anomalie » (`hem-qc-normes` C,
  `hem-qr-frottis`). Le verso de la thrombocytose suit la liste de la p. 14,
  infections comprises.
- **Le vocabulaire** : le ronéo 2026-27 dit **neutrophilie** et ne dit plus
  « polynucléose » ; les cartes ont suivi, et « polynucléose » reste accepté
  dans la QROC `hem-qr-bornes-pnn`.
- **Les chiffres qui ont disparu** — 120 G/L de réticulocytes, 80 % d'anomalies
  réactionnelles, 80 G/L avant une chirurgie lourde — ne sont plus donnés comme
  du cours de l'année : les explications disent d'où ils viennent.
- **Un stade qui se faisait nommer** : le trou c2 de `hem-fa-agranulocytose`
  demandait « promyélocytes ». Il demande désormais si le myélogramme est
  nécessaire quand un médicament suspect est identifié (p. 9).
- **Quinze notes nouvelles** pour ce que le cours 2026-27 enseigne et qu'aucune
  carte ne portait : les trois types d'hémopathies malignes, annoncés en QCM
  d'annales (`hem-qc-syndromes-malins`) ; les causes d'éosinophilie ; la LLC ;
  les lymphomes ; l'agranulocytose médicamenteuse comme première hypothèse
  devant une neutropénie isolée ; l'anémie microcytaire et la ferritine ; les
  signes des polyglobulies et des thrombopénies ; la pancytopénie, ses critères
  de gravité et son myélogramme ; la **LAM3**, « à connaître », urgence
  hématologique ; les examens complémentaires de la conclusion ; et deux points
  de raisonnement des p. 3-4 — un neutropénique est en général leucopénique
  (`hem-rv-neutropenie-leucopenie`), et ce dont dépend le nombre de leucocytes
  circulants (`hem-rv-variation-leucocytes`).
- **Des réponses acceptées alignées sur la réponse exacte** : `hem-qr-hiatus`
  dit « diminution » des formes matures, et n'accepte plus « formes matures
  absentes ».
- **Aucune note supprimée, aucun identifiant changé, aucun trou renuméroté.**
  Une seule clé a bougé : `hem-qc-morphologie` n'a plus d'item « inacceptable »,
  parce que sa proposition E réécrite oppose deux voisins (Howell-Jolly et
  hématies ponctuées).

## Consignes de programme du cours 2026-27

Imprimées dans le ronéo, souvent en gris — et le gris d'un ronéo est la voix
des rédacteurs, dont le contenu compte :

- « Valeurs normales à connaître sauf éosinophiles/basophiles (examen : QCM à
  raisonnement) » (p. 2) ; norme basse des PNN et norme haute des lymphocytes
  « à connaître » (p. 3, 6).
- Basophilie et monocytose : « À ne pas retenir » (p. 6).
- Hémoglobine : « valeurs basses à connaître / haute à ne pas connaître cette
  année » (p. 9), redit à la polyglobulie (p. 12).
- Leucopénies : « la seule importante à connaître : la NEUTROPÉNIE » (p. 7) ;
  lymphopénie « moins importante », retenir le VIH (p. 9).
- « QCMs annales : différencier les 3 types de syndromes hématologiques
  malins » (p. 4) ; thrombocytose de la carence martiale, « cas facile qui peut
  tomber » (p. 14) ; « à l'examen (partiel) : lymphocytes, neutrophiles,
  anémie, thrombopénie + questions de réflexion » (p. 16).

Les cartes qui font réciter une valeur désormais non exigée sont **gardées** —
PNE et PNB (`hem-fa-leucocytes` c3, c4), 18,5 et 17,5 g/dL
(`hem-fa-polyglobulie` c1, c2, `hem-qc-polyglobulie` A) — et leur explication
le dit. C'est à Vincent de trancher.

## Le cours le plus chiffré de l'UE

| | Ronéo 2026-27 |
|---|---|
| Leucocytes | 4 à 10 G/L (p. 3) |
| PNN · PNE · PNB | 1,5-7 · 0-0,4 · 0-0,1 G/L (p. 3) |
| Lymphocytes · monocytes | 1,5-4 · 0,2-0,8 G/L (p. 3) |
| Neutrophilie · éosinophilie · lymphocytose | > 7 · > 0,4 · > 4 G/L (p. 5-6) |
| Neutropénie | < 1,5 G/L — risque nul > 0,8, faible 0,5-0,8, **majeur < 0,5 = agranulocytose** (p. 7-8) |
| Lymphopénie | < 1,5 G/L (p. 9) |
| Anémie | < 13 H · < 12 F · < 11 enceinte (g/dL) (p. 9) |
| Polyglobulie | > 18,5 H · > 17,5 F (g/dL) — « à ne pas connaître » (p. 12) |
| Thrombopénie | < 150 G/L — provoquée < 50, spontanée < 20, fond d'œil < 20 (p. 13) |
| Thrombocytose | > 450 G/L (p. 14) |
| Pancytopénie grave | Hb < 8 g/dL · PNN < 0,5 G/L · plaquettes < 20 G/L (p. 14) |
| Leucémie aiguë | > 20 % de blastes au myélogramme, normale < 5 % (p. 7) |

Pour les leucocytes, les neutrophiles et les lymphocytes, la borne d'anomalie
est la borne de la norme : 4-10, 1,5-7, 1,5-4. Pas pour les monocytes : norme
0,2-0,8 (p. 3), monocytose au-delà de 1 G/L (p. 6) — voir les ATTENTION.

## Les contresens signalés (ATTENTION)

- **La norme des PNN, entre deux ronéos 2026-27 du même enseignant** : 1,5-7 G/L
  ici (p. 3, 5, 7), 2-7,5 G/L dans « Les cellules matures du sang » (p. 6).
  Chaque chapitre garde le chiffre de son ronéo ; ici, 1,5 et 7, qui sont les
  définitions écrites de la neutropénie et de la neutrophilie. Signalé dans
  `hem-qc-normes` B, `hem-qc-bornes` C et D, `hem-fa-leucocytes`,
  `hem-fa-bornes`, `hem-qr-bornes-pnn`. La carte `mat-qc-pnn` du chapitre des
  cellules matures cote l'autre fourchette vraie.
- **Les éosinophiles et les monocytes, de même** : 0-0,4 G/L ici, moins de
  0,5 G/L aux cellules matures (p. 8) ; monocytes 0,2-0,8 ici, 0,2-1 G/L aux
  cellules matures (p. 9), et ce ronéo-ci place lui-même la monocytose au-delà
  de 1 G/L (p. 6). Signalé dans `hem-fa-leucocytes`.
- **L'agranulocytose, 0,5 contre 0,2 G/L** : le ronéo 2026-27 dit 0,5 (p. 8),
  le ronéo 2024-25 disait « moins de 0,2 (0,5) ». Retenu : 0,5. Signalé dans
  `hem-qc-agranulocytose` A, `hem-fa-agranulocytose`, `hem-fa-neutropenie`.
- **L'erreur relevée par le tableau d'erreurs de l'UE** (seule entrée pour ce
  cours dans la version du 28/09/2026, p. 8) : carences en B12/folates et syndromes myélodysplasiques sont rangés
  sous « Conséquences » de la production inefficace ; ce sont ses **causes**.
  Signalé dans `hem-qc-neutropenie-mecanismes` D (et C), rappelé dans
  l'explication de `hem-qc-neutropenie`.
- **Le tabac, entre margination et neutrophilie** (erreur qu'aucun tableau ne
  relève) : le tabagisme « augmente la répartition des neutrophiles sur
  l'endothélium vasculaire » (p. 5). Pris à la lettre, c'est une margination,
  qui ferait baisser les PNN (p. 8) — la ligne suivante fait de la
  démargination une cause de neutrophilie. Retenu : le tabagisme est une cause
  de neutrophilie ; le mécanisme imprimé ne l'est pas. Signalé dans
  `hem-qc-neutrophilie` D.
- **L'« excès de margination » et la neutropénie cyclique, p. 8** (erreurs
  qu'aucun tableau ne relève). La parenthèse « (test d'exercice physique ou
  corticoïdes) » se lit comme une cause de neutropénie, alors que la p. 5 fait
  de l'effort et des corticoïdes une démargination, cause de neutrophilie.
  Retenu : c'est le test qui décolle les PNN marginés, pas la cause. Et la
  neutropénie cyclique, en gris, est rangée sous « anomalie de distribution »,
  alors que c'est une production médullaire qui baisse par cycles. Retenu :
  elle n'est pas une anomalie de distribution. Signalé dans
  `hem-qc-neutropenie-mecanismes` E et `hem-rv-neutropenie-anoter`.
- **Une erreur qu'aucun tableau ne relève** : « seul le médicament touche
  sélectivement les PNN », « tous les autres mécanismes touchent toutes les
  lignées » (p. 9). La neutropénie ethnique, les anticorps anti-PNN, la
  neutropénie cyclique (p. 8) ne touchent eux aussi que les neutrophiles.
  Retenu : le médicament est la première hypothèse, pas la seule. Signalé dans
  `hem-rv-agranulocytose-isolee`.
- **Le score de Matutes, p. 6 — c'est le cours lui-même** (relevé le
  28/09/2026, qu'aucun tableau ne relève) : « score de Matutes > 4 » est la
  formule de la diapositive, que le Ronéosaure 2024-25 (FC n°3, p. 9) porte
  déjà mot pour mot ; ce n'est pas une prise de notes fausse. Elle ne
  laisserait que 5 ; sur 5 marqueurs, la LLC score 4 ou 5 (Matutes et al.,
  *Leukemia* 1994). À l'examen, on répond comme le professeur (règle de
  Vincent, 28/09) : un item « score de Matutes > 4 » se tient pour vrai. Les
  trois cartes disent la formule du cours, puis la référence :
  `hem-qc-lymphocytose` (« ATTENTION — c'est le cours lui-même »),
  `hem-rv-mni-llc` et `hem-qc-llc`.
- **Un point douteux, non signalé en carte** : « même si un patient est
  neutropénique, il sera leucopénique » (p. 3). Avec les normes du même ronéo,
  1,2 G/L de PNN, 2,5 de lymphocytes et 0,5 de monocytes font 4,2 G/L de
  leucocytes : une neutropénie sans leucopénie. C'est sans doute une
  simplification orale ; `hem-rv-neutropenie-leucopenie` dit « en général ».

## Clés d'annales non reprises telles quelles

Aucune : les sept clés du polycopié et celle de la grille officielle de
2023/2024 sont reprises. Les quatre entrées de `CONFLITS` portent sur les deux
annales du dépôt du 15/10/2026 (voir « Les sujets du dépôt du 15/10/2026 ») :
le seuil féminin de la polyglobulie, où c'est le cours qui s'écarte de la grille,
et le QCM 6 de 2024/2025, sans corrigé.

Un cas examiné et écarté : `hem-an-2021s2-q4` A (« un hématocrite inférieur à
la normale », coté faux dans la définition d'une anémie macrocytaire). Le ronéo
2026-27 cite bien « Hb, Ht » pour la lignée rouge (p. 3), mais il y précise
qu'« on interprète la concentration d'hémoglobine », et il définit l'anémie sur
elle seule (p. 9) ; seule la polyglobulie se définit aussi sur l'hématocrite
(p. 12). Pas de contradiction : la clé est reprise, et la justification cite
ces trois pages.

## Absent du cours 2026-27

Des cartes et des propositions gardées telles quelles, pour que Vincent
décide : leur contenu n'est pas dans le ronéo 2026-27, mais rien ne le
contredit. Les notes des deux premiers tableaux ont pour source, dans le
paquet, le ronéo 2024-25 (`src-cours-sang-hemogramme`), et leur explication le
dit ; les propositions isolées restent dans des cartes citées sur le ronéo
2026-27, et leur justification dit d'où elles viennent.

**Notes entières, toujours citées sur le ronéo 2024-25**

| Note | Pourquoi |
|---|---|
| `hem-qc-myelogramme` | Technique du myélogramme (aucune contre-indication, deux doigts sous la fourchette sternale) et de la biopsie ostéo-médullaire (pas sous anticoagulant, 50 G/L, carotte de 1-2 cm) : sections supprimées. Restent le site de ponction, « dans le sternum, crête iliaque » (p. 7), et « BOM indispensable si aplasie ou fibrose » (p. 15-16) ; seul le repère de la fourchette sternale, pour la proposition B, vient du ronéo 2024-25. |
| `hem-rv-portee` | Ce que le myélogramme montre et ne montre pas (progéniteurs, tests fonctionnels) : disparu ; le ronéo dit seulement « hémogramme = NFS, myélogramme = étude de la moelle » (p. 2). |
| `hem-rv-megacaryocytes` | L'orientation d'une thrombopénie par les mégacaryocytes : disparue avec la section « orientation diagnostique ». |
| `hem-rv-petechies` | La définition des pétéchies et du purpura, les gingivorragies et bulles jugales : plus rédigées, mais montrées par la photo de la p. 13. |

**Notes citées sur le ronéo 2024-25 parce que leur réponse exacte, ou la
plupart de leurs clés, n'est pas dans celui de 2026-27**

| Note | Ce qui manque au ronéo 2026-27 | Ce qu'il garde |
|---|---|---|
| `hem-qr-seuils-plaquettes` | Le seuil de 80 G/L avant une chirurgie lourde ; la QROC demande quatre seuils | 150, 50 et 20 G/L, fond d'œil sous 20 (p. 13) |
| `hem-qr-hemodilution` | L'insuffisance cardiaque de la réponse exacte (ronéo 2024-25 et diapositive) ; le pic monoclonal IgM de la réponse (diapositive seulement : tag `a-relire`) | Splénomégalie (en gris) et hyperprotidémie (p. 9) |
| `hem-qc-lymphopenie-causes` | B à E : corticoïdes et immunosuppresseurs, causes bactériennes, Hodgkin, déficits congénitaux (ronéo 2024-25 et diapositive) | « RETENIR : le VIH » (p. 9), la proposition A |

**Propositions isolées, dans des cartes relues par ailleurs**

| Note | Proposition | Pourquoi |
|---|---|---|
| `hem-qc-reactionnel` | A (« environ 80 % réactionnelles »), et la raison de D (« exceptionnelles ») | Le ronéo 2026-27 ne chiffre plus ; il marque les anomalies réactionnelles « +++ » (p. 4). |
| `hem-qc-lymphocytose` | C (« lymphocytes T activés ») | Le ronéo 2026-27 dit « atypiques, de grande taille, hyperbasophiles » (p. 6), sans « T ». |
| `hem-fa-mononucleosique` | c4 (« T ») | Même point. |
| `hem-qc-anemie-def` | E (nouveau-né 22 g/dL, 11 à six mois) | Le ronéo 2026-27 dit seulement « enfant, selon l'âge » (p. 9). |
| `hem-qc-anemie-tolerance` | B (palpitations → transfusion), C (respecter la tachycardie) | La transfusion n'est plus abordée ; tachycardie et palpitations restent des signes (p. 10). |
| `hem-qc-polyglobulie` | E (ne pas corriger une polyglobulie d'adaptation) | Le ronéo 2026-27 ne parle pas de traitement. |
| `hem-qc-thrombopenie` | D (pétéchies confluentes → purpura) | Photo seulement (p. 13). |
| `hem-qc-mecanismes` | C (mégacaryocytes), exemples de E (réanimation, serpent, post-partum) | Le ronéo 2026-27 donne les cinq mécanismes sans orientation ni exemples (p. 13). |

**Absentes du ronéo 2026-27, présentes dans le ronéo 2024-25** (et, pour la
plupart, sur les diapositives du 18/09, qui sont du cours 2026-27) :

- `hem-qc-la-infiltrations` A (adénopathies, splénomégalie, hépatomégalie) et
  B pour la peau ; le ronéo 2026-27 ne cite que SNC, testicules et hypertrophie
  gingivale (p. 7).
- L'explication de `hem-rv-lymphopenie` (les causes autres que le VIH).
- `hem-qc-anemie-def` D : l'insuffisance cardiaque ; le ronéo 2026-27 cite
  splénomégalie et hyperprotidémie (p. 9).
- `hem-rv-neutropenie-anoter` : le détail de la neutropénie cyclique
  (autosomique dominante, 1/1 000 000, tous les 21-30 jours) ; le ronéo 2026-27
  la cite seulement, en gris (p. 8).

**Portées par les diapositives du 18/09 seulement** — du cours 2026-27, mais
dans aucun des deux ronéos ; la relecture du 25/09 n'a pas eu les diapositives
sous les yeux :

- `hem-qc-la-infiltrations` D (LAM4, LAM5) et le mot « sanctuaires » de la
  justification de B — tag `a-relire`.
- `hem-qr-hemodilution` : le pic monoclonal IgM de la réponse — tag `a-relire`.
- `hem-qc-thrombocytose-causes` A et B, « à retenir en premier » (imprimées en
  rouge sur la diapositive ; le ronéo cite les infections d'abord, sans
  hiérarchie, p. 14), et C, « les causes secondaires dominent » (le ronéo ne
  chiffre pas leur fréquence) — tag `a-relire`.
- `hem-qc-neutropenie-mecanismes` B : la moelle « riche » de la production
  inefficace ; le ronéo dit des cellules « de moins bonne qualité, qui meurent
  plus vite » (p. 8), et une « moelle +/- riche avec dysplasie » au myélogramme
  d'une pancytopénie (p. 15), ce qui suffit à la clé.
- `hem-qc-thrombopenie-risque` C : l'âge et les lésions qui peuvent saigner ;
  le ronéo cite le « terrain : maladies vasculaires » (p. 13), ce qui suffit à
  la clé.
- `hem-qc-agranulocytose` C : les aphtes ; le ronéo s'arrête à « (angines…) »
  (p. 9), ce qui suffit à la clé. Et la justification de B cite l'ancienne
  conduite de la diapositive, arrêt de tous les médicaments non indispensables.
- Des accents seulement, sur un contenu que le ronéo porte : la coqueluche en
  rouge (`hem-qc-lymphocytose-causes` D, p. 6), le point d'exclamation sur le
  VIH (`hem-qc-lymphopenie-causes` A, p. 9).

## À relire : 3 cartes

Trois notes portent le tag `a-relire` (`A_RELIRE` en fin de `donnees.py`) :
`hem-qc-la-infiltrations`, `hem-qc-thrombocytose-causes`,
`hem-qr-hemodilution`. Une de leurs clés ou de leurs réponses ne se lit que sur
les diapositives du 18/09 (voir juste au-dessus). Le tag se retire à la
relecture des diapositives, jamais avant. Les notes citées sur le ronéo 2024-25
ne le portent pas : elles ont été vérifiées page à page sur lui.

## L'arbre d'orientation devant une anémie

Redessiné nu dans `schemas.py` — sept boîtes à cliquer, aucun mot dessus, seule
leur place dit ce qu'elles sont. C'est la démarche du cours (p. 10-11) :

1. **le VGM d'abord.** Une microcytose (< 80 fL) est *toujours* centrale :
   carence martiale, anémie inflammatoire ou anomalie de synthèse de
   l'hémoglobine, et le premier paramètre est la **ferritine** — basse dans la
   carence, haute dans l'inflammation ;
2. **les réticulocytes ensuite**, si l'anémie n'est pas microcytaire.
   Augmentés, la moelle compense et la destruction est ailleurs — anémie
   régénérative, périphérique ; diminués, elle n'arrive pas à répondre — cause
   centrale. Le ronéo 2026-27 ne donne plus de seuil chiffré.

## Deux décisions de programme, tenues

- **Les stades de maturation ne sont pas cartés** — décision de Vincent pour
  toute l'UE, et c'est ici qu'elle compte le plus : le cours 2026-27 cite
  myélocytes et métamyélocytes à la myélémie, qu'il marque « à connaître »
  (p. 5), et le blocage « au stade de promyélocytes » de l'agranulocytose
  (p. 9). Aucune carte ne demande de les nommer ni de les ordonner depuis la
  réécriture du trou c2 de `hem-fa-agranulocytose` ; la LAM3 se carte sans le
  nom du précurseur. La myélémie et le blocage de maturation sont cartés comme
  des **concepts**.
- **Le détail des facteurs de transcription** n'est pas carté. Une seule ligne
  reste, dans `hem-an-2324-q4` : ils agissent sur l'ADN, quand l'EPO agit sur
  un récepteur de surface. La justification C de la même annale dit seulement
  que l'hypoxie active la transcription du gène de l'EPO, sans décrire ni
  nommer le facteur en cause — le HIF, que nomme le ronéo 2026-27 des cellules
  matures (p. 3) ; la question est posée à Vincent.

Les deux exclusions que le ronéo 2024-25 posait lui-même — les causes rares de
polyglobulie, « pas interrogés sur ces causes ! », et la neutropénie cyclique,
« pas d'intérêt d'après le prof » — **ne tiennent plus** : le cours 2026-27 ne
les écarte pas. Les explications listent donc les causes de polyglobulie de la
figure de la p. 12.

## Ce que les annales visent

Sept questions seulement, mais **trois portent sur les polyglobulies** — la
distinction fausse / primitive / secondaire, et les deux mécanismes de la
secondaire. C'est proportionnellement le sujet le plus rentable du fascicule.
Les trois QROC sont regroupées avec les QCM : ce polycopié en pose, contrairement
à ceux de sémiologie.

La question à réponse unique de 2020/2021 ne déclare aucune proposition
« inacceptable » : sur un QRU, toute autre lettre vaut déjà zéro — les interdire
n'ajouterait rien et ne laisserait aucune lettre libre.

## Illustrations : à décider

Avant l'échelle, une seule des 39 questions à choix était illustrée, l'annale de 2023/2024 sur la
définition des polyglobulies (figure du ronéo 2026-27, p. 12 ; objectif de la
règle 3 : la moitié), et le hook le rappelle à chaque écriture. Le chapitre pourrait
l'atteindre sans figure du ronéo, avec des schémas redessinés légendés — l'arbre
de l'anémie en version légendée pour la correction, l'arbre du myélogramme
devant une pancytopénie, les seuils de neutropénie et de plaquettes sur une
échelle. La relecture du 25/09 (C3) ne les a pas faits : la question est posée à
Vincent, et il n'y a donc pas de section « Sans illustration ». Depuis le 16/10, les
16 marches de l'échelle portent le schéma `ech-hemogramme` : 17 questions à choix
illustrées sur 55 (31 %).

## Les sujets du dépôt du 15/10/2026

Deux annales de plus : le chapitre en compte 9, sur 7 sessions.

- **2023/2024, QCM 10** (`hem-an-2324-q10`), la définition d'une polyglobulie.
  Absente du polycopié, elle garde la source de session en place (le polycopié)
  et le dit ; sa page du ronéo 2026-27 (p. 12, `PAGES_2026`) est sa source
  secondaire, et sa figure, l'orientation devant une polyglobulie, illustre la
  correction.
- **2024/2025, QCM 6** (`hem-an-2425-q6`), myélogramme et biopsie
  ostéo-médullaire. La session cite le sujet (`src-sujets-sang-2425`, par
  `SRC["sessions"]`). Pas de page 2026-27 : les items D et E ne se lisent que
  dans le ronéo 2024-25 du Pr Terriou (p. 22).

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2023/2024, QCM 10 C (`hem-an-2324-q10`) — « un taux d'hémoglobine supérieur à 16 g/dl chez la femme » | CE (grille officielle) ; surlignée : CE | **CE**, clé officielle reprise | le ronéo écrit « > 17,5 g/dL chez la femme » (2026-27 p. 12, et déjà 2025-26 et 2024-25) ; 16 g/dL est le seuil de référence — OMS 2016 (Arber et al., *Blood* 2016) et consensus de la Société française d'hématologie (UMVF, item 165) — et le ronéo dit ces valeurs « à ne pas connaître ». `ATTENTION (cours)` sur C, entrée `CONFLITS` |
| 2024/2025, QCM 6 (`hem-an-2425-q6`) | aucune (sujet sans corrigé) ; surlignée : D | **CE** | C : diagnostic de leucémie aiguë au myélogramme (2026-27 p. 7) ; D : le myélogramme n'a « aucune contre-indication », E : la biopsie exige 50 G/L de plaquettes (2024-25 p. 22). Trois `ATTENTION —`, trois entrées `CONFLITS` |

**Une erreur du cours lui-même, portée dans la liste des erreurs** : le seuil
féminin de la polyglobulie, « 17,5 g/dL », dans les trois ronéos de ce cours,
alors que la grille officielle de l'examen 2023/2024 compte juste 16 g/dL, le
seuil de l'OMS. Trois cartes portent l'`ATTENTION (cours)`, avec « À l'examen : »
et « La référence : » : `hem-an-2324-q10` (C), `hem-qc-polyglobulie` (A) et
`hem-fa-polyglobulie`, dont le trou c2 garde le chiffre du cours.

**La correction surlignée (officieuse).** Les sujets du dépôt portent des
réponses surlignées en bleu, posées en annotation sur le PDF après coup et
d'origine inconnue : ce n'est ni une grille ni un corrigé de la faculté, et elle
n'est pas déclarée comme source. Sur 2023/2024, elle reproduit la
grille officielle, sauf au QCM 9, où elle ajoute D. Sur 2024/2025, elle sert de
seconde opinion : quand la clé déduite du cours coïncide, l'explication le dit ;
quand elle diffère et que le cours tranche, la carte suit le cours, et l'item
en cause porte un `ATTENTION —` et une entrée `CONFLITS`. Les surlignages des
QROC 2024/2025 ne marquent que l'énoncé et n'apportent rien.

**2023/2024.** Clés confirmées par la grille officielle (dépôt du 15/10/2026) :
le QCM 4 (`hem-an-2324-q4`, CE), et le QCM 10, carté le 15/10
(`hem-an-2324-q10`, CE). À la Q9 de ce sujet, seul le surligneur ajoute D, la
grille dit AE.

## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026)

L'échelle du pilote de l'immunité innée, étendue au tissu sanguin et aux trois derniers chapitres de sémiologie pour l'examen du 4/11 (Vincent, 16/10 : « on continue pour les chapitres que je vais avoir à l'examen »). Sous les annales, 12 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 4 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `anemies` | 5 | 1 | 3 |
| `polyglobulies` | 4 | 2 | 5 |
| `myelogramme` | 3 | 1 | 1 |

**Le schéma** `ech-hemogramme`, « L'hémogramme · la lignée rouge, puis la moelle », donne 23 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_HEMOGRAMME`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**La source.** Les marches citent la ronéo 2026-27 (`SRC["fiche"]`) ; le Ronéosaure 2024-25 sert d'appoint, nommé par `fiche=` quand un fait n'est que là, et la FC 2025-26 de contre-épreuve.

**Le générateur.** Depuis le 16/10, `generer.py` est la copie exacte du modèle du skill : le bloc « le générateur modèle » en fin de `donnees.py` déclare les sources dans `SRC` et range les QROC d'annales dans `ANNALES_QROC`, officielles comme avant. Le paquet est resté le même, à trois écarts voulus près (indentation, champs par défaut des cartes à zones, légende du média du schéma cliquable), plus le tag d'année `cours-2026-27` ou `cours-2024-25` sur les cartes de cours).

**ATTENTION posés** : la correction surlignée officieuse du sujet 2024/2025 contre le cours sur le myélogramme et la BOM (QCM 6 C, D, E : s10, s11, s12, m4). La microcytose se rattache ici au fer ; le chapitre des anémies y ajoute la thalassémie (s3, m3). La microcytose « toujours centrale » de la ronéo devient, dans m3, « carentielle ou inflammatoire » : la littérature excepte la thalassémie (Lhomme et Lamy, Rev Prat 2020 ; Vincent, 17/10 : la littérature fait foi).

**Sans marche** :
- hem-an-2324-q4 A, B, E (l'EPO facteur de croissance et non de transcription, produite surtout par le rein, agissant par un récepteur) : enseignés par les ronéos « Les cellules matures du sang » (p. 3-4) et « Cellules souches » (p. 8), pas par celui de ce chapitre ; côté cellules souches, sso-ech-s17 et sso-ech-m7 préparent l'opposition ADN / récepteur
- hem-an-2021s2-q4 D, E (CCMH, TCMH) : absents des ronéos 2026-27 et 2024-25 La CCMH < 32 g/dL de l'hypochromie est enseignée dans sang_anemies (ane-ech-s18).
- hem-an-2324-q10 B, C, D (seuils de l'hématocrite et de l'hémoglobine féminine) : le cours les dit « à ne pas connaître » (p. 12), et le seuil féminin est en conflit (CONFLITS : 17,5 g/dL du cours contre 16 de la grille) ; aucune marche ne l'écrit, selon la règle 11
- hem-an-2425-q6 A (myélogramme et CSH) : le ronéo 2026-27 de ce cours ne le dit pas ; les CSH « non identifiables morphologiquement » sont enseignées par le ronéo des cellules souches (p. 5), dont le schéma ech-hematopoiese porte la case
- hem-an-2021s1-q6 E (test de Coombs) : absent des ronéos 2026-27 et 2024-25 ; la QRU se joue sur D, que hem-ech-s3 prépare, et la lettre E se pose sur la case des anémies régénératives

## Régénérer

```
python generer.py
```

Le script écrit d'abord le SVG, puis valide : une justification manquante, un
trou de plus de deux mots, deux zones qui se recouvrent, un thème qui ne porte
qu'une carte, une page hors du ronéo 2026-27 — et il refuse d'écrire.
`donnees.py` refuse lui-même de se charger si `PAGES_2026` ou `A_RELIRE` cite
une note inconnue ; une note de `A_RELIRE` porte le tag `a-relire`.
