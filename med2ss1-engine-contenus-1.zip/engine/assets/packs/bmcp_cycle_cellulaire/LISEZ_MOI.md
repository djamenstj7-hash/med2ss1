# Cycle cellulaire : oncogènes et gènes suppresseurs de tumeurs — paquet BMCP

110 notes, 176 cartes. Chapitre `chap-ue-bmcp-fc9` de l'UE BMCP, neuvième de
l'UE. Cours du **Pr Nicolas Germain, le 13/10/2025, de 9 h à 11 h**, dans le
**Ronéosaure 2025-26** (FC n°9, 23 pages) ; les annales de trois polycopiés du
Ronéosaure 2024-25 et le sujet de 2024/2025, sans corrigé (20 sessions citées). Examen : mardi 5 janvier 2027.

**Fiche provisoire** (C16, décision de Vincent du 02/10) : le cours de l'année
2026-27 n'est pas encore paru. Chaque carte de cours cite la FC 2025-26 à sa
page, et porte le badge « Cours 2025-26 » (l'auteur de la source dit l'année) ;
le ronéo 2026-27 la corrigera quand il sortira.

**Le brouillon du 03/10.** Le dossier ne contenait que `media/`, 35 figures
extraites par la passe interrompue. Chacune a été regardée et rapportée à sa
page : toutes sont des figures du cours, juste recadrées, et toutes sont
gardées ; trois n'illustrent aucune carte et partent pour la lecture (la souris
p27−/−, p. 8 ; les points de contrôle de p53, p. 18 ; les mutations de p53 par
tissu, p. 19). S'y ajoutent la figure des poisons du fuseau (p. 20,
`ccl-poisons-fuseau.png`, qui dit « mort mitotique »), la planche numérotée
(`ccl-voie-prb-numerotee.png`) et les trois schémas de `schemas.py`. Tout le
reste — données, annales, schémas, lexique — est écrit dans cette passe.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 52 | 52 |
| Texte à trous | 14 | 73 |
| QROC | 18 | 18 |
| Recto-verso | 14 | 14 |
| Lexique | 9 | 9 |
| Schéma cliquable | 2 | 9 |
| Planche à légender | 1 | 1 |

Dont **42 annales** sur 20 sessions : 28 QCM des polycopiés (25 du BMCP 9, deux du
BMCP 11, un du BMCP 13), le QROC 2 de 2023/2024 en trois sous-questions
(corrigé imprimé) et les quatre QROC du western blot de 2021/2022 S1 (sans
corrigé) ; et, du sujet de 2024/2025 (examen du 09/01/2025, sans corrigé, déposé le
15/10/2026), les Q. 7 et Q. 8 et le QROC 3 — le cas de Mme Octobre — en cinq cartes. Les QCM de cours sont 22, dont quatre questions corrigées par le
professeur dans le ronéo (QCM p. 8, questions p. 12, 13-14, wooclap p. 17),
marquées clé officielle. **Les 52 QCM sont illustrés** ; les deux qui portent
sur les niveaux de régulation (2016/2017 S2 Q. 14, BMCP 13 Q17) le sont par les
courbes des cyclines (p. 6), qui montent et s'effondrent à chaque cycle.

Six thèmes, dans l'ordre du cours ; les six clés sont **nouvelles**, et leurs
libellés sont dans `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) depuis l'intégration du 05/10 :

| Clé | Libellé | Notes |
|---|---|---|
| `phases-cycle` | Phases du cycle et points de contrôle | 12 |
| `cdk-cyclines` | Complexes CDK-cycline et CKI | 25 |
| `voie-prb` | Point de restriction et voie pRB | 19 |
| `virus-oncogenes` | Virus oncogènes et dérégulation du cycle | 8 |
| `points-surveillance` | Points de surveillance : lésions de l'ADN et fuseau | 18 |
| `oncogenes-gst` | Oncogènes et gènes suppresseurs de tumeurs | 19 |

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-bmcp-ccl-2526` — Ronéosaure, « FC n°9 Cycle cellulaire » (23 p.) | 2025-26 | le cours ; `SRC["fiche"]`, ses figures ; fiche provisoire |
| `src-annales-bmcp-9-cycle-cellulaire-role-et-implications-cliniques-des-oncogenes-et-des-genes-suppresseurs-de-tumeurs` — « BMCP 9 - Cycle Cellulaire _ Rôle et Implications Cliniques… » | 2024-25 | 16 sessions, 25 QCM et 5 QROC ; tables p. 10-11 |
| `src-annales-bmcp-11-tests-biologiques-en-medecine-personnalisee` — « BMCP 11 - Tests biologiques en médecine personnalisée » | 2024-25 | 2 QCM de GST ; table p. 6 |
| `src-annales-bmcp-13-signalisation-et-recepteurs` — « BMCP 13 - Signalisation et récepteurs » | 2024-25 | 1 QCM (2019/2020 S2 Q17) ; la copie de 2018/2019 S1 Q16 |
| `src-sujets-bmcp-2425` — « Sujets de BMCP 2024/2025, session 1 » (30 p.) | 2024-25 | le sujet de l'examen du 09/01/2025, **sans corrigé** (dépôt `Annales_15102026/`, 15/10/2026) : Q. 7, Q. 8 et QROC 3 ; `SRC["sessions"]["2024/2025 S1"]` ; déclaré à l'identique dans tous les chapitres de BMCP qui en cartent une question |

Le QROC 3 du sujet 2024/2025 est le cas de **l'ED n°1 de biologie cellulaire** du
Ronéosaure 2025-26 (« ED n°1 Biocell », 10 p.), qui le recopie à sa dernière page sans
corrigé (p. 10) : ses cinq cartes citent l'ED à la page, sans qu'il soit déclaré en
source (aucune carte de cours n'en est tirée), comme l'ED n°2 de 2024-25 (« diagnostic
du cancer du sein », p. 2).

Les trois polycopiés sont déclarés avec **exactement** les champs que la
consigne C16 fixe (id, kind, titre, chemin_relatif, auteur), pour que les
chapitres écrits en parallèle (sénescence, tests biologiques, signalisation)
les déclarent à l'identique. Les noms de fichiers du BMCP 9 et du BMCP 11 sont
en NFD sur le disque : ils sont recopiés en NFC.

Les trois questions des BMCP 11 et 13 partagent leur session avec des questions
du BMCP 9 ; le générateur choisit la source par session : elles portent
« 2021/2022 S1 (BMCP 11) », « 2019/2020 S1 (BMCP 11) », « 2019/2020 S2
(BMCP 13) » (convention de `genet_chromosomes`).

Les pages citées sont celles du PDF ; les p. 17 à 23 sont imprimées « 2 » à
« 8 ». Lus en appoint, sans être déclarés : le cours 2024-25 du même professeur
(Ronéosaure, FC n°9) et les deux cours 2023-24 (Charonéo, « Le cycle
cellulaire » et « Oncogènes et gènes suppresseurs de tumeur »), cités page à
page dans les justifications ; l'errata des cours 2025-26 (une entrée pour
cette FC : ATM et ATR inversés, p. 18) et celui des annales (rien pour ces
polycopiés). Aucun nom d'étudiant n'est repris des en-têtes, des polycopiés ni
des erratas.

## Ce que le cours a dicté

- **Ce qu'il a dit de retenir** a sa carte : le complexe CDK-cycline (« insiste
  sur le fait de bien le retenir », p. 4) ; l'« A RETENIR » de la p. 10 (PSTAIRE,
  cyclin box, phosphorylations activatrices ou inhibitrices, trois points de
  contrôle, point R) et de la p. 11 (pRB, protéine suppresseur de tumeur) ; la
  « partie importante à connaître ++ » de la p. 22 (oncogène et GST,
  gatekeepers et caretakers). Le rouge du ronéo (phases, signaux en G1, trois
  points de contrôle, CDK = kinase dépendante des cyclines, deux familles de
  CKI, point R) est carté.
- **Ce qu'il a dit de laisser**, sans carte : les types de CDK et de cyclines de
  chaque phase (p. 5), les régulations post-traductionnelles de détail (p. 6),
  chaque CKI de chaque famille (p. 7), les effecteurs (p. 18), la régulation de
  p53 par MDM2 (p. 19). Les annales qui en parlent (p57, cycline B, CDC25C,
  wee1) se justifient sur le cours 2023-24.
- **Le gris** est la voix des rédacteurs : carté (wooclaps, questions).
- **Les questions du professeur** reprises en QCM de cours, clé officielle :
  le QCM p. 8 (six propositions ; la cinquième, PSTAIRE, laissée aux annales),
  « qu'est-ce qu'un GST » (p. 12), « proto-oncogène » (p. 13-14), le wooclap des
  virus (p. 17). La question d'INK4 (p. 15) est complétée en QCM de cinq. Le quiz
  p. 16-17 et le wooclap récapitulatif p. 21 reprennent mot pour mot les annales
  2021/2022 S1 Q. 14 et Q. 15 : pas de carte en double, l'annale cite le corrigé.
- **Aucune photographie de patient** : celle du sarcome de Kaposi (p. 14) n'est
  pas reprise ; la carte du Kaposi est illustrée par le tableau des protéines
  virales.
- **Ce qui n'est pas carté ici** (plan C16) : la sénescence et les télomères
  (`bmcp_senescence`), l'imatinib et les thérapies ciblées (FC n°11), le test
  compagnon HER2 et le trastuzumab (FC n°12). Les cartes les citent.

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| PSTAIRE : des CDK, pas des cyclines | 2023/2024 Q. 8 ; 2021/2022 S1 Q. 14 ; 2021/2022 S2 Q. 3 ; 2020/2021 S1 Q. 20 ; 2020/2021 S2 Q. 23 ; 2018/2019 S1 Q. 16 ; 2018/2019 S2 Q. 18 ; 2017/2018 S2 Q. 12 ; 2016/2017 S1 Q. 13 ; 2015/2016 S1 Q. 19 |
| Les cyclines activent les CDK ; phosphorylations activatrices et inhibitrices | 2021/2022 S2 Q. 3 ; 2020/2021 S1 Q. 20 ; 2020/2021 S2 Q. 23 ; 2019/2020 S1 Q. 18 ; 2018/2019 S1 Q. 16 ; 2017/2018 S1 Q. 12 et S2 Q. 12 |
| pRB, pas P53, au point R ; deux vagues, deux complexes | 2023/2024 Q. 9 ; 2022/2023 Q. 3 ; 2020/2021 S1 Q. 20 ; 2020/2021 S2 Q. 23 ; 2019/2020 S1 Q. 18 et S2 Q. 18 ; 2018/2019 S1 Q. 16 et S2 Q. 18 ; 2017/2018 S1 Q. 12 et S2 Q. 12 ; 2015/2016 S2 Q. 19 |
| p16 ne bloque que les cyclines D ; CIP/KIP, complexe ternaire | 2021/2022 S2 Q. 4 ; 2020/2021 S2 Q. 23 ; 2019/2020 S2 Q. 18 ; 2018/2019 S1 Q. 16 et S2 Q. 18 ; 2017/2018 S1 Q. 12 et S2 Q. 12 |
| Perte du point R, cycline D1, virus | 2023/2024 Q. 9, Q. 10, QROC 2 ; 2020/2021 S1 Q. 21 ; 2019/2020 S1 Q. 18 ; 2016/2017 S1 Q. 14 ; 2015/2016 S2 Q. 19 |
| p53, ATM, CDC25C, le western blot | 2024/2025 Q. 7 ; 2021/2022 S1 Q. 15 et QROC 1-4 ; 2021/2022 S2 Q. 4 ; 2020/2021 S2 Q. 23 ; 2019/2020 S2 Q. 18 ; BMCP 11 2019/2020 Q19 |
| APC/C, Bub1, aneuploïdie | 2022/2023 Q. 3 ; 2021/2022 S1 Q. 15 ; 2017/2018 S2 Q. 13 ; 2016/2017 S2 Q. 15 |
| Le cas de Mme Octobre (ED n°1) : biopsie, index Ki67, cytométrie en flux ou immunohistochimie, HER2 et récepteurs hormonaux | 2024/2025 QROC 3 (a à d) |
| GST et oncogènes, cancérogenèse | 2024/2025 Q. 8 ; 2023/2024 Q. 10 ; 2020/2021 S2 Q. 24 ; BMCP 11 2021/2022 Q17 et 2019/2020 Q19 |

### Les 36 questions

| Polycopié | Session | N° | Clé imprimée | Retenu | Carte |
|---|---|---|---|---|---|
| sujet 2024/2025 | 2024/2025 S1 | Q. 7 | aucune (sans corrigé) | BCE, déduite | `ccl-an-2425s1-q7` |
| sujet 2024/2025 | 2024/2025 S1 | Q. 8 | aucune (sans corrigé) | CE, déduite (`a-relire`) | `ccl-an-2425s1-q8` |
| sujet 2024/2025 | 2024/2025 S1 | QROC 3 (a à d) | aucune (sans corrigé) | biopsie ; index Ki67 ; cytométrie en flux ; immunohistochimie ; HER2, RE, RP | `ccl-anq-2425s1-qroc3a`, `…3b`, `…3c1`, `…3c2`, `…3d` |
| BMCP 9 | 2023/2024 S1 (« 2023/2025 ») | Q. 8 | BE | BE | `ccl-an-2324s1-q8` |
| BMCP 9 | 2023/2024 S1 | Q. 9 | ABDE | ABDE | `ccl-an-2324s1-q9` |
| BMCP 9 | 2023/2024 S1 | Q. 10 | BCDE | BCDE | `ccl-an-2324s1-q10` |
| BMCP 9 | 2023/2024 S1 | QROC 2 (1-3) | voie pRB ; un facteur de croissance ; libération de E2F | idem, et « la phosphorylation de pRB » acceptée au 2) | `ccl-anq-2324s1-qroc2a`, `…2b`, `…2c` |
| BMCP 9 | 2022/2023 S1 | Q. 3 | pas de correction | DE (déduite) | `ccl-an-2223s1-q3` |
| BMCP 9 | 2021/2022 S1 | Q. 14 | BC | BC | `ccl-an-2122s1-q14` |
| BMCP 9 | 2021/2022 S1 | Q. 15 | BCE | BCE | `ccl-an-2122s1-q15` |
| BMCP 9 | 2021/2022 S1 | QROC 1-4 | aucune correction | versos déduits | `ccl-anq-2122s1-qroc1` à `…4` |
| BMCP 11 | 2021/2022 S1 | Q17 | BCDE | BCDE | `ccl-an-2122s1-bmcp11-q17` |
| BMCP 9 | 2021/2022 S2 (en-tête « 2020/2021 S2 ») | Q. 3 | AC | AC | `ccl-an-2122s2-q3` |
| BMCP 9 | 2021/2022 S2 (idem) | Q. 4 | BCDE | BCDE | `ccl-an-2122s2-q4` |
| BMCP 9 | 2020/2021 S1 | Q. 20 | pas de correction | BC (déduite) | `ccl-an-2021s1-q20` |
| BMCP 9 | 2020/2021 S1 | Q. 21 | pas de correction | ABCDE (déduite) | `ccl-an-2021s1-q21` |
| BMCP 9 | 2020/2021 S2 | Q. 23 | ABD | ABD | `ccl-an-2021s2-q23` |
| BMCP 9 | 2020/2021 S2 | Q. 24 | BCDE | BCDE | `ccl-an-2021s2-q24` |
| BMCP 11 | 2019/2020 S1 | Q19 | (A)BCDE | ABCDE, non officielle | `ccl-an-1920s1-bmcp11-q19` |
| BMCP 9 | 2019/2020 S1 | Q. 18 | ADE | ADE | `ccl-an-1920s1-q18` |
| BMCP 13 | 2019/2020 S2 | 17 | pas de correction | CDE (déduite) | `ccl-an-1920s2-bmcp13-q17` |
| BMCP 9 | 2019/2020 S2 | Q. 18 | pas de correction | DE (déduite) | `ccl-an-1920s2-q18` |
| BMCP 9 (et BMCP 13, même question) | 2018/2019 S1 | Q. 16 | AD | AD | `ccl-an-1819s1-q16` |
| BMCP 9 | 2018/2019 S2 | Q. 18 | D | D | `ccl-an-1819s2-q18` |
| BMCP 9 | 2017/2018 S1 | Q. 12 | AB | AB | `ccl-an-1718s1-q12` |
| BMCP 9 | 2017/2018 S2 | Q. 12 | C | C | `ccl-an-1718s2-q12` |
| BMCP 9 | 2017/2018 S2 | Q. 13 | BCE | BCE | `ccl-an-1718s2-q13` |
| BMCP 9 | 2016/2017 S1 | Q. 13 | BCDE | BCDE | `ccl-an-1617s1-q13` |
| BMCP 9 | 2016/2017 S1 | Q. 14 | ACDE | ACDE | `ccl-an-1617s1-q14` |
| BMCP 9 | 2016/2017 S2 | Q. 14 | ABCDE | ABCDE | `ccl-an-1617s2-q14` |
| BMCP 9 | 2016/2017 S2 | Q. 15 | ABCDE | ABCDE | `ccl-an-1617s2-q15` |
| BMCP 9 | 2015/2016 S1 | Q. 19 | ABDE | ABDE | `ccl-an-1516s1-q19` |
| BMCP 9 | 2015/2016 S2 | Q. 19 | colonne vide | ABCDE (déduite) | `ccl-an-1516s2-q19` |

**Hors du cours 2025-26**, reprises comme la clé et justifiées sur le cours
2024-25, le cours 2023-24 ou une source nommée : sérine/thréonine kinases,
demi-vies de l'ARNm et de la protéine, cycline B et télophase, boucle CDK1 →
CDC25C / wee1, p34cdc2 humaine (Lee et Nurse 1987), Hanahan et Weinberg,
RAS-GTP, domaine de liaison à l'ADN de p53, mutations « signatures » de p53,
aflatoxine B1 et benzopyrène (CIRC), dimères de pyrimidine, psoriasis et voie
pRB (Mol Med Rep 2018 ; Clin Exp Dermatol 2010), Beckwith-Wiedemann et p57
(Hatada 1996), Tax du HTLV-1 et MAD1 (Jin 1998), PTEN, E2F-DP1, sous-unités des
protéines G et arrestine (FC n°14).

## Les erreurs du ronéo 2025-26

Le Ronéosaure n'est pas le ronéo de l'année : chaque erreur est portée par un
**ATTENTION nu** dans la carte qui tient la notion, la sorte dite dans le texte,
et rien n'entre dans `contenu/ERRATA_RONEOS_2026-27.md`.

| Page | Le ronéo dit | Retenu | Sorte | Carte |
|---|---|---|---|---|
| 3 | pour sortir de quiescence, des « signaux de croissance (facteurs de croissance, TGFβ) » | le TGFβ inhibe la prolifération : la diapositive de la même page le met dans « Fail » du point G1 tardif ; cours 2023-24, p. 4 | prise de notes (trouvée en relisant) | `ccl-qc-points-controle` B |
| 5 | mutant wee1 : « les répresseurs des CDK/cyclines […] p21, p16 ou encore p27 » ; mutant cdc25 : « le complexe CDK/cycline qui est muté » | wee1 est la kinase qui inhibe CDK1 (petites cellules), cdc25 la phosphatase qui l'active (grandes cellules) — figure p. 6, cours 2024-25 p. 4 | point douteux (plan C16) | `ccl-qc-levures` C, D ; `ccl-rv-wee1-cdc25` ; annales 2021/2022 S2 Q. 4 B, 2020/2021 S1 Q. 21 A |
| 6 | « La Cycline = la partie activatrice du complexe CDK = portent la partie catalytique » | la cycline est régulatrice, la CDK catalytique (p. 7, diapositive p. 4) | prise de notes | `ccl-fa-cdk`, `ccl-qc-cdk-cycline` A, `ccl-rv-catalytique`, `ccl-an-2324s1-q8` A |
| 7 | « Les CDK sont nombreux et diffèrent par leurs cibles… », sous le titre des CKI | ce sont les CKI (cours 2024-25, p. 5) | prise de notes (trouvée en relisant) | `ccl-qc-cki` (explication) |
| 13 | proto-oncogène : « comme il s'agit d'une mutation perte de fonction, il suffit qu'un seul des allèle… » | gain de fonction (p. 12, 13, 22) ; la conclusion est juste | prise de notes | `ccl-qc-quiz-proto-oncogene` C |
| 18 | « cassure simple brin … ATM ; double brin … ATR » | l'inverse : ATR-CHK1 simple brin et fourches bloquées, ATM-CHK2 double brin ; le paragraphe suivant et la figure le disent ; errata de la promo, non corrigé | prise de notes | `ccl-qc-surveillance` C, `ccl-rv-atm-atr`, annales BMCP 11 2019/2020 Q19 E et 2019/2020 S2 Q. 18 E |
| 19 | « CDK1/cycline D » à la transition G2/M | CDK1/cycline B (figure de la même page) | prise de notes | `ccl-qc-g2m` D |
| 20 | « une orientation vers la bande mitotique » | la mort mitotique (figure de la même page) | prise de notes | `ccl-qc-apc` E |
| 21 | Peyton Rous « dans les années 1800 » | 1910-1911 (déjà « vers les années 1800 » dans le ronéo 2024-25, p. 17) | prise de notes ou lapsus repris d'une année sur l'autre | `ccl-qc-oncogenes` B |

Deux imprécisions sans ATTENTION, dites dans l'explication : « DNA-PK (PK =
phospho-kinase) » (p. 17, c'est la DNA-dependent Protein Kinase, comme le ronéo
l'écrit p. 18 : `ccl-fa-surveillance`) ; p53 « nommée ainsi car son poids
moléculaire est de 53 kDa » (sa masse apparente en électrophorèse ; masse
calculée ≈ 44 kDa : `ccl-qc-cki` E). Le ronéo transcrit aussi de travers une
proposition du wooclap p. 17 (C), remise en ordre dans `ccl-qc-wooclap-virus`.

## Les schémas cliquables et la planche

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `cycle-phases.svg` | l'anneau du cycle, nu : G1, S, G2, M, et G0 hors de l'anneau | 5 (`ccl-zo-phases`) |
| `cycle-controles.svg` | l'anneau aux phases nommées, traversé de quatre repères non nommés : point R, contrôle de G1 tardif, de G2 tardif, du fuseau | 4 (`ccl-zo-controles`) |
| `cycle-legende.svg` | la correction des deux : phases et repères nommés | — |
| `ccl-voie-prb-numerotee.png` | la voie pRB de la p. 10, neuf numéros, six intrus (p53, p21, MDM2, CDC25C, cycline B, APC/C) | 1 (`ccl-pl-voie-prb`) |

L'anneau tourne dans le sens des aiguilles d'une montre, comme les roues du
cours ; les arcs ont à peu près la durée relative des phases (G1 la plus
longue, M la plus courte). Les quatre arcs sont séparés d'un blanc de deux
degrés et chaque repère a une zone de douze degrés : aucune zone n'en touche
une autre. Le point R est placé avant le point de contrôle de G1 tardif, et le
point de contrôle du fuseau dans la seconde moitié de M, comme sur les roues
des p. 10 et 18 (« M/G1 checkpoint »). Il n'y a pas de repère « fin de M, pRB
déphosphorylée » : il tomberait à l'endroit même où ces roues tracent le
point de contrôle du fuseau, et un clic juste selon la figure du cours serait
compté faux (relecture du 05/10) ; la déphosphorylation de pRB en fin de M
reste dans `ccl-qc-point-r` C, `ccl-fa-voie-prb` et la légende du schéma. Sur la planche, les cases des complexes CDK-cycline
et les deux autres pRB et E2F sont vidées avec le numéro de leur original : une
légende, un numéro.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| BMCP 11, 2019/2020 S1 Q19 | (A)BCDE | ABCDE, `officielle=False` | A entre parenthèses, sans légende. RAS est surtout activé par mutation ponctuelle, mais son amplification existe (≈ 2 % des cancers, 7,5 % des œsogastriques) et le cours dit « par mutation ou amplification » : A tenue vraie, ATTENTION point douteux, CONFLITS |
| 2023/2024 QROC 2, point 2 | « Un facteur de croissance » | le corrigé, et « la phosphorylation de pRB » acceptée | le cours dit que E7 se lie à pRB « comme s'il était phosphorylé » (p. 12, 17) ; ATTENTION point douteux (une sous-question de QROC ne se déclare pas dans `CONFLITS`) |
| 2022/2023 S1 Q. 3 | pas de correction | DE | clé déduite ; A (pRB et le point de contrôle de G1 tardif) tenue fausse comme le cours, ATTENTION point douteux, CONFLITS |
| 2020/2021 S1 Q. 20 | pas de correction | BC | clé déduite ; les mêmes propositions ont leur clé en 2018/2019 S1 et 2017/2018 S1 |
| 2020/2021 S1 Q. 21 | pas de correction | ABCDE | clé déduite ; A et B ont leur clé en 2021/2022 S2 Q. 4, D en 2019/2020 S1 Q. 18 E |
| 2019/2020 S2 Q. 18 | pas de correction | DE | clé déduite ; D et E ont leur clé ailleurs (2020/2021 S2 Q. 24 C, BMCP 11 Q19 E) |
| BMCP 13, 2019/2020 S2 Q17 | pas de correction | CDE | clé déduite (cours p. 7 ; FC n°14 p. 6 pour l'arrestine) |
| 2015/2016 S2 Q. 19 | colonne vide | ABCDE | clé déduite |
| 2021/2022 S1 QROC 1-4 | « AUCUNE CORRECTION » (trois colonnes pour quatre QROC) | versos déduits du cours | la figure manque au polycopié : le western blot du cours 2025-26 (p. 18), recadré, est l'image de la question |
| 2024/2025 S1 Q. 7 | aucune (sujet sans corrigé) | **BCE**, déduite | A fausse, p53 est un GST (p. 19, 22) ; B, UV et hypoxie (p. 18) ; C, G2/M par 14-3-3σ (p. 19) ; D fausse, ATM et ATR sont des kinases (p. 18) ; E, ATM caretaker (p. 22), « ATR, ATM, p53… ce sont des gènes suppresseurs de tumeur » (cours 2024-25, p. 12) |
| 2024/2025 S1 Q. 8 | aucune (sujet sans corrigé) | **CE**, déduite, `a-relire` | A fausse, HER2 proto-oncogène (p. 23) ; B fausse, l'équivalent normal est le proto-oncogène (p. 14) ; C, la LOH (p. 23) ; **D, la non-disjonction, n'est dans aucun cours** 2023-24 à 2025-26 : retenue fausse sur Cavenee et al. (Nature 1983), ATTENTION, CONFLITS, `a-relire` ; E, Knudson (p. 11) |
| 2024/2025 S1 QROC 3 (a à d) | aucune (sujet sans corrigé) | réponses déduites de l'ED n°1 de biologie cellulaire 2025-26 | biopsie (p. 2-3) ; Ki67, que l'ED appelle aussi « index mitotique » (accepté) (p. 5-7) ; cytométrie en flux pour une tumeur liquide, immunohistochimie pour une tumeur solide (p. 4, 6-7) ; HER2 (IHC, FISH), RE et RP (p. 7-10). La d) porte un ATTENTION nu : l'ED range Mme Octobre (RE−, RP−, HER2+) parmi les « luminales B » (p. 9), contre son propre tableau (p. 8) |

Les conflits déclarés (`CONFLITS`, 8) : la proposition hors cours du sujet
2024/2025 (Q. 8 D), les deux propositions ci-dessus qui
portent un doute (2022/2023 Q. 3 A, BMCP 11 Q19 A) et cinq propositions justes
que le ronéo 2025-26 brouillerait (2023/2024 Q. 8 A, 2021/2022 S2 Q. 4 B, 2020/2021 S1
Q. 21 A, BMCP 11 Q19 E, 2019/2020 S2 Q. 18 E).

## Questions pour Vincent

1. **BMCP 11, 2019/2020 S1 Q19 A** (« Le gène ras est activé en oncogène par
   amplification génique », imprimée « (A) ») : la carte la tient vraie, clé non
   officielle. À trancher : ABCDE ou BCDE ?
2. **2022/2023 S1 Q. 3 A** (« pRB intervient dans le point de contrôle en G1
   tardif », sans corrigé) : la carte la tient fausse, comme le cours qui sépare
   point R et point de contrôle de G1 tardif, en disant que pRB est en aval de
   p21. D'accord ?
3. **2023/2024 QROC 2, point 2** : « un facteur de croissance » (corrigé) et
   « la phosphorylation de pRB » (cours) sont acceptés tous les deux.
4. **wee1 et cdc25 (p. 5)** : le plan classe l'erreur du ronéo « point
   douteux » ; la figure de la p. 6 la tranche (Wee/Myt : inhibition de la
   CDK). La passer en prise de notes ?
5. **Le lexique** : Aneuploïdie et Quiescence, proposées par le plan, sont déjà
   accueillies hors de l'UE (`genet_chromosomes`, `immuno_reponse_t`) ; elles
   sont remplacées par Mitogène et Sarcome. D'accord ?

## Le lexique

Neuf termes, pages mesurées dans le texte de la FC 2025-26 (règle de
`scripts/chercher_pages.py`, lue avec PyMuPDF faute de pypdf ; la p. 1, le
titre et le plan, n'est pas comptée) :

| Terme | Origine | Pages |
|---|---|---|
| Cytodiérèse | grec κύτος + διαίρεσις | 3, 4, 20 |
| Cycline | grec κύκλος, par l'anglais cyclin (T. Hunt, 1983) | 4-11, 13-17, 19 |
| Rétinoblastome | latin retina + grec βλαστός + -ωμα | 11, 22, 23 |
| Oncogène | grec ὄγκος + -γενής | 2, 12-15, 17, 21-23 |
| Papule | latin papula | 14 |
| Kinétochore | grec κινητός + χῶρος | 20 |
| Hétérozygotie | grec ἕτερος + ζυγωτός | 23 |
| Mitogène | grec μίτος + -γενής | 3, 9, 10 |
| Sarcome | grec σάρκωμα | 14 |

**Aneuploïdie** (`lex-aneuploidie`, `genet_chromosomes`) et **Quiescence**
(`lex-quiescence`, `immuno_reponse_t`) sont déjà accueillies : un terme, un
identifiant. L'origine de chaque terme et de chaque racine est écrite dans les
définitions ; les six racines nouvelles (`-diérèse`, `cycl(o)-`, `onc(o)-`,
`papula (latin)`, `kinéto-`, `-chore`) et les neuf termes sont proposés à la
table dans le brouillon `scratchpad/etym/bmcp_cycle_cellulaire.json`
(Wiktionnaire, Bailly, Gaffiot), à fusionner dans `scripts/etymologies.json`.
Les racines reprises gardent la clé de la table (`cyt(o)- / -cyte`,
`retina (latin médiéval)`, `-blaste`, `-ome`, `-gène`, `hétéro-`, `-zygote`,
`mit(o)-`, `sarco-`). `onc(o)-`, que `bmcp_tests_biologiques` propose aussi sous
la même clé, cite la FC de sémantique 2026-27 (1/2, p. 6 : « protooncogène »,
onco- : gonflement, grosseur), comme `cyt(o)-`, `-blaste`, `-gène` et
`hétéro-` ; les autres racines sont hors FC.

## À relire

Deux cartes portent `a-relire` : `ccl-anq-2122s1-qroc3`, l'anticorps anti-p53
phosphorylée sur la sérine 15. Sa réponse est déduite (ATM et ATR phosphorylent
la sérine 15 et stabilisent p53 : Banin et al., Canman et al., Science 1998 ;
Shieh et al., Cell 1997), hors du texte du cours 2025-26 : à relire contre le
cours de l'année. Et `ccl-an-2425s1-q8` (sujet 2024/2025, sans corrigé) : sa D, la
non-disjonction comme cause de perte d'hétérozygotie, n'est tranchée par aucune page
des cours 2023-24 à 2025-26 ; retenue fausse sur Cavenee et al. (Nature 1983). Le tag
se retire si le ronéo 2026-27 en parle, ou si Vincent confirme.

## Relecture (05/10)

Chaque carte a été relue contre la page de la FC qu'elle cite, chaque annale
contre le texte du polycopié (mot pour mot) et sa table de corrections, chaque
renvoi aux cours 2024-25 et 2023-24 contre leur page, et les sources externes
en ligne (PubMed 39106591 pour l'amplification de KRAS ; Mol Med Rep 2018 et
Clin Exp Dermatol 2010 pour le psoriasis). Les figures sont rapportées à leur
page par comparaison avec les images du PDF. Ce que la relecture a changé :

- le repère « fin de M » du schéma des contrôles est retiré, et le point de
  contrôle du fuseau placé comme sur les roues du cours (voir plus haut) ; la
  carte passe au thème `phases-cycle` ;
- la racine `onc(o)-` cite la FC de sémantique (1/2, p. 6), comme dans
  `bmcp_tests_biologiques` ; le sens de l'étymon de « cycline » est ramené à
  « cercle, cycle » ;
- la QROC de l'aneuploïdie prend la figure de l'aneuploïdie (p. 20), et les deux
  annales des niveaux de régulation les courbes des cyclines (p. 6) ;
- BMCP 11 Q19 A cite aussi le tableau de la p. 22 du cours 2025-26 et dit quoi
  répondre à l'examen ;
- les comptes de ce fichier (quatre questions du professeur, non cinq).

## Intégration (05/10)

- Les libellés de thèmes sont dans `THEME_LABELS`
  (`app/src/med_engine/application/scopes.py`), bloc « BMCP FC n°6 à 22 ».
- Les étymologies proposées (racines et termes) sont versées dans
  `.claude/skills/nouveau-chapitre/scripts/etymologies.json` ;
  `appliquer_etymologies.py` n'a rien réécrit, les textes du lexique étant
  déjà à sa forme.
- Le libellé de `points-surveillance` ne porte plus « p53 » (un libellé de
  thème ne porte aucun chiffre) : « Points de surveillance : lésions de l'ADN
  et fuseau ».
- `onc(o)-` n'a qu'une entrée, commune avec `bmcp_tests_biologiques`.

## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier (BMCP) ou du 6 janvier (SSH, papier). Sous les annales, 35 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 12 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `phases-cycle` | 1 | 1 | 4 |
| `cdk-cyclines` | 12 | 3 | 14 |
| `voie-prb` | 7 | 2 | 7 |
| `virus-oncogenes` | 1 | 1 | 3 |
| `points-surveillance` | 6 | 3 | 8 |
| `oncogenes-gst` | 8 | 2 | 6 |

**Le schéma** `ech-cycle-cellulaire`, « Le cycle cellulaire · moteur, freins et gardiens », donne 78 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_CYCLE_CELLULAIRE`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- ccl-an-2425s1-q8 D — la non-disjonction, absente des cours 2023-24 à 2025-26 (CONFLITS, a-relire) ; ccl-ech-s34 C le signale par un ATTENTION.
- ccl-an-2324s1-q8 E, ccl-an-1516s1-q19 A, ccl-an-1617s1-q13 A — sérine/thréonine ou tyrosine kinases : le ronéo 2025-26 dit seulement « kinases ».
- ccl-an-1516s1-q19 C — la structure de la CDK ne se lit que sur une figure non légendée.
- ccl-an-2324s1-q10 A, ccl-an-2122s1-bmcp11-q17 E, ccl-an-2021s1-q21 D E, ccl-an-2021s2-q24 A C D E, ccl-an-1920s1-bmcp11-q19 D, ccl-an-1920s1-q18 E, ccl-an-1920s2-q18 D, ccl-an-1819s2-q18 D, ccl-an-1617s2-q14 D, ccl-an-1617s2-q15 C, ccl-an-1516s2-q19 D — hors du cours 2025-26 (Hanahan-Weinberg, signatures et domaine de liaison de p53, psoriasis, p57, RAS-GTP, aflatoxine, UV-dimères, benzopyrène, p34cdc2, demi-vie de l'ARNm, ubiquitine ligase, E2F-DP1).
- ccl-an-1920s2-bmcp13-q17 A B — protéines G et arrestine : la FC n°14.
- ccl-an-1718s2-q13 D E — Tax du HTLV-1 et cancer colorectal : hors du cours 2025-26 (« certains types de cancer », p. 20).
- ccl-an-1617s1-q14 B — PTEN n'est nommé que parmi les gatekeepers (p. 22), sans sa voie.
- ccl-anq-2425s1-qroc3a, qroc3c1, qroc3c2 — biopsie, cytométrie, immunohistochimie : l'ED n°1, absent des sources.

## Régénérer

```powershell
cd contenu\chapitres\bmcp_cycle_cellulaire
..\..\..\app\.venv\Scripts\python.exe generer.py
```

La planche numérotée se refait depuis `app/` (Pillow) :
`python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/bmcp_cycle_cellulaire ccl-pl-voie-prb --apercus <brouillon>`.
