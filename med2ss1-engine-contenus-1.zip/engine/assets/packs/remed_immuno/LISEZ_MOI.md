# Immunologie — paquet ECL Remédiation

147 notes, 229 cartes. Chapitre `chap-remed-immuno` de l'UE ECL Remédiation,
pour le **test intermédiaire 2 du 29/10/2026** (QCM avec degré de certitude).
Sources : les diapositives des deux séances d'immunologie de **2025-26**
(Dr De Nadaï, Dr Marion, Dr Vignal) et les QCM d'immunologie de deux tests
intermédiaires 2, **sans corrigé** : les vingt de 2024-25, photographiés sur
une copie annotée, et les dix-huit de 2025-26 (30/10/2025), sujet imprimé.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 76 | 76 |
| QRU | 8 | 8 |
| Texte à trous | 16 | 76 |
| QROC | 15 | 15 |
| Recto-verso | 12 | 12 |
| Schéma cliquable | 4 | 26 |
| Planche à légender | 2 | 2 |
| Lexique | 14 | 14 |

Dont **38 annales** (QRM : session `2024/2025 TI2`, `QCM 1` à `QCM 20` ;
session `2025/2026 TI2`, `QCM 1` à `QCM 18`) et 46 QCM de cours (38 QRM,
8 QRU), chacun avec une justification par proposition. Les lettres justes se répartissent sur A à E (dans les 46 QCM du
cours : A 21, B 16, C 23, D 27, E 26 ; deux QRU pour A, C, D et E) ; les QRM du
cours ont d'une à quatre vraies (une : 2, deux : 9, trois : 23, quatre : 4),
après le rééquilibrage de la critique d'ensemble (19/10).

Vingt-cinq thèmes, tous des clés de l'UE Immunologie reprises à leur libellé
exact (`application/scopes.py`, aucun libellé nouveau) : un thème se révise
ainsi d'une UE à l'autre. C'est plus que les cinq à huit d'un chapitre de
sémiologie, parce que ces 93 diapositives balaient tout le programme :

`systeme-immunitaire`, `inne-adaptatif`, `phagocytose`, `complement-voies`,
`complement-effets`, `cellules-dendritiques`, `organes-lymphoides`,
`molecules-hla`, `genes-hla`, `recepteur-t`, `differenciation-thymocytes`,
`activation-lt`, `polarisation-lt`, `lb-elements-cles`, `structure-ig`,
`recombinaison-vdj`, `aide-cognate`, `fonctions-isotypes`, `modes-action-ac`,
`bacteries-extracellulaires`, `bacteries-intracellulaires`,
`immunite-antivirale`, `types-memoire`, `memoire-vaccination`, `vaccins`.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-remed-immuno-p1` — « Immunologie, partie 1 », séance du 16/10/2025, `Remediation/Immuno_partie1_161025.pdf` (57 p.) | **2025-26** | la fiche par défaut : chaque carte qui la cite porte `page=` |
| `src-remed-immuno-p2` — « Immunologie, partie 2 », séance du 23/10/2025, export Wooclap, `Remediation/Immuno partie2 231025.pdf` (36 p.) | **2025-26** | les cartes qui la citent portent `fiche=` et `page=` |
| `src-remed-ti2-2425` — test intermédiaire 2, 24/10/2024 (sujet photographié, 10 p.) | 2024-25 | les 20 annales de la session `2024/2025 TI2` ; déclaration identique à celle de `remed_pharmaco` |
| `src-remed-ti2-2526` — test intermédiaire 2, 30/10/2025 (sujet imprimé, 7 p., 36 QCM) | 2025-26 | les 18 annales de la session `2025/2026 TI2` (questions 1 à 18) ; déclaration identique dans `remed_souches` (19 à 27) et `remed_pharmaco` (28 à 36) |

**Des diapositives d'une année passée.** L'auteur des deux fiches porte
« ECL Remédiation 2025-26 » : chaque carte de cours reçoit le tag
`cours-2025-26` et le badge « Cours 2025-26 ». Les supports des séances de
2026-27 (15/10 et 22/10/2026) corrigeront les cartes à leur parution.

**La partie 2 est un export Wooclap** : des images seules, sans texte PDF, et
aucune question Wooclap n'y figure. Ses pages ont été lues sur les images
rendues ; les numéros cités sont ceux des pages du PDF (pNN), pas les numéros
imprimés sur certaines diapositives.

Vérifications hors du cours, citées dans la carte qui s'en sert : Janeway,
*Immunobiology* (MAC-1 et CR3, récepteurs C3aR et C5aR, CR1 et CR2, acides
lipotéichoïques, Pattern Recognition Receptors, bourse de Fabricius, commutation
isotypique, queues intracytoplasmiques du TCR et du BCR, granzymes, C5a et
ingestion ; pour le test de 2025-26 : ITAM du seul CD3, polymorphisme des
chaînes β de classe II et chaîne α de HLA-DR quasi invariable, autophagie et
classe II) ; Le Bon et al., *Immunity*
2001 (IFN de type I et commutation).

## Ce que le cours a dicté

- **Les mots en rouge des diapositives ont tous leur carte** : « non
  spécifique » et « retardée » (p. 8), cellules dendritiques, neutrophiles et
  macrophages (p. 14), « cytokines » (p. 13), CR1 et FcR (p. 17), « organe
  d'initiation de la réponse immune adaptative » (p. 27), opsonisation, lyse,
  agglutination, neutralisation, phagocytose (p. 57) ; en partie 2, « réponse
  cytotoxique de type Th1 » (p. 2) et « toute cellule de l'organisme peut
  produire un IFN type I » (p. 17), le « ou toute autre cellule » souligné de la
  p. 11 — c'est la proposition 6 C de l'annale.
- **Le calcul de la p. 51** (134 V × 13 D × 4 J, 85 V × 4 J, 2,37 millions)
  a trois cartes : un texte à trous pour les deux étapes, une QROC pour le
  résultat, une QRU dont les distracteurs sont les erreurs de calcul.
- **Le tableau des isotypes (p. 54)** et **le tableau innée/adaptative (p. 9)**
  sont cartés ligne par ligne.
- **Les ateliers de la partie 2** (primo-injection et rappel du vaccin polio,
  p. 27-34) ne posent que des questions ; leurs réponses, dessinées p. 29-33,
  font les cartes `rimm-qc-primo-rappel` et `rimm-rv-primaire-secondaire`.

## Les erreurs des diapositives

Chacune est dite par **ATTENTION**, sans genre (précédent d'`immuno_innee`),
dans la carte qui porte la notion : « À l'examen : », puis « La référence : ».
Rien n'entre dans `contenu/ERRATA_RONEOS_2026-27.md`, qui ne concerne que les
ronéos de l'année.

| Page | Ce que dit la diapositive | Ce qui est juste | Carte |
|---|---|---|---|
| immuno1 p. 17-18 | « CR1 (MAC-1) > C3b » | MAC-1 est le CR3 (CD11b/CD18), qui lie l'iC3b ; le CR1 est le CD35 (Janeway) | `rimm-qc-phagocytose-recepteurs` B (la proposition E qui la posait est remplacée, critique du 19/10) |
| immuno1 p. 23 | « récepteurs CR1 et CR2 des polynucléaires, monocytes/macrophages », que les anaphylatoxines font exprimer (le rôle de la p. 22) | une imprécision plutôt qu'une erreur : le C5a augmente le CR1 et le CR3 des neutrophiles ; le CR2 (CD21) est surtout celui des LB, et les récepteurs des anaphylatoxines sont le C3aR et le C5aR (Janeway). Dite sans ATTENTION ; la proposition qui la mettait en jeu est remplacée (critique d'ensemble, 19/10) | `rimm-qc-complement-effets` (explication) |
| immuno1 p. 13 | « Lipoteichoic acids (Gram-negative) » | composants des Gram POSITIF (Janeway) | `rimm-qc-tlr` E |
| immuno1 p. 9 | « Pathogen Recognition Receptors (PRR) » | Pattern Recognition Receptors, comme l'écrivent les annales (Janeway) | `rimm-qr-prr` |
| immuno1 p. 48 | « Lymphocyte B pour Bone marrow » | le B vient de la bourse de Fabricius des oiseaux (Glick 1956 ; Janeway) | `rimm-qr-b-moelle` |
| immuno1 p. 43 | les deux sélections thymiques dessinées au contact d'une cellule dendritique | la sélection positive se fait sur les cellules épithéliales du cortex thymique, la négative surtout dans la médullaire (épithéliales médullaires, cellules dendritiques) (Janeway) | `rimm-rv-selections` (explication) |

Sans ATTENTION, parce qu'aucune réponse n'en dépend : « C3 thick-over » pour
« tick-over », l'hydrolyse spontanée du C3 (p. 21-22, dit dans
`rimm-qc-complement-voies`) ; « transmission sans crossing-over » (p. 37), la
règle, que des recombinaisons rares nuancent (dit dans `rimm-qc-hla-genetique`
E) ;
« Chiomokines » (p. 14-15) ; « (ex: ROR) » après « vaccin vivant atténué – Ou –
vaccin inactivé » (immuno2 p. 26) : le ROR est vivant atténué, ce que disent
`rimm-fa-vaccins` et `rimm-qc-vaccins` A ; « Son rôle est la lyse cellulaire »
pour le complément (p. 20), que les p. 22-23 complètent (opsonisation,
inflammation).

**Deux diapositives du cours qui ne disent pas la même chose** : « B cell
receptor = IgM » (immuno1 p. 53) et « BCR = Ig membranaire » (immuno2
p. 29-30). La seconde est la juste : le LB naïf porte IgM et IgD (p. 54), le
LB qui a commuté une autre classe. Dit dans l'annale 11 B (ATTENTION).

## Ce que les annales ont dicté

Les vingt QCM du test 2 de 2024-25 et les dix-huit de 2025-26, rangés par
savoir :

| Savoir | 2024-25 | 2025-26 | Cartes de cours qui y préparent |
|---|---|---|---|
| Inné et adaptatif, cytokines | Q1, Q5, Q7 | Q1, Q5, Q7, Q12 | `rimm-qc-tableau-inne`, `rimm-qc-temporalite`, `rimm-qc-roles`, `rimm-qc-neutrophiles` |
| Complément | Q2, Q3, Q4 | Q2, Q3, Q4 | `rimm-qc-complement-voies`, `rimm-qc-complement-effets` |
| Défense humorale, bactéries extracellulaires | Q3, Q4 | Q3, Q4 | `rimm-qc-humorale`, `rimm-qc-extracellulaires` |
| Interférons et immunité antivirale, NK | Q6, Q14 | Q6, Q17 | `rimm-qc-ifn-types`, `rimm-qc-ifn-effets`, `rimm-qc-nk` |
| Cellule dendritique, organes lymphoïdes | — | Q11, Q18 | `rimm-qc-organes`, `rimm-qc-antigene` |
| LT : récepteur, sélection, sous-populations, Th1 | Q8, Q9, Q10, Q18, Q19 | Q8, Q9, Q14 | `rimm-qc-tcr`, `rimm-qc-lt-thymus`, `rimm-qc-polarisation`, `rimm-qc-activation-lt` |
| LB, BCR et immunoglobulines | Q11, Q16, Q17 | Q10, Q15 | `rimm-qc-ig-structure`, `rimm-qc-fab-fc`, `rimm-qc-isotypes` |
| HLA | Q15 | Q13, Q16 | `rimm-qc-hla-classes`, `rimm-qc-hla-genetique`, `rimm-qc-haplotype` |
| Vaccination et mémoire | Q12, Q13, Q20 | — | `rimm-qc-vaccins`, `rimm-qc-primo-rappel`, `rimm-qc-memoire` |

Ce qui revient le plus : les lymphocytes T (cinq questions en 2024-25, trois
en 2025-26), l'inné et le complément, repris presque mot pour mot d'une année
à l'autre. **Le test de 2025-26 ne pose aucune question de vaccination ni de
mémoire**, qui en avait trois en 2024-25, et en ajoute sur la cellule
dendritique, les organes lymphoïdes et le HLA. Aucune question, en deux ans,
ne porte sur la recombinaison VDJ, que le cours développe (p. 50-52), sinon
comme distracteur (Q1 E).

## Le test de 2024-25 et ses anomalies

Le sujet du 24/10/2024 est photographié en huit photos coupées en deux
(IMG_8033 à IMG_8040) ; l'immunologie tient sur les quatre premières. **La
question 20 finit en bas d'IMG_8036** ; IMG_8037 s'ouvre sur la question 21,
de pharmacologie. Chaque énoncé et chaque proposition sont recopiés mot pour
mot, les mots douteux relus sur un agrandissement.

- **Aucun corrigé** : les vingt clés sont déduites du cours, `officielle=False`,
  et chaque explication commence par « Clé déduite du cours, absente de la
  table de corrections », dit la page qui tranche et ce que montre la copie.
- **Les Q12 et Q13 ont le même énoncé** imprimé ; **les Q5 et Q6 partagent
  mot pour mot** leurs propositions D et E (cytokines, puis IFN de type I).
- **Coquilles gardées telles quelles** : « Elle se lient au » (Q5 D),
  « sécrète » (Q9 C), « le lymphocyte » (Q9 E), « entrainer » (Q12 D),
  « classe 1 » (Q15 B), « reconnaitre » (Q16 E).
- **Six propositions ambiguës ou que le cours ne tranche pas**, déclarées dans
  `CONFLITS` et signalées par ATTENTION en tête de leur justification :

| Question | Ce qui coince | Retenu | Pourquoi |
|---|---|---|---|
| Q2 E | « les anaphylatoxines favorisent la phagocytose » : l'opsonine est le C3b | vrai | le cours leur prête l'expression des récepteurs du complément sur les phagocytes (p. 22) ; le C5a accroît l'ingestion (Janeway) |
| Q6 E | « les IFN de type I régulent le switch isotypique des LB naïfs » | vrai, **cas ouvert** | le cours se tait (le switch n'est pas parmi les cinq effets des IFN I, immuno2 p. 17) sans l'exclure ; la science tranche : les IFN I, des cytokines, favorisent la commutation par les cellules dendritiques (Le Bon et al., Immunity 2001) ; la même phrase est vraie à la Q5, et la copie entoure E. Retenu faux par le rédacteur, sur le silence du cours ; passé à vrai à la relecture |
| Q11 B | « le récepteur spécifique du LB est une IgM aussi appelée BCR » | vrai | « B cell receptor = IgM » (p. 53), formule réductrice : « BCR = Ig membranaire » (immuno2 p. 29-30) |
| Q11 D | « lors du switch, les LB produisent un seul isotype » | vrai | après la commutation, une cellule B et sa descendance ne produisent qu'un isotype (Janeway) ; lue pour l'ensemble des LB, elle serait fausse |
| Q12 A | « un vaccin contient un pathogène inactivé ou un morceau de pathogène » | vrai | définition incomplète (vivants atténués, ARNm, vecteurs, immuno2 p. 26), juste comme définition générale |
| Q16 B | « absence de domaine intracellulaire », pour le BCR et le TCR | vrai, **cas ouvert** | sous la membrane, une queue de quelques acides aminés (trois pour l'IgM de membrane), sans domaine ni motif de signalisation, d'où le CD3 et ses ITAM (p. 41) et Igα/Igβ (Janeway) ; la figure du cours ne dessine qu'un trait court, sans domaine (p. 41-42). Lue « aucune partie intracellulaire », elle serait fausse. Retenu faux par le rédacteur ; passé à vrai à la relecture |

## Les clés déduites qui s'écartent des annotations de la copie (2024-25)

La copie est annotée à la main : lettres entourées ou barrées (un tiret devant
la lettre), surlignages bleus, flèches, « ✓ » (Q1, Q2), points perdus en marge.
Ce n'est pas un corrigé : on ne sait pas si un entourage est la réponse donnée
ou la réponse recopiée à la correction, et les points perdus ne sont pas notés
partout (aucun à la Q16, où la copie s'écarte pourtant du cours) : on ne
raisonne jamais sur leur absence. C'est une contre-épreuve : chaque explication
dit ce qu'elle montre. Les marques ont été relues sur des agrandissements à la
relecture du sceptique ; plusieurs tirets (lettres barrées) avaient échappé à la
première lecture.

| Question | La copie | Retenu | Ce qui tranche |
|---|---|---|---|
| Q2 | tiret devant A, arcs pâles devant C, D, E ; surligne B et D ; « ✓ » | D faux | anaphylatoxines C3a et C5a (p. 22) |
| Q4 | flèche et surlignage sur C | C faux | les anticorps activent la voie classique (p. 55) |
| Q6 | « −0,5 » et flèche sur C, surlignée mais non entourée ; entoure A, et pâles B et E | C vrai, E vrai (cas ouvert) | toute cellule produit un IFN I (immuno2 p. 17) : le demi-point va dans le sens de la clé ; E, voir plus haut |
| Q7 | D surlignée, avec un tiret et un arc pâle | D vrai | les anticorps sont de l'adaptative (p. 7) |
| Q11 | barre A et C ; « −0,5 » relié à E, entourée et précédée d'un tiret ; B sans marque | B et E vrais | p. 53 |
| Q13 | entoure B, D et, pâle, C ; tiret devant E ; « −1 » à hauteur de C | C faux, E vrai | les Ig n'activent pas les LT mémoires (immuno2 p. 22) ; rappel et taux d'anticorps (p. 33) — deux écarts, compatibles avec le « −1 » |
| Q15 | entoure C et D ; tirets pâles devant A et B | C faux, B vrai | transmission en bloc (p. 37), β2m (p. 35-37) |
| Q16 | entoure A (pâle), D et E ; tiret devant C | D faux, C vrai | le TCR n'a pas de forme soluble (p. 40-44) ; domaines de type Ig (p. 40) |
| Q18 | entoure et surligne A | A faux | sélection négative (p. 43) |
| Q20 | surligne D ; barre B et E | D faux | l'innée et des naïfs répondent aussi (immuno1 p. 7 ; Janeway) |
| Q9, Q12, Q17 | E, C, D sans marque | vrais | p. 53 ; immuno2 p. 22 ; p. 53 |

Le demi-point perdu tombe sur une proposition barrée que le cours tient pour
vraie, donc dans le sens de la clé, aux Q10 (B, IL-12) et Q14 (E, ADCC). Même
lecture que la copie : Q1 (A, C, D entourées, B et E barrées), Q8 (B, C
entourées, A, D, E barrées), Q19 (A et, pâles, C, D entourées ; B barrée).
Q3 et Q5 n'ont aucune lettre entourée.

## Le test de 2025-26 et ses anomalies

Le sujet du 30/10/2025 (10 h-11 h 15, 36 QCM) est imprimé, **sans corrigé ni
annotation** : l'immunologie tient les questions 1 à 18, les tissus et
cellules souches 19 à 27 (`remed_souches`), la pharmacologie 28 à 36
(`remed_pharmaco`). Énoncés et propositions sont recopiés mot pour mot du texte
du sujet, et une comparaison automatique les a relus contre lui. Les dix-huit
clés sont déduites du cours, `officielle=False`, et chaque explication dit la
page qui tranche et ce qui a changé depuis 2024-25.

**Huit questions reprennent le test de 2024-25.** Une proposition identique
garde son verdict et sa justification :

| 2025-26 | 2024-25 | Ce qui change |
|---|---|---|
| Q1, Q4, Q6 | QCM 1, 4, 6 | rien (Q1 : « chaînes » prend son accent) |
| Q2 | QCM 2 | le « et » manque en A, sans changer le sens |
| Q5 | QCM 5 | la coquille « Elle se lient » est corrigée |
| Q15 | QCM 17 | l'énoncé seul |
| Q3 | QCM 3 | A (NETose : des NK aux neutrophiles, faux → vrai), B (lectines → cascade du complément, vrai), D (HLA-II → CMH-I et LT CD8, vrai → faux) |
| Q16 | QCM 15 | l'énoncé ; B (classe 1 → classe 2, vrai → faux) ; E (sélection thymique → protéines endogènes, vrai → faux) : une seule vraie, D |
| Q7, Q8, Q9, Q10 | QCM 7, 8, 9, 11 | même énoncé, propositions nouvelles (quelques-unes reprises, dites dans l'explication) |

Les Q11 à Q14, Q17 et Q18 sont nouvelles. Les Q5 et Q6 partagent encore mot
pour mot leurs propositions D et E.

**Les clés, toutes déduites du cours** (aucun corrigé) :

| Question | Clé | Page qui tranche | Question | Clé | Page qui tranche |
|---|---|---|---|---|---|
| Q1 | ACD | immuno1 p. 7-9, 13 | Q10 | ACD | immuno1 p. 48, 53 ; immuno2 p. 30 |
| Q2 | ABE | immuno1 p. 20-22 | Q11 | BDE | immuno1 p. 26-27, 43-44 |
| Q3 | ABCE | immuno1 p. 15-16, 57 ; immuno2 p. 2, 6 | Q12 | ADE | immuno1 p. 9, 16 ; immuno2 p. 22 |
| Q4 | ABDE | immuno1 p. 53-56 | Q13 | ABCE | immuno1 p. 13-14, 28-36 |
| Q5 | BCE | immuno1 p. 13-14, 45, 53 | Q14 | ADE | immuno1 p. 40-44 |
| Q6 | ABCE | immuno2 p. 11-17 | Q15 | ADE | immuno1 p. 49-54 |
| Q7 | ADE | immuno1 p. 7-9 | Q16 | D | immuno1 p. 26-37 ; immuno2 p. 6 |
| Q8 | ABD | immuno1 p. 39-45 | Q17 | BDE | immuno2 p. 2, 9-13, 18-19 |
| Q9 | BE | immuno1 p. 45, 53 | Q18 | DE | immuno1 p. 13-14, 25-27 |

Les lettres justes : A 12, B 10, C 6, D 12, E 14 ; une vraie : 1 question (Q16),
deux : 2, trois : 11, quatre : 4. Aucune lettre n'a été pliée pour équilibrer :
la Q16 n'a qu'une vraie parce que ses propositions B et E, changées depuis
2024-25, sont devenues fausses.

**Quatre propositions ambiguës ou que le cours ne tranche pas**, déclarées dans
`CONFLITS` et signalées par ATTENTION en tête de leur justification :

| Question | Ce qui coince | Retenu | Pourquoi |
|---|---|---|---|
| Q2 E | « les anaphylatoxines favorisent la phagocytose », repris du QCM 2 E de 2024-25 | vrai | comme en 2024-25 : récepteurs du complément sur les phagocytes (p. 22) ; C5a et ingestion (Janeway) |
| Q6 E | « les IFN de type I régulent le switch isotypique », repris du QCM 6 E de 2024-25 | vrai, **cas ouvert** | comme en 2024-25 : le cours se tait, la science tranche (Le Bon et al., Immunity 2001) |
| Q14 B | « sa partie intracytoplasmique [du TCR] possède des motifs ITAM » | faux, **cas ouvert** | la phrase de la p. 41 (« associé au CD3 … grâce aux motifs ITAM sur la partie intra-cytoplasmique ») se lit pour le TCR ; sa figure ne dessine les ITAM que sur les chaînes du CD3, et les chaînes α et β n'ont qu'une queue courte sans motif (Janeway) — la lecture déjà retenue au QCM 16 B de 2024-25. Vrai si le professeur entend le complexe TCR-CD3 |
| Q18 C | « grâce aux récepteurs PAMPs qu'elles expriment à leur surface » | faux, **cas ouvert** | les récepteurs sont les PRR, les PAMPs leurs motifs (p. 9, 13-14) : le sujet nomme les PRR en toutes lettres aux Q5 et Q6, et la confusion motif-récepteur semble la faute attendue. Lu « récepteurs des PAMPs » (comme « récepteur Fc »), il serait vrai |

Tranchées par le cours sans ATTENTION, la nuance dite dans la justification :
Q3 D (la présentation croisée par le CMH-I, immuno2 p. 6, sert contre les
pathogènes intracellulaires), Q12 B (les « anticorps naturels » de la p. 7 sont
là avant l'agression), Q16 E (le cours n'écrit pas « exogène », mais la classe
II présente l'antigène capturé par la CPA, et il appelle « présentation
croisée » l'antigène exogène sur le CMH-I ; l'autophagie, qu'il n'enseigne pas,
est l'exception).

Relecture du sceptique (26/10) : les dix-huit clés et les quatre conflits sont
confirmés sur les pages du cours ; quatre justifications sont précisées — Q12 D
(les « médiateurs préformés » de la p. 9), Q16 B (les chaînes β de la classe II
sont polymorphes, c'est la chaîne α de HLA-DR qui varie à peine), Q16 E
(l'inférence « exogène » dite comme telle), Q17 C (la phagocytose après
opsonisation contre les intracellulaires, immuno2 p. 9-10).

**Coquilles gardées telles quelles** : « C8 un polymère de C9 » (Q2 A) ;
« au Pattern-Recognition-Receptors » (Q5 D, Q6 D, comme en 2024-25) ; « le (ou
lesquels) est (ou sont) » et « La netose » (Q12) ; « Quelles affirmations
suivantes la ou lesquelles est/sont justes : » (Q15) ; « chaîne beta » et
« classe 2 » (Q16 B) ; « Ils présentent de l'antigène » (Q10 A) ; « sous
populations », sans trait d'union (Q9, comme en 2024-25).

**Illustrations** : les dix-huit portent une figure du cours déjà déclarée ;
six n'avaient encore servi à aucune annale : la planche légendée de
l'activation du LT (p. 44, Q8), les organes lymphoïdes (p. 27, Q11), les
neutrophiles (p. 16, Q12), les rôles des HLA (p. 32, Q13), le rôle des
anticorps contre un virus (immuno2 p. 18, Q17), la capture et la présentation
par la cellule dendritique (p. 26, Q18).

## Les schémas cliquables et les planches

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `rimm-ig-nue.svg` (`rimm-zo-ig-domaines`) | VL, VH, CL, CH1, les CDR, la charnière, CH2, CH3 | 8 |
| `rimm-ig-nue.svg` (`rimm-zo-ig-fragments`) | un Fab, la charnière, le Fc | 3 |
| `rimm-ifn-nue.svg` (`rimm-zo-ifn`) | IFNAR, JAK1/TYK2, STAT1/2, ISGF3, ISRE, ISG, protéines antivirales, IRF3/IRF7, IFN sécrété | 9 |
| `rimm-hla-nue.svg` (`rimm-zo-hla`) | niche α1-α2, α3, β2m (classe I) ; niche α1-β1, α2, β2 (classe II) | 6 |

**L'immunoglobuline** est redessinée d'après la p. 49 : le bras gauche plein
porte les zones, le droit est estompé et tient un antigène à sa pointe — les
deux bras sont identiques, une zone ne se pose que là où un seul tracé passe.
La chaîne légère est à l'extérieur du bras, la lourde à l'intérieur ; les
domaines variables sont plus foncés que les constants, les CDR sont trois
boucles rouges à la pointe. Deux listes de zones sur le même dessin, parce
qu'un Fab recouvre ses quatre domaines.
**La voie des IFN de type I** redessine les p. 14-16 de la partie 2 : à gauche
l'IFN reçu et la voie jusqu'au noyau, à droite le virus qui entre et l'IFN qui
sort ; l'ADN du noyau porte l'ISRE, les ISG et le gène de l'IFN.
**Les molécules HLA** redessinent les p. 28-32 : une chaîne ancrée et une β2m
libre d'un côté, deux chaînes ancrées de l'autre ; le peptide de la classe II
déborde de sa niche ouverte. Les trois versions légendées (`rimm-ig.svg`,
`rimm-ifn.svg`, `rimm-hla.svg`), tirées des mêmes constantes, illustrent les
corrections. Rendus avec les zones superposées : aucune zone ne déborde sur une
autre.

**Les planches**, faites depuis `app/` avec
`scripts/planche_depuis_pdf.py`, les aperçus relus :

- `rimm-pl-activation-lt` (immuno1 p. 44) : douze numéros (cytokines IL-2,
  adhésion, CMH I ↔ T CD8+, CMH II ↔ T CD4+, reconnaissance, CD80, CD28, CD86,
  costimulation, CPA, cellule T naïve, synapse immunologique), cinq intrus
  (CD40, IL-12, perforine, CD3, IFN-γ). Les puces du haut, le « TCR » et les
  cadres 1, 2, 3 des signaux restent visibles (`--garder`) ; APC, CD80, CD86,
  CD28, CMH et cellule T, en capitales, sont retirés (`--effacer`).
- `rimm-pl-tcr` (immuno1 p. 42) : six numéros (CD4, TCR, CD8, trois CD3),
  quatre intrus (BCR, CD28, CD80, CMH II), options `--effacer TCR --effacer CD3
  --effacer CD4 --effacer CD8 --au-centre`. **Les mots « CD4 » et « CD8 »
  écrits dans l'image même** (les boîtes de droite) ont ensuite été recouverts
  de la couleur de leur boîte, pixel par pixel au-dessus de la teinte du fond,
  dans les rectangles (818, 225, 851, 243) et (956, 297, 989, 316) de
  `rimm-pl-tcr.png` : ils donnaient les numéros 1 et 3. Les lettres grecques
  des chaînes et les D1 à D4 du CD4 restent : les reconnaître est la question.

**Illustrations** : 84 QCM sur 84 portent une figure du cours ou un schéma en
correction ; 133 notes sur 147. Les 51 figures du cours sont des diapositives
entières rendues à 900 px et réduites à 256 couleurs ; avec les quatre images
des planches et les six SVG, `media/` pèse 4,7 Mo. Dans `rimm-ifn.svg`, la
relecture a déplacé la boîte des protéines antivirales et deux légendes
(ISGF3, IRF3/IRF7) qui chevauchaient un trait ou une boîte ; les zones suivent,
puisqu'elles lisent les mêmes constantes.

## Le lexique

Quatorze termes, identifiants `lex-<terme>-remed` : phagocytose (immuno1 p. 9,
15, 17, 18, 23, 56, 57 ; immuno2 p. 9, 24, 35), opsonisation (p. 23, 54, 56,
57 ; immuno2 p. 9, 18), anaphylatoxine (p. 22, 23), complément (p. 4, 17-24,
54, 55, 57 ; immuno2 p. 2, 9, 12, 18), antigène (p. 9, 25, 26, 28-32, 45, 49,
53, 54, 56 ; immuno2 p. 6, 26, 29, 35), immunoglobuline (p. 17, 18, 40, 41,
49, 54), paratope (p. 49), haplotype (p. 35-37), plasmocyte (p. 53 ; immuno2 p. 24, 30, 35),
isotype (p. 53, 54), interféron (p. 45 ; immuno2 p. 3, 5-9, 11-19, le mot ou
le sigle IFN), neutralisation (p. 54, 56, 57 ; immuno2 p. 9, 18, 24),
agglutination (p. 54, 56, 57), vaccination (immuno2 p. 22, 31, 33, 35, 36).
« Polymorphisme » est laissé à `remed_gene_proteine`, qui l'emploie sur six pages
et dont la définition dit aussi le polymorphisme HLA : les deux chapitres le
déclaraient sous le même identifiant, et la note changeait de chapitre à
chaque réimport (critique du 19/10).

Les pages d'immuno1 sont mesurées par `chercher_pages.py` dans le texte du PDF,
complétées des mots que porte une image de la diapositive (p. 23 : « Opsonisation
C3b », « Anaphylatoxines C3a et C5a », « phagocytose » ; p. 45 : « IFN ») ;
celles d'immuno2, sans texte, sont lues sur les images, en français seulement
(« Plasma cell » ou « Neutralizing antibodies », p. 20, ne comptent pas ;
« vacciner », p. 27, n'est pas « vaccination »). Le relevé d'immuno2 a été
refait page par page à la relecture. Chaque définition finit
par son étymologie et chaque racine par la sienne, au mot près de ce
qu'écrirait `appliquer_etymologies.py`. Les treize termes dont le terme de
base est déjà dans `etymologies.json` y reprennent son entrée ; **agglutination
est nouvelle** (TLFi : « empr. au lat. agglutinatio, attesté uniquement dans les
gloses », de agglutinare ; Wiktionnaire, Gaffiot). Les entrées sont versées dans
`.claude/skills/nouveau-chapitre/scripts/etymologies.json`. Aucune racine nouvelle.

## Pages sans carte

- immuno1 : p. 1 (titre), 2 (« Introduction »), 3, 10, 38 et 47 (diapositives
  de questions), 6 (la frise vide de la p. 7), 11-12 (le poumon infecté, mise
  en scène de la p. 14), 19 (reprise de la p. 15 avec le titre du complément),
  29 (première construction de la p. 32), 46 (le drainage lymphatique, que la
  p. 26 dit mieux). Les p. 24, 30, 33, 36, 39 et 50, constructions de
  diapositives voisines, sont citées dans le texte des cartes. **Ajoutées à la
  relecture** : la p. 14 (immunité innée cellulaire, `rimm-qc-inne-cellulaire`)
  et les p. 50-52 (étapes de la recombinaison, D-J puis V-DJ, épissage vers C,
  `rimm-qc-vdj-etapes`), que le premier jet ne cartait pas.
- immuno2 : p. 1 (titre), 10 (« Les virus », titre), 21 (le retour des LT au site de l'infection), 24 (résumé de
  la réponse adaptative, sans notion nouvelle), 25, 28, 32 et 34 (titres et
  questions des ateliers), 35 (l'infographie de conclusion). Les p. 5, 7, 8,
  14, 29 et 31 sont citées dans le texte des cartes ; la p. 19 (le résumé de
  l'immunité antivirale, prévention et lutte) a reçu à la relecture sa carte,
  `rimm-rv-antiviral`.

## À relire

Cinq cartes portent `a-relire` : **`remed-ti2-2425-q6`** et
**`remed-ti2-2526-q6`** (E, les IFN de type I et le switch, retenue vraie ; la
même question posée deux ans de suite), **`remed-ti2-2425-q16`** (B, « absence
de domaine intracellulaire », retenue vraie), **`remed-ti2-2526-q14`** (B, les
ITAM « de la partie intracytoplasmique » du TCR, retenue fausse) et
**`remed-ti2-2526-q18`** (C, les « récepteurs PAMPs », retenue fausse). Le
cours ne les tranche pas ; les clés suivent la science ou la figure, mais
l'intention du professeur reste inconnue. Q16 B de 2024-25 et Q14 B de 2025-26
se tiennent : la queue intracellulaire du TCR, sans domaine ni motif, est la
même lecture. Une question au professeur, ou le corrigé du test de 2026 s'il
est diffusé, retirera le tag. À la parution des supports 2026-27, relire toutes les cartes
contre eux : pages, et les erreurs des diapositives ci-dessus.

## Relecture du sceptique (19/10/2026)

Les vingt annales relues mot pour mot sur les photos (agrandies), la question 20
finissant bien en bas d'IMG_8036 (IMG_8037 s'ouvre sur la question 21) ; chaque
carte relue contre sa page rendue. Ce qui a changé :

- **Deux clés d'annales** : Q6 E et Q16 B passent de faux à vrai (tableau des
  propositions ambiguës) ; Q6 devient ABCE, Q16 ABCE. Les `CONFLITS` et les
  ATTENTION le disent.
- **Les annotations de la copie**, relues sur agrandissements : tirets (lettres
  barrées) aux Q7, Q8, Q10, Q11, Q13, Q14, Q15, Q16, Q18, Q19, Q20 ; le
  « −0,5 » de la Q6 tombe sur C, non entourée, donc dans le sens de la clé —
  l'ATTENTION qui le disait contraire au cours est retiré.
- **Cartes de cours recopiées des annales, reformulées** : `rimm-qc-fab-fc` C
  (mot pour mot la Q17 C), `rimm-qc-ig-structure` A (Q17 B), `rimm-qc-nk` A
  (Q14 D), `rimm-qc-neutrophiles` B (Q3 A), `rimm-qc-polarisation` D (Q9 A),
  `rimm-qc-t-memoire` A (Q20 E).
- **Répartition des lettres** : sept QRM rééquilibrées (propositions permutées
  dans `rimm-qc-roles` et `rimm-qc-hla-classes` ; une vraie remplacée par un
  piège du même champ dans `rimm-qc-organes` E, `rimm-qc-t-memoire` E,
  `rimm-qc-lt-thymus` E, `rimm-qc-activation-lt` D, `rimm-qc-isotypes` D).
- **Justifications** : le distracteur « 236 000 » de `rimm-qc-calcul-vdj`, qui
  ne venait d'aucune erreur, devient « 182 240 » (le D oublié : 134 × 4 × 340) ;
  le « tick-over » est une hydrolyse, pas un clivage ; la transmission en bloc
  des gènes HLA connaît de rares recombinaisons ; le TLR9 lit l'ADN CpG
  (immuno1 p. 13) ; l'injection intramusculaire est celle de l'infographie, pas
  de tous les vaccins ; la sélection thymique (ATTENTION, tableau des erreurs).
- **Ajouts** : `rimm-qc-inne-cellulaire` (p. 14-15), `rimm-qc-vdj-etapes`
  (p. 50-52, figure `rimm-synthese-ac.png`), `rimm-rv-antiviral` (immuno2
  p. 19, figure `rimm-antiviral-resume.png`).
- **Lexique** : pages corrigées (voir plus haut) ; étymologie d'agglutination
  vérifiée sur le TLFi, sources ajoutées à `etymologies.json`.

## La critique d'ensemble (19/10)

Un critique a relu les quatre chapitres de l'ECL ensemble. Ici :
- **`rimm-qc-phagocytose-recepteurs`** — la proposition E (« MAC-1 est un autre
  nom du CR1 ») faisait répondre contre la diapositive, sur le point même où
  elle se trompe. Elle est remplacée par un piège faux dans les deux lectures
  (les récepteurs scavenger et le C3b). L'ATTENTION passe en B : à l'examen,
  « CR1 (MAC-1) > C3b », comme la diapositive ; la référence, MAC-1 = CR3.
- **`rimm-qc-complement-effets`** — la p. 23 ne dit pas que CR1 et CR2 sont les
  récepteurs des anaphylatoxines : elle dessine leur rôle de la p. 22. La
  proposition A qui la mettait en jeu est remplacée ; l'imprécision (le CR2
  des polynucléaires) est dite dans l'explication.
- **`rimm-qc-organes` B** — « site d'origine des leucocytes » reste vraie,
  comme la diapositive, avec un ATTENTION : le thymus fait mûrir et
  sélectionne les LT, il ne produit pas les leucocytes.
- **L'indice de forme** — 34 QRM sur 38 avaient trois ou quatre vraies. Sept
  passent à deux vraies (`rimm-qc-antigene`, `-tcr`, `-fab-fc`, `-ac-virus`,
  `-memoire`, `-vaccins`, `-primo-rappel`), une vraie devenant un piège du
  même champ, justifié ; deux QRU (`rimm-qc-ros`, `rimm-qc-haplotype`) ont
  maintenant A pour réponse.
- **Polymorphisme** — laissé à `remed_gene_proteine` (voir Le lexique).
- **Le nombre de pages du sujet** : `src-remed-ti2-2425` dit 10 pages, à
  l'identique dans `remed_pharmaco`.

## Régénérer

```powershell
cd contenu\chapitres\remed_immuno
..\..\..\app\.venv\Scripts\python.exe generer.py
```

Les figures sont versionnées dans `media/` (une diapositive entière par fichier,
900 px, 256 couleurs) ; chacune dit sa page dans `IMAGES`. Les planches se
refont avec `planche_depuis_pdf.py` et les options ci-dessus.
