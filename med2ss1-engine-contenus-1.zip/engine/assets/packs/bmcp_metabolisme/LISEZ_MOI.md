# Métabolisme général cellulaire — paquet BMCP

81 notes. Premier chapitre de l'UE **BMCP**, Pr P. Pigny, cours des 22 et
23/09/2026 (semaine 3). Les sources :

- **les trois ronéos 2026-27** (Ronéo & Juliette), qui font foi et
  s'affichent Partie 1, 2 et 3 :
  « La cellule, un carrefour du métabolisme » (22/09, 8 h-9 h, 12 p.,
  `src-fc-bmcp-carrefour`), « Métabolisme général cellulaire 1 » (22/09,
  9 h-10 h, 10 p., `src-fc-bmcp-mgc1`) et « Métabolisme général cellulaire 2 »
  (23/09, 8 h-8 h 30, 6 p., `src-fc-bmcp-mgc2`) — cités « carrefour »,
  « MGC 1 » et « MGC 2 » dans les cartes ;
- le ronéo 2024-25 (Ronéosaure, FC n°1, 20 p., `src-cours-metabo`), sur lequel
  le chapitre avait été bâti le 22/09 ;
- cinq polycopiés d'annales du Ronéosaure — métabolisme général cellulaire,
  énergétique, glucidique, protéique, lipidique — et leurs deux erratas. Un
  recensement contradictoire de ces sources est résumé dans `RECENSEMENT.md` ;
- le sujet de l'examen du 09/01/2025 (`src-sujets-bmcp-2425`, « Sujets de BMCP
  2024/2025, session 1 », 30 p.), déposé le 15/10/2026 **sans corrigé** : ses
  Q. 13 et Q. 14, du Pr Pigny, le citent par `SRC["sessions"]`, comme les
  autres chapitres de BMCP ; la source est déclarée à l'identique dans tous les
  chapitres de BMCP qui en cartent une question.

| Type | Nombre | Ce que c'est |
|---|---|---|
| `qrm` | 44 | 32 QCM d'annales (22 du métabolisme général, 8 des polycopiés Huin, 2 du sujet 2024/2025), 4 quizz corrigés du cours 2026-27, 5 QCM corrigés du cours 2024-25, 3 QCM du cours 2026-27 |
| `cloze` | 12 | les chiffres et les listes qui se récitent (63 trous) |
| `qroc` | 11 | 8 questions du cours, 3 QROC d'annales |
| `basic` | 9 | les couples à ne pas inverser |
| `zone` | 4 | les schémas cliquables (36 zones) |
| `legend` | 1 | le schéma de l'activation d'un acide gras, à remplir (8 numéros) |

Pas encore de lexique. Le générateur est le modèle depuis le 19/10 : une liste
`LEXIQUE` en fin de `donnees.py` suffira à le construire.

## Relu sur le cours de l'année (28/09/2026)

Chaque note a été relue contre les trois ronéos 2026-27, texte et figures.
Même enseignant, même matière, en trois ronéos : 28 pages aérées, contre
20 pages denses en 2024-25. Le cours perd la synthèse des acides gras (passée
au cours 2026-27 de métabolisme lipidique du Pr Benlian) et l'anaplérose
nommée, gagne la plasticité métabolique, les transporteurs, la chaîne
respiratoire illustrée et la clinique de l'oncométabolisme.

Une note vérifiée porte `page` et `fiche` dans `donnees.py` ou `annales.py` :
une note de cours cite alors ce ronéo à cette page (42 notes), une annale en
fait sa source secondaire (26 annales sur 35). Aucune note n'a été retirée,
aucun identifiant ni aucun type n'a changé, aucune clé d'annale n'a bougé. Le
générateur a gagné juste ce qu'il faut pour cela, comme celui de
`sang_souches` : `page`/`fiche`, `ABSENTS_2026`, la source secondaire, et un
troisième élément de `IMAGES` qui nomme la fiche d'une figure.

Ce qui a changé dans le cours, et ce que les cartes en font :

| Point | 2024-25 | 2026-27 | Cartes |
|---|---|---|---|
| Moyens d'éviter anabolisme et catabolisme simultanés | trois : compartimentation, hormone, voies différentes | deux : régulation à l'opposé (insuline), compartimentation, « très souvent utilisée » (carrefour p. 3) | `met-qr-trois-facons` réécrite : elle demande la compartimentation, et sa réponse cite les deux moyens de 2026-27 et le troisième de 2024-25 |
| Flexibilité | hématie « +++ » inflexible ; neurones : glucose, corps cétoniques, lactate ; muscle « au travail » | hématie non flexible ; neurones : glucose, corps cétoniques ; muscle « omnivore » (carrefour p. 5) | `met-fa-flexibilite` réécrite |
| Plasticité métabolique | définie en passant | deux concepts « complètement différents », récapitulés côte à côte (carrefour p. 4, 10) | nouvelle carte `met-rv-plasticite` |
| Rendement | 4 ATP directs, 28 indirects | idem, 32 en tout, « 38 en théorie » ; NAD ← niacine, FAD ← vitamine B2 (figures p. 6-7) | `met-fa-rendement` gagne un trou (32) |
| Glycolyse | bilan pas à pas | trois réactions irréversibles, figure (carrefour p. 11) | nouvelle carte `met-fa-glycolyse` |
| Néoglucogenèse | trois compartiments, tableau de perméabilité | « le véritable précurseur du glucose est le lactate » ; transporteurs MPC et CIC, navette OGC ; glucose-6-phosphatase du « RE (foie / intestin / rein) » (MGC 1 p. 2-4) | nouvelles cartes `met-qr-precurseur-ngg`, `met-co-navettes` ; la figure p. 4 appuie désormais l'ATTENTION « le foie n'est pas le seul organe à libérer du glucose » |
| Pools de NAD | séparés | séparés, mais un transporteur « encore discuté » a été décrit (MGC 1 p. 2) | explications de `met-fa-permeabilite`, `met-co-navettes` |
| Acides gras | activation, CPT, β-oxydation, corps cétoniques, lipogenèse (FAS, malonyl-CoA) | activation (ATP → AMP + PPi, figure), CPT, β-oxydation, corps cétoniques ; plus de lipogenèse, passée au cours de métabolisme lipidique (MGC 1 p. 6-8) | `met-co-quizz3` cite MGC 1 p. 6, et le cours lipidique 2026-27 pour la FAS et le malonyl-CoA (p. 7-9) ; seule sa proposition E (le malonyl-CoA inhibe CPT1) vient de 2024-25, et le dit ; la zone « cpt » de `met-zo-carnitine` ne demande plus « l'enzyme inhibée par le malonyl-CoA » mais celle qui greffe la carnitine |
| Cycle de Krebs | enzymes en partie nommées | sept étapes avec leurs enzymes (MGC 1 p. 9), figure avec les huit enzymes et l'ALAT, l'ASAT, la glutaminase (p. 10) ; « il faut connaître le schéma » (p. 8) | `met-zo-krebs-enz`, `met-zo-krebs-meta`, `met-an-1819-q1` : les noms d'enzymes sont maintenant sourcés |
| Anaplérose | le mot, sa définition, la glutamine | la glutamine « se branche directement sur le cycle », sans le mot | `met-qr-anaplerose` marquée absente |
| Chaîne respiratoire | cinq complexes | idem, figure des protons pompés ; cyanure ; fuites d'électrons et ROS (MGC 2 p. 2) | nouvelle carte `met-co-mitochondrie` |
| AMPK | inhibe mTORC1 | charge énergétique = (ATP + ½ ADP) / (ATP + ADP + AMP) ; captation du glucose, glycolyse, β-oxydation, autophagie ; mTORC1 n'est plus nommé (MGC 2 p. 3) | `met-rv-ampk` réécrite ; nouvelle carte `met-fa-charge` |
| Oncométabolisme | Warburg, LDH, mitochondries fonctionnelles, TEP | idem, plus l'avidité pour la glutamine, le 2-désoxyglucose, les inhibiteurs de glutaminase et de MCT1/MCT4 (MGC 2 p. 3-4) | nouvelle carte `met-co-onco-clinique` |
| Quizz du cours | cinq QCM corrigés | quatre quizz corrigés (carrefour p. 7-8, MGC 1 p. 5 et 8, MGC 2 p. 5) | nouvelles cartes `met-co-2627-quizz1` à `quizz4`, `officielle` ; les cinq de 2024-25 restent, leur énoncé dit leur année |

Dix-sept figures des ronéos 2026-27 sont extraites en PNG dans `media/`
(`carrefour-*`, `mgc1-*`, `mgc2-*`), déclarées dans `IMAGES` avec leur page et
leur fiche. Elles illustrent la correction, jamais la question. 32 des 42 QCM
sont illustrés ; les dix qui ne le sont pas portent sur la nutrition, les
relations inter-organes, le métabolisme protéique et la lipolyse, que ces
figures ne montrent pas.

## Les ATTENTION de ce chapitre

Le ronéo 2026-27 ne sera pas corrigé, et le tableau des erreurs de BMCP
n'existe pas encore : les erreurs relevées sont portées par les cartes, là où
elles se jouent, et par `contenu/ERRATA_RONEOS_2026-27.md`. La clé d'aucun
quizz n'en dépend. À l'examen, on répond d'abord comme le professeur (règle de
Vincent, 28/09) : chaque erreur a donc été triée, preuves à l'appui, entre une
prise de notes fausse du ronéo (le tableau ci-dessous) et le cours lui-même
(le tableau suivant).

| Ronéo 2026-27 | Ce qu'il écrit | Ce qui est juste | Carte |
|---|---|---|---|
| carrefour p. 3 | l'insuline, « hormone qui favorise le stockage », va « donc bloquer les réactions anaboliques » | stocker, c'est de l'anabolisme : elle bloque la mobilisation des réserves (« inhibiteur de la lipolyse », MGC 1 p. 8) et, dans la paire glycolyse/néoglucogenèse, active la voie catabolique et freine l'anabolique (cours 2024-25, p. 9) ; le professeur disait qu'elle joue « sur des réactions d'anabolismes et de catabolismes de manière opposée » (p. 2) | `met-co-quizz2` (C), `met-qr-trois-facons`, `met-rv-insuline` |
| carrefour p. 7 | sur les 32 ATP, « 4 qui proviennent de la glycolyse » | 2 de la glycolyse, 2 du cycle de Krebs (GTP) — sa propre figure | `met-fa-rendement` |
| carrefour p. 8 | la glycolyse seule libérerait « 4 ATP sur les 32 » | 2 ATP nets (carrefour p. 11) | `met-co-mitochondrie` (E) |
| carrefour p. 8 | dans une voie métabolique, « chacune de ces réactions [...] fonctionne avec un coenzyme d'oxydoréduction » | une seule réaction de la glycolyse en utilise un (figure p. 11) | `met-fa-glycolyse` |
| carrefour p. 11 | « les réactions irréversibles sont associées à la consommation d'ATP » | pas la pyruvate kinase, qui en produit | `met-fa-glycolyse` |
| MGC 1 p. 2 | le citrate, « molécule à 6 carbones et 3 COH » | trois carboxyles, COOH | `met-co-navettes` (E) |
| MGC 1 p. 4 | la pyruvate carboxylase fait passer « d'un dérivé à 4 atomes de carbone » à l'oxaloacétate | le pyruvate a 3 carbones (la figure de la page le dit) | `met-qr-precurseur-ngg` |
| MGC 1 p. 5 | à l'effort, « le glucose va être créé surtout par la glycolyse » | c'est l'ATP qu'elle produit, en consommant le glucose | `met-co-2627-quizz2` (explication) |
| MGC 1 p. 8 | « la formation des corps cétoniques empêche la libération de protons » | elle en libère — d'où l'acidose ; la figure p. 7 montre le H+ | `met-qr-corps-cetoniques`, `met-co-2627-quizz3` (B), `met-an-2223-q11` (D) |
| MGC 1 p. 8 | l'acétyl-CoA en excès « surcharge le système de la bêta oxydation » | il surcharge le cycle de Krebs (p. 7) | `met-co-2627-quizz3` (A) |
| MGC 1 p. 8 | quizz C : « sont libérés ainsi qu'un NADH2 et un FADH2 » | un mot manque : un acétyl-CoA | `met-co-2627-quizz3` (C) |
| MGC 1 p. 9 | « à chaque fois qu'on libère un acide dans la bêta oxydation on réalise un tour » | chaque acétyl-CoA fait un tour de cycle | `met-fa-bilan-krebs` |
| MGC 2 p. 2 | « les coenzymes réduisent le NADH et le FADH2 » | le NADH et le FADH2 sont réoxydés, ils cèdent leurs électrons | `met-fa-chaine` |
| MGC 2 p. 3 | l'autophagie, « mécanisme d'endocytose » | deux mécanismes distincts | `met-rv-ampk` |
| MGC 2 p. 4 | les cellules tumorales utilisent peu le cycle de Krebs « pour synthétiser le glucose » | pour oxyder le pyruvate | `met-rv-warburg` |
| MGC 2 p. 4 | le 2-désoxyglucose « bloque le passage de glucose à travers la membrane » | imprécis : il entre lui-même par les GLUT, en concurrence avec le glucose, et bloque surtout la glycolyse (Pajak et al., Int J Mol Sci 2019) — point douteux, pas une erreur prouvée | `met-co-onco-clinique` (B) |

**C'est le cours lui-même.** La formule vient du professeur — son quizz, son
cours des années précédentes, les clés d'annales —, et le ronéo la rapporte
fidèlement. La carte répond comme lui, et son `ATTENTION` dit, dans l'ordre,
« c'est le cours lui-même » et d'où vient la formule, « À l'examen : » ce qu'on
répond, puis « La référence : » le fait juste et sa source.

| Ronéo 2026-27 | Ce qu'il écrit | D'où vient la formule | À l'examen | La référence | Carte |
|---|---|---|---|---|---|
| carrefour p. 6 | la glycolyse se déroule « en milieu anaérobie (= en absence d'oxygène) » | la correction du quizz du Pr Pigny (carrefour p. 8) ; le cours 2024-25, « en absence d'oxygène, donc privilégiée lors d'hypoxie » (FC n°1, p. 4) ; les clés d'annales (2018-2019 Q. 2 B, 2017-2018 S1 Q. 2 B, 2020-2021 S1 Q. 2 B selon l'errata) | glycolyse « anaérobie », vrai ; « aérobie », faux ; mais l'effet Warburg est la « glycolyse aérobie » | elle n'a pas besoin d'oxygène mais tourne aussi en sa présence (MGC 2 p. 3, « condition aérobie » ; StatPearls, *Biochemistry, Glycolysis*) | `met-co-2627-quizz1` (A), `met-ech-s2` (B) |

Une nuance hors cours, signalée sans toucher la réponse attendue : les bornes
C6-C22 de la navette carnitine (MGC 1 p. 6 et 8) sont celles du professeur ;
l'entrée des acides gras moyens sans carnitine dépend en réalité du tissu
(Pereyra et al., *Am J Physiol Gastrointest Liver Physiol* 2023). La carte
`met-fa-carnitine` le dit et fait répondre C6-C22.

Points douteux relevés sans carte, parce qu'aucune n'y touche : les crampes
attribuées à l'acide lactique (MGC 1 p. 4-5, idée que la physiologie de
l'exercice ne retient plus : Miller et al., *Sports Health* 2010), la voie
des pentoses qui « synthétise » acides aminés et acides gras (MGC 2 p. 4 : elle
fournit le ribose-5-phosphate et le NADPH2 ; les acides aminés de la figure
viennent de la voie de la sérine, branchée sur le 3-phosphoglycérate), et « la
même enzyme » pour les deux malate déshydrogénases, mitochondriale et
cytosolique (MGC 1 p. 3). Un quatrième, relevé le 19/10, a ses cartes : la LDH,
« première étape » de la néoglucogenèse (MGC 1 p. 4), alors que la première
étape à partir du pyruvate est mitochondriale (`met-ech-s17`, `met-an-2021s2-q1`).

Écartée après vérification : le ronéo introduit le CIC « pour la
néoglucogenèse » (MGC 1 p. 2). Ce n'est pas une erreur démontrée — le citrate
cytosolique active la fructose-1,6-bisphosphatase de la néoglucogenèse, et
inhiber le CIC freine la néoglucogenèse (Mosaoa et al., *Biomolecules* 2021).
Les cartes `met-co-navettes` et `met-fa-permeabilite` disent seulement ce que le
cours en décrit : la sortie du citrate vers les acides gras et le cholestérol,
et le malate pour la néoglucogenèse.

Deux erreurs du ronéo 2024-25, corrigées dans les cartes : l'activation d'un
acide gras « de l'ATP à l'ADP » (c'est l'AMP, figure MGC 1 p. 6 ; `met-qr-palmitate`)
et les « 8 tours × 2C » du palmitate (sept tours, huit acétyl-CoA ;
`met-co-quizz3`).

## Absent du cours 2026-27

Une carte est **gardée telle quelle** — rien dans les ronéos 2026-27 ne la
contredit — et porte le tag `absent-2026` ; son explication commence par
« Absent du cours 2026-27 : il n'y a pas de version 2026-27 de cette carte ;
elle vient du cours 2024-25 (FC n°1, Ronéosaure) ». À Vincent de décider s'il
la garde.

| Carte | Ce qui est absent | Ce que 2026-27 en garde |
|---|---|---|
| `met-qr-anaplerose` | le mot « anaplérose » et sa définition, dans tous les ronéos 2026-27 de BMCP | la glutamine qui « se branche directement sur le cycle » (carrefour p. 4, 10 ; figure MGC 1 p. 10) |

`met-co-quizz3` (β-oxydation du C16, FAS, malonyl-CoA, carnitine) avait
d'abord été marquée absente ; la relecture l'a rendue au cours de l'année : sa
β-oxydation et ses bornes C6-C22 sont dans MGC 1 (p. 6-8), sa FAS et son
malonyl-CoA dans le cours 2026-27 de métabolisme lipidique (Pr Benlian, p. 7-9).
Elle cite MGC 1 p. 6 ; seule sa proposition E vient de 2024-25.

Détails de 2024-25 gardés dans des cartes par ailleurs vérifiées, et dits dans
leur justification : le malonyl-CoA qui inhibe CPT1 (`met-co-quizz3` E, zone
« cpt » de `met-zo-carnitine`), mTORC1 (`met-rv-ampk`, `met-an-1718s2-q1` C), l'insuline
qui active la PDH (`met-qr-pdh-vs-pc`, `met-rv-insuline`), le lactate des
neurones (`met-fa-flexibilite`), le peroxysome au-delà de C22 et l'entrée libre
en deçà de C6 (`met-fa-carnitine`, zone « acyl-cyt »), les glioblastomes et
leucémies aux mitochondries touchées (`met-co-quizz5`, `met-rv-warburg`), la
glutamine « acide aminé le plus concentré du sang » (`met-rv-glutamine`), le
mot « amphibolique » (`met-qr-amphibolique`, dont le cours 2026-27 garde l'idée,
MGC 2 p. 5).

## Hors du cours du Pr Pigny

Deux cartes de cours (`met-rv-lipolyse`, `met-rv-substrats`) et neuf annales
(`met-an-2223-q16`, `-q17`, `-q18`, `met-an-2324-q15`, `-q16`, `-q17`,
`met-an-1920s1-q30`, `met-an-1920s2-q9`, `met-an-1718s1-q7`) portent sur la
nutrition, les relations inter-organes, le métabolisme protéique ou la
lipolyse : la matière des cours du Pr Huin (2024-25). Les ronéos 2026-27 du
Pr Pigny n'en parlent pas ; ce ne sont donc pas des cartes « absentes » de son
cours, et elles ne portent pas de page. Leur polycopié reste leur source (le
ronéo 2024-25 pour les deux cartes de cours). La lipolyse est vérifiée sur le
cours 2026-27 de métabolisme lipidique (Pr Benlian, p. 6 et 9-10), que leur
explication cite ; les autres attendent les cours de nutrition 2026-27.

## Le cycle de Krebs se clique deux fois

Le comptage des annales ne laisse pas le choix : **quinze des vingt-deux QCM du
polycopié du métabolisme général touchent au cycle ou à ce qui s'y branche**,
et le cours 2026-27 le dit : « il faut connaître le schéma du cycle de Krebs
(dérivés) » (MGC 1 p. 8). Le cycle a donc deux cartes de repérage, sur deux
fichiers qui partagent les mêmes constantes d'anneau :

* `krebs-metabolites.svg` — les huit intermédiaires **plus l'entrée de
  l'acétyl-CoA**, dans l'ordre de rotation. Neuf zones, jouées d'un bloc.
* `krebs-enzymes.svg` — le même anneau, mais ce sont les **huit réactions** qui
  portent les zones. Le cours 2026-27 nomme chaque enzyme (MGC 1 p. 9, figure
  p. 10) ; la « fumarase » du texte est la fumarate hydratase de la figure.

Les deux autres schémas répondent à des questions posées telles quelles :
`compartiments.svg` est le QROC 1 de 2023-2024 et la plateforme commune du
carrefour (p. 4) ; `carnitine.svg` redessine la navette de la figure MGC 1 p. 6.

## Le schéma de l'activation se remplit (29/09)

Sous la figure de l'activation d'un acide gras, le ronéo écrit : « schéma vide
mis sur moodle (être capable de le remplir totalement pour être prêts en
examen) » (MGC 1 p. 6). Vincent l'a demandé en carte le 29/09 : c'est la
planche à légender `met-pl-activation`, la seule du chapitre.

- **La question** est la figure du ronéo, légendes effacées et remplacées par
  huit numéros : `mgc1-activation-acide-gras-numerotee.png`. Les formules
  restent, et les deux cadres aussi — celui de l'enzyme et celui, rouge, de
  l'ATP —, vides comme sur un schéma distribué.
- **Les huit légendes** : C6-C22 (en rouge sur la figure), acide gras, CoA-SH,
  ATP, acyl-CoA synthétase, Mg²⁺, AMP + PPi, acyl-CoA. Chaque numéro a sa
  phrase, qui dit ce qu'est la molécule et avec quoi on la confond.
- **Neuf intrus** du même champ : ADP + Pi (l'erreur du ronéo 2024-25), GTP,
  Ca²⁺, acétyl-CoA, carnitine, CPT1, thiolase, et deux autres longueurs de
  chaîne, C2-C4 et C24-C26.
- **La correction** est la figure du ronéo telle qu'imprimée,
  `mgc1-activation-acide-gras.png`, qui illustrait déjà `met-qr-palmitate`.

La figure est une image (une capture de la diapositive) et non du texte PDF :
`planche_depuis_pdf.py` n'a rien à y lire. Chaque numéro de `PLANCHES` porte
donc le rectangle à blanchir (`efface`) et la place de son numéro (`x`, `y`),
en pixels de l'image, et `scripts/planche_depuis_image.py` du skill en tire
l'image numérotée et un aperçu de contrôle, relu avant d'écrire la carte :
rien ne reste des légendes, et aucune flèche n'est entamée. Le générateur a
gagné, pour elle, le code des planches du modèle, repris sans changement ; le
chapitre, lui, n'est passé au modèle que le 19/10 (voir « Régénérer »).

## Les treize clés qui ne font pas foi

Six clés imprimées ne sont pas bonnes, les polycopiés laissent en outre cinq
questions sans aucune clé, et le sujet de 2024/2025 en ajoute deux, publié sans
corrigé. Les treize cartes concernées portent
`cle_officielle: false`, et **la justification de la proposition en cause
contient ATTENTION**, dit pourquoi et cite sa source — le générateur refuse
d'écrire si un conflit déclaré n'est pas signalé là où il se joue. Une clé
absente de la table le dit dans l'explication : « clé déduite du cours ». Les
trois QROC d'annales n'ont pas de clé écrite (« voir schéma cours ») et le
disent aussi.

La règle est celle de Vincent (26/09) : **la clé retenue est la bonne, pas la
clé imprimée**. L'énoncé reste tel qu'il est imprimé. La relecture du 28/09
n'a changé aucune de ces clés ; elle les appuie sur le cours 2026-27.

| Question | Clé imprimée | Retenu ici | Pourquoi | Source |
|---|---|---|---|---|
| 2020-2021 S1 Q.1 | AB | **A** | B place le FADH2 à l'IDH ; c'est la succinate déshydrogénase | MGC 1 p. 9 ; StatPearls, *Physiology, Krebs Cycle* |
| 2020-2021 S1 Q.2 | CE | **BCD** | B (glycolyse cytosolique anaérobie) et D (la LDH régénère le NAD+) sont dans le cours ; E fait produire la majorité de l'ATP par la glycolyse | carrefour p. 7-8 ; MGC 1 p. 5 ; MGC 2 p. 5 ; StatPearls, *Anaerobic Glycolysis* |
| 2019-2020 S2 Q.8 | ABD | **AB** | le muscle n'a pas de glucose-6-phosphatase | MGC 1 p. 4 (figure) ; StatPearls, *Glycogenolysis* |
| 2017-2018 S1 Q.1 | BD | **B** | D écrit « NADPH,H+ » au lieu de NADH,H+ | MGC 1 p. 9 ; carrefour p. 7 |
| 2017-2018 S1 Q.8 | ABC | **BC** | A fait du foie le *seul* organe qui libère du glucose ; le rein (15 à 20 % à jeun) et l'intestin (5 à 7 %) en libèrent aussi. Le cours du Pr Huin dit « seul » ; la figure du cours 2026-27 du Pr Pigny place la glucose-6-phosphatase dans le « RE (foie / intestin / rein) » | MGC 1 p. 4 ; Vily-Petit, Gautier-Stein, Mithieux, *médecine/sciences* 2025 ; Gerich, *Diabetes Care* 2001 |
| 2017-2018 S2 Q.1 | B | **BDE** | D (le glutamate réalimente le cycle en oxaloacétate) et E (G6P carrefour) sont dans le cours ; l'errata relève E | MGC 1 p. 10 ; carrefour p. 9 ; Owen, Kalhan, Hanson, *J Biol Chem* 2002 ; Rajas et al., *Metabolites* 2019 |
| 2022-2023 Q.12 | *aucune* | **BD** | proposition de l'errata, vérifiée item par item | MGC 1 p. 8-9 ; carrefour p. 7-8 |
| 2019-2020 S2 Q.9 | *aucune* | **BDE** | l'errata propose BE ; D est la définition de la transamination | Holeček, *Nutr Metab* 2018 ; Sorbonne Université, « Les réactions de transamination » ; Cruzat et al., *Nutrients* 2018 |
| 2022-2023 Q.16 | *aucune* | **CDE** | le cours (50 %, protéines « très peu mobilisables ») et la question 15 de 2023-2024, qui a une clé | cours (énergétique, 2024-25) p. 3 ; ANSES 2016 |
| 2022-2023 Q.17 | *aucune* | **AD** | le cours, mot pour mot | cours (glucidique, 2024-25) p. 2 et 6 ; ANSES 2016 |
| 2020-2021 Q.1 / Q.8 | *aucune* | **E** | le seul doublon réel du bloc ; C (« le foie est le seul organe… ») est fausse pour la même raison que 2017-2018 S1 Q.8 A | MGC 1 p. 4 ; Vily-Petit et al., *médecine/sciences* 2025 ; Gerich, *Diabetes Care* 2001 |
| 2024-2025 Q.13 | *aucune* (sujet sans corrigé) | **CDE** | A, la cétogenèse est hépatique ; B, l'insuline inhibe la lipolyse ; C, l'acétone gagne les poumons par le sang (l'item le moins explicite : l'ATTENTION « sans clé » y est posée, conflit déclaré) ; D, l'excès d'acétyl-CoA ; E, la cétose | carrefour p. 4 ; MGC 1 p. 7-8 ; ronéo 2026-27 « Métabolisme énergétique » p. 6 |
| 2024-2025 Q.14 | *aucune* (sujet sans corrigé) | **CD** | A définit la plasticité, pas la flexibilité ; B, la néoglucogenèse coûte 6 ATP ; C, lactate et glycérol (ATTENTION « sans clé », conflit déclaré) ; D, le NADH au complexe I ; E, 2,5 ATP par NADH2, 1,5 par FADH2 | carrefour p. 4, 5, 8-10 ; MGC 1 p. 4 ; MGC 2 p. 2 |

Apprendre « la glycolyse produit la majorité de l'ATP » parce qu'une table de
corrections l'a imprimé serait pire que de ne rien apprendre. **Le cas du
« foie, seul organe à libérer du glucose » est le seul où la carte contredit
un cours** — celui du Pr Huin ; celui du Pr Pigny, en 2026-27, montre le rein
et l'intestin. La question reste posée à Vincent.

Un cas reste ouvert, **clé imprimée gardée** : 2019-2020 S2 Q.1 B, « la
pyruvate carboxylase oriente le pyruvate vers le cycle de Krebs », faux. Le
cours l'attache à la néoglucogenèse (MGC 1 p. 4-5) et la clé le suit ; mais la
pyruvate carboxylase est aussi la réaction anaplérotique type du cycle
(Lehninger). La justification B porte ATTENTION et le conflit est déclaré
(seizième de `CONFLITS`), sans que la carte perde sa clé officielle.

Un dix-septième conflit, déclaré le 28/09 : 2023-2024 Q.17 B, « les
périlipines sont activées par la signalisation induite par les récepteurs à
l'insuline », faux. La clé imprimée est gardée, et le ronéo 2026-27 du
Pr Benlian (p. 6) la confirme : l'insuline stabilise les périlipines par
déphosphorylation. Mais le cours 2024-25 (FC n°8, p. 4) écrivait « par
activation des périlipines ». La justification B porte l'ATTENTION.

Deux conflits encore, déclarés le 15/10 en tête de la liste : les Q. 13 et Q. 14
du sujet de 2024/2025, publié sans corrigé — leur ATTENTION « sans clé officielle »
est posée sur la proposition C, la moins explicite du cours.

Un vingtième, déclaré le 19/10 (C29), **clé imprimée gardée** : 2020-2021 S2 Q.1 D,
« la 1re étape de la néoglucogenèse a lieu dans la mitochondrie », vrai. Le ronéo
2026-27 appelle pourtant « la première étape » la LDH, qui fait le pyruvate à
partir du lactate, dans le cytosol (MGC 1 p. 4) ; à partir du pyruvate, c'est la
pyruvate carboxylase, mitochondriale (p. 2 ; quizz p. 5 D). La justification D
porte un `ATTENTION (douteux)`, comme la marche `met-ech-s17`, et la liste des
erreurs le range parmi les points douteux. `CONFLITS` en compte vingt ; les rangs
« seizième » et « dix-septième » ci-dessus sont ceux du 28/09.

## À relire : aucune carte

Les vingt-huit cartes que l'audit du 23/09 avait marquées `a-relire` ont été
reprises une à une le 28/09, et le tag est retiré de toutes :

| Dossier de l'audit | Cartes | Ce qui l'a tranché |
|---|---|---|
| Noms d'enzymes que le ronéo 2024-25 n'écrivait pas (SDH, fumarate hydratase, α-cétoglutarate déshydrogénase) | `met-an-1819-q1`, `met-zo-krebs-meta`, `met-zo-krebs-enz`, `met-an-2021s2-q2` | le cours 2026-27 les nomme (MGC 1 p. 9-10) ; le complexe II est cité à part, avec sa référence |
| Sept ou huit tours de β-oxydation, activation à 1 ou 2 ATP (106, 107 ou 110) | `met-co-quizz3`, `met-qr-palmitate`, `met-fa-carnitine`, `met-zo-carnitine` | sept tours, huit acétyl-CoA, activation ATP → AMP (figure MGC 1 p. 6) : 106 ATP, le total que donne le cours 2026-27 de métabolisme lipidique (Pr Benlian, p. 11) |
| Réponses de QROC trop longues pour être tapées | `met-qr-anaplerose`, `met-qr-corps-cetoniques`, `met-qr-trois-facons`, `met-qr-g6p`, `met-anq-2122-qroc2`, `met-anq-1718-qroc1`, `met-anq-2324-qroc1` | réponses courtes en `exactes`, plusieurs formulations ; `met-qr-g6p` et `met-qr-trois-facons` ne posent plus qu'une question |
| Le rein, absent du cours | `met-an-1718s1-q8`, `met-an-2021s1-q8`, `met-rv-inter-organes` | la figure MGC 1 p. 4 : glucose-6-phosphatase du « RE (foie / intestin / rein) » |
| Anaplérose attribuée à l'aspartate → glucose | `met-co-quizz4` | justification B réécrite : l'oxaloacétate qui part vers le glucose quitte le cycle |
| Provenances inexactes | `met-an-1920s1-q30`, `met-zo-compartiments`, `met-an-1718s2-q1` | réécrites : la session voisine n'a pas de clé ; un seul QROC sur le G6P ; le C16 est un item du quizz 2026-27 ; l'errata ne relève que l'item E |
| Substrats de la néoglucogenèse, argument hors sujet | `met-an-2223-q11`, `met-an-1920s2-q8` | le lactate, « véritable précurseur » (MGC 1 p. 4), les acides aminés glucoformateurs et le glycérol, pas les acides gras ; l'argument des vitamines remplacé |
| Corps cétoniques « du tissu adipeux » | `met-fa-corps-cetoniques` | « une propriété des hépatocytes dans leur mitochondrie » (carrefour p. 4) ; la phrase de 2024-25 est dite inexacte |
| Pyruvate carboxylase et anaplérose | `met-an-1920s2-q1` | la nuance remonte dans la justification B, signalée ATTENTION, conflit déclaré (cas ouvert, clé gardée) |
| Doublon | `met-fa-ordre-krebs` | pas une faute : le cloze fait réciter, la zone fait cliquer |
| 35, 40 ou 50 % de la ration | `met-an-2223-q17` | le cours 2024-25 dit 50 % (FC n°5) et 50 à 60 % (FC n°6) |

## Une remarque du ronéo 2024-25 que je n'ai pas cartée telle quelle

Le ronéo 2024-25 écrit une fois « la protéine la plus abondante au niveau du
sang est la glutamine ». La glutamine est un acide aminé, pas une protéine, et
les annales posent toujours la question sous la forme « l'acide aminé sanguin
le plus abondant ». La carte retient la formulation des annales, et la note le
signale.

## Le thème `regulation` était déjà pris

`THEME_LABELS` attachait déjà `regulation` à « Régulation de l'hématopoïèse »,
pour le Tissu sanguin. Un tag n'a qu'un libellé : la régulation métabolique de
ce chapitre porte donc `charge-energetique`, et non `regulation`. Aucun thème
nouveau n'a été ajouté le 28/09.

## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier. Sous les annales, 55 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 15 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `generalites` | 4 | 2 | 2 |
| `glucose` | 9 | 2 | 6 |
| `krebs` | 11 | 4 | 9 |
| `lipides` | 11 | 2 | 4 |
| `proteines` | 8 | 2 | 4 |
| `charge-energetique` | 1 | 1 | 1 |
| `nutrition` | 11 | 2 | 9 |

**Les schémas** sont au nombre de 2 : `ech-metabolisme`, « Le métabolisme cellulaire · un carrefour » (40 Simple, 13 Moyen, 26 annales ; 80 fichiers), et `ech-metabolisme-assiette`, « L'assiette et l'adipocyte · nutriments, régimes, lipolyse » (15 Simple, 2 Moyen, 6 annales ; 24 fichiers). Une carte ou une annale va au schéma de son mécanisme. Ils sont décrits dans `schemas.py` (`ECH_METABOLISME`, `ECH_METABOLISME_ASSIETTE`, avec leurs `TROUS_*` et `LETTRES_*`, un `FICHIERS.update` chacun) et dessinés par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Deux schémas, deux moitiés** (C29, 19/10) : le critique a ajouté la seconde, `ech-metabolisme-assiette`, pour les six annales du Dr Huin et du Pr Benlian que le chapitre héberge (2022/2023 Q. 16-18, 2023/2024 Q. 15-17). Leurs faits sont dans les ronéos 2026-27 des chapitres frères : l'exception du schéma nu ne valait donc pas. Elles quittent le premier schéma.

**Sources déclarées en plus** : `src-fc-bmcp-ene-2627`, `src-fc-bmcp-glu-2627`, `src-fc-bmcp-prt-2627` et `src-fc-bmcp-lipides`, à l'identique de `bmcp_energetique`, `bmcp_glucides`, `bmcp_proteines` et `bmcp_lipides`, pour `met-ech-s41` à `met-ech-s55`, `met-ech-m14` et `met-ech-m15`. Le chapitre n'a pas de fiche par défaut (`SRC` sans `fiche`) : chaque marche nomme la sienne.

**`annales.py`** : `_SCHEMA_LETTRES` et `_SCHEMA_NU` sont posées avant la première liste `ANNALES` ; la seconde, qui donne aux questions du Dr Huin leur `SessionDuPolycopie`, recopie chaque annale avec son `diagramme=`.

**32 ou 38 ATP** : le Pr Pigny compte 32 ATP par glucose, le Dr Huin 38 (ronéo 2026-27 de métabolisme énergétique, p. 7, 8 et 10). Le schéma ne l'écrit plus (« ATP du glucose : surtout indirect ») ; `met-ech-s39` et `met-ech-m12` le disent par un ATTENTION.

**Erreurs du ronéo** : `met-ech-s2` porte l'`ATTENTION (cours)` de la glycolyse « anaérobie » ; `met-ech-s17` un `ATTENTION (douteux)` sur la LDH « première étape », reporté sur la 2020-2021 S2 Q.1 D (vingtième conflit) et dans la liste des erreurs.

**Sans marche** :
- met-an-2021s1-q8 A, B : A (glucides < 20 %) est préparée par met-ech-s41, sur le schéma de l'assiette, mais non posée : l'annale garde le schéma du métabolisme, où se jouent C, D et E ; B (« ammoniaque » de l'oxydation du glucose) n'est écrit dans aucun cours, et les glucides ne portent que C, O et H (métabolisme glucidique 2026-27, p. 2)
- met-an-2324-q14 E : l'ammoniac, « particulièrement toxique pour le système nerveux central », détoxifié en urée par le foie, est dans le ronéo 2026-27 de métabolisme des protéines (Dr Huin, p. 10 ; chapitre bmcp_proteines), pas dans ceux du Pr Pigny ; le schéma du métabolisme n'a pas de case pour l'azote
- met-an-1920s1-q30 B, C, D : B (acides aminés branchés) et C (leptine « hormone hépatique ») ne sont dans aucun cours de l'année ; D (urée produite par le foie) est dans le ronéo 2026-27 de métabolisme des protéines (p. 4 et 10 ; bmcp_proteines), hors des sources de ce chapitre
- met-an-1920s2-q9 B, C : B (acides aminés branchés ; conflit déclaré, clé déduite de Holeček 2018) dans aucun cours ; C (insuline « hormone hépatique ») : le cours de l'insuline la dit « hormone polypeptidique pancréatique » (partie 1, p. 2 ; bmcp_insuline), hors des sources de ce chapitre
- met-an-1718s1-q7 C, D, E : C (graisses > 50 %) est préparée par met-ech-s41, mais non posée, puisque l'annale garde le schéma du métabolisme ; D (urée hépatique) : ronéo 2026-27 de métabolisme des protéines, p. 4 et 10 ; E (chylomicrons, intestinaux) : ronéo 2026-27 de métabolisme lipidique, p. 4 (bmcp_lipides)
- met-an-1718s2-q8 E : captation des triglycérides par le tissu adipeux, dans le ronéo 2026-27 de métabolisme lipidique (Pr Benlian, p. 6 ; bmcp_lipides), hors des sources de ce chapitre
- met-an-2021s2-q1 E : rapport NADPH/NADP+ élevé du cytosol — dans aucun des deux cours du Pr Pigny (l'annale le dit, Lehninger)
- met-an-1920s2-q8 A, C : acides aminés alimentaires indispensables au métabolisme énergétique, captation du glucose cérébral indépendante de l'insuline — cours du Pr Huin, absent des sources
- met-an-1718s1-q2 A : rapports ATP/ADP et NADPH/NADP+ du cytosol — dans aucun des deux cours du Pr Pigny

## Régénérer

```
python generer.py
```

Le script écrit les quatre SVG, valide, et refuse d'écrire `paquet.json` s'il
trouve une erreur : ce sont les règles du générateur modèle. Une justification
par proposition ; un conflit déclaré, signalé là où il se joue ; une page dans
les pages de sa fiche ; une figure qui nomme une source déclarée ; une planche à
légender faite de deux images distinctes, de numéros de 1 à n sans trou, chacun
dans l'image, et d'au moins un intrus, qui n'est jamais une légende.

**Le générateur.** Depuis le 19/10/2026 (C29), `generer.py` est la copie exacte
du modèle du skill, pour que le chapitre puisse recevoir l'échelle Simple/Moyen.
Le bloc « le générateur modèle », en fin de `donnees.py`, déclare les sources
dans `SRC`. Il n'y a pas de `SRC["fiche"]` : chaque page nomme son ronéo.

Le modèle prend la source d'une annale par session (`SRC["sessions"]`). Or trois
sessions mêlent le polycopié du métabolisme général et celui du Pr Huin. Les
huit questions du Pr Huin gardent donc `source_id`, et le bloc de fin
d'`annales.py` fait de leur session une `SessionDuPolycopie` : la même chaîne,
qui garde sa source, et que `SRC["sessions"]` lit en premier.

Le paquet est resté le même, à trois écarts voulus près :
- l'indentation et la fin de ligne finale ;
- la légende des quatre schémas cliquables, désormais accentuée ;
- le tag `cours-2026-27`, que le modèle pose sur les 43 cartes de cours qui
  citent un ronéo de l'année. Les trois autres citent le ronéo 2024-25, dont
  la source ne dit pas son année : elles n'ont pas de tag.

Si les rectangles d'une planche changent, refaire l'image numérotée avant de
régénérer, depuis `app/` :

```
uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/bmcp_metabolisme met-pl-activation --apercus <brouillon>
```
