# Hippocampe sur un vrai chapitre : sémiologie cardiovasculaire normale

Exemple complet d'utilisation, construit à partir de vos deux fichiers réels :

| Fichier | Rôle | Contenu retenu |
|---|---|---|
| `FC n°4 - Sémiologie cardiovasculaire normale VIDUM 11 09 2026.docx` | le cours | 16 pages, 25 600 caractères de texte, 14 schémas laissés de côté |
| `Sémiologie cardiovasculaire normale.pdf` | les annales | 9 pages, 33 questions sur 17 sessions d'examen, corrections page 9 |

Trois fichiers produits :

- `demo_session.html` : une session de dix cartes, jouable au clavier. Ouvrez-la dans un navigateur.
- `paquet.json` : les 53 notes et 65 cartes au format d'import de l'application.
- `donnees.py` et `generer.py` : le contenu source et le script qui produit les deux fichiers ci-dessus.

Tout est en texte seul, comme demandé.

## 1. Ce que l'application a fait des deux fichiers

Le cours et les annales n'ont pas le même statut, et l'application ne les traite pas pareil.

Le cours produit des **cartes de connaissance**. Il donne les définitions, les valeurs chiffrées et les localisations. Vingt notes en sortent, sous quatre formats : question à réponse ouverte courte, texte à trous, recto/verso, et question à réponse unique.

Les annales produisent des **cartes au format examen**. Elles sont recopiées telles quelles, avec leur énoncé d'origine, leur année et leur numéro de question. Trente-trois notes, toutes en question à réponse unique ou multiple.

Les deux pointent vers leur source. Chaque question d'annales porte deux références : sa page dans le PDF des annales, et la page du cours qui contient la réponse. Le bouton « Voir dans le cours » de l'application utilise la seconde.

## 2. Ce que les annales disent, et qui ne se voit pas à la lecture

C'est le gain le moins attendu. En comptant les occurrences par thème sur dix-sept sessions, la hiérarchie des priorités apparaît.

| Thème | Questions posées en 9 ans |
|---|---|
| Auscultation cardiaque | 8 |
| Insuffisance cardiaque droite | 6 |
| Fraction d'éjection ventriculaire gauche | 6 |
| Facteurs de risque cardiovasculaire | 4 |
| Dyspnée | 3 |
| Mesure de la pression artérielle | 2 |
| Angor, examens complémentaires, thrombose veineuse, insuffisance cardiaque | 1 chacun |

Trois observations exploitables tout de suite :

**L'auscultation et la fraction d'éjection font la moitié des questions.** Vingt questions sur trente-trois portent sur trois thèmes. Les quatre localisations des foyers d'auscultation, qui tiennent en trois lignes du cours page 10, alimentent à elles seules huit questions.

**Les questions sont souvent recopiées mot pour mot.** La question sur la fraction d'éjection revient six fois, quatre fois à l'identique. Le cas clinique du patient essoufflé après un escalier de dix marches revient trois fois dans les mêmes termes. Ce qui change d'une année sur l'autre, c'est la position de la proposition fausse, pas son contenu.

**Une proposition est vraie huit fois sur huit.** « Le foyer tricuspidien est au niveau de la xiphoïde » apparaît dans les huit questions d'auscultation, toujours vraie. À l'inverse, « la valeur normale est de 100 % » apparaît cinq fois, toujours fausse.

L'application utilise ce comptage pour composer la file : les thèmes récurrents passent devant. Dans la démonstration, chaque question d'annales affiche son étiquette « tombé 8 fois ».

## 3. Comment une note devient plusieurs cartes

C'est la distinction que le cahier des charges demande, et elle se voit ici concrètement.

La note sur les foyers d'auscultation est un texte à trous unique :

> Le foyer mitral se situe au **{{c1::5e espace intercostal gauche sur la ligne médio-claviculaire}}**. Le foyer aortique se situe au **{{c2::2e espace intercostal droit}}**. Le foyer pulmonaire se situe au **{{c3::2e espace intercostal gauche}}**. Le foyer tricuspidien se situe au niveau du **{{c4::processus xiphoïde}}**.

Une note, quatre cartes. À la révision, un seul trou est masqué et les trois autres sont visibles, ce qui donne le contexte sans donner la réponse. Chaque carte a son propre état de mémorisation : vous pouvez maîtriser le foyer mitral et continuer à confondre aortique et pulmonaire.

Au total : 53 notes donnent 65 cartes. Les textes à trous expliquent l'écart.

## 4. Une révision, pas à pas

La démonstration enchaîne exactement la séquence décrite dans le cahier des charges. Voici la première carte, réellement tirée des annales 2023/2024.

**Affichage.** L'énoncé, les cinq propositions, et les étiquettes de contexte : thème, année d'examen, nombre d'occurrences, format de question.

**Réponse.** Touches A à E pour cocher. Rien d'autre à faire.

**Confiance, avant la correction.** Touches 1, 2, 3 pour « sûr », « hésitant », « au hasard ». Le bouton de validation reste inactif tant que la confiance n'est pas déclarée, parce que la déclarer après avoir vu le résultat n'a aucune valeur.

**Correction.** Chaque proposition reçoit son verdict : vraie et cochée, vraie et oubliée, fausse et cochée. Le détail du calcul est affiché, puis l'explication ancrée dans le cours, puis les deux liens de source.

**Note de mémorisation, puis XP, puis citation en fin de session.** Dans cet ordre, et l'XP dépend du score et de la confiance, jamais du volume.

## 5. Le barème par discordances, sur un cas réel

Annales 2023/2024, question 4. Les bonnes réponses sont B, C et D.

| Vous cochez | Discordances | Score |
|---|---|---|
| B, C, D | 0 | 1 |
| B, C | 1 | 0,5 |
| B seul | 2 | 0,2 |
| tout | 2 | 0,2 |
| A, E | 5 | 0 |

Deux garde-fous s'ajoutent au comptage. Sur la question des signes d'hypertension des cavités droites, le reflux hépato-jugulaire est marqué **indispensable** : l'oublier annule la question, quel que soit le reste. Sur la question des facteurs de risque, l'élévation du HDL-cholestérol est marquée **inacceptable** : la cocher annule la question. Ces deux drapeaux sont dans le paquet de données et la démonstration les applique.

## 6. Les règles qui empêchent de tricher avec soi-même

Trois comportements sont visibles dans la démonstration.

**Juste au hasard n'est pas acquis.** Répondez correctement en déclarant « au hasard » : la carte est planifiée comme oubliée et revient dans dix minutes, et l'XP est plafonnée à 4 points au lieu de 17. C'est la règle qui empêche la chance de se transformer en progression.

**Sûr et faux coûte cher.** La carte revient très vite et l'application le dit explicitement. C'est l'erreur la plus dangereuse en examen.

**La correction automatique n'a pas le dernier mot.** Sur une réponse tapée, la comparaison ignore la casse, les accents et la ponctuation, et tolère une faute de frappe isolée. Au-delà, elle refuse. Un bouton « J'avais juste » permet de trancher vous-même, et le journal garde la trace des deux : ce que la machine a calculé, et ce que vous avez décidé. Essayez d'écrire la formule de la fraction d'éjection en inversant deux lettres pour voir le mécanisme.

## 7. Le journal, et pourquoi il est en ajout seul

L'écran de bilan montre le journal de la session : une ligne par carte, avec le score, la confiance déclarée, la note de mémorisation, le prochain délai et l'XP. Rien n'y est modifié ni effacé.

C'est ce qui permettra plus tard de réoptimiser les paramètres de l'algorithme sur votre historique réel, et de recalculer l'XP si les règles changent. Un journal qui se réécrit perd cette possibilité.

## 8. Ce qui reste à faire sur ce chapitre

**Les 14 schémas du cours.** Ce sont eux qui portent l'essentiel de la mémoire visuelle : la vue du cœur page 2, les foyers d'auscultation page 10, les irradiations des souffles et le tracé B1-B2 page 11, le schéma des pouls page 12, les électrodes et la radiographie page 14. Ce sont les cartes à masques à créer en priorité, et ce sont celles que l'application ne peut pas fabriquer seule.

**Deux clés déduites en 2025/2026.** Le corrigé officiel du sujet 2025/2026 ne
couvre que 20 de ses 25 questions ; les Q3 (FEVG) et Q4 (auscultation) n'en
font pas partie. Leur clé est déduite du cours, et la carte le dit (25/09/2026).

**Une réponse manquante.** La question 8 de juin 2019 session 1 n'apparaît pas dans la table de corrections des annales. La réponse retenue est déduite du cours et la carte porte un avertissement visible jusqu'à vérification. L'application ne présente jamais une réponse déduite comme une réponse officielle.

**Les vingt cartes tirées du cours sont les miennes, pas les vôtres.** Elles sont fidèles au texte, mais c'est vous qui savez ce que le professeur attend. Relisez-les dans `donnees.py`, elles sont lisibles sans connaître Python.

## 9. Deux réserves honnêtes

**La planification est simplifiée.** La démonstration associe un délai fixe à chaque note : dix minutes, un jour, trois jours, six jours. La vraie application utilisera la bibliothèque de répétition espacée, dont les intervalles dépendent de l'historique complet de chaque carte. La mécanique montrée ici est celle de la conversion score et confiance vers la note, qui est la partie à décider, pas celle du calcul des intervalles.

**Les valeurs d'XP et de niveau sont des exemples.** La courbe de progression doit vivre dans un fichier de configuration, comme prévu dans le cahier des charges.

## Le tableau d'erreurs de la promo (28/09/2026)

Une entrée pour ce cours : le ronéo 2026-27 titre « C. Les palpations » (p. 7)
là où il s'agit des **palpitations**. La carte `co-palpitations-def` disait déjà
palpitations ; son explication le signale maintenant par ATTENTION. La liste de
la promo est tenue dans `contenu/ERRATA_RONEOS_2026-27.md`.

## Le corrigé officiel 2023-24

Le sujet de sémiologie générale 2023-24 et son corrigé officiel (une clé par question) sont arrivés le 15/10/2026. Les cartes de cette session venaient du polycopié et en gardent la source ; leur clé est vérifiée :

- 2023/2024 Q3 (`an-2324-q3`, ACDE) : clé confirmée par le corrigé officiel 2023-24, dépôt du 15/10/2026.
- 2023/2024 Q4 (`an-2324-q4`, BCD) : clé confirmée par le corrigé officiel 2023-24, dépôt du 15/10/2026.

## 10. Relancer la génération

```bash
python generer.py
```

Le script valide les données avant d'écrire : nombre de propositions, cohérence des lettres de réponse, une proposition indispensable est forcément vraie, une inacceptable forcément fausse. Il refuse de produire quoi que ce soit si un contrôle échoue.

## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026)

L'échelle du pilote de l'immunité innée, étendue au tissu sanguin et aux trois derniers chapitres de sémiologie pour l'examen du 4/11 (Vincent, 16/10 : « on continue pour les chapitres que je vais avoir à l'examen »). Sous les annales, 31 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 9 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `auscultation` | 8 | 2 | 9 |
| `fevg` | 4 | 1 | 7 |
| `coeur-droit` | 6 | 1 | 6 |
| `risque` | 3 | 1 | 4 |
| `dyspnee` | 2 | 1 | 3 |
| `pression-arterielle` | 0 | 0 | 2 |
| `paracliniques` | 4 | 1 | 1 |
| `angor` | 3 | 1 | 1 |
| `veineux` | 1 | 1 | 1 |
| `insuffisance-cardiaque` | 0 | 0 | 1 |

**Le schéma** `ech-coeur`, « Le cœur à l'examen · interroger, ausculter, mesurer », donne 74 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_COEUR`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Le générateur garde sa forme** (barèmes, page du cours en source secondaire, justifications dans `justifications.py`, démo HTML) et lit les marches comme le modèle : `CHOIX`, `IMAGES` et `SRC` en fin de `donnees.py`, `schemas.py` et `echelle.py`. Ses autres cartes et la démo n'ont pas changé. Les marches citent la ronéo 2026-27.

**Question négative** : 2019/2020 juin S2 Q2 (thrombose veineuse) ; ses lettres disent la vérité de chaque signe, et la réponse attendue est la lettre rouge.

**ATTENTION posés** : les clés déduites de 2025/2026 Q3 et Q4 et de 2019/2020 juin S1 Q8, sans corrigé officiel (s2 à s6, s17 à s20, s22, m1, m2, m6, m7).

**Tranché par la littérature** (Vincent, 17/10 : la littérature fait foi). (1) Le foyer mitral est l'apex, au 5e espace intercostal gauche sur la ligne médio-claviculaire (StatPearls) : `co-foyers` et `co-choc-pointe` passent du 4e de la ronéo au 5e, avec un `ATTENTION (cours)` et une ligne de la liste des errata ; le choc de pointe accepte encore le 4e. (2) La mesure de la pression artérielle n'est plus dans le cours 2026-27 : `co-korotkoff` dit « Absent du cours 2026-27 » et suit la littérature (StatPearls ; AHA 2019) ; ses deux annales gardent leur clé et ne citent plus de page de cours.

**La dyspnée d'effort suit le tableau** (Vincent, 17/10 : l'image fait foi sur le texte de la ronéo) : grade II au-delà de 2 étages, grade III à 2 étages ou moins. Le texte de la p. 7, « 2 escaliers ou plus » au grade II, est une `ATTENTION (prise de notes)` (`co-grade-frontiere`, `cv-ech-s9`, liste des errata) ; le schéma écrit la barre en étages.

**Sans marche** :
- 2020/2021 Q15 (an-2021-q15), A à E, et 2019/2020 juin S2 Q1 (an-1920j2-q1), A à E : la mesure auscultatoire de la pression artérielle (apparition et disparition des bruits, systolique, diastolique, moyenne, pulsée, site de mesure) n'est ni dans la ronéo 2026-27, ni dans la FC n°4 en docx, ni dans le Ronéosaure 2025-26. Le thème « Mesure de la pression artérielle » reste sans marche, sans carte Moyen et sans lettres sur le schéma.
- Assis penché en avant — 2023/2024 Q4 D, 2022/2023 Q22 D, 2019/2020 nov S1 Q8 D, 2016/2017 Q4 D, 2015/2016 S2 Q18 D : la ronéo ne cite que le dos, le décubitus latéral gauche, l'inspiration et l'expiration forcées (p. 9). Les lettres sont posées sur la case « Pour mieux entendre », sans marche.
- 2021/2022 S2 Q6 B (an-2122s2-q6) : l'IRM cardiaque n'est pas dans la ronéo, qui ne mesure la FEVG qu'en échographie (p. 15).
- 2019/2020 juin S2 Q5 (an-1920j2-q5) A, C, D, E : claquement d'ouverture, bruits « frappés », frottement et bradycardie sont absents de la ronéo. La lettre B n'est préparée que pour le foyer et l'irradiation de la fuite mitrale (p. 10), le lien avec l'insuffisance cardiaque gauche n'y étant pas.
- Souffle d'insuffisance mitrale fonctionnelle et marbrures — 2020/2021 Q19 A et D, 2020/2021 S2 Q6 A et D, 2019/2020 juin S2 Q7 D : absents de la ronéo. 2019/2020 juin S2 Q7 A (le cœur droit plus souvent atteint que le gauche) : la ronéo ne compare pas leurs fréquences.
- L'exercice physique régulier — 2017/2018 S2 Q16 C, 2015/2016 Q22 C : la ronéo ne le cite ni comme facteur de risque ni comme protection (p. 4).
- 2019/2020 juin S2 Q2 (an-1920j2-q2) B, C, D : l'œdème, la cyanose et le caractère unilatéral de la phlébite ne sont pas dans la ronéo, qui cite la douleur du mollet, l'aspect inflammatoire de la jambe et la douleur à la dorsiflexion (p. 12).
- 2016/2017 S2 Q4 B (an-1617s2-q4) : la ronéo dit que l'échographie montre les cavités et mesure les flux et les gradients (p. 15) ; elle ne nomme pas les valves.
- 2019/2020 juin S1 Q8 (an-1920j1-q8) B, C, D : l'examen de repos d'une insuffisance stabilisée, les quatre signes fonctionnels propres à l'insuffisance cardiaque (dyspnée, fatigue, prise de poids, œdèmes) et le souffle aortique « annonciateur » sont absents de la ronéo. Sa clé C est déduite hors du cours.

## La session de l'examen du 4 novembre (17/10/2026)

Ce chapitre déclare la seule session d'examen des quatre UE de novembre :
`exam-nov-2026`, « Examen du 4 novembre », le **2026-11-04** (planning MED2 S1
2026-27 : sémiologie générale, tissu sanguin, système immunitaire et BMCT, sur
tablette), posée sur les UE `ue-semio`, `ue-tissu-sanguin`, `ue-immunologie` et
`ue-bmct` pour couvrir aussi les chapitres qu'on leur ajoutera. Elle était datée
du 9/11 et limitée à ce seul chapitre.

Elle reste ici parce qu'elle y était : même identifiant, la date se corrige sur
place dans chaque bibliothèque à la mise à jour. Un import ajoute à la portée
d'une session au lieu de la remplacer (`importer._import_exam_sessions`) : un
autre chapitre pourra déclarer sa part sans rien retirer. Les trois autres UE
existent avant ce paquet dans l'ordre de chargement (le squelette du
Ronéosaure les crée) ; c'est tenu par
`test_the_delivered_session_of_4_november_covers_the_four_units`.
