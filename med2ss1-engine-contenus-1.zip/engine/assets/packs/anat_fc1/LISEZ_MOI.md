# Anatomie du membre inférieur — paquet Anatomie

106 notes, 217 cartes. Chapitre `chap-ue-anatomie-fc1` de l'UE Anatomie
(identifiant du squelette), premier chapitre de l'UE. Cours du **Pr Herteleer,
le 06/10/2026** : la région glutéale, l'articulation de la hanche, la région
lombaire et inguino-pelvienne. Examen de novembre, un **schéma** : orienter,
nommer, compléter. Aucune annale : les sujets du membre inférieur sont des
schémas à légender, cartés par les chapitres Schémas n°1 et n°2.

**La base est le cours 2026-27 pour ce qu'il couvre** (réalignement du
19/10/2026) : le ronéo « TOPOGRAPHIE DU MEMBRE INF 1 » de Ronéo & Juliette
(12 p., CM du 06/10/2026, 11 h-12 h, livré le 19/10), la fiche du chapitre.

- **I. Région glutéale** (p. 2-6) : anatomie de surface et nerfs cluniaux
  (p. 2, figure), ostéologie (p. 3), ligaments sacro-épineux et sacro-tubéral,
  glutéaux, signe de Trendelenburg, fascia lata (p. 4), les six
  pelvi-trochantériens (p. 5), les nerfs (p. 5-6), les artères (p. 6) ; la
  figure de la vue postérieure des muscles fessiers (p. 3).
- **II. Articulation de la hanche** (p. 7-9) : généralités, vues antérieure et
  postérieure, ligaments, clinique (figure p. 7) ; coupe transversale de la
  hanche droite en vue inférieure (figure p. 8, texte p. 9).
- **III. Région lombaire et inguino-pelvienne** (« région antérieure du petit
  bassin », p. 10-11) : ostéologie et figure (p. 10), muscles et nerfs du
  plexus lombal (p. 11).
- Une annexe (p. 12), une coupe de la région coxale d'IMAIOS, citée pour deux
  bourses, jamais extraite.

La FC n°1 (AC) du Ronéosaure 2024-25 (Pr Demondion, 16/09/2024, 21 p.), qui
faisait la base jusqu'ici, reste l'appoint et la fiche des cartes que le ronéo
2026-27 ne traite pas encore. **Le cours continue** : le trigone fémoral, la
cuisse, ses vaisseaux et ses nerfs et la fosse poplitée attendent les CM
suivants (« ce point sera revu au prochain cours », p. 9) — voir « En attente
des CM suivants ».

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 49 | 49 |
| QRU | 2 | 2 |
| Texte à trous | 17 | 105 |
| QROC | 13 | 13 |
| Recto-verso | 7 | 7 |
| Schéma cliquable | 3 | 26 |
| Lexique | 15 | 15 |
| **Total** | **106** | **217** |

**51 QCM sur 51 illustrés** (100 %), 78 notes sur 106 : les cinq figures du
ronéo 2026-27 (p. 2, 3, 7, 8, 10), treize figures de la FC n°1 2024-25 et
trois planches corrigées de Schémas n°1, en correction, jamais en question.
**4 cartes portent un piège du ronéo 2026-27** (thème « Pièges des ronéos »).
**1 carte absente du cours 2026-27.** **Aucune carte `a-relire`.** Aucune
annale, aucun conflit.

Neuf thèmes ; huit sont partagés avec les chapitres FC n°2, Schémas n°1 et n°2
(même libellé, vérifié). **Un thème nouveau**, `region-lombo-pelvienne`, pour la
partie III du ronéo 2026-27, aussi employé par le chapitre Schémas n°1 : il
manque à `THEME_LABELS` (`app/src/med_engine/application/scopes.py`), et
`test_tout_theme_du_paquet_a_son_libelle` échoue sur ce chapitre tant qu'il n'y
est pas.

| Clé | Libellé | Notes |
|---|---|---|
| `trigone-femoral` | Trigone fémoral, lymphonœuds et grande saphène | 10 |
| `osteologie-mi` | Ostéologie du membre inférieur | 3 |
| `muscles-cuisse` | Muscles de la cuisse | 7 |
| `vaisseaux-mi` | Artères et veines du membre inférieur | 10 |
| `nerfs-mi` | Nerfs du membre inférieur | 16 |
| `region-gluteale` | Région glutéale | 21 |
| `hanche` | Articulation coxo-fémorale | 13 |
| `fosse-poplitee` | Fosse poplitée | 9 |
| `region-lombo-pelvienne` | **Région lombaire et inguino-pelvienne** (nouveau) | 2 |

(91 notes de cours ; les 15 termes du lexique n'ont pas de thème.)

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-anat-fc1-2627` — Ronéo & Juliette, « TOPOGRAPHIE DU MEMBRE INF 1 » (12 p.), chemin `ANATOMIE/TOPOGRAPHIE DU MEMBRE INF 1.pdf` | **2026-27** | **la base** et la fiche du chapitre (`SRC["fiche"]`, `chapitre=`) : 42 notes de cours (20 relues, 22 nouvelles) et 11 termes du lexique la citent ; le chapitre Schémas n°1 la déclare à l'identique pour ses planches |
| `src-ue-anatomie-fc1` — Ronéosaure, FC n°1 (AC) (21 p.), chemin `Anatomie/FC n°1 (AC) - Anatomie du membre inférieur.pdf` | 2024-25 | l'ancienne base ; appoint, fiche (`fiche=FC`) des 48 cartes en attente et source de la carte absente ; **plus de `chapitre=`** |
| `src-ue-anatomie-sch1` — Ronéosaure, Schémas n°1 (AC) (16 p.) | 2024-25 | trois planches corrigées en illustration (p. 1, 5, 14) ; déclarée à l'identique du chapitre Schémas n°1, dont elle est la fiche |
| Cours 2023-24 (Charonéo, n°1) | 2023-24 | appui cité dans les justifications |

Dans le texte d'une carte relue, « ronéo 2026-27 p. N » renvoie au ronéo de
l'année, « Ronéosaure 2024-25 p. N » à l'ancienne base ; dans une carte en
attente, « p. N » ou « FC1 p. N » renvoie toujours au Ronéosaure 2024-25.

**Les figures du ronéo 2026-27 qui viennent d'un atlas ou d'un site** — la
planche osseuse de Netter et la figure des nerfs cluniaux d'un site
d'échographie (p. 3), la coupe IMAIOS (p. 12) — **ne sont jamais extraites** ;
les cinq autres sont les dessins du tableau, redessinés et légendés par
l'équipe du ronéo, en PNG dans `media/` (`mi1-2627-p…`).

## Ce que le ronéo 2026-27 a changé

**20 notes relues sur le ronéo 2026-27** : elles portent sa page, citent son
texte, et perdent le badge « Cours 2024-25 ». Les propositions que le ronéo ne
reprend pas disent, dans leur justification, qu'elles viennent du Ronéosaure
2024-25.

| Page | Partie | Notes relues |
|---|---|---|
| 3 | I.B ostéologie ; la figure des muscles fessiers | `mi1-qc-osteo-posterieure`, `mi1-qr-plancher` |
| 4 | I.C-D ligaments, glutéaux | `mi1-qc-gluteaux`, `mi1-qc-sacro-tuberal`, `mi1-fa-gluteaux` |
| 5 | I.D pelvi-trochantériens | `mi1-qc-piriforme-obturateur`, `mi1-zo-piriforme` |
| 6 | I.E-F nerfs, artères | `mi1-qc-nerf-ischiatique`, `mi1-qc-nerfs-gluteaux`, `mi1-rv-nerfs-gluteaux`, `mi1-fa-racines-sacrees`, `mi1-fa-nerfs-gluteaux` |
| 9 | II.C coupe transversale | `mi1-qc-hanche-articulaire`, `mi1-qc-hanche-muscles`, `mi1-qc-hanche-nerfs`, `mi1-qc-hanche-bourses` |
| 10 | III.A ostéologie | `mi1-qr-bifurcation-aortique` |
| 11 | III.C nerfs | `mi1-qc-nerf-femoral`, `mi1-qc-nerf-obturateur`, `mi1-fa-racines-lombaires` |

Ce qui a changé dans leur contenu (aucune clé de QCM ne change, aucun trou de
texte n'est renuméroté) :

- **Le piriforme « traverse le grand foramen »** (p. 5) : les cartes disent
  « grand foramen ischiatique », la grande incisure fermée par le sacro-épineux
  (p. 4).
- **Le sacro-tubéral est « plus superficiel »** que le sacro-épineux, avec un
  prolongement falciforme, la « chistera » (p. 4) ; « puissant et massif »
  reste cité comme mot du Ronéosaure.
- **Les jumeaux** naissent de l'épine (supérieur) et de la tubérosité
  ischiatiques (inférieur) et se terminent sur le tendon de l'obturateur
  interne (p. 5) ; le carré fémoral va du bord latéral de la tubérosité
  ischiatique à la crête intertrochantérique (p. 5).
- **Le nerf glutéal supérieur innerve aussi le tenseur du fascia lata** ; les
  racines des nerfs de la région sont données (p. 6) — glutéal supérieur L4-S1,
  inférieur L5-S2, pudendal **S2-S4**, ce qui tranche le « (S2 – S3) » de la
  figure 2024-25 : `mi1-fa-racines-sacrees` gagne trois trous (c5-c7).
- **L'obturateur interne dépend du plexus sacré, l'obturateur externe du nerf
  obturateur** (p. 5) : le « rameau du muscle obturateur interne » que la figure
  2024-25 pose sur le nerf obturateur est faux, comme le disait l'ATTENTION.
- **Le nerf obturateur** passe par le canal obturateur, la partie du foramen
  que la membrane ne ferme pas, après avoir longé la ligne arquée (p. 11).
- **L'articulation** : « notions vues l'an dernier », le professeur invite à
  revoir le cours de première année (p. 7). Le labrum « augmente la
  congruence » (p. 9).
- **La coupe de la hanche** est redessinée cette année (figure p. 8) : l'avant
  en haut, le médial à droite ; elle remplace la coupe 2024-25 en correction des
  quatre cartes de la hanche.
- Les figures 2026-27 remplacent celles de 2024-25 en correction partout où
  elles montrent ce que la carte demande (région glutéale, coupe, plexus
  lombal) ; les figures 2024-25 restent pour l'ostéologie postérieure, le nerf
  ischiatique et ses branches, le nerf fémoral et ses branches.

**27 notes nouvelles**, pour ce que le ronéo 2026-27 enseigne et qu'aucune
carte ne couvrait :

| Note | Ce qu'elle apprend | Page |
|---|---|---|
| `mi1-qc-surface-gluteale` | repères de surface, quadrant d'injection, nerfs cluniaux (et l'erreur de la figure) | 2 |
| `mi1-qr-injection` | le quadrant supéro-latéral | 2 |
| `mi1-fa-cluniaux` | les trois groupes de nerfs cluniaux, le quadrant | 2 |
| `mi1-qc-osteo-bord-posterieur` | bord postérieur de l'os coxal, tubérosité ischiatique, petit trochanter, ligne âpre, lignes glutéales | 3 |
| `mi1-qc-foramens-ischiatiques` | ligaments sacro-épineux et sacro-tubéral, grand et petit foramens, nerf pudendal | 4 |
| `mi1-qc-trendelenburg` (QRU) | le signe de Trendelenburg : le bassin tombe du côté qui ne porte pas | 4 |
| `mi1-qr-tractus` | le tractus ilio-tibial | 4 |
| `mi1-qc-pelvi-trochanteriens` | les six pelvi-trochantériens, leur innervation | 5 |
| `mi1-fa-pelvi-trochanteriens` | les mêmes, de haut en bas | 5 |
| `mi1-qc-arteres-gluteales` | artères glutéales, pudendale interne, anastomoses | 6 |
| `mi1-rv-pudendal` | « artère pudendale interne » / « nerf pudendal », son trajet | 6 |
| `mi1-qc-hanche-generalites` | 2/3 de sphère, énarthrose, capsule, zona orbicularis, articulation portante | 7 |
| `mi1-qc-hanche-ligaments` | ilio-fémoral (Bertin), pubo-fémoral, ischio-fémoral, récepteurs | 7-8 |
| `mi1-qr-bertin` | le ligament ilio-fémoral | 7 |
| `mi1-qr-zona-orbicularis` | la zona orbicularis | 7 |
| `mi1-fa-hanche-ligaments` | ligaments et capsule | 7-8 |
| `mi1-qc-hanche-clinique` | ponction, coxarthrose, prothèse, fracture du col | 8 |
| `mi1-qc-coupe-hanche-orientation` | lire la coupe en vue inférieure | 8-9 |
| `mi1-qc-reperes-lombaires` | crête iliaque en L4, L3, coccyx, ligament inguinal | 10 |
| `mi1-qc-psoas-iliaque` | grand psoas, iliaque, carré des lombes, muscles larges (et les erreurs de la figure) | 11 |
| `mi1-qc-plexus-lombal-trajets` | trajets du subcostal, du génito-fémoral, du fémoral, de l'obturateur | 11 |
| `mi1-fa-plexus-lombal-trajets` | les mêmes trajets | 11 |
| `lex-cluniaux`, `lex-acetabulum`, `lex-psoas`, `lex-pudendal`, `lex-obturateur` | termes du lexique | 2-11 |

Les planches à légender des cinq figures du ronéo 2026-27 sont au chapitre
Schémas n°1 (`anat-pl-2627-…`), avec celle de l'articulation que la photo du
cours coupait (C17).

Contrôles : aucune note supprimée, aucun identifiant ni type changé, aucune clé
de QCM changée, les numéros des trous des textes à trous conservés.

## Les erreurs du ronéo 2026-27

Portées dans les cartes avec leur genre (`.claude/rules/cartes.md`), à verser
dans `contenu/ERRATA_RONEOS_2026-27.md`. Le tableau des erreurs de la promo
(19/10) n'a aucune entrée sur ce ronéo : toutes sont trouvées en relisant.

| Page | Ce que dit le ronéo | Ce qui est juste, et la preuve | Genre | Cartes |
|---|---|---|---|---|
| p. 2 (figure) | « Nerfs cluniaux moyens (S2, S3, S4) » | S1-S3 : le tableau de la même page (« rameaux postérieurs des nerfs spinaux sacraux (S1-S2-S3) ») ; Aota, World J Orthop 2016, PMC4794535 (« dorsal rami of S1 to S3 ») ; Wheeless' Textbook of Orthopaedics | prise de notes | `mi1-qc-surface-gluteale` (D), `mi1-fa-cluniaux` ; au chapitre Schémas n°1, `anat-pl-2627-surface-gluteale` (n° 6) |
| p. 9 | le pectiné parmi les « muscles postérieurs » de la coupe | en avant, juste en dedans de l'ilio-psoas : la figure de la p. 8, le dessin du professeur (« P »), le Ronéosaure 2024-25 (p. 16) ; Gray's Anatomy | prise de notes | `mi1-qc-hanche-muscles` (A) ; au chapitre Schémas n°1, `anat-pl-2627-coupe-hanche` (n° 19), `anat-pl-cours-coupe-hanche` (n° 6) |
| p. 10 (figure) | « m. ilaque » sur le grand psoas, « m. grand psoas » sur l'iliaque | inversés, ce que le ronéo signale lui-même en rouge ; texte p. 11 | prise de notes | `mi1-qc-psoas-iliaque` (B) ; au chapitre Schémas n°1, `anat-pl-2627-lombaire` (n° 13, 14) |
| p. 10 (figure) | « m. oblique externe » sur la bande du milieu, « m. oblique interne » sur la plus latérale | probablement inversés : vu de face, la bande la plus proche est la plus profonde (transverse), les nerfs passent sur celle du milieu, « entre le transverse et l'oblique interne » (p. 11) ; ordre de la superficie à la profondeur, p. 11 ; Gray's Anatomy (paroi abdominale) | douteux | `mi1-qc-psoas-iliaque` (D) ; au chapitre Schémas n°1, `anat-pl-2627-lombaire` (n° 11, 12) |

**Vus et laissés sans ATTENTION**, parce qu'ils ne changent aucune réponse :

- « Région antérieure du petit bassin » (titre de la partie III et p. 10) pour
  une région lombaire et inguino-pelvienne : le psoas, l'iliaque et le carré
  des lombes sont sur la paroi abdominale postérieure et dans le grand bassin.
  Le titre de la figure, « Vue antérieure de la région lombaire et inguino
  pelvienne », est celui que les cartes et la planche emploient ;
- le moyen glutéal inséré aussi « sur le tubercule glutéal moyen » (p. 4) :
  aucune structure ne porte ce nom ; non carté ;
- l'obturateur externe qui « se termine en arrière de l'obturateur interne »
  (p. 9) : sa terminaison (fosse trochantérique) est en arrière et au-dessous de
  celle de l'obturateur interne, mais sur la coupe il passe en avant de lui,
  contre l'articulation ; les cartes disent la coupe ;
- les coquilles « tactus » (p. 4), « pyriforme » (p. 6), « jumaux » (p. 3),
  « obturatice » et « ilaque » (figures p. 8 et 10), « n. sciatique » (figure
  p. 3, l'ancien nom du nerf ischiatique).

## Absent du cours 2026-27

**1 carte** (`ABSENTS_2026`, `ORIGINE_ABSENTS` : le cours du Pr Demondion de
2024-25) : `mi1-qr-plus-puissant`, « le muscle le plus puissant de
l'organisme ». Le ronéo 2026-27 traite le grand glutéal (p. 4 : « très
volumineux », extension puissante et rotation latérale) sans le dire le plus
puissant. La carte garde sa page de la FC n°1 2024-25.

## En attente des CM suivants

**48 notes** que le ronéo 2026-27 ne traite pas encore. Elles gardent leur
page de la FC n°1 2024-25 (`fiche=FC`, badge « Cours 2024-25 ») et se
reliront à la parution des ronéos des CM suivants du membre inférieur.

| Sujet | Notes |
|---|---|
| trigone fémoral, lymphonœuds, grande saphène | `mi1-qc-ligament-inguinal`, `mi1-qc-lymphonoeuds`, `mi1-qc-gvs-trajet`, `mi1-qc-gvs-affluents`, `mi1-qc-trigone-clinique`, `mi1-qr-plaie-toreador`, `mi1-rv-schema-trigone`, `mi1-fa-lymphonoeuds`, `mi1-fa-gvs`, `mi1-zo-trigone` |
| ostéologie antérieure et muscles de la cuisse | `mi1-qc-osteo-reperes`, `mi1-qc-quadriceps`, `mi1-qc-adducteurs`, `mi1-qc-iliopsoas-sartorius`, `mi1-qc-patte-doie`, `mi1-qr-capot`, `mi1-rv-quadriceps`, `mi1-fa-insertions` |
| vaisseaux de la cuisse | `mi1-qc-axe-arteriel`, `mi1-qc-collaterales`, `mi1-qc-profonde-cuisse`, `mi1-qc-veines`, `mi1-qr-hiatus`, `mi1-rv-saphenes`, `mi1-rv-circonflexes`, `mi1-fa-collaterales`, `mi1-fa-profonde-cuisse` |
| nerfs fémoral, saphène et cutané latéral dans la cuisse, lésions | `mi1-qc-lesion-femoral`, `mi1-qc-nerf-saphene`, `mi1-rv-lesions`, `mi1-qr-meralgie` |
| nerf ischiatique dans la cuisse, ses branches | `mi1-qc-variations-ischiatique`, `mi1-qc-nerf-tibial`, `mi1-qc-nerf-sural`, `mi1-qc-ischio-jambiers`, `mi1-fa-ischiatique`, `mi1-fa-nerf-tibial`, `mi1-fa-sural` |
| fosse poplitée | `mi1-qc-fosse-poplitee`, `mi1-qc-poplite-superficiel`, `mi1-qc-nivea`, `mi1-qc-losange`, `mi1-qc-plan-profond`, `mi1-qc-triceps-sural`, `mi1-qr-nivea`, `mi1-fa-semi-membraneux`, `mi1-zo-poplite` |
| **renvoyée au cours de l'an dernier** (« notions vues l'an dernier », p. 7) | `mi1-qr-fovea` : la fovéa capitis, que le ronéo ne nomme pas ; ni absente ni en attente d'un CM, elle garde sa page 2024-25 |

Quatre d'entre elles ont déjà une proposition confirmée par le ronéo 2026-27,
que leur justification cite sans changer leur fiche : `mi1-qc-ligament-inguinal`
(A, p. 10), `mi1-qc-osteo-reperes` (D, p. 3 et 11), `mi1-qc-iliopsoas-sartorius`
(A et B, p. 9 et 11), `mi1-qc-axe-arteriel` (A, p. 10). À la prochaine relecture,
commencer par elles.

## Ce que le cours a dicté

- **L'examen est un schéma** : orienter, nommer, compléter. Les cartes
  apprennent où passe quoi, qui est en avant ou en arrière, au-dessus ou
  au-dessous du piriforme, qui innerve quoi, où s'insère quoi, et l'orientation
  de chaque figure (la coupe vue d'en bas, `mi1-qc-coupe-hanche-orientation`).
- **Le rouge du ronéo 2026-27** n'est qu'un avertissement des rédacteurs (p. 10,
  l'inversion des muscles) ; il n'y a pas de gris. Le rouge de la FC 2024-25
  était la convention des noms d'artères.
- « **À la dissection, couper un nerf n'est pas grave. Sur un patient, c'est
  autre chose.** » (p. 5) : cité dans l'explication des pelvi-trochantériens.
- « **Il faut consulter le livret d'anatomie pour les TP de dissection** »
  (p. 12).
- **Les noms.** L'en-tête du ronéo 2026-27 (correcteurs, binôme), ceux de la FC
  2024-25 et la première colonne des errata portent des noms d'étudiants :
  aucun n'est repris. Les Pr Herteleer et Demondion le sont.

## Les erreurs du Ronéosaure, et ce que les cartes en font

Le Ronéosaure n'est pas la ronéo de l'année : ses erreurs sont signalées par un
**ATTENTION nu**, « de cette année-là », sans le genre que `.claude/rules/cartes.md`
réserve aux ronéos 2026-27. Aucune n'entre dans
`contenu/ERRATA_RONEOS_2026-27.md`. Le ronéo 2026-27 en tranche deux.

| Où | Ce que dit le Ronéosaure | Retenu, et pourquoi | Carte |
|---|---|---|---|
| p. 8 | le nerf fémoral innerve « les muscles glutéaux » | faux : nerfs glutéaux supérieur et inférieur (ronéo 2026-27 p. 4 et 6) | `mi1-qc-nerf-femoral` (D), `mi1-qc-nerfs-gluteaux` (E) |
| p. 17 | « une conséquence pathologique de cette tuméfaction [le kyste] est un anévrisme de l'artère poplitée » | faux : deux causes distinctes de tuméfaction poplitée | `mi1-qc-fosse-poplitee` (E) |
| figure p. 5 | « artère circonflexe iliaque médiale » | n'existe pas : circonflexe médiale (errata) | `mi1-qc-profonde-cuisse` (C) |
| figure p. 8 | « rameau du muscle obturateur interne » sur le nerf obturateur | faux : **tranché par le ronéo 2026-27**, tous les pelvi-trochantériens dépendent du plexus sacré, sauf l'obturateur externe (p. 5) | `mi1-qc-nerf-obturateur` (explication) |
| figure p. 8 | nerf pudendal « (S2 – S3) » | **S2-S4 dans le ronéo 2026-27** (p. 6), comme les références | `mi1-fa-racines-sacrees` (explication, trou c7) |
| p. 9 | le sac dural « descend jusqu'en S3 » | les références disent « à peu près S2 » ; non carté | `mi1-qc-osteo-posterieure` (C) |
| p. 3 | les supéro-latéraux drainent aussi « la partie plus latérale et médiale du membre inférieur » | formule confuse ; seule la paroi abdominale inférieure est cartée | `mi1-qc-lymphonoeuds` (explication) |
| p. 6 | le sartorius « participe à l'extension de la jambe… » | douteux ; fonction non cartée | `mi1-qc-iliopsoas-sartorius` (explication) |
| p. 8 | le nerf saphène, « plus longue branche collatérale » | classé parmi les branches terminales ; non carté | `mi1-qc-nerf-saphene` (explication) |
| p. 15 | la lame quadrilatère « fait communiquer la cavité articulaire avec le pelvis » | lame osseuse qui les sépare ; non carté | `mi1-qc-hanche-articulaire` (explication) |
| p. 16 vs 2023-24 | bourse de l'ilio-psoas communicante « dans au moins 40 % des cas » ; 20 % en 2023-24 | le chiffre n'est pas carté | `mi1-qc-hanche-bourses` (A) |
| p. 18, figure p. 18, 2023-24 | le nerf qui accompagne la grande saphène au genou | cas ouvert, en attente du CM de la fosse poplitée | `mi1-qc-poplite-superficiel` (explication) |
| p. 21 | muscle poplité : « insertion proximale » sur le tibia, « terminaison » sur le fémur | à l'envers des références ; seul le lieu est carté | `mi1-qc-plan-profond` (D) |
| p. 9 (et 2023-24) | la branche postérieure du nerf obturateur innerve « le muscle pectiné » | douteux (surtout fémoral) ; non carté | `mi1-qc-nerf-obturateur` (D) |

## Les schémas cliquables

| Fichier | Ce qu'on clique | Cartes | Source |
|---|---|---|---|
| `trigone-femoral.svg` | trigone fémoral droit, vue antérieure : ligament inguinal, nerf cutané latéral de la cuisse, nerf fémoral, artère et veine fémorales, crosse de la grande saphène, trois groupes de lymphonœuds | 9 | en attente : FC1 2024-25 p. 2-3, 7, 16-17 |
| `espaces-piriformes.svg` | région glutéale droite profonde, vue postérieure : espaces supra- et infra-piriformes, piriforme, petite incisure ischiatique, ligament sacro-tubéral, carré fémoral, sommet du grand trochanter | 7 | **relu sur le ronéo 2026-27** (p. 4-6, figure p. 3) : chaque phrase de zone le cite |
| `losange-poplite.svg` | creux poplité droit, vue postérieure | 10 | en attente : FC1 2024-25 p. 17-21 |

Aucune légende n'est imprimée sur les dessins, seul le repère d'orientation.
Les zones et le dessin lisent les mêmes constantes ; le réalignement n'a touché
que les phrases des zones des espaces piriformes, pas leur géométrie.

## Les illustrations

Les cinq figures du ronéo 2026-27 sont extraites du PDF (images d'origine,
recadrées, 256 couleurs), sans retouche : leurs légendes fausses restent, et la
légende de l'illustration le dit (« S2, S3, S4 » p. 2 ; iliaque et grand psoas,
obliques, p. 10). Les figures 2024-25 sont celles du Ronéosaure, et trois
figures non corrigées par l'errata y sont remplacées par la planche corrigée de
Schémas n°1 (trigone p. 2, vascularisation p. 5, plan superficiel poplité
p. 18). Deux légendes d'illustration 2024-25 ont été corrigées à la relecture
du 19/10 : la vue postérieure de l'ostéologie (p. 9) dit que ses « épines
iliaques postéro-supérieure et postéro-inférieure », sur le bord latéral, sont
les épines antérieures vues de profil (l'erreur que le chapitre Schémas n°1
relève sur la même figure) ; celle du nerf fémoral et du nerf obturateur (p. 8)
dit faux, et non plus douteux, le « rameau du muscle obturateur interne », que
le ronéo 2026-27 tranche (p. 5).

## Le lexique

Quinze termes, pages mesurées dans le texte du ronéo 2026-27 et de la FC n°1
2024-25 (`scripts/chercher_pages.py`, mot entier, pluriel permis, la page 1 —
le plan — écartée). Les pages du ronéo 2026-27 viennent en premier : c'est
elles qui font la provenance du terme.

| Terme | Pages 2026-27 | Pages FC1 2024-25 | Note |
|---|---|---|---|
| Trochanter | 3, 4, 5, 6, 8, 9, 10, 11 | 4, 5, 7, 10, 11, 15, 16 | |
| Sartorius | 9 | 5, 6, 8, 16, 17, 19 | |
| Pectiné | 9 | 5, 6, 9, 16, 17 | |
| Glutéal | 2, 3, 4, 6, 9 | 8, 9, 10, 14, 15, 16, 17 | glutéal, glutéale, glutéaux |
| Piriforme | 5, 6 | 11, 12, 13, 14 | |
| Ischiatique | 2, 3, 4, 5, 6, 8, 9 | 11, 12, 13, 14, 16, 17, 19 | |
| Saphène | — | 2, 3, 8, 9, 18, 19 | en attente |
| Poplité | — | 5, 7, 13, 17-21 | en attente |
| Sural | — | 13, 14, 18, 19, 21 | en attente |
| Gastrocnémien | — | 13, 17, 19, 20, 21 | en attente |
| **Nerfs cluniaux** | 2, 6 | — | nouveau ; racine `clunis (latin)` |
| **Acétabulum** | 7, 8, 9, 10 | 15 (« acétabulaire ») | nouveau ; racine `acetabulum (latin)` |
| **Psoas** | 9, 10, 11 | 5, 7, 8, 16, 17 | nouveau ; racine `psoa (grec)` |
| **Pudendal** | 6 | 7 (« pudendales ») | nouveau ; racine `pudendus (latin)` |
| **Obturateur** | 5, 9, 11 | 7, 9, 11, 16, 17 | nouveau ; racine `obturare (latin)` |

Les étymologies des cinq termes nouveaux (Wiktionnaire, Gaffiot, Bailly) sont
proposées pour `etymologies.json` dans `scratchpad/etym/anat_fc1.json`, et déjà
écrites dans les définitions et les racines, mot pour mot comme
`appliquer_etymologies.py` les écrirait. Aucun des cinq n'existait ailleurs dans
la bibliothèque (vérifié sur tous les `paquet.json`). « Coxarthrose » n'est pas
repris : `lex-coxarthrose` est au chapitre `semio_osteo`.

## Ce qui n'est pas carté ici (frontières)

- **Chapitre FC n°2** : la division de l'artère poplitée, le nerf fibulaire
  commun après le genou, le nerf tibial à la cheville, le tendon calcanéen.
- **Chapitre Schémas n°1** : toutes les planches à légender, dont les cinq du
  ronéo 2026-27, et « tout schéma comporte un titre et une orientation ».

## À relire

Aucune carte `a-relire` : chaque carte relue cite une page du ronéo 2026-27,
chaque carte en attente une page de la FC n°1 2024-25. Relues une seconde fois
le 19/10, carte par carte, sur les pages et les figures du ronéo.

## Régénérer

```powershell
cd contenu\chapitres\anat_fc1
..\..\..\app\.venv\Scripts\python.exe generer.py
```

`generer.py` est la copie exacte de `scripts/generer_modele.py` du skill.

## Questions pour Vincent

- (19/10) Les deux obliques de la figure p. 10 : la bande du milieu est
  légendée « oblique externe », la plus latérale « oblique interne » ; lue sur
  le dessin et sur le texte p. 11, c'est l'inverse. Les cartes suivent
  l'anatomie, avec un ATTENTION (douteux). Le professeur a-t-il nommé ces bandes
  au tableau ?
- (19/10) « Le muscle le plus puissant de l'organisme » (`mi1-qr-plus-puissant`)
  est passé en « Absent du cours 2026-27 », le ronéo du 06/10 ne le disant plus.
  Le garder ainsi, ou le remettre en attente si le professeur l'a dit sans que
  le ronéo le note ?
- (19/10) La fovéa capitis (`mi1-qr-fovea`) et les détails de l'articulation
  que le ronéo ne redit pas sont gardés sur le Ronéosaure 2024-25, puisque le
  professeur « invite à revoir le cours de l'an dernier » (p. 7). Préfères-tu
  qu'ils passent en « Absent du cours 2026-27 » ?
