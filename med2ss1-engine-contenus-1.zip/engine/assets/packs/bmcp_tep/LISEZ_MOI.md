# Bases physiques de l'imagerie médicale (partie 2) — paquet BMCP

76 notes, 177 cartes. Chapitre `chap-ue-bmcp-fc17` de l'UE BMCP, ordre 18.
Cours du **Pr Huglo, le 08/12/2025, de 8 h à 9 h**, dans le **Ronéosaure
2025-26** (FC n°18, 14 pages) : les acquisitions de la gamma-caméra, la caméra
à semi-conducteur (CZT), la TEP, les radiopharmaceutiques et le FDG. Les
annales viennent du Ronéosaure 2024-25 (polycopiés BMCP 16 et BMCP 21, quatre
sessions). Examen : mardi 5 janvier 2027.

**Fiche provisoire** (C16, décision de Vincent du 02/10) : le ronéo 2026-27 de
ce cours n'est pas encore paru. Chaque carte de cours cite la FC 2025-26 à sa
page et porte le tag `cours-2025-26` (badge « Cours 2025-26 ») ; le ronéo
2026-27 la corrigera quand il sortira. Aucune carte n'est « Absent du cours
2026-27 ».

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 29 | 29 |
| Texte à trous | 16 | 114 |
| QROC | 12 | 12 |
| Recto-verso | 9 | 9 |
| Lexique | 8 | 8 |
| Schéma cliquable | 1 | 4 |
| Planche à légender | 1 | 1 |

Dont **9 annales** sur 4 sessions : 7 QCM et 2 QROC (le second en
recto-verso, sa réponse étant une liste). Les 22 autres QCM sont des questions
de cours, avec une justification par proposition.

Sept thèmes, dans l'ordre du cours, **tous nouveaux** : leurs libellés sont dans `THEME_LABELS` (`app/src/med_engine/application/scopes.py`) depuis l'intégration du 05/10. `gamma-camera` est partagé avec
`bmcp_medecine_nucleaire`, avec le même libellé.

| Clé | Libellé | Notes |
|---|---|---|
| `gamma-camera` | La gamma-caméra | 4 |
| `acquisitions-scintigraphiques` | Acquisitions planaires, dynamiques, synchronisées, TEMP | 12 |
| `tep` | TEP : coïncidences, atténuation, temps de vol | 13 |
| `suv` | Quantification et SUV | 4 |
| `radiopharmaceutiques` | Radiopharmaceutiques et vecteurs | 22 |
| `fdg` | Le FDG et la préparation du patient | 10 |
| `irradiation-mn` | Irradiation en médecine nucléaire | 3 |

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-bmcp-tep-2526` — Ronéosaure, « FC n°18 - Bases physiques de l'imagerie médicale (pt 2) » (14 p.) | 2025-26 | le cours ; `SRC["fiche"]` et `SRC["medias"]`, 29 figures |
| `src-annales-bmcp-16-medecine-nucleaire` — « BMCP 16 - Médecine nucléaire » | 2024-25 | les 9 questions ; table de corrections p. 7 |
| `src-annales-bmcp-21-contrastes-en-irm` — « BMCP 21 - Contrastes en IRM » | 2024-25 | la copie des Q.22-24 de 2023/2024 S1, et leur image (p. 1) |

Les deux polycopiés sont déclarés exactement comme dans `bmcp_medecine_nucleaire`,
`bmcp_bases_physiques`, `bmcp_echographie_irm` et `bmcp_contrastes_irm`
(vérifié : même id, mêmes cinq champs). Les pages citées sont celles du PDF
(imprimées « n/14 », identiques). Le nom du PDF de la fiche porte une
apostrophe typographique (U+2019) ; il est en NFD sur le disque, écrit en NFC
dans `SOURCES`.

Lus en appoint, sans être déclarés, et cités dans les justifications : le
cours 2024-25 du même professeur (FC n°17 2024-25, « Bases physiques de
l'imagerie médicale (suite) »), qui tranche plusieurs erreurs de prise de
notes ; les FC n°16, 17 et 19 2025-26, pour les propositions d'annales qui en
relèvent (demande d'examen, produits de contraste iodés, rotor du scanner,
convention droite-gauche, gradients de l'IRM). Les deux erratas (cours 2025-26,
annales 2024-25) n'ont aucune entrée pour la FC n°18 ni pour BMCP 16 ou 21.

## Ce que le cours a dicté

- **Le rouge** (p. 3) : la scintigraphie rénale dynamique est « le seul examen
  qui permet d'étudier la fonction séparée des reins » → `tep-qr-fonction-separee`,
  `tep-fa-dynamiques`, `tep-qc-dynamiques` C. **Le rouge** (p. 9) : dire « TEP »
  sans préciser le traceur « ne veut pas dire grand-chose » → `tep-qc-traceurs-tep` E.
- **Le ✪** de l'atténuation (p. 7) → `tep-fa-attenuation`, `tep-qc-attenuation`,
  `tep-rv-nac-ac`.
- **« Isotopes à retenir ++ »** (p. 12), le fluor 18 et le gallium 68 →
  `tep-fa-isotopes-tep`, `tep-qr-gallium`.
- **« C'est ce qu'il faut retenir »** (p. 14) : la médecine nucléaire n'est ni
  plus ni moins irradiante que la radiologie → `tep-fa-doses`, `tep-qc-irradiation` A.
- **« Connaître la différence entre les 2 suivants est utile mais il n'est pas
  nécessaire de connaître leur nom »** (DTPA, DMSA, p. 11) → les cartes
  demandent la différence (scintigraphie rénale dynamique, fonction tubulaire),
  jamais le sigle : le recto-verso `tep-rv-dtpa-dmsa` et deux trous de
  `tep-fa-technetium-cibles` ; aucun QCM sur ces sigles.
- Le ronéo n'a pas de gris.

**Ce que ce chapitre ne refait pas** (plan C16, § 0.7) : le « résumé du dernier
cours » de la p. 2 (la constitution de la gamma-caméra d'Anger : collimateur,
cristal, guide de lumière, photomultiplicateurs, électronique), carté dans
`bmcp_medecine_nucleaire` sur la FC n°17 ; les particules, le traceur et le
marqueur, la théranostique (FC n°17) ; la scanographie (`bmcp_bases_physiques`) ;
les limites de dose (`bmcp_radioprotection`). Les cartes les citent.

## Les erreurs du Ronéosaure 2025-26

Le Ronéosaure n'est pas le ronéo de l'année : chaque erreur est portée par un
**ATTENTION nu** dans la carte qui tient la notion, la sorte dite dans le texte,
et rien n'entre dans `contenu/ERRATA_RONEOS_2026-27.md`.

| Page | Le ronéo dit | Retenu | Sorte | Carte |
|---|---|---|---|---|
| 2 | « 10 min, 300 000 coupes » | 300 000 **coups** : le pré-compte de la diapositive | prise de notes | `tep-fa-acquisition` |
| 3 | la courbe hépatique : « pic d'activité à 2 minutes » | la courbe de la diapositive culmine vers **12 min** (le ronéo 2024-25 aussi), rétention 24 % à 1 h | prise de notes | `tep-fa-dynamiques` |
| 4 | après Lasilix : « pas d'obstacle donc rétention purement mécanique » | pas d'obstacle : une simple dilatation des cavités ; le ronéo 2024-25 disait « absence de cause organique » | point douteux | `tep-qc-dynamiques` E |
| 5 | l'iode, « utilisé pour la thyroïde et les parathyroïdes » | formule ambiguë, que le ronéo 2024-25 partage (« l'iode et le technétium sont utilisés pour la thyroïde et les parathyroïdes ») : l'iode sert à l'examen des parathyroïdes, mais il n'y montre que la thyroïde, que l'on soustrait ; les parathyroïdes, c'est le sestamibi (MIBI-Tc, diapositive p. 5 ; p. 11) | point douteux | `tep-qc-parathyroides` A |
| 5 | la CZT remplace « le guide de lumière, le cristal et le collimateur » | elle remplace le cristal, le guide de lumière et les **photomultiplicateurs** (schéma de la diapositive) ; le collimateur reste (Slomka et al., J Nucl Med 2019;60:1194) | prise de notes | `tep-fa-czt` |
| 6 | « conversion neutron en protons » | un **proton** devient **neutron** (diapositive : « Proton decays to neutron ») | prise de notes | `tep-fa-annihilation`, `tep-qc-principe` E |
| 9 | le F-Na, « meilleure résolution du squelette en scintigraphie » | la p. 12 dit seulement la scintigraphie « plus simple et plus utilisée » ; la TEP au fluorure a plutôt la meilleure résolution | point douteux | aucune carte : la carte `tep-qc-traceurs-tep` C ne garde que la p. 12 |
| 10 | « l'irradiation … est liée au traceur et son acquisition » | elle vient du traceur injecté ; le nombre d'images n'y change rien (ronéo 2024-25, p. 16), seul le scanner associé ajoute une dose | point douteux | `tep-qc-irradiation` E |
| 11 | avec le carbone, « on ne peut pas voir les poumons séparément … contrairement au krypton » | ce qui se sépare, ce sont les deux images (ventilation, perfusion), grâce aux deux énergies (p. 2) | point douteux | `tep-rv-ventilation` |
| 11 | l'embolie : « des zones bien ventilées et des zones moins bien ventilées » | une ventilation **normale** et des défauts de **perfusion** (ronéo 2024-25, p. 13) | prise de notes | `tep-qc-traceurs-classiques` E, `tep-rv-embolie` |
| 12 | élimination urinaire « car le glucose n'est pas absorbé » | c'est le **FDG** que le rein ne réabsorbe pas, contrairement au glucose (ronéo 2024-25, p. 14) | prise de notes | `tep-qc-fdg` E |
| 12 | « le fluor empêche la déphosphorylation » | le FDG-6-P n'est pas transformé en fructose-6-P (ronéo 2024-25 ; diapositive : « ne subit que la 1re étape »), et la plupart des tissus ont peu de glucose-6-phosphatase (Buck et Reske, J Nucl Med 2004;45:461) | point douteux | `tep-fa-fdg-piegeage`, `tep-qc-fdg` C |
| 12 | « le F-DOPA va rentrer en compétition avec le glucose » | le **FDG** : toute la page en parle | prise de notes | `tep-qc-preparation` D |
| 12 | (diapositive) « Oxygène 15 » imprimé deux fois, à 2 et à 20 min | la ligne à 20 min est le **carbone 11** (20,4 min, LNHB) | le cours lui-même | `tep-fa-isotopes-tep` |
| 13 | la F-DOPA cible « les tumeurs non endocrines » | les tumeurs **endocrines** (diapositive : phéochromocytomes, paragangliomes, cancers médullaires de la thyroïde, tumeurs carcinoïdes ; ronéo 2024-25 : « neuro-endocrines ») | prise de notes | `tep-qc-autres-vecteurs` B |

Sans carte, parce qu'aucune n'en dépend : « un certain nombre de patients dont
la distribution est stable » (p. 2, phrase sans sens), « position qui rencontre
un électron » (p. 6, pour positon), « PMSA » (p. 12, pour PSMA, dit dans
`tep-qr-psma`), « Krypton 81 » (p. 10, la diapositive dit 81m : les cartes
écrivent 81m), le FDG « utilisé en cancérologie (Ex : pour les aortites) »
(p. 9 : les aortites relèvent de l'inflammation ; aucune carte ne reprend l'exemple).

## Ce que les annales ont dicté

Neuf questions de BMCP 16, toutes cartées ici (plan C16, § 12) ; les autres
questions de BMCP 16 sont dans les chapitres voisins (FC 16, 17, 19).

| Session | N° | Clé imprimée | Retenu | Carte | Remarque |
|---|---|---|---|---|---|
| 2023/2024 S1 | Q. 22 | ACE | ACE | `tep-an-2324s1-q22` | cas illustré (images A-G, image avant la question) ; copie : BMCP 21 Q.22 |
| 2023/2024 S1 | Q. 23 | ACDE | ACDE | `tep-an-2324s1-q23` | E : la droite du patient à gauche de l'image (FC 17 p. 3) ; copie : BMCP 21 Q.23 |
| 2023/2024 S1 | Q. 24 | AE | AE | `tep-an-2324s1-q24` | à jeun (p. 13) ; copie : BMCP 21 Q.24 |
| 2022/2023 S1 | Q. 24 | B | B | `tep-an-2223s1-q24` | radiopharmaceutiques de la TEP |
| 2022/2023 S2 | Q. 24 | ABCDE | ABCDE | `tep-an-2223s2-q24` | vecteurs du technétium (p. 11) |
| 2022/2023 S2 | QROC 1 | TEP-TDM au FDG | idem | `tep-anq-2223s2-qroc1` | images avant la question ; session discutée plus bas |
| 2022/2023 S2 | QROC 4 | à jeun ; pas de glucosé ou diabète équilibré ; ménopause ou absence de grossesse | idem, en recto-verso | `tep-anq-2223s2-qroc4` | même réserve de session |
| 2018/2019 S1 | Q. 22 | AD | AD | `tep-an-1819s1-q22` | TEMP (p. 4) ; C, D : le rotor du scanner (FC 17 p. 3) |
| 2018/2019 S1 | Q. 23 | CE | CE | `tep-an-1819s1-q23` | SUV (p. 9) |

Ce qui revient : le cas TEP-TDM au FDG (quatre questions et deux QROC, en
2023/2024 et en 2022/2023), sa préparation (le jeûne, trois fois), les vecteurs
du technétium, le SUV.

## Les clés qui ne sont pas reprises telles quelles

**Aucune** : les neuf clés imprimées sont justes et reprises telles quelles ;
`CONFLITS` est vide. Les deux QROC ont un corrigé dans la table : ils sont
`officielle=True`. Le QROC 1 demande le radiopharmaceutique « en toutes
lettres ainsi que son acronyme » : seule la réponse complète (« TEP-TDM au
fluorodésoxyglucose (FDG) ») est exacte, une réponse en sigles seuls (« TEP-TDM
au FDG ») est acceptable, un demi-point. Une réserve, dite dans les cartes sans
changer la clé :

| Question | Clé | Le point | À l'examen |
|---|---|---|---|
| 2022/2023 S2 QROC 1 et 4 | — | la session (voir les questions pour Vincent) | sans effet sur la réponse |

## Le schéma cliquable et la planche

| Fichier | Ce qu'on clique | Pourquoi ce dessin |
|---|---|---|
| `tep-coincidences.svg` | la coïncidence vraie, la diffusée, la fortuite, et l'événement simple (4 zones) | la diapositive des types de coïncidence (p. 6) et le texte des p. 6-7, redessinés en coupe transverse : le patient, la couronne de 72 détecteurs, une étoile par annihilation, une croix par photon absorbé, les détecteurs touchés noircis, la ligne enregistrée en tireté. Sur le schéma nu, tous les événements ont la même couleur ; la version légendée (`tep-coincidences-legende.svg`) reprend les couleurs du cours (vraie en noir, diffusée en rose, fortuite en bleu) et met l'événement simple en vert. Chaque zone enveloppe un événement entier, avec 14 px de marge ; les quatre sont placés dans quatre régions du disque et ne se touchent pas |

**La planche `tep-pl-fdg`** : la diapositive du FDG piégé (p. 12), légendes
effacées (`planche_depuis_image.py`) : 1 FDG, 2 GLUT, 3 hexokinase, 4
FDG-6-phosphate (ses sept occurrences effacées sous un seul numéro), 5 ATP, 6
cellule hypermétabolique ; huit intrus du même champ (glucose,
glucose-6-phosphate, fructose-6-phosphate, glucose-6-phosphatase,
phosphofructokinase, cellule normale, ADP, fluorocholine). La légende « FDG »
du cadre vert et la phrase de la diapositive (« FDG = 2-fluoro-2-déoxyglucose
… ») sont effacées avec le numéro 1, sans quoi elles donneraient la réponse ;
les deux formules du cadre vert restent. Les rectangles sont dans `donnees.py` ;
l'image numérotée se refait, depuis `app/`, par
`python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/bmcp_tep tep-pl-fdg --apercus <brouillon>`
(Pillow requis).

**Les figures** : 29 captures de diapositives de la FC 2025-26, extraites des
images du PDF — entières, quand le ronéo n'en montre qu'une partie (p. 2-14) —
la plupart réduites en 256 couleurs ; deux images d'annales, montrées avant la
question parce que les lire est la question : le cas de 2023/2024 S1 (BMCP 21,
p. 1, mieux résolu que BMCP 16 p. 2 ; recadré sous la phrase d'introduction) et
celui des QROC (BMCP 16, p. 5). Les images de TEP, de scintigraphie et de
scanner sont la matière du cours ; aucune photographie de patient.

**26 QCM sur 29 illustrés (90 %)**, 57 notes sur 76. Sans figure :
`tep-qc-radiopharmaceutiques`, `tep-qc-criteres`, `tep-qc-interets-limites`
(aucune diapositive ne montre ce qu'ils demandent).

## Le lexique

Huit termes, ceux du plan C16 ; aucun n'existait (vérifié contre les `lex-*`
de tous les paquets, et contre les lexiques des chapitres BMCP écrits en
parallèle). Pages mesurées dans le PDF de la FC 2025-26 (`chercher_pages.py`,
la p. 1, sommaire, exclue) :

| Terme | Origine | Pages |
|---|---|---|
| Parathyroïde | grec pará + thureoeidḗs | 2, 3, 5, 11, 12, 13 |
| Tomoscintigraphie | grec tómos + latin scintilla + grec gráphein | 4 |
| Semi-conducteur | latin semi- + conductor | 5, 6 |
| Positon | latin positivus + grec ḗlektron | 6 |
| Annihilation | latin adnihilatio (ad + nihil) | 6 |
| Coïncidence | latin médiéval coincidentia | 6, 7 |
| Métastable | grec metá + latin stabilis | 10 |
| Fluorodésoxyglucose | fluor + de- + oxús + glukús | 9, 12, 13 (le PDF écrit « fluoro-désoxyglucose » p. 12 et « FDG » ailleurs) |

Trois racines sont enseignées par les FC de sémantique et les citent :
`para- (grec)` (2/2, p. 8), `ad- (latin)` (2/2, p. 4), `ox-` (1/2, p. 6).
Racines nouvelles proposées à la table commune (`etymologies.json`), avec les
huit termes, dans `scratchpad/etym/bmcp_tep.json` : `thyr(o)-`, `semi-
(latin)`, `nihil (latin)`, `stabilis (latin)`, et `tom(o)-`, `scintill-
(latin)`, identiques (clé et contenu) aux propositions de `bmcp_bases_physiques`
et `bmcp_medecine_nucleaire`. Les autres racines reprennent les clés
existantes (`-oïde`, `-graphie`, `conducere (latin)`, `ponere (latin)`,
`électr(o)-`, `cum (latin)`, `in- (latin, dans)`, `cadere (latin)`, `méta-`,
`fluor- (latin)`, `dé- (latin)`, `gluc(o)-`). Les textes du lexique sont déjà
écrits dans la forme que `appliquer_etymologies.py` produirait (vérifié en
appliquant la table et les propositions).

## Questions pour Vincent

1. **La session des deux QROC d'imagerie de BMCP 16** (« la patiente » : l'examen
   réalisé, puis ses précautions). Le polycopié les range après 2022/2023
   session 2 et les corrige dans sa colonne ; le plan C16 doutait de cette
   session, « la patiente » pouvant renvoyer au cas de 2023/2024 S1. Les images
   imprimées avec ces QROC (BMCP 16, p. 5) sont celles d'un autre examen que le
   cas de 2023/2024 : la session imprimée, **2022/2023 S2**, est gardée, et les
   deux cartes le disent. Faut-il les déplacer, si tu as le sujet ?

## Décisions prises en route

- **Le brouillon du 03/10** ne contenait que `media/` (31 images) : chacune a
  été comparée aux images du PDF (écart moyen de pixel < 1 sur 255, la
  réduction en 256 couleurs) ou de l'annale (identiques), et gardée ; le reste
  du chapitre est écrit ici.
- **Les deux QROC sont officiels** : la table imprime leur corrigé. Le QROC 4,
  une liste, est un recto-verso ; le QROC 1 une QROC à plusieurs formulations
  exactes.
- **`EXAMENS` n'est pas déclaré**, comme dans tout chapitre BMCP.
- **Relecture du 05/10**, carte par carte contre les pages de la FC, la table
  de BMCP 16 et le ronéo 2024-25. Ce qui a changé :
  - l'iode « pour les parathyroïdes » (p. 5) passe de « prise de notes » à
    « point douteux » : le ronéo 2024-25 dit la même chose ;
  - la note A de 2018/2019 Q.22 perd sa nuance sur les caméras CZT en tunnel,
    que ni le cours ni une source ne portait ;
  - le QROC 1 n'accepte plus « TEP-TDM » seul, et les sigles seuls n'y valent
    qu'un demi-point ;
  - le QROC du MIP ne donne plus sa réponse dans la question ;
  - DTPA et DMSA : les cartes demandent la différence, plus les sigles ;
  - le texte à trous de la CZT limite aux basses énergies la seule
    sensibilité, comme la diapositive ;
  - le FDG : « l'OH du carbone 2 du glucose » remplacé par un fluor ;
  - deux références rectifiées. « Kapoor et al., AJR 2005 » n'a pas pu être
    vérifiée : l'article de Kapoor sur la TEP-TDM est paru dans RadioGraphics
    en 2004. C'est désormais Buck et Reske, J Nucl Med 2004, qui porte les deux
    faits. Le scanner « sans injection » n'est plus attribué à la FC n°17.
- `contenu/COUVERTURE.md` et `CHANGELOG.md` ne sont pas touchés : les chapitres
  C16 s'écrivent en parallèle, et l'orchestrateur les met à jour ensemble.

## À relire

**Aucune carte `a-relire`** : toutes citent une page de la FC 2025-26 ou une
source sûre nommée. Reste à Vincent :

- quand le ronéo 2026-27 de ce cours paraîtra, relire chaque carte sur lui ;
- `copier_les_cours.py` avec le dossier `…/examen janvier` du Ronéosaure
  2025-26, hors du bac à sable, pour que la fiche s'ouvre dans l'application.

## Intégration (05/10)

- Les libellés de thèmes sont dans `THEME_LABELS`
  (`app/src/med_engine/application/scopes.py`), bloc « BMCP FC n°6 à 22 ».
- Les étymologies proposées (racines et termes) sont versées dans
  `.claude/skills/nouveau-chapitre/scripts/etymologies.json` ;
  `appliquer_etymologies.py` n'a rien réécrit, les textes du lexique étant
  déjà à sa forme.
- `tom(o)-` et `scintill- (latin)` n'ont qu'une entrée, communes avec
  `bmcp_bases_physiques` et `bmcp_medecine_nucleaire`.

## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier (BMCP) ou du 6 janvier (SSH, papier). Sous les annales, 23 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 5 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `gamma-camera` | 2 | 1 | 1 |
| `tep` | 3 | 1 | 1 |
| `suv` | 3 | 1 | 1 |
| `radiopharmaceutiques` | 9 | 1 | 2 |
| `fdg` | 6 | 1 | 4 |

**Le schéma** `ech-tep`, « La TEP · l'examen, le SUV, les traceurs », donne 36 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_TEP`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- tep-an-2324s1-q22 B (l'examen peut être une IRM) : lire D et E comme des coupes de scanner (os blanc, fenêtre pulmonaire) relève du cours sur le scanner (FC n°21), hors des sources du chapitre ; la TEP-IRM existe (p. 9). Lettre posée sur la case « Faire une TEP-TDM ».
- tep-an-2324s1-q23 B (D et E, deux acquisitions) : une lecture d'image — deux coupes du même scanner — sans phrase de cours qui la porte.
- tep-an-2324s1-q23 E (le nodule dans le poumon droit) : la convention droite-gauche est à la FC n°17 (p. 3), hors des sources du chapitre.
- tep-an-2324s1-q24 A (la demande écrite) et C (la fonction rénale), et tep-an-2223s1-q24 D (la fonction rénale) : la demande d'examen et les produits de contraste iodés sont aux FC n°16 et 17, hors des sources ; tep-an-2324s1-q24 B (l'allergie aux produits iodés) n'a que la moitié de sa réponse dans la FC n°18 — le radiopharmaceutique ne donne normalement pas d'allergie (s21, qui la prépare). Lettres posées sur la case du MRP.
- tep-an-1819s1-q22 C et D (le rotor du scanner, lent ou continu) : FC n°17 (p. 3), hors des sources ; E (l'aimant de l'IRM) : FC n°19. Lettres posées sur la case « Faire une TEP-TDM ».

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```
