# ECL Remédiation — le squelette

L'UE, ses sept chapitres, ses quatre épreuves. Les cartes vivent à côté, un
paquet par chapitre : six chapitres sur sept en ont. Seul « Mort cellulaire »
attend son cours.

## Ce qui est en cartes

| Paquet | Contenu | Clés |
|---|---|---|
| `remed_biostats` | test intermédiaire 1 de 2023-24, questions 1 à 15 | officielles |
| `remed_biochimie` | test intermédiaire 1 de 2023-24, questions 16 à 35 | officielles |
| `remed_biochimie` | séance 1 : 7 QCM et 3 questions ouvertes | déduites |
| `remed_immuno` | les deux séances d'immunologie de 2025-26 (diapositives du 16/10 et du 23/10/2025), 109 notes ; test 2 de 2024-25, questions 1 à 20 | déduites |
| `remed_pharmaco` | la séance de pharmacologie 2025, 56 notes ; test 2 de 2024-25, questions 21 à 35 | déduites |
| `remed_souches` | « Le tissu… » (diapositives du 31/10/2024, distribuées le 16/10/2025), 88 notes ; test 3 de 2024-25, questions 15 à 21 | déduites |
| `remed_gene_proteine` | « Du gène à la protéine » 2024, 79 notes ; test 3 de 2024-25, questions 1 à 10 et 14 | déduites |

Les quatre derniers chapitres (C30, 19/10/2026) sont bâtis sur des
diapositives d'une année passée, données par Vincent : leurs cartes portent le
badge de leur année. Les tests 2 et 3 de 2024-25 n'ont pas de corrigé : ce
sont des photos d'une copie annotée par un étudiant. Leurs clés sont déduites
du cours ; les annotations ne servent que de contre-épreuve, et chaque carte
dit où elles divergent. Les cas que ni le cours ni une source sûre ne
tranchent portent le tag `a-relire` : cinq annales en tout, détaillées dans
le `LISEZ_MOI.md` de leur chapitre.

Les clés officielles sont les propositions **entourées** sur la correction
diffusée, relevées page par page. Deux vont contre le cours et portent le tag
`a-relire` : la Q25 compte la néoglucogenèse comme catabolique, la Q35 refuse
que le transport actif secondaire « assure le transport du glucose ». Elles
sont gardées, puisque ce sont elles qui notent, et leur justification le dit.

La séance 1 n'a pas de corrigé : ses clés sont déduites. Sa question 2 n'est
pas reprise, c'est mot pour mot la Q21 du test.

## Ce qui attend

- **Deux planches**, à relire avant d'écrire : la carte métabolique de la
  séance 1 (douze cadres vides, dix mots) et la mitochondrie en microscopie
  électronique.
- **Le test 1 de 2025-2026** : sujet en photos HEIC ; son corrigé officiel est
  la colonne « bonne réponse » d'un relevé de résultats d'étudiant, dont seul ce
  corrigé servira.
- **Le test 3 de 2024-25, questions 22 à 36** (mort cellulaire) : elles
  attendent le cours de « Mort cellulaire » (séances 7 et 8). La page des
  questions 11 à 13 n'a pas été photographiée.
- **Le rattrapage de juin 2025** (session 2, toute l'UE) : dix captures de
  369 × 800 px, illisibles mot à mot. Il faut les photos d'origine.
- **Les diapositives 2026-27** des séances 4 et 5 : les cartes d'immunologie,
  de cellules souches et de pharmacologie sont faites sur celles de 2025-26.
  Elles se relisent sur celles de l'année quand elles arrivent.

## D'où vient la structure

Du syllabus 2026-2027 (Pr Pluquet). L'ECL tient en dix séances le jeudi matin,
du 24 septembre au 10 décembre, sur sept thèmes :

| Chapitre | Séances | Épreuve |
|---|---|---|
| Biostatistiques | 1 et 2 · 24/09, 01/10 | test intermédiaire 1 · 08/10 |
| Biochimie et énergétique | 1 et 2 · 24/09, 01/10 | test intermédiaire 1 · 08/10 |
| Immunologie | 4 et 5 · 15/10, 22/10 | test intermédiaire 2 · 29/10 |
| Cellules souches et renouvellement tissulaire | 4 · 15/10 | test intermédiaire 2 · 29/10 |
| Pharmacologie | 5 · 22/10 | test intermédiaire 2 · 29/10 |
| Du gène à la protéine | 7 et 8 · 19/11, 26/11 | test intermédiaire 3 · 03/12 |
| Mort cellulaire | 7 et 8 · 19/11, 26/11 | test intermédiaire 3 · 03/12 |

Le test final (10/12) couvre toute l'UE. Les quatre épreuves sont déclarées
comme sessions d'examen : la planification ramène les cartes de chaque
chapitre avant la date qui le concerne. Un chapitre par **thème** et non par
séance, parce que les tests sont découpés par thème — « Biostatistique »,
puis « Biochimie » — et que c'est ce qu'on révise.

Les enseignants changent d'un groupe à l'autre : seules les dates figurent
sur les chapitres, elles sont vraies pour tout le monde.

## Notation

3 points de présence (0,5 par séance), puis 17 points : moitié contrôle
continu — **les deux meilleurs** des trois tests intermédiaires —, moitié
test final. Tous les tests sont des QCM **avec degré de certitude**, sur six
niveaux de 0 à 100 %.

## Ce qui a été déposé, et où ça ira

Rangé dans `Ajouts/A traiter/ECL REMED`, hors du dépôt.

**Biochimie et énergétique**

- Le support des séances 1 et 2 (9 pages), rattaché au chapitre et lisible
  depuis l'application. Cinq parties : révision protéines, glucides et lipides
  en QCM (d'après l'épreuve LAS1 2021-22), enzymologie, voies métaboliques,
  **une mitochondrie en microscopie électronique à légender** — exactement le
  type de carte « planche » —, et une analyse de documents sur le lactose.
- Les polycopiés LAS 2024 : protéines (71 p), lipides (86 p), glucides (63 p).
  Ce sont des références de fond, pas le cours de l'ECL.

**Biostatistiques**

- Une fiche A4 manuscrite (variables, intervalle de confiance, tests
  univariés) : le format que le test 1 autorise en salle.

**Annales**

- Test intermédiaire 1, 2023-2024 : sujet et correction en PDF, 35 QCM —
  biostatistique aux questions 1 à 15, biochimie ensuite.
- Une copie d'étudiant corrigée du test 1 (2 pages). Elle porte un nom : elle
  sert à vérifier une clé, jamais à être diffusée.
- Tests intermédiaires 1, 2 et 3 : 31 photos HEIC. Le test 2 est celui du
  24/10/2024 (35 QCM : immunologie, pharmacologie), le test 3 celui du
  25/11/2024 (36 QCM : du gène à la protéine, tissus et cellules souches, mort
  cellulaire). Les deux sont sur une copie annotée par un étudiant ; ils sont
  en cartes depuis C30, sauf la mort cellulaire.
- Session 2 de juin 2025 (le rattrapage) : 10 captures de 369 × 800 px,
  rangées **deux fois**, dans « test final » et dans « rattrapages » — ce sont
  les mêmes fichiers octet pour octet. La résolution est limite pour relire
  une proposition sans se tromper.

**Donnés par Vincent le 18/10, hors d'`Ajouts/`**

Les cinq supports des séances 3 à 8 des années passées : immunologie parties 1
et 2 (2025-26, la seconde en export Wooclap, sans les questions), « Le tissu…
cellules souches » (diapositives de 2024), pharmacologie (2025), « Du gène à
la protéine » (2024). Ils sont copiés dans `cours\Remediation\` sous les noms
que déclarent les chapitres, et lisibles depuis l'application.

**À redemander**

- Le Wooclap de la séance 1 est un fichier **vide** (0 octet) : probablement
  un raccourci de Drive qui n'a pas été téléchargé.

## Pistes

Le degré de certitude de l'ECL rejoint ce que l'application demande avant
chaque correction (« sûr », « hésitant », « au hasard »). L'ECL en tire un
profil en quatre cases — méprise grave, méconnaissance, mi-connaissance,
maîtrise — qu'on pourrait calculer sur les révisions de cette UE.
