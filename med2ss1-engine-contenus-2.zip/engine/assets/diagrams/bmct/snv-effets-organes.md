---
id: bmct/snv-effets-organes
titre: Sympathique et parasympathique — qui fait quoi, organe par organe (récepteurs α, β, M)
ue: BMCT
chapitre: FC n°4 - Pharmacologie du système nerveux végétatif, effets sympathiques et parasympathiques (partie 1, p. 9-13 ; partie 2, p. 3)
themes_app: [bmct_snv/pupille, bmct_snv/effets-snv, bmct_snv/synapse-adrenergique]
cartes_en_plus: [snv-fa-muscariniques, snv-qc-muscariniques, snv-an-2324-q13, snv-an-2122-q8]
cartes_exclues: [snv-qc-synapse-adrenergique, snv-fa-synthese-na]
mots_cles: [effets sympathiques, effets parasympathiques, β1, β2, α1, M2, M3, cœur, bronches, vaisseaux, myosis, mydriase, salive, tube digestif, vessie, atropine]
schema: snv-effets-organes.html
majeur: true
date: 2026-10-20
---

## Explication

> Cours : tableaux des récepteurs adrénergiques (partie 1, p. 9) et muscariniques (p. 12), effets (p. 13), œil (partie 2, p. 3). « Les différents sous-types de récepteurs ne sont pas à apprendre » (p. 13), mais les annales interrogent β1 et β2 (2024/2025 S1 Q15, 2021/2022 Q.9, 2020/2021 Q.8, 2016/2017 Q.10). Simplifications : vessie et intestin côté sympathique donnés par leur effet global ; la salive α1 et l'astuce mnémotechnique sont du complément ; la sudation (α1 localisée du stress, M3 généralisée) n'est pas représentée. Complète [[bmct/snv-recepteurs]].

### Le schéma

Une silhouette, sept organes ; à gauche en orange le sympathique (stress, effort : noradrénaline sur α et β), à droite en violet le parasympathique (repos : acétylcholine sur M). Sur chaque ligne, les deux systèmes font l'inverse l'un de l'autre.

| Organe | Sympathique | Parasympathique |
|---|---|---|
| Œil | α1 : mydriase (muscle dilatateur) | M3 : myosis (muscle sphincter) |
| Salive | salive rare, épaisse | M3 : salive abondante |
| Cœur | **β1 : accélère, plus fort** | **M2 : ralentit** |
| Bronches | **β2 : dilatées** | M3 : resserrées, sécrétions |
| Vaisseaux | **α1 : resserrés** | peu d'innervation |
| Tube digestif | ralentit le transit | M3 : accélère, diarrhée |
| Vessie | retient l'urine | M3 : vide la vessie |

Et aussi : β3 → lipolyse (tissu adipeux).

### Les récepteurs à retenir

β1 → cœur (cible des bêtabloquants) ; β2 → bronches (cible du salbutamol) ; α1 → vaisseaux et œil ; M2 → cœur ; M3 → tout le reste du parasympathique. Astuce : β1, 1 cœur ; β2, 2 poumons.

### La méthode pour les médicaments

Un médicament qui imite un système produit sa colonne ; un médicament qui le bloque produit la colonne d'en face. L'atropine (antagoniste M) donne la colonne orange : mydriase, bouche sèche, tachycardie, constipation, rétention urinaire. Un anticholinestérasique donne la colonne violette.

## Cartes

### Q: Quel récepteur adrénergique accélère le cœur, et lequel dilate les bronches ?
R: β1 accélère le cœur ; β2 dilate les bronches (β1, 1 cœur ; β2, 2 poumons).

### Q: Quel récepteur muscarinique ralentit le cœur, et lequel commande les autres organes du parasympathique ?
R: M2 ralentit le cœur ; M3 commande l'œil (myosis), la salive, les bronches, l'intestin et la vessie.

### Q: Quels effets donne l'atropine sur l'œil, le cœur, la salive, l'intestin et la vessie ?
R: Ceux du sympathique, puisqu'elle bloque le parasympathique : mydriase, tachycardie, bouche sèche, constipation, rétention urinaire.

### Q: Quel récepteur provoque la vasoconstriction sympathique ?
R: α1, sur les fibres musculaires lisses des vaisseaux.
