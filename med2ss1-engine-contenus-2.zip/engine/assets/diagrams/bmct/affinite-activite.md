---
id: bmct/affinite-activite
titre: Affinité et activité intrinsèque — schéma récapitulatif
ue: BMCT
chapitre: FC n°1 - Pharmacodynamie générale, I.B Quantification de la puissance et I.E Agoniste / Antagoniste (p. 3-5)
themes_app: [bmct_pharmacodynamie/agonistes]
cartes_en_plus: [pdg-fa-doses50, pdg-qc-dl50, pdg-rv-affinite-activite]
cartes_exclues: []
mots_cles: [affinité, activité intrinsèque, CE50, dose 50, courbe dose-effet, plateau, occupation des récepteurs, agoniste partiel, buprénorphine]
schema: affinite-activite.html
majeur: true
date: 2026-10-18
---

## Explication

> Récapitulatif qui complète [[bmct/activite-intrinseque]]. Le cours donne la classification par l'activité intrinsèque, la dose 50 et la buprénorphine ; la séparation entre courbe d'occupation et courbe d'effet (modèle simple d'occupation) est un outil de compréhension, et les valeurs du schéma sont illustratives.

### Deux questions différentes posées au même médicament

- **Affinité : se fixe-t-il ?** C'est la force de la liaison au récepteur. Elle décide de la concentration nécessaire pour occuper les récepteurs.
- **Activité intrinsèque (α) : une fois fixé, qu'active-t-il ?** C'est l'effet produit quand tous les récepteurs sont occupés, rapporté à l'effet maximal.

Image de la clé et de la serrure : l'affinité dit si la clé entre bien dans la serrure et y reste ; l'activité intrinsèque dit ce qu'elle fait une fois dedans (tourner à fond, à moitié, pas du tout, ou verrouiller davantage).

### Ce que montre le schéma

Deux courbes en fonction de la concentration du ligand (échelle logarithmique) :

- **en pointillés, la part des récepteurs occupés** : elle ne dépend que de l'affinité. Le point marque la CE50, la concentration qui occupe la moitié des récepteurs ;
- **en trait plein, l'effet produit** : c'est l'occupation multipliée par l'activité intrinsèque.

D'où la règle de lecture d'une courbe dose-effet :

- **l'affinité fixe la position horizontale** : forte affinité, courbe à gauche, il en faut peu ;
- **l'activité intrinsèque fixe la hauteur du plateau**, que rien ne dépasse, même à dose énorme.

Les deux réglages sont indépendants : le schéma permet de les faire varier séparément (curseurs) ou de charger un cas type (boutons).

### Récapitulatif

| Ligand | Se fixe (affinité) | Active (α) | Sur la courbe |
|---|---|---|---|
| Agoniste entier | oui | à fond, α = 1 | plateau à 100 % |
| Agoniste partiel | oui | en partie, 0 < α < 1 | plateau plus bas, quelle que soit la dose |
| Antagoniste | oui, souvent très bien | pas du tout, α = 0 | plat au niveau basal ; son effet n'apparaît qu'en présence d'un agoniste |
| Agoniste inverse | oui | il verrouille, α < 0 | un peu sous le niveau basal (−5 à −10 % d'AMPc) |

### Les pièges

- **Bien se fixer n'est pas bien activer.** Un antagoniste peut avoir une excellente affinité et une activité intrinsèque nulle : c'est même ce qui le rend efficace, il prend la place de l'agoniste.
- **La dose compense une faible affinité, jamais une faible activité intrinsèque.** Un agoniste entier de faible affinité atteint le même plateau, plus à droite ; un agoniste partiel reste sous son plateau quelle que soit la dose.
- **La buprénorphine** (Subutex) : affinité très forte, activité intrinsèque partielle sur les récepteurs μ. Elle s'accroche mieux que l'héroïne et lui prend sa place, mais active moins le récepteur : d'où son rôle de traitement de substitution.
- Nuance : la puissance d'un agoniste dépend surtout de l'affinité, et un peu de l'activité intrinsèque. Retenir « affinité = position, activité intrinsèque = plateau » suffit.

## Cartes

### Q: Sur une courbe dose-effet, quelle propriété du ligand fixe la position horizontale de la courbe, et laquelle fixe la hauteur du plateau ?
R: L'affinité fixe surtout la position horizontale (CE50 : forte affinité, courbe à gauche). L'activité intrinsèque fixe la hauteur du plateau (effet maximal).

### Q: Peut-on compenser une faible activité intrinsèque en augmentant la dose ?
R: Non. La dose compense une faible affinité (on atteint le même plateau, à plus forte concentration), mais pas une faible activité intrinsèque : le plateau d'un agoniste partiel reste plus bas quelle que soit la dose.

### Q: Un antagoniste a-t-il une affinité pour son récepteur ?
R: Oui, souvent très forte : il se fixe et occupe le récepteur. C'est son activité intrinsèque qui est nulle, et c'est son affinité qui lui permet d'empêcher l'agoniste d'agir.

### Q: Pourquoi la buprénorphine réduit-elle l'effet de l'héroïne ?
R: Elle a une affinité très forte pour les récepteurs μ (elle prend la place de l'héroïne) mais une activité intrinsèque partielle (elle les active moins) : l'effet total baisse.
