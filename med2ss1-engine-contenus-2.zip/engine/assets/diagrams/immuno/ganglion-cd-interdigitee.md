---
id: immuno/ganglion-cd-interdigitee
titre: Le ganglion lymphatique — cortex superficiel, cortex profond, médulla — et la place de la CD interdigitée
ue: Immunologie
chapitre: Organes et circulation des cellules immunitaires ; cellules dendritiques et présentation aux LT
themes_app: [immuno_organes/ganglions]
cartes_en_plus: [lym-rv-ganglion-rate, lym-ech-m4, lym-ech-s3, imm-ech-m3, imm-ech-s8, imm-ech-s9, imm-ech-s11, imm-an-1718-q9, alb-ech-s15, alb-qr-cdf, alb-zo-cortex]
cartes_exclues: [lym-qc-adenopathie-territoire, lym-qr-adenopathie]
mots_cles: [ganglion lymphatique, cortex superficiel, follicule, centre germinatif, cortex profond, paracortex, médulla, hile, lymphe afférente, lymphe efférente, cellule dendritique, CD interdigitée, CD immature, LT naïfs, plasmocytes, cellules dendritiques folliculaires, CDF]
schema: ganglion-cd-interdigitee.html
majeur: true
date: 2026-10-24
---

## Explication

> Cours : ronéo 2026-27 « Les cellules dendritiques » (p. 7), FC n°8 2024-25 (p. 7), ronéo 2026-27 des organes lymphoïdes (p. 6). Schéma simplifié, sans échelle.

### Les trois zones

| Zone | Qui y vit | À quoi elle sert |
|---|---|---|
| Cortex superficiel | Lymphocytes B, en follicules (et CDF) | Réponse B ; un follicule activé forme un centre germinatif |
| Cortex profond (paracortex) | LT naïfs et CD interdigitées | La rencontre CD–LT : présentation de l'antigène |
| Médulla | Plasmocytes, macrophages | Sécrétion des anticorps, qui partent avec la lymphe efférente |

La lymphe entre par les vaisseaux afférents (bord convexe) et ressort par le hile (lymphatique efférent).

### Le voyage de la CD

1. Tissu : immature, en sentinelle, elle capture l'antigène.
2. Lymphe afférente : elle migre vers le ganglion le plus proche et mûrit en route.
3. Cortex profond : mature, elle devient interdigitée (longs prolongements entre les lymphocytes) et présente l'antigène aux LT naïfs.

Logique : la CD présente l'antigène aux LT, donc elle s'installe chez les LT, dans le cortex profond.

### Les pièges

- La médulla : le ronéo 2026-27 des organes lymphoïdes y range « les cellules présentatrices d'antigènes » (p. 6), point douteux (déjà signalé par `lym-qc-ganglion-structure`) ; le cours (FC n°8 2024-25, p. 7) et la clé de 2017/2018 Q9 E placent la CD interdigitée dans le cortex profond.
- CDF ≠ CD : les cellules dendritiques folliculaires, dans les follicules B, sont un autre type cellulaire, non issu de la moelle ; elles ne présentent pas de peptides aux LT et gardent l'antigène natif pour les LB.

## Cartes

### Q: Où se trouvent les lymphocytes B et les lymphocytes T dans le ganglion ?
R: Les LB dans le cortex superficiel, en follicules ; les LT dans le cortex profond (paracortex), avec les CD interdigitées.

### Q: Pourquoi la CD mature s'installe-t-elle dans le cortex profond du ganglion ?
R: Parce qu'elle doit présenter l'antigène aux LT naïfs, qui s'y trouvent ; elle y devient interdigitée.

### Q: Une cellule dendritique folliculaire est-elle une cellule dendritique présentatrice pour les LT ?
R: Non : c'est un autre type cellulaire, non issu de la moelle, situé dans les follicules B ; elle garde l'antigène natif à sa surface pour les LB.
