---
id: immuno/complement
titre: Le système du complément — trois voies, une cascade à partir de C3, trois effets
ue: Immunologie
chapitre: Immunité innée et réponse inflammatoire — le complément
themes_app: [immuno_innee/complement-voies, immuno_innee/complement-effets]
cartes_en_plus: [inn-qc-opsonisation, anc-qc-cdc, inf-ech-s5, inf-ech-m2, inf-an-2425s1-q9]
cartes_exclues: []
mots_cles: [complément, voie classique, voie des lectines, voie alterne, C1q, MBL, MASP, C3 convertase, C4b2a, C3bBb, C5 convertase, C3b, opsonisation, C3a, C5a, anaphylatoxines, CAM, C5b-9, lyse, facteur H, facteur I, DAF, MCP, CD59, C1-inhibiteur, angio-œdème héréditaire]
schema: complement.html
majeur: true
date: 2026-10-24
---

## Explication

> Schéma fourni par Vincent (fiche « Immunologie, partie 1 », section 7 : https://claude.ai/artifact/84U99NbJwDZSXbtZHNRdca), mis au format MED_ENGINE. Cours : Immuno_partie1_161025 (16/10/2025) et chapitres `immuno_*` de l'application.

### Le schéma

Trois déclencheurs différents aboutissent à une C3 convertase ; tout converge sur la coupure de C3. C3b opsonise et forme la C5 convertase ; C5a (et C3a) donnent l'inflammation ; C5b amorce le complexe d'attaque membranaire. La voie alterne amplifie toutes les voies.

- **Voie classique** : C1q sur des anticorps (IgM, IgG) liés au microbe ; C1r, C1s coupent C4 puis C2. Avec anticorps.
- **Voie des lectines** : MBL, ficolines sur les sucres du microbe ; les MASP coupent C4 puis C2. Sans anticorps.
- **Voie alterne** : C3 activé spontanément se dépose sur une surface non protégée ; facteurs B et D, properdine. Sans anticorps, en continu.
- **C3 convertases** : C4b2a (voies classique et lectines ; C4b2b selon les cours) ; C3bBb (alterne, stabilisée par la properdine). Chaque C3b peut former une nouvelle C3bBb : boucle d'amplification.
- **Trois effets** : opsonisation (C3b, récepteurs CR1 et CR3 des phagocytes) ; inflammation (C3a, C5a, anaphylatoxines : mastocytes, vasodilatation ; C5a attire les neutrophiles) ; lyse par le CAM (C5b + C6, C7, C8, n × C9 : pore dans la membrane ; surtout Gram négatif, *Neisseria*).
- **Régulation** : nos cellules se protègent (facteur H, facteur I, DAF/CD55, MCP/CD46, CD59) ; le C1-inhibiteur freine la voie classique, son déficit donne l'angio-œdème héréditaire.

### Les pièges

- Le complément n'est pas déclenché par les PRR des cellules.
- Ce sont des clivages (protéolyse), pas des « lyses » successives.
- Le CAM est C5b-9, et non C5a-9.
- La voie classique dépend des anticorps, mais le complément reste un acteur de l'immunité innée.

## Cartes

### Q: Sur quelle molécule convergent les trois voies du complément, et en quoi est-elle coupée ?
R: Sur C3, coupé par une C3 convertase en C3a (petit fragment, inflammation) et C3b (gros fragment, opsonisation et C5 convertase).

### Q: Quelles sont les trois fonctions effectrices du complément et les fragments responsables ?
R: Opsonisation (C3b) ; inflammation et recrutement (C3a, C5a, anaphylatoxines) ; lyse par le complexe d'attaque membranaire (C5b-9).

### Q: Quelle voie du complément dépend des anticorps ?
R: La voie classique (C1q se fixe sur des IgM ou IgG liés au microbe) ; les voies des lectines et alterne fonctionnent sans anticorps.
