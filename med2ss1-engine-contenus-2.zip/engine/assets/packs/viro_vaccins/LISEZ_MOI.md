# Vaccins viraux — paquet Virologie

145 notes, chapitre `chap-ue-virologie-fc10` (ordre 10), UE `ue-virologie`. Sources : la FC
n°10 du **Ronéosaure 2025-26** en deux parties (le cours du Pr Hober, les 08 et 09/12/2025), le
polycopié d'annales **VIROLOGIE 10 - Vaccins viraux** du Ronéosaure 2024-25 (quatorze sessions,
2015/2016 S1 à 2023/2024 S1) et la session 2024/2025, du sujet de l'examen du 09/01/2025
(sans corrigé), dont le ronéo 2025-26 imprime lui-même six questions avec une « Correction ».
Le ronéo 2026-27 corrigera les cartes à sa parution (Vincent, 02/10/2026, tâche C16) : aucune
carte n'est « Absent du cours 2026-27 », et toutes les cartes de cours portent le badge
« Cours 2025-26 ».

**18/10/2026** : 7 questions du sujet de virologie 2025/2026 (examen du
08/01/2026, sans corrigé) — Q.23, Q.24, Q.25, Q.26, Q.27, Q.28, Q.29 ; voir «
Le sujet 2025/2026 ».

| Source | Fichier (dossier des PDF de cours) | Pages | Ce qu'on y prend |
|---|---|---|---|
| `src-fc-viro-fc10a` | `VIROLOGIE/FC n°10 partie 1 - Vaccins viraux.pdf` | 17 | HPV, polio, arbovirus, VZV, recombinants, dengue, réplicons, ADN, ARN, conclusion ; annales 2024/2025 p. 16-17 |
| `src-fc-viro-fc10b` | `VIROLOGIE/FC n°10 partie 2 - Vaccins viraux.pdf` | 9 | vaccins inactivés : rage, grippe, hépatite A ; antigènes viraux : VHB-VHD, VRS, SARS-CoV-2, zona |
| `src-annales-virologie-10-vaccins-viraux` | `S1/ANNALES/Examens de Janvier/Virologie/VIROLOGIE 10 - Vaccins viraux.pdf` | 31 | 58 questions ; table p. 28 ; 2019/2020 S1 en captures p. 17-18 et 29-31 |
| `src-sujet-viro-2425` | — (sujet d'examen, `kind="examen"`) | 16 | « Sujet de virologie 2024/2025, session 1 », examen du 09/01/2025, 30 QCM, sans corrigé : source de la session 2024/2025 (`SRC["sessions"]`, qui pointait vers la FC n°10 partie 1 jusqu'au 15/10/2026) ; Q.23 à Q.30 ici ; déclaration identique dans tous les chapitres de virologie |

Le polycopié d'annales est partagé avec `viro_vaccins_vivants` : il est déclaré avec les seuls
champs convenus (id, kind, titre, chemin_relatif, auteur), pour que les deux paquets le
déclarent à l'identique.

## Ce qu'il contient

| Type | Notes | Dont |
|---|---|---|
| QRM | 99 | 73 annales sur 16 sessions, 26 QCM de cours |
| Texte à trous | 14 | 85 trous |
| QROC | 12 | |
| Recto-verso | 10 | 7 « un exemple de chaque type » (consigne du professeur, p. 15) |
| Zone | 1 | le principe du vaccin anti-HPV, 6 zones |
| Planche à légender | 1 | la diapositive des types de vaccins, 6 numéros, 3 intrus |
| Lexique | 8 | |

Thèmes (8) : `vaccins-types`, `vaccins-inactives`, `hepatites`, `hpv`, `polio`, `arbovirus`,
`varicelle-zona`, `vaccins-nouveaux`. Leurs libellés sont à ajouter à `THEME_LABELS`.

Ce chapitre ne refait pas, d'après le plan C16 : l'introduction de la vaccinologie (immunisation
active, principe des vivants atténués), la variole, le ROR, les infections congénitales, le
rotavirus (`viro_vaccins_vivants`, FC n°11) ; les glissements et cassures comme notion
(`viro_virus_hote`, `viro_pathogenes_1`).

## Ce que le cours a dicté

- **La consigne de la conclusion** (partie 1, p. 15) : « être en mesure de donner un exemple de
  vaccin de chaque type ». D'où la planche `vac-pl-types`, une carte recto-verso par type et le
  tableau `vaccins-exemples.svg`, en correction de nombreuses questions.
- **« Les diapos suffisent »** et « le professeur a toujours de l'imagination » (p. 16) : les
  QCM de cours jouent sur les mêmes oppositions que les annales (vivant ou inactivé, IgG ou IgA,
  avant ou après l'immunodépression, réservoir humain ou simien).
- **Le gris** : « TICOVAC® et ENCEPUR®, peu importe les noms » (p. 7) — noms non cartés. La
  définition de la prophylaxie et les anticorps antirabiques « non mentionnés à l'oral mais
  présents sur le diapo » (partie 2, p. 2 et 4) sont la voix des rédacteurs : cartés.
- Pas de rouge dans ces deux FC.

## Ce que les annales ont dicté

| Sujet | Questions | Cartes de cours qui y préparent |
|---|---|---|
| Arbovirus : fièvre jaune, dengue, encéphalites japonaise et à tiques | 16 | `vac-qc-fievre-jaune`, `-tiques`, `-japonaise`, `-dengue`, 4 textes à trous |
| Vaccin anti-HPV | 11 | `vac-qc-hpv-*`, `vac-zo-hpv`, 2 textes à trous, 2 QROC |
| Vaccin anti-VHB (et le VRS) | 11 | `vac-qc-vhb-marqueurs`, `vac-qc-hepatites`, `vac-fa-vhb-vaccin` |
| Varicelle et zona | 9 | `vac-qc-varicelle-vaccin`, `vac-qc-zona`, `vac-fa-zona` |
| Poliovirus | 8 | `vac-qc-vpi-vpo`, `-polio-*`, `vac-rv-vpi-vpo` |
| Grippe, rage, hépatite A | 7 | `vac-qc-inactives`, `-rage-*`, `-grippe-*` |
| Recombinants, adénovirus, ARN | 4 | `vac-qc-recombinants`, `-replicons`, `-arn`, `-adn-nu` |

Ce qui revient à chaque session : le vaccin anti-HPV induit des IgG, pas d'IgA ; le vaccin
anti-VHB est l'Ag HBs recombinant, protège du VHD, et le vacciné n'a pas d'anti-HBc ; la fièvre
jaune n'existe pas en Asie du Sud-Est ; le VPI se donne à tous, la femme enceinte comprise ; le
vaccin varicelle se donne avant l'immunodépression.

## Le schéma cliquable et la planche

| Fichier | Ce qu'on clique | Pourquoi |
|---|---|---|
| `hpv-vaccin-nue.svg` (`vac-zo-hpv`) | le point d'injection et les VLP, les IgG sériques, la transsudation, la couche basale que l'HPV infecte, les kératinocytes où L1 et L2 s'assemblent, la surface de la muqueuse, où les IgG neutralisent | la figure 5 de l'annale 2020/2021 S1 Q.12 est ce schéma ; le cycle de la p. 3 s'y lit en même temps |
| `vac-types-numerotee.png` (`vac-pl-types`) | les six secteurs de la diapositive de conclusion | la consigne du professeur |

La planche est une photographie de diapositive (une image, pas de texte PDF) : les rectangles
à blanchir sont dans `donnees.py`, l'image numérotée sort de `planche_depuis_image.py`. Deux
secteurs portent chacun deux légendes sur la diapositive (« sous-unités » et « antigène
recombinant » ; « vecteur viral non réplicatif » et « virus recombinant ») : un seul numéro par
secteur, sans quoi l'ordre des deux légendes se devinerait au hasard. Les intrus sont ceux du
plan : le vaccin à ADN nu et le vaccin hétérologue (la vaccine, FC n°11), plus le vaccin à
peptides synthétiques ; les deux biotechnologies sont dans la liste de la p. 14, aucun des trois
n'est sur la figure.

## Les illustrations

99 QCM sur 99 illustrés, toujours du côté de la réponse. Huit figures des FC (gènes de l'HPV,
entérovirus, VPI-VPO, cycle des tiques, types de vaccins, virus de la rage, composition du vaccin
grippal) et quatre tableaux redessinés (`vaccins-exemples.svg`, `arbovirus-vaccins.svg`,
`vhb-vaccin-marqueurs.svg`, `vzv-varicelle-zona.svg`). Les figures 4 et 5 de l'annale
2020/2021 S1 (Q.11 et Q.12) **sont** la question : elles s'affichent avant l'énoncé
(`illustration_question`), et la figure 4 ne vend rien — c'est au lecteur de reconnaître le
cycle de la fièvre jaune.

## Le sujet 2025/2026 (18/10/2026)

Le sujet de virologie de l'examen du 08/01/2026 (cahier de 30 QCM,
`src-sujet-viro-2526`, sans corrigé), déposé le 18/10/2026, apporte 7
questions à ce chapitre (Q.23, Q.24, Q.25, Q.26, Q.27, Q.28, Q.29) ; les
autres questions vont aux chapitres de leur cours. Aucune n'était déjà en
cartes. Chaque clé est déduite du cours 2025-26, l'année de l'examen,
proposition par proposition et page à l'appui (`officielle=False`) ; les
propositions déjà posées d'autres années ont servi de contre-épreuve, et
l'explication dit chaque reprise. Rédigées et contre-vérifiées le 18/10/2026 :
un rédacteur, un sceptique qui a refait chaque clé sur le cours, un critique
de complétude. Le profil des clés — A souvent vraie, trois ou quatre vraies
par question — est celui des sessions 1 officielles du Pr Hober (2021/2022 S1,
2023/2024 S1).

| Question | Clé imprimée | Retenue | Lecture |
|---|---|---|---|
| 2025/2026 Q.23 (`vac-an-2526-q23`) | aucune (sujet sans corrigé) | **ABCD** | Trois vaccins inactivés : la rage (même après exposition), la grippe injectable (types A et B), l'hépatite A (pour les métiers exposés aux selles) ; la grippe a aussi un vivant atténué nasal, et le VHA ne donne jamais d'hépatite chronique. |
| 2025/2026 Q.24 (`vac-an-2526-q24`) | aucune (sujet sans corrigé) | **ADE** | Trois vaccins à antigène viral recombinant : l'Ag HBs (qui protège aussi du VHD), la protéine F du VRS (la femme enceinte au 8e mois), la gE du zona (le sujet âgé) ; chez la femme enceinte Ag HBs+, c'est le nouveau-né qu'on sérovaccine. |
| 2025/2026 Q.25 (`vac-an-2526-q25`) | aucune (sujet sans corrigé) | **ABDE** | Le vaccin anti-HPV : des pseudo-particules de L1, des IgG qui gagnent la muqueuse génitale, une valence par type — HPV 6 et 11 des condylomes, 16 et 18 du cancer ; E6 et E7 inhibent p53 et pRb. |
| 2025/2026 Q.26 (`vac-an-2526-q26`) | aucune (sujet sans corrigé) | **ACE** | Polio : le VPI inactivé, seul employé en France depuis 1982, le VPO vivant ailleurs, PV2 et PV3 éradiqués ; inactivé pour l'encéphalite à tiques, vivant atténué pour la varicelle. |
| 2025/2026 Q.27 (`vac-an-2526-q27`) | aucune (sujet sans corrigé) | **ABD** | La dengue est un Flaviviridae à quatre sérotypes, qu'on combat par la démoustication et par des vaccins à virus recombinant, chimères vivantes atténuées. |
| 2025/2026 Q.28 (`vac-an-2526-q28`) | aucune (sujet sans corrigé) | **ABC** | Un vaccin à réplicon, au sens du cours, est un vecteur viral non réplicatif : génome modifié, entrée dans la cellule et traduction, mais pas de nouvelles particules ; l'adénovirus qui porte le gène de la protéine S d'enveloppe du SARS-CoV-2 en est l'exemple, et il n'existe pas de vaccin contre le VHC. |
| 2025/2026 Q.29 (`vac-an-2526-q29`) | aucune (sujet sans corrigé) | **ABD** | Le vaccin à ARN : un ARNm qui fait exprimer une protéine ou un fragment, en nanoparticules lipidiques, injecté par voie intramusculaire ; contre le SARS-CoV-2, la protéine S d'enveloppe ou son RBD ; aucun vaccin anti-VIH. |

Ce qui est signalé :

- Q.24 C, « au femmes » et « 6ième », gardés tels qu'imprimés.
- Q.25 C : la protection contre les HPV 6 et 11 (condylomes) n'est pas écrite en
  une phrase dans le cours ; elle tient sur « une pseudo-particule pour chaque
  type de HPV » (p. 2), sur la Correction des annales 2024-25 qu'imprime le
  même ronéo (p. 16-17 : 2024/2025 Q.25 C vraie), sur la table de 2020/2021 S2
  Q.12 E et sur le Gardasil 9 (HAS).
- Q.28 : « virus réplicons » au sens du cours, des vecteurs viraux non
  réplicatifs (l'adénovirus anti-SARS-CoV-2, p. 12-13). Q.28 E et Q.29 E sont
  fausses par l'absence même d'un vaccin anti-VHC ou anti-VIH (p. 15-16).
- Q.29 E : le ronéo dit le canarypox « utilisé pour vacciner contre le VIH » (p.
  11), puis met ce vaccin en recherche (p. 15) ; sans effet sur la clé,
  puisque c'est un virus recombinant et non un ARN.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2021/2022 S2 Q.29 | CDE | **CE** | D, un vaccin humain contre le virus West Nile : aucun n'est autorisé (CDC, OMS ; vaccins vétérinaires seulement) ; 2020/2021 S2 Q.11 D le cote faux. Conflit déclaré. |
| 2017/2018 S2 Q.25 | ABCD | **ABC** | D, idem. Conflit déclaré. |
| 2024/2025 Q.28 | ABDE | **ABE** | D, « éruption généralisée » d'un sujet « réinfecté » : le zona est une réactivation localisée (partie 1, p. 10 ; FC n°7, p. 8). Conflit déclaré. |
| 2024/2025 Q.29 | BCD | **ABCD** | A, dengue « dans toute la zone intertropicale » : la phrase du cours (partie 1, p. 9 ; FC n°7, p. 15) ; la remarque du ronéo confond avec l'absence de réservoir simien. Conflit déclaré. |
| 2024/2025 Q.25, 26, 27, 30 | — | clé du ronéo | clés de la « Correction » du ronéo (partie 1, p. 17), pas d'une table officielle : `officielle=False` |
| 2024/2025 Q.23 (`vac-an-2425-q23`) | aucune (sujet sans corrigé, aucun ronéo) | **C** | clé déduite du cours : la rage, « jamais de virémie », vaccin toujours inactivé (partie 2, p. 2-3) ; hépatite A inactivé dès 1 an (p. 7) ; vaccin grippal inactivé, non contre-indiqué pendant la grossesse (FC n°9, p. 13), 2 A et 1 ou 2 B (p. 5-6). `officielle=False` |
| 2024/2025 Q.24 (`vac-an-2425-q24`) | aucune (sujet sans corrigé, aucun ronéo) | **ADE** | clé déduite du cours : Ag HBs recombinant, obligatoire depuis 2018, protège du VHD ; vaccin VRS à protéine F dès 60 ans et au 8e mois de grossesse (partie 2, p. 7-9). `officielle=False` |
| 2020/2021 S2 Q.13 | absente | **ABDE** | clé déduite du cours (partie 2, p. 8-9) ; la table saute de 12 à 14 |
| 2015/2016 S1 Q.25, 26, 27, 28, 30 | absentes | **ACE, ABCE, CE, ABC, ABCDE** | la table n'a pas de colonne 2015/2016 S1 ; clés déduites, chacune miroir d'une question de 2015/2016 S2 ou de 2016/2017 S2 |

Seize cartes d'annales ne sont donc pas officielles.

**Les autres anomalies**, signalées dans la carte :

- le premier bloc du polycopié (Q.21-28) est imprimé « Année 2022/2023, session 2 » : ses clés
  sont la colonne 2023/2024 S1, retenue ;
- 2020/2021 S1 Q.12 E, « les HPV génitaux du virus de la dengue » : énoncé altéré, gardé tel
  quel, clé (vrai) reprise ;
- 2023/2024 S1 Q.23 E (vaccin grippal 2 A + 2 B) : vrai à la date de l'examen et selon le cours,
  mais les vaccins français sont redevenus trivalents en 2025-26 (OMS, HAS) — ATTENTION nu ;
- 2019/2020 S2 : sept clés sans énoncé, pas de carte ;
- 2019/2020 S1 Q36 et Q37 : énoncés imprimés seulement dans les captures corrigées (p. 31) ;
- la Q30 de 2024/2025 est imprimée sans numéro ni phrase d'introduction dans la FC n°5 (p. 12) ;
  la phrase est celle des questions 25 à 29, comme le confirme le sujet ;
- **les énoncés 2024/2025 du ronéo, alignés sur le sujet du 09/01/2025** (15/10/2026) : la Q29
  du ronéo (partie 1, p. 17) imprime en D et E les D et E de la Q30 ; la carte porte les vraies
  (D, les moustiques Aedes, vrai ; E, des vaccins « à base de protéines recombinantes », faux),
  auxquelles répond la Correction (« E → attention piège : vaccin à VIRUS recombinant ») ; la
  clé retenue ne change pas (ABCD). Q26 E suit le sujet, « il n'y plus que » (le ronéo ajoutait
  « a »), et Q30 D « adénovirus » (la FC n°5 imprimait « adéno virus ») ; Q25, Q27 et Q28 étaient
  conformes ;
- coquilles gardées telles qu'imprimées (« voir orale », « uneannée », « au nouveau de la
  muqueuse », « lésionsprovoquées », « de de vaccins », « vis-à-vis du quel », « de de
  l'encéphalite » ; dans le sujet 2024/2025, « il n'y plus que » (Q.26 E), « 8ième »
  (Q.24 E)).

## Les erreurs du Ronéosaure 2025-26

Dites par un ATTENTION nu (convention C14), pas dans `ERRATA_RONEOS_2026-27.md`, réservé aux
ronéos 2026-27. L'errata de la promo ne relève, pour ce cours, que l'introduction manquante
(→ `viro_vaccins_vivants`).

| Page | Le ronéo écrit | Juste, et la source | Carte |
|---|---|---|---|
| a p. 3 | l'HPV infecte « des cellules vivantes de l'endothélium » | de l'épithélium, sa couche basale (déjà faux en 2024-25) | `vac-qc-hpv-cycle` A |
| a p. 4 | « activité ARN polymérase = protéase » | protéases 2A et 3C, polymérase 3D (la figure de la même page) | `vac-qc-enterovirus` E |
| a p. 12 | Dengvaxia, « 3 doses intramusculaires » | sous-cutanées (RCP, EMA) | `vac-qc-dengue` D |
| a p. 15-16 | vaccin Ebola à vecteur « VZV, proche parent du virus de la rage » | VSV, virus de la stomatite vésiculeuse, Rhabdoviridae (Ervebo ; déjà faux en 2024-25) | `vac-qc-recombinants` |
| b p. 3 | incubation de la rage « allant de 3 mois à 18 mois et plus » | « 3 mois (jusqu'à 18 mois et plus) » au cours 2024-25 ; 2-3 mois en général, d'une semaine à plus d'un an (OMS) | `vac-qc-rage-prophylaxie` E |
| b p. 9 | protéine F « en conformation perfusion », adjuvée pour tous | préfusion ; le vaccin de la femme enceinte (Abrysvo), aussi donné aux sujets âgés, est sans adjuvant (cours 2024-25) ; seul Arexvy, pour les sujets âgés, est adjuvé (EMA) | `vac-qc-vrs` A |
| b p. 4 | grippe B : « réservoir les phoques » | point douteux : virus humain, isolé chez le phoque (Osterhaus, 2000) | `vac-rv-grippe-a-b` |
| a p. 9 | encéphalite japonaise « uniquement en Asie du Sud-Est » | point douteux : aussi l'Inde (FC n°7, p. 15 ; OMS, 24 pays) | `vac-qc-japonaise` |

Le Dengvaxia, dont le ronéo annonce l'arrêt en « août 2026 » : vérifié (Sanofi, derniers lots
périmés en août 2026), dit dans `vac-qc-dengue`.

Ce qui a changé depuis le cours, sans que le cours se trompe à sa date, dit par un ATTENTION nu
qui garde la réponse du cours pour l'examen : depuis la campagne 2025-26, les vaccins grippaux
français sont trivalents (B/Yamagata retirée : OMS, EMA, HAS) et un vaccin inactivé adjuvé
(Fluad, MF59) est recommandé de préférence aux 65 ans et plus — le plus répandu reste sans
adjuvant (`vac-fa-grippe-vaccin`, `vac-qc-grippe-vaccins` A, 2023/2024 S1 Q.23 E).

## Questions pour Vincent

1. **Le vaccin West Nile** (2021/2022 S2 Q.29 D, 2017/2018 S2 Q.25 D) : le professeur l'a coté
   vrai deux fois, faux une fois (2020/2021 S2 Q.11 D, sous une autre forme). La notion est hors
   du cours 2025-26. La proposition du plan est appliquée — les trois questions restent ici, la
   justification dit « hors du cours 2025-26 » et cite le CDC et l'OMS, et la clé retenue est
   « faux », parce qu'aucun vaccin humain n'existe — et la carte dit le point douteux. Faut-il
   plutôt répondre comme le professeur à l'examen ?
2. **Les clés 2024/2025** viennent de la « Correction » du ronéo 2025-26. Si elle reprend la
   clé officielle, Q.28 D (zona) et Q.29 A (dengue) sont des clés du professeur que les cartes
   contredisent : faut-il les garder contre lui ?
3. **La planche des types** réunit deux paires de légendes sous un seul numéro (voir plus
   haut) : convient-il, ou préfères-tu huit numéros ?
4. **Les cartes « un exemple de chaque type »** sont ici (la conclusion de la FC n°10) ; le plan
   met aussi les types de vaccins dans l'introduction de `viro_vaccins_vivants` : à garder des
   deux côtés, ou ici seulement ?

## Le lexique

Huit termes, accueillis ici parce que la FC n°10 les emploie et que les annales les
demandent : Adjuvant, Pseudoparticule virale (écrit d'un seul mot, comme dans les annales, pour
y être compté ; le cours écrit « pseudo-particule »), Transsudation, Réplicon, Virus chimère,
Recombinant, Sous-unitaire, Prophylaxie. Pages mesurées dans le texte des deux FC.
« Virus chimère » a son propre identifiant (`lex-virus-chimere`) : `lex-chimere` est déjà le
terme de génétique (deux zygotes) de `genet_chromosomes`.

Les étymologies sont proposées dans `scratchpad/etym/viro_vaccins.json`, sur la structure
d'`etymologies.json` (TLFi par l'API du portail cnrtl.fr, Littré, Gaffiot, Bailly,
Wiktionnaire). Les racines déjà dans la table gardent leur clé : `ad- (latin)`,
`trans- (latin)`, `re- (latin)`, `plicare (latin)`, `chimaera (latin)`, `pro- (grec)`,
`-phylaxie` ; huit racines sont nouvelles (`juvare`, `pseud(o)-`, `particula`, `virus`,
`sudare`, `combinare`, `subtus`, `unitas`). `virus (latin)` est aussi proposée par
`viro_structure`, `viro_multiplication`, `viro_virus_hote` et `viro_pathogenes_2` : même clé,
même sens (« suc, jus ; venin, poison »), une seule entrée à verser dans la table.

## À relire

Aucune carte `a-relire` : chaque carte de cours cite sa page, chaque annale sa clé (imprimée,
de la Correction du ronéo ou déduite, et dite).

## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier. Sous les annales, 99 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 22 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `vaccins-types` | 1 | 1 | 2 |
| `vaccins-inactives` | 14 | 3 | 6 |
| `hepatites` | 15 | 4 | 13 |
| `hpv` | 11 | 4 | 11 |
| `polio` | 12 | 2 | 9 |
| `arbovirus` | 17 | 4 | 17 |
| `varicelle-zona` | 14 | 2 | 8 |
| `vaccins-nouveaux` | 15 | 2 | 7 |

**Les schémas** sont au nombre de 2 : `ech-vaccins-virus`, « Des vaccins, virus par virus · ce qu'ils contiennent, qui ils protègent » (41 Simple, 12 Moyen, 32 annales ; 86 fichiers), et `ech2-vaccins-viraux`, « Vaccins viraux · poliovirus, arbovirus, VZV, nouvelles techniques » (58 Simple, 10 Moyen, 41 annales ; 110 fichiers). Une carte ou une annale va au schéma de son mécanisme. Ils sont décrits dans `schemas.py` (`ECH_VACCINS_VIRUS`, `ECH2_VACCINS_VIRAUX`, avec leurs `TROUS_*` et `LETTRES_*`, un `FICHIERS.update` chacun) et dessinés par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- vac-an-2324s1-q25 A — « des HPV provoquent des lésions de la cavité buccale » : un fait d'une seule annale (HPV 13 et 32, hyperplasies focales, partie 1, p. 2), que la phrase du cours range parmi les HPV « à forte malignité » avec les 16 et 18 ; écrit sur le schéma, il aurait aussi servi de réponse visible aux distracteurs des cartes 6-11 et 16-18 (et la colonne HPV est pleine). Pas de ligne ni de carte ; la lettre se pose sur la case des HPV, et le fait sert de distracteur expliqué en s3 et s4.
- vac-an-2021s1-q12 E — énoncé altéré (« HPV génitaux du virus de la dengue ») et ATTENTION existant : la proposition porte sur la figure 5 entière, sans fait à isoler ; lettre posée sur la case du vaccin, qui redessine ce principe.
- 2022/2023 S2 Q.30 A, 2022/2023 S1 Q.30 A, 2021/2022 S2 Q.30 A, 2021/2022 S1 Q.30 A (les grandes épidémies dues aux virus à ARN) : aucune phrase de la FC n°10 ne le dit, la justification de l'annale le tire de plusieurs cours ; lettres non posées, faute de case.
- 2022/2023 S2 Q.30 C, 2022/2023 S1 Q.30 C (les rotavirus, 11 segments d'ARN double brin, Reoviridae) : FC n°11, chapitre viro_vaccins_vivants, hors des sources de ce chapitre ; lettres non posées, faute de case.
- 2021/2022 S2 Q.30 C, 2021/2022 S1 Q.30 C (le diagnostic de l'hépatite A par les IgM anti-VHA) : FC n°10 partie 2, p. 7, notion du thème vaccins-inactives ; lettres non posées, faute de case sur ce schéma.
- 2021/2022 S2 Q.29 D, 2017/2018 S2 Q.25 D, 2020/2021 S2 Q.11 D (un vaccin humain contre le virus West Nile) : hors du cours 2025-26, en CONFLITS ; aucune phrase du cours sur laquelle bâtir une marche. Lettre posée, sans marche, sur la case de l'encéphalite japonaise, où se joue la proposition (genre Flavivirus, moustiques Culex, vaccin inactivé).
- 2024/2025 Q.29 B (la dengue, virus à ARN enveloppé) : seulement dans la FC n°7 2025-26, hors des sources du chapitre ; la lettre est posée sur la case de la dengue.
- 2024/2025 Q.30 A (le SARS-CoV-2, un Coronaviridae) : la FC n°10 ne nomme pas sa famille ; la lettre est posée sur la case du SARS-CoV-2.
- 2020/2021 S1 Q.8 D (les adénovirus, virus nus) : FC n°1, hors des sources du chapitre ; la lettre est posée sur la case du réplicon.
- En partie seulement : 2021/2022 S1 Q.29 D (le virus de l'encéphalite à tiques, un Flaviviridae) — la famille n'est que dans la FC n°7, s17 prépare l'existence du vaccin ; 2023/2024 S1 Q.28 A et 2024/2025 Q.28 A (« enveloppé ») — la FC n°10 dit l'ADN double brin, pas l'enveloppe, s28 et s29 préparent le reste ; 2015/2016 S1 et S2 Q.30 B (le VPI « par voie intramusculaire ») — le cours dit « injectable » sans préciser la voie (p. 5) : le titre de la case et l'énoncé de s1 portent « injectable ».

## Régénérer

```powershell
cd contenu\chapitres\viro_vaccins
..\..\..\app\.venv\Scripts\python.exe generer.py
```

La planche numérotée se refait depuis ce dossier, si les rectangles changent :
`python ..\..\..\.claude\skills\nouveau-chapitre\scripts\planche_depuis_image.py . vac-pl-types --apercus <brouillon>`
(Pillow requis).
