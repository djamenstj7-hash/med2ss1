# Métabolisme énergétique — paquet BMCP

77 notes, 155 cartes. Chapitre `chap-ue-bmcp-fc5` de l'UE BMCP, ordre 6. **Cours
du Dr V. Huin, le 30/09/2026, de 8 h à 9 h (semaine n°4), dans la ronéo Ronéo &
Juliette 2026-27 « Métabolisme énergétique »** (12 pages, la dernière vide).
Réaligné sur elle le 11/10/2026 ; il était carté depuis le 03/10 (tâche C16) sur
la FC n°6 du Ronéosaure 2025-26 (Dr Huin, 03/10/2025), qui n'est plus qu'un
appoint. Une annale du Ronéosaure 2024-25 (BMCP 5, 2020/2021 S1), et deux du sujet de
2024/2025, sans corrigé (Q. 17, Q. 18). Examen : mardi
5 janvier 2027.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 30 | 30 |
| QRU | 1 | 1 |
| Texte à trous | 14 | 88 |
| QROC | 14 | 14 |
| Recto-verso | 5 | 5 |
| Schéma cliquable | 1 | 5 |
| Planche à légender | 1 | 1 |
| Lexique | 11 | 11 |

Dont **trois annales** sur deux sessions, toutes à clé déduite : 2020/2021 S1 Q. 2 (polycopié
BMCP 5) et les Q. 17 et Q. 18 du sujet de 2024/2025 (examen du 09/01/2025, sans corrigé,
déposé le 15/10/2026) ; les cinq autres questions du polycopié BMCP 5 sont dans
`bmcp_metabolisme` (voir plus bas). **30 QCM sur 31 illustrés (97 %)**, 60 notes sur 77. **4 cartes absentes du cours 2026-27** (tag
`absent-2026`), **18 cartes portent un piège de la ronéo** (thème « Pièges des
ronéos »).

Huit thèmes, dans l'ordre du cours, tous déjà dans `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`, intégration du 05/10) ; le
réalignement n'en ajoute aucun :

| Clé | Libellé | Notes |
|---|---|---|
| `depense-energetique` | Dépense énergétique et ATP | 8 |
| `substrats` | Substrats énergétiques et réserves | 11 |
| `malnutrition` | Malnutrition protéino-énergétique | 4 |
| `carrefours-metaboliques` | Pyruvate, acétyl-CoA, lactate et corps cétoniques | 15 |
| `glucose` | Métabolisme du glucose | 10 |
| `lipides` | Métabolisme des lipides | 6 |
| `proteines` | Métabolisme des protéines | 4 |
| `gestion-energie` | Effort et gestion de l'énergie | 8 |

(plus les 11 termes du lexique, sans thème de cours).

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-bmcp-ene-2627` — « Métabolisme énergétique » (12 p.), `BMCP/MÉTABOLISME ÉNERGÉTIQUE.pdf` | **2026-27** | **la base** : `SRC["fiche"]`, ce que le lecteur ouvre ; 69 notes la citent à leur page ; une figure propre (les carrefours, p. 5) |
| `src-fc-bmcp-ene-2526` — Ronéosaure, « FC n°6 - Métabolisme énergetique » (15 p.) | 2025-26 | **appoint** (`SRC["cours"]`, sans `chapitre=`) : ce que la ronéo 2026-27 ne reprend pas, **les figures** (`SRC["medias"]`), et la source des **4 cartes absentes** |
| `src-annales-bmcp-5-metabolisme-energetique` — « BMCP 5 - Métabolisme énergétique » (3 p.) | 2024-25 | la question 2020/2021 S1 Q. 2 ; table p. 3 |
| `src-sujets-bmcp-2425` — « Sujets de BMCP 2024/2025, session 1 » (30 p.) | 2024-25 | le sujet de l'examen du 09/01/2025, **sans corrigé** (dépôt `Annales_15102026/`, 15/10/2026) : Q. 17 et Q. 18 ; `SRC["sessions"]["2024/2025 S1"]` ; déclaré à l'identique dans tous les chapitres de BMCP qui en cartent une question |
| tableau d'erreurs BMCP de la promo 2026-27 | 2026-27 | **aucun** dans les ronéos déposées au 11/10/2026 |

Les textes citent « p. 5 » (ronéo 2026-27) ou « FC 2025-26, p. 9 ». Lus en appoint,
sans être déclarés : les cours 2023-24 (Charonéo) et 2024-25 (Ronéosaure) du même
enseignant, pour trier les erreurs ; la ronéo 2026-27 « La cellule, un carrefour du
métabolisme » du Pr Pigny (32 ATP, p. 7). La fiche de l'année se copie dans le
dossier des PDF de l'application par `outils/copier_les_cours.py`, lancé avec le
dossier des ronéos 2026-27 (`Ajouts/[NUMERIQUE] Ronéo & Juliette 26-27 11 10 2026/S1/CM`),
hors du bac à sable.

Les en-têtes des ronéos, des erratas et des polycopiés portent des noms
d'étudiants : aucun n'est repris.

**Le titre du professeur.** L'en-tête dit « Professeur : Dr. V. HUIN » ;
`CHAPITRE.semaine` écrit « 30/09/2026 · Dr Huin », comme les autres chapitres
dont l'en-tête dit « Dr ».

## Ce qui correspond à quoi

La ronéo 2026-27 suit tout le plan de la FC 2025-26, en plus court (11 pages de
texte contre 15) :

| FC 2025-26 | Ronéo 2026-27 |
|---|---|
| I. La dépense énergétique (p. 2-3) | p. 2-3 |
| II.A-C Sources, apports, réserves (p. 4-5) | p. 3-4 |
| II.C Malnutrition (p. 5) | p. 4 |
| II.D Destinée des nutriments, carrefours, dosage du lactate, corps cétoniques (p. 5-9) | p. 4-6 |
| II.E-F Destinées anabolique et d'élimination (p. 9-10) | p. 6-7 |
| III. Les glucides (p. 10-12) | p. 7-9 |
| IV. Les lipides (p. 12-13) | p. 9-10 |
| V. Les protides (p. 13-14) | p. 10 |
| VI. Gestion du métabolisme, effort (p. 14-15) | p. 10-11 |

Elle couvre donc tout le cours : **rien n'est en attente d'une ronéo suivante**.

## Le réalignement du 11/10/2026

**Relues et confirmées sur la ronéo 2026-27** — chaque carte cite sa page de
l'année (et perd le badge « Cours 2025-26 ») ; une proposition ou un trou que seul
le cours 2025-26 porte le dit dans sa justification (« FC 2025-26, p. 6 ; la ronéo
2026-27 n'en parle pas ») :

| Page | Notes |
|---|---|
| 2 | `ene-fa-atp`, `ene-fa-depense`, `ene-qc-depense`, `ene-qr-atp`, `ene-qr-thermogenese` |
| 3 | `ene-fa-autres-postes`, `ene-fa-apports`, `ene-qc-grand-brule`, `ene-qc-apports` |
| 4 | `ene-fa-reserves`, `ene-fa-marasme`, `ene-qc-reserves`, `ene-qc-proteines-reserve`, `ene-qc-malnutrition`, `ene-qr-ascite`, `ene-rv-glycogene`, `ene-rv-marasme-kwashiorkor` |
| 5 | `ene-fa-destinees`, `ene-qc-retenir`, `ene-qc-gradient`, `ene-qc-carrefours`, `ene-qc-lactate`, `ene-qc-dosage`, `ene-qc-cetoniques`, `ene-qr-ucp1`, `ene-qr-interconversion`, `ene-rv-pyruvate-lactate`, `ene-zo-mitochondrie`, `ene-pl-carrefours` |
| 6 | `ene-fa-anabolique`, `ene-qc-acidocetose`, `ene-qc-anabolique`, `ene-qr-cytopathies` |
| 7 | `ene-qc-dechets`, `ene-qc-glycolyses`, `ene-qr-glucides-kcal` |
| 8 | `ene-fa-repas`, `ene-fa-chiffres`, `ene-qc-rendements`, `ene-qc-periode-alimentaire`, `ene-qr-glycogenogenese`, `ene-qr-hydrophobe` |
| 9 | `ene-qc-jeune-glucides`, `ene-qc-lipides`, `ene-qc-lipides-regulation`, `ene-qr-lipides-kcal` |
| 10 | `ene-qc-protides`, `ene-rv-glycolyses` |
| 11 | `ene-fa-effort`, `ene-qc-effort`, `ene-qc-sprint` |

**Ce que la ronéo 2026-27 dit autrement, et ce qui a été réécrit** :

- **85 % des « échanges énergétiques »** (p. 2), et non plus « des dépenses en
  énergie » (FC 2025-26, p. 2) : le point douteux de 2025-26 est levé ;
  `ene-fa-atp` gagne un trou sur ce chiffre (c8).
- **Le glycogène du foie, environ 100 g** (p. 4 ; 100 à 200 g en 2025-26) :
  `ene-fa-reserves` (c6), `ene-rv-glycogene`. Le total, « 500 g à 700 g », n'a pas
  de trou. `ene-fa-reserves` c4 demande désormais le « dernier recours » des
  protéines, au lieu de la graisse « blanche », que la ronéo ne nomme plus.
- **Le rendement des nutritionnistes du glucose : « pas retenir le chiffre mais que
  le rendement est assez bon »** (p. 8, en rouge) : le trou c1 de `ene-fa-chiffres`
  demande « assez bon », non plus 53 ; la proposition D de `ene-qc-rendements` dit
  « assez bon ». `ene-fa-chiffres` gagne le rendement de 5 % de la glycolyse
  anaérobie (c6, p. 10).
- **Les trois rendements** sont redéfinis (p. 7-8) : le théorique maximal, 4 kcal
  par gramme, hors in vivo ; le moléculaire des biochimistes, 38 ATP par mole ; celui
  des nutritionnistes. Les propositions A, B et E de `ene-qc-rendements` sont
  réécrites sur eux (la clé reste ABD).
- **L'effort** (p. 11) : le 800 m à parts équivalentes aérobie et anaérobie, le
  marathon à 99 % aérobie avec le glycogène, les triglycérides et les acides gras
  circulants, la marche (5 km/h, plus de 3 h) à 80 % d'acides gras. `ene-fa-effort`
  est réécrit (c3, c6, c7) et `effort.svg` redessiné.
- **Les apports** (p. 3) : mono-, di- et polysaccharides, l'amidon « principale
  source alimentaire » ; `ene-fa-apports` c4 (polysaccharide) et
  `ene-qc-apports` D remplacent les 25 % de l'amidon (FC 2025-26).
- **La destinée anabolique** (p. 6) : les glycoconjugués des groupes sanguins, les
  prostaglandines, les membranes ; `ene-fa-anabolique` est réécrit sur ces mots.
- **La réaction immunitaire** remplace « l'inflammation chronique »
  (`ene-fa-autres-postes` c4) ; **l'exemple du repas** compte 90 g de glucose
  (`ene-fa-repas`).
- **La diapositive des carrefours** (p. 5) gagne le lactate et les corps
  cétoniques : extraite (`ene-carrefours-2627.png`), elle illustre désormais
  `ene-qc-carrefours`, `ene-qc-periode-alimentaire`, `ene-qr-interconversion` et
  `ene-fa-repas`. La planche reste la version 2025-26, plus nette ; ses deux intrus
  « Lactate » et « Corps cétoniques », que la version 2026-27 porte, sont retirés
  (« Créatine phosphate » s'ajoute).
- **Les justifications** citent les pages 2026-27 ; les erreurs du Ronéosaure
  2025-26 que la ronéo 2026-27 ne redit pas (le marathon « anaérobie », « la
  moitié du sucre », les 2600 kcal) ne sont plus dites qu'en passant, sans
  ATTENTION.

**Notes nouvelles (11)**, sur ce que le cours 2026-27 apporte ou dit en rouge :

| Note | Ce qu'elle carte |
|---|---|
| `ene-qc-atp` | on ne crée pas d'énergie, l'ATP de tous les vivants, 85 % des échanges, 150 kg/j, les formes d'énergie libérées (p. 2) |
| `ene-qc-glucose-substrat` | le glucose substrat préféré, SNC et globules rouges, destinée surtout énergétique, glycolyse, le cerveau qui ne stocke pas (p. 6-8) |
| `ene-fa-jeune` | glycogénolyse, néoglucogenèse (acides aminés, oxaloacétate), cétogenèse : le foie au jeûne (p. 9, p. 6) |
| `ene-qc-lipides-destinee` | le muscle et les acides gras, la réserve, la faible destinée anabolique, des déchets faciles, des centaines de kilos (p. 9) |
| `ene-fa-lipides-regulation` | insuline et lipogenèse, glucagon et lipolyse, acides gras aux muscles, corps cétoniques au cerveau (p. 9-10) |
| `ene-qr-ammoniac` | l'azote accumulé donne l'ammoniac, le cycle de l'urée en fait l'urée (p. 7) |
| `ene-qr-protides-kcal` | 15 % des apports, environ 400 kcal ; un repas de viande ou de poisson par jour (p. 10) |
| `ene-qc-substrats-effort` | 800 m, marathon 99 % aérobie, triglycérides, marche à 80 % d'acides gras, sprint (p. 11) |
| `lex-macronutriment`, `lex-hypoperfusion`, `lex-cetogenese` | trois termes du lexique (voir plus bas) |

## Absent du cours 2026-27

Quatre cartes **entières** que la ronéo du 30/09/2026, qui couvre tout le plan, ne
porte plus. Elles restent, citent la FC n°6 2025-26 (sans `page`, donc avec le
badge « Cours 2025-26 »), prennent le tag `absent-2026` et la phrase « Absent du
cours 2026-27 » en tête de l'explication (`ABSENTS_2026`, `ORIGINE_ABSENTS`) :

| Carte | Ce que le cours 2026-27 ne dit plus |
|---|---|
| `ene-fa-cetolyse` | la cétolyse détaillée : β-hydroxybutyrate, acétone, acétoacétate, retour à l'acétyl-CoA (FC 2025-26, p. 9 ; la ronéo garde le foie qui fabrique et le cerveau qui consomme, p. 5-6) |
| `ene-qr-7h` | la moitié du glycogène hépatique consommée en 7 h de jeûne (FC 2025-26, p. 12) |
| `ene-qr-marche` | la marche, « meilleur sport d'un point de vue énergétique » (FC 2025-26, p. 15 ; la ronéo garde ses substrats, p. 11) |
| `ene-rv-sprinteur` | le sprinteur « baraqué », le marathonien « sec » (FC 2025-26, p. 14) |

## En attente des ronéos suivantes

**Rien.** La ronéo 2026-27 est complète (plan I à VI, de la dépense à l'effort) ; il
n'y a pas de partie « 1 » ni de suite annoncée. Les notions du chapitre que la
ronéo traite ailleurs (le cycle de Krebs, la néoglucogenèse, la cétogenèse en
détail, la lipolyse, l'insulinorésistance) sont cartées dans leurs chapitres,
réalignés ou à réaligner sur leurs propres ronéos.

## Ce que le cours a dicté

- **Le rouge** de la ronéo 2026-27 a chacun sa carte : 50 % des apports en glucides
  (`ene-fa-apports`, `ene-qr-glucides-kcal`) ; les glycolyses anaérobie et
  aérobie, 2 et 38 ATP (`ene-qc-glycolyses`, `ene-rv-glycolyses`,
  `ene-fa-chiffres`) ; le rendement des nutritionnistes « assez bon »
  (`ene-fa-chiffres`, `ene-qc-rendements`) ; l'insuline et la glycogénogenèse
  (`ene-qc-periode-alimentaire`, `ene-qr-glycogenogenese`) ; glycogénolyse et
  cétogenèse (`ene-fa-jeune`) ; 30 à 35 % de lipides, un rendement « élevé »
  (`ene-qr-lipides-kcal`, `ene-qc-lipides`) ; lipogenèse et lipolyse
  (`ene-fa-lipides-regulation`) ; 15 % de protides, un rendement « peu élevé »
  (`ene-qr-protides-kcal`, `ene-qc-protides`).
- **Le gras** (pas de gris dans cette ronéo) porte les définitions de la p. 2, les
  réserves de la p. 4, les deux malnutritions, le lactate « forme réduite », les
  efforts : tout est carté.
- **Ce qui n'est pas carté ici**, parce qu'un autre chapitre le tient : le cycle de
  Krebs, la chaîne respiratoire et ses 32 ATP, le mécanisme de la cétogenèse, la
  néoglucogenèse (`bmcp_metabolisme`) ; lipogenèse, lipolyse, β-oxydation
  (`bmcp_lipides`) ; le syndrome métabolique (`bmcp_insuline`) ; les glucides
  alimentaires (`bmcp_glucides`) ; le cycle de l'urée (`bmcp_proteines`). Les
  cartes les citent.
- **Aucune photographie de patient** : les deux enfants de la p. 4 (marasme,
  kwashiorkor) sont remplacés par `marasme-kwashiorkor.svg`.
- Deux coquilles ne sont pas reprises comme erreurs : « le glucose indexé est stocké
  sous forme de glycogène » (p. 6, sans doute « en excès ») et « la kwashiorkor »
  (p. 4).

## Ce que les annales ont dicté

Le polycopié BMCP 5 (Pr Huin, quatre sessions, six questions) est presque tout
entier dans `bmcp_metabolisme`, et n'est pas recopié : 2023/2024 Q.14
(`met-an-2324-q14`) et Q.15 (`met-an-2324-q15`), 2022/2023 Q.16
(`met-an-2223-q16`), 2020/2021 Q.1 (`met-an-2021s1-q8`, la même que BMCP 6
Q.8), 2019/2020 Q.1 (`met-an-1920s1-q1`, aussi dans BMCP 1). Ce qu'elles
demandent — principale source (les glucides), principale réserve (les
lipides), destinée énergétique des glucides, anabolique des protides — a ses
cartes de cours ici : `ene-qc-apports`, `ene-qc-reserves` et `ene-qc-protides`
citent 2023/2024 Q.15 et 2022/2023 Q.16 ; `ene-qc-proteines-reserve` renvoie à
l'item A de 2020/2021 Q. 2.

| Polycopié | Session | N° | Clé imprimée | Carte | Retenu |
|---|---|---|---|---|---|
| BMCP 5 | 2020/2021 S1 | Q. 2 | aucune (« pas de corrections officielles ») | `ene-an-2021s1-q2` | BCD, `officielle=False` |
| sujet 2024/2025 | 2024/2025 S1 | Q. 17 | aucune (sujet sans corrigé) | `ene-an-2425s1-q17` | CDE, `officielle=False` |
| sujet 2024/2025 | 2024/2025 S1 | Q. 18 | aucune (sujet sans corrigé) | `ene-an-2425s1-q18` | ABCD, `officielle=False` |

Les deux questions du sujet de 2024/2025 sont cartées ici, au chapitre dont le cours traite
la notion, et non dans `bmcp_metabolisme` où vit la 2023/2024 Q.15 : la Q. 18 en est une
reprise remaniée (ses A et C sont les C et B de 2023/2024, mot pour mot ; sa B, la D de
2022/2023 Q.16 ; ses D et E, neuves), et son explication le dit.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2020/2021 S1 Q. 2 | aucune | **BCD** | A : les triglycérides (12 kg) sont la plus grande réserve, devant les protéines (6 kg), histogramme de la ronéo 2026-27, p. 3 — **ATTENTION (prise de notes) et `CONFLITS`** : le texte de la ronéo 2026-27 écrit « 15 kg de protéines » (p. 4), ce qui rendrait A vrai ; la clé suit l'histogramme du professeur. B : vrai par le seul glycérol, glucoformateur (diapositive des carrefours, ronéo 2026-27 p. 5) ; les acides gras ne redonnent pas de glucose, et le cours de lipides dit « on ne fait jamais de sucre avec du gras » — ATTENTION et `CONFLITS` : la lecture stricte donnerait CD (question 1 ci-dessous). C : l'insulinorésistance est au cœur du syndrome métabolique (FC n°3 2025-26 p. 9 ; Reaven 1988). D : surproduction hépatique de VLDL (FC n°3 p. 6, 10 ; FC n°7 p. 9 ; Adiels, ATVB 2008). E : « l'insuline est la seule hormone hypoglycémiante de l'organisme » (FC n°3 2025-26 p. 2) ; la leptine n'est dans aucun cours de BMCP (Zhang, Nature 1994) |
| 2024/2025 S1 Q. 17 | aucune (sujet sans corrigé) | **CDE** | A fausse, petite réserve de glycogène (p. 4) ; **B fausse**, 12 kg de triglycérides contre 6 kg de protéines (histogramme, p. 3) — **ATTENTION (prise de notes) et `CONFLITS`** : la même erreur des « 15 kg de protéines » (p. 4) ; C, protéines peu mobilisables (p. 4, 10) ; D, 85 % (p. 9) ; E, 30 % (p. 10) |
| 2024/2025 S1 Q. 18 | aucune (sujet sans corrigé) | **ABCD** | A, 50 % des apports (p. 3) ; B, destinée énergétique des glucides (p. 7) ; C, anabolique des protides (p. 10) ; D, le glycogène (p. 4, 7) ; E fausse, le glycogène est mobilisé le premier, au jeûne (p. 9) comme à l'effort (p. 11) — « peu mobilisable » est le mot du cours pour les protéines (p. 4) |

La proposition C est imprimée sans espaces
(« Lesyndromemétaboliques'accompagnerapidement… ») : les espaces sont rétablis,
aucun mot n'est changé, et la justification le dit.

## Les erreurs de la ronéo 2026-27

Aucun tableau d'erreurs BMCP de la promo dans les ronéos déposées au 11/10/2026 :
toutes les erreurs ci-dessous ont été trouvées en relisant, et vont dans
`contenu/ERRATA_RONEOS_2026-27.md`. Chaque erreur est portée par une carte, avec son
genre. À l'examen, on répond d'abord comme le professeur.

**Prises de notes fausses** (`ATTENTION (prise de notes)`) :

| Page | La ronéo dit | Ce qui est juste | Carte |
|---|---|---|---|
| 4 | « 15 kg de protéines » chez l'homme de 70 kg | environ 6 kg : l'histogramme du professeur, p. 3 de la même ronéo ; Ronéosaure 2024-25 et Charonéo 2023-24 (« 6 kg », p. 3) ; Cahill, N Engl J Med 1970 (environ 6 kg de protéines mobilisables) ; Berg, Biochemistry (24 000 kcal de protéines, surtout musculaires) | `ene-fa-reserves`, `ene-qc-proteines-reserve` (E), `ene-an-2021s1-q2` (A), `ene-an-2425s1-q17` (B, ajoutée le 15/10/2026) |
| 5 | « Le pyruvate est le produit final de la glycolyse anaérobie » | le produit final de la glycolyse (aérobie) ; en anaérobie, le pyruvate est réduit en lactate : même ronéo, p. 7 (« production de 2 molécules de lactate + 2 ATP ») ; FC 2025-26, p. 7 ; StatPearls, Biochemistry, Glycolysis | `ene-qc-lactate` (A), `ene-rv-pyruvate-lactate` |
| 5 | « Si le rapport pyruvate / lactate augmente cela signifie que les tissus sont mal oxygénés » | c'est le rapport pyruvate/lactate qui BAISSE (le lactate/pyruvate monte), le lactate augmentant avec la glycolyse anaérobie (même phrase) : FC 2025-26, p. 8 ; Ronéosaure 2024-25, p. 5 ; StatPearls, Lactic Acidosis | `ene-qc-dosage` (C) |
| 6 | « diagnostic différentiel avec les acidocétoses métaboliques » (déjà dans la FC 2025-26, p. 8) | avec les acidoses métaboliques : Charonéo 2023-24 et Ronéosaure 2024-25, p. 5 ; le lactate distingue l'acidose lactique de l'acidocétose | `ene-qc-dosage` |
| 8 | « Rendement moléculaire théorique = rendement des biochimistes — dans tubes à essai : 1 mole de glucose libère 38 ATP » | le tube à essai est celui du rendement théorique MAXIMAL (4 kcal par gramme, hors in vivo) : « le rendement théorique maximum correspond au rendement dans un tube à essai » (Charonéo 2023-24, p. 7) ; « rendement énergétique théorique : observé dans un tube essais » (FC 2025-26, p. 11) ; « calcul mathématique ou chimique » (Ronéosaure 2024-25, p. 7). Le rendement des biochimistes compte les ATP (38 par mole selon le cours) | `ene-qc-rendements` (B) |
| 9 | « 3 tartines beurrées de 10g, 1 plat de viande en sauce de 30g à 50g, 1 pâtisserie industrielle 20g représente environ 50Kcal » | environ 500 kcal sur les 800 kcal de lipides de la journée : Ronéosaure 2024-25, p. 8 ; Charonéo 2023-24, p. 9 (« 70g ou 500Kcal ») ; FC 2025-26, p. 12 (deux tartines, « déjà 500 Kcal ») ; à 9 kcal/g (Atwater, FAO 2003), 10 g de lipides font déjà ~90 kcal | `ene-qr-lipides-kcal` |

**C'est le cours lui-même** (`ATTENTION (cours)` : « À l'examen : … », puis « La
référence : … ») :

| Page | Le cours dit | La référence | Carte |
|---|---|---|---|
| 7, 8, 10 (rouge p. 10) | la glycolyse aérobie, « 38 ATP » par glucose ; « 1 mole de glucose libère 38 ATP » (FC 2025-26, p. 11 et 14 ; cours 2023-24 et 2024-25) | 30 à 32 ATP, avec 2,5 ATP par NADH et 1,5 par FADH2 (Lehninger ; StatPearls) ; 32 dans le cours du Pr Pigny (ronéo 2026-27 « La cellule, un carrefour du métabolisme », p. 7) | `ene-qc-glycolyses` (C), `ene-fa-chiffres`, `ene-rv-glycolyses`, `ene-qc-rendements` |
| 8 | un repas de 90 g de glucose, peu d'exercice ensuite : « 60 % oxydé », « 30 % transformé en graisse », « 10 % en glycogène » (déjà dans la FC 2025-26, p. 11) | après un repas glucidique ordinaire, la lipogenèse de novo est minime chez l'homme (1 à 2 % des acides gras des VLDL : Hellerstein et al., J Clin Invest 1991) ; le glucose non oxydé va d'abord au glycogène, et ne devient de la graisse en quantité qu'une fois le glycogène saturé, par un excès massif et prolongé (Acheson et al., Am J Clin Nutr 1988) ; le sucre en excès fait stocker les graisses qu'il remplace comme combustible (Hellerstein, Eur J Clin Nutr 1999) | `ene-fa-repas` |

**Points douteux** (`ATTENTION (douteux)`), dits dans la carte sans changer sa clé :

| Page | Le point | Carte |
|---|---|---|
| 2 | l'ATP, « la molécule de stockage de l'énergie » (la diapositive, comme en 2023-24 et 2025-26), quand la même ronéo dit « quasiment pas de stock d'ATP » (p. 4) : l'ATP est le donneur immédiat, pas une réserve (Berg, Biochemistry, § 14.1) ; vrai si l'on lit « l'énergie est stockée dans ses liaisons ». À l'examen : la formule du cours, à ne pas contredire ; « principale réserve », jamais (les triglycérides) | `ene-fa-atp`, `ene-qc-atp` |
| 5 | « L'acétyl coA pourra ensuite entrer dans les mitochondries » : c'est la lecture du schéma général du cours, qui pose l'acétyl-CoA à l'étape « la cellule », juste avant « la mitochondrie » (p. 4 ; cours 2024-25 : « transformés dans la cellule », p. 4), alors que le cours 2023-24 faisait faire l'acétyl-CoA par la mitochondrie (p. 4). En fait, il est fabriqué dans la matrice (pyruvate déshydrogénase, β-oxydation), ne traverse pas la membrane interne et n'en sort que sous forme de citrate (Lehninger ; Berg, Biochemistry). À l'examen : l'acétyl-CoA alimente le cycle de Krebs, dans la mitochondrie | `ene-qc-retenir` (E) |
| 6 | les corps cétoniques « peuvent servir de marqueur du diabète » : ils signent une carence en insuline (l'acidocétose qui révèle ou complique un diabète), pas le diagnostic du diabète, posé sur la glycémie ou l'HbA1c (ADA, Standards of Care, section 2) ; une cétose s'observe aussi au jeûne | `ene-qc-acidocetose` |
| 8 | le cerveau, « incapable de stocker » le glucose : les astrocytes gardent un peu de glycogène, une réserve minime, vite épuisée en hypoglycémie ou en ischémie (Brown et Ransom, Glia 2007 ; Obel et al., Front Neuroenergetics 2012). À l'examen : le cerveau ne stocke pas, comme le dit le cours | `ene-qc-glucose-substrat` (E) |

## Les erreurs du Ronéosaure 2025-26

Le Ronéosaure n'est pas le ronéo de l'année : ses erreurs n'entrent pas dans
`contenu/ERRATA_RONEOS_2026-27.md`. Celles que la ronéo 2026-27 redit ont pris le
genre de l'année (38 ATP, « acidocétoses métaboliques »). Restent :

| Page | Le Ronéosaure dit | En 2026-27 | Carte |
|---|---|---|---|
| 2 | « l'ATP représente 85 % des dépenses en énergie » | « 85 % des échanges énergétiques » : levé | `ene-fa-atp` (dit en passant) |
| 3 | l'activité physique « de l'ordre de 2600 kcal/j » | plus dit | `ene-fa-depense` (dit en passant) |
| 4, 5, 11 | trois chiffres du glycogène total | « 500 g à 700 g », 400 g + 100 g | `ene-fa-reserves` |
| 8 | le glucose resynthétisé « à partir de […] l'Acétyl-CoA » | « AA, oxaloacétate » (p. 9) | `ene-qc-periode-alimentaire` (E), `ene-qr-interconversion` : ATTENTION nu |
| 8 | « Le cerveau […] synthétise des corps cétoniques » | le foie (p. 5) | `ene-qc-cetoniques` (E) : ATTENTION nu |
| 9 | le β-hydroxybutyrate porté aux « globules rouges » | plus dit | `ene-fa-cetolyse` (absente) : ATTENTION nu |
| 11 | « l'Acétyl CoA en acide gras, et inversement » | un seul sens (p. 8) | `ene-qc-periode-alimentaire` (E), `ene-qr-interconversion` : ATTENTION nu |
| 11 | « la moitié du sucre sera du gras » | plus dit | `ene-fa-repas` (dit en passant) |
| 12 | « 50 % de nos réserves en glycogène » en 7 h | plus dit | `ene-qr-7h` (absente) : ATTENTION nu |
| 14 | « Marathon : glycolyse anaérobie (99 %) » | aérobie (99 %), juste | `ene-qc-effort` (C), `ene-fa-effort` (dit en passant) |

## Les schémas et les figures

**Douze figures de la FC 2025-26**, extraites telles quelles du PDF. La ronéo
2026-27 en reprend sept telles quelles, en moins net (250 à 410 px de large) : on
garde la version nette, et la légende cite les deux pages. Une huitième, les
carrefours, a changé (ci-dessous). Quatre ne sont plus dans la ronéo (la glycolyse
anaérobie, la cétogenèse, la cétolyse, les produits finaux) : leur légende ne cite
que la FC 2025-26.

**Une figure propre à 2026-27** : la diapositive des carrefours, enrichie du lactate
et des corps cétoniques (`ene-carrefours-2627.png`, p. 5, 271 × 280 px).

**Un schéma cliquable** (`schemas.py`), avec sa version légendée en correction :

| Fichier | Ce qu'on clique | Pourquoi ce dessin |
|---|---|---|
| `mitochondrie-decouplage.svg` | l'espace intermembranaire, la matrice, l'ATP synthase, la chaîne respiratoire, UCP1 (5 zones) | la figure de la p. 5 (« Phosphorylation oxydative », « Découplage ») ; les complexes dans l'ordre de la diapositive (IV, III, Q, II, I) ; la tête de l'ATP synthase, tournée vers la matrice, oriente le dessin. Les protéines sont dessinées dans l'épaisseur de la membrane, sans en dépasser ; la zone de l'ATP synthase est un T renversé, et la matrice, échancrée autour avec 2 px de marge, garde ce qui borde la tige. Aucune zone n'en recouvre une autre |

**Une planche à légender**, `ene-pl-carrefours` : la diapositive des carrefours
(version 2025-26, plus nette ; ronéo 2026-27, p. 5), douze numéros (glycogène,
protéines, triglycérides, glucose-6-phosphate, acides aminés, acides gras,
glucose, glycérol, pyruvate, acétyl-CoA, ATP, pyruvate déshydrogénase), six intrus
(oxaloacétate, malonyl-CoA, urée, lactate déshydrogénase, fructose-6-phosphate,
créatine phosphate). Les rectangles et l'image numérotée sont inchangés.

**Trois figures redessinées** pour les corrections : `rendements.svg` (apports et
rendements des nutritionnistes, « assez bon » pour le glucose), `effort.svg`
(sprint, 800 m, marathon, marche, redessiné sur la p. 11 de 2026-27) et
`marasme-kwashiorkor.svg`. Rendues et regardées.

**30 QCM sur 31 illustrés (97 %)**, 60 notes sur 77. Sans figure :
`ene-qc-anabolique` (aucune figure du cours ne montre la destinée anabolique).

## Le lexique

Onze termes ; aucun n'existe dans un autre paquet (vérifié contre les `lex-*` de
tous les chapitres). Pages mesurées dans le texte de la ronéo 2026-27 (en-têtes
exclus), puis de la FC 2025-26 :

| Terme | Origine | Pages 2026-27 |
|---|---|---|
| Thermogenèse | grec thermós + génesis | 2, 3 |
| **Macronutriment** (nouveau) | grec makrós + latin nutrimentum | 3 |
| Marasme | grec marasmós | 4 |
| Kwashiorkor | ga (Ghana), par l'anglais ; Cicely Williams, 1935 | 4 |
| **Hypoperfusion** (nouveau) | grec hupó + latin perfusio | 5 |
| Découplage | latin de- + copula | — (le mot n'est que sur la figure de la p. 5 ; FC 2025-26, p. 6) |
| Interconversion | latin inter + conversio | 5 |
| Acidocétose | latin acidus + acetum, grec -ōsis | 6 |
| **Cétogenèse** (nouveau) | latin acetum (par cétone) + grec génesis | 6, 9 |
| Glycogénogenèse | grec glukús + -genḗs + génesis | 8 |
| Anaérobie | grec an- + aḗr + bíos (Pasteur, 1863) | 5, 7, 10, 11 |

Les trois termes nouveaux reprennent des racines de la table commune (`macro-`,
FC de sémantique 2/2 p. 6 ; `nutrire (latin)` ; `hypo-`, FC de sémantique 2/2
p. 10 ; `cét(o)-` ; `-genèse`, FC de sémantique 1/2 p. 7). Une racine nouvelle,
`perfusio (latin)`, et les trois termes sont proposés à `etymologies.json`
(brouillon `etym/bmcp_energetique.json`, vérifiés sur le TLFi, le Wiktionnaire,
Lewis & Short et Georges ; le Bailly pour les racines grecques) ; les textes du
lexique sont écrits dans la forme que `appliquer_etymologies.py` produirait.
**Glycolyse** et **néoglucogenèse**, employés aussi, ne sont pas pris : le chapitre
« Métabolisme général cellulaire » les enseigne en détail et devrait les accueillir.

## Décisions prises en route

- **Une carte n'est confirmée que si sa notion centrale est dans le cours de
  l'année** ; ses propositions de 2025-26 le disent une à une. Une carte dont la
  notion centrale a disparu est absente, même si l'une de ses propositions est
  encore enseignée (`ene-qr-marche` : la marche reste, « meilleur sport » non).
- **Les trous changés** : `ene-fa-atp` (c8 ajouté), `ene-fa-autres-postes` c4,
  `ene-fa-apports` c4, `ene-fa-reserves` c4 et c6, `ene-fa-anabolique` (tous ses
  trous), `ene-fa-chiffres` c1 (et c6 ajouté), `ene-fa-effort` c3, c6 et c7. Aucun
  trou n'est retiré.
- **Les figures identiques** restent celles de la FC 2025-26, plus nettes, la
  légende citant la page de la ronéo 2026-27 ; seule la diapositive des carrefours,
  qui a changé, est extraite de la ronéo.
- **`EXAMENS` n'est pas déclaré** (aucun chapitre BMCP n'en a) : l'examen du
  5 janvier 2027 se règle dans l'application.
- **38 ATP** est carté comme le cours le dit, désormais avec `ATTENTION (cours)` :
  le Dr Huin le redit en 2026-27, en rouge.

## La relecture du 11/10/2026

Le réalignement a été relu carte par carte contre la ronéo 2026-27 (texte et
figures, p. 1 à 12), les cours 2023-24, 2024-25 et 2025-26 du Dr Huin, et des
sources de référence. Ce qu'elle a changé :

- **Une erreur de prise de notes reclassée** : les « tubes à essai » du rendement
  des biochimistes, passés de « douteux » à « prise de notes », parce que les trois
  cours précédents rangent le tube à essai sous le rendement théorique maximal
  (`ene-qc-rendements`, A et B).
- **Deux points douteux ajoutés** : le cerveau « incapable de stocker » le glucose
  (p. 8 ; les astrocytes ont un peu de glycogène), dans `ene-qc-glucose-substrat` (E) ;
  l'acétyl-CoA qui « pourra ensuite entrer dans les mitochondries » (p. 5), dans
  `ene-qc-retenir` (E). Ce dernier, d'abord classé en prise de notes, est un point
  douteux : la phrase suit le schéma général du cours (l'acétyl-CoA posé à l'étape
  « la cellule », p. 4), comme le cours 2024-25 (« transformés dans la cellule »),
  alors que le cours 2023-24 faisait faire l'acétyl-CoA par la mitochondrie.
- **Une erreur du cours lui-même ajoutée** : le repas de 90 g de glucose dont 30 %
  deviendrait de la graisse (p. 8, déjà dans la FC 2025-26, p. 11), dans
  `ene-fa-repas`. À l'examen, on répond comme le cours ; la référence est que la
  lipogenèse de novo après un repas ordinaire est minime chez l'homme (Hellerstein,
  J Clin Invest 1991 et Eur J Clin Nutr 1999 ; Acheson, Am J Clin Nutr 1988).
- **Trois corrections de détail** : `ene-qc-apports` D cite la bonne phrase de la p. 3
  (l'amidon « doit être la principale source alimentaire ») ; `ene-qr-lipides-kcal` cite
  la p. 9 du cours 2023-24 (et non la p. 8), et sa réponse dit que les trois exemples
  font déjà environ 500 kcal, au lieu de les donner pour les 800 kcal de la journée.
- **`paquet.json` et les cinq SVG de `media/` étaient remplis d'octets nuls** (écrits
  le 11/10 à 15 h 44, sans doute par une génération interrompue) : régénérés.
- **Des justifications reprises** : l'ATP « molécule de stockage » dit désormais ce
  qu'on répond à l'examen ; `ene-qc-lipides` A et D ne citaient pas chacune son
  propre chiffre ; `ene-qc-carrefours` C cite la flèche du lactate vers le glucose
  de la diapositive 2026-27 ; les 90 kcal de `ene-qr-lipides-kcal` sont ceux de
  10 g de lipides, et non d'une tartine ; la réserve de protéines cite aussi Berg.
- **Vérifié et laissé tel quel** : aucune note retirée, aucun identifiant ni type
  changé (75 notes contre 64), aucun trou retiré ; les quatre `ABSENTS_2026`
  appartiennent à des sections que la ronéo couvre en entier ; les pages des
  figures (p. 2 à 6) ; la clé de l'annale ; les trois termes nouveaux du lexique,
  absents de tous les autres paquets.

## Questions pour Vincent

- (11/10) 2020/2021 S1 Q. 2, clé déduite BCD : B est tenu pour vrai par le seul glycérol des triglycérides. Si tu préfères la lecture stricte du cours de lipides du Pr Benlian (« on ne fait jamais de sucre avec du gras », ronéo 2026-27 p. 3), la clé devient CD. Garde-t-on BCD ?
- (11/10) « Diagnostic différentiel avec les acidocétoses métaboliques » revient deux années de suite (2025-26 et 2026-27), alors que 2023-24 et 2024-25 disent « acidoses métaboliques ». Si la diapositive du Dr Huin porte vraiment ce mot, l'erreur passe de « prise de notes » à « le cours lui-même ». La bonne réponse ne change pas.
- (11/10) Le repas de 90 g de glucose dont 30 % deviendrait de la graisse porte désormais un ATTENTION (cours). À l'examen, on répond comme le professeur ; la référence dit que la lipogenèse de novo après un repas ordinaire est minime. Garde-t-on cet avertissement ?

1. **2020/2021 S1 Q. 2, clé déduite BCD** : B est tenu vrai par le seul glycérol
   des triglycérides ; si tu préfères la lecture stricte, celle du cours de lipides
   du Pr Benlian (« on ne fait jamais de sucre avec du gras »), la clé devient CD.
2. **« Acidocétoses métaboliques »** : deux ronéos de suite (2025-26, 2026-27)
   écrivent la même chose ; si la diapositive du Dr Huin le dit vraiment, l'erreur
   passerait de « prise de notes » à « le cours lui-même ». La réponse ne change pas.
3. **La clé de thème** `gestion-energie` (au lieu d'`effort`) : à garder ?

## À relire

**Aucune carte `a-relire`** : chaque note cite sa page de la ronéo 2026-27 ou,
pour les quatre absentes, de la FC 2025-26 ; les trois annales ont une clé déduite, dite,
chaque proposition sur une page de la ronéo 2026-27.
Reste à Vincent :

- `copier_les_cours.py` avec le dossier des ronéos 2026-27, hors du bac à sable,
  pour que la fiche de l'année s'ouvre dans l'application ;
- réimporter le paquet (Réglages → « Importer un paquet » →
  `contenu/chapitres/bmcp_energetique/paquet.json`).

## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier (BMCP) ou du 6 janvier (SSH, papier). Sous les annales, 10 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 2 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `substrats` | 10 | 2 | 3 |

**Le schéma** `ech-substrats`, « Les substrats énergétiques · apporter, stocker, utiliser », donne 16 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_SUBSTRATS`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**L'ATTENTION des réserves complété** (C29, 19/10), sur 2024/2025 S1 Q17 B et 2020/2021 S1 Q2 A : la ronéo des protéines 2026-27 donne « une masse de 18 kg » de protéines pour un homme de 70 kg (p. 2). C'est la masse protéique de l'organisme, pas la réserve énergétique ; la clé suit toujours l'histogramme.

**Sans marche** :
- ene-an-2021s1-q2 C et D (syndrome métabolique, insulinorésistance, VLDL) : justifiées sur la FC n°3 2025-26 (chapitre de l'insuline), hors des sources du dossier ; ce cours ne les traite pas.
- ene-an-2021s1-q2 E (leptine) : absente de ce cours ; sa justification s'appuie sur le chapitre de l'insuline et une source extérieure.

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```
