# Ontogenèse des lymphocytes B — paquet Immunologie

79 notes, 153 cartes. Chapitre `chap-ue-immunologie-fc4` de l'UE Immunologie.
Cours du **Pr Dubucquoi, le 02/10/2026** (10 h-11 h), « Le récepteur pour
l'antigène des lymphocytes B : l'ontogenèse des lymphocytes B », **ronéo
Ronéo & Juliette 2026-27** (20 pages, la dernière blanche), livré le 11/10/2026.
Le Ronéosaure 2025-26 (FC n°4, même professeur, 06/10/2025) n'est plus qu'un
appoint. Annales des polycopiés IMMUNO n°4 et n°8 du Ronéosaure 2024-25 (15
questions sur 13 sessions) et du sujet 2024/2025 déposé le 15/10/2026 (2
questions). Examen de novembre (mercredi 4 novembre 2026).

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| Texte à trous | 15 | 81 |
| QRM | 33 | 33 |
| QRU | 1 | 1 |
| QROC | 9 | 9 |
| Recto-verso | 10 | 10 |
| Schéma cliquable | 2 | 10 |
| Planche à légender | 1 | 1 |
| Lexique | 8 | 8 |

Dont **17 annales** : 14 QCM et 3 QROC (en recto-verso), sur 14 sessions, de
2015/2016 S1 à 2024/2025 S1. **33 QCM sur 34 illustrés** (97 %), 64 notes sur 79.
**10 cartes portent un piège du ronéo** (thème « Pièges des ronéos » ; deux de plus le 19/10, pour la suite du cours) ; **aucune
n'est absente du cours 2026-27**, ni en entier ni par une proposition : `olb-qc-plasmocyte` E,
seule proposition que le ronéo du 02/10 ne portait plus, est redite par sa suite (ronéo du
09/10/2026, p. 8), et a perdu sa mention le 19/10.

Six thèmes, tous déjà dans `THEME_LABELS` (`app/src/med_engine/application/scopes.py`) :

| Clé | Libellé |
|---|---|
| `lb-elements-cles` | Le lymphocyte B : éléments clés |
| `structure-ig` | Structure des immunoglobulines |
| `formes-ig` | Formes membranaires et solubles des immunoglobulines |
| `isotypes-idiotypes` | Isotypes, allotypes et idiotypes |
| `recombinaison-vdj` | Réarrangements V(D)J et diversité du répertoire (partagé avec `immuno_thymus`) |
| `repertoire` | Répertoire et éducation des lymphocytes (celui d'`immuno_temporelle`) |

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-immuno-ontogenese-b` — Ronéo & Juliette, « Le récepteur pour l'antigène des lymphocytes B : l'ontogenèse des lymphocytes B » (20 p.), `IMMUNOLOGIE/ONTOGENÈSE DES LYMPHOCYTES B.pdf` | **2026-27** | **la base** : la fiche que le lecteur ouvre (`chapitre=`, `SRC["fiche"]`) ; ses 54 notes de cours portent leur page, et les 8 termes du lexique y ont leurs premières pages. À copier dans le dossier des PDF de l'application par `outils/copier_les_cours.py`, hors du bac à sable |
| `src-cours-immuno-ontogenese-b` — Ronéosaure, FC n°4 - Ontogenèse des lymphocytes B (16 p.), `IMMUNOLOGIE/FC n°4 - Ontogenèse des lymphocytes B.pdf` | 2025-26 | **appoint**, sans `chapitre=` : les images entières des diapositives que le ronéo 2026-27 rogne, celles des chaînes lourde et légère qu'il n'a pas, les pages de 2025-26 du lexique (après celles de 2026-27). Cet identifiant est nouveau : jusqu'au 11/10, la FC 2025-26 portait `src-fc-immuno-ontogenese-b`, que reprend désormais le ronéo de l'année |
| `src-annales-immuno-ontogenese-b` — IMMUNO n°4 (5 p.) | 2024-25 | 7 questions ; table p. 4-5 |
| `src-annales-immuno-activation-b` — IMMUNO n°8 (13 p.) | 2024-25 | 8 questions, par `SRC["sessions"]` ; **déclaration identique**, mot pour mot, à celle d'`immuno_activation_b` |
| `src-sujets-immuno-2425` — sujet de système immunitaire 2024/2025, session 1 (3 p.) | 2024-25 | dépôt du 15/10/2026 : les Q6 et Q7 (`SRC["sessions"]["2024/2025 S1"]`) ; sujet sans corrigé, clés déduites du cours ; déclaré à l'identique dans chaque chapitre d'immunologie qui en a une question |
| grille officielle des QCM 2023/2024 (02/11/2023) | 2023-24 | dépôt du 15/10/2026 : confirme la clé de la Q6 de cette session ; citée, pas déclarée |
| Tableau des erreurs d'immunologie 2026-27 | 2026-27 | deux entrées au 11/10, toutes deux sur le CMH, quatre au 19/10 : **aucune sur ce cours ni sur sa suite** |
| Ronéo & Juliette 2026-27, « Ontogenèse des lymphocytes B et mise en place d'une réponse immunitaire anticorps dépendante » (12 p., 09/10/2026), `IMMUNOLOGIE/ONTOGENÈSE DES LYMPHOCYTE B 2.pdf` | 2026-27 | la suite de ce cours, fiche d'`immuno_activation_b`, qui la déclare (`src-fc-immuno-activation-b`) ; citée ici dans le texte de cinq cartes, sans être déclarée (ci-dessous) |
| Erratas Immuno 2025-26 (cours) | 2025-26 | trois entrées sur la FC n°4 : « VA » (corrigé dans le ronéo 2026-27), « 3 CDR » et « à terme les anticorps » (reprises telles quelles en 2026-27, portées dans les cartes) |
| Erratas annales immunologie 2024-25 | 2024-25 | aucune entrée pour ces questions |

Cités dans le texte des cartes, sans être déclarés : la FC n°6 2025-26 (BAFF et
APRIL, révision de la chaîne légère, IgM et IgD sur le LB qui sort de la moelle),
la FC n°10 2025-26 (avidité, IgM et IgG d'une réponse, « 4 bras pour IgA »), la
FC n°7 2025-26 (voie classique), le ronéo 2026-27 du cours d'introduction
(`immuno_temporelle`, 10⁹ à 10¹⁰ récepteurs).

Vérifications hors du cours, citées là où elles servent : Janeway, Immunobiology
(Fab = fragment antigen-binding ; neuf isotypes de chaîne lourde ; diversification
secondaire par l'AID ; coexpression IgM-IgD par épissage alternatif ; 7e éd., p. 153 :
1,9 × 10⁶ par les seules diversités combinatoires, jusqu'à 10¹¹ avec la
jonctionnelle) ; Porter 1959 (le Fab de la papaïne) ; Sender et al., PNAS 2023 (les
LB, un tiers des lymphocytes de l'organisme) ; Pinto et al., Blood 2013;121:4110 (les
plasmocytes humains à IgA et à IgM gardent un BCR fonctionnel) ; Shapiro-Shelef et
Calame, Nat Rev Immunol 2005 (quelques milliers d'anticorps par seconde et par
plasmocyte) ; Jefferis et Lefranc, mAbs 2009, et la base IMGT (allotypes Gm,
dont G1m17 et G1m3 sur le CH1, et Km sur la chaîne kappa) ; Kapitonov et Jurka,
PLoS Biol 2005, et Flajnik et Kasahara, Nat Rev Genet 2010 (apparition du
réarrangement V(D)J chez les vertébrés à mâchoires) ; Hozumi et Tonegawa, PNAS 1976
(sa découverte, chez la souris).

## Le ronéo 2026-27 remplace le Ronéosaure 2025-26 (11/10/2026)

Jusqu'au 11/10, le chapitre était bâti sur la FC n°4 du Ronéosaure 2025-26, en
attendant le ronéo de l'année (tâche C14), et ses cartes portaient le badge
« Cours 2025-26 ». Le ronéo 2026-27 est arrivé ; **chaque note a été relue contre
lui**, page par page. Son texte suit celui de 2025-26 presque mot pour mot, mais
ses pages sont décalées (20 au lieu de 16) : **toutes les notes de cours ont reçu
leur page de 2026-27** et citent le ronéo de l'année ; aucune n'en est absente.
Les annales citent elles aussi ses pages.

**Ce que le ronéo 2026-27 dit autrement, et ce qui a été corrigé** :

- **Plus de rouge ni de gris.** Les cartes ne disent plus « en rouge dans le
  cours » (`olb-qc-forces` A, `olb-qc-allo-idio` E, `olb-qc-diversites` D,
  `olb-fa-diversites`) ; le « Attention » qu'elles citent est souligné. Les
  consignes du professeur, elles, restent dans le texte et sont suivies.
- **Plus de « résumé » à la p. 10 de 2025-26** : deux paratopes par
  immunoglobuline de membrane, jusqu'à dix pour l'IgM soluble, un seul isotype à
  un moment donné, sécrétion « vraiment prolongée » et « jusqu'à 1 000 kg/min ».
  `olb-qc-valences` et les annales sur la valence (2023/2024 Q6, 2021/2022 S2 Q6,
  2020/2021 S1 Q6, 2019/2020 S1 Q6) comptent désormais sur les p. 7 à 9 : deux Fab
  par monomère, un pentamère de cinq immunoglobulines, un dimère d'IgA.
  `olb-qc-plasmocyte` E (« il sécrète ses anticorps de façon prolongée ») **reste**,
  avec sa clé. Le 11/10, sa justification commençait par « Absent du cours 2026-27 » ;
  le 19/10, la suite du cours la redit (ronéo du 09/10/2026, p. 8 : les plasmocytes
  vivent dans la moelle et la rate « pour produire de façon prolongée des anticorps »),
  et la justification cite cette page au lieu de la mention. Elle dit aussi, sans ATTENTION,
  que le « 1 000 kg/min » de 2025-26 était impossible. L'explication de la carte cite
  la phrase de l'année (p. 8) : le plasmocyte sécrète « les immunoglobulines qui
  étaient exprimées à la membrane, sous une forme potentiellement différente ».
- **Trois fautes de 2025-26 corrigées** : « une partie VH et une partie VL »
  (p. 7 ; `olb-qc-fab-fc` A n'a plus d'ATTENTION), « terminal désoxynucléotidyl
  transférase » (p. 16 ; `olb-qr-tdt`), « chaîne μ » (p. 14 ; `olb-qc-genes` D).
  Aussi : « l'activité PCR » (p. 2) et « préserver les LB qui expriment des LB »
  (p. 19) ont disparu.
- **Deux fautes de 2025-26 reprises telles quelles** (« à terme les anticorps »,
  « 3 CDR différents ») et sept autres points (« fragment antibody », « jamais en
  même temps », allotypes « au niveau des Fc », « multiplie par 10 », « 80 % », le
  plasmocyte qui « exprime une IgA monomérique à sa membrane », « poissons
  cartilagineux ») sont désormais des **erreurs du ronéo de l'année**, avec leur
  genre (ci-dessous). Le plasmocyte à IgA de membrane reste un point douteux, comme
  en 2025-26 : la p. 6 et la diapositive (« Membrane (du LB) ») le contredisent, mais
  les plasmocytes humains à IgA gardent un peu de BCR (Pinto et al., Blood 2013).
- **Le 10⁹ à 10¹²** est sur la diapositive p. 12, avec sous chaque puissance un
  petit mot trop flou pour être lu sûrement (peut-être « individu » et
  « espèce ») : `olb-qc-genes` E le dit, et garde l'avertissement sur l'écart avec
  le cours d'introduction (10⁹ à 10¹⁰).
- **Les figures** : beaucoup sont des captures rognées des mêmes diapositives
  (ci-dessous, « Les figures »).

**Cartes nouvelles** (4), sur ce que le ronéo 2026-27 enseigne et qu'aucune carte
ne portait : `olb-fa-defense` (les trois niveaux de la défense, p. 2-3),
`olb-qc-defense` (antigène, répertoire, barrières, deuxième niveau ciblé,
récepteurs communs de l'immunité innée, p. 2-4), `olb-fa-organes` (organes
lymphoïdes primaires, production et éducation, p. 5), `olb-qc-bcr` (100 000 BCR
identiques par LB, deux LB deux BCR, BCR et anticorps, plus d'un milliard de BCR
pour 20 000 gènes, le schéma « pas à l'échelle », p. 4-6, 13). Toutes quatre
illustrées. Les 100 000 BCR étaient laissés à `immuno_temporelle` ; le ronéo de
l'année les dit ici (p. 5), et `olb-qc-bcr` en fait une proposition.

## La suite du cours, le 09/10/2026 (relue le 19/10/2026)

Le Pr Dubucquoi a poursuivi ce cours le 09/10/2026 (8 h-9 h) : « Ontogenèse des lymphocytes
B et mise en place d'une réponse immunitaire anticorps dépendante », ronéo 2026-27 de 12
pages déposé le 19/10. Ses pages se partagent ainsi entre trois chapitres :

| Pages | Contenu | Chapitre |
|---|---|---|
| 2-3 | rappels de ce cours : immunoglobuline bifonctionnelle, paratope et Fc, répertoire, RAG, VDJ et VJ, TdT et diversité N, CDR3, sélection, révision du paratope, « fenêtre de tir » | **celui-ci** : rien de nouveau, aucune carte à changer |
| 3-5 | de la moelle aux organes lymphoïdes secondaires, origine des LB, étapes pro-B, pré-B, transitionnelle (« à ne pas toutes retenir »), sélection, sous-populations | `immuno_activation_b` (la FC n°6) |
| 6-10 | BAFF et APRIL, les deux voies, aide cognate, centre germinatif, hypermutation, commutation, chronologie, réponses primaire et secondaire, biologie médicale | `immuno_activation_b` |
| 10-11 | fonctions des classes d'anticorps, « à connaître », et leur tableau | `immuno_activation_b` (une carte) ; recoupe `immuno_anticorps` |

Elle est la fiche d'`immuno_activation_b`, qui la déclare ; ce chapitre-ci ne la déclare
pas, puisqu'aucune de ses cartes n'en cite une page. Aucune clé, aucune page n'a changé.
La suite porte ici trois erreurs de prise de notes, là où la notion se joue
(`olb-qc-rag` B, `olb-qr-tdt`, `olb-qc-fab-fc` E, ci-dessous), et deux témoins de plus :
sa figure de rappel p. 2 développe Fab en « Fragment « Antibody » » (`olb-qc-fab-fc` B,
ATTENTION (cours) déjà posé) ; sa figure p. 5 (LB immatures à IgM et IgD) et son tableau
p. 11 (« (IgD) expression sur les LB naïfs ») renforcent la référence d'`olb-qc-isotypes` E.
Elle redit enfin la sécrétion prolongée des plasmocytes, dans leur niche de la moelle
(p. 4) et de la rate (p. 8) : `olb-qc-plasmocyte` E perd sa mention « Absent du cours
2026-27 » et cite cette page (relecture sceptique du 19/10).
Rien de ce que la première partie laissait aux chapitres voisins (sortie de moelle, BAFF et
APRIL, activation, fonctions des isotypes) n'est carté ici.

## Ce que le cours a dicté

- **Cinq parties** : contexte et éléments clés (p. 2-5), le BCR et sa structure,
  ses formes, isotypes, allotypes, idiotypes, les Ig dans le sang (p. 5-11), la
  génération du répertoire (p. 12-16), le contrôle de qualité (p. 16-18), les
  sélections (p. 18-19).
- **Les consignes du professeur** : « retenir que TdT » (p. 16 : `olb-qr-tdt`,
  trois QCM) ; « ne pas retenir les noms/chiffres des chromosomes », retenir
  « comment ça marche » (p. 15 — les cartes n'en parlent pas ; la figure du
  réarrangement garde son « chromosome 14 ») ; l'ordre des concentrations des Ig,
  pas les chiffres (p. 11 : `olb-qc-concentrations`, une QRU sans chiffre) ; le
  déficit en IgA « vu au prochain semestre » (p. 9 ; la p. 11 en dit une phrase,
  reprise dans l'explication d'`olb-fa-concentrations`) ; « just for fun » (p. 16) :
  la diapositive qui porte ce titre (la clé du paratope, SARS-CoV-2, p. 17), dont le
  professeur « n'a rien évoqué », n'est pas reprise. La mise en page du ronéo, la
  même qu'en 2025-26, pose ce titre au-dessus de la diapositive des « mécanismes de
  contrôle » (p. 16), qui ouvre la partie IV et que le texte p. 17 reprend ; la
  diapositive de la séquence du CDR3 (p. 17) est du cours, redessinée en
  `olb-cdr3.svg`.
- **Le gris** : le ronéo 2026-27 n'en a pas, ni de rouge.
- **Ce qui n'est pas recarté**, parce qu'un autre chapitre le porte : le TCR et
  ses réarrangements (FC5) ; la sortie de moelle, BAFF et APRIL, l'activation
  (FC6) ; les fonctions par isotype — dont la résistance des IgA aux protéases
  bactériennes (p. 9), la barrière des muqueuses et la transcytose par le pIgR — et
  l'avidité (FC10, `immuno_anticorps`, cités en justification seulement). La pièce
  sécrétoire n'est vue ici que comme une forme. Le QROC sur le CD20 garde le
  marqueur et sa cible ; les mécanismes du rituximab sont au chapitre des anticorps.

## Ce que les annales ont dicté

Les deux polycopiés sont numérotés d'après le programme 2024-25 ; les questions
ont été rangées par contenu (plan C14). Ce qui revient : la valence et la forme de
l'IgM (4 sessions), la structure des chaînes et des fragments (4), les sources de
la diversité (3), le contrôle de qualité et la révision du paratope (2). **Le
11/10/2026, chaque clé a été relue contre le ronéo 2026-27 : aucune n'est
contredite.**

| Poly | Session | N° | Clé imprimée | Retenu | Sujet | Carte |
|---|---|---|---|---|---|---|
| sujet 2024/2025 | 2024/2025 S1 | 6. | **aucune** | déduite : CD | génération des BCR | `olb-an-2425s1-q6` |
| sujet 2024/2025 | 2024/2025 S1 | 7. | **aucune** | déduite : ABCE | isotypes, sous-classes, formes | `olb-an-2425s1-q7` |
| n°4 (= n°10) | 2023/2024 S1 | Q6 | ABE (= grille officielle) | ABE | sites Fab des IgM, IgG, IgA | `olb-an-2324s1-q6` |
| n°4 (= n°8) | 2022/2023 S1 | Q5 | BCD | BCD | structure du BCR | `olb-an-2223s1-q5` |
| n°8 | 2022/2023 S2 | 6. | CD | CD | production du BCR | `olb-an-2223s2-q6` |
| n°8 (= n°10) | 2021/2022 S2 | Q6 | ACE | ACE | IgM, avidité | `olb-an-2122s2-q6` |
| n°4 (= n°7, n°8, n°10) | 2020/2021 S1 | Q.6 | BDE | BDE | IgM, avidité | `olb-an-2021s1-q6` |
| n°4 (= n°8) | 2020/2021 S2 | QROC 3 | corrigé | corrigé | test du BCR, révision du paratope | `olb-an-2021s2-qroc3` |
| n°4 (= n°8, n°10) | 2019/2020 S1 | Q6 | ADE | ADE | domaines, valence | `olb-an-1920s1-q6` |
| n°4 | 2019/2020 S1 | QROC 1 | **aucune** | déduite | réarrangement VDJ, enzymes | `olb-an-1920s1-qroc1` |
| n°4 | 2018/2019 | Q1 | DE | DE | le Fc d'une IgG | `olb-an-1819-q1` |
| n°8 | 2019/2020 S2 | Q1 | BCDE | BCDE | isotypes, allotypes, idiotypes | `olb-an-1920s2-q1` |
| n°8 | 2018/2019 S1 | Q8 | ACD | ACD | sources de la variabilité des paratopes | `olb-an-1819s1-q8` |
| n°8 | 2016/2017 S2 | Q1 | AD | AD | le répertoire B | `olb-an-1617s2-q1` |
| n°8 (= n°10) | 2015/2016 S1 | Q2 | ADE | ADE | ontogenèse B | `olb-an-1516s1-q2` |
| n°8 / n°10 | 2015/2016 S1 | Q3 | **CE / DE** | CE | immunoglobulines | `olb-an-1516s1-q3` |
| n°8 | 2015/2016 S2 | QROC 4 | corrigé | corrigé | 4 fonctions des LB | `olb-an-1516s2-qroc4` |

Les anomalies des polycopiés, dites dans la carte qui les concerne :

- **IMMUNO n°4** porte un en-tête fautif (« BMCP - Annales », « Oncogènes des
  lymphocytes B ») et imprime ses années sans session ; le libellé vient d'IMMUNO
  n°8 ou n°10 quand ils reprennent la question. 2018/2019 Q1, qu'aucun autre ne
  reprend, garde « 2018/2019 ». IMMUNO n°4 range sous « 2020-2021 » la Q.6
  (session 1) et le QROC 3 (session 2).
- **2016/2017 S2 Q1** est imprimée sous « Année 2017/2018 (Session 2) » ; la table
  de corrections la range en 2016/2017 session 2, libellé gardé.
- **2021/2022 S2 Q6** : IMMUNO n°10 la reprend sous « Session X ».
- Déjà ailleurs, non recopiée : 2019/2020 S1 Q9 (lymphopoïèse B) est dans
  `immuno_temporelle` (`imm-an-1920-q9`) ; le QROC 4 « 2021/2022 » d'IMMUNO n°4
  (trois diversités du répertoire T) part au chapitre du thymus.

**Les annales du dépôt du 15/10/2026** : la clé de 2023/2024 S1 Q6
(`olb-an-2324s1-q6`, ABE) est **confirmée par la grille officielle (dépôt du
15/10/2026)**. Deux questions du sujet 2024/2025 S1 sont nouvelles : la Q6
(`olb-an-2425s1-q6`), voisine de 2022/2023 S2 6. ; la Q7 (`olb-an-2425s1-q7`),
dont l'énoncé imprime « en lien en lien », gardé. La Q8 du même sujet (BAFF et
APRIL, MSC, CDF) est dans `immuno_activation_b`, qui enseigne ces notions.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2024/2025 S1 Q6 (`olb-an-2425s1-q6`) | aucune (sujet sans corrigé) | **CD**, déduite du cours, non officielle | BCR produit dans la moelle, organe primaire (p. 5), avant tout contact, pas chez le plasmocyte (p. 6) ; VDJ et VJ (p. 14-15) ; nucléotides N de la TdT aux jonctions (p. 15-16) ; des BCR qui reconnaissent faiblement le soi (p. 17-19) |
| 2024/2025 S1 Q7 (`olb-an-2425s1-q7`) | aucune (sujet sans corrigé) | **ABCE**, déduite du cours, non officielle | cinq isotypes, quatre sous-classes d'IgG (p. 6, 10) ; monomère à la membrane, IgG soluble « principalement » monomérique (p. 8) ; IgM soluble pentamérique, dix paratopes (p. 7-8) ; IgA dimérique aux muqueuses (p. 9) |
| 2015/2016 S1 Q3 | CE (IMMUNO n°8), DE (IMMUNO n°10) | **CE**, officielle (celle d'IMMUNO n°8) | D (« le fragment cristallisable interagit avec l'épitope ») est faux : c'est le paratope du Fab (ronéo 2026-27, p. 7-8, 10) ; la clé d'IMMUNO n°10 n'est pas bonne. C (« quatre isotypes différents d'IgG ») est vrai : le cours dit « sous-classes », mais chacune est un isotype de chaîne lourde (γ1 à γ4 ; Janeway), les « 9 immunoglobulines différentes » du cours (p. 6). `CONFLITS` sur C et D, ATTENTION dans les deux justifications |
| 2019/2020 S1 QROC 1 | aucune | déduite du cours, `officielle=False` | « aucune correction » ; réponse tirée du ronéo 2026-27, p. 12-16 |

Un contresens signalé, clé gardée :

| Question | Clé | Le contresens | Retenu |
|---|---|---|---|
| 2018/2019 S1 Q8 E | ACD (E fausse) | l'AID déclenche l'hypermutation, qui modifie le paratope : 2023/2024 S1 Q7, 2018/2019 S1 Q9 D et le corrigé du QROC 3 de 2015/2016 S2 le disent, la littérature aussi (diversification secondaire) | la clé imprimée : la question porte sur la variabilité du répertoire, née dans la moelle (RAG, TdT, association, ronéo 2026-27 p. 15-16) ; l'AID n'agit qu'après le contact antigénique. `CONFLITS` sur E, ATTENTION « point douteux » qui dit les deux lectures |

Cas ouvert : 2018/2019 S1 Q8 E reste un point douteux ; la carte garde la clé
imprimée et le dit.

## Les erreurs du ronéo 2026-27

Le tableau des erreurs de la promo ne cite pas ce cours au 11/10 : toutes ces
erreurs ont été trouvées en relisant, et sont aussi à porter dans
`contenu/ERRATA_RONEOS_2026-27.md`. Le ronéo n'est pas corrigé ; chaque erreur est
portée par une carte, avec son genre, et la carte retient la bonne lecture. À
l'examen, on répond d'abord comme le professeur.

**Prises de notes fausses** (`ATTENTION (prise de notes)`) :

| Page | Le ronéo dit | Ce qui est juste | Carte |
|---|---|---|---|
| 4 | les plasmocytes, « c'est ce qu'on appelle à terme les anticorps » | le plasmocyte produit les anticorps : le même ronéo le dit p. 6, la diapositive p. 5 le montre (plasmocyte, puis Ac soluble) ; déjà dans l'errata 2025-26 de l'UE | `olb-qc-plasmocyte` (A) |
| 12 | « comme il y a 2 chaînes lourdes et 2 chaînes légères, on aura 3 CDR différents » | six CDR par paratope, trois par chaîne : la p. 13 (« la somme des 3 CDR de la chaîne lourde + les 3 CDR de la chaîne légère »), la main à six doigts (p. 12), la diapositive p. 12 ; déjà dans l'errata 2025-26 | `olb-qc-cdr` (C) |

**C'est le cours lui-même** (`ATTENTION (cours)`, avec « À l'examen » puis « La
référence ») :

| Page | Le cours dit | À l'examen | La référence | Carte |
|---|---|---|---|---|
| 7 (diapositive p. 8) | Fab, « fragment antibody » | le Fab reconnaît l'antigène | Fab = fragment antigen-binding, le fragment de la papaïne (Porter 1959 ; Janeway) | `olb-qc-fab-fc` (B) |
| 8 | un LB produit « des IgM, puis à un autre moment des IgD, … jamais en même temps » (et le résumé 2025-26 p. 10 : un seul isotype à un moment donné) | un seul isotype sécrété à la fois ; IgM puis IgA, jamais en même temps | le LB naïf mature porte IgM et IgD ensemble, même paratope, par épissage alternatif (Janeway) ; le professeur le montre lui-même (FC n°6 2025-26, diapositive p. 3) | `olb-qc-isotypes` (E) |
| 10 | les allotypes, « les différences siègent au niveau des fragments Fc » | allotypes surtout des IgG, sur le Fc | la plupart des Gm sur le Fc (CH2, CH3 ; G1m1 et G1m2 sur le CH3), mais G1m17 et G1m3 sur le CH1 et les Km sur la chaîne kappa, donc sur le Fab (Jefferis et Lefranc, mAbs 2009 ; IMGT) | `olb-qc-allo-idio` (B) |
| 16 | la diversité jonctionnelle « multiplie par 10 la diversité des récepteurs » (en rouge en 2025-26, p. 13) | « par 10 » | bien plus qu'un facteur 10 : 1,9 × 10⁶ par les diversités combinatoires, jusqu'à 10¹¹ récepteurs avec la jonctionnelle (Janeway, Immunobiology, 7e éd., p. 153) | `olb-qc-diversites` (D) |

**Points douteux** (`ATTENTION (douteux)`), dits dans la carte sans changer sa clé :

| Page | Le point | Carte |
|---|---|---|
| 4 | les LB, « 80 % des lymphocytes présents dans les organes lymphoïdes secondaires » : aucune diapositive ne le montre ; dans l'organisme, les LB font environ un tiers des lymphocytes (Sender et al., PNAS 2023) | `olb-qc-elements` (B) |
| 9 | « le plasmocyte exprime une IgA monomérique à sa membrane » : la p. 6 dit que le plasmocyte n'exprime plus de BCR, et la diapositive de la même page range les monomères sous « Membrane (du LB) » ; mais les plasmocytes humains à IgA et à IgM gardent un BCR fonctionnel, en petite quantité (Pinto et al., Blood 2013) — la phrase n'est pas fausse à coup sûr. À l'examen, la règle de la p. 6 | `olb-qc-plasmocyte` (B) |
| 14 | le mécanisme « a été découvert grâce aux poissons cartilagineux il y a environ 450 millions d'années » : le réarrangement V(D)J est apparu chez les premiers vertébrés à mâchoires il y a 450 à 500 millions d'années, les poissons cartilagineux étant les plus anciens à le porter (Kapitonov et Jurka 2005 ; Flajnik et Kasahara 2010), et il a été découvert chez la souris (Hozumi et Tonegawa 1976) ; on ne sait qui, du professeur ou des rédacteurs, a mêlé les deux | `olb-qr-rag` |

**Les erreurs de la suite du cours (ronéo du 09/10/2026), portées dans ce chapitre**
(`ATTENTION (prise de notes)`) ; les autres erreurs de ce ronéo sont dans le LISEZ_MOI
d'`immuno_activation_b` :

| Page | Le ronéo dit | Ce qui est juste | Carte |
|---|---|---|---|
| 5 | « un réarrangement du gène V, puis DJ au niveau de la chaîne légère » | la chaîne LOURDE réarrange D-J, puis V-DJ ; la chaîne légère, sans segment D, réarrange V-J (ce cours p. 14-15 ; le même ronéo p. 2, « VDJ ou VJ » ; Janeway) | `olb-qc-rag` (B) |
| 3 | la diversité N « apportée par la termino terminale, mais aussi la TDT (transférase) » | une seule enzyme, la terminal désoxynucléotidyl transférase (ce cours p. 16) | `olb-qr-tdt` |
| 2 | « une autre structure appelée fragment cristallisable (IgG) » | (Fc) : sa figure de la même page dit « Fragment cristallisable = « Fc » » ; l'IgG est une classe | `olb-qc-fab-fc` (E) |

**Coquilles sans carte** : « les 2 FAD » (p. 11, les deux Fab) ; « Fab'2 » (p. 7 et
diapositive p. 8, F(ab')₂ — dit dans `olb-qc-fab-fc` C).

**Un avertissement ordinaire** (`ATTENTION` sans genre), qui n'est pas une erreur du
ronéo : le cours d'introduction du même professeur (ronéo 2026-27,
`immuno_temporelle`) donne 10⁹ à 10¹⁰ récepteurs, celui-ci « plus de 10⁹ à plus
de 10¹² » (`olb-qc-genes` E).

## Absent du cours 2026-27

**Aucune carte entière.** Toutes les notions du chapitre sont dans le ronéo du
02/10/2026. Ce qu'il ne reprend plus du Ronéosaure 2025-26 (le résumé de la p. 10 :
valences, un seul isotype à la fois, sécrétion prolongée et son débit) tenait dans
des propositions : les valences se comptent sur les p. 7 à 9, le seul isotype à la
fois tient dans « jamais en même temps » (p. 8), et **`olb-qc-plasmocyte` E** (la
sécrétion prolongée) reste. Du 11 au 19/10, sa justification commençait par « Absent du
cours 2026-27 » ; la suite du cours la redit (ronéo du 09/10/2026, p. 4 et 8), et la
mention est retirée. `ABSENTS_2026` est vide ; `ORIGINE_ABSENTS` est prêt pour la suite.

## Les schémas cliquables

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `olb-ig-domaines.svg` | une IgG nue, moitié droite estompée : VH, CH1, VL, CL, charnière, CH2, CH3 | `olb-zo-domaines`, 7 |
| `olb-ig-fragments.svg` | la même, bras droit estompé : Fab (le bras gauche), Fc (la tige), charnière | `olb-zo-fragments`, 3 |

Les deux moitiés d'une IgG sont symétriques : seule la gauche porte des zones,
comme un organe pair. Le paratope n'est pas une zone : il se confondrait avec le
Fab, ou avec VH et VL, qui le portent. Le ronéo 2026-27 nomme VH, les CH, VL, CL
et la charnière ; la numérotation CH1 à CH3 vient de la diapositive de la chaîne
lourde du Ronéosaure 2025-26 (p. 5), que l'explication cite.

**Une planche à légender** (`olb-pl-formes`), tirée de la diapositive des formes
(ronéo 2026-27 p. 9, où elle est rognée ; image entière du Ronéosaure 2025-26,
p. 7) par `planche_depuis_image.py` : 9 numéros et 4 intrus (IgM dimérique, IgG
pentamérique, CD79, IgE monomérique soluble). Inchangée le 11/10, sinon ses pages.

## Les figures

Toutes du côté de la correction. **Trois viennent du ronéo 2026-27**, entières et
au moins aussi nettes que celles de 2025-26 ; elles remplacent les fichiers du même
nom (comme dans `immuno_cmh`) :

| Fichier | Page 2026-27 | Ce qu'elle montre |
|---|---|---|
| `olb-reponse-b.png` | 3 | ontogenèse intramédullaire, puis guidée par l'antigène (redessinée par l'équipe du ronéo, nette ; réduite à 1400 px) |
| `olb-paratope-cdr.png` | 12 | CDR sur la chaîne linéarisée, « plus de 1.10⁹ à plus de 1.10¹² » |
| `olb-signaux-bcr.png` | 18 | quantité de signaux : mort, survie, révision du paratope |

**Les autres sont les mêmes diapositives, que le ronéo 2026-27 montre rognées ou
plus petites** : l'image entière du Ronéosaure 2025-26 est gardée (source
`src-cours-immuno-ontogenese-b`), et sa légende dit les deux pages.

| Fichier | Page 2026-27 | Page 2025-26 | Pourquoi l'image 2025-26 |
|---|---|---|---|
| `olb-bcr-plasmocyte.png` | 5 | 4 | 585 px contre 1400 |
| `olb-fab-fc.png` | 8 | 6 | rognée en bas (Fc, glycosylation) |
| `olb-ponts-disulfure.png` | 8 | 6 | rognée |
| `olb-formes-ig.png` | 9 | 7 | rognée (titres « Membrane », « Solubles ») ; la planche en dépend |
| `olb-rearrangement-vdj.png` | 13-14 | 12 | rognée (« Recombinaison Activating Gene », légendes du bas) |
| `olb-selections.png` | 17 | 15 | rognée (anergie, délétion clonale) |
| `olb-chaine-lourde.png` | — | 5 | absente du ronéo 2026-27 ; son texte p. 6 dit la même chose |
| `olb-chaine-legere.png` | — | 6 | absente du ronéo 2026-27 ; son texte p. 7 dit la même chose |

Et un schéma redessiné, `olb-cdr3.svg` (V, N, D, N, J, Cμ ; CDR1, CDR2, CDR3),
d'après la diapositive « Génération du paratope : séquence nucléotidique » (p. 17,
petite et floue dans le ronéo 2026-27) et son texte (p. 16). Non reprises : la
couverture, la diapositive « Just for Fun… » (p. 17) et celle des « mécanismes de
contrôle » (p. 16), que le texte p. 17 dit. Le seul QCM sans illustration est
`olb-qc-concentrations`.

## Le lexique

Huit termes, pages mesurées dans le texte du ronéo 2026-27 (le plan, p. 1, n'est
pas compté), en tête, puis celles de la FC n°4 2025-26 :

| Terme | Origine | Pages 2026-27 | Pages 2025-26 |
|---|---|---|---|
| Immunoglobuline | latin immunis + globulus | 2, 4, 6-13, 15, 16 | 1-14 |
| Paratope | grec para + topos (N. K. Jerne, 1960) | 7, 9-13, 15, 16, 19 | 6, 8, 10, 11, 13, 14, 16 |
| Isotype | grec isos + typos (J. Oudin) | 6, 7, 9, 10 | 5, 6, 8, 10 |
| Allotype | grec allos + typos (J. Oudin, 1956) | 9, 10 | 8 |
| Idiotype | grec idios + typos (J. Oudin, 1963) | 9-12 | 8, 9, 11 |
| Plasmocyte | grec plasma + kytos | 4, 6, 8, 9 | 3, 5, 7, 10 |
| Pentamère | grec pente + meros | 8 (« pentamériques ») | 7 |
| Hypervariable | grec hyper + latin variabilis | 11, 12 | 9, 11 |

Aucun terme nouveau le 11/10 ; aucun n'est accueilli par un autre chapitre de
l'UE ; épitope, affinité, avidité restent au chapitre des anticorps (FC10). Les
racines que la sémantique enseigne citent sa page : iso- (2/2, p. 5), idio- (1/2,
p. 5), allo- (1/2, p. 6), hyper- (2/2, p. 9), -mère (2/2, p. 10), cyt(o)- (1/2,
p. 8). Les étymologies des huit termes et de leurs racines sont dans
`etymologies.json` (`lex-immunoglobuline` à `lex-hypervariable`) ; aucune
proposition nouvelle le 11/10.

## À relire

**0 carte `a-relire`** : chaque note de cours cite sa page du ronéo 2026-27, chaque
annale sa session, son numéro et sa clé. Reste à faire :

- porter les neuf erreurs ci-dessus dans `contenu/ERRATA_RONEOS_2026-27.md` (fait le 11/10), et les trois de la suite du cours (19/10), sous le ronéo du 09/10 ;
- copier la fiche 2026-27 dans le dossier des PDF de l'application
  (`outils/copier_les_cours.py`, hors du bac à sable).

## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026)

Le pilote de l'immunité innée, étendu au reste de l'immunologie pour l'examen du 4/11 (choix de Vincent, 15/10). Sous les annales, 27 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 8 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `lb-elements-cles` | 0 | 1 | 1 |
| `structure-ig` | 10 | 2 | 5 |
| `formes-ig` | 4 | 1 | 3 |
| `isotypes-idiotypes` | 2 | 1 | 1 |
| `recombinaison-vdj` | 8 | 2 | 5 |
| `repertoire` | 3 | 1 | 2 |

**Le schéma** `ech-ontogenese-b`, « Le BCR · une structure, des formes, un répertoire contrôlé », donne 50 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_ONTOGENESE_B`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu les dix chapitres ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- olb-an-2122s2-q6 E et olb-an-2021s1-q6 E : l'avidité de l'IgM est enseignée au chapitre des anticorps (FC n°10), pas dans ce cours (docstring de donnees.py) : aucune marche.
- olb-an-1920s2-q1 E : la différence de paratope entre IgM et IgG tient à l'hypermutation du centre germinatif (FC n°6 et n°10) : aucune marche.
- olb-an-1516s1-q2 E : BAFF et APRIL relèvent du chapitre de la FC n°6 : aucune marche ; sa lettre est posée sur la case du contrôle (la survie des LB).
- olb-an-1617s2-q1 E : les antigènes thymo-indépendants relèvent de la FC n°6 : aucune marche ; lettre posée sur le contrôle (p. 19, sucres et protéines).
- olb-an-1920s1-q6 C : pas de Simple — l'appariement des légères se déduirait des cases de chaînes et des ponts disulfures ; préparée par olb-ech-m2 (D).
- olb-an-1819-q1 A, B, C : pas de Simple — la case du Fc (« surtout des domaines constants ») les donnerait ; préparées par olb-ech-m1 (A, B, C).
- olb-an-1819s1-q8 B et E : préparées par olb-ech-m5 (C, D), E avec son ATTENTION.

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```

La planche numérotée se refait, depuis `app/`, avec Pillow :
`uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/immuno_ontogenese_b olb-pl-formes --apercus <brouillon>`.

## Questions pour Vincent

- (11/10) Images : la plupart des figures du ronéo 2026-27 sont des captures rognées ou plus petites des mêmes diapositives (p. 5, 8, 9, 13-14, 17). Le chapitre garde l'image entière du Ronéosaure 2025-26, avec une légende qui cite les deux pages, et ne reprend que trois figures de 2026-27 (p. 3, 12, 18). Préfères-tu les images de l'année, même rognées ?
- (11/10) Sur la diapositive p. 12, sous 10⁹ et 10¹², deux petits mots sont trop flous pour être lus avec certitude (sans doute « individu » et « espèce »). Si tu as le diaporama du professeur, peux-tu vérifier ? Et à la p. 16, le diaporama dit-il bien « × 10 » pour la diversité jonctionnelle ? La carte olb-qc-diversites D le signale comme une erreur du cours.
- (11/10) olb-qc-plasmocyte E (« il sécrète ses anticorps de façon prolongée ») est remise comme dans ta bibliothèque, marquée « Absent du cours 2026-27 » dans sa justification, au lieu d'être remplacée : ta règle garde ce que seul l'ancien cours porte. Ça te convient ? — (19/10) Question close : la suite du cours (ronéo du 09/10/2026, p. 8) redit la sécrétion prolongée, et la mention est retirée.
