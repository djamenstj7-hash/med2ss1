# Spécificités sémiologiques chez l'enfant — paquet d'exemple

67 notes, 83 cartes (un texte à trous fait une carte par trou) : 34 QCM (11 du
cours, 23 d'annales), 17 recto-verso, 8 QROC, 5 textes à trous (21 trous) et 3
termes de lexique.

**La base du chapitre est le ronéo de l'année** : Ronéo & Juliette 2026-27,
« Spécificités sémiologiques de l'enfant », cours du **Dr Leruste** du
15/09/2026, 11 pages (source `src-fc-semio-enfant`, `SRC["fiche"]`). Le
chapitre avait d'abord été carté sur le Charonéo 2023-24 du Dr Aumar (7 pages,
`src-cours-enfant`) — même plan, autre enseignant ; un LISEZ_MOI précédent le
disait « arrivé le 17/09/2026 », c'était le ronéo de 2023-24. Il a été relu note
par note sur le ronéo 2026-27 le 25/09/2026 : **37 notes de cours, dont 9
nouvelles, citent la fiche 2026-27 à sa page** ; les 4 qui n'y figurent pas
gardent la source 2023-24 et sont listées plus bas, comme les propositions de
2023-24 gardées dans des cartes relues. S'y ajoute le polycopié d'annales,
dépouillé en entier.

Le ronéo 2026-27 ne définit pas de texte gris ; son rouge ne marque, hors des
titres, que les dépistages (p. 2) et « plus l'enfant est rassuré, plus les
parents le seront » (p. 3), tous deux cartés.

## Ce que le cours enseigne

Le cours tient sur une phrase : **l'enfant n'est pas un adulte miniature**,
c'est un être en développement — en croissance (volet quantitatif) et en
maturation (volet qualitatif). Il en tire quatre conséquences pratiques, et ce
sont les quatre familles de cartes.

**La consultation est triangulaire** — médecin, patient, parents. L'histoire est
une sémiologie rapportée par un tiers qu'il faut interpréter : on croit les
parents, sans les tenir pour objectifs. On ne s'approche pas trop vite trop
près, on appelle l'enfant par son prénom, on explique toujours ce que l'on fait,
et les examens instrumentaux viennent en dernier.

**Les classes d'âge commandent tout** : l'anamnèse, les signes, les constantes,
la conduite de l'examen, les diagnostics (la sténose du pylore, de la 3e à la 8e
semaine de vie) et les traitements.

**Le carnet de santé** est un outil de suivi qu'on remplit, pas une formalité :
obligatoire depuis 1945, trois certificats obligatoires, vingt examens pris en
charge à 100 %, trois parties de couleur, et le secret médical.

**L'examen du nourrisson a ses gestes propres** : le CRC en trente secondes, les
signes de lutte, la recoloration et le pli cutané au thorax, les pouls
fémoraux, la fontanelle, la gorge en dernier.

## Les repères chiffrés

Ce sont eux que les annales posent, et le chapitre les carte un par un.

| | |
|---|---|
| Nouveau-né | 0 à 28 jours |
| Nourrisson | 29 jours à 2 ans |
| Âge préscolaire | 2 à 5 ans |
| Âge scolaire | 6 à 10-11 ans |
| Adolescent | à partir de 12 ans |
| Pédiatrie, selon l'OMS | jusqu'à 18 ans |
| Tenue assise | avec aide à 6 mois, sans aide à 9 mois |
| Marche | acquise entre 9 et 18 mois |
| Fermeture de la fontanelle | en moyenne vers 9 mois, au plus tard à 24 mois : la formule du cours, à répondre à l'examen (la littérature donne un âge médian de 13,8 mois, voir les ATTENTION) |
| Temps de recoloration | au thorax, inférieur à 3 s |
| Score d'APGAR | à 1, 5 et 10 minutes, sur 10 |
| Certificats obligatoires | examen de maternité, 9 mois, 24 mois |
| Examens pris en charge à 100 % | 20 |

## Ce qui a changé avec le ronéo 2026-27

- **La fontanelle** : la « contradiction interne » que ce chapitre tranchait
  (« n'existe plus vers 6-7 mois » en page 1, « se ferme à partir de 9 mois et
  au max : 24 mois » en page 7) était celle du ronéo 2023-24. Le ronéo 2026-27
  n'en a plus, et elle y « se ferme en moyenne à 9 mois (maximum 24 mois) »
  (p. 11) : c'est le cours lui-même, la phrase du Ronéosaure 2024-25 (voir les
  ATTENTION ci-dessous).
- **Âge scolaire** : de 6 à 10-11 ans, l'adolescent à partir de 12 ans (p. 5) ;
  2023-24 disait « de 5 à 10/12 ans ». `enf-qc-ages` et `enf-fa-ages` réécrits.
- **Le sigle des critères de gravité** : CRC — Comportement, Respiration,
  Coloration (p. 7 et 11) ; 2023-24 écrivait CCR. Les trois mots ne changent
  pas ; `enf-fa-ccr`, `enf-qr-ccr` et `enf-qc-gravite` suivent le nouvel ordre,
  et la QROC accepte encore l'ancien.
- **Tenue assise sans aide** : 9 mois (p. 10) ; 2023-24 disait 7-9 mois.
  `enf-qr-assise` attend 9 mois (7-9 accepté) ; `enf-fa-psychomoteur` dit 9 mois.
- **Couleurs du carnet** : voir ATTENTION ci-dessous.
- **Examens du carnet** : même nombre (20), mais un autre calendrier (J8 et J14,
  tous les mois jusqu'à 6 mois, tous les 3 mois jusqu'à 12 mois, tous les 6 mois
  jusqu'à 2 ans, une fois par an jusqu'à 6 ans, puis 9, 12-13 et 16 ans), et le
  premier certificat s'appelle « examen de maternité ».
- **Le temps de recoloration** juge la perfusion périphérique (volet
  « cardiovasculaire et hydratation ») ; il doit être inférieur à 3 s.
- Les justifications et les explications citent désormais le ronéo 2026-27, à
  la page ; les citations propres à 2023-24 (« papapa », le doudou, « les
  mamans ont vraiment très souvent raison », le « point le plus défaillant »)
  en sont sorties. Aucune clé de question du cours n'a changé.
- **Examen déshabillé** : au-delà de 2 ans l'enfant peut garder ses
  sous-vêtements, mais on les retire à un moment de l'examen, en présence des
  parents (p. 9). La proposition B de `enf-qc-conditions` (« on déshabille
  également complètement ») est réécrite en « entièrement déshabillé dès le
  début de l'examen », et n'est plus marquée inacceptable — à confirmer.
- **Neuf notes nouvelles**, pour ce que 2023-24 ne disait pas : `enf-qr-femoraux`
  (pouls fémoraux, dépistage de la coarctation), `enf-rv-apgar` (1, 5 et 10 min),
  `enf-rv-lutte` (« BéBé Tire EN geignant »), `enf-rv-reconsultation` (consignes
  de surveillance), `enf-rv-depistages` (sensoriels, Guthrie), `enf-rv-secret`
  (secret médical, enveloppe fermée), `enf-rv-certificats` (examen de maternité,
  9 et 24 mois, PMI), `enf-rv-domaines` (les huit domaines du développement
  psychomoteur), `enf-qr-marche` (la marche acquise entre 9 et 18 mois,
  ajoutée à la relecture).

## Les ATTENTION du chapitre

Aucune clé d'annales n'est contredite par le ronéo 2026-27 : `CONFLITS` reste
vide. Mais huit cartes portent un ATTENTION, dans une justification ou une
explication, sur six points où une lecture se discute. Depuis le 28/09/2026,
chaque erreur du ronéo est triée (règle de Vincent : à l'examen, on répond
d'abord comme le professeur) : **le cours lui-même** — la carte répond comme
lui, et l'ATTENTION dit d'où vient la formule, « À l'examen : » et « La
référence : » —, ou **une prise de notes fausse** — la carte suit le cours et
la vérité, et l'ATTENTION dit l'erreur du ronéo.

| Carte | Ce qui se discute | Retenu |
|---|---|---|
| `enf-qc-carnet` D, `enf-rv-pictogrammes` | Couleurs du carnet : vert / bleu / rouge en 2023-24, vert / **violet** / **orange** en 2026-27 (p. 6) | le ronéo 2026-27 |
| `enf-an-2526-q21` A | Le ronéo écrit « on est avec l'enfant mais surtout avec les parents » (p. 2), ce qui peut faire cocher A ; mais sur qui rassurer, il pose en rouge « plus l'enfant est rassuré, plus les parents le seront » (p. 3) | clé officielle, A fausse |
| `enf-an-1819-q10` D | La marche « devrait être acquise entre 9 et 18 mois » (p. 11) : 9 mois est la borne basse, pas l'âge de la majorité | clé officielle, D fausse |
| `enf-an-1617-q14` E | Le ronéo cite 15 ans comme pratique de certains hôpitaux (p. 4), pas comme définition | clé officielle, E fausse (18 ans) |
| `enf-fa-fontanelle`, `enf-an-1920s1-q3` E (et l'explication de `enf-an-1819-q10`, qui le rappelle) | **C'est le cours lui-même** (tri du 28/09/2026) : la fontanelle « se ferme en moyenne à 9 mois (maximum 24 mois) » (ronéo 2026-27 du Dr Leruste, p. 11), la même phrase que le Ronéosaure 2024-25 du Dr Aumar (p. 14) ; le Charonéo 2023-24 disait « à partir de 9 mois ». La référence : âge médian de fermeture 13,8 mois ; 1 % sont fermées à 3 mois, 38 % à 12 mois, 96 % à 24 mois (Duc et Largo, *Pediatrics* 1986 ; *Am Fam Physician* 2003) | à l'examen, comme le cours : en moyenne vers 9 mois, au plus tard à 24 mois ; « vers 3 mois » faux, la clé officielle de l'annale (E fausse) ne change pas |
| `enf-rv-lutte` | **Prise de notes fausse** du ronéo 2026-27 (p. 9-10), qu'aucun tableau d'erreurs ne relève : le moyen mnémotechnique du cours, « BéBé Tire EN geignant », nomme le tirage et le geignement, mais la liste qui le suit oublie le tirage, finit sur « Gêne » et dit deux fois « quand il inspire » à propos du balancement ; aucune diapositive ni aucun cours antérieur ne donne une autre liste | les cinq signes du moyen mnémotechnique et du référentiel (CNPU, chap. 54) : battement des ailes du nez, balancement (à l'inspiration, le thorax se déprime et l'abdomen se soulève), tirage, entonnoir xiphoïdien, geignement expiratoire |

## Absent du cours 2026-27

Ces notes ne sont pas contredites par le ronéo 2026-27, mais ne s'y trouvent
pas ; elles gardent la source 2023-24 (`src-cours-enfant`), sans page. **Vincent
décide s'il les garde.**

| Note | Ce qui manque en 2026-27 |
|---|---|
| `enf-fa-psychomoteur` | la tenue de tête (3-4 mois), le passage d'une main à l'autre (5-8 mois) et la pince pouce-index (8-9 mois) : le ronéo cite ces gestes sans les dater. La tenue assise a été alignée sur 2026-27 (9 mois). Les annales 2018/2019 QCM 10 et 2020/2021 QCM 10 posent ces âges. |
| `enf-rv-gowers` | le nom « signe de Gowers » et la myopathie ; le ronéo garde le geste (passer de couché à debout sans aide, p. 11) |
| `enf-rv-imc` | la formule de l'IMC et l'absence de seuil fixe chez l'enfant ; le ronéo cite l'IMC parmi les mesures de chaque examen (p. 11) |
| `enf-rv-telephone` | tout le passage sur l'interrogatoire au téléphone |

**Propositions et détails de 2023-24 gardés dans des cartes relues** — la
carte cite le ronéo 2026-27, et la justification dit d'où vient l'élément :

| Note | Élément gardé, absent du ronéo 2026-27 |
|---|---|
| `enf-qc-relation` D | la comparaison avec une maladie qui toucherait les parents eux-mêmes (le ronéo 2026-27 dit seulement « très anxiogène ») |
| `enf-qc-approche` A | le tutoiement (le prénom, lui, est au cours) |
| `enf-qc-etiologies` A et E | les exemples de l'alcool contre la méningite, de la douleur abdominale à 3-4 mois contre 14 ans |
| `enf-qc-carnet` A et E | le conseil départemental qui imprime le carnet ; le « comportement » à noter, et nom, cachet, signature |
| `enf-qc-interrogatoire` A | l'âge de la mère (la durée de gestation est au cours) |
| `enf-qc-conditions` C | le brassard couvrant les deux tiers du bras (2026-27 : « adapté », trop étroit il surévalue) |
| `enf-qc-nourrisson` A et C | « sous la clavicule » ; le pli qui persiste après 2 à 3 secondes |
| `enf-fa-fontanelle` | « souple et fibreuse » (hors des trous) |
| `enf-fa-carnet` c2 et c3 | le conseil départemental, responsable jusqu'à 6 ans |
| `enf-qr-pli` | « sous la clavicule », encore accepté |
| `enf-rv-tireassis` | la prise par les épaules, le redressement de la tête à un mois |
| `enf-rv-courbe` | les deux exemples de courbes (dans les normes mais cassée, hors des normes mais régulière) |
| `enf-an-2021-q10` B et C, `enf-an-1819-q10` B et C | les âges de la pince pouce-index (8-9 mois) et du passage d'une main à l'autre (5-8 mois), dans les justifications |

Trois cartes d'annales portent toujours le thème **hors-fiche** — la mort
inattendue du nourrisson, et les valeurs moyennes du nouveau-né (3,3 kg, 50 cm,
35 cm de périmètre crânien) : ni le ronéo 2023-24 ni celui de 2026-27 n'en
parlent.

## Ce que les annales ajoutent

Les deux questions du sujet 2025/2026 reprennent, à un item retourné près, les
questions 18 et 19 de 2023/2024. Depuis le 15/10/2026, celles-ci ont leur
propre carte, `enf-an-2324-q18` (BCE) et `enf-an-2324-q19` (AE), faites sur le
sujet original et la clé de son **corrigé officiel** (source
`src-sujet-semio-2324`, `SRC["sessions"]["2023/2024"]`) : une carte par
session. Les deux clés de chaque paire sont justes et ne se contredisent pas —
c'est la proposition qui change, pas la réponse à une même proposition ; aucun
`CONFLITS` n'est donc déclaré, et la justification de l'item retourné le dit
sur les deux cartes 2023/2024. Ce retournement change la clé, et c'est tout ce
qu'elles enseignent :

- « la fréquence cardiaque est la **même** que celle d'un adolescent » ici,
  contre « est **différente** » là-bas, où l'item était vrai ;
- « il s'agit d'une relation **triangulaire** » ici, contre « une relation
  **duale** » là-bas, où l'item était faux.

Lire l'item, pas le souvenir de la clé.

## Les annales, en entier

Les **vingt-six questions** du polycopié sont cartées, en vingt-trois cartes : les
deux de 2023/2024, longtemps regroupées sous leurs reprises de 2025/2026, ont
leur carte depuis le 15/10/2026.
Ce polycopié est remarquablement répétitif, et c'est une information : le
**triangle d'évaluation pédiatrique** tombe quatre fois, le **carnet de santé**
quatre fois, la **fontanelle** deux fois, les **constantes du nouveau-né** deux
fois. Six questions sur vingt-six portent sur le carnet de santé — aucun sujet
n'est plus rentable.

## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026)

L'échelle du pilote de l'immunité innée, étendue au tissu sanguin et aux trois derniers chapitres de sémiologie pour l'examen du 4/11 (Vincent, 16/10 : « on continue pour les chapitres que je vais avoir à l'examen »). Sous les annales, 32 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 9 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `specificites` | 4 | 1 | 3 |
| `relation` | 5 | 2 | 3 |
| `ages` | 3 | 1 | 3 |
| `carnet` | 3 | 1 | 3 |
| `interrogatoire` | 3 | 1 | 3 |
| `examen` | 6 | 1 | 3 |
| `psychomoteur` | 3 | 1 | 2 |
| `hors-fiche` | 5 | 1 | 3 |

**Le schéma** `ech-enfant`, « L'enfant en consultation · relation, âges, carnet, examen », donne 65 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_ENFANT`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**ATTENTION posés** : « surtout les parents » (s8, m3) et l'âge de 15 ans (s11, m4) contre les clés officielles ; la fermeture de la fontanelle à 9 mois, le cours lui-même (s22, liste des errata) ; assis à 9 mois (s25) et la marche (s27, m8).

**Illustrations.** Avec l'échelle, 41 des 75 QCM sont illustrés (55 %) : la section « Sans illustration » est retirée. Les annales restent rangées dans `donnees.py`, que le modèle lit.

**Sans marche** :
- enf-an-1617s2-q5 C : l'identification du professionnel (nom, cachet, signature) vient du cours 2023-24 ; le ronéo 2026-27 dit seulement d'y inscrire ses observations (p. 5), trop mince pour une marche.
- enf-an-2021-q10 E : le poids à un an (10 kg) n'est dans aucune source du chapitre, seulement dans la justification de l'annale ; un chiffre isolé.
- enf-an-2223s2-q7 C : l'analyse de la croissance comme cause d'erreur devant une fièvre, que le cours n'aborde pas.
- E « Autre » de enf-an-2223-q9, enf-an-2223-q10 et enf-an-2223s2-q7 : proposition sans contenu, ni marche ni lettre posée.

## Régénérer

```
python generer.py
```

Le script valide avant d'écrire : une justification manquante, un trou de plus de
deux mots, un thème inconnu, une page hors de la fiche — et il refuse d'écrire.
