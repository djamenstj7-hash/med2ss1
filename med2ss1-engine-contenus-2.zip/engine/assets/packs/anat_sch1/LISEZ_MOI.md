# Membre inférieur (Schémas n°1) — paquet Anatomie

49 notes, 49 cartes. Chapitre `chap-ue-anatomie-sch1` de l'UE Anatomie
(identifiant, nom et ordre du squelette), bâti en même temps que les chapitres
de la FC n°1, de la FC n°2 et des Schémas n°2 du membre inférieur, sur un plan
commun qui partage le cours entre eux. Les planches des années passées sont du
Pr Demondion ; le premier CM 2026-27 du membre inférieur est du **Pr
Herteleer (06/10/2026)**. Examen de novembre (aucune date connue, donc pas
d'`EXAMENS`).

**Les sources, depuis le réalignement du 19/10/2026** : le Book Schéma 2025-26
fait foi pour les schémas d'examen (Vincent, 07/10), complété par le bloc
Schémas n°1 2024-25 ; **le ronéo 2026-27 du CM du 06/10** (« TOPOGRAPHIE DU
MEMBRE INF 1 », 12 p.) apporte cinq planches nouvelles sur ses figures, fait
relire les deux planches tirées des photos du cours, et ses pages sont citées
par les planches du Book qui dessinent les mêmes régions (voir « Le ronéo
2026-27 »). Ses erreurs portent un `ATTENTION` à genre ; celles du Ronéosaure
et des clés d'annales, un `ATTENTION` simple.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| Planche à légender (`legend`) | 27 | 27 |
| QRM | 4 | 4 |
| QROC | 1 | 1 |
| Recto-verso | 17 | 17 |
| **Total** | **49** | **49** |

- **5 planches du ronéo 2026-27** (`anat-pl-2627-…`, 83 numéros, 32 intrus) :
  la surface glutéale et les nerfs cluniaux (p. 2), la vue postérieure des
  muscles fessiers (p. 3), les vues antérieure et postérieure de l'articulation
  coxo-fémorale (p. 7), la coupe transversale de la hanche (p. 8), la région
  lombaire et inguino-pelvienne (p. 10).
- **2 planches des photos du cours du 06/10** (C17), relues sur le ronéo.

- **16 planches du bloc**, une par page (Schémas n°1 p. 1 à 16) : 278 numéros,
  dont 30 flèches de repère (Haut, Droite, Gauche, Avant) ; la p. 7, le plexus,
  n'a pas de repère. Les pages 2 à 12, 14 et 16 citent désormais le Book
  Schéma 2025-26, dont la correction est le même dessin et les mêmes
  légendes ; la planche de la p. 15 est devenue celle du schéma n° 14, refaite
  sur l'image du Book, qui ajoute une veine du gastrocnémien (23 numéros au
  lieu de 22). Seules les p. 1 et 13 restent au bloc 2024-25 : voir la table
  du Book plus bas.
- **1 planche du Book 2025-26** (`anat-pl-b1-zone-trigone`, schéma n° 1,
  p. 29), un dessin nouveau : la zone du trigone ouverte, la graisse, la crosse
  de la grande veine saphène et les trois groupes de lymphonœuds, 10 numéros
  dont « Droite ». Ses légendes sont des pixels : planche faite par
  `planche_depuis_image.py`, rectangles dans `donnees.py`, aperçu relu.
- **15 schémas à refaire sur papier** (tag `redessiner`) : le n° 4 (pilote du
  07/10), le lot 1 du 14/10 (n° 1, 2, 3, 5, 6), le lot 2 du même jour (n° 8
  à 12, avec la planche sans numéro de la p. 41) et le lot 3 du 18/10 (n° 13
  à 15 ; les n° 16 à 18 sont dans le chapitre des Schémas n°2, avec leurs
  planches). Le fond vide du Book en
  question, la correction en réponse, et l'on se note soi-même (su, difficile,
  raté) selon le barème écrit dans l'explication.
- **3 planches d'annales** (les dessins des trois sujets), 14 numéros.
- **6 notes d'annales** sur 3 sessions (2021/2022 S2, 2022/2023 S2, 2024/2025
  S1) : 4 QRM et les titres de 2021/2022 et 2024/2025 en recto-verso, plus les
  3 planches ; 3 conflits déclarés.
- **4 QCM sur 4 illustrés** : le dessin d'examen en question, la planche légendée
  du cours en correction.
- 116 intrus en tout (au moins quatre par planche) ; pas de lexique.

Neuf thèmes, aux libellés partagés par les quatre chapitres du membre inférieur.
Ils ne sont pas encore dans `THEME_LABELS` (`app/src/med_engine/application/scopes.py`) :
`test_tout_theme_du_paquet_a_son_libelle` échoue sur ce chapitre jusqu'à ce qu'ils
y soient.

| Clé | Libellé | Planches |
|---|---|---|
| `trigone-femoral` | Trigone fémoral, lymphonœuds et grande saphène | p. 1 |
| `vaisseaux-mi` | Artères et veines du membre inférieur | p. 2, 5, 6 |
| `osteologie-mi` | Ostéologie du membre inférieur | p. 3, 9 |
| `muscles-cuisse` | Muscles de la cuisse | p. 4 |
| `nerfs-mi` | Nerfs du membre inférieur | p. 7, 8, 11 |
| `region-gluteale` | Région glutéale | p. 10, 12 ; annale 2022/2023 S2 |
| `hanche` | Articulation coxo-fémorale | p. 13 |
| `fosse-poplitee` | Fosse poplitée | p. 14, 15, 16 ; annales 2021/2022 S2 et 2024/2025 S1 |
| `orientation-schemas` | Titre et orientation des schémas | la QROC du cours ; les titres de 2021/2022 S2 et 2024/2025 S1 |
| `region-lombo-pelvienne` | **Région lombaire et inguino-pelvienne** (nouveau, partagé avec la FC n°1 ; à ajouter à `THEME_LABELS`) | la planche du ronéo 2026-27 p. 10 |

## Les sources

| Source | Rôle |
|---|---|
| `src-fc-anat-fc1-2627` — Ronéo & Juliette 2026-27, « TOPOGRAPHIE DU MEMBRE INF 1 » (12 p., CM du 06/10/2026, Pr Herteleer) | déclaré à l'identique du chapitre FC n°1, dont il est la fiche (`chapitre="chap-ue-anatomie-fc1"`) : les sept planches de ses figures et des photos du cours le citent (`fiche=R`, sans badge d'année passée) ; chemin `ANATOMIE/TOPOGRAPHIE DU MEMBRE INF 1.pdf` |
| `src-ue-anatomie-sch1` — Ronéosaure 2024-25, « Schémas n°1 (AC) - Membre inférieur » (16 p.) | la fiche du chapitre (`chapitre=`), provisoire en attendant le ronéo 2026-27 ; chaque planche cite sa page. Chemin : `Anatomie/Schémas n°1 (AC) - Membre inférieur.pdf` dans le dossier des PDF de l'application |
| `src-annales-anatomie-inf` — Ronéosaure, « Anatomie du membre INF » (5 p.) | les deux sujets et leurs corrections non officielles (p. 4-5) |
| `src-sujet-anat-2425` — sujet d'anatomie 2024/2025, partie 1, session 1 (examen du 12/11/2024, 6 p.), déposé le 15/10/2026 | le schéma de la fosse poplitée (p. 4), **sans corrigé** ; `SRC["sessions"]["2024/2025 S1"]` |
| FC n°1 (AC) du Ronéosaure 2024-25 | le texte qui explique chaque numéro, cité dans les phrases (« FC n°1 p. … ») ; déclarée par le chapitre de la FC n°1, pas ici, pour ne pas écraser sa fiche à l'import |
| cours 2023-24 n°1 (Charonéo) | appoint, cité quand il tranche (drainage des lymphonœuds, VCI à droite de l'aorte, perforantes, droit fémoral latéral au sartorius) |
| Erratas Anatomie ; Erratas Annales Anatomie (2024-25) | la liste des corrections que le bloc intègre déjà, et l'inversion 3/4 de 2022/2023 S2 |
| `src-book-schema-mi-2526` — Ronéosaure 2025-26, « Book Schéma - Membre inférieur » (53 p.) | **fait foi depuis le 07/10/2026** (Vincent : les planches les plus récentes, complétées par 2024-25 quand il manque de la précision) : 25 schémas, fonds vides p. 4-27, corrections p. 29-53. Chemin : `ANATOMIE/Book Schéma - Membre inférieur.pdf` |

Le Book Schéma 2024-25 n'est pas cité : ses pages de correction sont, à
l'octet près, les images des Schémas n°1 et n°2. Celui de 2025-26 l'est, schéma
par schéma, à mesure que ses schémas entrent dans le chapitre (au 18/10, les
n° 1 à 15, sauf le n° 7, que le Book ne corrige pas ; les n° 16 à 25 sont les
dessins des Schémas n°2 et vont au chapitre `anat_sch2`, qui déclare la même
source à l'identique). Aucun nom d'étudiant
(en-têtes, secrétaires des annales, première colonne des errata) n'est repris ;
seul le Pr Demondion est nommé.

### Le Book Schéma 2025-26, schéma par schéma

L'index (p. 1) numérote les schémas par leur titre ; les corrections ne
suivent pas tout à fait cet ordre, et les fonds non plus : chaque fond a été
choisi sur le dessin. Les fonds « fémur seul » (p. 6, 8 et 11) sont presque
identiques.

| Schéma | Correction | Fond | Dans le chapitre |
|---|---|---|---|
| n° 1, zone du trigone fémoral | p. 29 (image, dessin nouveau) | p. 4 | `anat-pl-b1-zone-trigone`, `anat-rd-zone-trigone` |
| n° 2, réseau veineux superficiel | p. 30 | p. 5 | `anat-pl-reseau-veineux`, `anat-rd-reseau-veineux` |
| n° 3, ostéologie, vue antérieure | p. 31 | p. 6 | `anat-pl-osteologie-anterieure`, `anat-rd-osteologie-anterieure` |
| n° 4, trigone fémoral et cuisse | p. 32 | p. 8 | `anat-pl-muscles-cuisse`, `anat-rd-muscles-cuisse` |
| n° 5, vascularisation du trigone | p. 34 | p. 11 | `anat-pl-vaisseaux-trigone`, `anat-rd-vaisseaux-trigone` |
| n° 6, vascularisation de la cuisse | p. 33 | p. 7 | `anat-pl-vascularisation-cuisse`, `anat-rd-vascularisation-cuisse` |
| n° 7, vascularisation | p. 37, copie exacte de la p. 34 | — | rien : le Book n'a pas de correction propre |
| n° 8, plexus lombo-sacré | p. 35 | p. 9 | `anat-pl-plexus-lombo-sacre`, `anat-rd-plexus-lombo-sacre` |
| n° 9, nerf fémoral et nerf obturateur | p. 36 | p. 10 | `anat-pl-nerfs-femoral-obturateur`, `anat-rd-nerfs-femoral-obturateur` |
| n° 10, ostéologie, vue postérieure | p. 38 | p. 12 | `anat-pl-osteologie-posterieure`, `anat-rd-osteologie-posterieure` |
| n° 11, région glutéale et cuisse (muscles) | p. 39 | p. 13 | `anat-pl-gluteale-muscles`, `anat-rd-gluteale-muscles` |
| sans numéro, au titre du n° 11 (vaisseaux et nerfs) | p. 41 | p. 15 | `anat-pl-gluteale-vaisseaux-nerfs`, `anat-rd-gluteale-vaisseaux-nerfs` |
| n° 12, nerf ischiatique | p. 40 | p. 14 | `anat-pl-nerf-ischiatique`, `anat-rd-nerf-ischiatique` |
| n° 13, plan superficiel de la fosse poplitée | p. 42 | p. 16 | `anat-pl-poplite-superficiel`, `anat-rd-poplite-superficiel` |
| n° 14, plan profond de la fosse poplitée | p. 43 (image : le dessin de la p. 15 et une veine du gastrocnémien) | p. 17 | `anat-pl-poplite-profond` (refaite sur l'image), `anat-rd-poplite-profond` |
| n° 15, région postérieure du genou | p. 44 | p. 18 | `anat-pl-genou-posterieur`, `anat-rd-genou-posterieur` |
| n° 16 à 18 (vascularisation du genou, coupe) | p. 45 à 47 | p. 19 à 21 | chapitre `anat_sch2` |

**La p. 37 est une copie exacte de la p. 34** (même texte, même image au
pixel près) : le Book n'a donc pas de correction propre pour le schéma n° 7,
« vue antérieure de la vascularisation ». À voir au lot suivant.

Relecture du lot 1 par un sceptique (14/10) : les numéros, les rectangles et
les comptes des versos tiennent. Corrigé sur sa remarque :
- la question de la planche n° 1, qui ne numérote que « Droite » ;
- la grande veine saphène, qui monte sur la face MÉDIALE de la cuisse (la
  ronéo 2025-26 écrit « antérieure ») ;
- le fascia cribriforme, qui ferme le hiatus saphène du fascia lata (la ronéo
  2025-26 parle d'un « hiatus fibreux du fascia criblé ») ;
- des citations qui attribuaient au cours ce que la page ne dit pas.

**Point douteux, laissé ouvert** : sur le schéma n° 5 (p. 34, le même dessin
que la FC n°1), le trait « artère circonflexe médiale » vise une branche qui
part en dehors, l'allure de la circonflexe latérale. Une demande d'errata
2025-26 le relevait, sans réponse. À l'examen : la légende imprimée.

Relecture du lot 2 par un sceptique (14/10) : les fonds, les numéros de
schéma et l'identité des six dessins avec 2024-25 tiennent. Corrigé sur sa
remarque :
- le pectiné, que le schéma et le cours donnent au nerf obturateur (la
  référence dit surtout fémoral : ATTENTION) ;
- le plexus, dont le fond est un tracé sans légende : on légende ;
- l'ostéologie postérieure, dont le fond ne dessine pas le sacrum ;
- le chef court du biceps, né de la ligne âpre ;
- la p. 41, que le Book ne numérote pas ;
- les ATTENTION du pudendal (S2-S3 sur le schéma) et des épines « postéro- »
  de la correction, portés aussi sur les cartes à refaire ;
- les années des citations.

Relecture du lot 3 par un sceptique (18/10) : chaque légende des six
planches au bout du bon trait, chaque rectangle des deux planches sur image
sur la bonne légende, les fonds, les corrections et les comptes des versos
tiennent. Corrigé sur sa remarque :
- le nerf qui accompagne la grande veine saphène (n° 13) : la figure de la
  FC n°1 2025-26 (p. 14) porte la légende du Book, son texte dit « nerf
  saphène », et la référence penche pour le nerf saphène — un point douteux,
  dit comme tel ;
- les pages trop larges pour ce qu'elles portent (rameaux cutanés, tendon
  direct du semi-membraneux) ;
- le tendon du plantaire, qui descend entre le soléaire et les gastrocnémiens
  (la FC n°1 2025-26 dit « dans l'interstice des muscles gastrocnémiens ») ;
- la veine du gastrocnémien, que le Book ne dit pas « du chef latéral » ;
- l'origine du dessin du n° 14 (les Schémas n°1 2024-25, dont le sujet
  2021/2022 S2 reprend les muscles).

Vérifications hors du cours, citées dans la carte qui s'en sert : Gray's
Anatomy (nerf de l'obturateur interne, L5-S2, issu du plexus sacré ; pectiné
innervé surtout par le nerf fémoral ; nerf pudendal S2-S4 ; nerf saphène
satellite de la grande veine saphène à la jambe ; artère descendante du genou
née de la fémorale avant le hiatus ; sacrum fait des cinq vertèbres sacrées ;
vues de dos, les épines iliaques du bord latéral sont les épines antérieures —
Gray's et Kenhub).

## Comment les planches sont faites

`scripts/planche_depuis_pdf.py` du skill, page par page, avec `--effacer` pour
les mots du repère (ils deviennent des numéros) ; `--cote 1:bas` (p. 9, 11, 13)
et `--cote 3:droite` (p. 13, où le trait du repère attirait le numéro du nerf
cutané latéral de la cuisse). Chaque aperçu de contrôle a été relu : toutes les
légendes retirées, chaque numéro au départ de son trait, aucun texte lisible
hors du titre, du repère numéroté et des repères L1…S3, « PLEXUS LOMBAL /
SACRÉ », L2-L4 (p. 8) et le bandeau « NON PRÉSENT SUR LE SCHÉMA PRÉSENTÉ EN
COURS » (p. 6).

Trois retouches se font sur une copie de la page avant le script, parce que le
script ne sait pas retirer une ligne sans lui donner de numéro :

- p. 6 : « Artère iliaque externe droite » n'a pas de trait ; retirée de la
  question, elle reste sur la planche légendée, sans numéro ;
- p. 7 : la ligne rouge « L4 – L5 = TRONC LOMBO-SACRE », qui n'est pas une
  légende ;
- p. 14 : « Veine communicante » et les deux lignes « (avant sa réunion avec le
  rameau / communicant) ou nerf sural » ; le script coupait ces deux légendes en
  cinq morceaux, le numéro est posé sur la partie qui porte le trait.

Les images sont dans `media/` et se versionnent ; les refaire, c'est rejouer
le script du skill avec ces options, après ces trois retouches.

Les deux corrections du Book qui sont des images (n° 1 et n° 14) se font
autrement : la page est rendue à 130 dpi (`mi-01-correction.png`,
`mi-14-correction.png`), chaque numéro de la planche dit dans `donnees.py` le
rectangle à blanchir et où s'imprime son numéro, et
`scripts/planche_depuis_image.py` écrit l'image numérotée. Les deux aperçus de
contrôle ont été relus : chaque rectangle sur sa légende, aucune lettre
lisible, chaque numéro au départ de son trait. Le n° 14 remplace la planche
numérotée de la p. 15, retirée de `media/` ; sa planche légendée 2024-25
(`sch1-poplite-profond-legendee.png`) reste, parce qu'elle est la correction
des deux annales qui portent ce dessin. Les dessins
d'annales sont les images du polycopié, recadrées sans la grille de réponse,
avec des numéros ajoutés (police Arial gras) sur les flèches qui n'en portent
pas. Celui de 2024/2025 S1 (`an-2425s1-poplite.png`) est l'image du sujet
lui-même, extraite telle quelle de sa p. 4 (740 × 685 pixels), numérotée de la
même façon.

La liste d'une planche écrit les légendes proprement : sans les racines du
plexus (p. 7 : elles sont dans les phrases), « Os coxal » pour « Ox coxal »,
« Nerf ilio-hypogastrique » pour « hypograstrique », « Tendon réfléchi » pour
« réfléchis », « Artères pudendales externes », « Ligament de la tête
fémorale », et, p. 9, « Épine iliaque antéro-supérieure » et
« antéro-inférieure » là où le bloc écrit « postéro- » (voir plus bas).
Une légende répétée (moyen et grand glutéal p. 10, bourse synoviale p. 13,
rameaux cutanés p. 14, nerfs ischiatique, tibial et fibulaire commun
p. 11) garde un numéro par occurrence et s'écrit à l'identique. Les intrus sont
du même champ et jamais une légende de la planche ; ils comprennent toujours les
deux directions opposées du repère (Bas, et Gauche ou Droite, ou Arrière).

## Ce que les annales ont dicté

L'examen de novembre est un schéma, et seulement un schéma (errata du cours :
« notre examen est uniquement un schéma ») : orienter, nommer deux à quatre
structures fléchées, parfois donner le titre, puis compléter le dessin. D'où les
flèches du repère numérotées sur chaque planche, et la QROC « un titre et une
orientation » (FC n°1 p. 2).

Les deux sujets du polycopié « Anatomie du membre INF » sont ici ; celui de
2022/2023 Session 1 du polycopié « INF et SUP » (coupe du genou) est carté par
le chapitre des Schémas n°2.

| Sujet | Dessin | Cartes |
|---|---|---|
| 2022/2023 S2 | région glutéale droite, vue postérieure, grand glutéal réséqué ; flèches 1-4 | la planche (1-4, repère 5-6) ; QRM « Structures 1 à 4 » (porte le conflit) ; QRM « Compléter : structures nerveuses » |
| 2021/2022 S2 | genou droit, vue postérieure, muscles du losange poplité ; 2 flèches | la planche (flèches 1-2, repère 3-4) ; recto-verso « Titre » ; QRM « Compléter : structures vasculaires et nerveuses » |
| 2024/2025 S1 (examen du 12/11/2024) | **le même dessin que 2021/2022 S2**, mêmes deux flèches, mêmes consignes (la dernière phrase reformulée : « puis Identifier chaque structure ajoutée par une flèche et son nom ») | `anat-an-2425s1-planche` (flèches 1-2, repère 3-4) ; recto-verso `anat-an-2425s1-titre` ; QRM `anat-an-2425s1-completer`, aux propositions neuves |

Les QRM sont transposées : l'énoncé cite la consigne imprimée mot pour mot, les
propositions sont écrites d'après le cours. Les dessins d'examen sont ceux du
professeur, recadrés sans la grille « 1 : … 4 : ».

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée (correction non officielle) | Retenu | Pourquoi |
|---|---|---|---|
| 2022/2023 S2, structures 3 et 4 (`anat-an-2223s2-noms`, `anat-an-2223s2-planche`) | 3 piriforme, 4 obturateur interne | **3 obturateur interne, 4 piriforme** ; `officielle=False`, `CONFLITS` sur C, D, E | 4 est la bande née du sacrum, au-dessus de laquelle la correction elle-même fait passer le nerf glutéal supérieur et sous laquelle elle fait sortir le nerf ischiatique ; 3 est le corps ovale au-dessous. Planche du cours p. 10 et 12, FC n°1 p. 10-14 ; l'errata des annales propose la même correction (sans avis du bureau). La correction illustrée est recadrée sans sa liste fausse |
| 2022/2023 S2, compléter (`anat-an-2223s2-nerfs`) | trois nerfs : glutéal supérieur, cutané postérieur de la cuisse, ischiatique | clé déduite du cours : s'y ajoutent les nerfs glutéaux inférieurs et le nerf pudendal | FC n°1 p. 14 ; Schémas n°1 p. 12 |
| 2021/2022 S2, compléter (`anat-an-2122s2-completer`) | nerfs ischiatique, tibial, fibulaire commun, cutané sural « median », rameau communicant ; petite veine saphène et sa crosse ; une veine non nommée | clé déduite du cours : la veine poplitée nommée, l'**artère poplitée** (la plus profonde, NiVeA), les lymphonœuds | FC n°1 p. 19 ; Schémas n°1 p. 15 |
| 2021/2022 S2, titre (`anat-an-2122s2-titre`) | « Vue postérieure du plan profond de la région poplitée » | le titre de la planche du cours, « … de la fosse poplitée (après dissection) » — la même chose | Schémas n°1 p. 15 |
| 2024/2025 S1, flèches et orientation (`anat-an-2425s1-planche`) | aucune (sujet sans corrigé) | 1 muscle semi-membraneux, 2 muscle biceps fémoral ; Haut, Gauche (genou droit, vue postérieure) | clé déduite du cours : la planche p. 15 et la correction de 2021/2022 S2, même dessin |
| 2024/2025 S1, titre (`anat-an-2425s1-titre`) | aucune (sujet sans corrigé) | « Vue postérieure du plan profond de la fosse poplitée (après dissection) » | clé déduite du cours : Schémas n°1 p. 15 ; Book Schéma 2025-26, schéma n° 14 |
| 2024/2025 S1, compléter (`anat-an-2425s1-completer`) | aucune (sujet sans corrigé) | ACE : NiVeA, crosse de la petite saphène dans la veine poplitée, lymphonœuds ; faux : le fibulaire commun le long du muscle 1 (il longe le biceps, muscle 2), le cutané sural médial branche du fibulaire commun (il vient du tibial) | clé déduite du cours : FC n°1 p. 18-19 ; Schémas n°1 p. 15 |

Les deux flèches de 2021/2022 S2 (semi-membraneux, biceps fémoral) sont reprises
telles quelles : relues sur l'image, elles concordent avec la planche p. 15.

## Les points du bloc signalés dans les cartes

Aucun n'est une erreur de ronéo 2026-27 : ils ne vont pas dans
`contenu/ERRATA_RONEOS_2026-27.md`, et leur `ATTENTION` est sans genre.

| Planche, numéro | Ce que dit le bloc | Ce qui est juste | Traitement |
|---|---|---|---|
| p. 9, n°4 et 9 | « Épine iliaque postéro-supérieure » et « postéro-inférieure », sur le bord latéral de l'os coxal (la figure de la FC n°1 p. 9 aussi) ; une demande d'errata proposait « antéro-inférieure », rejetée par le bureau (« nous sommes sur une vue postérieure ») | vu de dos, l'extrémité latérale de la crête iliaque et l'épine qui surplombe l'acétabulum sont les épines ANTÉRIEURES, vues de profil ; les postérieures sont médiales, contre le sacrum, au-dessus de la grande incisure ischiatique (Gray's Anatomy ; Kenhub) | liste : **épines antéro-supérieure et antéro-inférieure**, `ATTENTION` dans les deux phrases et l'explication ; les deux épines « postéro- » deviennent des intrus |
| p. 8, n°7 | « Rameau du muscle obturateur interne », né du nerf obturateur | le nerf obturateur innerve l'obturateur externe (FC n°1 p. 9) ; l'obturateur interne a son nerf, issu du plexus sacré L5-S2 (Gray's) ; **tranché par le ronéo 2026-27** : tous les pelvi-trochantériens dépendent du plexus sacré, sauf l'obturateur externe (p. 5) | légende gardée (le Book la porte), `ATTENTION` dans la phrase : elle est fausse |
| p. 8, n°9 | rameau du pectiné sur le nerf obturateur (FC n°1 p. 9 : branche postérieure) | pectiné surtout fémoral, obturateur inconstant (Gray's) | `ATTENTION` ; à l'examen, le schéma du cours |
| p. 7, n°9 | nerf pudendal S2-S3 | S2-S4 : **le ronéo 2026-27** (p. 6), comme Gray's | `ATTENTION` ; on retient S2-S4 ; la liste ne porte pas les racines |
| p. 14 (schéma n° 13), n°6 | la grande veine saphène accompagnée d'un rameau du nerf cutané postérieur de la cuisse, « et non par le nerf saphène » ; la correction du Book 2025-26 (p. 42) et la figure de la FC n°1 2025-26 (p. 14) gardent cette légende | point douteux : le texte de la FC n°1 2025-26 (p. 14), le cours 2023-24 et la figure de la FC n°1 2024-25 p. 18 disent « nerf saphène », et la référence (Gray's) met le nerf saphène avec la grande veine saphène à la jambe | `ATTENTION — point douteux`, porté aussi sur la carte à refaire ; à l'examen, la légende du schéma ; cas ouvert : « Nerf saphène » n'est pas offert dans la liste (ni légende ni intrus), pour ne pas compter faux la réponse de la référence |
| p. 5, n°6 | « Artère circonflexe iliaque médiale » dans la figure de la FC n°1 p. 5 | artère circonflexe médiale (erreur reconnue par le professeur ; le bloc est corrigé) | dit dans la phrase du n°6 de la p. 5 ; « Artère circonflexe iliaque médiale » est un intrus des p. 5 et 6 |

Les autres entrées de l'errata du cours sont déjà appliquées dans le bloc et
dites dans la phrase du numéro concerné (lymphonœuds supéro-médiaux, condyles,
tendon du semi-tendineux, biceps sur la fibula, tendon patellaire, épigastrique
superficielle collatérale de la fémorale, circonflexe iliaque superficielle
dans la crosse ou dans la veine fémorale, rameau du grand adducteur, cadre du
trigone, nerfs glutéaux inférieurs écrits une fois). Une seule entrée rejetée par
le bureau n'est pas suivie : l'épine « postéro-inférieure » de la p. 9 (ci-dessus).

## Le lexique

Aucun terme : les chapitres de schémas n'en accueillent pas (plan commun du
membre inférieur). Les termes du membre inférieur (trochanter, sartorius,
pectiné, glutéal, piriforme, ischiatique, saphène, poplité, sural,
gastrocnémien…) sont accueillis par les chapitres des FC n°1 et n°2.

## À relire

0 carte `a-relire` : chaque numéro a été relu sur l'aperçu de contrôle et sur la
planche légendée, chaque phrase sur la page du ronéo 2026-27 ou de la FC n°1
2024-25 qu'elle cite.

## Le cours du 06/10/2026 (C17)

Deux dessins du **Pr Herteleer** (l'en-tête du ronéo du 06/10 le nomme ; le
LISEZ_MOI du 18/10 disait, faute de ronéo, « Pr Demondion ») que le Book n'a
pas, en planches à légender sur les photos de la vidéo du cours (Lille.Pod) que
Vincent a prises sur son écran le 06/10 (11 photos, hors dépôt). Vincent a
accepté le 18/10 qu'elles partent avec le chapitre.

| Planche | Photo | Numéros | Intrus | Fiche depuis le 19/10 |
|---|---|---|---|---|
| `anat-pl-cours-coupe-hanche`, coupe horizontale de la hanche, redessinée cette année | 11 h 56 | 11 | 6 | ronéo 2026-27 p. 8 (texte p. 9) |
| `anat-pl-cours-plexus-lombal`, plexus lombal sur la paroi postérieure de l'abdomen | 12 h 08 | 7 | 6 | ronéo 2026-27 p. 10 (texte p. 11) |

Les photos sont recadrées sur le tableau, et l'interface du lecteur est
masquée de la couleur du tableau. Les sigles à la craie (« TFL », « OE »,
« NCLC »…) sont effacés en `fond="degrade"` : un fondu entre les bords haut et
bas de chaque rectangle, que `planche_depuis_image.py` a appris pour les
photos, où un remplissage uni laissait des stries. Chaque phrase dit le sigle
du professeur ; « OE », l'obturateur externe, se lit « OF » sur la photo.

**Relues le 19/10 sur le ronéo du 06/10** : chaque légende est juste, chaque
phrase cite désormais la page du ronéo (et non plus le bloc 2024-25 ou Gray's
seul), et le badge « Cours 2024-25 » tombe. Une légende change de mot sans
changer de structure : « Nerf sous-costal » devient « Nerf subcostal », le nom
du ronéo (p. 11) ; la phrase garde « sous-costal ». La phrase du pectiné porte
l'`ATTENTION (prise de notes)` du ronéo (p. 9).

La troisième région du cours, **l'articulation coxo-fémorale**, que la photo
coupait, a maintenant sa planche, sur la figure du ronéo (p. 7) :
`anat-pl-2627-hanche-vues`. Aucune carte « à refaire sur papier » pour ces
dessins : ils n'ont pas de fond vide.

## Le ronéo 2026-27 (réalignement du 19/10/2026)

« TOPOGRAPHIE DU MEMBRE INF 1 » (Ronéo & Juliette, CM du 06/10/2026, 11 h-12 h,
Pr Herteleer, 12 p.) est la fiche du chapitre FC n°1, qui le carte ; ce
chapitre le déclare à l'identique (`R`, `chapitre="chap-ue-anatomie-fc1"`) pour
que ses planches le citent. `CHAPITRE["semaine"]` devient « 06/10/2026 · Pr
Herteleer ».

### Cinq planches sur ses figures

Ses figures sont les dessins du tableau, redessinés en couleur et légendés par
l'équipe du ronéo : des images, faites en planches par
`planche_depuis_image.py` (rectangles dans `donnees.py`, `fond="auto"`, les
rectangles élargis jusqu'aux halos clairs des légendes). Les titres restent ;
les mots des repères sont numérotés. Chaque aperçu de contrôle a été relu :
aucune lettre restante, aucune flèche entamée, chaque numéro au départ de son
trait. Les figures d'atlas du même ronéo (Netter et un site d'échographie p. 3,
IMAIOS p. 12) ne sont pas employées.

| Planche | Page | Numéros | Intrus | Ce qu'elle apprend |
|---|---|---|---|---|
| `anat-pl-2627-surface-gluteale` | 2 | 10 | 6 | repères de surface, nerfs cluniaux, nerf cutané postérieur de la cuisse |
| `anat-pl-2627-muscles-fessiers` | 3 | 20 | 7 | glutéaux, piriforme, ligaments, pelvi-trochantériens, artères et nerfs glutéaux, pudendaux, ischiatique |
| `anat-pl-2627-hanche-vues` | 7 | 9 | 6 | ligaments ilio-, pubo-, ischio-fémoraux, zona orbicularis, deux repères (C17) |
| `anat-pl-2627-coupe-hanche` | 8 | 28 | 7 | la coupe transversale entière : 26 structures et le repère |
| `anat-pl-2627-lombaire` | 10 | 16 | 6 | carré des lombes, psoas, iliaque, muscles larges, nerfs du plexus lombal, ligament inguinal |

Deux légendes sont doublées par la figure (« a. glutéal sup » et « n. glutéal
sup », « a. glutéale inf. » et « n. pudendal » se chevauchent) : chacune garde
son numéro, au départ de son propre trait.

### Les erreurs du ronéo portées par les planches

| Page | Ce que dit le ronéo | Retenu | Genre | Planche, numéro |
|---|---|---|---|---|
| p. 2 (figure) | « Nerfs cluniaux moyens (S2, S3, S4) » | S1-S3, comme le tableau de la même page et les références (Aota, World J Orthop 2016, PMC4794535) | prise de notes | `anat-pl-2627-surface-gluteale` n° 6 |
| p. 9 | le pectiné parmi les « muscles postérieurs » | en avant, en dedans de l'ilio-psoas (figure p. 8, dessin du professeur, Ronéosaure 2024-25 p. 16) | prise de notes | `anat-pl-2627-coupe-hanche` n° 19, `anat-pl-cours-coupe-hanche` n° 6 |
| p. 10 (figure) | « m. ilaque » / « m. grand psoas » | inversés, comme le ronéo le signale : la liste dit « Muscle grand psoas » pour la bande médiale, « Muscle iliaque » pour la fosse iliaque | prise de notes | `anat-pl-2627-lombaire` n° 13, 14 |
| p. 10 (figure) | « m. oblique externe » (bande du milieu) / « m. oblique interne » (bande latérale) | probablement inversés : la liste suit l'anatomie et le texte p. 11 | douteux | `anat-pl-2627-lombaire` n° 11, 12 |

### Les planches du Book et du bloc des mêmes régions

Elles gardent leur fiche (le Book Schéma 2025-26 fait foi pour les schémas de
l'examen ; le bloc 2024-25 pour la coupe p. 13) ; leur section cite les pages
du ronéo 2026-27, et leurs phrases le citent là où il confirme ou tranche :
`anat-pl-osteologie-posterieure` (p. 3, 10), `anat-pl-gluteale-muscles`
(p. 3-5), `anat-pl-gluteale-vaisseaux-nerfs` (p. 3-6), `anat-pl-nerf-ischiatique`
(p. 6), `anat-pl-plexus-lombo-sacre` (p. 6, 11 : le pudendal S2-S4 retenu),
`anat-pl-nerfs-femoral-obturateur` (p. 5, 11 : le rameau de l'obturateur
interne, faux), `anat-pl-coupe-hanche` (p. 8-9). Deux planches en attente pour
le reste citent aussi le ronéo sur les numéros qu'il dessine déjà (relecture
du 19/10) : `anat-pl-osteologie-anterieure` (p. 3, 10-11 : épines iliaques
antérieures, foramen obturé et canal obturateur, petit trochanter
postéro-médial) et `anat-pl-muscles-cuisse` (p. 8-11 : iliaque, grand psoas,
ligament inguinal, pectiné). Les cartes « à refaire sur papier » de ces
schémas ne changent pas : le Book reste le fond de l'examen.

Les deux QRM de l'annale 2022/2023 S2 (région glutéale) ont été relues sur le
ronéo : clés inchangées, et leur explication cite ses pages 3, 5 et 6.

### Absent du cours 2026-27

Aucune carte : les planches dessinent des structures que le ronéo confirme ou
que les CM suivants traiteront.

### En attente des CM suivants

Les planches du trigone fémoral, du réseau veineux, de l'ostéologie
antérieure, des muscles et de la vascularisation de la cuisse, de la fosse
poplitée et du genou (Book n° 1 à 6, 13 à 15, bloc p. 1), leurs cartes « à
refaire sur papier », et les deux annales de la fosse poplitée (2021/2022 S2,
2024/2025 S1) : le ronéo du 06/10 ne traite pas ces régions (il ne dessine que
le haut de l'ostéologie antérieure et les muscles de la paroi, que deux de ces
planches citent déjà). Elles restent sur le Book 2025-26 et le bloc 2024-25, à
relire à la parution des ronéos suivants.

## Questions pour Vincent

- (19/10) Les cinq planches des figures du ronéo 2026-27 sont dans ce chapitre,
  et la coupe de la hanche existe désormais deux fois : la photo du tableau
  (11 numéros, les sigles du professeur) et la figure du ronéo (28 numéros).
  Garder les deux, ou passer la photo en « doublon » ?
- (19/10) La figure p. 10 légende probablement les deux obliques à l'envers ;
  la planche suit l'anatomie (bande du milieu = oblique interne) avec un
  ATTENTION (douteux). Le professeur a-t-il nommé ces bandes au tableau ?
- (19/10) Faut-il tirer des figures du ronéo 2026-27 des cartes « à refaire sur
  papier », sur un fond fait en effaçant aussi les dessins des muscles, ou
  rester sur les fonds du Book ?

## Régénérer

```powershell
cd contenu\chapitres\anat_sch1
..\..\..\app\.venv\Scripts\python.exe generer.py
```

`generer.py` est la copie exacte de `.claude/skills/nouveau-chapitre/scripts/generer_modele.py`.

Les images numérotées des cinq planches du ronéo 2026-27 se refont, depuis
`app/`, par
`uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/anat_sch1 <id> --apercus <brouillon>`.
