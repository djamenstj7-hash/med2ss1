# Cryptographie — paquet Informatique médicale

64 notes, 104 cartes. Chapitre `chap-ue-info-medicale-fc6` de l'UE
Informatique médicale, sixième de l'UE. Cours du **Pr Renard, le 19/11/2025,
de 11 h à 12 h**, dans le **Ronéosaure 2025-26** (FC n°6, 11 pages) ; les
annales du polycopié « FC n°6 - Cryptographie » du Ronéosaure 2024-25
(5 QCM, 3 sessions). Examen : partiel du mercredi 16 décembre 2026, sur
tablette.

**Fiche provisoire** (C15, décision de Vincent du 02/10) : le ronéo 2026-27 de
ce cours n'est pas paru. Chaque carte de cours cite la FC 2025-26 à sa page ; le
ronéo 2026-27 la corrigera quand il sortira. La fiche porte son année dans son
auteur (« Ronéosaure 2025-26 ») : les cartes prennent le tag `cours-2025-26` et
le badge « Cours 2025-26 ». `donnees.py` porte aussi `ANNEE_COURS = "2025-26"`.
Aucune carte ne dit « Absent du cours 2026-27 ».

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 28 | 28 |
| QRU | 3 | 3 |
| Texte à trous | 9 | 46 |
| QROC | 9 | 9 |
| Recto-verso | 7 | 7 |
| Schéma cliquable | 1 | 4 |
| Lexique | 7 | 7 |

Dont **5 annales** (QRM) sur 3 sessions : 2023/2024 S1 (Q14, Q15), 2022/2023 S1
(Q1, Q2), 2021/2022 S1 (Q1). Les 26 QCM du cours ont, comme les annales, une
justification par proposition.

Sept thèmes, dans l'ordre du cours ; les sept clés sont nouvelles (plan C15),
et leurs libellés restent à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) :

| Clé | Libellé | Notes |
|---|---|---|
| `protection-donnees` | Protection des données personnelles | 10 |
| `proprietes-securite` | Propriétés de la sécurité informatique | 9 |
| `risques-securite` | Risques, ingénierie sociale et open source | 5 |
| `algorithmes-cles` | Algorithme privé, algorithme public et clés | 7 |
| `symetrique-asymetrique` | Chiffrement symétrique et asymétrique | 7 |
| `usages-chiffrement` | Signature, hachage, confidentialité, HTTPS | 13 |
| `nouvelles-cryptos` | Quantique, post-quantique, zéro connaissance | 6 |

(Plus les 7 termes de lexique, tag `lexique`.)

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-info-crypto-2526` — Ronéosaure, « FC n°6 Cryptographie » (11 p.), `INFORMATIQUE MÉDICALE/…` | **2025-26** | **la base** : `SRC["fiche"]`, `cours` et `medias` ; chaque note du cours porte sa page ; c'est ce que le lecteur ouvre (`chapitre=`) |
| `src-annales-fc-n6-cryptographie` — Ronéosaure, « FC n°6 - Cryptographie » (3 p.), `S1/ANNALES/Examens de Décembre/Informatique médicale/…` | 2024-25 | les 5 QCM et leur table de corrections (p. 3) ; déclaré avec les seuls champs de la convention commune (id tiré du nom du fichier) |
| Cours 2024-25 (Ronéosaure, n°6) et 2023-24 (Charonéo, n°4) du Pr Renard | 2024-25, 2023-24 | appoint, cités dans le texte des cartes sans être déclarés : la pseudonymisation, l'ANSSI « tous systèmes d'information », l'« injective », l'authentification « pendant de l'authenticité » |
| Erratas : cours 2025-26 (vide), annales 2024-25 (vide), cours 2024-25 (« ingénierie sociale », « Phishing », « Tor ») | — | aucune entrée ne change une carte : le ronéo 2025-26 écrit juste « ingénierie sociale » et ne parle plus ni de phishing ni de Tor |

`copier_les_cours.py` se lance avec le dossier `…/examen décembre` du
Ronéosaure 2025-26, **hors du bac à sable**, pour que la fiche s'ouvre dans
l'application. Les en-têtes des ronéos, des erratas et du polycopié portent des
noms d'étudiants : aucun n'est repris.

## Ce que le cours a dicté

- **Ni rouge ni gris de contenu** : le gris de ce ronéo ne marque que les titres
  de parties, les exemples RSA et ElGamal (p. 7) et la conclusion. Tout se carte.
- **Les consignes du professeur** ont choisi les cartes : « très importante à
  retenir » — les outils ne sont pas naturellement sûrs (p. 2,
  `cry-qc-introduction`) ; « +++ » — les trois organismes (p. 3,
  `cry-fa-organismes`, `cry-qc-organismes`, `cry-qr-anssi`) et security by
  design (p. 3, `cry-qc-security-by-design`, `cry-qr-security-by-design`) ;
  « ++ QCM » — les propriétés (p. 4 : `cry-fa-proprietes`, `cry-qc-proprietes`,
  deux QRU) ; « très important » — l'ingénierie sociale (p. 5) et les deux
  familles de chiffrement (p. 7).
- **Ce qui n'est pas carté ici**, parce qu'un autre chapitre le tient (plan
  C15, § 0.5) : les dates du RGPD, la définition des données de santé,
  l'hébergeur HDS, la messagerie sécurisée (FC1, `info_sante`) ; le fichier
  PMSI réidentifié (FC4) ; le chaînage par le code H (FC3). Les cartes les
  citent.

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| Ce que le chiffrement apporte : authenticité, intégrité, confidentialité, (disponibilité), et le piège de la « répudiation » | 2023/2024 Q14 = 2022/2023 Q1 (mot pour mot) |
| Le secret dans l'algorithme ou dans les clés ; une clé secrète en symétrique, une paire en asymétrique ; la signature = l'empreinte chiffrée par la clé secrète | 2023/2024 Q15 = 2022/2023 Q2 (une virgule près) |
| Les usages du chiffrement, la clé publique faite pour être partagée, la confiance dans les clés | 2021/2022 Q1 |

Toutes les clés sont officielles (aucune accolade dans la table). Les deux
questions répétées ont chacune leur carte, et l'explication renvoie à l'autre.

## Les erreurs du ronéo 2025-26

Le Ronéosaure n'est pas le ronéo de l'année : chaque erreur est portée par un
**ATTENTION nu** dans la carte qui tient la notion, la sorte dite dans le texte,
et rien n'entre dans `contenu/ERRATA_RONEOS_2026-27.md`.

| Page | Le ronéo dit | Retenu | Sorte | Carte |
|---|---|---|---|---|
| 2 | « le Code civil, qui traite notamment du secret professionnel » | le secret professionnel relève du Code pénal (art. 226-13) et du CSP (art. L. 1110-4) ; le Code civil protège la vie privée (art. 9) | point douteux | `cry-qc-textes` (explication) |
| 3 | la relation personne-données, après agrégation, « n'est plus bijective, mais injective » | l'idée : plusieurs personnes partagent la même donnée, on ne remonte plus à l'individu ; mathématiquement, c'est la perte d'injectivité | **le cours lui-même** — le ronéo 2024-25 (p. 3) dit le même mot ; le plan C15 disait « prise de notes » | `cry-qc-anonymisation` (explication) |
| 3 | avant le RGPD, « la CNIL vérifiait la conformité des projets a posteriori » | c'est l'inverse dans la loi : formalités préalables (déclaration, autorisation) sous la loi de 1978 ; le RGPD supprime cette obligation générale de notification (considérant 89) au profit de la responsabilité, contrôlée a posteriori ; l'idée du professeur, la sécurité dès la conception, reste juste | point douteux | `cry-qc-security-by-design` (explication) |
| 3 | « 150 000 à 300 000 € d'amende et jusqu'à 3 ans de prison » | Code pénal, art. 226-17 : 5 ans et 300 000 € | point douteux, sans carte chiffrée | `cry-rv-cle-usb` (explication) |
| 6 | algorithme public : « l'idée est d'utiliser deux clés distinctes au lieu d'une seule » | vrai de l'asymétrique seulement ; le symétrique est aussi un algorithme public (p. 7) | raccourci | `cry-qc-algo-public` D |
| 9 | la cryptographie quantique rend l'homme du milieu « impossible » | l'interception des photons se détecte, mais le canal classique doit être authentifié, sinon un imposteur se place au milieu (ANSSI, « Should Quantum Key Distribution be Used for Secure Communications? », 2020) | point douteux | `cry-qc-quantique` (explication) |

Dits sans ATTENTION, comme des précisions : la fonction de hachage « injective
en pratique » (p. 8 ; des collisions existent, on ne sait pas en trouver,
`cry-qc-hachage`) ; « Classic McEliece » cité parmi les exemples à côté des
« quatre protocoles retenus » en 2022 (le NIST a retenu Kyber et trois
signatures ; Classic McEliece est passé au tour suivant, `cry-qc-post-quantique`).

## Les clés qui ne sont pas reprises telles quelles

**Aucune** : les cinq clés imprimées sont reprises. Un point est discuté dans la
carte (`ATTENTION`, déclaré dans `CONFLITS`) sans changer la clé :

| Question | Clé | Le point | À l'examen |
|---|---|---|---|
| 2023/2024 Q14 D et 2022/2023 Q1 D, « Disponibilité » | ABCD | point douteux : aucun mécanisme de chiffrement ne rend une donnée disponible (la redondance le fait, p. 4-5 ; un rançongiciel chiffre pour la détruire) ; les quatre objectifs de la cryptographie sont la confidentialité, l'intégrité, l'authentification et la non-répudiation (Menezes, van Oorschot, Vanstone, *Handbook of Applied Cryptography*, 1996, § 1.2). Le professeur la range parmi les propriétés (p. 4) et dit que le chiffrement en met « plusieurs » en place (p. 7) | cocher D, comme la clé du professeur, deux années de suite |

## Le schéma cliquable et les figures

| Fichier | Ce qu'on clique | Pourquoi ce dessin |
|---|---|---|
| `cles.svg` | la clé privée de l'émetteur (signer), sa clé publique (vérifier), la clé publique du destinataire (chiffrer pour lui), sa clé privée (déchiffrer) — 4 zones, 4 cartes | les p. 7-8 ; c'est le raisonnement que posent les trois annales de clés (2023/2024 Q15 E, 2022/2023 Q2 E, 2021/2022 Q1 B et D). Les tuiles disent « clé publique » ou « clé privée » et à qui elles sont : sans cela, le clic n'aurait pas de sens ; ce qu'il faut savoir — laquelle sert à quoi — n'est écrit que sur `cles-legende.svg`, la correction |

**Trois figures de la FC 2025-26**, extraites en PNG : la seule figure de cours,
message → clé → chiffre (p. 7), et les deux moitiés du tableau récapitulatif
(p. 10, p. 11). **Huit schémas redessinés** pour les corrections, d'après le
texte des pages qu'ils citent : les propriétés (p. 4), trois listes croisées
(p. 3), les familles d'algorithmes (p. 6-7), symétrique et asymétrique (p. 7),
hachage et signature (p. 7-8), l'homme du milieu (p. 8), une session HTTPS
(p. 9), les nouvelles approches (p. 9-10).

**31 QCM sur 31 illustrés (100 %)**, 48 notes sur 64 ; l'image est toujours du
côté de la réponse, sauf le schéma nu de la carte de zone.

## Le lexique

Sept termes, ceux du plan C15 ; aucun n'existait (vérifié contre les `lex-*` de
tous les paquets et des chapitres écrits en parallèle). Pages mesurées dans le
texte de la FC 2025-26 (motif de `chercher_pages.py`, en-têtes exclus) :

| Terme | Origine | Pages |
|---|---|---|
| Cryptographie | grec kruptós + gráphein | 1, 7, 9, 10 |
| Stéganographie | grec steganós + gráphein | 6, 11 |
| Cryptogramme | grec kruptós + grámma | 8 |
| Hachage | français, de hacher (francique *happja) ; sens informatique calqué de l'anglais hashing | 8, 11 |
| Chiffrement asymétrique | arabe ṣifr par le latin médiéval cifra + grec a- + summetría | 7, 8, 9 |
| Authenticité | grec authentikós, par le latin authenticus | 4, 10 |
| Répudiation | latin repudiatio | 4, 10 |

- **« Asymétrique » devient « Chiffrement asymétrique »** (`lex-chiffrement-asymetrique`) :
  l'identifiant `lex-asymetrique` est pris par `biostat_analyse_descriptive`
  (la distribution asymétrique), d'un autre sens. La p. 7 l'écrit « chiffrement
  à clé asymétrique », les p. 8-9 « chiffrement asymétrique » ; l'annale
  2021/2022 Q1 D (« chiffrements asymétriques ») l'emploie.
- **« Répudiation »** est gardé comme le plan le dit : le mot de l'annale-piège
  (E de 2023/2024 Q14 et 2022/2023 Q1) ; la définition dit que la propriété est
  la NON-répudiation.
- Deux racines citent la FC de sémantique : `a-/an-` (1/2, p. 3) et
  `syn- (grec)` (2/2, p. 2). Sept racines nouvelles (`crypt(o)-`,
  `stégan(o)-`, `-gramme`, `hacher (français)`, `chiffre (arabe)`,
  `authent- (grec)`, `repudiare (latin)`) et les sept termes sont proposés à la
  table commune (`etymologies.json`), vérifiés sur le TLFi, le Wiktionnaire et le
  Bailly ; les textes du lexique sont déjà écrits dans la forme que
  `appliquer_etymologies.py` produirait (vérifié). `-graphie`, `-métrie`,
  `aut(o)- (grec)`, `a-/an-` et `syn- (grec)` reprennent les clés existantes.

## Décisions prises en route

- **L'« injective » de la p. 3** est rangée « le cours lui-même », et non
  « prise de notes » comme le proposait le plan : le ronéo 2024-25 (p. 3) écrit
  le même mot, et le cours de 2023-24 employait déjà « relation injective » pour
  le hachage. La carte ne pose aucune proposition sur le mot ; son explication
  dit l'idée à retenir.
- **Deux points douteux de plus que le plan** : la CNIL « a posteriori » (p. 3)
  et l'homme du milieu « impossible » en cryptographie quantique (p. 9),
  vérifiés sur le RGPD (considérant 89) et l'ANSSI.
- **`EXAMENS` n'est pas déclaré** (convention de BMCT) : le partiel du 16/12 se
  règle dans l'application.
- **Icône `book`**, celle du squelette pour ce chapitre et celle des autres chapitres de
  l'UE (`shield` est l'icône de l'immunologie).

## À relire

**Aucune carte `a-relire`** : toutes les notes citent une page de la FC 2025-26,
et ce que le ronéo ne dit pas a sa source dans le texte de la carte (Code pénal,
RGPD, ANSSI, NIST, *Handbook of Applied Cryptography*). Reste à Vincent :

- quand le ronéo 2026-27 paraîtra, relire chaque carte sur lui et retirer le
  badge « Cours 2025-26 » ;
- `copier_les_cours.py` avec le dossier `…/examen décembre`, hors du bac à
  sable ;
- les sept libellés de thèmes dans `THEME_LABELS`.

## Questions pour Vincent

- **2023/2024 Q14 et 2022/2023 Q1, « Disponibilité »** : la clé du professeur
  range la disponibilité parmi ce que donne le chiffrement. La carte garde ABCD,
  clé officielle, avec un ATTENTION « point douteux » qui dit la nuance (et
  « à l'examen : cocher D »). D'accord, ou faut-il tenir D pour faux ?


## L'échelle : Simple → Moyen → Annale (C20, 18/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 16 décembre. Sous les annales, 14 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 3 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `proprietes-securite` | 5 | 1 | 2 |
| `algorithmes-cles` | 5 | 1 | 2 |
| `symetrique-asymetrique` | 4 | 1 | 1 |

**Le schéma** `ech-chiffrement`, « Le chiffrement · ses familles et ses usages », donne 23 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_CHIFFREMENT`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```
