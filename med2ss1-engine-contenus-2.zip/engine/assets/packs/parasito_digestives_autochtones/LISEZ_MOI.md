# Parasitoses digestives autochtones — paquet Parasitologie et mycologie

81 notes, 141 cartes. Chapitre `chap-ue-parasito-fc3` de l'UE Parasitologie et
mycologie (ordre 3). Cours du **Pr Leroy, le 24/10/2025**, « Parasitoses
digestives autochtones » (FC n°3 du Ronéosaure 2025-26, 17 pages) ; annales de
trois polycopiés du Ronéosaure 2024-25 et du sujet 2024/2025 de l'UE (15
questions, 6 sessions). Examen du 5 janvier 2027.

**Une fiche provisoire.** Aucun ronéo 2026-27 de parasitologie n'est paru : le
chapitre est carté sur le Ronéosaure 2025-26 (tâche C16, décision de Vincent du
02/10), et le ronéo de l'année corrigera les cartes à sa parution. La fiche
porte son année dans son auteur : chaque carte de cours prend le tag
`cours-2025-26`, et l'écran montre « Cours 2025-26 ». Aucune carte ne dit
« Absent du cours 2026-27 » ; les erreurs du Ronéosaure sont dites par un
ATTENTION sans genre (précédent d'`immuno_cmh`, d'`immuno_innee`) et n'entrent
pas dans `contenu/ERRATA_RONEOS_2026-27.md`, réservé aux ronéos 2026-27.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 36 | 36 |
| QRU | 2 | 2 |
| Texte à trous | 13 | 68 |
| QROC | 10 | 10 |
| Recto-verso | 8 | 8 |
| Schéma cliquable | 1 | 6 |
| Planche à légender | 1 | 1 |
| Lexique | 10 | 10 |

Dont **15 annales** : 13 QCM (QRM) et 2 QROC (recto-verso), sur 6 sessions, de
2020/2021 S2 à 2024/2025 S1 (Q1, Q2 et QROC 1 du sujet 2024/2025, sans corrigé). Les 25 QCM du cours (23 QRM, 2 QRU) ont une
justification par proposition, comme les annales.

Sept thèmes, ceux du plan C16 (§3.3), dans l'ordre du cours :

| Clé | Libellé |
|---|---|
| `peril-fecal` | Péril fécal et transmission digestive (partagé avec la FC n°5) |
| `diagnostic-biologique` | Diagnostic biologique (partagé avec huit chapitres de l'UE) |
| `giardiose` | Giardiose |
| `cryptosporidiose` | Cryptosporidiose |
| `hypereosinophilie` | Hyperéosinophilie et helminthes (partagé avec la FC n°5) |
| `oxyurose` | Oxyurose |
| `teniasis` | Téniasis et cysticercose |

Les sept libellés sont à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) : aucune de ces clés n'existe
encore. La classification des parasites (p. 3) et la biologie des helminthes
(p. 11) sont rangées sous `hypereosinophilie`, faute d'un thème de
classification dans le plan de ce chapitre (voir les questions).

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-parasito-fc3` — Ronéosaure, « FC n°3 Parasitoses digestives autochtones » (17 p.), `PARASITO-MYCOLOGIE/…` | **2025-26** | **la base** : chaque note du cours porte sa page ; c'est ce que le lecteur ouvre (`chapitre=`) |
| `src-annales-3-parasitoses-digestives-autochtones` — polycopié 3 (3 p.) | 2024-25 | 2023/2024 S1 et 2022/2023 S1 ; table p. 3 |
| `src-annales-1-definition-du-parasitisme-classification-des-pathogenes-d-interet-medical` — polycopié 1 (3 p.) | 2024-25 | 2021/2022 S1 et 2020/2021 S2 ; table p. 3 |
| `src-annales-5-parasitoses-digestives-exotiques` — polycopié 5 (5 p.) | 2024-25 | 2021/2022 S2 ; table p. 4-5 |
| `src-sujets-parasito-2425` — sujets de parasitologie-mycologie 2024/2025, session 1 (examen du 10/01/2025, 14 p.), sans chemin | 2024-25 | 2024/2025 S1 : Q1, Q2, QROC 1 ; **aucun corrigé**, clés déduites du cours ; déclaration commune aux dix chapitres de l'UE qui en cartent une question, champ pour champ |
| `src-cours-parasito-fc3-2425` — Ronéosaure, FC n°3, Pr Leroy (20 p.) | 2024-25 | appoint, cité dans le texte : les selles « aqueuses puis progressivement pâteuses » de la giardiose (p. 8) ; la définition du parasite (p. 2) et la cysticercose par les embryophores (p. 20), à l'appui de deux ATTENTION |
| FC n°1 et n°4 2025-26 | 2025-26 | citées dans le texte, à la page, pour la définition de l'hôte définitif (FC n°1 p. 8-9, FC n°4 p. 4) et l'impasse parasitaire (FC n°1 p. 10) ; ce sont les fiches d'autres chapitres |
| erratas : cours 2025-26 (`Erratas de Parasitologie mycologie.docx`), annales 2024-25 | — | deux entrées sur la FC n°3 (la classification des métazoaires, « toxicomanie ») ; l'errata des annales est vide |

**Une source par session** (`SRC["sessions"]`) : chaque session de ce chapitre
vient d'un seul polycopié, et 2024/2025 S1 du sujet de l'UE. **Les trois déclarations d'annales sont
partagées** : les polycopiés 1 et 5 servent aussi aux chapitres de la FC n°1,
de la FC n°4 et de la FC n°5. Ils sont déclarés avec exactement les champs
convenus (identifiant `src-annales-<nom de fichier>`, titre = nom du fichier,
chemin sous `S1/ANNALES/Examens de Janvier/Parasitologie et Mycologie/`,
auteur « Ronéosaure 2024/2025 ») ; le titre du polycopié 1 garde l'espace qui
finit le nom du fichier, « … d_intérêt médical ».

Vérifications hors du cours, citées dans la carte qui s'en sert : l'OMS
(aide-mémoire « Taeniasis/Cysticercose » : le téniasis par les cysticerques de
la viande, la cysticercose par les œufs) ; l'Assurance maladie (« selles molles
et graisseuses » de la giardiase) ; l'étymologie (TLFi par l'API du CNRTL, LSJ
et Lewis & Short sur Perseus, Wiktionnaire).

## Ce que le cours a dicté

- **Pas de rouge.** Le gris est la voix des rédacteurs (titres, remarques) et
  se carte (décision de Vincent du 25/09).
- **Hors examen, carté avec le tag `edn`** : le cycle de Cryptosporidium,
  « de rang C », « aucune question sur le cycle ne sera posée » (p. 9, 11) —
  `pda-fa-crypto-cycle`, `pda-rv-oocystes`. Le cycle illustre aussi deux
  corrections, en le disant dans sa légende.
- **« Il n'y aura jamais de question sur la taille d'un parasite »** (p. 7) et
  **« les posologies ne sont pas à apprendre »** (p. 8) : aucune carte ne
  demande une taille ni une posologie ; la planche efface même les longueurs
  des deux ténias.
- **Les points clés de chaque parasite** (p. 8, 11, 14, 17) ont chacun leur
  carte : Giardia (protiste flagellé cosmopolite, duodénum, EPS répété,
  métronidazole, contrôle) ; Cryptosporidium (pôle apical, immunodéprimé,
  biologie moléculaire, eau) ; oxyurose (femelle nocturne, scotch-test, pas de
  migration des mâles, entourage) ; téniasis (T. saginata en France, bœuf ou
  porc, cysticercose et épilepsie, sérologie de la seule cysticercose).
- **Frontières du plan C16** : le péril fécal est défini ici (p. 2-3), les
  diarrhées du voyageur sont à la FC n°5 ; la courbe de Lavier et son principe
  sont ici (p. 11-12), le tableau des seuils et l'anguillulose à la FC n°5.

## Les erreurs du Ronéosaure 2025-26

Chacune est dite par **ATTENTION**, sans genre, dans la carte qui porte la
notion.

| Page | Ce que dit le Ronéosaure | Ce qui est juste | Carte |
|---|---|---|---|
| 2 | « Un Parasite est un être eucaryote (bactérie, virus) » | bactéries et virus ne sont pas eucaryotes ; le cours 2024-25 : « un être vivant eucaryote qui vit au dépend de son hôte » | `pda-qc-parasite` B |
| 2 | « Hôte définitif → là où survient la reproduction (asexuée ou sexuée) » | l'hôte définitif héberge la forme adulte, celle de la reproduction sexuée (FC n°1 2025-26, p. 8-9 ; FC n°4, p. 4) | `pda-qc-parasite` C, `pda-fa-hotes` |
| 3 | les trématodes : « bilharziose intestinale et distomatose → enterovirus vermicularis (oxyurose +++) » | Enterobius vermicularis est un némathelminthe ; trématodes = bilharziose et distomatose (errata de la promo 2025-26) | `pda-qc-classification` C |
| 11 | « La reproduction de ces vers se fait par hermaphrodie », en fin de partie sur les helminthes, sans distinguer | vrai du ténia (p. 15) ; les nématodes ont des sexes séparés, l'oxyure un mâle et une femelle (p. 12) | `pda-qc-helminthes` C, `pda-rv-nematode-cestode` |
| 16 | un porc infesté contient des cysticerques, « après leur ingestion par l'homme elles peuvent se disséminer dans les muscles, l'œil et le cerveau » | les cysticerques de la viande donnent le téniasis ; la cysticercose vient des embryophores (même page ; cours 2024-25, p. 20 ; OMS) | `pda-qc-cysticercose` B, `pda-fa-cysticercose` |
| 7 | « diarrhées modérées puis aqueuses » | point douteux : « aqueuses puis progressivement pâteuses » dans le cours 2024-25 (p. 8) | `pda-an-2223s1-q6` D |

Sans ATTENTION, parce qu'aucune réponse n'en dépend : « la toxicomanie des
parasites » pour la taxonomie (p. 1 et 3 ; errata de la promo), « stéartorrhée »
(p. 7), « Giardia intestinales » (p. 1), « La diagnostic est porté par le
prurit » (p. 14).

**Points douteux, non cartés** : la survie du kyste de Giardia, « 1 à 2 ans »
dans le texte (p. 5) contre « 2 semaines à 25 °C » sur la diapositive (p. 6) ;
la ponte de l'oxyure, « 10 000 œufs au cours de sa vie » dans le texte (p. 12)
contre « 10 000 œufs/jour » sur la diapositive ; « environ 3 semaines
(28 jours) » avant la ponte (p. 13 ; la carte garde les 3 semaines de la
diapositive) ; « 1 mois entre la libération d'œuf et la formation d'un ténia
adulte » (p. 15 ; la diapositive porte « 3 mois ») ; T. solium « 2-8 m » sur la
diapositive des scolex, « 1 à 8 m » dans le tableau (p. 15-16) ; la diapositive
de Lavier, « Modérée > 1500 - < 500 » (p. 12 : sans doute < 5 000).

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| Les ténias : vers plats, intestin grêle, bœuf et porc, épidémiologie, clinique, EPS | 2023/2024 S1 Q.2, 2022/2023 S1 Q.7, 2021/2022 S1 Q. 5, 2021/2022 S2 Q6 |
| L'oxyurose : cosmopolite, strictement humaine, contagieuse, de l'enfant, prurit vespéral, scotch-test, hyperéosinophilie faible | 2023/2024 S1 Q.4, 2022/2023 S1 Q.5, 2021/2022 S1 Q. 9 et QROC 5, 2020/2021 S2 Q. 4, 2024/2025 S1 2) |
| La giardiose : protozoaire cosmopolite, péril fécal, diarrhée sans hyperéosinophilie, EPS, ses deux formes | 2023/2024 S1 Q.1, 2022/2023 S1 Q.6, 2021/2022 S2 Q7, 2024/2025 S1 QROC 1 |
| L'hyperéosinophilie parasitaire : helminthes, migration larvaire, faible dans l'oxyurose, absente de la giardiose | 2024/2025 S1 1) |

Cryptosporidium n'est jamais demandé. **Doublons cartés une fois** (même
session, deux polycopiés) : 2023/2024 S1 Q1 et Q2 (polycopiés 3 et 5, mêmes
clés), 2022/2023 S1 Q5 et Q7 (3 et 1, sans correction), 2021/2022 S1 Q5 (1 et
5, même clé), 2021/2022 S2 Q6 (1 et 5, même clé).

| Annale | Polycopié | Clé imprimée | Clé retenue |
|---|---|---|---|
| 2023/2024 S1 Q.1 (giardiose) | 3 (= 5) | AE | AE |
| 2023/2024 S1 Q.2 (ténias) | 3 (= 5) | BD | BD |
| 2023/2024 S1 Q.4 (oxyurose) | 3 | ABC | ABC |
| 2022/2023 S1 Q.5 (oxyurose) | 3 (= 1) | aucune | CDE, déduite |
| 2022/2023 S1 Q.6 (giardiose) | 3 | aucune | ACD, déduite |
| 2022/2023 S1 Q.7 (Taenia spp.) | 3 (= 1) | aucune | ABD, déduite |
| 2021/2022 S1 Q. 5 (ténias) | 1 (= 5) | CDE | CDE |
| 2021/2022 S1 Q. 9 (oxyurose) | 1 | CD | CD |
| 2021/2022 S1 QROC 5 (signes de l'oxyurose) | 1 | prurit anal vespéral et nocturne ; troubles digestifs | idem |
| 2021/2022 S2 Q6 (ténias) | 5 (= 1) | AB | AB |
| 2021/2022 S2 Q7 (Giardia) | 5 | ACD | ACD |
| 2020/2021 S2 Q. 4 (Enterobius) | 1 | ABE | ABE |
| 2024/2025 S1 1) (hyperéosinophilie) | sujet | aucune | ACE, déduite |
| 2024/2025 S1 2) (oxyurose) | sujet | aucune | CDE, déduite |
| 2024/2025 S1 QROC 1 (formes de Giardia) | sujet | aucune | trophozoïte et kyste, déduit |

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2022/2023 S1 Q.5 (oxyurose) | « Pas de correction, vérifier le cours » | **CDE** | clé déduite de la FC 2025-26 (p. 12-14) ; `officielle=False` |
| 2022/2023 S1 Q.6 (giardiose) | « Pas de correction, vérifier le cours » | **ACD** | clé déduite ; D (« selles pâteuses ») tenue pour vraie sur le cours 2024-25 (p. 8), contre le Ronéosaure 2025-26 (« modérées puis aqueuses ») : ATTENTION, point douteux ; `officielle=False` |
| 2022/2023 S1 Q.7 (Taenia spp.) | « Pas de correction, vérifier le cours » | **ABD** | clé déduite de la FC 2025-26 (p. 14-17) ; `officielle=False` |
| 2024/2025 S1 1) (hyperéosinophilie d'origine parasitaire) | aucune (sujet sans corrigé) | **ACE** | clé déduite de la FC 2025-26 (p. 11-12, 14) ; E, « elle n'est jamais décrite dans la giardiose », tenue pour vraie avec la FC n°5 (« les protozoaires ne donnent pas d'hyperéosinophilie », p. 5), alors que la FC n°3 dit « pas normalement » (p. 12) : ATTENTION, point douteux, déclaré dans `CONFLITS` ; `officielle=False` |
| 2024/2025 S1 2) (oxyurose) | aucune (sujet sans corrigé) | **CDE** | clé déduite de la FC 2025-26 (p. 12-14) ; A, « la contamination peut être liée à l'ingestion de végétaux », tenue pour fausse : le cours ne cite que les mains, la literie, les objets et la poussière (p. 12-13), mais le manuel MSD décrit des œufs portés par des aliments manipulés ; ATTENTION, point douteux, déclaré dans `CONFLITS`, carte `a-relire` ; `officielle=False` |
| 2024/2025 S1 QROC 1 (formes de Giardia) | aucune (sujet sans corrigé) | trophozoïte (forme végétative) et kyste | réponse déduite de la FC 2025-26 (p. 5-7) ; non officielle. Le sujet écrit « Gardia intestinalis » : coquille gardée dans l'énoncé |

Aucune clé imprimée n'est contredite. `CONFLITS` déclare trois cas ouverts
jusqu'au ronéo 2026-27 : 2022/2023 S1 Q.6 D, où deux années du cours se
contredisent, et les deux points douteux du sujet 2024/2025 (1) E, 2) A) ; le
générateur vérifie que l'ATTENTION reste dans chaque justification. L'Assurance maladie (ameli.fr, « Giardiase ») décrit des
« selles molles et graisseuses » dans la forme chronique, ce qui va dans le
sens retenu.

## Le schéma cliquable et la planche

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `tube-digestif-parasites.svg` (`pda-zo-tube`) | l'estomac (lyse du kyste de Giardia), le duodénum (Giardia), l'intestin grêle (ténia adulte), le cæcum et l'appendice (oxyures adultes), le côlon et le rectum (migration de la femelle), la marge anale (ponte) | 6 |

Un tube digestif de face, redessiné sans une légende ; le côté gauche du
patient est à droite de l'image. Le jéjunum passe sous le côlon transverse ;
chaque tube et sa zone sortent de la même ligne médiane (`_bande`), et le haut
de la zone du grêle se cale sous la bande du côlon (`_GRELE_HAUT`). Rendu avec
les zones superposées : aucune zone n'en touche une autre. La version légendée,
`tube-digestif-parasites-legende.svg`, est en correction.

**La planche** `pda-pl-scolex` : la diapositive « Agent pathogène » (p. 15),
légendes effacées par `scripts/planche_depuis_image.py` — huit numéros
(Taenia saginata, Taenia solium, scolex, ventouse, rostre à crochets, cou,
anneaux, strobile), quatre intrus (embryophore, cysticerque, lèvres
rétractiles, Hymenolepis nana). La légende « Scolex (1-2 mm) » de la photo et
les longueurs des deux espèces sont effacées avec les numéros 1 à 3 : elles
donnaient les réponses. L'aperçu de contrôle a été relu : aucun reste de
lettre, aucune flèche entamée.

**Illustrations** : 37 QCM sur 38 (97 %) portent une figure de la fiche en
correction ; 63 notes sur 81. Les trois annales 2024/2025 sont illustrées (la
courbe de Lavier, le cycle d'Enterobius, les deux formes de Giardia). Le seul QCM sans figure, `pda-qc-techniques`
(concentration, qPCR), n'en a pas dans la fiche.

## Le lexique

Dix termes, aux pages mesurées dans la fiche 2025-26 : péril fécal (p. 2, 3,
5, 8, 17), cosmopolite (1, 2, 5, 8, 12, 14), trophozoïte (5-7), zoonose (5, 9,
12, 13), embryophore (15-17), scolex (15), proglottis (15-17), cysticercose
(16, 17), hyperéosinophilie (11, 12, 14, 16), prurit (13, 14, 16). Chacun dit
son origine grecque ou latine. Cosmopolite, hyperéosinophilie et prurit sont
accueillis ici plutôt qu'aux FC n°5 et n°10 (plus d'annales ici, plan C16).
Helminthe et monoxène restent à la FC n°1, oocyste à la FC n°6.

**Zoonose** porte l'identifiant `lex-zoonose-parasito` : `lex-zoonose` est déjà
pris par le chapitre de virologie `viro_pathogenes_1`, et un même identifiant
dans deux paquets ferait passer le terme d'un chapitre à l'autre à l'import.
C'est la convention de l'UE (`lex-neutropenie-parasito`,
`lex-amniocentese-parasito`).

Les étymologies nouvelles — douze racines (`periculum (latin)`, `cosm(o)-`,
`-polite`, `zo(o)-`, `-zoïte`, `-nose`, `-phore`, `skôlêx (grec)`,
`gloss(o)- / glott(o)-`, `cerc(o)- / -cercaire`, `éosin(o)-`,
`prurire (latin)`) et les dix termes — sont **proposées** pour
`scripts/etymologies.json`, avec leurs sources ; la table n'est pas modifiée
par ce chapitre. Les racines que d'autres chapitres proposent aussi gardent
leur clé et leur texte : `cerc(o)- / -cercaire` est l'entrée de la FC n°5,
recopiée telle quelle ; `-zoïte` et `-phore` sont identiques à celles du
paludisme et de la toxoplasmose, `-nose` à celle de la virologie. Reste un
point pour qui versera les propositions dans la table : ζῷον y arrive sous
trois clés, `zo(o)-` (ici et au paludisme), `zo(o)- / -zoaire` (FC n°1) et
`zoo-` (virologie) ; il en faut une seule. Les définitions et les
racines disent déjà, mot pour mot, ce qu'`appliquer_etymologies.py` en écrira
(calculé avec la table et la proposition). Les racines réemployées gardent la
clé de la table : `faex, faecis (latin)`, `troph(o)-`, `embry(o)-`,
`pro- (grec)`, `cyst-`, `-ose`, `hyper-`, `-phile`.

## Questions pour Vincent

1. **2022/2023 S1 Q.6 D, les selles pâteuses de la giardiose** : sans clé
   imprimée, je la tiens pour vraie sur le cours 2024-25 du même professeur
   (« aqueuses puis progressivement pâteuses »), contre le Ronéosaure 2025-26
   (« modérées puis aqueuses »), et la carte le signale. D'accord, ou attendre
   le ronéo 2026-27 ?
2. **Les modalités de l'EPS** (question 3 du plan) : ici, Giardia se cherche
   sur « 3 selles sur 10 jours » (FC n°3, p. 7), ce qui concorde avec la FC
   n°5 ; la FC n°1 dit « espacé de 3 semaines ». Les cartes suivent les FC n°3
   et n°5, comme le plan le propose : d'accord ?
3. **La classification des parasites** (p. 3) est rangée sous le thème
   `hypereosinophilie` (« Hyperéosinophilie et helminthes »), le plan ne
   donnant pas de thème de classification à ce chapitre. Préfères-tu le thème
   `classification-parasites` de la FC n°1, au même libellé ?
4. **L'examen du 5 janvier 2027** (question 5 du plan) n'est pas déclaré
   (`EXAMENS`), comme dans les autres chapitres : faut-il le faire pour les
   quatre UE de janvier ?
5. **Les deux points douteux du sujet 2024/2025**, sans corrigé : 1) E
   (« l'hyperéosinophilie n'est jamais décrite dans la giardiose ») tenue pour
   vraie, avec la FC n°5 ; 2) A (« la contamination [de l'oxyurose] peut être
   liée à l'ingestion de végétaux ») tenue pour fausse, faute de page qui la
   donne. D'accord, ou préfères-tu ACDE pour la Q2 ?

## À relire

**Une carte `a-relire`** : `pda-an-2425s1-q2` (oxyurose, 2024/2025 S1), dont la
proposition A — la contamination par les végétaux — n'est tranchée par aucune
page du cours ; le tag se retire quand une source (ronéo 2026-27, avis du
professeur) la tranche. Toutes les autres cartes de cours portent leur page
dans la fiche 2025-26, chaque annale sa clé vérifiée ou déduite. À la parution du ronéo
2026-27 de ce cours, relire toutes les cartes contre lui : pages, chiffres
(7,5 % et 30 % de porteurs de Giardia, 80 % d'efficacité du métronidazole,
contrôle à 4 semaines, 500-1 500 éosinophiles), et les erreurs ci-dessus.


## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier. Sous les annales, 36 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 5 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `giardiose` | 9 | 1 | 4 |
| `hypereosinophilie` | 4 | 1 | 1 |
| `oxyurose` | 14 | 2 | 6 |
| `teniasis` | 9 | 1 | 4 |

**Le schéma** `ech-parasites-digestifs`, « Trois parasites du tube digestif · Giardia, oxyure, ténia », donne 55 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_PARASITES_DIGESTIFS`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Un ATTENTION ajouté** (C29, 19/10) sur 2023/2024 S1 Q1 E : trois selles sur 10 jours dans ce cours, sur 3 semaines dans la FC n°1, sur 7 à 10 jours dans la FC n°5 ; la marche `pda-ech-s9` le dit aussi.

## Régénérer

```powershell
cd contenu\chapitres\parasito_digestives_autochtones
..\..\..\app\.venv\Scripts\python.exe generer.py
```

La planche se refait depuis `app/`, si ses rectangles changent :
`uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/parasito_digestives_autochtones pda-pl-scolex --apercus <brouillon>`.
