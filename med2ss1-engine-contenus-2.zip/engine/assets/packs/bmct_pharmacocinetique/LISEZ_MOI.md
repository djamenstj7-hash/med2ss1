# Pharmacocinétique appliquée — paquet BMCT

117 notes, 194 cartes. Chapitre `chap-ue-bmct-fc2` de l'UE BMCT, deuxième chapitre
de l'UE. **Cours du 28/09/2026, de 8 h à 10 h 30, en trois ronéos Ronéo & Juliette
2026-27** : la partie 1 et la partie 2 (en-têtes : Pr Deplanque ; la partie 2 dit le
cours donné par « sa remplaçante »), la partie 3 (Pr S. Gautier). Réaligné sur elles
le 11/10/2026 ; il était carté depuis le 02/10 (tâche C14) sur la FC n°2 du
Ronéosaure 2025-26, qui n'est plus qu'un appoint. Annales : 36 QCM sur seize sessions
(Ronéosaure 2024-25), et quatre du sujet 2024/2025 (déposé le 15/10/2026). Examen :
partiel de novembre (mercredi 4/11/2026).

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 72 | 72 |
| Texte à trous | 13 | 87 |
| QROC | 8 | 8 |
| Recto-verso | 12 | 12 |
| Lexique | 10 | 10 |
| Schéma cliquable | 1 | 4 |
| Planche à légender | 1 | 1 |

Dont **40 annales** (QCM) sur 17 sessions, de 2015/2016 S1 à 2024/2025 S1 — les
36 du polycopié et les Q8 à Q11 du sujet 2024/2025, session 1 (`pk-an-2425s1-q8`
à `-q11`, sans corrigé, clés déduites du cours) —, et 32 QCM de cours, dont les
trois quiz corrigés du professeur en 2025-26 (clé officielle). Les clés de
2023/2024 (Q.6 BD, Q.7 ABE, Q.8 AC) sont confirmées par la grille officielle de
la faculté (dépôt du 15/10/2026). **69 QCM sur 72 illustrés (96 %)**, 94 notes
sur 117. **14 cartes absentes du cours
2026-27** (tag `absent-2026`), **19 cartes portent un piège du ronéo** (thème
« Pièges des ronéos »).

Sept thèmes, dans l'ordre du cours, déjà dans `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) ; le réalignement n'en ajoute aucun :

| Clé | Libellé |
|---|---|
| `voies-administration` | Voies d'administration et galénique |
| `absorption` | Absorption, transferts et biodisponibilité |
| `distribution` | Distribution et volume de distribution |
| `biotransformation` | Métabolisme des médicaments |
| `induction-inhibition` | Inhibiteurs et inducteurs enzymatiques |
| `elimination` | Élimination rénale et biliaire |
| `demi-vie` | Demi-vie et administration répétée |

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-bmct-pk-2627-1` — « Pharmacocinétique » (12 p.), `BMCT/PHARMACOCINÉTIQUE.pdf` | **2026-27** | **partie 1**, 8 h-9 h : objectifs (p. 2-4), définition (p. 4-5), voies d'administration (p. 5-8), particularités (p. 8-9), transferts (p. 9-10), courbes (p. 10), facteurs de la biodisponibilité (p. 11-12) ; `SRC["fiche"]`, ce que le lecteur ouvre ; 24 notes |
| `src-fc-bmct-pk-2627-2` — « Pharmacocinétique 2 » (12 p., la dernière vide), `BMCT/PHARMACOCINÉTIQUE 2.pdf` | **2026-27** | **partie 2**, 9 h-10 h : pro-médicaments, vancomycine, galénique, déconditionnement (p. 2-4), distribution (p. 4-7), métabolisme et variabilité (p. 7-10), inducteurs et inhibiteurs (p. 10-11) ; `fiche=FC2` ; 22 notes |
| `src-fc-bmct-pk-2627-3` — « Principes pharmacocinétiques et prescription » (10 p., la dernière vide), `BMCT/PRINCIPES PHARMACOCINETIQUES ET PRESCRIPTION.pdf` | **2026-27** | **partie 3**, 10 h-10 h 30, Pr S. Gautier : élimination biliaire et rénale (p. 2-3), demi-vie (p. 3-4), administration répétée (p. 4-5), paracétamol et codéine (p. 5-7), conclusion (p. 8-9) ; `fiche=FC3` ; 17 notes |
| `src-fc-bmct-pk-2526` — FC n°2, « Pharmacocinétique appliquée » (25 p.) | 2025-26 | **appoint** (`SRC["cours"]`, sans `chapitre=`) : ce que le ronéo 2026-27 ne reprend pas, les quiz, **les figures** (`SRC["medias"]`), et la source des **14 cartes absentes** |
| `src-annales-bmct-pk` — « BMCT - Principes pharmacocinétiques » (12 p.) | 2024-25 | 37 QCM sur 16 sessions, table de corrections p. 10-11 |
| `src-sujets-bmct-2425` — Sujets de BMCT 2024/2025, session 1 (20 p.) | 2024-25 | les Q8 à Q11, sujet sans corrigé ; `SRC["sessions"]["2024/2025 S1"]` ; déclaré à l'identique par tous les chapitres de BMCT qui en cartent une question |
| tableau d'erreurs BMCT de la promo 2026-27 | 2026-27 | vide au 11/10/2026 ; au **19/10/2026**, une entrée sur ce chapitre : la liaison plasmatique « PEU importante » (partie 2, p. 6), déjà portée en prise de notes |

Les textes citent « partie 1, p. 10 » (ronéo 2026-27) ou « FC 2025-26, p. 20 ».
Lus en appoint, sans être déclarés : le cours 2023-24 n°7 du même professeur
(Charonéo) ; l'errata des cours 2025-26 de la promo ; l'errata des annales BMCT (rien
sur ce polycopié). Les trois fiches de l'année se copient dans le dossier des PDF de
l'application par `outils/copier_les_cours.py`, lancé avec le dossier des ronéos
2026-27 (`Ajouts/[NUMERIQUE] Ronéo & Juliette 26-27 11 10 2026/S1/CM`), hors du bac
à sable.

Les en-têtes des ronéos nomment leurs rédacteurs et leurs correcteurs, le polycopié
d'annales son secrétaire : aucun nom n'est repris.

**Qui a fait le cours.** L'en-tête des parties 1 et 2 nomme le Pr Deplanque, mais la
partie 1 parle de « la Pr » et la partie 2 du cours donné par « sa remplaçante » ; la
partie 3 nomme le Pr S. Gautier. C'est sans doute elle qui a fait les trois heures ;
`CHAPITRE.semaine` nomme les deux, comme les en-têtes.

## Ce qui correspond à quoi

Les trois ronéos suivent, dans l'ordre, tout le plan de la FC 2025-26 :

| FC 2025-26 | Ronéo 2026-27 |
|---|---|
| I. Introduction, objectifs, définition (p. 2-3) | partie 1, p. 2-5 |
| II.A-C Voies, particularités, transferts (p. 3-6) | partie 1, p. 5-10 |
| II.D Biodisponibilité, premier passage, galénique, déconditionnement (p. 6-9) | partie 1, p. 10-12, puis partie 2, p. 2-4 |
| III. Distribution (p. 9-12) | partie 2, p. 4-7 |
| IV. Métabolisme, inhibiteurs, inducteurs (p. 13-17) | partie 2, p. 7-11 |
| V. Élimination : voies accessoires (p. 17-18) | partie 2, p. 9 (une ligne) |
| V. Élimination biliaire, rénale, fonction rénale (p. 18-22) | partie 3, p. 2-3 |
| VI. Demi-vie, administration répétée (p. 22-25) | partie 3, p. 3-5 |
| Conclusion (p. 25) | partie 3, p. 8-9 |
| — | **nouveau** : le paracétamol et la codéine lus dans leur monographie (partie 3, p. 5-7) ; les métabolites actifs, la fluoxétine (partie 2, p. 7-8) |

Aucun des trois ronéos n'apporte un sujet qu'aucun chapitre BMCT ne tienne : tout
appartient à la pharmacocinétique, et se carte ici. Le 5-FU et la DPD (partie 3,
p. 9), le bypass (partie 1, p. 11-12) et le paracétamol à dose toxique sont déjà dans
la variabilité (`var-qc-5fu`, `var-qr-dpd`, `var-qc-bariatrique`, `var-fa-paracetamol`) ;
le CYP2D6 et la codéine, dans la pharmacodynamie générale (`pdg-qc-cyp2d6`,
`pdg-qc-codeine`). Les cartes d'ici y renvoient.

## Le réalignement du 11/10/2026

Les 62 notes de cours de la version 2025-26 ont été relues une à une contre les trois
ronéos.

**Relues et confirmées (40), qui citent désormais leur page de l'année** (et perdent
le badge « Cours 2025-26 ») :

| Partie | Notes |
|---|---|
| 1 (15) | `pk-fa-objectifs` (p. 2), `pk-fa-parametres` (p. 5), `pk-qc-quiz-absorption` (p. 5), `pk-qc-voies`, `pk-qc-biodisponibilite`, `pk-fa-biodisponibilite`, `pk-qr-hemorroidaires`, `pk-qr-voie-reference` (p. 7), `pk-qc-particularites` (p. 8), `pk-qc-transfert`, `pk-fa-transfert-passif` (p. 9), `pk-fa-transfert-actif`, `pk-rv-ldopa` (p. 10), `pk-qc-epph` (p. 11), `pk-rv-insuffisance-renale` (p. 3) |
| 2 (16) | `pk-qc-galenique`, `pk-qr-vancomycine` (p. 2), `pk-qc-deconditionnement` (p. 3), `pk-rv-aminosides` (p. 4), `pk-qc-quiz-distribution`, `pk-qc-liaison-proteines`, `pk-rv-libre-liee` (p. 5), `pk-qc-distribution-tissulaire`, `pk-qc-vd`, `pk-fa-volume-distribution` (p. 6), `pk-qr-astemizole` (p. 7), `pk-qc-metabolisme`, `pk-fa-metabolisme` (p. 9), `pk-qc-inhibition-induction`, `pk-fa-inhibiteurs-inducteurs`, `pk-rv-inhibition-induction` (p. 10) |
| 3 (9) | `pk-qc-quiz-elimination`, `pk-qc-entero-hepatique`, `pk-qc-renal`, `pk-fa-cycle-entero-hepatique`, `pk-pl-entero-hepatique` (p. 2), `pk-rv-cockcroft-mdrd` (p. 3), `pk-fa-plateau` (p. 4), `pk-qc-fractionnement`, `pk-qc-demi-vie` (p. 5) |

Dans ces cartes, chaque proposition ou chaque trou que seul le cours 2025-26 porte le
dit dans sa justification (« FC 2025-26, p. 9 ; le ronéo 2026-27 n'en parle pas ») :
une carte n'est confirmée que si sa notion centrale est dans le cours de l'année.

**Ce que le ronéo 2026-27 dit autrement, et ce qui a été réécrit** :

- **La formule du Vd est « pas à connaître »** (en rouge, partie 2, p. 6) : le premier
  trou de `pk-fa-volume-distribution`, qui la demandait, demande désormais que le Vd
  est un volume **virtuel** ; les seuils (5 L, 15 L) restent.
- **Les listes d'inducteurs et d'inhibiteurs** se réduisent à la rifampicine, aux
  barbituriques, à la carbamazépine, à la phénytoïne et au pamplemousse (CYP 3A4)
  (partie 2, p. 10-11) : `pk-fa-inhibiteurs-inducteurs` est réécrit sur elles (trois
  trous changent : CYP 3A4, phénytoïne, barbituriques au lieu du ritonavir, du
  millepertuis et de l'alcool) ; les longues listes de 2025-26 restent dans
  `pk-qc-inducteurs` et `pk-qc-inhibiteurs`, absentes.
- **L'induction est différée d'« environ 7 jours »** (partie 2, p. 10), non plus de
  « quelques jours » : `pk-rv-inhibition-induction`, `pk-qc-inhibition-induction` B.
- **La posologie se réduit « de moitié ou d'un tiers »** chez l'insuffisant rénal
  (partie 1, p. 3), non plus « de moitié » : `pk-rv-insuffisance-renale`.
- **Le transfert actif « peut s'effectuer contre un gradient »** (partie 1, p. 10) :
  ce que seuls le cours 2023-24 et Pharmacomédicale disaient est désormais du cours ;
  les huit annales du transfert actif le citent.
- **La vancomycine** n'est plus dite anti-staphylococcique mais donnée par la bouche
  pour une décontamination intestinale, grâce à sa biodisponibilité nulle (partie 2,
  p. 2) : la question de `pk-qr-vancomycine` est réécrite.
- **Les quiz** : le ronéo 2026-27 n'en a pas ; les trois quiz de 2025-26 restent,
  leur énoncé dit « FC 2025-26 », et chaque proposition est relue sur l'année.
- **La planche du cycle entéro-hépatique** cite désormais la partie 3, p. 2, et la FC
  2025-26.

**Notes nouvelles (15)**, sur ce que le cours 2026-27 apporte :

| Note | Ce qu'elle carte |
|---|---|
| `pk-qc-choix-voie` | voie orale ou injectable : biodisponibilité, rapidité, capacité d'avaler (partie 1, p. 5-7, 10) |
| `pk-qc-passage-membranaire` | liposolubilité, poids moléculaire, vidange gastrique, intestin, placenta (partie 1, p. 9-10) |
| `pk-qc-facteurs-biodisponibilite` | tacrolimus et repas, fonction hépatique incalculable, cirrhose, bypass, tamoxifène et clopidogrel (partie 1, p. 11-12) |
| `pk-qc-forte-liaison` | la baignoire pleine, 95 → 90 % lié, seuil de 80-85 %, hypoalbuminémie (partie 2, p. 5-6 ; partie 3, p. 7) |
| `pk-qc-metabolites` | 60 % métabolisés, forme inchangée, fluoxétine, pro-médicaments, paracétamol toxique (partie 2, p. 7-8) |
| `pk-fa-induction-inhibition-risques` | inefficacité ou sur-efficacité, toxicité ou inefficacité, 7 jours, immédiat (partie 2, p. 10-11) |
| `pk-rv-codeine-sensibilite` | le bien-être sous paracétamol codéiné : arrêter, chercher le CYP2D6 (partie 2, p. 9-10) |
| `pk-qc-paracetamol` | biodisponibilité, faible liaison, glutathion, N-acétylcystéine, demi-vie de 2 h (partie 3, p. 5-6 ; partie 1, p. 11) |
| `pk-qc-codeine` | biodisponibilité 40-70 %, élimination rénale en 48 h, faible liaison, pics synchrones, dextropropoxyphène (partie 3, p. 7) |
| `pk-qc-fonction-renale` | le rein, voie principale ; accumulation ; 70 ans ; diabète et HTA (partie 3, p. 3 ; partie 1, p. 3) |
| `pk-qc-cinq-demi-vies` | T = 0,7 × Vd / CL, 5 demi-vies, 3 h et 20 h, hors ordre 1 (partie 3, p. 3-4) |
| `pk-rv-chevauchement` | chevaucher deux traitements grâce à la demi-vie (partie 3, p. 4) |
| `pk-qc-rythme-prises` | demi-vie longue ou courte, LP ou perfusion, oubli, observance (partie 3, p. 4-5) |
| `lex-hepatotoxicite`, `lex-promedicament` | deux termes du lexique (voir plus bas) |

## Ce que le cours a dicté

- **Le rouge** des trois ronéos est celui des titres du plan, et de trois consignes,
  chacune cartée : « Formule pas à connaître ! » (partie 2, p. 6 :
  `pk-fa-volume-distribution`) ; la « toxicité du paracétamol » (partie 1, p. 11 :
  `pk-qc-paracetamol`) ; « ne pas prescrire » une interaction contre-indiquée
  (partie 2, p. 10 : `pk-fa-induction-inhibition-risques`).
- **« Retenir »** : la métabolisation n'est pas systématique (partie 2, p. 7 :
  `pk-qc-metabolites` A) ; les seuils du Vd, « critère à retenir » (p. 6-7).
- **Le gris** (trois passages de la partie 2 : la conjugaison selon l'état
  physiologique et la fonctionnalisation selon le polymorphisme, p. 9 ; « ne pas
  prendre de risques », p. 10 ; « attention surtout en EHPAD », p. 11) est la voix des
  rédacteurs (décision de Vincent du 25/09) et se carte comme le reste
  (`pk-fa-metabolisme`, `pk-fa-inhibiteurs-inducteurs`). Aucun ronéo ne définit son
  gris comme hors programme.
- **Les monographies** : le paracétamol et la codéine sont lus dans leur RCP, qui
  varie d'un laboratoire à l'autre (partie 3, p. 5) ; les cartes citent le RCP de
  Paracétamol/Codéine Mylan quand il tranche.
- **Ce qui est déjà ailleurs** n'est pas recarté (plan C14) : la définition de la
  pharmacocinétique et l'ADME (`pdg-fa-adme`), la définition de la biodisponibilité
  (`pdg-qc-biodisponibilite`), le pro-médicament (`pdg-qr-pro-medicament`), la
  barrière hémato-encéphalique (`pdg-qc-bhe`), le CYP2D6 (`pdg-qc-cyp2d6`), le 5-FU et
  la DPD (`var-qc-5fu`), la chirurgie bariatrique (`var-qc-bariatrique`), la dose
  toxique du paracétamol (`var-fa-paracetamol`), l'observance (`lex-observance`).
- **Pas de carte** sur l'anecdote du suppositoire « en forme de fusée » (partie 1,
  p. 7), dite seulement dans l'explication de `pk-qc-voies`, ni sur le site qui dit
  quels médicaments s'écrasent (partie 2, p. 4).

## Ce que les annales ont dicté

Cinq questions, posées et reposées par le Pr Deplanque, les propositions changeant
de tournure d'une session à l'autre :

| Savoir | Questions |
|---|---|
| Le transfert actif (énergie, transporteur, saturation, compétition, contre le gradient) | 9 : 2024/2025 S1 Q9, 2022/2023 S1 Q.8, 2021/2022 S2 Q.8, 2020/2021 S1 Q.10, 2019/2020 S2 Q.7, 2018/2019 Q.5, 2017/2018 S2 Q.6, 2016/2017 S1 Q.4, 2015/2016 S2 Q.7 ; et le transfert passif, 2022/2023 S2 Q.8 |
| La distribution (forme libre ou liée, compétition, Vd) | 8 : 2023/2024 Q.8, 2022/2023 S2 Q.6, 2021/2022 S1 Q.10, 2020/2021 S2 Q.9, 2019/2020 S1 Q.8, 2017/2018 S1 Q.7, 2016/2017 S2 Q.7, 2015/2016 S1 Q.8 |
| La voie nasale | 8 : 2024/2025 S1 Q8, 2022/2023 S1 Q.7, 2021/2022 S2 Q.7, 2020/2021 S1 Q.9, 2019/2020 S1 Q.7, 2018/2019 Q.4, 2016/2017 S2 Q.6, 2015/2016 S1 Q.7 |
| L'élimination (rénale, biliaire, fraction libre, fonction rénale, cycle entéro-hépatique) | 8 : 2024/2025 S1 Q10, 2022/2023 S1 Q.6, 2021/2022 S1 Q.11, 2020/2021 S2 Q.8, 2019/2020 S2 Q.8, 2017/2018 S2 Q.7, 2016/2017 S1 Q.5, 2015/2016 S2 Q.8 |
| La voie orale | 4 : 2023/2024 Q.7, 2022/2023 S2 Q.7, 2019/2020 S2 Q.6, 2017/2018 S1 Q.6 |
| L'absorption (le quiz de la FC 2025-26, à deux propositions près) | 2 : 2024/2025 S1 Q11, 2023/2024 Q.6 |

Les justifications qui reviennent sont écrites une fois (constantes en tête
d'`annales.py`) ; elles citent désormais le ronéo 2026-27 là où il dit la même
chose, la FC 2025-26 ailleurs. La session 2018/2019 n'a pas de numéro de session
dans le polycopié : ses identifiants portent `1819`.

Deux notions des annales ne sont toujours dans aucun cours, et leur justification dit
d'où vient la réponse : **la voie nasale et les formes retard** (fausse dans six
sessions, vraie à la négative en 2022/2023 S1 Q.7 E : la clairance mucociliaire,
Marttin et al., Adv Drug Deliv Rev 1998, et le cours, qui ne montre de formes retard
que par voie orale) ; **la voie nasale sans premier passage hépatique** (cours 2023-24,
p. 4, et Pharmacomédicale ; le ronéo 2026-27 la dit seulement « très efficace » pour
gagner la circulation générale, partie 1, p. 8).

## Les clés qui ne sont pas reprises telles quelles

**Aucune contestée.** Les 36 clés imprimées sont reprises telles quelles : chacune a
été relue proposition par proposition contre le ronéo 2026-27, puis contre la FC
2025-26 ; aucune ne contredit le cours de l'année ni une autre session, et l'errata des
annales BMCT ne relève rien sur ce polycopié. Les quatre questions du sujet 2024/2025
n'ont pas de corrigé ; leurs clés sont déduites du cours et des sessions qui posaient
les mêmes propositions. **Le PDF du sujet porte une correction surlignée en bleu**,
officieuse et d'origine inconnue (le même surligneur reproduit 37 des 40 clés
officielles de 2023-24) : ni table ni source déclarée, une seconde opinion. Elle donne
les mêmes clés aux Q8, Q10 et Q11 ; à la Q9 elle ajoute D, que le cours contredit —
seule entrée de `CONFLITS` :

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2024/2025 S1 Q8 (`pk-an-2425s1-q8`) | aucune (sujet sans corrigé) | **BC**, `officielle=False` | 2020/2021 S1 Q.9 (AC), A et B échangées : résorption rapide, irritation possible ; ni premier passage, ni biodisponibilité nulle, ni forme retard (partie 1, p. 8 ; FC 2025-26, p. 4) |
| 2024/2025 S1 Q9 (`pk-an-2425s1-q9`) | aucune (sujet sans corrigé ; surlignée **CDE**) | **CE**, `officielle=False`, ATTENTION sur D, `CONFLITS` | 2017/2018 S2 Q.6 (CE), une tournure près : énergie et compétition ; ni gradient, ni « non saturable », ni hydrophobes seuls — le transporteur prend aussi des molécules hydrophiles, L-DOPA, calcium (partie 1, p. 9-10), et les huit sessions qui posent D la donnent fausse. La correction surlignée la donne vraie : le cours l'emporte |
| 2024/2025 S1 Q10 (`pk-an-2425s1-q10`) | aucune (sujet sans corrigé) | **BDE**, `officielle=False` | la question de 2022/2023 S1 Q.6 (BC), C retournée (« liée ») et D, E à l'affirmative : bile, fonction rénale, cycle entéro-hépatique des estroprogestatifs (partie 1, p. 3 ; partie 2, p. 9 ; partie 3, p. 2-3) ; la forme libre seule éliminée (FC 2025-26, p. 9) |
| 2024/2025 S1 Q11 (`pk-an-2425s1-q11`) | aucune (sujet sans corrigé) | **AE**, `officielle=False` | 2023/2024 Q.6 (BD) dans un autre ordre : ionisée = hydrosoluble (partie 1, p. 9) ; effets systémiques par voie pulmonaire (partie 1, p. 8 ; FC 2025-26, p. 4) |

Un point est dit sans ATTENTION dans les annales, parce que la clé est juste :
« l'élimination rénale s'effectue principalement par filtration glomérulaire »
(2019/2020 S2 Q.8 A, 2017/2018 S2 Q.7 A) est fausse selon la clé et le cours ; les
chiffres que le cours en donne sont douteux (voir plus bas), la réponse ne l'est pas.

## Les erreurs des ronéos 2026-27

Le tableau d'erreurs BMCT de la promo, vide au 11/10/2026, relève au 19/10/2026 une
seule d'entre elles, la liaison plasmatique (partie 2, p. 6) ; toutes les autres ont été
trouvées en relisant. Toutes vont dans `contenu/ERRATA_RONEOS_2026-27.md`.
Aucun ronéo n'est corrigé ; chaque erreur est portée par une carte, avec son genre.
À l'examen, on répond d'abord comme le professeur.

**Prises de notes fausses** (`ATTENTION (prise de notes)`) :

| Partie, page | Le ronéo dit | Ce qui est juste | Carte |
|---|---|---|---|
| 1, p. 10 | l'aspirine « très absorbée au niveau de l'estomac (ionisée, stable) », moins stable « dans d'autres endroits plus acides » | dans l'estomac, le plus acide, l'aspirine est surtout non ionisée, donc liposoluble et absorbée ; elle s'ionise ailleurs (partie 1, p. 9 ; figure de la FC 2025-26, p. 6) | `pk-fa-transfert-passif` |
| 1, p. 10 | « Tmax : aire sous la courbe » ; « si Cmax 15 min, efficacité au bout de 15 min » | Tmax : le temps auquel la Cmax est atteinte ; l'aire sous la courbe est l'ASC (FC 2025-26, p. 6-7) | `pk-fa-biodisponibilite` |
| 1, p. 7 | une biodisponibilité de 20 % « correspond à 1/20 » de l'IV | 20 % = 1/5 | `pk-qc-choix-voie` (E) |
| 1, p. 7 | « il est nécessaire d'aller au fond de l'ampoule rectale » pour gagner directement la circulation générale | la partie basse de l'ampoule (veines rectales moyennes et inférieures) se draine vers la veine cave ; la partie haute (veines rectales supérieures) gagne la veine porte (FC 2025-26, p. 3-4 et diapositive p. 7 ; Gray's Anatomy for Students) | `pk-qc-voies` (B), `pk-qr-hemorroidaires` |
| 1, p. 11 | chez le dénutri, la perte de glutathion, « donc pas de métabolisation du principe actif » | le glutathion neutralise le métabolite toxique, il ne métabolise pas le paracétamol ; sans lui, c'est le métabolite toxique qui s'accumule (partie 2, p. 8 ; partie 3, p. 6) | `pk-qc-paracetamol` (C) |
| 2, p. 2 | l'enveloppe de la gélule « se détruit rapidement au niveau de l'intestin » | dans l'estomac : la diapositive de la même page, la FC 2025-26 (p. 8), et la partie 2 elle-même (p. 3, la gélule d'IPP) | `pk-qc-galenique` (A) |
| 2, p. 6 | « si la liaison plasmatique est importante, ça va être diffusé dans les autres tissus » — **tableau de la promo, 19/10** | l'inverse : seule la forme libre diffuse ; un médicament fortement lié reste davantage dans le plasma (FC 2025-26, p. 9 ; partie 2, p. 5) | `pk-qc-distribution-tissulaire` (E) |
| 2, p. 6 | les 10 L de l'acide salicylique, « 2x le volume plasmatique » | le plasma fait environ 3 L ; ce sont les 5 L du sang (partie 2, p. 4) que 10 L doublent | `pk-qc-vd` (C) |
| 3, p. 2 | le médicament fixé « sur les acides biliaires », que des enzymes intestinales en séparent | le foie excrète dans la bile un conjugué glucuronide ; les β-glucuronidases bactériennes le coupent (FC 2025-26, p. 18-19 ; partie 2, p. 9) | `pk-qc-entero-hepatique` (A), `pk-fa-cycle-entero-hepatique` |

**C'est le cours lui-même** (`ATTENTION (cours)` : « À l'examen : … », puis « La
référence : … ») :

| Partie, page | Le cours dit | La référence | Carte |
|---|---|---|---|
| 2, p. 7 | la cétirizine au Vd « nul (VD = 0) », « aucune distribution cardiaque » (la diapositive : « ~ 0 », fixation « très faible » ; FC 2025-26, p. 12) | 0,50 L/kg, environ 35 L à 70 kg (RCP de la cétirizine, ANSM) | `pk-qc-vd` (E) |
| 3, p. 2 | une flore perturbée par un antibiotique rend le contraceptif moins efficace (FC 2025-26, p. 19 ; cours 2023-24, p. 14) | la FSRH (CEU, mai 2022) ne demande aucune précaution avec un antibiotique non inducteur | `pk-qc-entero-hepatique` (E) |
| 1, p. 11 ; 3, p. 6 | « la moitié des transplantations hépatiques » sont dues au paracétamol | première cause de greffe hépatique d'origine médicamenteuse en France (ANSM, 2019) ; près de la moitié des insuffisances hépatiques aiguës aux États-Unis, dont 8 % greffées (Larson et al., Hepatology 2005) | `pk-qc-paracetamol` |

**Points douteux** (`ATTENTION (douteux)`), dits dans la carte sans changer sa clé :

| Partie, page | Le point | Carte |
|---|---|---|
| 1, p. 10 | l'aire sous la courbe « de chaque voie serait la même » : vrai d'un médicament complètement résorbé, comme celui de la figure des courbes (FC 2025-26, p. 7) ; faux en général, F étant le rapport des aires (partie 1, p. 7 : 20 % par voie orale) | `pk-qc-choix-voie` (D) |
| 3, p. 2 | l'élimination rénale « passive à 20 % et active à 80 % », le cours lui-même trois ans de suite ; aucune source ne donne cette répartition, qui est celle de la fraction de filtration ; elle dépend du médicament | `pk-qc-renal` (E) |
| 3, p. 3 | « principalement la formule de Cockcroft », le MDRD « plus actuel » : pour diagnostiquer et suivre, la CKD-EPI a remplacé la MDRD (HAS, 2011 ; Vidal, 2022 : Cockcroft « aujourd'hui abandonnée au profit de la formule CKD-EPI ») ; pour adapter les doses, la HAS garde Cockcroft (étude CLEAR, Néphrol Ther 2020), l'argument du cours | `pk-rv-cockcroft-mdrd` |
| 3, p. 4 | demi-vie de 20 h : « environ une semaine ou plus » pour l'élimination : 5 × 20 h = 100 h, un peu plus de 4 jours, comme le calcule la partie 2 (p. 8) ; la proposition de la carte dit 4 jours, vraie | `pk-qc-cinq-demi-vies` (D) |
| 1, p. 11 | le tacrolimus « à prendre 3 fois par jour » : deux prises par jour (Prograf) ou une (formes LP) ; le repas réduit l'absorption d'environ un tiers, non de 50 % (notice de Prograf, FDA) | `pk-qc-facteurs-biodisponibilite` (A) |
| 1, p. 11 | les céphalosporines en exemple de premier passage, « ATB qui ne peuvent être seulement injectés » : beaucoup se prennent par la bouche ; les injectables le sont faute d'absorption intestinale | `pk-qc-facteurs-biodisponibilite` |
| 1, p. 9 | la forme ionisée « pas stable », qui doit « attraper des électrons » : elle est chargée et hydratée, d'où son mauvais passage | `pk-fa-transfert-passif` |
| 2, p. 3 | la forme LP « résistante à ce qui l'élimine », qui « leurre les systèmes d'élimination » : elle étale la libération, pas l'élimination (FC 2025-26, p. 8) | `pk-qc-galenique` |
| 2, p. 4 | les aminosides en exemple de « grande distribution », « uniquement en voie IV » : Vd d'environ 0,25 L/kg, accumulation par captation active dans le rein et l'oreille ; voies IV et IM | `pk-rv-aminosides` |
| 2, p. 8 | la fluoxétine à demi-vie de 20 h, son métabolite de 120 h : 1 à 3 jours (4 à 6 en chronique) pour la fluoxétine, trop court ; 4 à 16 jours pour la norfluoxétine, dont 120 h est le bas (notice de Prozac) | `pk-qc-metabolites` (C) |
| 2, p. 8 | la codéine « pas un pro-médicament », « 15 % » transformés en morphine : le ronéo de pharmacodynamie la dit pro-médicament, comme la littérature (CPIC) ; environ 10 % (RCP, et partie 3, p. 7) | `pk-qc-metabolites` |
| 2, p. 10 | les inducteurs « stimulent tout le monde », « toutes les enzymes » : un inducteur en stimule plusieurs, pas toutes ; le CYP2D6 n'est guère inductible (Zhou et al., Curr Med Chem 2009) ; à l'examen, « non spécifique » (FC 2025-26, p. 16) | `pk-rv-inhibition-induction` |
| 3, p. 6 | pour « mesurer l'intoxication au paracétamol », chercher le métabolite urinaire : on dose la paracétamolémie, nomogramme de Rumack-Matthew (Manuel MSD) | `pk-qc-paracetamol` |
| 3, p. 7 | « 50 à 70 % de la codéine serait non métabolisée », « 25 à 35 % liée » parmi ce qui est éliminé : environ 60 % éliminés en codéine-6-glucuronide, 12 % inchangés (Chen et al., Br J Clin Pharmacol 1991) ; 25-35 %, c'est la liaison aux protéines | `pk-qc-codeine` |
| 3, p. 7 | la morphine à « T = 6h » : 1,5 à 2 h chez le sujet sain (notice de la morphine injectable, Pfizer) | `pk-qc-codeine` (B) |
| 3, p. 7 | le dextropropoxyphène à pic de « 4 à 5h » : 2 à 2,5 h (notice de Darvocet-N, FDA) ; c'est sa demi-vie, 6 à 12 h, qui le décalait du paracétamol | `pk-qc-codeine` (E) |

## Les erreurs du Ronéosaure 2025-26

Le Ronéosaure n'est pas le ronéo de l'année : ses erreurs sont dites par un
**ATTENTION nu**, sans genre, qui nomme la sorte d'erreur et la source ; elles
n'entrent pas dans `contenu/ERRATA_RONEOS_2026-27.md`. Celles que le ronéo 2026-27 redit
ont pris le genre de l'année (cétirizine, Cockcroft, antibiotique et pilule, 20/80 %).
Restent :

| Page | Le Ronéosaure dit | Sorte | Carte |
|---|---|---|---|
| 6 | « plus l'écart est important entre pK et le pH, plus la molécule est ionisée » (déjà en 2023-24) | le cours lui-même ; non repris en 2026-27 | `pk-fa-transfert-passif` |
| 8 | pro-médicaments : « l'aspirine, la morphine, la codéine, des bêtabloquants… » | prise de notes (la liste du fort premier passage, diapositive p. 7) | `pk-qc-epph` (D) |
| 16 | la méfloquine parmi les inducteurs (déjà en 2023-24) | le cours lui-même (RCP de Lariam : ni inducteur ni inhibiteur) | `pk-qc-inhibiteurs` (B) |
| 20 | l'ionisation « conditionne leur hydro- ou hypo-solubilité » | prise de notes (errata de la promo 2025-26 : liposolubilité) | `pk-qc-renal` (D) |

Sans ATTENTION : le « centre général de pharmacovigilance » (p. 11, le centre
régional) ; la demi-vie de l'amiodarone « ≈ 21 jours » (le RCP dit 20 à 100 jours,
dans `pk-fa-plateau`) ; un désaccord d'années sur le cerveau, « tissu difficile
d'accès » en 2025-26 (p. 4), « irrigué en priorité » en 2026-27 (partie 1, p. 2) —
les deux sont justes, l'un parle de la barrière, l'autre de l'irrigation, et
`pk-qc-distribution-tissulaire` D le dit.

## Les schémas et les figures

**Dix-huit figures de la FC 2025-26**, extraites en PNG, déclarées dans `IMAGES` avec
leur page. Le ronéo 2026-27 n'a qu'une figure à lui, **la formule de la demi-vie**
(`demi-vie-formule.png`, partie 3, p. 3, `pk-qc-cinq-demi-vies`, `pk-rv-chevauchement`) ;
les cinq autres images de la partie 2 (galénique p. 2, distribution p. 5, formule du Vd
p. 6, antihistaminiques p. 7, biotransformation p. 9) sont les diapositives de la FC
2025-26, identiques et trois fois moins nettes (235 à 400 px de large) : on garde la
version nette, et la légende cite les deux pages. La partie 2 finit sur une image sans
rapport avec le cours, non reprise.

**Un schéma cliquable** (`schemas.py`), `nephron.svg`, avec sa version légendée en
correction : la filtration glomérulaire, la sécrétion tubulaire, la réabsorption
proximale, la réabsorption distale (4 zones). Le ronéo 2026-27 ne détaille plus le
néphron : la carte (`pk-zo-nephron`) est absente du cours 2026-27.

**Une planche à légender** (`pk-pl-entero-hepatique`) : le cycle entéro-hépatique,
redessiné en SVG d'après la FC 2025-26 (p. 18-19), relu sur la partie 3 (p. 2) ; sept
numéros, trois intrus.

**69 QCM sur 72 illustrés (96 %)** (les quatre du sujet 2024/2025 reprennent la
figure de leur question sœur). Sans figure : `pk-qc-inducteurs`,
`pk-qc-inhibiteurs` et `pk-qc-inhibition-induction`, que rien ne dessine.

## Le lexique

Dix termes, chacun avec son **origine grecque ou latine** ; pages mesurées dans le
texte des trois ronéos 2026-27 (en-têtes exclus), puis de la FC 2025-26 :

| Terme | Origine | Pages 2026-27 |
|---|---|---|
| Galénique | grec Galēnós, par le latin Galenus (Galien) | partie 1 p. 2 ; partie 2 p. 2, 3, 4 ; partie 3 p. 8, 9 |
| Sublingual | latin sub + lingua | partie 1 p. 8 ; partie 2 p. 4 ; partie 3 p. 8 |
| Lipophile | grec lípos + phílos | partie 1 p. 9 |
| Hydrosoluble | grec húdōr + latin solubilis | partie 1 p. 9 |
| Biotransformation | grec bíos + latin transformatio | partie 2 p. 9, 10 ; partie 3 p. 6 |
| Glucuronoconjugaison (« glycurono-conjugaison ») | grec glukús + oûron + latin conjugatio | partie 2 p. 9 ; partie 3 p. 6 |
| Entéro-hépatique | grec énteron + hêpar | partie 3 p. 2 |
| Clairance | latin clarus, par l'anglais clearance | partie 1 p. 5 ; partie 3 p. 3 |
| **Hépatotoxicité** (nouveau) | grec hêpar + toxikón | partie 3 p. 6 |
| **Promédicament** (nouveau) | latin pro + medicamentum | partie 1 p. 12 ; partie 2 p. 2, 8, 10, 11 |

Les deux termes nouveaux reprennent des racines de la table commune (`hépat(o)-`,
`tox(i)-`, `pro- (latin)`, qui cite la FC de sémantique 2/2, p. 10) ; une racine
(`medicamentum (latin)`) et les deux termes sont proposés à `etymologies.json`
(brouillon `etym/bmct_pharmacocinetique.json`), que Claude fusionne ; les textes du
lexique sont déjà écrits dans la forme que `appliquer_etymologies.py` produirait.
Aucun des deux n'existait dans un autre paquet.

## Absent du cours 2026-27

Quatorze cartes **entières** que les trois ronéos du 28/09/2026 ne portent plus. Elles
restent, citent la FC n°2 2025-26 (sans `page`, donc avec le badge « Cours 2025-26 »),
prennent le tag `absent-2026` et la phrase « Absent du cours 2026-27 » en tête de
l'explication (`ABSENTS_2026`, `ORIGINE_ABSENTS`) :

| Carte | Ce que le cours 2026-27 ne dit plus |
|---|---|
| `pk-fa-rein`, `pk-zo-nephron` | le détail du néphron : filtration glomérulaire et DFG, sécrétion proximale, réabsorption des formes non ionisées, 80 % proximale et 20 % distale (il ne garde que « passive à 20 %, active à 80 % ») |
| `pk-fa-ordres`, `pk-qr-ordre-zero` | la cinétique d'ordre 0 et l'alcool (il dit seulement que hors ordre 1 les règles ne valent plus) |
| `pk-qc-inducteurs`, `pk-qc-inhibiteurs` | les longues listes d'inducteurs et d'inhibiteurs, et la méfloquine |
| `pk-qc-voies-accessoires` | les effets indésirables des voies accessoires (zopiclone, phénytoïne, amiodarone, rifampicine, eucalyptus) |
| `pk-qr-seuil-pulmonaire` | le seuil de 2 µm |
| `pk-qr-ciclosporine` | la ciclosporine liée aux éléments figurés du sang |
| `pk-qr-glucuronidases` | les β-glucuronidases nommées (il dit « enzymes intestinales ») |
| `pk-rv-visiteur` | l'anecdote du visiteur médical |
| `pk-rv-macrolides-ergot` | les macrolides et l'ergot de seigle |
| `pk-rv-carbamazepine-pilule` | la carbamazépine et la pilule (la carbamazépine reste nommée parmi les inducteurs) |
| `pk-rv-digoxine-amiodarone` | la digoxine et l'amiodarone oubliées deux jours |

## Décisions prises en route

- **Une carte n'est confirmée que si sa notion centrale est dans le cours de
  l'année** ; ses propositions de 2025-26 le disent une à une. Une carte dont la
  notion centrale a disparu est absente, même si l'une de ses propositions est encore
  enseignée (`pk-qc-inducteurs` A, la phénytoïne).
- **Les trous changés** : `pk-fa-volume-distribution` c1 (la formule devient le volume
  virtuel), `pk-fa-inhibiteurs-inducteurs` c3, c7, c8. Les autres textes à trous
  gardent leurs trous ; ceux qui viennent de 2025-26 le disent dans l'explication
  (« simultanément », le pK, la prise unique, les β-glucuronidases).
- **Les figures identiques** restent celles de la FC 2025-26, plus nettes, la légende
  citant la page du ronéo 2026-27 : la même diapositive, en lisible.
- **`EXAMENS` n'est pas déclaré**, comme dans la pharmacodynamie générale.
- **La Q.9 de 2023/2024** (métabolisme) vit dans `pdg-an-2324-q9` : 36 annales sur 37.
- **Les trois quiz du professeur** gardent `officielle=True` : leur clé est celle que le
  ronéo 2025-26 imprime.

## À relire

**Aucune carte `a-relire`** : chaque note de cours cite une page de l'une des trois
parties du ronéo 2026-27 ou, pour les absentes, de la FC 2025-26 ; chaque annale du
polycopié a une clé imprimée vérifiée, et les quatre du sujet 2024/2025 une clé
déduite page par page — pour la voie nasale, des mêmes sources que ses sept sessions,
dont les clés imprimées concordent. Reste à Vincent :

- confirmer qui a fait le cours (le Pr Gautier pour les trois heures ?) ;
- les trois points « le cours lui-même » (cétirizine, antibiotique et pilule,
  paracétamol et greffes) et les points douteux des 20/80 % et de Cockcroft : à garder
  tels quels si le partiel les pose ainsi.

## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026)

L'échelle du pilote de l'immunité innée, étendue à la BMCT pour l'examen du 4/11 (Vincent, 16/10 : « on continue pour les chapitres que je vais avoir à l'examen »). Sous les annales, 29 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 6 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `voies-administration` | 8 | 1 | 12 |
| `absorption` | 10 | 2 | 12 |
| `distribution` | 4 | 1 | 8 |
| `elimination` | 7 | 2 | 8 |

**Le schéma** `ech-pharmacocinetique`, « La pharmacocinétique · entrer, passer, se distribuer, sortir », donne 76 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_PHARMACOCINETIQUE`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```

## Questions pour Vincent

- (11/10) Qui a fait le cours ? L'en-tête des parties 1 et 2 nomme le Pr Deplanque, mais la partie 1 parle de « la Pr » et la partie 2 du cours donné par « sa remplaçante » ; la partie 3 nomme le Pr S. Gautier. CHAPITRE.semaine dit « 28/09/2026 · Pr Deplanque et Pr Gautier » : faut-il ne garder que le Pr Gautier ?
- (11/10) Les 5 diapositives de la partie 2 sont celles de la FC 2025-26, en 235 à 400 px de large. Les versions nettes de 2025-26 sont gardées, la légende citant les deux pages. Préfères-tu les images de la ronéo 2026-27 telles quelles ?
- (11/10) La partie 2 dit la codéine « pas un pro-médicament », la pharmacodynamie générale 2026-27 dit le contraire : c'est un point douteux, et aucune carte ne pose la question. Sais-tu lequel des deux professeurs pose ce genre de QCM au partiel ?
- (11/10) pk-qc-cinq-demi-vies D dit désormais « environ 4 jours » (vrai) pour 5 demi-vies de 20 h, alors que la partie 3 écrit « environ une semaine ou plus ». Si le Pr Gautier pose la question avec sa propre formule, la réponse attendue pourrait différer.
