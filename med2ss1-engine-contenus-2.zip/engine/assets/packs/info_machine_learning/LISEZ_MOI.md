# Introduction au machine learning — paquet Informatique médicale

80 notes, 128 cartes. Chapitre `chap-ue-info-medicale-fc5` de l'UE Informatique
médicale, huitième de l'UE. Cours du **Pr Grégoire Ficheur, le 02/12/2025, de
9 h 30 à 11 h 30**, dans le **Ronéosaure 2025-26** (FC n°8, 20 pages) ; les
annales du polycopié « FC n°5 - Machine learning » du Ronéosaure 2024-25 (onze
sessions) et les deux questions de 2024/2025 que la fiche reproduit (p. 20).
Examen : partiel du mercredi 16 décembre 2026.

**Fiche provisoire** (C15, décision de Vincent du 02/10) : le cours de l'année
2026-27 n'est pas encore paru. Chaque carte de cours cite la FC 2025-26 à sa
page et porte le badge « Cours 2025-26 » ; le ronéo 2026-27 la corrigera quand
il sortira. `donnees.py` porte `ANNEE_COURS = "2025-26"`.

**L'identifiant vient du squelette, qui numérote à la 2024-25** : son `fc5`
« Introduction au machine learning » est la FC n°8 de 2025-26. Le chapitre
garde cet identifiant (un identifiant inventé créerait un doublon chez les
collègues) et prend l'ordre 8 ; le squelette, lui, le met à l'ordre 5.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 47 | 47 |
| QRU | 1 | 1 |
| Texte à trous | 9 | 53 |
| QROC | 10 | 10 |
| Recto-verso | 5 | 5 |
| Schéma cliquable | 1 | 5 |
| Planche à légender | 1 | 1 |
| Lexique | 6 | 6 |

Dont **30 annales** sur 12 sessions : 28 QCM du polycopié 2024-25 (2017/2018 S2
à 2023/2024 S1) et les 2 QCM de 2024/2025 de la fiche, p. 20. Dix-huit QCM de
cours.

Sept thèmes, dans l'ordre du cours, toutes clés nouvelles (plan C15) ; leurs
libellés restent à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) :

| Clé | Libellé | Notes | dont annales |
|---|---|---|---|
| `ml-definition` | Machine learning : définition, prédire ou expliquer | 19 | 9 |
| `categories-apprentissage` | Supervisé, non supervisé, renforcement | 6 | 1 |
| `arbres-decision` | Arbres de classification | 10 | 3 |
| `reseaux-neurones` | Réseaux de neurones et deep learning | 16 | 6 |
| `non-supervise` | Règles d'association et classification hiérarchique | 2 | 0 |
| `evaluation-modeles` | Évaluer un modèle supervisé | 7 | 0 |
| `ia-sante` | IA en santé : niveaux, systèmes experts, usages | 14 | 11 |

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-info-ml-2526` — Ronéosaure, « FC n°8 informatique introduction au machine learning » (20 p.) | 2025-26 | le cours ; `SRC["fiche"]`, ses figures ; la source des deux questions de 2024/2025 (`SRC["sessions"]`) |
| `src-annales-fc-n5-machine-learning` — « FC n°5 - Machine learning » (10 p.) | 2024-25 | onze sessions, 28 QCM, table de corrections p. 10 |

La déclaration du polycopié n'a que les champs communs (id tiré du nom du
fichier, `kind`, `titre` = le nom sans extension, espace finale comprise,
`chemin_relatif`, `auteur`) : aucun autre chapitre ne le cite. Lus en appoint,
sans être déclarés, et cités dans le texte des cartes : le cours 2024-25 (FC
n°5) et le cours 2023-24 (Charonéo, n°6 : système expert p. 3, perceptron
simple p. 11, milliers d'exemples p. 13, FDA 2018 et responsabilité p. 15) ;
l'errata des cours 2025-26 et celui des annales (vides pour ce cours) ;
l'errata des cours 2024-25 (le premier exemple « non supervisé » qui était
supervisé : sans objet en 2025-26, l'exemple est la sclérodermie).

Les en-têtes des ronéos, des erratas et du polycopié portent des noms
d'étudiants : aucun n'est repris.

## Ce que le cours a dicté

- **Le gris du ronéo** n'est que la voix des rédacteurs : les titres de
  sous-parties et une anecdote (p. 12). La seule consigne du professeur est la
  terminologie de la p. 18, « pas à retenir selon le prof » : son tableau (une
  maladie rare, une spécificité à 99 %) et la F-mesure ne sont pas cartés. Sont
  cartés, parce que le cours les dit hors de ce passage ou y insiste : rappel =
  sensibilité, précision = VPP (VII.A), et la recommandation du professeur —
  sensibilité et spécificité, quand la VPP dépend de la prévalence (p. 19).
- **Les sections** suivent le plan de la p. 1 : le corps du ronéo renumérote
  « IV » les méthodes non supervisées et le renforcement, « V » l'évaluation.
- **Ce qui n'est pas carté ici** (plan C15, 0.5) : le test diagnostique, la
  courbe ROC, la sensibilité, la spécificité et les valeurs prédictives
  (biomédecine quantitative) ; l'IA générative pour chercher l'information
  (FC n°5, information probante) ; la responsabilité de droit commun (FC n°7).
  Les cartes les citent.

## Ce que les annales ont dicté

| Session | N° | Clé | Thème | Remarque |
|---|---|---|---|---|
| 2023/2024 S1 | Q6 | ABDE | `ml-definition` | C « pas en lien avec la statistique », faux (p. 2) |
| 2023/2024 S1 | Q7 | ABCD | `reseaux-neurones` | E « pas utilisés en Machine Learning », faux |
| 2022/2023 S1 | Q13 | ABCDE | `categories-apprentissage` | E réseaux de neurones supervisés (IV, p. 8) |
| 2022/2023 S2 | Q5 | ABCDE | `ml-definition` | |
| 2022/2023 S2 | Q6 | ABCDE | `arbres-decision` | Khi-2 (p. 8) ; régression logistique supervisée |
| 2022/2023 S2 | Q13 | BC | `ia-sante` | niveaux d'IA, première forme — hors cours, `a-relire` |
| 2021/2022 S1 | Q7 | ABCDE | `ml-definition` | |
| 2021/2022 S1 | Q8 | ABCDE | `arbres-decision` | |
| 2021/2022 S1 | Q16 | BC | `ia-sante` | niveaux d'IA, première forme — `a-relire` |
| 2021/2022 S2 | Q5 | ABCDE | `ml-definition` | |
| 2021/2022 S2 | Q6 | ABCDE | `arbres-decision` | |
| 2021/2022 S2 | Q13 | BC | `ia-sante` | niveaux d'IA, première forme — `a-relire` |
| 2020/2021 S1 | Q6 | BCD | `ia-sante` | niveaux d'IA, seconde forme — `a-relire` |
| 2020/2021 S1 | Q16 | ABCDE | `ml-definition` | |
| 2020/2021 S1 | Q17 | ABCDE | `reseaux-neurones` | |
| 2020/2021 S2 | Q3 | B | `ia-sante` | IA en santé — `a-relire` |
| 2020/2021 S2 | Q11 | BCD | `ia-sante` | niveaux d'IA, seconde forme — `a-relire` |
| 2019/2020 S1 | Q. 12 | B | `ia-sante` | = 2020/2021 S2 Q3 — `a-relire` |
| 2019/2020 S1 | Q13 | ABCD | `ia-sante` | applications de l'IA ; A point douteux (ECG) |
| 2019/2020 S1 | Q15 | **ABCDE** (imprimé ABCD) | `ml-definition` | **conflit**, `officielle=False` |
| 2019/2020 S1 | Q16 | ABCD | `reseaux-neurones` | D perceptron simple ; E « moins d'exemples qu'un humain », faux (p. 3) |
| 2019/2020 S2 | Q6 | BCD | `ia-sante` | niveaux d'IA, seconde forme — `a-relire` |
| 2019/2020 S2 | Q16 | ABCDE | `ml-definition` | |
| 2019/2020 S2 | Q17 | ABCDE | `reseaux-neurones` | |
| 2018/2019 S1 | Q19 | ABCDE | `ml-definition` | |
| 2018/2019 S1 | Q20 | ABCDE | `reseaux-neurones` | E FDA (cours 2023-24, p. 15 ; marquage CE, p. 15) |
| 2017/2018 S2 | Q9 | BCD | `ia-sante` | niveaux d'IA, seconde forme — `a-relire` ; « Session 1 » dans la table |
| 2017/2018 S2 | Q10 | ABDE | `ia-sante` | systèmes experts (cours 2023-24, p. 3 ; FC8 p. 2, 10) |
| 2024/2025 | 1re question (p. 20) | BCDE | `ml-definition` | clé de la fiche ; A « apprentissage non-automatique », faux |
| 2024/2025 | 2e question (p. 20) | BCDE | `reseaux-neurones` | clé de la fiche ; A arbres « non supervisés », faux |

Ce qui revient : la **définition du machine learning**, mot pour mot dans neuf
sessions, piégée une fois en C (2023/2024) et une fois en A (2024/2025) ; les
**méthodes supervisées** (arbres, Khi-2, régression logistique, réseaux,
boîte noire), trois fois la même question ; le **perceptron simple**, trois
fois. Chaque session a sa carte, et l'explication renvoie aux autres.

**Onze questions sont hors du cours 2025-26** (section 9 du plan C15) : les
« niveaux » d'intelligence artificielle (sept sessions, en deux formes), l'IA en
santé (deux sessions, même énoncé), les applications de l'IA et les systèmes
experts. Aucun ronéo ne les enseigne en entier depuis 2023-24 : les niveaux
d'IA ne sont dans aucun des trois ; le cours 2023-24 garde le système expert
(p. 3), la responsabilité du médecin et la FDA (p. 15). Elles sont cartées
ici, clé imprimée (aucune contradiction entre sessions), thème `ia-sante`, et
leur explication commence par « Notion d'un cours antérieur », dit laquelle et
ce que les ronéos 2023-24 à 2025-26 en gardent, puis que la clé est celle de
la table de corrections. Chaque
proposition est justifiée par ce que le cours en éclaire — programmer contre
apprendre (p. 2), règles expertes (p. 10), applications (p. 14-15), FC n°1
(p. 2, 9-10), FC n°7 (p. 18) — ou par la littérature (MYCIN ; van der Sijs,
JAMIA 2006 ; Bates, JAMA 1998 ; Schläpfer et Wellens, JACC 2017). Les neuf
dont une proposition ne se justifie que par la clé portent `a-relire`.
`ABSENTS_2026` n'est pas employé : sa mention parle du cours 2026-27, qu'on ne
connaît pas encore (question 1 ci-dessous).

## Les erreurs du ronéo 2025-26

Le Ronéosaure n'est pas le ronéo de l'année : chaque erreur est portée par un
**ATTENTION nu** dans la carte qui tient la notion, la sorte dite dans le texte,
et rien n'entre dans `contenu/ERRATA_RONEOS_2026-27.md`. L'errata de la promo
2025-26 est vide pour ce cours.

| Page | Le ronéo dit | Retenu | Sorte | Carte |
|---|---|---|---|---|
| 1 | « 02 / 12 / 2006 » | 02/12/2025 | coquille | la note de la source, sans carte |
| 3 | après la significativité, « interpréter la valeur de la p-valeur : est-ce que le coefficient est grand ou petit ? » | la p-valeur dit si le coefficient diffère de 0 ; l'effet se lit sur le coefficient et son intervalle de confiance | prise de notes | `mla-qc-predire` C |
| 4 | « SNIP » ; « qu'il n'y ait que 10 variables » puis « une liste de 12 variables » | SNP ; un seul nombre, celui de la consigne | coquilles | `mla-fa-alzheimer` |
| 10 | « Années 60 : […] forte déception, réduction des budgets → hivers de l'IA » | la diapositive de la même page : « Début des années 1980 : Artificial Intelligence Winter » ; les historiens comptent deux hivers, vers 1974-1980 et à partir de 1987 | prise de notes imprécise | `mla-fa-historique` |
| 13 | « George Hinton » | Geoffrey Hinton | coquille | `mla-fa-historique`, `mla-qc-imagenet` |
| 13 | « trouver sur 5 catégories la catégorie la plus probable » ; « la prédiction de 1000 images » | 1 000 catégories ; erreur top-5 : la bonne catégorie parmi les cinq que propose le réseau (Russakovsky et al., IJCV 2015) | prise de notes | `mla-qc-imagenet` |
| 15 | le réseau du mélanome a « à peu près les mêmes résultats » que le dermatologue sénior | l'article projeté (Haenssle et al., Ann Oncol 2018) le trouve meilleur que la plupart des 58 dermatologues, ses 30 experts compris en moyenne | point douteux | `mla-qc-sante-image` A |
| 17 | « jeux de goal » | le jeu de go ; l'équipe lilloise est sans doute celle de Rémi Coulom (recherche arborescente Monte-Carlo, Lille 3 et Inria, 2006) | coquille | `mla-qc-renforcement` (ATTENTION dans l'explication) |
| 16 | Amazon : « ce n'est pas fait par une machine mais par des humains » | — | point douteux, sans carte (aucune n'en dépend) | — |

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2019/2020 S1 Q15 | ABCD | **ABCDE**, `officielle=False` | E est mot pour mot l'item E de huit autres sessions, toujours donné vrai (sept fois par la table, une fois par la ronéo 2025-26 p. 20), et la définition du cours (p. 6) ; une lettre tombée de la table. ATTENTION dans la justification de E, `CONFLITS` |

Toutes les autres clés sont reprises telles quelles. Un point est discuté dans
la carte (ATTENTION, `CONFLITS`) sans changer la clé :

| Question | Clé | Le point | À l'examen |
|---|---|---|---|
| 2019/2020 S1 Q13 A | ABCD | « l'interprétation automatisée des électrocardiogrammes donne des résultats médiocres » : jugement sévère — fiable pour le rythme sinusal, souvent fausse pour les troubles du rythme et de la conduction (Schläpfer et Wellens, JACC 2017) | vrai, comme la clé |

Les clés des deux questions de 2024/2025 sont celles de la fiche (« Réponse :
BCDE »), sans table de corrections ; l'explication le dit. La session
2017/2018 s'appelle « Session 2 » dans les énoncés, « Session 1 » dans la
table : elle est gardée comme les énoncés, S2, et les deux cartes le disent.

## Les schémas et les figures

**Quatorze figures de la FC 2025-26**, extraites en PNG (captures de
diapositives et d'articles projetés, réduites à 1 000 px de large et à
256 couleurs, sauf le perceptron, gardé en couleurs vraies pour la planche) :
l'arbre (p. 8), l'historique des réseaux (p. 10), un réseau (p. 11), le
perceptron et ImageNet (p. 13), le mélanome (p. 15), l'évaluation par la ROC et
les règles d'association (p. 16), la CAH et le dendrogramme (p. 17), rappel et
précision (p. 18), la rétinopathie, l'expert sur la ROC et la cohorte de
validation (p. 19). La photo du tableau noir de la p. 11 n'est pas reprise.

**Un schéma cliquable** (`schemas.py`), avec sa version légendée en correction :

| Fichier | Ce qu'on clique | Pourquoi ce dessin |
|---|---|---|
| `arbre-classification.svg` | la racine, le nœud interne, la feuille où tombe un patient à 38,4 °C, à 37 °C la gorge irritée, à 37 °C la gorge normale (5 zones) | l'arbre de la p. 8, conditions écrites et feuilles vides : on le descend comme le cours le demande (p. 9), et la correction donne les trois règles en OU exclusif (p. 10) |

**Une planche à légender**, `mla-pl-perceptron` (la figure de la p. 13, une
image : `planche_depuis_image.py`) : variable explicative (les trois entrées
partagent le n°1), coefficient (n°2, les trois traits), seuil, sortie binaire,
nœud ; intrus : p-valeur, couche cachée, feuille de l'arbre. L'aperçu de
contrôle a été regardé : deux restes du « o » de la formule ont été blanchis.

**Deux figures redessinées** pour les corrections : `categories-ml.svg` (la
définition et les trois catégories, p. 2 et 5-7) et `programmer-apprendre.svg`
(programmer des règles ou apprendre des données, p. 2 et 10 ; le système expert
d'après le cours 2023-24, p. 3), qui illustre les onze annales d'IA.

**44 QCM sur 48 illustrés (92 %)** — 14 sur 18 du cours, les 30 annales —, 60
notes sur 80. Sans figure : `mla-qc-predire`, `mla-qc-epidemio-ml`,
`mla-qc-llm`, `mla-qc-sante-texte` (aucune figure du ronéo ne montre ce
qu'elles demandent).

## Le lexique

Six termes, ceux du plan C15 moins un ; aucun n'existait (vérifié contre les
`lex-*` de tous les paquets et des chapitres écrits en parallèle). Pages
mesurées dans le texte de la FC 2025-26 (en-têtes et page de plan exclus) :

| Terme | Origine | Pages |
|---|---|---|
| Algorithme | ancien français algorisme (arabe al-Ḫuwārizmī), croisé avec le grec arithmós | 2, 4-8, 15-19 |
| Perceptron | latin perceptio + grec -tron (mot de Rosenblatt) | 11 |
| Explicabilité | latin explicabilis + -itas | 12 |
| Euclidien | grec Eukleídēs | 17 |
| Élagage | élaguer (ancien nordique laga) + -age | 8 |
| Supervisé | latin médiéval supervidere, par l'anglais to supervise | 5-8, 16, 18-20 (« supervisées » compris) |

**Surajustement**, prévu par le plan C15, n'est pas repris : le chapitre de
pharmacovigilance de biomédecine quantitative (`biostat_phase_4_eim`) le tient
déjà (`lex-surajustement`), qui le carte aussi. « Algorithme » figure aussi dans
les FC n°4, 6 et 7 de l'UE ; seules les pages de la FC n°8 sont citées. Les
racines nouvelles (`algorisme (ancien français)`, `arithm(o)-`,
`percipere (latin)`, `-tron`, `explicare (latin)`, `Eukleidês (grec)`,
`laga (ancien nordique)`, `super- (latin)`, `videre (latin)`) et les six termes
sont proposés à la table commune (`etymologies.json`, par le brouillon
`etym/info_machine_learning.json`), vérifiés sur le TLFi, le Bailly, le Gaffiot
et le Wiktionnaire ; les textes du lexique sont déjà écrits dans la forme que
`appliquer_etymologies.py` produirait. `super- (latin)` cite la FC de
sémantique 2/2, p. 9 (« super- / supra- : au-dessus de »), ajouté au
regroupement du 03/10. Deux origines ne sont ni grecques ni
latines, et le disent : algorithme (arabe, refait sur le grec) et élagage
(norrois, selon le TLFi).

## Décisions prises en route

- **Les onze annales d'IA** sont cartées ici, clé imprimée, et le disent
  (question 1).
- **`EXAMENS` n'est pas déclaré** (convention de BMCT) : le partiel du 16/12 se
  règle dans l'application.
- **Les questions répétées** d'une session à l'autre ont chacune leur carte,
  l'explication renvoie aux autres.
- **La terminologie « pas à retenir »** (p. 18) n'a pas de carte ; « rappel =
  sensibilité, précision = VPP » en a deux, parce que le cours le dit en VII.A.
- **Le Nobel de Hinton** : le cours le donne seul ; les cartes ajoutent qu'il
  est partagé avec John Hopfield, sans en faire une question.
- **Les trois règles de l'arbre** gardent la numérotation du ronéo (p. 10) :
  1, la fièvre → malade ; 2, sans fièvre, gorge normale → bien portant ; 3, sans
  fièvre, gorge irritée → malade. Le schéma légendé et les notes des zones les
  citent ainsi (la relecture a remis dans cet ordre la légende du schéma, qui
  inversait 2 et 3).

## Questions pour Vincent

1. Onze annales d'IA (niveaux d'IA, systèmes experts, IA en santé, 2017 à
   2023) ne sont enseignées par aucun ronéo depuis 2023-24. Elles sont cartées
   ici, clés imprimées, en disant qu'elles viennent d'un cours antérieur, neuf
   d'entre elles avec `a-relire`. Les garder ainsi, ou les laisser de côté ?

## À relire

**Neuf cartes `a-relire`**, les annales des niveaux d'IA et de l'IA en santé
(`A_RELIRE` de `donnees.py`) : le nombre de niveaux, la définition du niveau 2
« créer ses propres mécaniques » et celle du niveau 5 ne se justifient que par
la clé ; le cours qui les enseignait n'est pas dans le Ronéosaure. Le tag se
retire quand Vincent aura tranché, ou qu'un cours les définira. Reste aussi :

- quand le ronéo 2026-27 paraîtra, relire chaque carte sur lui et retirer le
  badge « Cours 2025-26 » ;
- `copier_les_cours.py` avec le dossier `…/examen décembre` du Ronéosaure
  2025-26, hors du bac à sable, pour que la fiche s'ouvre dans l'application.


## L'échelle : Simple → Moyen → Annale (C20, 18/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 16 décembre. Sous les annales, 23 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 5 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `ml-definition` | 5 | 1 | 9 |
| `categories-apprentissage` | 1 | 1 | 1 |
| `arbres-decision` | 4 | 1 | 3 |
| `reseaux-neurones` | 8 | 1 | 6 |
| `ia-sante` | 5 | 1 | 11 |

**Le schéma** `ech-machine-learning`, « Le machine learning · définition, catégories, méthodes », donne 59 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_MACHINE_LEARNING`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Source déclarée en plus** : `src-fc-info-sante-2526`, à l'identique de `info_sante`, pour `mla-ech-s23` (l'alerte quand une prescription dépasse la dose maximale, FC n°1 p. 2). Les trois assistants d'annales (`_niveaux_forme1`, `_niveaux_forme2`, `_ia_sante`) prennent `**extra`, par où passe le schéma de l'échelle.

**Sans marche** :
- Niveaux d'IA, première forme (mla-an-2223s2-q13, mla-an-2122s1-q16, mla-an-2122s2-q13) — A, D, E : le nombre de niveaux, le niveau 3 « éprouvé » et les moteurs d'inférence ne sont dans aucun ronéo depuis 2023-24, la clé seule les tranche (cartes a-relire) ; B et C ont leurs marches (programmer, s19 ; règles apprises, s20).
- Niveaux d'IA, seconde forme (mla-an-2021s1-q6, mla-an-2021s2-q11, mla-an-1920s2-q6, mla-an-1718s2-q9) — A, D, E : nombre de niveaux, niveau 3 « inédit », niveau 5, absents de la FC 2025-26 ; clé seule.
- IA en santé (mla-an-2021s2-q3, mla-an-1920s1-q12) — C : le niveau 2 « créer ses propres mécaniques » ne se justifie que par la clé ; D : la responsabilité du médecin vient du cours 2023-24 (p. 15) et de la FC n°7, que la FC n°8 n'enseigne pas.
- Applications de l'IA (mla-an-1920s1-q13) — C et D ont leur marche (mla-ech-s23, l'alerte de dose, FC n°1 2025-26 p. 2) et leurs lettres sur la case de l'algorithme en santé ; A (ECG automatisé, point douteux), B (fatigue des alertes) et E (dispositifs de large diffusion) ne sont dans aucune fiche 2025-26 : pas de lettre.
- Systèmes experts (mla-an-1718s2-q10) — A, B, D, E : aide à la décision, base de connaissances, avis conforme aux recommandations, base de faits : cours 2023-24 (p. 3) et FC n°1, absents de la FC n°8 ; seule C (la forme des règles) a sa marche (s20).

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```
