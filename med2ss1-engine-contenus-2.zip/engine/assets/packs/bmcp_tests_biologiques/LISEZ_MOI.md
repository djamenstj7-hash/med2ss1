# Tests biologiques pour la médecine personnalisée en cancérologie — paquet BMCP

75 notes, 154 cartes. Chapitre `chap-ue-bmcp-fc11` de l'UE BMCP (`ordre=12`).
Cours du **Pr Buisine, le 29/10/2025, de 8 h à 9 h**, dans le **Ronéosaure
2025-26** (FC n°12, 6 pages) ; les annales du polycopié BMCP 11 du Ronéosaure
2024-25 (4 questions, 4 sessions) et le sujet de 2024/2025, sans corrigé (Q.5, Q.6,
QROC 1). Examen : mardi 5 janvier 2027.

**Fiche provisoire** (décision de Vincent du 02/10) : le cours 2026-27 n'est pas
encore paru. Chaque carte de cours cite la FC 2025-26 à sa page, et l'écran
montre « Cours 2025-26 » ; le ronéo 2026-27 corrigera les cartes quand il
sortira. Aucune carte n'est « Absent du cours 2026-27 ».

Un brouillon interrompu le 03/10 occupait le dossier : `generer.py` (copie
exacte du modèle, gardée), `schemas.py` (le récepteur HER2 : relu, gardé, la
note de la zone transmembranaire corrigée — voir les erreurs) et six figures
dans `media/` (relues contre les pages du PDF, gardées). Tout le reste est
écrit ici.

**Relu le 05/10** contre chaque page de la FC 2025-26, la table de corrections
du polycopié et les deux erratas (aucune entrée pour ce cours ni pour ces
questions), avec le schéma HER2 rendu, ses zones superposées, et les deux
planches agrandies. Corrigés à la relecture : les racines `mélan(o)-` et
`onc(o)-` citent leur FC de sémantique ; le texte à trous de BRAF dit le sens de
la substitution sans ambiguïté (« remplace une thymine par une adénine ») ;
l'explication de la FISH ; le compte des figures de la source.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 28 | 28 |
| QRU | 1 | 1 |
| Texte à trous | 14 | 87 |
| QROC | 13 | 13 |
| Recto-verso | 7 | 7 |
| Schéma cliquable | 1 | 7 |
| Planche à légender | 2 | 2 |
| Lexique | 9 | 9 |

Dont **9 annales** sur 5 sessions : les 4 QCM du polycopié, et du sujet de 2024/2025
(examen du 09/01/2025, sans corrigé, déposé le 15/10/2026) deux QCM (Q.5, Q.6) et le
QROC 1, en trois cartes (deux QROC et un recto-verso). **26 QCM sur 29 sont illustrés**
(90 %) :
six figures du ronéo, le schéma HER2 redessiné.

Six thèmes, dans l'ordre du cours, tous nouveaux ; leurs libellés sont dans `THEME_LABELS` (`app/src/med_engine/application/scopes.py`) depuis l'intégration du 05/10 :

| Clé | Libellé | Notes |
|---|---|---|
| `medecine-personnalisee` | Médecine personnalisée et instabilité génétique | 9 |
| `therapies-ciblees` | Thérapies ciblées | 13 |
| `tests-compagnons` | Tests compagnons : cancer du sein, mélanome | 21 |
| `resistances-ciblees` | Résistances aux thérapies ciblées | 7 |
| `cancers-hereditaires` | Cancers héréditaires | 8 |
| `dispositif-oncogenetique` | Dispositif d'oncogénétique et tests présymptomatiques | 8 |

Le plan C16 nommait `resistances` la clé des résistances, partagée avec
`bmcp_senescence` : elle est rendue plus précise, `resistances-ciblees` — le mot
seul servirait aussi aux antibiotiques ou aux antiviraux, et `resistance`
(« Insulinorésistance ») existe déjà. `bmcp_senescence` a pris la même clé, au
même libellé : les deux chapitres partagent `therapies-ciblees` et
`resistances-ciblees`.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-bmcp-tbi-2526` — Ronéosaure, « FC n°12 Tests biologiques pour la médecine personnalisée en cancérologie » (6 p.) | 2025-26 | le cours ; `SRC["fiche"]`, ses figures |
| `src-annales-bmcp-11-tests-biologiques-en-medecine-personnalisee` — « BMCP 11 - Tests biologiques en médecine personnalisée » | 2024-25 | les 4 annales ; table de corrections p. 6 |
| `src-sujets-bmcp-2425` — « Sujets de BMCP 2024/2025, session 1 » (30 p.) | 2024-25 | le sujet de l'examen du 09/01/2025, **sans corrigé** (dépôt `Annales_15102026/`, 15/10/2026) : Q.5, Q.6 et QROC 1 ; `SRC["sessions"]["2024/2025 S1"]` ; déclaré à l'identique dans tous les chapitres de BMCP qui en cartent une question |

La source d'annales est déclarée avec les seuls champs convenus (`id`, `kind`,
`titre`, `chemin_relatif`, `auteur`) : les cinq autres chapitres qui tirent une
question de ce polycopié doivent la déclarer à l'identique.

Lus en appoint, sans être déclarés : le cours 2024-25 du même professeur
(Ronéosaure, FC n°11, 9 p.) et le Charonéo 2023-24 (n°12, 10 p.), pour trier
les erreurs du ronéo 2025-26 ; l'errata des cours 2025-26 (aucune entrée pour
cette FC) et celui des annales (aucune pour ces questions). Les pages citées
sont celles du PDF, identiques à celles imprimées au pied.

Les en-têtes du ronéo et du polycopié portent des noms d'étudiants : aucun n'est
repris.

## Ce que le cours a dicté

- **Ni rouge ni gris** dans ce ronéo : tout se carte. Le plan du cours fait les
  thèmes.
- **Ce qui n'est pas carté ici**, parce qu'un autre chapitre le tient (plan C16) :
  la règle -mab / -nib comme règle générale, l'imatinib dans la LMC et les GIST,
  les cellules souches tumorales (`bmcp_senescence`, FC n°11) ; HER2
  proto-oncogène (ErbB2, neu, sans ligand propre), BCR-ABL, Knudson
  (`bmcp_cycle_cellulaire`, FC n°9). Les cartes les citent.
- **Les figures** : l'instabilité génétique (p. 2), les stratégies de ciblage
  d'un récepteur (p. 3), la voie de BRAF et le codon 600 (p. 4), le tableau des
  cancers héréditaires (p. 5), l'arbre de la famille Lynch en deux temps (p. 6).
  **La photographie du patient** traité par vémurafénib (p. 4) n'est pas
  reprise : rien à apprendre que le texte ne dise.
- **Deux figures deviennent des planches à légender** (`PLANCHES`, figures en
  image, `scripts/planche_depuis_image.py`) ; HER2 devient un schéma cliquable (`schemas.py`).

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| Le test compagnon : sur la tumeur, avant le traitement, il conditionne la prescription ; une trentaine de plateformes | 2023/2024 S1 Q.3 A-B, 2021/2022 S1 Q.18 |
| Le vémurafénib : petite molécule, inhibe BRAF muté V600, mélanome, test compagnon BRAF | 2023/2024 S1 Q.3 C, 2020/2021 S2 Q.20, 2019/2020 S1 Q.20 (la même, permutée) |
| Les cancers héréditaires : 5 %, diagnostic sur l'ADN du sang | 2023/2024 S1 Q.3 D-E, 2024/2025 S1 Q.6 |
| Le test compagnon de HER2 (amplification, FISH) et de BRAF ; le mélanome métastatique : quel test, sur quel matériel, pour quoi | 2024/2025 S1 Q.5 et QROC 1 |

Le polycopié BMCP 11 est **composite** : 17 QCM, dont 4 seulement de ce cours.
Les 13 autres vont à la sénescence (7), à la signalisation (2), au cycle
cellulaire (2), aux morts cellulaires (1) et aux cellules souches (1), selon le
plan. Deux d'entre elles touchent ce cours et sont citées par les cartes sans
être recopiées : 2018/2019 Q.14 C (« addiction aux oncogènes », sénescence) et
2023/2024 Q.1 E (« le trastuzumab … ciblant l'activité kinase du récepteur
HER2 », signalisation).

**Non carté** : le fragment de BMCP 12 « 24) Parmi les propositions suivantes
relatives aux tests compa… » (2016/2017 S2), sans propositions ni clé.

## Les clés qui ne sont pas reprises telles quelles

Aucune clé imprimée n'est contestée. Les quatre clés imprimées (ABD, BD, CDE, ADE) sont celles du cours
2025-26 ; `CONFLITS` est vide.

Le sujet de 2024/2025 n'a pas de corrigé : ses clés sont déduites du cours, chacune
sur sa page, `officielle=False`.

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2024/2025 S1 Q.5 (tests compagnons) | aucune (sujet sans corrigé) | **BCD**, déduite | A fausse, le test se fait sur la tumeur (p. 3) ; B, il conditionne la prescription (p. 3) ; C, HER2 et trastuzumab (p. 3-4) ; D, la FISH, que la FC 2025-26 appelle « biologie moléculaire » (p. 4) et que nomment le cours 2024-25 (p. 5) et l'ED n°1 de biologie cellulaire 2025-26 (p. 9-10) ; E fausse, la mutation V600 est la cible, les résistances viennent de PTEN et de MEK1 (p. 4-5) |
| 2024/2025 S1 Q.6 (médecine personnalisée) | aucune (sujet sans corrigé) | **CDE**, déduite | A fausse, le test compagnon prédit la réponse au traitement (p. 3) ; B fausse, 5 % (p. 5) ; C, gène suppresseur de tumeur (p. 5) ; D et E, sang et laboratoire autorisé par l'ARS (p. 6) |
| 2024/2025 S1 QROC 1 (mélanome métastatique), trois cartes | aucune (sujet sans corrigé) | réponses déduites du cours | la mutation BRAF V600, sur la tumeur, test compagnon des inhibiteurs de BRAF associés à un inhibiteur de MEK ; sans mutation, immunothérapie ou KIT (p. 3-5). L'explication du recto-verso redit l'appariement fautif des molécules du ronéo 2025-26 (p. 5), par un ATTENTION nu | Seule anomalie, dite dans l'explication de la
carte : l'en-tête « Année 2022/2024 (Session 1) » du polycopié, pour
2023/2024 — sa table de corrections le dit.

## Les erreurs du ronéo 2025-26

Le Ronéosaure n'est pas le ronéo de l'année : chaque erreur est portée par un
**ATTENTION nu** dans la carte qui tient la notion, la sorte dite dans le texte,
et rien n'entre dans `contenu/ERRATA_RONEOS_2026-27.md`. Le tri s'est fait sur
les ronéos 2024-25 et 2023-24 du même cours.

| Page | Le ronéo dit | Retenu | Sorte | Carte |
|---|---|---|---|---|
| 3 | le vémurafénib parmi les « inhibiteurs de tyrosine kinase » | BRAF est une sérine-thréonine kinase (p. 4 du même ronéo) ; 2024-25 et 2023-24 : « kinase(s) cytoplasmique(s) » | prise de notes | `tbi-qc-strategies` E, `tbi-fa-strategies` |
| 3 | HER2 surexprimé dans « 15-20 % » des cancers du sein | la FC n°9 (p. 23) dit 25 % ; les revues récentes, 15-20 % (Loibl et Gianni, Lancet 2017) : la carte garde 15-20 % | point douteux (deux cours, deux chiffres) | `tbi-qc-her2` B, `tbi-fa-her2` |
| 4 | la biologie moléculaire « utilisée si le résultat de l'immunohistochimie est négatif » | 2024-25 : « négatif ou douteux » ; 2023-24 : « non contributive » ; ASCO/CAP 2018 : IHC 2+, équivoque → FISH | prise de notes | `tbi-qc-her2-test` D |
| 4 | le pertuzumab « dirigé contre le domaine transmembranaire » de HER2 | domaine II, extracellulaire, de dimérisation (Franklin et al., Cancer Cell 2004 ; la figure de la p. 3 le place hors de la cellule) ; mais les ronéos 2024-25 et 2023-24 l'écrivent aussi | point douteux, peut-être le cours lui-même | `tbi-qc-resistance-trastuzumab` D, `tbi-fa-resistances-her2`, zone `transmembranaire` de `tbi-zo-her2` |
| 4 | « NGF (= séquençage à haut débit) » | NGS, next-generation sequencing ; la coquille est déjà dans les ronéos 2024-25 et 2023-24 | prise de notes (coquille reprise) | `tbi-qc-v600e` E, `tbi-qr-ngs` |
| 5 | « Vémurafénib + Trametinik ou Rabratenik + cobimetinib » | vémurafénib + cobimétinib (coBRIM, Larkin et al., NEJM 2014), dabrafénib + tramétinib (COMBI-d, Long et al., NEJM 2014) ; les ronéos 2024-25 et 2023-24 inversent déjà les couples | point douteux, peut-être le cours lui-même | `tbi-qc-resistance-braf` E, `tbi-fa-resistances-braf` |

Dites sans ATTENTION, parce que ce ne sont pas des erreurs : l'annexectomie
rangée sous la surveillance (p. 6), qui est une chirurgie prophylactique
(`tbi-fa-surveillance`) ; la mutation de KIT de la patiente de 79 ans, « par
délétion » en 2025-26 et 2024-25, « duplication » en 2023-24 (aucune carte n'en
dépend).

## Les schémas cliquables et les planches

| Fichier | Ce qu'on fait | Carte |
|---|---|---|
| `her2-recepteur.svg` (nu) / `her2-recepteur-legende.svg` | cliquer le domaine où se fixe le trastuzumab, le domaine transmembranaire, le domaine que bloque le lapatinib, le partenaire d'hétérodimérisation, PI3K, AKT, PTEN — 7 cartes | `tbi-zo-her2` |
| `tbi-voie-braf-numerotee.png` / `tbi-voie-braf.png` (p. 4) | 11 numéros : la mutation V600, KIT, vémurafénib-dabrafénib, RAS, RAF, PI3K, PTEN, MEK, AKT, ERK/MAPK, mTOR ; 5 intrus | `tbi-pl-voie-braf` |
| `tbi-instabilite-numerotee.png` / `tbi-instabilite-genetique.png` (p. 2) | 10 numéros : les huit propriétés acquises, l'instabilité génétique et l'inflammation ; 4 intrus | `tbi-pl-proprietes` |

Le schéma HER2 est redessiné nu d'après le texte des p. 3-4 et la figure de la
p. 3 : PI3K, AKT et PTEN se reconnaissent à leur place, sans légende. Les
planches gardent les cadres et les ovales de la diapositive, vidés de leur
texte ; les rectangles effacés sont dans `donnees.py` (`efface`), mesurés sur
des agrandissements quadrillés, et les deux images numérotées ont été
regardées avant d'être employées.

## Le lexique

Neuf termes, aucun déjà dans l'UE, pages mesurées dans le PDF de la FC
(`chercher_pages.py`, la p. 1 du plan exclue) ; chaque terme et chaque racine
disent leur origine. Les étymologies sont proposées pour la table
(`etymologies.json`) dans le brouillon `etym/bmcp_tests_biologiques.json` :
trois racines absentes de la table (`onc(o)-`, `mélan(o)-`, `annexe (latin)`),
les autres reprises à l'identique. `onc(o)-` reprend mot pour mot la
proposition de `bmcp_cycle_cellulaire` (Oncogène), avec deux sources de plus.

Deux racines sont enseignées par les FC de sémantique et les citent :
`mélan(o)-` (2/2 p. 7, « mélan- : noir », tableau des couleurs) et `onc(o)-`
(1/2 p. 6, « onco- : gonflement, grosseur », dans le tableau de -gène, à
protooncogène).

*Oncoprotéine* est employée par quatre questions du polycopié BMCP 9, cartées
au cycle cellulaire (deux QROC sur l'oncoprotéine E7, RAS, Bub1 et Tax) : selon la règle du
chapitre d'accueil, `bmcp_cycle_cellulaire` pourrait l'accueillir. Elle est
ici parce que seule la FC n°12 la définit (p. 3) et que le cycle ne l'a pas
prise ; le compte d'annales, calculé sur toute l'UE, n'y perd rien.

| Terme | Pages |
|---|---|
| Oncoprotéine | 3 |
| Cancérogenèse | 2 |
| Mélanome | 4, 5 |
| Mélanocyte | 4 |
| Polypose | 5 |
| Néoplasie | 5 |
| Oncogénétique | 6 |
| Annexectomie | 6 |
| Prophylactique | 6 |

**Deux termes du plan ne sont pas repris** : *Immunohistochimie* (p. 3-4) et
*Présymptomatique* (p. 6) sont déjà des notes de la bibliothèque
(`lex-immunohistochimie` dans `biostat_phase_3`, `lex-presymptomatique` dans
`genet_tests`) ; le même identifiant ferait passer la note de leur chapitre à
celui-ci à l'import. *Oncoprotéine* et *Cancérogenèse* les remplacent.

## À relire

Aucune carte `a-relire` : chaque carte de cours cite sa page de la FC 2025-26,
les quatre clés d'annales du polycopié sont reprises telles quelles, et les clés du
sujet de 2024/2025, sans corrigé, sont déduites chacune sur une page du cours.

## Questions pour Vincent

1. **Le pertuzumab** : les trois derniers ronéos le disent « dirigé contre le
   domaine transmembranaire » de HER2 ; la référence dit le domaine II,
   extracellulaire. Les ronéos 2025-26 et 2024-25 ne sont pas deux témoins : ils
   ont la même phrase, jusqu'au bégaiement « contre domaine le domaine » ; le
   Charonéo 2023-24 l'écrit autrement. Les cartes suivent la référence et le
   signalent (point douteux) ; aucune ne demande où se fixe le pertuzumab. Si
   la diapositive (Moodle) dit « transmembranaire », c'est le cours lui-même :
   faut-il alors répondre comme le professeur à l'examen ?
2. **Les couples BRAF + MEK** : les trois ronéos apparient « vémurafénib +
   tramétinib » et « dabrafénib + cobimétinib », l'inverse des associations
   autorisées. Aucune carte ne demande les couples ; elles demandent le principe
   (BRAF + MEK) et signalent le point douteux. À confirmer sur la diapositive.
3. **Immunohistochimie et Présymptomatique**, termes du plan déjà au lexique
   d'autres UE : faut-il un terme jumeau pour la BMCP (un autre identifiant), ou
   les laisser à la biostatistique et à la génétique ?

## Intégration (05/10)

- Les libellés de thèmes sont dans `THEME_LABELS`
  (`app/src/med_engine/application/scopes.py`), bloc « BMCP FC n°6 à 22 ».
- Les étymologies proposées (racines et termes) sont versées dans
  `.claude/skills/nouveau-chapitre/scripts/etymologies.json` ;
  `appliquer_etymologies.py` n'a rien réécrit, les textes du lexique étant
  déjà à sa forme.
- Le libellé de `tests-compagnons` ne porte plus « HER2 » (un libellé de thème
  ne porte aucun chiffre) : « Tests compagnons : cancer du sein, mélanome ».
- `onc(o)-` n'a qu'une entrée, commune avec `bmcp_cycle_cellulaire`.

## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier (BMCP) ou du 6 janvier (SSH, papier). Sous les annales, 19 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 4 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `therapies-ciblees` | 4 | 1 | 2 |
| `tests-compagnons` | 11 | 2 | 6 |
| `cancers-hereditaires` | 4 | 1 | 1 |

**Le schéma** `ech-tests-compagnons`, « Tests biologiques pour la médecine personnalisée », donne 30 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_TESTS_COMPAGNONS`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- tbi-an-2425s1-q5 D (la FISH) : la FC 2025-26 dit « biologie moléculaire », en complément de l'immunohistochimie (p. 4), sans nommer la FISH, que seuls le cours 2024-25 et l'ED n°1 2025-26 nomment (hors des sources) ; la lettre est posée sur la case du trastuzumab, où se lit « IHC, biologie moléculaire ».

## Régénérer

```powershell
cd contenu\chapitres\bmcp_tests_biologiques
..\..\..\app\.venv\Scripts\python.exe generer.py
```

Les deux images numérotées se refont depuis `app/`, Pillow en plus :
`uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/bmcp_tests_biologiques tbi-pl-voie-braf --taille 16`
(et `tbi-pl-proprietes --taille 24`).
