# Anatomie du membre supérieur (FC n°3) — paquet Anatomie

77 notes, 136 cartes. Chapitre `chap-ue-anatomie-fc3` de l'UE Anatomie
(identifiant du squelette), troisième chapitre de l'UE. Cours du
**Pr Demondion, le 29/09/2026** : la région scapulaire, vues postérieure et
antérieure, la région axillaire antérieure, et la vue antérieure de l'épaule et
du bras. Examen : partiel de novembre, un **schéma** — orienter un fond, nommer
les structures fléchées, dessiner et légender vaisseaux et nerfs.

**La base est le cours 2026-27** (réalignement du 11/10/2026), en deux ronéos
de Ronéo & Juliette, tous deux du 29/09/2026 et livrés le 11/10 :

- « TOPOGRAPHIE DU MEMBRE SUP » (10 p., 11 h-12 h), la fiche du chapitre ;
- la partie I de « TOPOGRAPHIE MEMBRE SUP 2 » (8 p., 12 h-13 h), le schéma en
  vue antérieure des muscles scapulaires et huméraux (p. 2-4). Sa partie II,
  l'avant-bras (p. 5-7), est au chapitre FC n°4.

Le Ronéosaure 2024-25 (FC n°3, cours du 04/10/2024), qui faisait la base
jusqu'ici, n'est plus qu'un appoint, comme le cours 2023-24 du même professeur.
**Le cours continue** : le 3e ronéo 2026-27 (CM du 06/10/2026, 10 h-11 h, livré
le 19/10) fait l'avant-bras, le canal carpien et la main (chapitre FC n°4) et ne
reprend aucune carte de ce chapitre ; les CM suivants n'ont pas encore de ronéo
(voir « En attente des ronéos suivantes »).

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 35 | 35 |
| Texte à trous | 11 | 55 |
| QROC | 12 | 12 |
| Recto-verso | 7 | 7 |
| Schéma cliquable | 2 | 17 |
| Lexique | 10 | 10 |
| **Total** | **77** | **136** |

**35 QCM sur 35 illustrés** (100 %), 49 notes sur 77 : les six figures des deux
ronéos 2026-27 en correction, jamais en question, deux figures du Ronéosaure
pour les cartes en attente, deux schémas redessinés pour le clic. **15 cartes
portent un piège de ronéo** (thème « Pièges des ronéos »). **Aucune annale** :
les deux sujets du membre supérieur sont des schémas à compléter, aux chapitres
de schémas (Schémas n°3 et n°4). **Aucune carte absente du cours 2026-27,
aucune à relire.**

Dix thèmes, tous déjà libellés dans `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) : aucune clé nouvelle.

| Clé | Libellé | Rôle |
|---|---|---|
| `region-scapulaire` | Région scapulaire | région (tag), et thème des consignes |
| `region-axillaire` | Région axillaire | région (tag), et thème de deux schémas |
| `osteologie` | Ostéologie | couche |
| `insertions-musculaires` | Insertions musculaires | couche |
| `nerfs` | Nerfs : origine, trajet, territoire | couche |
| `vascularisation` | Vascularisation | couche |
| `espaces-passages` | Espaces, canaux et passages | couche |
| `lesions-nerveuses` | Lésions nerveuses et syndromes canalaires | couche |
| `orientation-schemas` | Titre et orientation des schémas | repris des Schémas n°1 et n°2, pour l'orientation des fonds et la façon de les dessiner (réséqué, récliné) ; pas pour le plan de dissection, que son libellé ne couvre pas |
| `bras` | Bras | repris de la FC n°4, pour les deux cartes du 2e cours |

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-anat-fc3-2627` — Ronéo & Juliette, « TOPOGRAPHIE DU MEMBRE SUP » (10 p.) | **2026-27** | **la base** et la fiche du chapitre (`SRC["fiche"]`, `chapitre=`), chemin `ANATOMIE/TOPOGRAPHIE DU MEMBRE SUP.pdf` ; 60 notes y portent leur page |
| `src-fc-anat-fc3-2627-2` — Ronéo & Juliette, « TOPOGRAPHIE MEMBRE SUP 2 » (8 p.) | **2026-27** | partie I (p. 2-4) ; `chapitre=` ce chapitre ; 3 notes avec `fiche=R2` |
| `src-fc-anat-fc3-2425` — Ronéosaure, FC n°3 (7 p.) | 2024-25 | appoint, `SRC["cours"]`, et fiche des 4 cartes en attente (`fiche=FC3`) ; plus de `chapitre=` |
| `src-anat-ms-2324-4` — Charonéo, cours 4 (13 p.) | 2023-24 | appoint : tableaux d'insertions, rapports, pince costo-claviculaire |
| `src-anat-ms-2324-3` — Charonéo, cours 3 (6 p.) | 2023-24 | appoint : nerf axillaire et fracture du col |
| tableau des erreurs d'anatomie 2026-27 (11/10) | 2026-27 | deux entrées, toutes deux sur le 1er cours ; reprises ci-dessous |

Dans le texte d'une carte, « p. N » renvoie à la fiche que la carte cite,
« 2e cours, p. N » au second ronéo. Les faits pris hors du cours citent Gray's
Anatomy, Kenhub (« Levator scapulae », « Rhomboid muscles », « Latissimus
dorsi », « Medial pectoral nerve »), TeachMeAnatomy (« The Humerus ») et, pour
la description française de l'artère axillaire, le cours « Le creux axillaire »
de la faculté de médecine de Marrakech.

## Le réalignement du 11/10/2026

Chaque note a été relue contre les deux ronéos, page par page.

| Devenir | Notes |
|---|---|
| **Relues sur le 1er cours** (`page`, plus de badge 2024-25) : 52 | toutes les QRM, QROC, recto-verso, textes à trous et zones de 2024-25, sauf les quatre en attente et `ms3-qc-subscapulaire` |
| **Relue sur le 2e cours** (`fiche=R2`) : 1 | `ms3-qc-subscapulaire` (p. 3) |
| dont **réécrites** (une proposition ou une réponse changée) : 22 | `ms3-qc-scapula`, `ms3-qc-elevateur-rhomboides`, `ms3-qc-trapeze`, `ms3-qc-triceps`, `ms3-qc-espaces`, `ms3-qc-pedicule-supra-scapulaire`, `ms3-qc-nerf-radial`, `ms3-qc-grand-pectoral`, `ms3-qc-sillon-delto-pectoral`, `ms3-qc-thoraco-acromiale`, `ms3-qc-humerus`, `ms3-qc-pince-costo-claviculaire`, `ms3-qc-levres-sillon`, `ms3-qc-grand-rond-dorsal`, `ms3-rv-thoraciques`, `ms3-rv-levres`, `ms3-rv-cols`, `ms3-fa-sillon`, `ms3-fa-delto-pectoral`, `ms3-fa-subclaviere`, `ms3-fa-nerf-radial`, `ms3-qr-tendon-espaces` |
| **Nouvelles** : 12 | `ms3-qc-orientation-posterieure` (p. 2), `ms3-qc-scapula-mecanique` (p. 3), `ms3-rv-orientations` (p. 3), `ms3-fa-espaces` (p. 5), `ms3-qr-nerf-dorsal-scapula` (p. 5), `ms3-rv-reseque-recline` (p. 6), `ms3-qc-plan-dissection` (p. 7), `ms3-qc-axillaire-anterieure` (p. 9), `ms3-qc-vue-anterieure-bras` (2e cours, p. 3), `ms3-qc-nerfs-vue-anterieure` (2e cours, p. 4), `lex-resequer`, `lex-recliner` |
| **En attente des ronéos suivantes** : 4 | voir plus bas |
| **Absentes du cours 2026-27** : 0 | voir plus bas |

Deux clés ont changé : `ms3-qc-thoraco-acromiale` (ABC → ABCE : la proposition
sur la thoracique interne a cédé la place à l'anse des pectoraux, p. 10) et
`ms3-qc-pince-costo-claviculaire` (ABCD → ABC : la carte porte désormais les
trois noms de l'artère, subclavière, axillaire, brachiale, et l'erreur de la
p. 9). Aucun identifiant, aucun type n'a changé ; les trous des textes à trous
gardent leurs numéros.

### Ce que le cours 2026-27 dit autrement

- **Le plan** : trois régions (scapulaire postérieure, scapulaire antérieure,
  axillaire antérieure) au lieu de deux vues, et un second cours sur la vue
  antérieure de l'épaule et du bras. Chaque région a son fond de schéma (p. 2 et
  6) et son schéma complété (p. 3, 7 et 9).
- **La scapula** : pointe inférieure en regard de la 7e côte, orientée de 40°
  vers l'avant (35/40° en 2024-25), articulation synoviale sphéroïde, ses
  mouvements et son rôle dans la ceinture scapulaire (p. 3). La syssarcose est
  « constituée de tissu cellulo-graisseux ».
- **Les insertions** : l'élévateur naît de C1 à C4 (« axe médian » en 2024-25) ;
  les rhomboïdes et l'élévateur ont leur nerf, le nerf dorsal de la scapula
  (C4-C5), absent du schéma ; le supra-épineux sur le « sommet » du tubercule
  majeur, abducteur ; le grand dorsal par l'aponévrose thoraco-lombaire
  (« thoraco-dorsale » en 2024-25), dans la « partie médiale du sillon » (« lèvre
  médiale » les années précédentes), avec une torsion de son tendon ; le
  « vaste latéral » du triceps au-dessus du sillon du nerf radial.
- **Les espaces axillaires** : le ronéo nomme enfin le contenu de chacun,
  l'artère de l'espace médial comprise (circonflexe de la scapula), que la
  figure de 2024-25 légendait « thoraco-dorsale ».
- **Le trapèze** : trois chefs (supérieur vers l'occipital, moyen horizontal,
  inférieur sur les processus épineux) ; ni T11 ni terminaison (p. 6). La carte
  garde T11 et la terminaison, dites des années précédentes.
- **Le deltoïde** : épine, acromion et clavicule, tubérosité deltoïdienne au
  tiers moyen, trois faisceaux (p. 7) — le tableau 2024-25 ne disait que
  l'acromion.
- **Le grand pectoral** : faisceaux « claviculaire, costaux et chondro-costaux »
  (supérieur, intermédiaire, inférieur en 2024-25) ; la consigne « pas obligé de
  dessiner 3 faisceaux » n'est plus dite.
- **Le sillon delto-pectoral** : la veine céphalique et les branches
  deltoïdiennes et acromiale de la thoraco-acromiale (p. 8).
- **La région axillaire antérieure** : schéma « juste projeté pas dessiné »
  (p. 9) ; subclavière → axillaire → brachiale, l'axillaire changeant de nom au
  bord inférieur du grand pectoral ; l'anse des pectoraux au pied de la
  thoraco-acromiale (p. 10). La glande mammaire n'y est plus qu'un repère de
  surface (p. 6).
- **Le vocabulaire** : « réséqué = retirer », « récliné » = écarter (p. 6).

### Ce que le cours a dicté

- « /!\ DÉJÀ TOMBÉ EN EXAMEN : savoir replacer le trajet des nerfs sur le
  schéma /!\ » (2e cours, p. 4) : `ms3-qc-nerfs-vue-anterieure`.
- **L'orientation** : c'est toujours le membre supérieur droit ; « Haut /
  Droite → » sur la vue postérieure, « Ht / ← Dte » ou « Haut / Gauche → » sur
  les vues antérieures (`ms3-rv-orientations`, `ms3-qc-orientation-posterieure`,
  `ms3-qc-axillaire-anterieure`). Les deux schémas cliquables gardent leur
  repère « Haut / ← Gauche » (vue postérieure) et « Haut / ← Droite » (vue
  antérieure), qui disent la même chose.
- **Réséqué, récliné** : le trapèze et le deltoïde réséqués sur la vue
  postérieure, la peau réclinée sur la vue antérieure (p. 6), le deltoïde
  réséqué et le grand pectoral récliné sur la vue antérieure du bras (2e cours,
  p. 3) : `ms3-rv-reseque-recline`, et deux termes de lexique.
- Les **éléments du fond de schéma** de la vue antérieure du bras (p. 10) :
  processus coracoïde, cavité glénoïdale, incisure scapulaire, acromion,
  humérus, tubercule majeur, diaphyse, épicondyles.
- Le **TP de dissection** obligatoire (p. 2) : rien à carter.
- **Le gris** : une seule parenthèse grise (p. 10, « càd le nerf pectoral lat et
  médial »), la voix des rédacteurs, reprise dans `ms3-qc-thoraco-acromiale`.

## Les erreurs des ronéos 2026-27

Prouvées sur des sources sûres, chacune portée par un `ATTENTION` du genre qui
convient, là où elle se joue. ★ : entrée du tableau des erreurs de la promo.

| Ronéo, page | Ce que dit le ronéo | Ce qui est juste | Genre | Carte |
|---|---|---|---|---|
| ★ 1er cours, p. 2 (figure) | « sternum » légende la ligne médiane de la vue postérieure | la colonne vertébrale et ses processus épineux ; le sternum, antérieur, ne se voit pas de dos (figure p. 3 du même ronéo ; Gray's) | prise de notes | `ms3-qc-orientation-posterieure` (A), légende de la figure sur `ms3-qc-scapula` |
| ★ 1er cours, p. 6 (figure) | la flèche « sillon delto-pectoral » aboutit sur la ligne médiane, au-dessus de l'ombilic | entre le deltoïde et le grand pectoral, à l'avant de l'épaule, sous la clavicule (p. 8 et figure p. 7 du même ronéo ; Gray's) | prise de notes | `ms3-qc-sillon-delto-pectoral` (E), légende de la figure sur `ms3-qc-plan-dissection` |
| 1er cours, p. 2 (figure) | « incisure supra-claviculaire » | l'incisure scapulaire, sur le bord supérieur de la scapula (p. 5 du même ronéo ; Gray's) | prise de notes | `ms3-qc-scapula` (E) |
| 1er cours, p. 4 | « au niveau de la zone diaphysaire de l'humérus on retrouve le col anatomique » | le col anatomique borde la tête ; c'est le col chirurgical qui rejoint la diaphyse (Ronéosaure 2024-25 p. 6 ; TeachMeAnatomy ; Gray's) | prise de notes | `ms3-qc-humerus` (C), `ms3-rv-cols` |
| 1er cours, p. 4 | le tubercule majeur « reçoit l'insertion des muscles de la coiffe » (« P.I.S.S », subscapulaire compris) | le subscapulaire se termine sur le tubercule mineur (p. 9 et 2e cours p. 3 ; Gray's) | prise de notes | `ms3-qc-subscapulaire` (D), `ms3-qc-coiffe` (E), `ms3-fa-coiffe` |
| 1er cours, p. 4 | élévateur de la scapula sur le « bord supérieur de la scapula » | angle supéro-médial et bord médial au-dessus de l'épine (Ronéosaure 2024-25 p. 3 ; cours 2023-24 p. 2 ; Kenhub) | prise de notes | `ms3-qc-elevateur-rhomboides` (A), `ms3-fa-insertions-posterieures` |
| 1er cours, p. 9 (sous la figure) | « a. subclavière → a. axillaire après passage du bord inférieur du m. grand pectoral » | c'est l'axillaire qui devient brachiale à ce niveau ; la subclavière devient axillaire sous la clavicule, au-delà de la 1re côte (texte de la même page ; 2e cours p. 4 ; Gray's) | prise de notes | `ms3-qc-pince-costo-claviculaire` (D) ; la phrase est coupée de la figure |
| 2e cours, p. 3 | grand dorsal et grand rond : « insertion sur le bord latéral de la scapula » | vrai du grand rond seul ; le grand dorsal naît de l'axe médian par l'aponévrose thoraco-lombaire (1er cours p. 4 ; Kenhub) | prise de notes | `ms3-qc-vue-anterieure-bras` (C) |

**Les points douteux** :

| Ronéo, page | Ce que dit le ronéo | Ce qu'on en sait | Carte |
|---|---|---|---|
| 1er cours, p. 4 | rhomboïdes nés de la « colonne cervicale (à partir de C4 environ pour le petit rhomboïde) » | petit rhomboïde C7-T1, grand T2-T5 (Kenhub ; Gray's) ; C5-C7 et C7-T4 dans le cours 2023-24 : le grand est thoracique | `ms3-qc-elevateur-rhomboides` (C) |
| 1er cours, p. 4 | aponévrose thoraco-lombaire « s'étendant du sacrum et de la crête iliaque jusqu'à L2 » | le grand dorsal naît de T7 à T12, du fascia thoraco-lombaire, de la crête iliaque et des côtes 9 à 12 (Kenhub ; Gray's) ; aucune des références consultées ne donne la limite « L2 » | `ms3-qc-grand-rond-dorsal` (B) |
| 1er cours, p. 10 | « l'artère thoracique médiale est plus haute » | aucune artère ne porte ce nom : la thoracique supérieure (« suprême ») ou la thoracique interne ? | `ms3-rv-thoraciques` |

Vus et laissés, parce qu'ils ne changent aucune réponse : le petit pectoral
« sur les cartilages costaux des 3e, 4e et 5e côtes » (p. 9 ; les côtes 3 à 5
près de leurs cartilages en référence, dit dans la justification) ; le « fascia
superficiel » au contact des muscles (p. 7 ; c'est le fascia pectoral du cours
2023-24, la nomenclature française appelant « superficielle » l'aponévrose des
muscles superficiels) ; les trois faisceaux du grand pectoral « claviculaire,
costaux et chondro-costaux » (p. 8 ; claviculaire, sterno-costal et abdominal en
référence, dit dans la justification) ; la veine céphalique qui « croise » le
sillon (p. 8) ; l'artère « circonflexe profonde de la scapula » de la figure
p. 3, nom du cours 2023-24 ; le petit rond sur la « face postérieure de
l'humérus » (p. 5). Ce dernier n'est pas une erreur : c'est la formule du
Ronéosaure 2024-25 (p. 3), moins précise que « face postérieure du tubercule
majeur » (cours 2023-24 p. 2) mais juste, la facette inférieure du tubercule
majeur étant à la face postérieure de l'os (Gray's) ; `ms3-qc-infra-petit-rond`
(D) le dit sans ATTENTION.

Pour le 2e cours, partie II (avant-bras), et deux points de sa partie I que
portent les cartes de la FC n°4 — le biceps « supinateur accessoire » (p. 3) et
la branche superficielle du nerf radial « à proximité de l'artère brachiale
profonde » (p. 4) —, voir le chapitre FC n°4.

## Les erreurs des années précédentes

Signalées par un **ATTENTION nu** : ce ne sont pas des ronéos de l'année.

| Source | Ce qu'elle dit | Retenu | Carte |
|---|---|---|---|
| Ronéosaure 2024-25 p. 3 | trapèze « Proximale : bord supérieur de la scapula » | versant supérieur de l'épine, acromion, clavicule | `ms3-qc-trapeze` (C) |
| cours 2023-24 et Ronéosaure 2024-25 | trapèze jusqu'à T11 | à l'examen T11 ; C7 à T12 dans Gray's, T10 à T12 selon les sujets | `ms3-qc-trapeze` (D) |
| Ronéosaure 2024-25 p. 5 | le nerf supra-scapulaire « innerve la coiffe des rotateurs » | supra- et infra-épineux seulement (ronéo 2026-27 p. 5) | `ms3-qc-nerf-supra-scapulaire` (E) |
| Ronéosaure 2024-25, figure p. 2 | « artère thoraco-dorsale » dans l'espace axillaire médial | artère circonflexe de la scapula (ronéo 2026-27 p. 5) | `ms3-qc-arteres-espaces` (D), légende de la figure sur `ms3-qc-conventions` |
| Ronéosaure 2024-25, FC n°4 p. 7 | espace inférieur « juste au-dessous du grand pectoral » | sous le grand rond | `ms3-qc-espaces` (D) |
| cours 2023-24, cours 3 | le nerf axillaire « permet de hausser les épaules » | l'abduction ; hausser les épaules, c'est le trapèze | `ms3-qc-fracture-col` (D) |
| Ronéosaure 2024-25 p. 6 ; FC n°4 p. 4 ; cours 2023-24 | grand dorsal sur la « lèvre médiale » | « partie médiale du sillon » en 2026-27 ; fond du sillon en référence | `ms3-qc-levres-sillon` (C) |

## Les clés qui ne sont pas reprises telles quelles

Aucune annale dans ce chapitre, donc aucune clé imprimée. Les réponses du cours
que les cartes ne reprennent pas telles quelles sont dans les tableaux
ci-dessus ; une seule répond comme le professeur contre la référence : le
trapèze jusqu'à T11, chiffre des années précédentes.

## Absent du cours 2026-27

**Aucune carte.** Les deux ronéos ne couvrent que les deux heures du 29/09 ; le
3e, du 06/10, ne traite que l'avant-bras et la main, et le cours continue. Rien
de ce que les deux ronéos taisent n'est clairement abandonné par le professeur :
le schéma de la région axillaire antérieure, où se jouait la vascularisation de
la glande mammaire, a été « expliqué très brièvement, juste projeté pas
dessiné » (p. 9). `ABSENTS_2026` reste vide.

## En attente des ronéos suivantes

Quatre cartes que les deux ronéos ne traitent pas. Elles gardent leur page de la
FC n°3 2024-25 (`fiche=FC3`) et le badge « Cours 2024-25 » ; elles seront
relues à la parution des ronéos suivantes, ou passeront absentes si la fin du
cours ne les reprend pas.

| Carte | Ce qu'elle porte | Ce que les ronéos 2026-27 en disent |
|---|---|---|
| `ms3-qc-conventions` | les consignes de dessin de 2024-25 : nerf axillaire d'une autre couleur, trois faisceaux du grand pectoral facultatifs, veine plus grosse que l'artère | rien ; les consignes de 2026-27 sont ailleurs (`ms3-rv-reseque-recline`, `ms3-rv-orientations`, `ms3-qc-nerfs-vue-anterieure`) |
| `ms3-qc-glande-mammaire` | les trois artères de la glande mammaire | la glande n'est qu'un repère de surface (p. 6) ; la thoracique latérale « passe sur bord lat du thorax » (p. 10) |
| `ms3-fa-glande-mammaire` | le même, en texte à trous | idem |
| `ms3-qc-veine-artere` | la veine plus grosse et fragile, « papier à cigarette » | seule la veine médiale à l'artère (p. 10 ; 2e cours p. 4), citée dans la justification |

Des propositions isolées viennent aussi des années précédentes dans des cartes
relues sur 2026-27, et chacune le dit dans sa justification : l'infra-épineux
rotateur latéral, le petit rond innervé par le nerf axillaire, le nerf
axillaire né du faisceau postérieur et sensitif du moignon de l'épaule, la
veine céphalique venue de la partie latérale de l'avant-bras, le petit pectoral
qui couvre le pédicule axillaire, la terminaison du trapèze et T11, la
thoracique interne (`ms3-rv-thoraciques`), le triceps sur l'olécrâne, la pince
costo-claviculaire faite de la clavicule et de la 1re côte, le nerf axillaire
hors de la continuité du supra-scapulaire, la circonflexe de la scapula branche
de l'artère subscapulaire.

## Le 2e cours et le chapitre FC n°4

La partie I du 2e cours (p. 2-4) mêle l'épaule et le bras. Ce chapitre en carte
ce qui touche l'épaule et l'aisselle — le subscapulaire, le deltoïde réséqué, le
grand pectoral récliné, le grand dorsal et le grand rond, le coraco-brachial,
les changements de nom de l'artère, les faisceaux du plexus et le trajet des
nerfs sur le schéma — en trois cartes (`ms3-qc-subscapulaire`,
`ms3-qc-vue-anterieure-bras`, `ms3-qc-nerfs-vue-anterieure`). Le biceps, le
lacertus fibrosus, le brachial, le brachio-radial, les nerfs médian, ulnaire,
musculo-cutané et radial au bras et l'artère brachiale ont déjà leurs cartes au
chapitre FC n°4 (`ms4-qc-biceps-chef-long`, `ms4-qc-biceps-terminaison`,
`ms4-qc-brachial-coracobrachial`, `ms4-qc-plexus`, `ms4-qc-faisceaux-branches`,
`ms4-qc-median-bras`, `ms4-qc-musculo-cutane`, `ms4-qc-ulnaire-bras`,
`ms4-qc-artere-brachiale`…) : on ne les a pas doublées ici.

## Les schémas cliquables

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `ms3-scapula-posterieure.svg` | scapula droite de dos : angle supéro-médial (élévateur), bord médial (rhomboïdes), fosses supra- et infra-épineuses, bord latéral (petit rond), angle inférieur (grand rond), tubercule infra-glénoïdal (chef long du triceps), épine et acromion (trapèze et deltoïde), incisure scapulaire et incisure spino-glénoïdale | 10 |
| `ms3-humerus-proximal.svg` | humérus droit de face : tubercule majeur, tubercule mineur, sillon, lèvre latérale (grand pectoral), lèvre médiale (grand rond), col anatomique, col chirurgical | 7 |

Les dessins et les zones n'ont pas changé ; les notes des zones citent
désormais le ronéo 2026-27 (dont l'erreur de l'élévateur, p. 4). Le grand
dorsal n'a toujours pas de zone sur l'humérus : le cours le met dans la partie
médiale du sillon, les années précédentes sur la lèvre médiale, la référence au
fond du sillon. Les légendes de la correction sont placées comme avant (cadre
de la scapula élargi à 840 px, plusieurs légendes hors de l'os). Rien pour les
espaces axillaires : leur zone est au chapitre Schémas n°3.

## Les figures

Toutes extraites des PDF à pleine définition, redressées si besoin, ramenées à
1400 px de large, le papier blanchi, 128 couleurs (45 à 193 Ko). Aucune planche
d'atlas. Elles illustrent la correction, jamais la question.

| Fichier | Source | Remarque |
|---|---|---|
| `fc3-2627-p2-fond-posterieur.png` | 1er cours, p. 2 | fond de schéma ; sa légende dit l'ATTENTION de « sternum » et d'« incisure supra-claviculaire » |
| `fc3-2627-p3-vue-posterieure.png` | 1er cours, p. 3 | la figure de la plupart des cartes de la vue postérieure |
| `fc3-2627-p6-fond-anterieur.png` | 1er cours, p. 6 | fond de schéma ; sa légende dit l'ATTENTION du sillon delto-pectoral. Le bleu du bas est une note manuscrite sur la veine céphalique, posée sur le repère d'orientation : aucune veine n'est dessinée |
| `fc3-2627-p7-vue-anterieure.png` | 1er cours, p. 7 | deltoïde, grand pectoral, sillon, veine céphalique, thoraco-acromiale |
| `fc3-2627-p9-axillaire-anterieure.png` | 1er cours, p. 9 | capture du schéma projeté ; la phrase fausse écrite dessous est coupée |
| `fc3-2627-r2-p2-vue-anterieure-bras.png` | 2e cours, p. 2 | tournée d'un quart de tour : le ronéo l'imprime en paysage |
| `fc3-p2-scapulaire-posterieure.png` | FC n°3 2024-25, p. 2 | gardée pour `ms3-qc-conventions` (en attente) |
| `fc3-p7-axillaire-profonde.png` | FC n°3 2024-25, p. 7 | gardée pour la glande mammaire et la veine (en attente) |

Les trois autres images de 2024-25 restent dans `media/` mais ne sont plus
déclarées : `fc3-p5-axillaire-dissection.png` (remplacée par la p. 7 de 2026-27)
et les deux dessins numérotés du cours 2023-24
(`ms2324-p2-insertions-posterieures.png`, `ms2324-p3-rapports-posterieurs.png`),
remplacés par la p. 3.

Pas de planche à légender tirée des figures de 2026-27 : leurs légendes sont
manuscrites, dans l'image, et les planches de ces schémas sont aux chapitres
Schémas n°3 et n°4.

## Le lexique

Dix termes, pages mesurées dans le texte des deux ronéos 2026-27 :

| Terme | Pages |
|---|---|
| Syssarcose | 1er cours p. 3 |
| Acromion | 1er cours p. 6, 7, 10 ; 2e cours p. 3 |
| Cavité glénoïdale | 1er cours p. 3, 9, 10 |
| Deltoïde | 1er cours p. 5 à 8 ; 2e cours p. 3 |
| Rhomboïde | 1er cours p. 4, 5 |
| Coiffe des rotateurs | 1er cours p. 4 |
| Col chirurgical | 1er cours p. 5 |
| Veine céphalique | 1er cours p. 8 |
| **Réséquer** (nouveau) | 1er cours p. 6 ; 2e cours p. 3 |
| **Récliner** (nouveau) | 1er cours p. 6 ; 2e cours p. 3 |

Les huit premiers sont dans `scripts/etymologies.json`. Les deux nouveaux, et
leurs racines `secare (latin)` et `clinare (latin)`, sont proposés à la table
(TLFi, Littré, Gaffiot) ; leurs textes sont déjà écrits au format de
`appliquer_etymologies.py`.

## Décisions prises en route

- Les cartes en attente gardent leur page 2024-25 par `fiche=FC3` plutôt que de
  la perdre : le badge « Cours 2024-25 · p. N » dit d'où vient la notion.
- La phrase fausse écrite sous la figure p. 9 est coupée de l'image, pour ne pas
  la répandre sur six cartes ; l'erreur est portée par
  `ms3-qc-pince-costo-claviculaire`. Les deux erreurs du tableau de la promo,
  dans le dessin même, restent sur l'image, et sa légende les dit.
- Les erreurs du Ronéosaure gardent leur ATTENTION nu, raccourci.
- `ms3-qc-levres-sillon` : la formule de 2026-27, « partie médiale du sillon »,
  est plus proche de la référence que la « lèvre médiale » des années
  précédentes ; ce n'est plus « le cours lui-même » contre la référence, et
  l'ATTENTION, nu, dit l'écart entre les années.
- **Relecture critique du 11/10/2026**, carte par carte contre les pages des
  deux ronéos et leurs figures (PDF) :
  - le petit rond sur la « face postérieure de l'humérus » (p. 5) a été retiré
    des erreurs : c'est la formule du Ronéosaure 2024-25, et elle est juste ;
  - `ms3-fa-coiffe` porte désormais l'ATTENTION (prise de notes) de la coiffe
    entière sur le tubercule majeur, qu'il disait sans marqueur ; le compte des
    pièges reste à 15 ;
  - `ms3-qc-plan-dissection` perd le tag `orientation-schemas`, que son
    contenu (graisse, fascia, repères de surface) ne justifie pas ;
  - la légende de la figure p. 6 ne parle plus d'une veine dessinée en bleu :
    c'est une note manuscrite ; celle de la p. 2 nomme toutes les légendes du
    fond et son repère « Ht / D » ;
  - des citations remises mot pour mot (syssarcose, mécanique de la scapula,
    trapèze, deltoïde, changement de nom de la subclavière, veine céphalique,
    réséqué et récliné), et le point douteux « L2 » dit sans l'affirmer faux.

## À relire

Aucune carte `a-relire` : chaque carte cite sa page, dans un des deux ronéos
2026-27 ou, pour les quatre en attente, dans la FC n°3 2024-25.

## Régénérer

```powershell
cd contenu\chapitres\anat_fc3
..\..\..\app\.venv\Scripts\python.exe generer.py
```

`generer.py` est la copie exacte de
`.claude/skills/nouveau-chapitre/scripts/generer_modele.py`.

## Questions pour Vincent

- (11/10) Glande mammaire et veine « papier à cigarette » : le schéma de la région axillaire antérieure a été « juste projeté pas dessiné » cette année. Si les CM du 06/10 et suivants ne reviennent pas dessus, faut-il passer ms3-qc-glande-mammaire, ms3-fa-glande-mammaire et ms3-qc-veine-artere en « Absent du cours 2026-27 » ? Même question pour les consignes de dessin de ms3-qc-conventions.
- (11/10) Trapèze jusqu'à T11 : le ronéo 2026-27 ne donne plus de niveau. Faut-il garder T11 comme réponse d'examen ? C'est le chiffre des cours 2023-24 et 2024-25, et la référence dit T12.
- (11/10) Veux-tu des planches à légender tirées des figures 2026-27, la vue postérieure p. 3 et la vue antérieure du bras du 2e cours ? Leurs légendes sont manuscrites : il faut poser les rectangles à la main.
- (11/10) Le professeur a-t-il dit « artère thoracique supérieure » ou « thoracique interne » là où le ronéo écrit « thoracique médiale » (p. 10) ?
