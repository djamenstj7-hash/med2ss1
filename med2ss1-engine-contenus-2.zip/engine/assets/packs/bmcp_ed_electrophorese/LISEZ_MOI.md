# ED1 de biochimie : profil protéique et électrophorèse — paquet BMCP

85 notes, 173 cartes. Chapitre `chap-ue-bmcp-ed1` de l'UE BMCP, ordre 23.
**ED1 de biochimie du 28/09/2026** (semaine 3), « Raisonnement médical autour
de l'exploration des protéines », Pr Dessein, Pr Leclerc, Pr Schraen : un ronéo
de 16 pages. Aucune annale.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 33 | 33 |
| QRU | 2 | 2 |
| Texte à trous | 17 | 93 |
| QROC | 10 | 10 |
| Recto-verso | 5 | 5 |
| Lexique | 15 | 15 |
| Schéma cliquable | 2 | 14 |
| Planche à légender | 1 | 1 |

**35 QCM sur 35 illustrés** (100 %) : les figures du ronéo 2026-27 (bilans des
trois cas cliniques, tableau des profils ciblés, dix électrophorégrammes) et
cinq schémas redessinés. **6 cartes absentes du cours 2026-27** (tag
`absent-2026`). **13 cartes portent un piège de ronéo** (thème « Pièges des
ronéos »).

Huit thèmes, dans l'ordre de l'ED :

| Clé | Libellé | Statut |
|---|---|---|
| `profil-proteique` | Profil protéique : principes et profils ciblés | **nouveau** |
| `proteines-inflammation` | Protéines de la réaction inflammatoire | **nouveau** |
| `cas-profil-proteique` | Cas cliniques de profil protéique | **nouveau** |
| `denutrition-proteique` | Dénutrition protéique | existe déjà (FC n°8, métabolisme des protéines) |
| `bilan-martial` | Bilan martial : ferritine, transferrine, CST | **nouveau** |
| `electrophorese` | Électrophorèse | existe déjà (remédiation) |
| `electrophorese-pathologique` | Profils électrophorétiques pathologiques | **nouveau** |
| `gammapathies` | Hypo-, hypergammaglobulinémies et gammapathie monoclonale | **nouveau** |

Les six nouveaux libellés sont à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) ; tant qu'ils n'y sont pas,
`test_tout_theme_du_paquet_a_son_libelle` échoue sur ce chapitre, et lui seul.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-bmcp-ed1` — Ronéo & Juliette, « Profil protéique et électrophorèse » (16 p.) | **2026-27** | **la base** : chaque note relue porte sa page ; c'est ce que le lecteur ouvre |
| `src-ed1-bmcp-2526` — Ronéosaure, « ED n°1 Biochimie » (11 p.) | 2025-26 | appoint : les items faux des QCM du cas n°1 (p. 5-6), le « myélome multiple des os » (p. 11) |
| `src-ed1-bmcp-2425` — Ronéosaure, « ED 1 Biochimie - Exploration des protéines » (12 p.) | 2024-25 | appoint ; source de 3 cartes absentes |
| `src-ed1-bmcp-2324` — ronéo 2023-24 du Ronéosaure, « Exploration des protéines » (10 p.) | 2023-24 | appoint ; source de 3 cartes absentes |

Le ronéo 2026-27 dit son code couleur p. 2 : **rose** = diapositives, **noir** =
le professeur, **vert** = réponses aux QCM. Il n'a **pas de gris**. Ce code a
servi à trier les erreurs : ce qui est en rose est le cours ; ce qui est en
noir ou dans les encadrés violets des figures composées par les rédacteurs
(p. 11-15) peut être une prise de notes.

Les vérifications faites hors du cours sont citées dans la carte qui s'en sert :
Pepys et Hirschfield, J Clin Invest 2003 (demi-vie de la CRP) ; Levitt et
Levitt, Int J Gen Med 2016 (demi-vie de l'albumine, environ 17 jours, et son
catabolisme : peau et muscles, le rein pour 6 % au plus) ; Hernando et al.,
J Magn Reson Imaging 2014 (la rate épargnée dans l'hémochromatose génétique) ;
Moir et Fauci, Nat Rev Immunol 2009 (VIH et lymphocytes B) ; le cours
d'immunologie 2026-27 (`olb-qc-plasmocyte`) et le cours de virologie « Virus
et hôte » (Ronéosaure 2025-26, p. 10 : les cellules que le VIH infecte).

## Ce que le cours a dicté

- **Deux techniques à ne pas confondre** (p. 2) : `eph-fa-deux-techniques`,
  `eph-rv-deux-profils` ; « erreur souvent commise lors de l'examen » disait le
  ronéo 2023-24.
- **Les profils ciblés, « À SAVOIR PAR CŒUR »** (p. 3) :
  `eph-fa-profils-cibles`, `eph-qc-profils-cibles`, et le tableau p. 8 en
  illustration.
- **Les demi-vies** (diapositive p. 3), pour dater une inflammation (p. 4) :
  `eph-fa-demi-vies`, `eph-qc-demi-vie-courte`, `eph-qc-demi-vies`, le schéma
  `eph-demi-vies.svg`.
- **Les trois cas cliniques**, en QCM sur leurs bilans, les valeurs recopiées
  dans l'énoncé, la figure en correction : le cas n°1 (insuffisance hépatique)
  en quatre QCM suivant les questions de l'ED (`eph-qc-cas1-*`), le cas n°2
  (légionellose) en deux (`eph-qc-cas2`, `eph-qc-cas2-suivi`), le cas n°3
  (Matis, PCT) en un (`eph-qc-cas3`). Les items faux viennent des QCM du ronéo
  2025-26, qui les donnait (p. 5-6).
- **Les huit lectures d'électrophorégramme** (p. 10-15), une carte chacune
  (`eph-qc-marc`, `-olivier`, `-nephrotique`, `-cirrhose`, `-hypogamma`,
  `-hypergamma`, `-monoclonal`, `-myelome`) et une planche cliquable qui les
  réunit.
- **La conclusion** (p. 16) : « il faut bien connaître les principaux profils
  protéiques ciblés et leurs anomalies, le profil électrophorétique normal et
  ses principaux aspects pathologiques » — c'est le plan des thèmes.

## Ce que les annales ont dicté

**Rien** : aucun des polycopiés d'annales BMCP du Ronéosaure 2024-25 (toutes
sessions, BMCP 1 à 21) ne porte sur le profil protéique, l'électrophorèse, les
protéines de l'inflammation ou les gammapathies — l'ED n'y a pas été évalué.
Les seules questions voisines du Ronéosaure sont en Tissu sanguin
(HÉMATO n°3 et n°5, « en cas d'anémie microcytaire, quel examen biologique est
pertinent ? » — la ferritine) : elles sont déjà dans `sang_hemogramme`
(`hem-an-2021s1-q6`) et ne sont pas reprises. Le chapitre « Mode d'action des
anticorps » (`immuno_anticorps`, autre UE) a déjà une carte cliquable de
l'électrophorèse polyclonale/monoclonale (`anc-zo-electrophorese`) ; celle d'ici
porte sur les six fractions et les protéines qui y migrent.

## Les schémas cliquables et la planche

| Fichier | Ce qu'on clique | Carte |
|---|---|---|
| `eph-electrophorese-nue.svg` | la fraction (albumine, α1, α2, β1, β2, γ) où migre une protéine donnée | `eph-zo-fractions` (6 zones) |
| `eph-profils-nus.svg` | parmi huit électrophorégrammes schématiques, celui d'un profil donné : normal, inflammation aiguë, chronique, syndrome néphrotique, cirrhose, hypo-, hypergammaglobulinémie, pic monoclonal | `eph-zo-profils` (8 zones) |
| `eph-positions-numerotee.png` | planche à légender de la figure p. 9 : 18 numéros (6 fractions, anode, cathode, dépôt, 9 protéines), 4 intrus (fibrinogène, CRP, ferritine, procalcitonine) | `eph-pl-positions` |

L'électrophorégramme est dessiné comme la figure du cours : l'albumine à
gauche, du côté de l'anode, le dépôt à droite ; le sens de migration est
écrit sur les deux versions, ce n'est pas une réponse. Les huit tracés suivent
les rapports des tableaux du cours (g/L), sans échelle, dans un ordre qui ne
suit pas le cours ; une lettre seulement les distingue. Les versions légendées
(`eph-electrophorese.svg`, `eph-profils.svg`) sont en correction. La figure p. 9
est une image : la planche a été faite avec `planche_depuis_image.py`, les
rectangles mesurés sur un agrandissement quadrillé et l'aperçu de contrôle
regardé ; « Albumine » y a deux numéros (la fraction, en haut ; la protéine, en
bas), écrits à l'identique.

Trois schémas d'illustration, pour la correction seulement :
`eph-demi-vies.svg` (p. 3), `eph-profil-inflammatoire.svg` (p. 6),
`eph-strategie-martiale.svg` (p. 7-8).

## Les erreurs du ronéo 2026-27

Le ronéo n'est pas corrigé ; chaque erreur est portée par une carte, avec un
`ATTENTION` qui dit son genre, et la carte retient la bonne lecture. Le tableau
des erreurs BMCP de la promo n'a pas de rubrique pour les ED au 11/10/2026 :
toutes ont été trouvées en relisant, puis relues par un second passage qui
cherchait à les réfuter. Toutes sont à reporter dans
`contenu/ERRATA_RONEOS_2026-27.md`.

**Prises de notes**

| Page | Le ronéo dit | Ce qui est juste | Carte |
|---|---|---|---|
| 3 | L'albumine « est éliminée par le rein » (déjà dans le Ronéosaure 2025-26, p. 3) | « Le rein n'élimine pas les protéines mais il les filtre » (ronéo 2023-24, p. 2) ; normalement aucune protéine ne traverse le glomérule, la protéinurie est pathologique (même ronéo p. 12) ; l'albumine est surtout dégradée dans la peau et les muscles, le rein pour 6 % au plus, moins de 20 mg par jour dans l'urine (Levitt et Levitt 2016) | `eph-qc-albumine` (C) |
| 4 | « orosomucoïde et haptoglobine (car demi-vies de 3j) », phrase reprise mot pour mot du Ronéosaure 2025-26 (p. 3) | 3 jours pour l'orosomucoïde, 4 pour l'haptoglobine (diapositive p. 3, ronéo 2023-24 p. 3) | `eph-qc-demi-vies` (D) |
| 9 | « après migration des protéines sur un champ magnétique » | un champ électrique (ronéos 2023-24 p. 6, 2024-25 p. 8 ; anode et cathode sur la figure de la même page) | `eph-qc-technique` (A) |
| 9 | après l'albumine « 100% pure » : « Pour les restes on parle d'un mélange (IgG, IgA, IgM, IgE, IgD…) » | seul le signal γ est un mélange d'immunoglobulines ; les α1, α2 et β mêlent d'autres protéines, que la même page énumère | `eph-qc-formes-pics` (B) |
| 8 | « Si CST normale ou augmentée : pas de carence martiale (le taux normal de la ferritine […] malgré la carence en fer s'explique par la présence d'une inflammation) » | la parenthèse vaut pour l'autre branche : ferritine non diminuée et CST diminué, une carence masquée par l'inflammation (stratégie HAS, même page) | `eph-qc-martial` (E) |
| 14 | « VIH (destruction des LB) » | le VIH infecte et détruit les lymphocytes T CD4+ (et les macrophages, les cellules dendritiques), pas les LB (virologie « Virus et hôte », Ronéosaure 2025-26 p. 10) ; les ronéos 2023-24 et 2024-25 citent le VIH sans ce mécanisme | `eph-qc-hypogamma` (D) |
| 14 | « plasmocytes (lymphocyte B mature) » | le plasmocyte est le stade final d'un LB activé ; « LB mature » désigne le LB naïf (ronéo 2024-25 p. 11 ; immunologie 2026-27, `olb-qc-plasmocyte`) | `eph-qc-hypergamma` (E) |
| 15 | « Cancer des LB », « Il s'agit d'une leucémie lymphoïde » ; « protocole thérapeutique anti-leucémique » | un myélome (ronéos 2023-24 p. 9-10, 2024-25 p. 12, 2025-26 p. 11 : « myélome multiple des os ») ; les légendes des deux figures le disent | `eph-qc-myelome` (D) |
| 15 | « Quantitativement, la personne est saine (protidémie et doses protéiques normales) » | l'albumine est à 33,3 g/L, sous la normale, sur le tableau de la même figure ; ce qui est normal, ce sont les protéines totales et la quantité de γ ; le Ronéosaure 2025-26 disait seulement « normal au niveau des protéines » et « presque une inflammation » (p. 11) | `eph-qc-monoclonal` (E) |

**C'est le cours lui-même** (diapositive en rose p. 3, identique dans les
ronéos 2023-24, 2024-25 et 2025-26) :

| Page | Ce qui est écrit | À l'examen | La référence | Carte |
|---|---|---|---|---|
| 3 | CRP, demi-vie 12 h | 12 h | environ 19 h, constante en santé comme en maladie (Pepys et Hirschfield, J Clin Invest 2003) | `eph-qc-demi-vie-courte` (A), `eph-fa-demi-vies` |

La demi-vie de 15 jours que la même diapositive donne à l'albumine n'est
**pas** tenue pour une erreur : la mesure de référence est d'environ 17 jours
(Levitt et Levitt, Int J Gen Med 2016), 18 à 20 jours ailleurs, et
`bmcp_proteines` retient environ 20 jours. `eph-qc-demi-vies` (A) le dit, sans
`ATTENTION`.

**Les points douteux**, dits dans la carte, sans changer sa clé :

| Page | Le point | Carte |
|---|---|---|
| 8 (diapositive) | l'hémochromatose dépose le fer sur « foie, rate, cœur… » : la rate se charge dans les surcharges secondaires (transfusions), mais elle est relativement épargnée dans l'hémochromatose génétique (Hernando et al. 2014) ; 2023-24 et 2024-25 citaient cœur, peau, pancréas | `eph-qc-hemochromatose` (C) |
| 12 | « Alpha 1 ↓ : orosomucoïde ↓ » (aussi en 2025-26), quand le tableau imprime α1 à 2,3 g/L, dans les normes | `eph-qc-nephrotique` (explication) |
| 12 (figure) | « Le glomérule filtre moins bien le sang lors de la diurèse » : formule obscure ; à lire « le filtre abîmé retient moins bien les protéines » (ronéos 2023-24 p. 8, 2024-25 p. 10), ce n'est pas la filtration du sang qui baisse | `eph-qc-nephrotique` (explication) |
| 14 | le VIH parmi les causes d'hypogammaglobulinémie (cours depuis 2023-24) : il donne le plus souvent une hypergammaglobulinémie polyclonale (Moir et Fauci 2009) | `eph-qc-hypogamma` (D) |
| 15 (figure) | « électrophorégramme normale » en fin de traitement, avec γ à 5,6 g/L, sous la normale : normal par la forme, pas par la quantité | `eph-qc-myelome` (C) |

Une imprécision qui n'est pas une erreur : le ronéo dit « gamma normal » chez
Marc (p. 11) pour 7,8 g/L, juste sous 8,0 ; le ronéo 2023-24 rapportait que
cette « petite baisse » n'était « pas très significative ». La carte
`eph-qc-marc` le dit sans `ATTENTION`.

## Absent du cours 2026-27

Six cartes, tirées du même ED des années précédentes, dans des sections que le
ronéo 2026-27 couvre en entier sans les reprendre ; elles citent la page de
leur ronéo :

| Carte | Ce qu'elle porte | Source |
|---|---|---|
| `eph-fa-charge-ph` | pH supérieur au point isoélectrique, tampon basique, protéines chargées négativement (l'anode et la cathode, sur la figure 2026-27, ne sont pas des trous) | 2023-24, p. 6-7 |
| `eph-fa-hypogamma-causes` | causes primitives (« enfants bulles »), corticoïdes, rayons X, agammaglobulinémie (les causes physiologiques, au cours 2026-27, ne sont pas un trou) | 2024-25, p. 11 |
| `eph-qc-myelome-consequences` | envahissement médullaire, fractures, atteinte rénale, typage des chaînes légères, pic à surveiller | 2024-25, p. 12 ; 2023-24, p. 10 |
| `eph-qr-pct-thyroide` | la procalcitonine des cellules C de la thyroïde | 2024-25, p. 6 |
| `eph-qr-cas1-etiologie` | l'hépatite (virale) du cas n°1 | 2023-24, p. 4 ; 2024-25, p. 4 |
| `eph-rv-hemochromatose` | gène HFE, hyperabsorption intestinale, saignées | 2023-24, p. 6 |

Dans ces deux textes à trous, chaque trou est absent du cours 2026-27 : ce que
le ronéo de l'année porte reste écrit en clair, pour que le badge « Absent du
cours 2026-27 » ne tombe jamais sur une notion qu'il enseigne.

## En attente des ronéos suivantes

Rien : l'ED est complet en une séance, et son ronéo va jusqu'à la conclusion
(p. 16). Les ED2 et ED3 de biochimie sont d'autres chapitres.

## Le lexique

Quinze termes, tous nouveaux pour BMCP, pages mesurées dans le texte du PDF
(`protéinurie`, écrit seulement dans la figure p. 12, y a été lu) :
électrophorèse (`lex-electrophorese-bmcp` : le terme est déjà au lexique
d'immunologie, `lex-electrophorese`, d'où un identifiant propre), protéinogramme,
protidémie, orosomucoïde, haptoglobine, transferrine, ferritine,
procalcitonine, hémolyse, protéinurie, hémochromatose, gammapathie,
hypogammaglobulinémie, hypergammaglobulinémie, myélogramme. Laissés à leur
chapitre BMCP : myélome (`bmcp_bases_imagerie`), dénutrition (`bmcp_proteines`),
anamnèse (`bmcp_depistage`).

Les étymologies sont proposées dans le brouillon `etym/bmcp_ed_electrophorese.json`
(quatre racines nouvelles : `oros- (grec)`, `mucus (latin)`, `gamma (grec)`,
`calc- (latin)`) ; une fois versées dans `etymologies.json`,
`appliquer_etymologies.py` les écrira dans `LEXIQUE`.

## Relecture du 11/10/2026

Un second passage a relu chaque carte contre la page qu'elle cite, et chaque
erreur relevée en cherchant à la réfuter. Ce qu'il a changé :

- **ajouté** trois erreurs que le premier passage n'avait pas vues : l'albumine
  « éliminée par le rein » (p. 3, nouvelle carte `eph-qc-albumine`, qui
  remplace aussi cette phrase dans la note du n° 11 de la planche) ; les pics
  « restes » tous dits mélanges d'immunoglobulines (p. 9,
  `eph-qc-formes-pics`) ; la rate de l'hémochromatose (p. 8, point douteux,
  `eph-qc-hemochromatose` ; le lexique dit « foie, cœur, pancréas ») ;
- **retiré** l'`ATTENTION (cours)` sur les 15 jours de l'albumine : la
  référence citée donnait en fait 17 jours, et l'écart ne fait pas une erreur ;
- **précisé** les sources : la phrase des « demi-vies de 3j » vient mot pour
  mot du Ronéosaure 2025-26 ; le VIH et les cellules qu'il infecte, par le
  cours de virologie ; la « personne quantitativement saine », par le compte
  rendu du Ronéosaure 2025-26 ; la phrase du glomérule, lue pour ce qu'elle
  veut dire ;
- **légendé** les deux figures de la p. 15 pour qu'elles ne disent plus
  « leucémie » sans correction ;
- **réduit** les trous des deux textes à trous absents du cours 2026-27 à ce
  qui en est vraiment absent.

## À relire

Aucune carte `a-relire` : chaque carte cite sa page, relue sur le PDF ou sur
la figure. Les cartes absentes citent la page du ronéo de leur année.

## Régénérer

```powershell
cd contenu\chapitres\bmcp_ed_electrophorese
..\..\..\app\.venv\Scripts\python.exe generer.py
```

La planche numérotée se refait depuis `app/`, Pillow disponible :
`python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/bmcp_ed_electrophorese eph-pl-positions --apercus <brouillon> --taille 20`.

## Questions pour Vincent

- (11/10) VIH et hypogammaglobulinémie : le cours cite le VIH parmi les causes depuis 2023-24, alors que la référence l'associe surtout à une hypergammaglobulinémie. Le point est classé douteux, et la carte fait répondre comme le cours. Faut-il trancher ?
- (11/10) Demi-vies de la diapositive p. 3 : seule la CRP (12 h contre 19 h selon Pepys) reste signalée en ATTENTION (cours). Pour l'albumine, 15 jours contre 17, l'écart a été jugé trop faible pour une erreur. Est-ce le bon seuil pour des valeurs de diapositive ?
- (11/10) Hémochromatose : la diapositive cite la rate (« foie, rate, cœur… »), alors que l'hémochromatose génétique l'épargne. J'ai gardé la proposition vraie, comme la diapositive, avec un ATTENTION (douteux). Préférez-vous qu'on la reformule sans la rate ?
