# Membre supérieur (Schémas n°4) — paquet Anatomie

33 notes, 33 cartes. Chapitre `chap-ue-anatomie-sch4` de l'UE Anatomie
(identifiant et nom du squelette, ordre 1004), construit en même temps que
`anat_fc3`, `anat_fc4` et `anat_sch3` ; examen de novembre (aucune date encore,
donc pas d'`EXAMENS`). La base est le Ronéosaure 2024-25, dont les planches
gardent leur fiche ; **le chapitre a été relu le 11/10/2026 sur les deux
ronéos 2026-27** du Pr Demondion, qui font foi (section « Relus sur la ronéo
2026-27 »).

L'examen d'anatomie est un schéma, pas un QCM (FC4 p. 2 et 5, Book Schéma p. 2) :
le professeur donne un fond de schéma à orienter, fait nommer ce qui est fléché,
et demande de dessiner et d'annoter vaisseaux et nerfs. Le chapitre est donc
fait de **planches à légender**, une par dessin, et de l'annale 2023/2024, qui
porte sur le même dessin que la planche p. 4.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| Planche à légender (`legend`) | 19 | 19 |
| Schéma à refaire sur papier (recto-verso) | 10 | 10 |
| QRM | 3 | 3 |
| QRU | 1 | 1 |

- Neuf planches du cours, une par page des Schémas n°4 : **141 numéros**.
- Une planche d'annale, sur le sujet 2023/2024 lui-même : 3 numéros.
- Neuf planches du Book Schéma 2025-26 (n° 7, 9 à 15 et la p. 31) : 119 numéros.
- **95 intrus** en tout, de la même région, et jamais un synonyme d'une légende.
- **Dont 5 annales**, toutes de la session 2023/2024 : la planche de la consigne
  2, une QRU (consigne 1) et trois QRM (consigne 3). Aucune n'a de clé de la
  faculté.
- **4 QCM sur 4 illustrés** : le sujet avant la question, la correction du
  Ronéosaure en réponse.
- Aucune carte `a-relire` depuis le 19/10 (la coupe du canal carpien est
  relue sur le 3e ronéo 2026-27, voir plus bas), aucune carte absente du cours
  2026-27 ; **8 cartes portent un piège des ronéos 2026-27** (thème
  `piege-roneo`) : les planches `ms-s4-os-bras`, `ms-s4-muscles-bras`,
  `ms-s4-muscles-avant-bras`, `ms-s4-vasc-avant-bras`, `ms-s4-muscles-carpe`,
  `ms-b9-avant-bras-sup`, `ms-b11-avant-bras-prof` et `ms-b13-loge-post-prof`.

Huit thèmes, un jeu partagé par tout le membre supérieur (plan de répartition
des quatre chapitres). Chaque planche porte sa couche en thème, et sa région en
tag, plus la seconde couche quand la planche est mixte. Leurs libellés sont
dans `THEME_LABELS` (`app/src/med_engine/application/scopes.py`).

| Clé | Libellé |
|---|---|
| `bras` | Bras |
| `avant-bras` | Avant-bras |
| `main` | Main et carpe |
| `osteologie` | Ostéologie |
| `insertions-musculaires` | Insertions musculaires |
| `nerfs` | Nerfs : origine, trajet, territoire |
| `vascularisation` | Vascularisation |
| `orientation-schema` | Orienter et compléter un schéma |

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-anat-sch4-2425` — Ronéosaure, « Schémas n°4 - Membre supérieur » (9 p.) | 2024-25 | **la base** : les neuf planches, dessins du Pr Demondion redessinés et légendés par l'équipe ronéo ; déclarée fiche du chapitre (`chapitre=`) ; c'est ce que le lecteur ouvre |
| Ronéo & Juliette, « TOPOGRAPHIE DU MEMBRE SUP » et « TOPOGRAPHIE MEMBRE SUP 2 » (10 et 8 p.) | 2026-27 | **le cours de l'année**, qui fait foi : cité en premier dans les phrases (« cours 2026-27 », « 2e cours 2026-27 ») ; déclarés par `anat_fc3` et `anat_fc4`, pas ici |
| `src-annales-anat-ms` — Ronéosaure, « Anatomie du membre SUP » (3 p.) | 2024-25 | l'annale 2023/2024 session 1 (énoncé p. 2, correction non officielle p. 3) |
| FC n°4 2024-25 (« Membres supérieurs 2 », 12 p.) | 2024-25 | la matière des phrases de correction, citée par page ; déclarée par `anat_fc4`, pas ici |
| FC n°3 2024-25, Charonéos 2023-24 cours 3 et 4 | 2023-24, 2024-25 | appoint : trajets des nerfs, rapports dans l'aisselle, insertions de la main ; déclarés par `anat_fc3` et `anat_fc4` |
| Erratas d'anatomie 2024-25, section membre supérieur (9 entrées) | 2024-25 | sept portent sur les Schémas n°4 ; tranchées plus bas |

Les sources déjà déclarées par un autre chapitre ne sont pas redéclarées ici :
un import écraserait l'une par l'autre, et la FC4 perdrait son lien de fiche.
Une exception, depuis le 18/10 : le Book Schéma 2025-26 du membre supérieur
(`src-book-schema-ms-2526`), déclaré **à l'identique**, champ par champ, de
`anat_sch3`, dont il reste la fiche (`chapitre="chap-ue-anatomie-sch3"`) :
deux paquets qui l'importent écrivent la même ligne.

## Le Book Schéma 2025-26 (C17)

Ses corrections sont des images : chaque planche se fait avec
`scripts/planche_depuis_image.py`, un rectangle par légende dans `donnees.py`,
l'aperçu de contrôle relu. Les n° 1 à 6 et 8 sont dans `anat_sch3` ; ici, au
18/10, les n° 7 et 9 à 15 et la planche sans numéro de la p. 31. D'abord le **n° 7, vue antérieure du bras** (fond p. 10, correction p. 26) :
`ms-b7-bras-ant` (19 numéros, « Haut » et « Gauche » compris) et
`ms-rd-bras-ant` (dix-sept structures). Le fond porte la flèche vers la
gauche, que la carte nomme « Droite » ; la correction trace « Gauche » vers la
droite : la même orientation. Les coquilles du Book (« Artère brachial »,
« Nerf median », « Épicondyliens mediaux », « Muscle su scapulaire ») sont
corrigées dans la liste et dites dans la phrase. Deux erreurs de la FC n°3
2025-26 portent un `ATTENTION` simple : « chef long » pour le tendon commun
avec le coraco-brachial (p. 3, c'est le chef court), et les nerfs cutanés
médiaux nés de l'ulnaire (p. 4 : ils naissent du faisceau médial). Relu par
un sceptique le 18/10 : orientation du verso, citations resserrées, coquilles
dites.

Puis, le 18/10, les **n° 9 à 11, l'avant-bras droit vu de face**, en trois
plans (fonds p. 12-14, corrections p. 28-30) :

| Planche | Numéros | Intrus | Carte « à refaire » | Structures |
|---|---|---|---|---|
| `ms-b9-avant-bras-sup`, plan superficiel | 13 | 6 | `ms-rd-avant-bras-sup` | onze |
| `ms-b10-avant-bras-inter`, plan intermédiaire | 12 | 6 | `ms-rd-avant-bras-inter` | neuf |
| `ms-b11-avant-bras-prof`, plan profond | 8 | 6 | `ms-rd-avant-bras-prof` | six |

Ces trois corrections sont les figures de la FC n°3 2025-26 (p. 6, 7 et 9),
que le Book recopie avec leurs erreurs. La carte retient la bonne légende et le
dit par un `ATTENTION` simple :
- au n° 10, « Processus styloïde de l'ulna » et « Radius » sont inversés : le
  dessin met le pisiforme et le tendon commun des épicondyliens médiaux à
  droite, du côté médial, comme l'avait relevé l'errata 2025-26 de la promo.
  Retenus : le processus styloïde du radius, et l'ulna ;
- au n° 11, « Gauche » est écrit sur la flèche vers la gauche. Retenu :
  « Droite », comme « Dt » sur la figure du 2e cours 2026-27 (p. 5) ;
- au n° 11 encore, « nerf interosseux postérieur » désigne l'antérieur, la
  branche du médian, que la même FC nomme juste p. 15.

Les phrases disent aussi quatre erreurs du texte de la FC n°3 2025-26 :
- la branche superficielle du radial qui innerverait le brachio-radial (p. 6) ;
- l'« abduction » du poignet par le fléchisseur ulnaire du carpe (p. 7) : c'est
  une adduction ;
- le pisiforme articulé avec les os de l'avant-bras (p. 8) : il ne s'articule
  qu'avec le triquetrum ;
- le nerf ulnaire « en dedans du pisiforme » (p. 10) : il passe en dehors.

Les coquilles du Book (« Nerf median », « Nerf médial », « Retinaculum »,
« rond pronateur pronateur », « Vue antérieur de l'avant bras ») sont
corrigées dans la liste et dites dans la phrase. Dans la liste, chaque muscle
s'écrit « Muscle … », pour qu'aucune forme ne trahisse une légende. Deux
erreurs du 2e cours 2026-27, déjà relevées, touchent ces planches et y portent
leur genre : le supinateur à faisceaux « latéral et médial » (douteux, n° 9)
et la membrane interosseuse « dans le coude » (prise de notes, n° 11).

La correction du n° 10 est posée sur un panneau gris clair (252) : sa planche
porte `fond=(252, 252, 252)`, dont `planche_depuis_image.py` remplit les
rectangles, sans quoi leurs bords blancs dessinaient la longueur de chaque
légende — et aidaient à déjouer le piège du radius et de l'ulna. Relu par un
sceptique le 18/10 : aucune légende changée ; une erreur prêtée à tort à la
FC retirée (le « lacertus fibrosus » du fléchisseur ulnaire du carpe), une
citation retirée (le supinateur), cinq phrases précisées (Guyon, interosseux
antérieur, nerf médian au poignet, pisiforme, canal du fléchisseur radial du
carpe), et le fond gris.

Enfin, le 18/10, **la face postérieure et la main** : la planche sans numéro
de la p. 31 et les n° 12 à 15 (fonds p. 15-18, corrections p. 31-35) :

| Planche | Numéros | Intrus | Carte « à refaire » | Structures |
|---|---|---|---|---|
| `ms-bp31-os-avant-bras-post`, os vus de dos (p. 31) | 16 | 6 | `ms-rd-os-avant-bras-post` | quatorze |
| `ms-b12-loge-post-sup`, loge postérieure, plan superficiel | 12 | 6 | `ms-rd-loge-post-sup` | dix |
| `ms-b13-loge-post-prof`, loge postérieure, plan profond | 14 | 6 | `ms-rd-loge-post-prof` | douze |
| `ms-b14-main-laterale`, vue latérale de la main | 17 | 6 | `ms-rd-main-laterale` | quinze |
| `ms-b15-rayon-ii`, vue latérale du 2e rayon | 8 | 6 | `ms-rd-rayon-ii` | six |

La p. 31 n'a pas de fond propre : sa carte « à refaire » montre celui du
n° 13 (p. 16), qui porte les mêmes os. Les n° 12 à 15 recopient les figures
de la FC n°3 2025-26 (p. 11 à 14), avec leurs erreurs, que la carte corrige
par un `ATTENTION` simple :
- au n° 13, « tubérosité brachiale » : la flèche finit sur le radius, sous sa
  tête ; c'est la tubérosité bicipitale (la tubérosité brachiale est sur
  l'ulna) ;
- au n° 14, « M1 » est écrit sur le métacarpien de l'index (la chaîne du haut,
  trois phalanges) : c'est le deuxième ; le premier porte le pouce.

Les phrases disent aussi deux erreurs du texte de la FC : la tête du radius
« en contact avec la trochlée et le caviculum » (p. 6), qui s'articule avec le
capitulum ; et le mouvement des interosseux et des lombricaux « permis par le
nerf ulnaire » (p. 15), quand les lombricaux I et II, dont celui de l'index,
sont innervés par le médian. Deux erreurs du 2e cours 2026-27, déjà relevées,
portent leur genre au n° 13 : la membrane interosseuse « dans le coude »
(prise de notes) et le supinateur à faisceaux « latéral et médial » (douteux).
À la vue latérale de la main, les six flèches de droite finissent sur des
tendons : la liste dit « Tendon du muscle … ».

Les noms imprimés que la liste complète ou corrige sont dits dans la phrase : « Muscle stabilisateur du coude » (l'anconé), « long extenseur du
carpe » (radial), « Cole », « bicipital », « M1 », « M2 », et les abréviations
des repères (« Ht », « Dt », « Arr. », « Prox. », « Post », « Dist »). Le bord
de la page coupe trois mots au n° 12 (« e », « …chisseur », « …tenseur ») ;
un reste de fond (« TITRE : ») traîne au bas de la p. 35.

Les corrections des p. 33 à 35 posent leur dessin sur un panneau gris clair
(252) que les légendes de droite débordent : leurs planches portent
`fond="auto"`, qui remplit chaque colonne d'un rectangle de la couleur la plus
fréquente de son pourtour, hors des autres rectangles. Trois numéros collés à
un trait ou au bord du panneau prennent une couleur fixe (`fond=` sur le
numéro). Les rectangles ont été relevés à la main, puis élargis jusqu'aux
pixels gris clair des lettres (seuil 245) : la détection à 160 laissait des
bouts de lettres. Les numéros font 17 px (`taille=`), 16 au n° 14, où le
numéro 14 tient entre deux traits.

Relu par un sceptique le 18/10. Il a redressé une erreur de la première
version : la flèche « trapézoïde » du n° 14 finit bien sur le trapézoïde, le
petit os entre le capitatum, le scaphoïde et le trapèze (ce dernier, dessiné
sans numéro, porte le pouce) ; la légende du Book est gardée. Repris aussi :
quatre pointes de flèche que les rectangles rognaient, le haut du « M1 », les
deux erreurs 2026-27 du n° 13, l'innervation des lombricaux, l'anconé
(latéral, pas médial), deux intrus que le dessin pouvait montrer.

Enfin, **la coupe du canal carpien**, dessinée par le Pr Demondion au CM du
06/10/2026, que le Book n'a pas : une carte « à refaire sur papier »,
`ms-rd-canal-carpien`, faite sur deux captures du cours (la photo du dessin
légendé à la main, 457 × 349 px, et sa version en couleurs sur la
diapositive). Le fond (`ms-cc-fond.png`) garde les seuls contours des os du
dessin en couleurs : couleurs, initiales et pointillés retirés. La correction
(`ms-cc-correction.png`) met les deux dessins côte à côte. Neuf structures :
le rétinaculum, les fléchisseurs superficiels (sur deux plans) et profonds,
le long fléchisseur du pouce, le nerf médian ; hors du canal, le fléchisseur
radial du carpe, le long palmaire, l'artère et le nerf ulnaires. La carte
cite depuis le 19/10 le **3e ronéo 2026-27** (« TOPOGRAHIE MEMBRE SUP 3 »,
CM du 06/10/2026, p. 8-9), qui reproduit ce dessin légendé : il est redéclaré
ici **à l'identique** de `anat_fc4`, dont il reste la fiche
(`chapitre="chap-ue-anatomie-fc4"`), comme le 2e cours. Relue sur lui : les
cinq os (scaphoïde, capitatum, hamatum, triquetrum, pisiforme — les deux du
milieu étaient illisibles sur la photo), les neuf structures et leur ordre, les
superficiels et les profonds dessinés chacun sur un seul rang, la gaine commune
et la gaine propre du long fléchisseur du pouce, le dédoublement du
rétinaculum pour le fléchisseur radial du carpe. Le tag `a-relire` est retiré.
La correction est désormais `ms-cc-correction-2627.png` : la figure légendée du
ronéo en haut, les deux captures du cours en bas. Les coulisses des extenseurs,
que la photo ne laisse lire qu'à moitié et que le ronéo ne reprend pas, restent
hors barème.

Le Book Schéma 2024-25 - Membre supérieur, p. 20-28, reprend les mêmes neuf dessins, à
l'octet près, sauf un trait de rappel orphelin p. 22 : les planches sont tirées
des Schémas n°4.

Vérifié hors du cours, et cité dans la carte qui s'en sert (Gray's, par
Wikipédia) : le trajet de l'artère ulnaire sous les épicondyliens médiaux, le
médian entre les deux chefs du rond pronateur, le musculo-cutané qui perfore le
coraco-brachial, la branche superficielle du radial sous le brachio-radial, le
cutané médial du bras dans l'aisselle, l'innervation des deux faisceaux du court
fléchisseur du pouce, les insertions de l'adducteur et de l'opposant du pouce,
les attaches du rétinaculum des fléchisseurs. La zone capitulo-trochléaire est
la « zone conoïde » des traités français.

## Ce que les schémas ont dicté

**Aucun gris, aucune planche d'atlas.** Le rouge du ronéo est son code couleur
(artères rouges, veines bleues, nerfs jaunes, muscles bruns), pas une consigne.
Le Book p. 2 rappelle que le professeur peut faire redessiner muscles, artères,
veines et nerfs, qu'il insiste sur la bonne localisation, et que des coquilles
restent possibles.

**Les conventions de dessin du professeur** sont dites dans les phrases des
numéros concernés :
- le pointillé pour ce qui passe derrière (radial à la face postérieure de
  l'humérus, ulnaire derrière le septum, musculo-cutané dans le coraco-brachial) ;
- une petite boule, pas une flèche, pour une terminaison cutanée (FC4 p. 7) ;
- les nerfs en noir, pas en jaune, dans l'annale.

**Les planches** (`scripts/planche_depuis_pdf.py`, chaque aperçu de contrôle
relu, zoomé là où deux numéros se touchent) :

| Planche | Page | Numéros | Intrus | Thème, tags | Fabrication |
|---|---|---|---|---|---|
| `ms-s4-plexus` | 1 | 9 | 4 | nerfs ; bras | sans reprise |
| `ms-s4-os-bras` | 2 | 19 | 5 | osteologie ; bras | `--cote 5:droite --cote 6:droite` : les deux légendes se chevauchent dans le PDF, et le script avait donné à chacune le trait de l'autre, numéros rapetissés |
| `ms-s4-muscles-bras` | 3 | 16 | 4 | insertions-musculaires ; bras | le n°14 (brachio-radial) n'a pas de trait vectoriel : son trait est dans l'image, sur la même ligne, numéro gardé à gauche |
| `ms-s4-vasc-bras` | 4 | 14 | 5 | vascularisation ; nerfs, bras | sans reprise : les rameaux du musculo-cutané (8, 10, 12) sont au départ de leur trait |
| `ms-s4-os-avant-bras` | 5 | 19 | 4 | osteologie ; avant-bras | sans reprise |
| `ms-s4-muscles-avant-bras` | 6 | 20 | 4 | insertions-musculaires ; avant-bras | `--cote 13:droite --cote 15:droite` : même chevauchement, 13 rapetissé et hors de son trait |
| `ms-s4-vasc-avant-bras` | 7 | 8 | 4 | vascularisation ; nerfs, avant-bras | sans reprise |
| `ms-s4-os-carpe` | 8 | 22 | 3 | osteologie ; main | sans reprise |
| `ms-s4-muscles-carpe` | 9 | 14 | 4 | insertions-musculaires ; nerfs, main | sans reprise |

Dans chaque planche, aucune légende n'est restée lisible, rien de ce qui devait
rester (titre, « Haut », « Droite ») n'a disparu, et chaque numéro est au départ
de son trait. Quand une légende sert deux numéros, elle est écrite à
l'identique : deux « Muscle biceps brachial » (p. 3), deux tendons du
fléchisseur radial du carpe et deux du long fléchisseur du pouce (p. 6), au-dessus
et au-dessous du rétinaculum, deux phalanges proximales et deux distales (p. 8),
l'origine et la terminaison du court abducteur du pouce (p. 9). Une légende à
deux flèches reste un seul numéro : supinateur (p. 6), os sésamoïdes (p. 8).

« Aponévrose palmaire » n'est pas un intrus de la planche p. 6 : la FC4 p. 8
dit que le tendon du long palmaire « correspond à l'aponévrose palmaire », ce
qui en ferait un synonyme du n°18. Le court palmaire le remplace.

Rien n'a été repris des planches en « nommez » dans les chapitres des FC, et ce
chapitre ne refait aucune carte des FC : les phrases de correction les citent.

## Ce que l'annale a dicté

Une seule question, 2023/2024 session 1 : la vue antérieure du bras droit,
dessin du professeur, avec les trois faisceaux du plexus déjà légendés. Quatre
consignes, et quatre formes de cartes :

1. **orienter** avec les repères en bas à gauche : une QRU
   (`ann-ms-2324-orientation`) ;
2. **nommer 1 à 3** : une planche à légender sur le sujet lui-même
   (`ann-ms-2324-structures`), les numéros imprimés par le professeur ;
3. **ajouter le médian, le radial et le musculo-cutané** : une QRM par nerf
   (`ann-ms-2324-median`, `-radial`, `-musculocutane`). Chacune dit d'où part le
   nerf, où il passe par rapport à l'artère et aux muscles, et comment il se
   dessine (plein ou pointillé, boule ou flèche) ;
4. **dessiner en noir** : dit dans l'énoncé des QRM.

Le sujet est montré avant la question : c'est un dessin sans réponse. La
correction du Ronéosaure, la planche p. 4, est montrée en réponse.

## Les clés et les légendes qui ne sont pas reprises telles quelles

| Carte | Imprimé | Retenu | Pourquoi |
|---|---|---|---|
| Les cinq annales | aucune clé de la faculté ; « correction non officielle faite par le/la secrétaire errata » | clés déduites du cours, `officielle=False`, dit en tête de chaque explication | la correction est une planche de l'équipe ronéo |
| `ann-ms-2324-structures` | la correction ne nomme pas 1 à 3 | 1 grand dorsal, 2 biceps brachial, 3 brachio-radial | le même dessin est légendé p. 3 des Schémas n°4 (n°9, 13 et 14) |
| `ann-ms-2324-musculocutane`, B | la correction dessine le nerf en trait plein devant le coraco-brachial | faux (`CONFLITS`) | il perfore le muscle (FC4 p. 6 ; 2023-24 cours 4 p. 7 et 10 ; Gray's), et le professeur l'a dessiné en pointillé (errata E8) |
| `ann-ms-2324-orientation` | « Haut », « Droite » | repris | membre droit vu de face ; « Latéral » dirait la même chose, les planches écrivent « Droite » |
| `ms-s4-muscles-bras`, n°15 | « Lapersus fibrosus » | « Lacertus fibrosus » | coquille de la planche ; la légende de la correction le signale |

## Les erreurs des planches

Les erreurs du Ronéosaure portent un `ATTENTION` sans genre, dans la phrase du
numéro, et n'entrent pas dans `contenu/ERRATA_RONEOS_2026-27.md`, qui ne liste
que les ronéos de l'année ; celles des ronéos 2026-27 sont dans la section
suivante. Le 2e cours 2026-27 confirme quatre des corrections ci-dessous : le
radial « croise l'humérus par sa face postérieure », le musculo-cutané
« traverse le muscle coraco-brachial », le radial « ressort en profondeur du
muscle brachioradial » (p. 4), le médian « descend entre les deux faisceaux du
muscle rond pronateur » (p. 7).

| Planche, numéro | Ce que montre le dessin | Ce qui est juste | Source | D'où |
|---|---|---|---|---|
| `ms-s4-plexus` n°9 | le nerf radial descend en avant de l'humérus | en arrière de l'artère axillaire, médial à l'humérus, puis face postérieure par l'espace axillaire inférieur | FC3 p. 5, FC4 p. 2 et 7, Gray's | errata E2, accepté |
| `ms-s4-plexus` n°6 (et 7) | cutané médial du bras en superficie de la veine, ulnaire en profondeur | **point douteux** : en référence, le cutané médial du bras est le plus médial, d'abord derrière la veine puis médial à elle, et l'ulnaire chemine entre artère et veine, ce qui va dans le sens de l'erratum ; le cours 2023-24 du même professeur donne l'ordre du dessin. Légendes gardées telles qu'imprimées | Gray's ; 2023-24 cours 4 p. 7 | errata E9, laissé ouvert |
| `ms-s4-vasc-bras` n°5 | le musculo-cutané passe devant le coraco-brachial, en trait plein | il le perfore, en pointillé | FC4 p. 6, 2023-24 cours 4 p. 7 et 10 | errata E8, accepté |
| `ms-s4-vasc-avant-bras` n°8 | l'artère ulnaire passe devant les épicondyliens médiaux | sous le rond pronateur (chef profond), le fléchisseur radial du carpe, le long palmaire et le fléchisseur superficiel | Gray's | errata E3, accepté |
| `ms-s4-vasc-avant-bras` n°5 | le nerf médian passe devant le rond pronateur | entre ses deux chefs | FC4 p. 8-9, 2023-24 cours 3 p. 6, Gray's | errata E4, précisé |
| `ms-s4-vasc-avant-bras` n°4 | la branche superficielle du radial passe devant le brachio-radial | sur sa face profonde, puis sous son tendon distal | FC4 p. 10, 2023-24 cours 3 p. 5, Gray's | errata E5, accepté |
| `ms-s4-muscles-bras` n°15 | « Lapersus fibrosus » | lacertus fibrosus | FC4 p. 4 et 7 | trouvé en relisant |

Les deux entrées de l'errata sur la planche p. 9 :
- **E6**, les deux faisceaux du court fléchisseur du pouce, séparés par le
  tendon du long fléchisseur, est **accepté** comme précision. Le dessin n'est
  pas faux, donc il n'y a pas d'`ATTENTION` : la phrase du n°12 le dit.
- **E7**, « le médian innerve le faisceau profond », est **rejeté**. Le médian
  innerve le faisceau superficiel, l'ulnaire le profond (FC4 p. 11 ; Gray's). La
  phrase du n°12 le dit.

Quelques phrases corrigent en passant la FC4, sans `ATTENTION`, parce que ces
erreurs appartiennent aux cartes d'`anat_fc4` :
- les tubérosités bicipitale et brachiale confondues (p. 4) ;
- le pisiforme « latéral » (p. 10) ;
- l'opposant sur le « trapézoïde » (p. 11) ;
- l'adducteur sur le sésamoïde « latéral » (p. 11) ;
- l'artère « axillaire » qui se diviserait au coude (p. 6) ;
- l'espace axillaire inférieur « sous le grand pectoral » (p. 7).

## Le lexique

Aucun terme. Le plan de répartition confie le lexique du membre supérieur à
`anat_fc3` et `anat_fc4`, qui l'emploient dans leurs FC. Le fichier de
propositions d'étymologie de ce chapitre est donc vide.

## À relire

Aucune carte `a-relire` : `ms-rd-canal-carpien` a été relue le 19/10/2026 sur
le 3e ronéo 2026-27 (p. 8-9). Les autres numéros ont été relus sur la planche
légendée, et chaque phrase sur la page de la FC qu'elle cite, puis sur les
ronéos 2026-27.
Un cas reste ouvert : l'ordre du cutané médial du bras et de l'ulnaire dans
l'aisselle (n°6-7 de la planche du plexus). La carte le dit ; les deux ronéos
2026-27 parues n'en parlent pas.

## Relus sur la ronéo 2026-27

Le 11/10/2026, chaque numéro des dix planches a été relu contre les deux ronéos
2026-27 du Pr Demondion (Ronéo & Juliette, cours du 29/09/2026), PDF et figures
compris. Dans les phrases, « cours 2026-27, p. N » renvoie au 1er cours
(« TOPOGRAPHIE DU MEMBRE SUP »), « 2e cours 2026-27, p. N » au second
(« TOPOGRAPHIE MEMBRE SUP 2 ») : sa partie I (p. 2-4, figure p. 2) refait la vue
antérieure de l'épaule et du bras, donc les planches p. 1 à 4 ; sa partie II
(p. 5-7, figure p. 5) celle de l'avant-bras et du carpe, donc les planches p. 5
à 8. Le fond de la vue antérieure du bras est listé au 1er cours (p. 10). Les
planches restent celles du Ronéosaure : les deux figures 2026-27 sont d'autres
dessins, et `anat_fc4` en tire déjà une planche (l'avant-bras).

**Ce qui a changé** : la phrase de chaque numéro que le cours 2026-27 traite
cite sa page d'abord, et dit ce qu'il dit autrement ; aucune légende, aucun
numéro, aucun intrus ni aucune image n'a changé.

| Planche | Numéros relus sur 2026-27 | En attente des ronéos suivantes |
|---|---|---|
| `ms-s4-plexus` (p. 1) | 7 / 9 | n°4 et 6, les cutanés médiaux |
| `ms-s4-os-bras` (p. 2) | 19 / 19 | — |
| `ms-s4-muscles-bras` (p. 3) | 16 / 16 | — |
| `ms-s4-vasc-bras` (p. 4) | 14 / 14 | — |
| `ms-s4-os-avant-bras` (p. 5) | 17 / 19 | n°12 tête de l'ulna, n°14 styloïde radial |
| `ms-s4-muscles-avant-bras` (p. 6) | 20 / 20 (le 19/10 : n°4, 5, 6, 13, 14, 18, 19, 20 sur le 3e cours) | — |
| `ms-s4-vasc-avant-bras` (p. 7) | 7 / 8 | n°3 tronc commun des interosseuses (le cours n'a fait que le « DÉBUT DE LA VASCULARISATION ET DES NERFS ») |
| `ms-s4-os-carpe` (p. 8) | 22 / 22 (le 19/10 : n°12 à 22 sur le 3e cours, p. 3 et 10) | — |
| `ms-s4-muscles-carpe` (p. 9) | 14 / 14 (le 19/10, sur le 3e cours, p. 3-12) | — |
| `ann-ms-2324-structures` (annale) | 3 / 3 | — |

Les quatre annales 2023/2024 citent aussi le 2e cours 2026-27 dans leurs
justifications, et leurs explications rappellent qu'il est « DÉJÀ TOMBÉ EN
EXAMEN » de replacer le trajet des nerfs (p. 4).

Deux remarques sur les figures 2026-27 :
- le carré pronateur, dessiné en 2026-27 (2e cours, p. 5-6), n'est pas sur la
  planche p. 6 : il y reste un intrus ;
- les épicondyles, que le 1er cours range dans le fond du bras (p. 10), sont
  dessinés sans numéro sur la planche p. 2 : ils y restent des intrus.

**Les erreurs des ronéos 2026-27 portées ici**, à verser dans
`contenu/ERRATA_RONEOS_2026-27.md` avec ces cartes :

| Ronéo, page | Ce qu'il dit | Ce qui est juste | Genre | Carte | D'où |
|---|---|---|---|---|---|
| 1er cours, p. 2 (fond) | « incisure supra-claviculaire » pour l'encoche du bord supérieur de la scapula | l'incisure scapulaire (même ronéo, p. 5 et 10) | prise de notes | `ms-s4-os-bras` (n°4) | trouvée en relisant |
| 1er cours, p. 4 | la coiffe entière, « P.I.S.S: Petit rond, Infra-épineux, Supra-épineux, Subscapulaire », sur le tubercule majeur | le subscapulaire se termine sur le tubercule mineur (même ronéo, p. 9 ; 2e cours, p. 3) | prise de notes | `ms-s4-os-bras` (n°6) | trouvée en relisant |
| 2e cours, p. 3 | grand dorsal et grand rond insérés « sur le bord latéral de la scapula » | vrai du grand rond seul ; le grand dorsal naît de l'aponévrose thoraco-lombaire (1er cours, p. 4) | prise de notes | `ms-s4-muscles-bras` (n°9) | trouvée en relisant |
| 2e cours, p. 6 | radius et ulna « unis par l'articulation du coude, contenant une membrane interosseuse » | la membrane est une syndesmose tendue entre les corps des deux os, hors du coude (même ronéo, p. 6-7 ; Gray's) | prise de notes | `ms-s4-muscles-avant-bras` (n°12), `ms-b11-avant-bras-prof` (n° 6), `ms-b13-loge-post-prof` (n° 4) | trouvée en relisant |
| 2e cours, p. 3 | le biceps « Muscle supinateur accessoire » | c'est le cours lui-même (FC4 2024-25 p. 4). À l'examen : supinateur accessoire. La référence : supinateur puissant, le plus puissant coude fléchi | cours | `ms-s4-muscles-bras` (n°16) | trouvée en relisant |
| 2e cours, p. 6 | le supinateur à « 2 faisceaux : un latéral et un médial » | faisceaux superficiel et profond (Kenhub ; Gray's ; cours 2023-24) | douteux | `ms-s4-muscles-avant-bras` (n°7), `ms-b9-avant-bras-sup` (n° 5), `ms-b13-loge-post-prof` (n° 6) | trouvée en relisant |
| 2e cours, p. 4 | la branche superficielle du radial « à proximité de l'artère brachiale profonde » | à l'avant-bras, elle longe l'artère radiale (Gray's ; Radiopaedia) | douteux | `ms-s4-vasc-avant-bras` (n°4) | trouvée en relisant |

**Le 3e ronéo 2026-27 (19/10)** ajoute, portées sur `ms-s4-muscles-carpe` :
l'abducteur du V « sur le triquetrum » et la figure p. 9 qui l'appelle
« adducteur du petit doigt » (n°4) ; le court fléchisseur du V terminé « sur la
phalange intermédiaire » (n°9, n°14) ; l'opposant du V « sur le bord latéral »
(n°11) ; l'opposant du pouce sur le « bord médial » (n°10) — toutes de prise de
notes, détaillées au LISEZ_MOI de `anat_fc4`, avec les autres erreurs de ce
ronéo. L'artère radiale « derrière l'os pisiforme » (p. 6) est dite au n°6 de
`ms-s4-vasc-avant-bras`.

Ce sont les erreurs déjà relevées par la relecture de `anat_fc3` et
`anat_fc4` : ce chapitre n'en trouve pas d'autre, et ajoute ses cartes à leur
ligne. Les deux entrées du tableau de la promo (1er cours, p. 2 « sternum » et
p. 6 « sillon delto-pectoral ») ont été vues sur le PDF ; elles portent sur les
vues de la région scapulaire, et aucune planche de ce chapitre ne les
reproduit (elles sont portées dans `anat_sch3` et `anat_fc3`).

## Régénérer

```powershell
cd contenu\chapitres\anat_sch4
..\..\..\app\.venv\Scripts\python.exe generer.py
```

Les PNG des planches ne sont pas régénérés par `generer.py`. Ils se refont
depuis `app/`, avec les options ci-dessus, et l'aperçu de contrôle se relit à
chaque fois :

```powershell
uv run --with pymupdf python ..\.claude\skills\nouveau-chapitre\scripts\planche_depuis_pdf.py "<Schémas n°4 - Membre supérieur.pdf>" <page> <id> --sortie ..\contenu\chapitres\anat_sch4\media --apercus <brouillon>
```

`ann-ms-2324-sujet.png` est l'image de la p. 2 de l'annale, extraite à sa
définition d'origine (1055 × 1333) puis recadrée sur le dessin et ses repères
(115, 235, 975, 1175). L'énoncé est dans les cartes, et le tableau de réponse
est retiré.
