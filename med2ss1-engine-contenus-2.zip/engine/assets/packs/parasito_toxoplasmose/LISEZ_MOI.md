# Toxoplasmose — paquet Parasitologie et mycologie

80 notes, 131 cartes. Chapitre `chap-ue-parasito-fc6` de l'UE Parasitologie et
mycologie (`ue-parasito`). Cours du **Dr J. Leroy, le 18/11/2025**,
« Toxoplasmose » (FC n°6 du Ronéosaure 2025-26, 8 pages) ; annales du
polycopié « 6 - Toxoplasmose » du Ronéosaure 2024-25 (19 questions, 13
sessions) et du sujet 2024/2025 de l'UE (1 question, sans corrigé). Examen du
5 janvier 2027.

**Une fiche provisoire.** Le ronéo 2026-27 de ce cours n'est pas paru : le
chapitre est carté sur le Ronéosaure 2025-26 (tâche C16, décision de Vincent du
02/10), et le ronéo de l'année corrigera les cartes à sa parution. La source
porte son année dans son auteur (« Ronéosaure 2025-26 ») : chaque carte de
cours prend le tag `cours-2025-26` et le badge « Cours 2025-26 ». Aucune carte
ne dit « Absent du cours 2026-27 », et les erreurs du Ronéosaure sont dites par
un ATTENTION sans genre (précédent d'`immuno_cmh` et d'`immuno_innee`) : la
liste `contenu/ERRATA_RONEOS_2026-27.md` ne concerne que les ronéos 2026-27.

Le dossier contenait un brouillon laissé le 03/10 par une exécution
interrompue : `generer.py` (copie exacte du modèle, vérifiée), `schemas.py` et
onze figures dans `media/`. Tout a été relu : les onze PNG sont exactement les
images intégrées du PDF de la FC (comparées pixel à pixel, pages 2 à 8) ; les
zones des deux schémas tombent sur leurs tracés (aperçu superposé) ; quelques
légendes de la cinétique, qui chevauchaient les courbes, ont été déplacées.
`donnees.py`, `annales.py` et ce fichier ont été écrits.

**Relecture contradictoire (05/10).** Chaque carte a été relue contre la page
qu'elle cite, chaque clé contre la table de corrections (en image) ; l'errata
2025-26 n'a aucune entrée de toxoplasmose, et les citations du cours 2024-25
ont été retrouvées à leur page. Corrigé : la congélation de la viande cite la
fiche de l'ANSES telle qu'elle est (−12 °C à cœur, 3 jours au moins, et non
« sous −18 °C ») ; « cuire la viande à point » devient « bien cuire la viande »
(`tox-qc-hygiene` A) ; la justification D de `tox-qc-tachyzoite` cite la
diapositive plutôt que « sous des formes quiescentes » ; le macrogamète cite
aussi le schéma du cycle (p. 4) ; la racine `parasit(o)-` reprend mot pour mot
celle de `parasito_paludisme` ; la légende de l'amniocentèse, sur la frise, se
lit dans l'ordre.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 32 | 32 |
| Texte à trous | 10 | 49 |
| QROC | 9 | 9 |
| Recto-verso | 17 | 17 |
| Schéma cliquable | 2 | 14 |
| Lexique | 10 | 10 |

Dont **20 annales** : 10 QCM (QRM) et 10 QROC (recto-verso), sur 14 sessions,
de 2015/2016 S1 à 2024/2025 S1 (la Q3 du sujet 2024/2025, clé déduite). Les 22
QCM du cours ont une justification par proposition, comme les annales. **31 des
32 QCM sont illustrés** (97 %) ; seul celui des génotypes n'a pas de figure
dans la fiche.

Huit thèmes, ceux du plan C16 (§3.6) ; quatre sont partagés dans l'UE (§0.5) :

| Clé | Libellé |
|---|---|
| `toxoplasma-biologie` | Toxoplasma gondii : formes et génotypes |
| `cycle-parasitaire` | Cycle parasitaire et hôtes (partagé : FC n°1, 4, 6) |
| `toxo-immunocompetent` | Toxoplasmose de l'immunocompétent |
| `immunodeprime` | Infections opportunistes de l'immunodéprimé (partagé : FC n°6, 8, 9) |
| `toxo-congenitale` | Toxoplasmose congénitale |
| `suivi-grossesse` | Suivi sérologique de la grossesse |
| `diagnostic-biologique` | Diagnostic biologique (partagé) |
| `traitement-prevention` | Traitement et prévention (partagé) |

Les huit libellés sont à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`), bloc « parasitologie » ;
jusque-là, le test `test_tout_theme_du_paquet_a_son_libelle` échoue pour ce
chapitre, et lui seul. Les clés `diagnostic` (« Le diagnostic de la mort ») et
`diagnostic-prenatal` (génétique) ne sont pas réemployées.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-parasito-toxoplasmose` — Ronéosaure, « FC n°6 Toxoplasmose .pdf » (8 p.), `PARASITO-MYCOLOGIE/…` | **2025-26** | **la base** : chaque note du cours porte sa page ; c'est ce que le lecteur ouvre (`chapitre=`) ; ses figures illustrent les corrections |
| `src-annales-6-toxoplasmose` — Ronéosaure, « 6 - Toxoplasmose » (5 p.), `S1/ANNALES/Examens de Janvier/Parasitologie et Mycologie/…` | 2024-25 | les 19 questions et leur table de corrections (p. 4-5) ; déclarée avec les seuls champs convenus pour l'UE |
| `src-cours-tox-2425` — Ronéosaure, FC n°6 (AC), Pr J. Leroy (16 p.) | 2024-25 | appoint, cité dans le texte des cartes : la toxoplasmose congénitale (p. 10-11), le suivi et la séroconversion (p. 12-14), les traitements (p. 15) |
| Cours 2023-24 (« 6. Parasitologie - Toxoplasmose ») | 2023-24 | lu pour trancher les annales, cité nulle part : rien n'en dépend |
| `src-sujets-parasito-2425` — sujets de parasitologie-mycologie 2024/2025, session 1 (examen du 10/01/2025, 14 p.), sans chemin | 2024-25 | 2024/2025 S1 Q3, par `SRC["sessions"]` ; **aucun corrigé**, clé déduite du cours ; déclaration commune aux dix chapitres de l'UE, champ pour champ |

Sources hors Ronéosaure, citées dans les justifications qu'elles appuient :
Nicolle et Manceaux, C. R. Acad. Sci. 1908, t. 147, p. 763, et le CNR
Toxoplasmose (CHU de Reims), pour l'Institut Pasteur de Tunis ; l'ANSES, sa
fiche « Toxoplasma gondii » (mise à jour de mai 2021 : congélation à −12 °C à
cœur pendant 3 jours au moins, cuisson à 70 °C à cœur) pour la viande, et son
Bulletin épidémiologique (« rétinochoroïdites principalement ») pour les
séquelles oculaires ; la tétrade de Sabin (1942) pour les convulsions.

## Ce que le cours a dicté

- **Le gris** de ce ronéo ne marque que des titres de sous-parties : il se
  carte. Aucune ligne rouge.
- **« Dimensions à ne pas retenir »** (tachyzoïte 6-8 µm, p. 2 ; kyste
  20-200 µm, p. 3) : aucune carte ne les demande. **Les reproductions
  asexuées dans la vacuole, « à ne pas retenir »** (p. 3) : la carte du cycle
  lytique (`tox-qc-cycle-lytique`) s'en tient à ce qu'« il faut retenir » —
  le conoïde, la vacuole parasitophore, les organites, la formation des
  bradyzoïtes.
- **« Le nom des molécules n'est pas à connaître »** (p. 7) : seules la
  spiramycine et l'association sulfamide-pyriméthamine sont nommées, parce que
  les annales les demandent (2023/2024 S2 Q3 E, 2020/2021 S1 Q13 A) ; les
  cartes le disent.
- **« Suivi au cours de la grossesse (!!Tombe souvent à l'examen!!) »** (p. 6) :
  deux propositions `indispensables` — la surveillance jusqu'à 3 semaines après
  l'accouchement (`tox-qc-depistage` D) et la cuisson de la viande
  (`tox-qc-hygiene` A). Le ronéo écrit « cuisson à point » : la proposition dit
  « bien cuire la viande », comme le cours 2024-25 (p. 12), pour qu'on n'y lise
  pas la cuisson rosée du cuisinier ; sa justification cite le ronéo.
- **La datation de l'infection est dite « rang C »** (p. 7, « on utilise des
  rangs C (dans pour notre culture G) ») : sa carte, `tox-qc-datation`, porte
  le tag `edn`.

## Les erreurs du Ronéosaure 2025-26

Aucun errata 2025-26 ne touche cette FC. Erreurs trouvées en relisant, chacune
dite par un ATTENTION sans genre dans la carte qui porte la notion :

| Page | Ce que dit le Ronéosaure | Ce qui est juste, et sa source | Cartes |
|---|---|---|---|
| 2 | découverte « à l'institut Pasteur d'Alger » | l'Institut Pasteur de **Tunis** (diapositive de la même page ; cours 2024-25, p. 2 ; Nicolle et Manceaux 1908 ; CNR Toxoplasmose) | `tox-qc-agent` C, `tox-fa-decouverte` |
| 3 | « micro-gamète mâle rencontre le micro-gamète femelle » | le gamète femelle est le **macrogamète** (« Micro ♂/macro ♀ gamètes » sur le schéma du cycle, p. 4 ; cours 2024-25, p. 5-6) | `tox-qc-cycle` D |
| 4 | « Conservation de la viande > 3 jours avec une T° < à 12-16 °C » rangée parmi les **modes de contamination** | c'est, au signe moins près, la **congélation** qui détruit les kystes : une prévention (ANSES, fiche *Toxoplasma gondii* 2021 : « −12 °C à cœur, pendant 3 jours minimum » ; cours 2024-25, p. 6 ; corrigé des annales « cuisson / congélation ») | `tox-qc-hygiene` D, `tox-fa-contamination` |
| 6 | « Période critique → 2ème trimestre : forme grave et placenta plus perméable » | la gravité est **maximale au 1er trimestre**, moindre au 2e, où se croisent les courbes de transmission et de gravité (diapositive de la même page ; cours 2024-25, p. 10) | `tox-qc-trimestre` C, `tox-rv-transmission-gravite`, `tox-an-1516s1-q15` C |
| 7 | tableau « **À la naissance** : PCR négatif / PCR positif » | c'est la PCR du **liquide amniotique**, anténatale, après amniocentèse dès 18 SA (algorithme de la même page ; cours 2024-25, p. 13 ; corrigé de 2018/2019 S1 QROC 2) | `tox-qc-seroconversion` E, `tox-rv-pcr-amnio` |
| 7 | « On traite par spiramycine au 1er trimestre puis on met en place un traitement normal (sulfamide-pyriméthamine) » | le relais par sulfamide-pyriméthamine ne se fait que si la **PCR du liquide amniotique est positive** (tableau et algorithme de la même page ; cours 2024-25, p. 14-15) | `tox-qc-traitement` D |

Sans ATTENTION, parce qu'aucune réponse n'en dépend : « toponymie viscérale »
pour toxoplasmose viscérale (p. 4) ; « des formes oculaires d'acquisition au
cours de la vie (congénitales) », contradictoire (p. 4) ; « Coccidies dont le
chef de file est Plasmodium falciparum » (p. 2, point douteux, non carté) ;
« relation inversion entre stage gestationnel et gravité » (p. 6) ; « rangs C
(dans pour notre culture G) » (p. 7). Les chiffres du ronéo et du cours
2024-25 diffèrent sur la disparition des IgM (4 à 6 mois, contre 7 mois à
1 an) : les cartes suivent 2025-26 et le disent.

## Ce que les annales ont dicté

| Session | N° | Sujet | Clé imprimée | Retenue | Anomalie |
|---|---|---|---|---|---|
| 2023/2024 S1 | Q3 | immunodéprimé | CDE | CDE | — |
| 2023/2024 S1 | QROC 1 | trois formes évolutives | tachyzoïte, bradyzoïte, sporozoïte (oocyste) | idem | même question en 2022/2023 S1 et 2020/2021 S1 |
| 2023/2024 S2 | Q3 | toxoplasmose congénitale | ADE | ADE | — |
| 2022/2023 S1 | QROC 4 | trois formes évolutives | idem | idem | — |
| 2021/2022 S1 | QROC 4 | trois moyens de prévention | cuisson/congélation, mains, crudités, litière, gants | idem | — |
| 2021/2022 S2 | Q5 | toxoplasmose congénitale | ACDE | ACDE | B : la ligne « période critique » du ronéo 2025-26 pourrait la faire douter (voir plus haut) |
| 2020/2021 S1 | Q13 | femme enceinte séronégative | DE | DE | énoncé imprimé « exacte(s) ?) », gardé tel quel |
| 2020/2021 S1 | QROC 4 | trois formes évolutives | idem | idem | — |
| 2020/2021 S2 | Q26 | signes de toxoplasmose congénitale | « 1) ABCDE » | ABCDE | **numéro** : énoncé Q26, table « 1) » ; C : encéphalo-méningo-myélite, tétrade de Sabin |
| 2020/2021 S2 | QROC 1 | trois mesures de prévention | idem 2021/2022 | idem | — |
| 2019/2020 S1 | Q12 | toxoplasmose | « 2) AD » | AD | **numéro** : énoncé Q12, table « 2) » |
| 2019/2020 S2 | QROC 3 | localisations des bradyzoïtes | neurones, muscles cardiaques et squelettiques, rétine | idem | — |
| 2018/2019 S1 | QROC 1 | organisation de la prévention | sérologie au 1er trimestre, mensuelle jusqu'à 3 semaines après l'accouchement, règles hygiéno-diététiques | idem | — |
| 2018/2019 S1 | QROC 2 | diagnostic anténatal | sérologie IgM/IgG ; PCR du liquide amniotique dès 18 SA | idem | — |
| 2018/2019 S1 | Q11 | toxoplasmose | ABC | ABC | — |
| 2017/2018 S1 | QROC 1 | quatre mesures de prévention | ∅ (« AUCUNE CORRECTION ») | règles de la FC p. 6 | **clé déduite**, `officielle=False` |
| 2017/2018 S2 | Q11 | toxoplasmose | AC | AC | — |
| 2017/2018 S2 | QROC (sans numéro) | manifestations chez l'immunodéprimé | ∅ (absente de la table) | formes encéphalique, rétinienne, pulmonaire, disséminées (FC p. 5, diapositive p. 8) | **numéro manquant, clé déduite**, `officielle=False` |
| 2015/2016 S1 | Q15 | toxoplasmose | ABD | ABD | C : même remarque que 2021/2022 S2 Q5 B |
| 2024/2025 S1 | 3) | toxoplasmose de la femme enceinte | ∅ (sujet sans corrigé) | ABD | **clé déduite**, `officielle=False` ; A : même remarque que 2021/2022 S2 Q5 B |

Ce qui revient : le suivi de la grossesse et la prévention de la toxoplasmose
congénitale (2 QCM, 5 QROC) ; les trois formes évolutives (3 QROC) ; la
toxoplasmose congénitale (3 QCM) ; l'agent et ses hôtes (4 QCM, presque mot
pour mot de 2015/2016 à 2019/2020) ; l'immunodéprimé (1 QCM, 1 QROC) ; les
kystes (1 QROC). Les trois sessions qui posent la même question (formes
évolutives) donnent trois cartes, dont l'explication dit « Même question
en… » ; aucune question n'est imprimée deux fois pour une même session.

## Les schémas cliquables

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `cinetique-anticorps-nue.svg` (correction : `cinetique-anticorps.svg`) | l'incubation, l'apparition des IgM, celle des IgG (la séroconversion), le pic de chacune, la disparition des IgM, leur persistance chez 20-30 %, le taux basal des IgG | 8 |
| `frise-grossesse-nue.svg` (correction : `frise-grossesse.svg`) | le trimestre le plus grave, la période critique, le trimestre où la transmission est la plus fréquente, le terme de l'amniocentèse (18 SA), la première et la dernière sérologie | 6 |

La cinétique est redessinée d'après la diapositive de la p. 4 et le texte de la
p. 5 : deux courbes de la même encre, sans graduation nommée, puisque c'est
leur ordre et leur devenir qu'on reconnaît ; les IgA de la diapositive ne sont
pas tracées, on ne les dose pas. La frise met sur un axe en semaines
d'aménorrhée les trimestres (arrondis), la transmission et la gravité de la
diapositive de la p. 6, l'amniocentèse et les sérologies de la p. 6-7. Pas de
planche à légender : les légendes de la diapositive du cycle (p. 4) sont trop
petites pour une planche lisible (le plan la donnait en option).

## Les clés qui ne sont pas reprises telles quelles

**Aucune clé imprimée n'est contredite** : chacune est confirmée par la FC
2025-26, et l'errata des annales 2024-25 de l'UE est vide. `CONFLITS` est
vide. Trois corrigés manquent, et sont déduits du cours (`officielle=False`,
explication « Clé déduite du cours, absente de la table de corrections ») :
2017/2018 S1 QROC 1, 2017/2018 S2 QROC et la Q3 du sujet 2024/2025.

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2024/2025 S1 3) (toxoplasmose de la femme enceinte) | aucune (sujet sans corrigé) | **ABD** | clé déduite de la FC 2025-26 : forme grave surtout au 1er trimestre (p. 6 ; la ligne « période critique → 2ème trimestre » du Ronéosaure est signalée par un ATTENTION dans A, sans conflit, comme pour 2015/2016 S1 Q15 C), viande pas assez cuite (p. 6), dépistage sérologique et règles hygiéno-diététiques de la femme non immunisée (p. 6), PCR sur liquide amniotique (p. 7) | Deux numéros diffèrent entre
l'énoncé et la table (2020/2021 S2 Q26, 2019/2020 S1 Q12) : la clé est bien la
leur, l'explication le dit.

## Le lexique

Dix termes, ceux du plan C16 ; pages mesurées dans le texte de la FC 2025-26
(script du skill `chercher_pages`, en-têtes retirés) :

| Terme | Identifiant | Origine | Pages |
|---|---|---|---|
| Tachyzoïte | `lex-tachyzoite` | grec ταχύς + ζῷον | 2, 3, 4, 5, 7, 8 |
| Bradyzoïte | `lex-bradyzoite` | grec βραδύς + ζῷον | 2, 3, 4, 5, 6 |
| Sporozoïte | `lex-sporozoite` | grec σπορά + ζῷον | 3, 4 |
| Oocyste | `lex-oocyste` | grec ᾠόν + κύστις | 2, 3, 4 |
| Séroconversion | `lex-seroconversion` | latin serum + conversio | 1, 7 |
| Choriorétinite | `lex-chorioretinite` | grec χόριον + latin retina + -ῖτις | 6 |
| Amniocentèse | `lex-amniocentese-parasito` | grec ἀμνίον + κέντησις | 7, 8 |
| Hydrocéphalie | `lex-hydrocephalie` | grec ὑδροκέφαλον | 6 |
| Félidé | `lex-felide` | latin felis | 2, 3, 4 |
| Vacuole parasitophore | `lex-vacuole-parasitophore` | latin vacuus + grec παράσιτος + φορός | 3 |

**Amniocentèse existe déjà dans une autre UE** : `lex-amniocentese`
(`genet_tests`, génétique). L'identifiant d'une note est global : le reprendre
aurait déplacé la note de génétique dans ce chapitre à l'import. Le terme prend
donc le suffixe `-parasito`, pour figurer aussi au lexique de la parasitologie,
où trois annales l'emploient (précédent : `lex-phagocytose-bmcp`) — question
pour Vincent, plus bas.

L'origine de chaque terme et de chaque racine est écrite dans les définitions,
au format exact d'`appliquer_etymologies.py` (vérifié en simulant le script sur
la table augmentée). Les huit racines nouvelles et les dix termes sont proposés
dans le brouillon `scratchpad/etym/parasito_toxoplasmose.json` (TLFi par l'API
du CNRTL, Wiktionnaire, Bailly, Gaffiot), à fusionner dans
`scripts/etymologies.json`. Quatre racines y reprennent **mot pour mot** les
entrées des chapitres voisins : `-zoïte` et `-phore`
(`parasito_digestives_autochtones`), `spor(o)- / -spore`
(`parasito_agents_fongiques`), `parasit(o)-` (`parasito_paludisme`, dont le
texte est aussi repris dans le sens de la racine). Les racines déjà dans la table gardent leur clé :
`tachy-`, `brady-`, `cyst-`, `serum (latin)`, `conversio (latin)`,
`retina (latin médiéval)`, `-ite`, `amni(o)-`, `-centèse`, `hydr(o)-`,
`céphal(o)-`. Aucune n'est enseignée par la FC de sémantique : aucune ne cite
de page.

## Questions pour Vincent

1. **Amniocentèse au lexique de la parasitologie.** Le terme est déjà celui de
   la génétique (`lex-amniocentese`, `genet_tests`) ; il est repris ici sous
   `lex-amniocentese-parasito`, pour que le lexique de la parasitologie l'ait
   (trois annales l'emploient). Garder ce doublon d'une UE à l'autre, ou le
   retirer d'ici ? (Proposition appliquée : le garder, comme
   `lex-phagocytose-bmcp`.)
2. **L'examen du 5 janvier 2027** (plan C16, question 5) : faut-il le déclarer
   (`EXAMENS`) dans les chapitres des quatre UE de janvier, ou le laisser au
   réglage de l'application, comme jusqu'ici ? (Proposition appliquée : ne pas
   le déclarer.)

## À relire

**Aucune carte `a-relire`** : toutes les notes du cours citent une page de la
FC 2025-26, toutes les annales leur session, leur numéro et leur clé (déduite à
la page pour celle de 2024/2025).


## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier. Sous les annales, 39 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 7 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `toxoplasma-biologie` | 4 | 1 | 4 |
| `cycle-parasitaire` | 4 | 1 | 3 |
| `immunodeprime` | 8 | 1 | 2 |
| `toxo-congenitale` | 11 | 1 | 4 |
| `suivi-grossesse` | 7 | 1 | 3 |
| `diagnostic-biologique` | 1 | 1 | 1 |
| `traitement-prevention` | 4 | 1 | 3 |

**Le schéma** `ech-toxoplasmose`, « La toxoplasmose · le parasite, l'homme, la grossesse », donne 57 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_TOXOPLASMOSE`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- tox-an-1516s1-q15 B : « Toxoplasma gondii est le pathogène de la toxoplasmose » — le nom même de la maladie ; il titre la case de l'agent, aucune case vide ne le demande.

## Régénérer

```powershell
cd contenu\chapitres\parasito_toxoplasmose
..\..\..\app\.venv\Scripts\python.exe generer.py
```
