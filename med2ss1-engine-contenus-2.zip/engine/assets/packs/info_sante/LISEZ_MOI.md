# Informatique en santé — paquet Informatique médicale

128 notes, 225 cartes. Chapitre `chap-ue-info-medicale-fc1` de l'UE Informatique
médicale, premier de l'UE. Cours du **Dr Erwin Gérard, le 06/10/2026, de 8 h à
10 h** (semaine 5 ; l'en-tête courant des ronéos écrit « Pr. Gerard »). Examen :
partiel du mercredi 16 décembre 2026, sur tablette (30 minutes).

**La base est le cours 2026-27** (réalignement du 19/10/2026) : les deux ronéos
Ronéo & Juliette du 06/10/2026, déposés le 19/10.

- **Partie 1**, « Informatique en santé » (8 p., 8 h-9 h ; `SRC["fiche"]`) :
  l'introduction et le référentiel (p. 2) ; les données médicales — donnée,
  information, connaissance ; la définition juridique de la donnée de santé ;
  six catégories (p. 3) ; le cycle de vie, la qualité, le structuré et le texte
  libre (p. 4-5) ; identifier sans ambiguïté — identitovigilance, INS (p. 5),
  professionnels et structures (p. 6) ; l'urbanisation — définition, objectifs,
  enjeux (p. 6-7), la « maison » du numérique, l'échange et le partage, les
  trois processus du SIH (p. 7). Pas de figure : des tableaux en texte.
- **Partie 2**, « L'informatique en santé » (12 p., 9 h-10 h ; `fiche=FC2`) :
  l'urbanisation redite (p. 2-3) ; l'interopérabilité — trois niveaux, CI-SIS,
  référentiels, la biologie médicale (p. 3-5) ; le cadre juridique, éthique et
  sécurité — finalité, proportionnalité, sécurité ; RGPD ; secret et partage ;
  HDS ; PGSSI-S et cyberattaques (p. 6-9) ; partage, stockage, réutilisation —
  Mon espace santé et DMP, entrepôts, SNDS et HDH, anonymisation et
  pseudonymisation (p. 9-11) ; cinq exemples cliniques — MSSanté, prescription
  numérique, aide à la décision, objets connectés, IA (p. 11-12). Sept tableaux
  y sont des images, reprises des diapositives : ils font foi sur le texte.

Le **Ronéosaure 2025-26** (FC n°1, cours du Pr Gérard du 24/10/2025, 10 h-12 h,
13 p.), qui faisait la base depuis le 02/10, reste l'appoint, la source des
quatre annales qu'il reproduit (p. 13) et celle des cartes absentes du cours
2026-27. **Le cours de l'année est complet** : les deux heures ont été données le
06/10, comme les deux heures de 2025-26, et la partie 2 finit sur sa conclusion.
Rien n'est donc « en attente » dans ce chapitre.

Le second ronéo n'appartient pas à `info_stockage` (FC n°2, Pr Chazard) : il
parle de « stockage » au sens du partage des données de santé, et du cloud
comme cadre juridique de l'hébergement. Les deux ronéos sont à ce chapitre-ci.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 50 | 50 |
| QRU | 22 | 22 |
| Texte à trous | 24 | 121 |
| QROC | 14 | 14 |
| Recto-verso | 10 | 10 |
| Planche à légender | 1 | 1 |
| Lexique | 7 | 7 |
| **Total** | **128** | **225** |

Dont **4 annales** sur une session (2024/2025, questions 3 à 6) et **25 marches
d'échelle** (21 Simple, 4 Moyen). **67 QCM sur 72 illustrés (93 %)**, 108 notes
sur 128. **10 cartes portent un piège du ronéo 2026-27** (thème « Pièges des
ronéos »). **35 cartes absentes du cours 2026-27.** **Aucune carte `a-relire`.**

Dix thèmes, tous déjà libellés dans `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) : **aucune clé nouvelle**. Les sept
du chapitre, et trois thèmes d'autres chapitres de l'UE pour ce que le cours
2026-27 ajoute, au même libellé.

| Clé | Libellé | Notes |
|---|---|---|
| `urbanisation-si` | Urbanisation du système d'information | 25 |
| `identification-sante` | Identifier patients, professionnels, établissements | 17 |
| `donnees-sante` | Données de santé : types, finalités, définition | 16 |
| `dsbp` | DataSets de bonnes pratiques et aide à la décision | 16 |
| `interoperabilite` | Interopérabilité et terminologies | 14 |
| `hebergement-securite` | Réglementation, hébergement et messagerie sécurisée | 11 |
| `dmp-rosp` | Dossier médical partagé et ROSP | 11 |
| `protection-donnees` | Protection des données personnelles (de `info_cryptographie`) | 6 |
| `bases-donnees-sante` | Bases de données de santé : SNDS, PMSI, entrepôts (de `info_reutilisation`) | 3 |
| `ia-sante` | IA en santé : niveaux, systèmes experts, usages (de `info_machine_learning`) | 2 |

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-info-sante-2627-1` — Ronéo & Juliette, « INFORMATIQUE EN SANTÉ 1 » (8 p.), chemin `INFORMATIQUE MÉDICALE/INFORMATIQUE EN SANTÉ 1.pdf` | **2026-27** | **la base** et la fiche (`SRC["fiche"]`, `chapitre=`) : 41 notes de cours la citent |
| `src-fc-info-sante-2627-2` — Ronéo & Juliette, « INFORMATIQUE EN SANTÉ 2 » (12 p.), chemin `INFORMATIQUE MÉDICALE/INFORMATIQUE EN SANTÉ 2.pdf` | **2026-27** | la seconde fiche (`chapitre=`) : 41 notes de cours la citent (`fiche=FC2`) |
| `src-fc-info-sante-2526` — Ronéosaure, « FC n°1 Informatique en santé » (13 p.) | 2025-26 | l'ancienne base, plus de `chapitre=` : `SRC["cours"]` et `SRC["annales"]` (p. 13), la fiche des 35 cartes absentes (`fiche=FC2526`), quatre figures |

Les noms de fichier sont ceux du disque, en NFC. Dans le texte d'une carte
relue, « partie 1, p. N » et « partie 2, p. N » renvoient aux ronéos 2026-27,
« FC 2025-26, p. N » au Ronéosaure. Dans une carte absente, « p. N » renvoie
toujours à la FC 2025-26. Les trois annales Q3, Q4 et Q6 portent la page du
ronéo 2026-27 où se lit leur réponse : l'application la cite en source
secondaire.

Les en-têtes des ronéos portent des noms d'étudiants : aucun n'est repris.

## Ce que le cours 2026-27 a changé

Le cours est **réécrit**, avec le même professeur et le même volume : des
tableaux à la place des listes, et une architecture annoncée (« donnée →
identité → urbanisation → interopérabilité → règlement → réutilisation →
impacts cliniques », partie 1, p. 2).

**42 notes du Ronéosaure relues et confirmées** : elles portent la page du ronéo
2026-27 et perdent le badge « Cours 2025-26 ». Les propositions qu'il ne reprend
pas disent, dans leur justification, qu'elles viennent du cours 2025-26.

| Partie, page | Notes relues |
|---|---|
| 1, p. 2-3 | `isn-fa-referentiel`, `isn-fa-rgpd-definition`, `isn-qc-donnees-types` |
| 1, p. 5 | `isn-fa-ins`, `isn-qc-ins`, `isn-qr-identitovigilance`, `isn-qr-nia`, `isn-ech-s7`, `isn-ech-s8` |
| 1, p. 6 | `isn-fa-urbanisation`, `isn-qc-urbanisation`, `isn-qr-urbanisation`, `isn-qc-professionnels`, `isn-qr-mssante`, `isn-rv-rpps-finess`, `isn-ech-s1`, `isn-ech-s2`, `isn-ech-m1`, `isn-ech-s9`, `isn-ech-s10`, `isn-ech-m2` |
| 1, p. 7 | `isn-fa-sih`, `isn-qc-sih-processus`, `isn-ech-s6` |
| 2, p. 2-5 | `isn-ech-s5`, `isn-fa-standards`, `isn-fa-biologie`, `isn-qc-standards`, `isn-qc-biologie`, `isn-qr-ans`, `isn-rv-cim-ccam` |
| 2, p. 7-9 | `isn-qc-rgpd`, `isn-qc-hds`, `isn-ech-s11`, `isn-ech-s19`, `isn-qc-dmp`, `isn-rv-dmp`, `isn-ech-s18`, `isn-ech-s20`, `isn-ech-s21`, `isn-ech-m4` |
| 2, p. 11 | `isn-qc-messagerie` |

Ce qui a changé dans leur contenu (clés, identifiants, types et numéros des
trous inchangés ; contrôlé contre le paquet d'avant) :

- **Les trois processus du SIH** (partie 1, p. 7) : le soin (admission,
  observation, prescription, administration, biologie, imagerie, compte rendu,
  sortie), le **support** (ressources humaines, pharmacie, stocks, restauration,
  brancardage, facturation), le **pilotage** (qualité, PMSI, indicateurs, gestion
  de lits, vigilance, recherche). Le recrutement, au pilotage en 2025-26, passe
  au support ; la recherche passe au pilotage. `isn-fa-sih` est réécrit sur le
  tableau 2026-27, l'énoncé de `isn-qc-sih-processus` prend ses exemples
  (pharmacie, stocks, brancardage), et les justifications de `isn-ech-s6` le
  disent.
- **La définition de l'urbanisation** : des « briques cohérentes, autonomes,
  évolutives et interopérables, alignées sur les besoins du métier » (partie 1,
  p. 6). La question de `isn-qr-urbanisation` la prend ; « discipline
  d'ingénierie » reste, dite du cours 2025-26. L'annale 2024/2025 Q3 D (« briques
  applicatives autonomes et interopérables ») se lit désormais mot pour mot dans
  le cours.
- **L'identitovigilance** a une définition (« règles, processus et contrôles »)
  et deux familles de risques (partie 1, p. 5) : la question de
  `isn-qr-identitovigilance` la prend.
- **Le DMP** est « alimenté par nous ou encore par les médecins » (partie 2,
  p. 9) : le cours 2026-27 corrige lui-même le raccourci de 2025-26 (« c'est le
  patient qui alimente son DMP »), que `isn-qc-dmp` D et `isn-rv-dmp` signalaient.
- **Le Health Data Hub** est géré sur Azure, chez Microsoft (partie 2, p. 7) : le
  « possédé par une société étrangère » de 2025-26 est corrigé par le cours.
- Les figures 2026-27 remplacent en correction celles de 2025-26 partout où elles
  montrent ce que la carte demande ; les figures 2025-26 restent sur les cartes
  absentes et là où elles disent toujours vrai (identifiants, standards, DMP).

**41 notes nouvelles**, pour ce que le cours 2026-27 enseigne et qu'aucune carte
ne couvrait :

| Partie, page | Notes |
|---|---|
| 1, p. 3 | `isn-qc-donnee-information`, `isn-qc-donnee-de-sante`, `isn-fa-categories-2627`, `isn-qc-categories` |
| 1, p. 4-5 | `isn-fa-cycle-vie`, `isn-fa-qualite`, `isn-qc-qualite`, `isn-qc-structure-texte`, `isn-qc-identitovigilance`, `isn-rv-ins-nir` |
| 1, p. 6-7 | `isn-qc-acteurs`, `isn-fa-urbanisation-definition`, `isn-fa-objectifs-2627`, `isn-qc-enjeux`, `isn-fa-maison`, `isn-qc-maison`, `isn-qc-echange-partage` |
| 2, p. 4-5 | `isn-fa-niveaux-interop`, `isn-qc-interoperabilite`, `isn-qc-ci-sis`, `isn-qr-ci-sis`, `isn-fa-referentiels-usages`, `isn-fa-dfg` |
| 2, p. 6-7 | `isn-fa-finalite`, `isn-qc-principes`, `isn-qc-notions-rgpd`, `isn-qc-secret-partage` |
| 2, p. 7-9 | `isn-qc-hds-cloud`, `isn-qc-pgssi-s`, `isn-qc-cyberattaques`, `isn-rv-reflexes-cyber` |
| 2, p. 9-11 | `isn-qc-eds`, `isn-qr-eds`, `isn-qc-snds-hdh`, `isn-qc-anonymisation`, `isn-qr-pseudonymisation`, `lex-pseudonymisation` |
| 2, p. 11-12 | `isn-qc-outils-cliniques`, `isn-rv-objets-connectes`, `isn-qc-ia`, `isn-fa-ia-evaluation` |

**Frontières avec les autres chapitres de l'UE.** Le cours 2026-27 de Gérard
traite en quelques lignes des notions que d'autres chapitres tiennent en
détail : les trois niveaux d'interopérabilité et les terminologies
(`info_financement`), l'anonymisation (`info_cryptographie`), le SNDS et les
entrepôts (`info_reutilisation`), l'IA (`info_machine_learning`). Ce chapitre
les carte telles que Gérard les dit — ses tableaux, ses formules —, sans
reprendre leurs détails, et sans terme de lexique en double
(`lex-interoperabilite` et `lex-terminologie` restent à `info_financement`).

## Absent du cours 2026-27

**35 cartes** (`ABSENTS_2026`, origine : « cours du Pr Gérard de 2025-26
(Ronéosaure 2025-26, FC n°1), que les deux ronéos du 06/10/2026 ne reprennent
pas »). Le cours de l'année a couvert chacun de ces sujets et ne tient plus ces
points ; chaque carte garde sa page de la FC 2025-26 (`fiche=FC2526`), le badge
« Cours 2025-26 » et la phrase « Absent du cours 2026-27 » en tête de
l'explication.

| Sujet | Notes |
|---|---|
| les DSBP et le DSBP-BPCO — le cours 2026-27 ne parle que d'un « système d'aide à la décision » qui alerte (partie 2, p. 11) | `isn-fa-dsbp-objectifs`, `isn-fa-dsbp-bpco`, `isn-qc-dsbp`, `isn-qc-dsbp-bpco`, `isn-qr-frugalite`, `isn-qr-premier-dsbp`, et les marches `isn-ech-s12` à `isn-ech-s17`, `isn-ech-m3` |
| la ROSP et l'informatisation des cabinets (remplacée en réalité depuis le 1er janvier 2026) | `isn-qc-rosp`, `isn-qr-rosp`, `isn-fa-aspects` |
| les cinq objectifs de 2025-26 et l'efficience — le cours 2026-27 en donne quatre autres (`isn-fa-objectifs-2627`) | `isn-fa-objectifs`, `isn-qc-objectifs`, `isn-qr-efficience`, les marches `isn-ech-s3`, `isn-ech-s4` |
| le contexte chiffré, la santé numérique et ses familles de services, le sang contaminé | `isn-qc-contexte`, `isn-qc-sante-numerique`, `isn-qr-tracabilite` |
| les finalités, les cinq catégories, le stockage (CPS, carte Vitale, HAS, omique, données synthétiques), la mise à jour | `isn-qc-finalites`, `isn-fa-categories`, `isn-qc-stockage`, `isn-qr-synthetiques`, `isn-rv-mise-a-jour` |
| données de référence et produits de certification | `isn-rv-reference-certification` |
| la chaîne de production de l'information (et sa planche) | `isn-qc-production`, `isn-pl-production` |
| les textes et leurs dates (RGPD, L.1111-8, décret 2018-137), la rançon | `isn-fa-hds`, `isn-rv-rgpd-dates`, `isn-rv-cyberattaque` |

Trois termes du lexique n'ont plus de page 2026-27 (omique, frugalité,
télétransmission) : ils restent, avec leurs pages de la FC 2025-26 (un terme du
lexique ne se range pas dans `ABSENTS_2026`).

## En attente des CM suivants

**Aucune carte** : le cours « Informatique en santé » de l'année a eu lieu en
entier le 06/10/2026. Les autres CM de l'UE (Pr Chazard, Pr Ficheur, Pr Renard,
Pr Guédon) ont leurs chapitres.

## Les erreurs des ronéos 2026-27

L'UE n'a pas de tableau d'erreurs de la promo au 19/10. Erreurs trouvées en
relisant, portées dans les cartes avec leur genre (`.claude/rules/cartes.md`), à
verser dans `contenu/ERRATA_RONEOS_2026-27.md` ; chaque preuve est citée dans la
carte.

| Ronéo, page | Ce que dit le ronéo | Ce qui est juste, et la preuve | Genre | Carte |
|---|---|---|---|---|
| 1, p. 5 | l'INS « associe un matricule INS + NIR ou NIA (= N° de sécurité sociale) » | le matricule INS EST le NIR ou, à défaut, le NIA ; le NIA est un numéro d'attente, pas le numéro de sécurité sociale — FC 2025-26 p. 7 (même professeur) ; ANS, guide d'implémentation de l'INS | prise de notes | `isn-qc-ins` (B) |
| 2, p. 2 | « L'empilement de logiciels isolés » en tête des objectifs | « Éviter l'empilement de logiciels isolés » — partie 1, p. 6 | prise de notes | `isn-fa-objectifs-2627` |
| 2, p. 3 | l'échange, « entre un émetteur et plusieurs destinataires » | « vers 1 ou plusieurs destinataires » — tableau de la partie 1, p. 7 | prise de notes | `isn-qc-echange-partage` (A) |
| 2, p. 8 | la PGSSI-S, dont « le but est de lutter contre l'usurpation d'identité » | cinq risques au tableau de la même page (usurpation, accès illégitime, perte, fuite, indisponibilité) ; un cadre pour « gérer les risques » — ANS, « PGSSI-S » | prise de notes | `isn-qc-pgssi-s` (B) |
| 2, p. 10 | le SNDS « permet le remboursement des soins exercés à l'hôpital » | il contient des données de remboursement (tableau de la même page) ; c'est une base pour la recherche et l'évaluation — DREES ; CSP art. L.1461-1 | prise de notes | `isn-qc-snds-hdh` (B) |
| 2, p. 12 | « les valeurs marquantes : il peut manquer des informations » | les valeurs manquantes — sa propre explication | prise de notes | `isn-qc-ia` (E) |
| 1, p. 6 | « Organiser l'information progressive du système de santé » | « l'informatisation progressive » (cours 2024-25 p. 6 et 2023-24 p. 5) ; la même coquille est dans le Ronéosaure 2025-26 | douteux | `isn-fa-urbanisation-definition` |
| 1, p. 6 | « Éviter l'empilement de logiciels isolés (= centralisation) » | l'urbanisation découpe en briques « autonomes » autour de services socles communs (même page, p. 7) : ce n'est pas une centralisation | douteux | `isn-fa-objectifs-2627` |
| 2, p. 3 | le pilotage, « la gestion d'un patient infectieux » | le pilotage, c'est la qualité, le PMSI, les indicateurs, la gestion de lits, la vigilance, la recherche (tableau de la partie 1, p. 7) ; la prise en charge d'un patient relève du soin, l'exemple ne tient que comme vigilance (alerte, isolement, épidémie) | douteux | `isn-fa-sih` |
| 2, p. 7 | le Health Data Hub « garde toutes les données des patients pris en charge en France » | une plateforme qui facilite l'accès sécurisé aux données pour des projets d'intérêt public (tableau p. 10) : guichet des demandes d'accès au SNDS, elle enrichit sa base principale avec les bases de son catalogue — des remboursements, des séjours, des décès, pas le dossier de chaque patient — DREES | douteux | `isn-qc-hds-cloud` (D) |
| 2, p. 8 | les données d'une entreprise américaine stockées hors des États-Unis « appartiennent de ce fait aux États-Unis » | elles n'appartiennent pas aux États-Unis ; le CLOUD Act (2018, 18 U.S.C. § 2713) oblige les fournisseurs américains à les livrer sur réquisition, où qu'elles soient | douteux | `isn-qc-hds-cloud` (E) |
| 2, p. 8 | « Retour au papier pour avoir une meilleure prise en charge » | la liste qui suit dit le contraire : erreurs de retranscription, ralentissement, perte de traçabilité | douteux | `isn-qc-cyberattaques` (B) |

**Coquilles dites sans ATTENTION** : « formations / terminologies
incompatibles » (formats, 2, p. 4), « Agence Numérique en Santé » (Agence du
numérique en santé, 2, p. 5), « Azur » (Azure, 2, p. 7), « qui/quoi à produire »
(a produit, 1, p. 4), « SNOMED, CT » (SNOMED CT, tableau de 2, p. 4), « bénévole
ou pas ? » (2, p. 4, incompréhensible, non carté), « Facebook par l'État »
(2, p. 7, non carté), « l'ensemble des données juridiques des français » (données de
santé, 2, p. 7), « MES … étudie la santé de tout usager » (2, p. 9).

**Vus et laissés sans ATTENTION** : la parenthèse « (âge, lieu de
résidence, lieu de naissance…) » (1, p. 3), qui suit « données personnelles » et en
donne des exemples — `isn-qc-donnee-de-sante` B le fait lire (retirée de la liste
des erreurs par la revue du 19/10) ; la MSSanté « entre un patient et un
médecin » (2, p. 11) — juste depuis la messagerie de Mon espace santé, où le
professionnel écrit au patient ; « Le DMP doit être alimenté par nous ou encore
par les médecins » (2, p. 9) — juste, et il corrige le Ronéosaure.

**Revue sceptique du 19/10** : chaque carte nouvelle ou changée relue sur sa page
et son PNG ; la parenthèse de la p. 3 sort de la liste des erreurs ; le Health Data
Hub ne « met » pas encore « à disposition une copie de la base principale du SNDS » :
la Plateforme ne la gérera elle-même qu'après sa migration chez Scaleway (communiqué
du 23/04/2026) : `isn-qc-hds-cloud` D ne le dit plus, et cite ce communiqué pour
le choix de Scaleway.

## Les erreurs du Ronéosaure 2025-26

Le Ronéosaure n'est pas le ronéo de l'année : ses erreurs restent dites par un
**ATTENTION nu**, sans genre, et n'entrent pas dans
`contenu/ERRATA_RONEOS_2026-27.md`. Le cours 2026-27 en corrige deux (le DMP
alimenté par les médecins, le HDH sur Azure).

| Page | Le ronéo disait | Retenu | Carte |
|---|---|---|---|
| 4 | la carte Vitale « contient … le dossier médical partagé » | la diapositive la range parmi les données administratives | `isn-qc-stockage` B, `isn-ech-s21` A |
| 7 | « un numéro de sécu avant d'avoir un prénom » | le NIR est attribué d'après l'acte de naissance | `isn-qc-ins` (explication) |
| 8 | CIM-10 « avec des codes SIM » ; CCAM « classification des actes médicaux » | codes CIM ; Classification commune des actes médicaux | `isn-qc-standards` B et C, `isn-rv-cim-ccam` |
| 9 | le RGPD « depuis le 27 avril 2016 » | adopté ce jour-là, appliqué le 25 mai 2018 | `isn-qc-rgpd` C, `isn-rv-rgpd-dates` |
| 10 | la certification HDS « plutôt à l'échelle européenne » | une certification française | `isn-qc-hds` (explication) |
| 10 | le Health Data Hub « possédé par une société étrangère » | un GIP français, hébergé chez Microsoft | `isn-qc-hds` E |
| 11 | « c'est le patient qui alimente son DMP » | les professionnels et l'Assurance maladie aussi (et le cours 2026-27) | `isn-qc-dmp` D, `isn-rv-dmp` |
| 11 | ROSP, « rémunération sur Objet de santé publique » | sur objectifs | `isn-qr-rosp` |

## Ce que les annales ont dicté

| Savoir | Question | Dans le cours 2026-27 |
|---|---|---|
| Les objectifs de l'urbanisation : collaboration, alignement métier, efficience, anticipation, briques | 2024/2025 Q3 | B, D, E oui (partie 1, p. 6-7) ; A et C par les objectifs de 2025-26 |
| INS, RPPS, identitovigilance, FINESS, hébergeur certifié | 2024/2025 Q4 | tout (partie 1, p. 5-6 ; partie 2, p. 7-8) |
| Les DSBP | 2024/2025 Q5 | **non** : les DSBP ont quitté le cours |
| Le DMP : partage, coordination, accès, tout le monde | 2024/2025 Q6 | tout, sauf le « logiciel compatible » (D) |

La clé est le « Vrai » ou « Faux » que le Ronéosaure imprime après chaque
proposition — pas de table de corrections. **Aucune clé ne change** : relues
contre les deux ronéos 2026-27, aucune n'est contredite par le cours de
l'année. Les annales restent verbatim, hors `ABSENTS_2026`, même Q5.

## Les clés qui ne sont pas reprises telles quelles

**Aucune.** Un point reste discuté dans la carte (`ATTENTION`, déclaré dans
`CONFLITS`), sans changer la clé :

| Question | Clé | Le point | À l'examen |
|---|---|---|---|
| 2024/2025 Q6 D | ABD | « les professionnels doivent disposer d'un logiciel compatible DMP pour y accéder », vrai pour la ronéo ; ni le cours 2025-26 ni le cours 2026-27 n'en parlent (2026-27 exige des logiciels conformes et homologués, partie 1, p. 6) ; l'Assurance maladie décrit aussi l'accès par dmp.fr avec la CPS ou l'e-CPS | vrai, comme la clé |

## L'échelle : Simple → Moyen → Annale (C20, 18/10)

21 cartes Simple (`niveau-simple`) et 4 Moyen (`niveau-moyen`) sous les quatre
annales. **Relues sur le cours 2026-27 le 19/10** : 16 marches le citent
désormais (`isn-ech-s1`, `s2`, `s5` à `s11`, `s18` à `s21`, `m1`, `m2`, `m4`),
leurs justifications réécrites sur ses pages, la proposition de 2025-26 dite
comme telle là où elle reste (la date de l'INS, « à vie » du RPPS, l'efficience
et la collaboration de `m1`) ; 9 sont absentes du cours 2026-27 (`s3`, `s4`,
`s12` à `s17`, `m3` : objectifs de 2025-26 et DSBP). Aucune clé, aucun énoncé,
aucune proposition ne change ; les clés Simple restent réparties entre A, B et
C, et les Moyen ont une à trois vraies.

Le cours 2026-27 ne contredit aucun fait du schéma `ech-informatique-sante` :
le SIH garde ses trois processus, l'INS son NIR ou NIA, le DMP son accès décidé
par le patient. Seule sa légende change : elle cite le ronéo 2026-27 (partie 1,
p. 5-7 ; partie 2, p. 7-9) et la FC 2025-26 pour les cases des objectifs et des
DSBP.

**Sans marche** : 2024/2025 Q6 D (logiciel compatible DMP), point douteux, que
ni l'un ni l'autre cours ne traite.

## Les schémas et les figures

**Dix-huit figures du ronéo 2026-27** (`isn-2627-*.png`, en correction, jamais
en question) : douze tableaux de la partie 1, rendus en PNG à 170 dpi depuis le
PDF (donnée, information, connaissance ; catégories ; cycle de vie ; qualité ;
structuré et texte libre ; identitovigilance ; identification des acteurs ;
définition de l'urbanisation ; enjeux ; « maison » du numérique ; échange et
partage ; processus du SIH) et six des sept tableaux-images de la partie 2, extraits
tels quels (niveaux d'interopérabilité, référentiels, notions du RGPD, PGSSI-S,
SNDS-HDH-entrepôts, anonymisation ; le tableau des enjeux de la p. 2 double
celui de la partie 1 et n'est pas repris). En-têtes et noms exclus du cadrage.

**Quatre figures de la FC 2025-26** et **six figures redessinées**
(`schemas.py`), qui restent sur les cartes absentes et là où elles disent
toujours vrai. `isn-urbanisation.svg` garde les exemples de 2025-26 (le
recrutement au pilotage) : elle n'illustre plus que des cartes absentes.

**La planche** `isn-pl-production` (la chaîne de production de l'information,
FC 2025-26, p. 8) est absente du cours 2026-27.

## Le lexique

Sept termes, avec leur origine grecque ou latine. Les pages du ronéo 2026-27
viennent en premier : c'est elles que cite la provenance du terme.

| Terme | Pages 2026-27 | Pages FC 2025-26 |
|---|---|---|
| Urbanisation | partie 1 : 2, 6, 7 ; partie 2 : 2, 12 | 4, 5, 6, 13 |
| Identitovigilance | partie 1 : 5 | 7 |
| Cybersécurité | partie 1 : 2 ; partie 2 : 9 | 2, 13 |
| **Pseudonymisation** (nouveau) | partie 2 : 10, 11 | — |
| Omique | — | 4 |
| Frugalité | — | 9 |
| Télétransmission | — | 12 |

Les définitions d'urbanisation, d'identitovigilance et de cybersécurité
prennent les mots du cours 2026-27. **Pseudonymisation** est un terme nouveau
(vérifié : aucun `lex-pseudonymisation` dans les autres chapitres) ; sa
racine `-onyme` (grec ὄνομα) est nouvelle, `pseud(o)-` existe. Ils sont proposés
pour `etymologies.json` dans `scratchpad/etym/info_sante.json` (Wiktionnaire,
Bailly), et déjà écrits dans la forme que `appliquer_etymologies.py` produit
(contrôlé : la table fusionnée ne change rien). **Anonymisation** n'est pas
pris : son chapitre d'accueil serait `info_cryptographie`, qui l'enseigne en
détail.

## Sans illustration

Sans objet : 67 QCM sur 72 sont illustrés. Sans figure : `isn-qc-rosp` (aucune
figure ne montre la ROSP), `isn-qc-principes`, `isn-qc-secret-partage`,
`isn-qc-outils-cliniques` et `isn-qc-ia` (la partie 2 n'a pas de tableau pour ces
pages).

## Questions pour Vincent

1. **Les DSBP ont quitté le cours** : l'annale 2024/2025 Q5 reste, avec sa clé,
   hors `ABSENTS_2026` (une annale est une vraie question d'examen). Tu veux
   qu'elle passe aussi en « Absent du cours 2026-27 » ?
2. **2024/2025 Q6 D** (le logiciel compatible DMP) : toujours la clé de la
   ronéo, vraie, avec un ATTENTION point douteux. D'accord ?
3. **Le sujet 2024/2025 complet** : la ronéo n'en reproduit que les questions 3
   à 6. Les questions 1 et 2, ou le sujet de 2025/2026, s'ajouteraient ici.
4. **L'en-tête** dit « Dr Erwin Gerard » et l'en-tête courant « Pr. Gerard » :
   `semaine` écrit « 06/10/2026 · Pr Gérard », au format des autres chapitres.

## À relire

**Aucune carte `a-relire`** : chaque carte relue cite sa page d'un des deux
ronéos 2026-27, chaque carte absente sa page de la FC 2025-26, et les faits qui
n'y sont pas (dates, CLOUD Act, Health Data Hub, SNDS, INS) ont leur source dans
la carte. Reste à faire :

- `copier_les_cours.py` avec le dossier du dépôt du 19/10, hors du bac à sable,
  pour que les deux fiches 2026-27 s'ouvrent dans l'application ;
- verser les douze erreurs du tableau ci-dessus dans
  `contenu/ERRATA_RONEOS_2026-27.md` ;
- fusionner `scratchpad/etym/info_sante.json` dans `etymologies.json`.

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```
