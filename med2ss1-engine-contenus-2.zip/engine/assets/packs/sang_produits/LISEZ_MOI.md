# Les produits sanguins labiles — paquet d'exemple

39 notes, 62 cartes. Dixième chapitre de l'UE **Tissu sanguin**, Pr Mendel,
semaine 7. Le cours des produits eux-mêmes : d'où ils viennent, comment on les
garde, à qui on les donne.

## Un don, trois couches, trois produits

`circuit-don.svg`, redessiné nu — onze boîtes. La centrifugation sépare par
densité, et chaque couche donne son produit :

| Couche | Produit | Conservation |
|---|---|---|
| plasma (haut) | **PFC** | congelé, 3 ans (quarantaine) ou 1 an (Intercept) |
| couche leuco-plaquettaire | **CP** — 8 donneurs | **7 j, 20-24 °C, sous agitation** |
| globules rouges (fond) | **CGR** + SAG-mannitol | **42 j, 2-6 °C** |

Et une règle par-dessus les trois : une fois délivré, la transfusion **commence
dans les 6 heures**, comptées depuis l'horodatage de la fiche de délivrance.

Les plaquettes ne vont **jamais** au froid : leurs granules libéreraient leur
contenu.

## PSL ou MDS : la frontière que le fascicule exploite

| | PSL | MDS |
|---|---|---|
| Vigilance | **hémovigilance** | **pharmacovigilance** |
| Qui | EFS | LFB, industrie |
| Durée | jours | 2 à 5 ans |

Albumine, immunoglobulines — **Rhophylac compris** — et facteurs de coagulation
sont des **MDS**, pas des PSL. Deux questions du fascicule reposent là-dessus.

## Les deux règles de compatibilité sont inverses

- **Cellules** (CGR, plaquettes) : ce sont les *antigènes du produit* qui
  comptent → le **O** donne à tous.
- **Plasma**, règles **en miroir** : ce sont les *anticorps du produit* → l'**AB**
  donne à tous, le **O** reçoit de tous.

Deux QROC de 2017/2018 posent la comparaison telle quelle : au patient A, des
**globules rouges A ou O**, et du **plasma A ou AB**.

## Seuils plaquettaires

Base en onco-hématologie **10 G/L** ; fièvre ou infection **20** ; anticoagulant,
CIVD ou geste invasif **50** ; péridurale **80** ; **neurochirurgie 100**. En
curatif, maintenir au-dessus de **50 G/L** pendant la cicatrisation. Rendement
attendu : **+20 G/L**.

## Clés d'annales non reprises telles quelles

La clé retenue est la bonne, pas la clé imprimée (règle de Vincent, 26/09) :
la question porte alors `cle_officielle` à faux, et la justification de l'item
dit que la correction imprimée n'est pas bonne, et pourquoi.

| Question | Clé imprimée | Retenu | Pourquoi | Source |
|---|---|---|---|---|
| 2021/2022, QCM 2 B (`prd-an-2122-q2`) — « la transfusion de CGR phénotypés RH-Kell est réservée aux femmes en âge de procréer » | AB (B vrai) | **A** (B faux) | le phénotype RH-Kell est aussi obligatoire en cas de RAI positive et chez le nouveau-né de mère immunisée, et recommandé chez les polytransfusés ; le professeur le recommande lui-même chez les drépanocytaires (2022/2023 QCM 5 B) | cours p. 15 ; HAS, novembre 2014, « Transfusion de globules rouges homologues : produits, indications, alternatives », § 3.1 (femmes jusqu'à la fin de la période procréatrice, allo-immunisés, hémoglobinopathies, transfusés itératifs, groupes rares) |

La question est à réponses multiples dans le polycopié ; l'item B faux, il ne
reste qu'une bonne réponse, et la carte la pose en réponse unique.

## Les sujets du dépôt du 15/10/2026

Une annale de plus : le chapitre en compte 11, sur 10 sessions. Le QCM 9 du
sujet 2024/2025 (`prd-an-2425-q9`) cite son sujet (`src-sujets-sang-2425`, par
`SRC["sessions"]`) ; il est illustré par le tableau des prix des PSL (p. 18),
qui tranche son item A.

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2024/2025, QCM 9 (`prd-an-2425-q9`) | aucune (sujet sans corrigé) ; surlignée : E | **AE** | A : le CGR déleucocyté coûte 214,11 euros hors taxes, arrêté du 21/07/2023 (p. 18) ; l'item porte un `ATTENTION —` et une entrée `CONFLITS`. E : échanges plasmatiques des microangiopathies thrombotiques (p. 13) |

**La correction surlignée (officieuse).** Les sujets du dépôt portent des
réponses surlignées en bleu, posées en annotation sur le PDF après coup et
d'origine inconnue : ce n'est ni une grille ni un corrigé de la faculté, et elle
n'est pas déclarée comme source. Sur 2023/2024, elle reproduit la
grille officielle, sauf au QCM 9, où elle ajoute D. Sur 2024/2025, elle sert de
seconde opinion : quand la clé déduite du cours coïncide, l'explication le dit ;
quand elle diffère et que le cours tranche, la carte suit le cours, et l'item
en cause porte un `ATTENTION —` et une entrée `CONFLITS`. Les surlignages des
QROC 2024/2025 ne marquent que l'énoncé et n'apportent rien.

**2023/2024.** Clés confirmées par la grille officielle (dépôt du 15/10/2026) :
le QCM 8 (`prd-an-2324-q8`, BE). À la Q9 de ce sujet, seul le surligneur ajoute D, la
grille dit AE.

## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026)

L'échelle du pilote de l'immunité innée, étendue au tissu sanguin et aux trois derniers chapitres de sémiologie pour l'examen du 4/11 (Vincent, 16/10 : « on continue pour les chapitres que je vais avoir à l'examen »). Sous les annales, 16 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 6 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `psl` | 11 | 3 | 4 |
| `cgr` | 1 | 1 | 2 |
| `plasma` | 0 | 1 | 1 |
| `qualifications` | 4 | 1 | 3 |
| `prescription` | 0 | 0 | 1 |

**Le schéma** `ech-psl`, « Les produits sanguins labiles · garder, donner, qualifier », donne 28 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_PSL`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**La source.** Les marches citent le cours 2024-25 du chapitre, sur lequel ses cartes et les justifications de ses annales sont bâties (décision de Vincent, 16/10 : pas de ronéo 2026-27 parue). La FC 2025-26 du Ronéosaure a servi de contre-épreuve : un fait qui change d'une année à l'autre porte un `ATTENTION`, ou n'a pas de marche.

**Le générateur.** Depuis le 16/10, `generer.py` est la copie exacte du modèle du skill : le bloc « le générateur modèle » en fin de `donnees.py` déclare les sources dans `SRC` et range les QROC d'annales dans `ANNALES_QROC`, officielles comme avant. Le paquet est resté le même, à trois écarts voulus près (indentation, champs par défaut des cartes à zones, légende du média du schéma cliquable).

**ATTENTION posés** : la clé imprimée de 2021/2022 QCM 2 sur le phénotypé RH-Kell (s12, s13, m6) ; l'équivalence CPA et MCP, que la FC 2025-26 ne redit pas (s6, m2) ; le prix des PSL, que la correction surlignée de 2024/2025 ne coche pas (s15). L'annale de la NFS (2022/2023 QCM 9) n'a ni marche ni lettre : la NFS n'est pas dans ce cours.

**Sans marche** :
- prd-an-1819s2-q10 A — l'hémolyse ABO dès la première transfusion tient au caractère naturel des anti-A et anti-B, que ce cours n'enseigne pas (cours des groupes sanguins, p. 4 : marche grp-ech-s2) ; la lettre est posée sur la case des règles ABO des CGR, sans marche ici.
- prd-an-2223-q9 A-E — la NFS (hémogramme) n'est ni dans le cours des produits 2024-25 ni dans sa FC 2025-26 : aucune page à citer, donc ni marche ni lettre ; le thème « prescription », qui n'a que cette annale, reste sans Moyen.

## Régénérer

```
python generer.py
```
