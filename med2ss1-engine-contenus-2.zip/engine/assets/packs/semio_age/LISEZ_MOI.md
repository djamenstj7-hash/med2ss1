# Spécificités sémiologiques du sujet âgé — paquet d'exemple

101 notes, 174 cartes. Cours du **14/09/2026, Dr Aurélie Mailliez** (semaine 1,
10 h-12 h). Cinq sources :

- **le ronéo 2026-27** (Ronéo & Juliette, 17 pages, `src-fc-semio-age`), qui
  fait foi depuis le 25/09/2026 ;
- la fiche de Vincent sur l'ancien cours du **Pr Boulanger** (18 pages,
  `src-cours-age`), sur laquelle le chapitre avait été bâti ;
- le Charonéo 2023-24 du Pr Boulanger (32 pages, `src-roneo-age`), qui lui avait
  ajouté la biologie du vieillissement ;
- le polycopié d'annales du Ronéosaure 2024-25 (dix sessions, 25 questions) et
  le sujet 2025/2026 (deux questions).

| Type | Notes | Cartes |
|---|---|---|
| QRM | 57 | 57 |
| Texte à trous | 19 | 83 |
| Repérage sur schéma | 3 | 12 |
| QROC | 12 | 12 |
| Recto-verso | 6 | 6 |
| Lexique | 4 | 4 |

Sur les 57 QRM, **27 sont des annales**, de 2015/2016 à 2025/2026.

## Relu sur le cours de l'année (25/09/2026)

Chaque note a été relue contre le ronéo 2026-27. **Le cours a changé
d'enseignante et de plan** : le Pr Boulanger ouvrait sur la biologie du
vieillissement et la démographie ; le Dr Mailliez part des profils de
vieillissement et de la fragilité, puis déroule l'évaluation gériatrique et
trois syndromes — confusion, chute, dénutrition. Le ronéo n'a **pas de texte
gris** ; un seul passage en rouge, « vieillissement réussi » (p. 3). **Ses
figures comptent aussi** : la liste des douze syndromes gériatriques et le
schéma de Bouchon avec sa référence de 1984 (p. 6), la grille AGGIR et le
tableau des GIR et de l'APA (p. 8), les seuils HAS de la dénutrition modérée et
sévère (p. 15). Aucune n'est reprise dans les cartes ; elles servent à vérifier.

Une note vérifiée porte la page de ce ronéo (`page` dans `donnees.py`) : sa
source devient `src-fc-semio-age` à cette page (41 notes, plus le lexique).
Une note sans page garde l'ancien cours pour source : ce sont les 29 de la
section « Absent du cours 2026-27 ». Aucune note n'a été retirée, aucun
identifiant n'a changé, aucune clé d'annales n'a bougé ; 19 notes nouvelles
couvrent ce que le ronéo 2026-27 apporte.

| Point | Ancien cours (Pr Boulanger) | Ronéo 2026-27 (Dr Mailliez) | Cartes |
|---|---|---|---|
| Biologie du vieillissement | Hayflick, télomères, trois définitions, épigénome, 1000 jours | absente | gardées, voir « Absent » |
| Hétérogénéité (p. 2-3) | génétique, maladies, comportements, environnement ; 20 % / 80 % | génétique, pathologies, environnement, habitudes de vie ; jumeaux et tabac | `age-qc-facteurs` relue p. 2, passée du thème « biologie » à « vieillissement » |
| Démographie (p. 2) | espérance de vie à la naissance 86 / 80 ans, sans incapacité 65 / 64 | à 65 ans : 23,6 / 19,9 ans, sans incapacité 11,8 / 10,5 ; une personne sur six à 60 ans ou plus en 2030 | nouvelles `age-fa-esperance65`, `age-qc-demographie` ; `age-fa-esperance` gardée |
| Fragilité (p. 3-4, 11) | définition, trois états | trois profils, robuste = « vieillissement réussi » ; âge physiologique ; six domaines de dépistage ; pré-fragilité dès 50-55 ans ; plus fréquente chez les femmes ; objectifs du repérage | `age-fa-fragilite` reformulée ; nouvelles `age-fa-profils`, `age-qr-agephysio`, `age-fa-domaines`, `age-qc-depistage`, `age-qc-reperage` |
| Évaluation (p. 4-10) | interrogatoire, EGS d'1 h 30, AGGIR, ADL et IADL, MNA, GDS à 15 items | conciliation médicamenteuse ; EGS par tests, scores et grilles ; ADL sur 6 points et IADL ; grille AGGIR et tableau des GIR en figure, sans le nom AGGIR (GIR 1 à 4 : droit à l'APA ; p. 8) ; TUG, unipodal < 5 s, grip test, SPPB ; MoCA, MMSE ; presbytie, cataracte, glaucome, DMLA (grille d'Amsler), presbyacousie ; HADS et GDS | `age-qc-interrogatoire`, `age-qr-egs`, `age-qr-tug`, `age-qr-gds`, `age-fa-adl`, `age-qr-aggir` relues ; nouvelles `age-qr-conciliation`, `age-qc-adl-iadl`, `age-qc-tests`, `age-qc-neurosensoriel` |
| Syndromes gériatriques (p. 6) | quatre critères ; douze syndromes (liste de Lille), environ 144 selon la fiche | quatre critères ; « un syndrome gériatrique peut en cacher un autre » ; douze syndromes « à évaluer / rechercher » en figure, la polypathologie en tête | `age-fa-criteres`, `age-qc-criteres` |
| Bouchon, cascade (p. 6-7, 17) | décrit en 1984 ; exemple de l'AINS sur une insuffisance rénale | figure p. 6 : vieillissement physiologique, maladie chronique, maladie aiguë, référence Bouchon, Rev Prat 1984 ; texte p. 7 : âge, maladie chronique, maladie aiguë ; exemple de l'infection respiratoire ; cascade de la dénutrition | `age-fa-bouchon`, `age-qc-bouchon`, `age-qc-cascade`, `age-zo-bouchon` |
| Confusion (p. 11-13) | quatre signes cardinaux, dont le rythme veille-sommeil | début aigu, fluctuation, attention, désorganisation de la pensée, vigilance ; CAM ; +3 en urgence, +2 par un bilan mémoire à six mois ; bilan biologique, ECG, scanner sur indication | `age-fa-confusion` **réécrite** ; `age-qc-confusion`, `age-qc-confusion-causes` relues ; nouvelles `age-qr-cam`, `age-qc-confusion-bilan` |
| Chute (p. 13-14) | syndrome de désadaptation psychomotrice, posture détaillée | gravité, plus d'une heure au sol, syndrome post-chute (peur, rétropulsion, pieds collés), causes graves, récidive, prévention | `age-qc-postchute` relue ; nouvelles `age-qc-chute`, `age-qc-chute-risque`, `age-qr-sol` |
| Dénutrition (p. 14-17) | trois mécanismes ; 30-40 % en EHPAD, 50-60 % à l'hôpital ; MNA | HAS 2021 dès 70 ans : critère phénotypique et étiologique, IMC < 22 ; sévère si albuminémie < 30 g/L ou IMC < 20 ; trois types ; causes avant, dans et après la bouche ; prise en charge | `age-fa-denutrition` relue (garde ses pourcentages) ; nouvelles `age-fa-denut-has`, `age-qc-denut`, `age-qc-denut-pec` |
| Sarcopénie, ostéopénie (p. 9, 11, 14) | « réversibles » ; ostéoporose non réversible sans traitement | ostéopénie stabilisée ou améliorée ; activité physique quotidienne ; densitométrie pour traiter l'ostéoporose | `age-fa-bienvieillir` reformulée |
| Polypathologie | au moins trois maladies chroniques | nommée en tête des douze syndromes (figure p. 6), sans définition ; la polymédication sans seuil (p. 5, 16) | gardées, voir « Absent » |

## Quatre ATTENTION, aucun conflit de clé

Aucune clé d'annales n'est contredite par le ronéo 2026-27 : `CONFLITS` reste
vide. Mais quatre points se signalent dans les cartes, là où ils se jouent :

- **L'autonomie** (`age-qc-dependance` B, `age-an-1920s2-q18` B). Le ronéo
  2026-27 écrit « Dépendant : perte importante d'autonomie » (p. 3), son
  tableau des GIR « personne autonome pour les gestes de la vie courante »
  (GIR 6, p. 8), et emploie le mot au sens courant ; l'ancien cours et
  l'annale 2019/2020 S2 distinguent
  l'autonomie (décider) de la dépendance (faire) et donnent faux « l'autonomie
  est l'exact inverse de la dépendance ». Retenu : faux, clé inchangée.
- **L'entourage** (`age-qc-interrogatoire` B, `age-an-1516s2-q6` B). Le ronéo
  fait vérifier l'histoire auprès de la famille (p. 5) et juge le patient
  confus « pas très informatif » (p. 13), sans dire qu'il faut s'adresser à
  l'accompagnant plutôt qu'au patient. Retenu : faux, clé inchangée.
- **« La ponction rénale »** (`age-qc-confusion-bilan` C). Coquille du ronéo
  (p. 13) pour la fonction rénale ; aucun tableau d'erreurs ne la relève, les
  cours ne seront pas modifiés. La carte dit fonction rénale.
- **« Le seuil de 18 retenu chez l'adulte jeune »** (`age-fa-denut-has`,
  explication). La HAS retient 18,5 chez l'adulte de moins de 70 ans ; la
  carte ne demande que le seuil de 22.

## Absent du cours 2026-27

Ces cartes sont **gardées telles quelles** — question, réponse et clés — parce
que rien dans le ronéo 2026-27 ne les contredit ; leur explication dit
maintenant d'où vient leur contenu. À Vincent de décider s'il les garde.

| Cartes | Ce qui est absent | Source restée |
|---|---|---|
| `age-qc-hayflick`, `age-qc-telomeres`, `age-qr-hayflick`, `age-fa-troisdef`, `age-qc-vieillissement`, `age-fa-definitions`, `age-qr-epigenetique`, `age-qr-1000jours`, `age-rv-troismots` | toute la biologie du vieillissement : Hayflick, télomères, sénescence, trois définitions, « pas une maladie », OMS à 60 ans, épigénome, 1000 premiers jours | fiche (Pr Boulanger) et Charonéo 2023-24 — **hors programme cette année ?** |
| `age-qc-longevite`, `age-qr-calment`, `age-fa-esperance`, `age-rv-population`, `age-fa-population` | longévité, Jeanne Calment, espérance de vie à la naissance (86 / 80, dont 65 / 64 sans incapacité), part des plus de 75 ans dans l'activité médicale, nombre contre proportion, gériatrie au-delà de 75 ans. Le 2026-27 parle de « proportion » et donne des chiffres à 65 ans (`age-fa-esperance65`) : ne pas les mélanger | Charonéo 2023-24 et fiche |
| `age-fa-poly`, `age-qc-polypathologie` | la définition de la polypathologie (au moins trois maladies chroniques), le seuil de cinq molécules, la polypathologie comme critère du malade gériatrique. Le 2026-27 la nomme seulement, en tête des douze syndromes de sa figure p. 6. Trois annales l'interrogent (2018/2019 Q13, 2016/2017 Q25 B, 2015/2016 Q1 B) | fiche |
| `age-qc-dependance` | la définition de la dépendance, ses causes (les maladies plutôt que l'âge), les aidants familiaux. Son item C (AGGIR mesure le degré de dépendance) est vérifié sur les figures p. 8, comme `age-fa-adl` et `age-qr-aggir`, qui portent maintenant la page 8 | fiche |
| `age-fa-iatrogenie` | la définition de la iatrogénie ; le 2026-27 la nomme sans la définir (figure p. 6, p. 16-17) | fiche |
| `age-fa-postchute`, `age-zo-postchute` | le « syndrome de désadaptation psychomotrice », la sidération des automatismes, l'appui podal postérieur, les genoux fléchis, le polygone élargi ; le 2026-27 ne décrit que la peur, la rétropulsion et les pieds collés au sol (p. 13) | fiche |
| `age-fa-reserves` | la définition des réserves fonctionnelles par la distance au seuil ; le 2026-27 dit seulement la fragilité « diminution des réserves fonctionnelles » (p. 3). Trois annales la posent | fiche et annales |
| `age-qc-aigus` | la classification des syndromes en aigus (chute, confusion) ; l'annale 2023/2024 Q21 la pose | fiche |
| `age-qc-erreurs`, `age-qr-gerontes`, `age-qr-geriatrie`, `age-qr-glissement`, `age-qr-mna` | les deux erreurs et l'âgisme, « rien sur tout », la gériatrie au-delà de 75 ans, le « syndrome de glissement », le MNA | fiche |
| `age-qc-sommeil`, `age-qc-memoire` | le vieillissement du sommeil et les plaintes de mémoire, déjà absents de la fiche ; trois annales. La figure p. 6 ne nomme que « dépression - troubles du sommeil » parmi les syndromes | annales |

**Détails absents gardés dans des cartes par ailleurs vérifiées** : 30-40 % en
EHPAD et 50-60 % à l'hôpital (`age-fa-denutrition`, trous c4 et c5) ; la
marche à petits pas (`age-qc-postchute` B) ; l'AINS sur insuffisance rénale
(`age-qc-cascade` D) ; la confusion ancienne (`age-qc-confusion` E) ; « dont
certaines sont inévitables », le diabète « plus belle maladie évitable » et le
sommeil (`age-qc-facteurs` B, D, E) ; la définition des réserves
(`age-qc-bouchon` E, tirée des annales) ; l'EGS d'1 h 30 (`age-qr-egs`) ; les
15 items et le mini-GDS (`age-qr-gds`) ; le nom « AGGIR », que les figures
p. 8 n'impriment pas (`age-fa-adl` c1, `age-qr-aggir`) ; l'accumulation
d'incapacités et « ni scanner ni IRM » dans la phrase de la zone « fragile » de
`age-zo-fragilite` (les phrases de zone vivent dans `schemas.py`, qui n'a pas
été touché). La date de 1984 (`age-fa-bouchon` c1) n'en est pas : elle est
imprimée sous la figure de Bouchon p. 6.

## Sans illustration

22 QCM sur 57 portent une illustration (39 %), sous l'objectif de la moitié.
Les trois schémas redessinés du chapitre — Bouchon, les trois profils, la
posture post-chute — sont attachés partout où ils éclairent la réponse : douze
QCM de plus depuis la relecture (trois cartes du cours, cinq annales, quatre
cartes nouvelles). Le reste ne peut pas l'être :

- le cours 2026-27 est fait de **listes, de grilles et de seuils** (ADL et
  IADL, tests gériatriques, neurosensoriel, critères HAS de la dénutrition,
  chute, démographie) qu'aucun des trois schémas n'illustre ;
- ses figures (la liste des syndromes et le schéma de Bouchon p. 6, la grille
  AGGIR et le tableau des GIR p. 8, la balance de la dénutrition p. 14, les
  seuils HAS p. 15, les situations à risque p. 16, la spirale de la dénutrition
  p. 17) appartiennent au ronéo et ne sont jamais reprises ;
- les cartes gardées de l'ancien cours (biologie, polypathologie, sommeil,
  mémoire) n'ont pas de schéma.

Redessiner nus la balance de la dénutrition et l'algorithme de la CAM, dans
`schemas.py`, relèverait la part : à décider.

**Depuis l'échelle (16/10/2026)**, 60 QCM sur 95 portent une illustration.
Restent sans marche ni lettre 2021/2022 S2 Q15, 2019/2020 S2 Q15 et Q16,
2015/2016 Q2 (sommeil, démographie, plaintes de mémoire : ni au ronéo 2026-27,
ni tranchés par le Charonéo 2023-24).

## Le schéma qui rapporte le plus

Le **1 + 2 + 3 de Bouchon** est interrogé par **quatre questions sur
vingt-sept**, et à chaque fois par le même procédé : échanger les droites II et
III. Le ronéo 2026-27 reproduit le schéma, légendé « vieillissement
physiologique, maladie chronique, maladie aiguë », avec sa référence (Bouchon,
Rev Prat 1984, p. 6), nomme ses trois facteurs « âge, maladie chronique,
maladie aiguë » (p. 7), et en fait la clé de la confusion : le +3 se cherche en
urgence, le +2 à distance (p. 11-12).

| Droite | Ce qu'elle est | Le piège |
|---|---|---|
| **I** | vieillissement physiologique, l'« âge » | « peut franchir le seuil à elle seule » → **faux** |
| **II** | maladie **chronique** | proposée comme « facteurs précipitants » ou « maladie causale » |
| **III** | maladie **aiguë** | proposée comme « pathologies chroniques » ou « comorbidités » |

Et une définition à connaître mot pour mot, tirée des annales : **les réserves
fonctionnelles sont la distance entre l'individu et le seuil de
décompensation.** Elles diminuent avec l'âge, donc un patient fragile en est
plus **proche** — deux annales posent l'inverse et le donnent faux.

Les zones cliquables de ce schéma ne sont pas placées à vue : leurs sommets sont
calculés sur les pentes de la courbe, et un test vérifie que la courbe passe
**dans** chaque zone.

## Les trois autres savoirs rentables

| Le savoir | Questions | Le piège constant |
|---|---|---|
| Les **4 critères** d'un syndrome gériatrique | 6 | « spécifique de la personne âgée » → toujours faux |
| **Fragilité** contre **dépendance** | 5 | la grille **AGGIR mesure la dépendance**, pas la fragilité (le ronéo 2026-27 la range sous « Évaluation de la dépendance », figure p. 8) |
| La **polypathologie** | 3 | « maladies aiguës ou chroniques » → c'est **chroniques**, au moins trois (le ronéo 2026-27 la nomme sans la définir, figure p. 6) |

Deux sessions fixent définitivement ce que mesure AGGIR : 2019/2020 S2 le donne
**vrai** pour la dépendance, 2015/2016 S2 le donne **faux** pour la fragilité.

## Trois sujets tombent sans être au cours

Ni dans la fiche, ni dans le ronéo 2026-27. Ils sont cartés dans un thème à
part — **« Tombé en annales, absent de la fiche »** — et chaque carte le
signale :

- le **vieillissement du sommeil** : deux questions entières (2021/2022 et
  2015/2016) ; la figure p. 6 du ronéo 2026-27 ne nomme que « dépression -
  troubles du sommeil » parmi les douze syndromes ;
- les **plaintes de mémoire** : une question (2019/2020 S2) ;
- quelques **chiffres démographiques** précis, différents de ceux des deux
  cours.

## Une anomalie de mise en page, répétée

Le mot **« Dépression »** fuit à la fin de quatre énoncés — 2021/2022 Q16,
2017/2018 Q25, 2017/2018 S2 Q8, 2015/2016 Q4. Les clés portent à chaque fois sur
cinq propositions lettrées A à E, ce qui confirme l'artefact. Il a été retiré des
énoncés, sauf en 2017/2018 Q25 où il est restitué : la dépression **est** un
syndrome gériatrique, et l'ancien cours insistait pour qu'on cesse de parler de
« syndrome de glissement ».

## Les trois schémas cliquables

| Fichier | Ce qu'on y clique | Cartes |
|---|---|---|
| `bouchon-123.svg` | les trois droites et le seuil | 4 |
| `fragilite-etats.svg` | robuste, fragile, dépendant, et la perturbation | 4 |
| `posture-post-chute.svg` | rétropulsion, appui podal, genoux, polygone (posture de l'ancien cours) | 4 |

## Le corrigé officiel 2023-24

Le sujet de sémiologie générale 2023-24 et son corrigé officiel (une clé par question) sont arrivés le 15/10/2026. Les cartes de cette session venaient du polycopié et en gardent la source ; leur clé est vérifiée :

- 2023/2024 S1 QCM 20 (`age-an-2324-q20`, A) : clé confirmée par le corrigé officiel 2023-24, dépôt du 15/10/2026.
- 2023/2024 S1 QCM 21 (`age-an-2324-q21`, CE) : clé confirmée par le corrigé officiel 2023-24, dépôt du 15/10/2026.


## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026)

L'échelle du pilote de l'immunité innée, étendue à la sémiologie pour l'examen du 4/11 (Vincent, 16/10 : « on continue pour les chapitres que je vais avoir à l'examen »). Sous les annales, 28 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 10 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `vieillissement` | 1 | 1 | 1 |
| `syndromes` | 7 | 2 | 9 |
| `decompensation` | 9 | 2 | 4 |
| `fragilite` | 7 | 3 | 6 |
| `examen` | 4 | 2 | 3 |
| `hors-fiche` | 0 | 0 | 4 |

**Le schéma** `ech-sujet-age`, « Le sujet âgé · syndromes, Bouchon, fragilité », donne 62 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_SUJET_AGE`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- 2021/2022 S2 Q15, 2019/2020 S2 Q15, 2019/2020 S2 Q16, 2015/2016 Q2 (A à E, thème hors-fiche) : sommeil, démographie chiffrée, plaintes de mémoire, absents du ronéo 2026-27 et de la fiche de l'ancien cours. Le Charonéo 2023-24 (src-roneo-age), relu, ne les tranche pas : il dit seulement que la part des plus de 65, 75 et 85 ans « va exploser » d'ici 2050, et ne nomme les troubles du sommeil et de la mémoire que comme syndromes gériatriques ou causes de chute, sans l'architecture du sommeil ni les plaintes de mémoire. Aucune phrase du cours de l'année à citer : ni marche, ni lettres sur le schéma.
- « Les syndromes gériatriques sont des marqueurs de fragilité » : 2021/2022 S2 Q13 D, 2019/2020 S1 Q24 C, 2018/2019 S1 Q15 E, 2015/2016 S2 Q4 D, 2019/2020 S2 Q17 C. Ni le ronéo 2026-27 ni aucune carte de l'ancien cours ne le disent ; seules les clés le portent. Les lettres sont posées sur la case « Fragile ».
- « Le plus souvent des états de décompensation fonctionnelle » : 2021/2022 S2 Q13 A, 2018/2019 S1 Q15 A. Le ronéo range le modèle du bouchon dans sa partie sur les syndromes gériatriques (p. 6-7), mais ne le dit pas.
- 2021/2022 S2 Q13 E (la maladie d'Alzheimer) : aucun des deux cours ne la nomme. La figure p. 6 range « troubles cognitifs - démence - confusion » parmi les douze ; seule la clé sépare la maladie du syndrome.
- 2021/2022 S2 Q16 D (la polypathologie, cause et non risque de la fragilité) : aucun cours cité par le chapitre ne relie polypathologie et fragilité dans ce sens.
- 2018/2019 S1 Q13 B, D, E. B : le seuil de cinq molécules de l'ancien cours n'a pas de case, faute de place sous 600 px. D : aucun cours ne dit que la polypathologie modifie l'expression clinique. E : aucun ne dit qu'elle n'est pas l'exclusivité du sujet âgé.
- 2018/2019 S1 Q14 D (l'isolement social contribue à la fragilité) : le ronéo cite l'isolement pour la gravité d'une chute (p. 14) et pour la dénutrition (p. 16), pas pour la fragilité.
- 2017/2018 S1 Q25 B (« fragilité et dépendance ») : la figure p. 6 dit « fragilité - sarcopénie » et ne nomme pas la dépendance. La liste du schéma ne garde que deux items.
- 2017/2018 S2 Q8 B (l'âge moyen) et E (la prévention, le vieillissement actif) : ni l'un ni l'autre dans les deux cours.
- 2016/2017 Q25 D (effets indésirables plus fréquents et plus graves) : le ronéo nomme la iatrogénie parmi les douze (figure p. 6) sans la quantifier.
- 2015/2016 S2 Q7 D (la fragilité précède « toujours » la dépendance) : aucun cours ne décrit le passage direct du robuste au dépendant qui la rend fausse.
- 2025/2026 Q25 A (« un enjeu majeur de santé publique ») : c'est la formule de l'ancien cours ; le ronéo dit seulement que le repérage réduit les dépenses de santé évitables (p. 11). Pas reprise, pour que la carte m6 reste sur le repérage.

## Régénérer

```powershell
python generer.py
```
