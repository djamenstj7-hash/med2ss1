# Pharmacodynamie du métabolisme — paquet BMCT

137 notes, 213 cartes. Chapitre `chap-ue-bmct-fc7` de l'UE BMCT, septième de
l'UE. **Cours du Pr Devos du 12/10/2026, de 9 h à 10 h, en une ronéo Ronéo &
Juliette 2026-27**, « Pharmacologie du métabolisme » (10 p.). Réaligné sur elle le
19/10/2026. Il était carté depuis le 02/10 (tâche C14) sur la FC n°7 du
Ronéosaure 2025-26 (Pr Devos, 14/10/2025), qui n'est plus qu'un appoint.

Les annales viennent du polycopié « Pharmacologie du métabolisme » du Ronéosaure
2024-25 (15 sessions), plus deux questions du sujet 2024/2025 (déposé le
15/10/2026). Examen : partiel du mercredi 4 novembre 2026.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 53 | 53 |
| QRU (marches Simple) | 36 | 36 |
| Texte à trous | 12 | 83 |
| QROC | 9 | 9 |
| Recto-verso | 12 | 12 |
| Lexique | 12 | 12 |
| Planche à légender | 2 | 2 |
| Schéma cliquable | 1 | 6 |

Le chapitre compte **30 annales** sur 16 sessions : 23 QCM et 7 rédactionnelles
(recto-verso). Ce sont le polycopié de métabolisme et les Q4 et Q5 du sujet
2024/2025 (session 1, sans corrigé : `pmt-an-2425s1-q4`, `pmt-an-2425s1-q5`).
La correction surlignée en bleu sur le PDF du sujet donne les mêmes clés, ABCD
et ACE. Elle est officieuse, d'origine inconnue, et n'est pas déclarée ; le même
surligneur reproduit 37 des 40 clés officielles de 2023-24.

Côté cours : 24 QCM, 12 textes à trous, 9 QROC, 5 recto-verso, 1 schéma
cliquable, 2 planches et 12 termes de lexique. S'y ajoutent les 42 marches de
l'échelle.

**85 QCM sur 89 illustrés (96 %)**, et 113 notes sur 137. **92 cartes citent la
ronéo 2026-27 à sa page** : elles perdent le badge « Cours 2025-26 ». **3 cartes
sont absentes du cours 2026-27** (tag `absent-2026`). **32 cartes portent un piège
de la ronéo** (thème « Pièges des ronéos »).

Les sujets déposés le 15/10/2026 confirment deux corrections :

- la grille officielle de la faculté confirme les clés de 2023/2024 S1 (Q3 BE,
  Q4 AC) ;
- le corrigé officiel de la QR2 2023/2024 (Pr Devos, remodelage osseux) est mot
  pour mot celui du polycopié, déjà repris (`pmt-an-2324s1-qroc2`,
  `officielle=True`).

Cinq thèmes, dans l'ordre du cours. Leurs libellés sont déjà dans `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`), et le réalignement n'en ajoute
aucun :

| Clé | Libellé | Notes |
|---|---|---|
| `metabolisme-bases` | Métabolisme, anabolisme, catabolisme | 11 |
| `antidiabetiques` | Médicaments du diabète | 37 |
| `hypolipemiants` | Hypolipémiants et dyslipidémies | 33 |
| `hormonotherapie` | Médicaments des hormones | 20 |
| `remodelage-osseux` | Os et remodelage osseux | 24 |

(Les 12 termes de lexique portent le tag `lexique`, sans thème.)

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-bmct-pmt-2627` — « Pharmacologie du métabolisme » (10 p.), `BMCT/PHARMACOLOGIE DU MÉTABOLISME.pdf` | **2026-27** | **la fiche** (`SRC["fiche"]`, `FC1`), ce que le lecteur ouvre ; cours du 12/10/2026, 9 h-10 h, Pr Devos ; 92 cartes et les 12 termes du lexique la citent |
| `src-fc-bmct-pmt-2526` — FC n°7, « Pharmacodynamie du métabolisme » (10 p.), `BMCT/FC n°7 Pharmacodynamie du métabolisme .pdf` | 2025-26 | **appoint** (`SRC["cours"]`, `SRC["medias"]`, sans `chapitre=`) : ce que la ronéo 2026-27 ne reprend pas, **les sept figures**, plus nettes, et la source des **3 cartes absentes** (`fiche=FC2526`) |
| `src-annales-bmct-meta` — « BMCT - Pharmacologie du métabolisme » (9 p.) | 2024-25 | 15 sessions, table p. 7-9 ; déclarée **à l'identique** de `bmct_variabilite`, qui en carte le QROC 1 de 2022/2023 S1 |
| `src-sujets-bmct-2425` — Sujets de BMCT 2024/2025, session 1 (20 p.) | 2024-25 | les Q4 et Q5, sujet sans corrigé ; `SRC["sessions"]["2024/2025 S1"]` ; déclaré à l'identique par tous les chapitres de BMCT qui en cartent une question |
| tableau d'erreurs BMCT de la promo 2026-27 | 2026-27 | rien sur ce cours au 19/10/2026 (ses deux lignes portent sur d'autres cours) |

**Comment les textes citent.** Ils citent « p. 5 » pour la ronéo 2026-27, et
« FC 2025-26, p. 6 » pour l'ancienne fiche. Chaque annale porte la page de la
ronéo où se lit sa réponse (`page`, source secondaire).

**Les fichiers.** La fiche de l'année se copie dans le dossier des PDF de
l'application par `outils/copier_les_cours.py`, lancé hors du bac à sable avec
le dossier des ronéos 2026-27 (`Ajouts/[NUMERIQUE] Ronéo & Juliette 26-27 19 10
2026/S1/CM`). Le nom du fichier de la FC 2025-26 finit par une espace avant
`.pdf` (NFC).

**Lus en appoint, sans être déclarés** :

- la FC n°7 2024-25 du même professeur ;
- le cours 2023-24 n°3 (Charonéo) ;
- l'errata des cours 2025-26 et celui des annales.

Les en-têtes des ronéos, des erratas et du polycopié portent des noms
d'étudiants : aucun n'est repris.

## Ce qui correspond à quoi

La ronéo 2026-27 suit, dans l'ordre, le plan de la FC 2025-26 ; les pages
glissent d'une unité à partir des lipides.

| FC 2025-26 | Ronéo 2026-27 |
|---|---|
| I. Introduction, définitions (p. 1-2) | p. 2, avec **le métabolisme basal et l'élimination rénale ou hépatique**, que le ronéo 2025-26 taisait |
| II. Glucidique : généralités, deux diabètes (p. 2) | p. 2-3 ; **nouvelle diapositive** de la régulation de la sécrétion d'insuline (p. 3) |
| II. Insuline, objectifs, schéma, metformine, sulfonylurées (p. 3) | p. 3 |
| II. Glinides à SGLT2, glucocorticoïdes (p. 4) | p. 3-4 (les glinides seulement projetés) |
| III. Lipides, lipoprotéines, mécanismes (p. 5-6) | p. 4-5 |
| III.B Pharmacologie (p. 6) | p. 5 |
| III.C Dyslipidémies et leurs causes (p. 6-7) | p. 6, « hypercholestérolémies secondaires », avec un **résumé** du traitement |
| IV. Hormones : généralités, axe (p. 7-8) | p. 6-7, avec des **généralités** plus longues |
| IV. Ocytocine, médicaments (p. 8) | p. 7-8 |
| IV. Hormones sexuelles (p. 9) | p. 8-9 |
| V. Os : généralités, maladies (p. 9) | p. 9-10 |
| V.C Remodelage (p. 10) | p. 10, avec la **calcitonine** dans le texte et l'**antisclérostine** |

Les sept diapositives de la FC 2025-26 sont dans la ronéo 2026-27 : les deux
diabètes ne sont plus en tableau, les six autres sont identiques, et quatre sont
moins nettes. Les figures restent donc celles de la FC 2025-26, et leur légende
cite les deux pages.

## Le réalignement du 19/10/2026

Les 90 notes de cours de la version 2025-26 (48 de cours et 42 marches) ont été
relues une à une contre la ronéo.

**87 relues sur elle, dont 24 réécrites (ci-dessous).** Elles citent désormais
leur page de l'année (`page`, fiche 2026-27). Leurs justifications citent la ronéo (« p. 5 ») ; ce que seule la
FC 2025-26 porte le dit (« FC 2025-26, p. 9 ; la ronéo 2026-27 ne le dit
plus »). Une carte n'est confirmée que si sa notion centrale est dans le cours de
l'année. Toutes les pages des cartes de lipides et d'hormones ont glissé d'une
unité.

**Réécrites (24), parce que la ronéo 2026-27 dit autrement ou ne dit plus**,
la note gardant son identifiant et son type :

- `pmt-qc-hormones-sexuelles` change de clé (ABCE → **BCDE**). La ronéo 2026-27 dit
  que donner des œstrogènes « augmente la fertilité alors que c'est l'inverse »
  (p. 8). Elle note que le professeur n'a parlé que de la GnRH pour la fertilité
  (« NB » de la p. 9). La FC 2025-26 disait les œstrogènes utiles « pour
  favoriser la fertilité ». La proposition A est retournée, et B, D, E suivent la
  ronéo (GnRH au bon moment, pulsatilité, moment de la prise).
- `pmt-qc-os` A et E, `pmt-fa-os` (trous 2 et 8) : la part de l'os cortical
  (80 %) et les protons de l'ostéoclaste ne sont plus dans le cours. Ils sont
  remplacés par ce qu'il dit : os cortical et os longs, trabéculaire et vertèbres,
  l'hydroxyapatite.
- `pmt-qc-dyslipidemies` A (le syndrome néphrotique devient l'alcoolisme) et
  `pmt-fa-dyslipidemies` : la ronéo ne cite plus le syndrome néphrotique ni les
  thiazidiques. Le trou des thiazidiques reste, dit « du cours 2025-26 et des
  annales », puisque deux annales les posent.
- `pmt-qc-metabolisme` D, `pmt-fa-metabolisme` : la « balance continue » cède à
  l'élimination rénale ou hépatique et au métabolisme basal (p. 2).
- `pmt-qc-vitamine-d-rankl` : nouvel énoncé. La vitamine D du sujet âgé et
  « pas d'effet sans déficit », qui ne sont plus dans le cours, laissent la place à
  l'antisclérostine et à la parathormone (p. 10).
- `pmt-fa-objectifs` : « glycémie post-prandiale », et plus d'« antidiabétiques
  oraux ».
- `pmt-fa-maladies-os` : la vitamine D « et/ou le calcium ».
- `pmt-fa-remodelage` : deux trous ajoutés, la calcitonine et l'antisclérostine.
- `pmt-qc-diabetes` C : l'insuline normale ou augmentée du type II.
- `pmt-qc-lipides` C : le « fuel » et la bêta-oxydation ne sont plus dits.
- `pmt-qc-incretines` E : le détournement et les effets à long terme.
- `pmt-qc-glucocorticoides` B et E : « maladie endocrinienne », la figure.
- `pmt-qc-hormones-axe` A et D : voie nasale ou comprimé, petite taille.
- `pmt-qc-ocytocine` B : « les campagnols des vallées ».
- `pmt-qr-isotretinoine`, `pmt-ech-s28` : « très efficace pour l'acné mais
  dangereux ++ ». La thrombose sous pilule ne vient plus que de 2025-26.
- `pmt-qr-desmopressine` : la voie nasale ou le comprimé.
- Les versos de `pmt-rv-blaste-claste` (sans les protons), de
  `pmt-rv-gliptines-glp1` (gliptines « moins efficaces ») et de
  `pmt-rv-gc-bisphosphonates`.
- `pmt-ech-s2` et sa case : « dans tout le corps » (p. 2) remplace « cellule,
  tissu, organe… » (FC 2025-26, p. 1).

**Nouvelles (9)** :

- `pmt-qr-tabac-pilule` (ajoutée à la relecture) : « Tabac + pilule = possibilité
  de faire un infarctus (ou embolie pulmonaire) » (p. 5, déjà dans la FC 2025-26,
  p. 6), qu'aucune carte ne tenait ; la référence HAS en explication.
- `pmt-qc-secretion-insuline`, sur la seule diapositive nouvelle (p. 3). Les
  nutriments, les hormones gastro-intestinales et le parasympathique y stimulent
  la cellule β ; le sympathique α2, la somatostatine et l'amyline la freinent.
- `pmt-fa-diabetes` : type I à insuline basse, auto-immune, plus de 90 % des
  îlots détruits ; type II à insuline normale ou augmentée, multifactoriel
  (p. 2-3).
- `pmt-qc-hypercholesterolemie` : le résumé du traitement, la pilule d'abord chez
  la jeune femme, le diabète, l'isotrétinoïne « dangereux ++ » (p. 6).
- `pmt-qc-hormones-generalites` : la fonction à distance, les récepteurs
  membranaires, intracellulaires et l'ADN, les cytokines qui ne sont pas des
  hormones, l'ADH et l'ocytocine stockées sans changer d'état (p. 6-7).
- Quatre termes de lexique : glycosurie, hypercholestérolémie, ostéocyte,
  hydroxyapatite.

**Les annales** restent telles quelles, verbatim. Aucune clé n'est contredite
par le cours de l'année, et `CONFLITS` reste vide. Leurs justifications citent
la ronéo. Deux reçoivent l'ATTENTION d'un piège que leur clé déjoue
(`pmt-an-1718s2-q4` E, `pmt-an-1718s2-q20` A).

**La relecture sceptique du 19/10**, carte par carte contre les pages et les
images de la ronéo, les cours 2023-24 à 2025-26 et l'errata 2025-26 :

- trois genres corrigés : la metformine passe en douteux (sa formule se lit
  aussi comme la baisse de l'absorption intestinale que posent la diapositive
  et le corrigé) ; le GIP passe en cours (trois ronéos, rien qui dise juste) ;
  « craniopharyngium », une coquille, perd son ATTENTION ;
- cinq erreurs manquées, portées dans leurs cartes : les « Ostéocytes » de la
  p. 9 (prise de notes : `pmt-qc-os`, `pmt-rv-blaste-claste`) ; en douteux, les
  chylomicrons (`pmt-pl-hypolipemiants`, n° 11), les hormones « synthétisés
  majoritairement de l'axe » (`pmt-qc-hormones-generalites`), le taux
  d'ocytocine des campagnols (`pmt-qc-ocytocine`) et l'espérance de vie (sans
  carte) ;
- une carte nouvelle, `pmt-qr-tabac-pilule` (p. 5) ;
- `pmt-qc-hormones-generalites` B ne fait plus lier l'ADN aux hormones
  elles-mêmes, mais à leurs récepteurs, comme la ronéo ; `pmt-qc-hormones-sexuelles`
  E ne dit plus « autant que la dose » ;
- l'ézétimibe redevient masculin dans `pmt-ech-s25`, `pmt-ech-m4` et deux
  justifications d'annales ; le verso des dyslipidémies dit où vont les
  triglycérides des chylomicrons ;
- « 1 % restant dans les cellules » (p. 9), donné faux, est juste : retiré.

## Absent du cours 2026-27

Trois cartes (`ABSENTS_2026`, tag `absent-2026`, « Absent du cours 2026-27 » en
tête de l'explication) citent la FC 2025-26 à sa page (`fiche=FC2526`) :

| Carte | Ce qu'elle tient | FC 2025-26 |
|---|---|---|
| `pmt-ech-s1` | le métabolisme, transformations « moléculaires et énergétiques » ; la ronéo 2026-27 dit « une transformation dans le corps » | p. 1 |
| `pmt-ech-s29` | les thiazidiques, cause médicamenteuse de dyslipidémie | p. 7 |
| `pmt-qr-protons` | les protons que libère l'ostéoclaste pour déminéraliser l'os | p. 9 |

Elles préparent toujours des annales (2017/2018 S2 Q3 A, 2015/2016 S1 Q5 A ;
2022/2023 S2 Q4 A, 2021/2022 S1 Q.4 A). Le schéma de l'échelle garde les deux
cases, et sa légende cite la FC 2025-26 pour elles.

Dans des cartes de l'année, deux propositions ne viennent que de 2025-26, et
chacune le dit dans sa justification : l'origine antibiotique des sulfonylurées
(`pmt-qc-cellule-beta` D) et les glinides qui rendent la cellule plus excitable
(`pmt-qc-cellule-beta` C) ; de même la définition « moléculaires et
énergétiques » (`pmt-qc-metabolisme` A, `pmt-fa-metabolisme`) et le trou des
thiazidiques (`pmt-fa-dyslipidemies`).

D'autres notions de la FC 2025-26 ne sont plus testées : leurs propositions ont
cédé la place à celles de l'année, et elles ne vivent plus que dans
l'explication de la carte, « la FC 2025-26 ajoutait… » :

- la neuroprotection des analogues du GLP-1 dans Parkinson ;
- la desmopressine contre la polyurie ;
- la bromocriptine dans Parkinson et « quelques jours » gagnés ;
- la décharge d'ocytocine contre l'hémorragie ;
- les anti-testostérone du cancer de la prostate, « la plus petite dose possible,
  le moins longtemps possible » (`pmt-qc-hormones-sexuelles`, ex-D et E) ;
- la vitamine D du sujet âgé et son inutilité sans déficit
  (`pmt-qc-vitamine-d-rankl`, ex-B et E) ;
- l'os cortical à 80 % (`pmt-qc-os` ex-A, `pmt-fa-os`) ;
- le syndrome néphrotique parmi les causes (`pmt-qc-dyslipidemies` ex-A) ;
- l'athérosclérose par excès de LDL.

Aucune annale ne les pose. Si Vincent veut les réviser, une carte entière
`ABSENTS_2026` par thème les reprendrait (voir les questions).

## Ce que le cours a dicté

- **Le rouge de la ronéo 2026-27**, chacun dans sa carte :
  - « UNE SEULE hormone hypoglycémiante » et « BEAUCOUP d'hormones
    hyperglycémiantes » (p. 2) ;
  - la maladie auto-immune qui détruit les îlots (p. 2) ;
  - « augmente » et « glycogène » (p. 3) ;
  - le syndrome de Cushing (p. 4) ;
  - « Attention » à la balance bénéfice/risque (p. 8) ;
  - les ostéocytes, les ostéoclastes et la perte de masse osseuse (p. 9).
- **Le bleu gras** (mots clés des rédacteurs) se carte comme le reste. La ronéo
  n'a **pas de gris**, et ne définit aucune couleur « à ne pas retenir ».
- **« NB : le prof a dit que les années précédentes il posait seulement des
  questions schémas à l'examen mais que cette année avec la mise en place des
  QROC etc il ne savait pas trop ce qui allait nous attendre »** (p. 2). Les
  schémas restent donc au centre :
  - le schéma cliquable ;
  - les deux planches ;
  - l'échelle ;
  - la figure du cours en correction de presque chaque QCM.

  Les QROC et les textes à trous couvrent le reste.
- **« NB : ne pas tout retenir »** (p. 6), sur la pharmacologie des lipides : rien
  n'est retiré, puisque les annales posent chaque classe.
- **Ce qui n'est pas carté ici** (plan C14), et que les cartes citent :
  - les seuils de glycémie et les lipoprotéines elles-mêmes (BMCP :
    `bmcp_insuline`, `bmcp_lipides`) ;
  - l'acidose lactique de la metformine (`bmct_variabilite`) ;
  - l'immunosuppression des glucocorticoïdes (FC6) ;
  - la balance bénéfice-risque des analogues du GLP-1 (FC9).
- **Les apartés sans contenu à apprendre ne sont pas cartés** :
  - le foie refait en trois semaines ;
  - la vie « prévue » à deux fois l'âge de la maturité sexuelle ;
  - l'espérance de vie en bonne santé ;
  - les campagnols et les sociopathes, dont seul le raisonnement est carté ;
  - l'infertilité et l'environnement.

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| Métabolisme et hormones : catabolisme « uniquement hépatique », métabolisme basal, D1 contre D2, desmopressine, lévothyroxine | 2023/2024 Q3, 2022/2023 S1 Q. 3, 2020/2021 S1 Q. 5, 2019/2020 S1 Q. 5 (mot pour mot) ; 2021/2022 S2 Q. 4 (variante) |
| Généralités du métabolisme | 2017/2018 S2 Q3, 2015/2016 S1 Q5 (mot pour mot) |
| Antidiabétiques : metformine, sulfonylurées, gliptines, DPP-4, α-glucosidases, gliflozines, GLP-1 | 2023/2024 Q4, 2021/2022 S2 Q. 5 et 2016/2017 S1 Q2 (mot pour mot), 2017/2018 S2 Q20, 2015/2016 S2 Q5 |
| Hypolipémiants et dyslipidémies secondaires | 2024/2025 S1 Q4, 2022/2023 S1 Q. 4, 2022/2023 S2 Q4, 2019/2020 S2 Q. 4, 2018/2019 S1 Q. 2, 2017/2018 S2 Q4 |
| Remodelage osseux | 2024/2025 S1 Q5, 2022/2023 S2 Q3, 2017/2018 S1 Q4 (même question, un mot près), 2021/2022 S1 Q.4, 2016/2017 S2 Q4 |
| Rédactionnelles « à l'aide d'un schéma » | antidiabétiques : 2022/2023 S2 (corrigé), 2021/2022 S1, 2017/2018 S1 ; dyslipidémie : 2021/2022 S2, 2019/2020 S1, 2015/2016 S1 ; remodelage : 2023/2024 (corrigé) |

**Non carté ici** : le QROC 1 de 2022/2023 S1 (Pr Gautier, metformine chez le
sujet âgé), carté au chapitre des facteurs de variabilité.

## Les erreurs de la ronéo 2026-27

Le tableau d'erreurs BMCT de la promo ne relève rien sur ce cours. Toutes les
erreurs ci-dessous ont été trouvées en relisant la ronéo contre la diapositive
du professeur, le ronéo 2025-26 du même professeur et les références. Chacune
est portée par un ATTENTION à genre dans la carte qui tient la notion ; aucune
n'est encore dans `contenu/ERRATA_RONEOS_2026-27.md`.

**Prise de notes** (la diapositive, la même page, le cours d'une année
précédente ou le même ronéo 2025-26 ailleurs disent juste) :

| Page | La ronéo dit | Retenu | Preuve | Cartes |
|---|---|---|---|---|
| 2 | stress : « on sera donc dans un état hyperinsulinique » | le stress est hyperglycémiant : l'adrénaline freine l'insuline | la diapositive p. 3 : Σ (α2) (−) sur la cellule β ; cours 2023-24 (« légère hyperglycémie ») ; errata 2025-26 ; Fagerholm 2011 | `pmt-qc-regulation`, `pmt-qc-secretion-insuline`, `pmt-ech-s12` |
| 3 | l'insuline : « si elle augmente la formation de glucose elle diminue sa dégradation » | formation de glycogène, glycogénolyse diminuée | la même page, en rouge : « stockage de sucre sous la forme de glycogène » ; errata 2025-26 | `pmt-qc-insuline` |
| 4 | Cushing : « Il ne manifeste pas un ensemble de signes résumés sur cette image » | il se manifeste par les signes de la figure | la figure p. 4 ; FC 2025-26, p. 4 | `pmt-qc-glucocorticoides` |
| 4 | les lipoprotéines « vont donner des lipides aux protéines » | aux cellules, par leurs apoprotéines et les récepteurs | la figure p. 4 (liaison aux récepteurs cellulaires, internalisation) ; errata 2025-26 | `pmt-qc-lipides` |
| 5 | ézétimibe : « bloque le passage des acides gras dans le sang » | bloque l'absorption intestinale du cholestérol (NPC1L1), pas des acides gras | cours 2023-24 (« la pénétration du cholestérol »), FC 2024-25 et 2025-26 (« la captation du cholestérol ») ; clé de 2017/2018 S2 Q4 E ; Vidal | `pmt-qc-resines-niacine`, `pmt-fa-hypolipemiants`, `pmt-ech-s25`, `pmt-an-1718s2-q4` |
| 7-8 | « Growing Hormone », « Growing Hormone Releasing Hormone » | growth hormone, growth hormone-releasing hormone | la diapositive p. 6 (« GH », « GHRH ») ; FC 2025-26, p. 8 (« GHRH : growth hormone releasing hormone ») ; StatPearls, Physiology, Growth Hormone | `pmt-fa-axe` |
| 9 | « deux types de cellules, en équilibre permanent : Ostéocytes [en rouge] : ce sont des ostéoblastes… ; Ostéoclastes » | l'équilibre est entre ostéoblastes et ostéoclastes ; l'ostéocyte est l'ostéoblaste emmuré | la diapositive p. 10 (OBs, OCs) ; le résumé de la p. 10 ; cours 2023-24 (« un équilibre permanent entre ostéoblastes et ostéoclastes ») | `pmt-qc-os`, `pmt-rv-blaste-claste` |

**Le cours lui-même** (la carte répond comme le professeur, puis donne la
référence) :

| Page | La ronéo dit | À l'examen | La référence | Cartes |
|---|---|---|---|---|
| 2 | hormones hyperglycémiantes : « glucagon, somatostatine, amyline, les catécholamines » (ronéos 2023-24 à 2025-26) | comme la liste ; seules les catécholamines ont été demandées | glucagon, catécholamines, cortisol, GH ; l'amyline et la somatostatine freinent, entre autres, le glucagon | `pmt-qc-regulation` |
| 4 | « le GLP 1 et le gastro-intestinal peptide » (ronéos 2024-25 et 2025-26 ; la diapositive écrit « GIP » sans le développer) | le GIP, incrétine sécrétée avec le GLP-1, que la DPP-4 dégrade | glucose-dependent insulinotropic polypeptide (StatPearls, GIP) | `pmt-qc-incretines` |
| 5 | statines : « stimuler l'ApoE pour permettre la fixation des LDL » (ronéos 2023-24 à 2025-26, diapositive) | « les statines stimulent les récepteurs Apo E » : vrai | elles augmentent le récepteur des LDL (apo B/E) par SREBP-2 (Duriez 2003) | `pmt-qc-statines-fibrates`, `pmt-ech-s21` |
| 5 | « La nicotine permet de faire perdre du poids par le mécanisme de stimulation de lipoprotéine lipase » (ronéos 2023-24 à 2025-26) | l'acide nicotinique stimule les LPL : vrai | l'acide nicotinique est la niacine (vitamine B3), non la nicotine (StatPearls, Niacin) | `pmt-qc-resines-niacine`, `pmt-ech-s23`, `pmt-ech-m4` |

**Points douteux** (une imprécision, une formule ambiguë, ou un cas qu'aucune
source ne tranche) :

| Page | La ronéo dit | Le point | Cartes |
|---|---|---|---|
| 2 | « Hyperglycémie ⇒ entre 1,10 et 1,26 ; Diabète ⇒ > 1,26 g/L » | 1,10-1,25 g/L : l'hyperglycémie modérée à jeun ; diabète ≥ 1,26 g/L, deux fois (OMS 2006) | `pmt-qc-diabetes` |
| 3 | metformine : diminue « la captation du glucose au niveau des alpha-glucosidases » (ronéo 2025-26 ; « en inhibant l'alpha-glucosidase » en 2023-24) | formule ambiguë : la diapositive pose un (−) des biguanides sur le tube digestif, et le corrigé du QROC 2022/2023 S2 dit « diminution de l'absorption intestinale » ; au muscle, la captation AUGMENTE ; la metformine n'inhibe pas les α-glucosidases (RCP) | `pmt-qc-metformine`, `pmt-ech-s10`, `pmt-ech-s11`, `pmt-an-1718s2-q20` |
| 5 | « Les chylomicrons amènent au foie les triglycérides et le cholestérol » (cours 2023-24 à 2025-26) | un raccourci : la diapositive fait libérer leurs triglycérides par la lipoprotéine lipase, et c'est le remnant (CE > TG) qui gagne le foie (MSD Manuel, « Revue générale du métabolisme des lipides ») | `pmt-pl-hypolipemiants` (n° 11) |
| 5 | résines : « moins de dégradation des lipides en cholestérol » | les lipides ne se dégradent pas en cholestérol ; retenir la chélation des acides biliaires | `pmt-qc-resines-niacine`, `pmt-ech-s24` |
| 6 | « hypercholestérolémie et des triglycérides on met des fibrates » | dyslipidémie mixte : statine d'abord ; fibrate en première intention si TG ≥ 5 g/L (HAS, consensus 2016) | `pmt-qc-hypercholesterolemie` |
| 6 | hormones : « transmetteurs synthétisés majoritairement de l'axe hypothalamo-hypophysaire » | l'axe en commande beaucoup, il ne les synthétise pas toutes : la même ronéo fait sécréter l'insuline par les îlots (p. 2) et la parathormone par les parathyroïdes (p. 10) | `pmt-qc-hormones-generalites` |
| 7 | campagnols : « le taux d'ocytocine des campagnols des vallées qui est très élevé » (cours 2023-24 et 2025-26) | à l'examen, vrai ; la référence oppose campagnols des prairies et des montagnes par la distribution des récepteurs de l'ocytocine (Insel et Shapiro, PNAS 1992), plus que par leur ocytocine (Wang et al., J Comp Neurol 1996) | `pmt-qc-ocytocine` |
| 8 | ménopause : « hormones naturelles de substitution sans danger » | le THM augmente le risque de cancer du sein ; plus faible dose, plus courte durée (Vidal, d'après la HAS) | `pmt-qc-hormones-sexuelles` |
| 10 | vitamine D et calcium : « recrutement des ostéoclastes » | le corrigé du QROC 2023/2024 dit « précurseurs des ostéoblastes » ; voir les questions | `pmt-qc-vitamine-d-rankl`, `pmt-an-2324s1-qroc2` |
| 10 | rachitisme : « l'os n'est pas suffisamment remodelé » | un défaut de minéralisation (StatPearls, Osteomalacia ; le cours 2023-24 le disait) | `pmt-qc-maladies-os` |

Sans carte, parce qu'aucune ne la tient :

- « espérance de vie totale à 85 ans (femme meurent un peu plus tard) » (p. 9) :
  85,6 ans est celle des femmes, 80,0 ans celle des hommes (INSEE, Bilan
  démographique 2024), point douteux d'un aparté.

Relus et écartés à la relecture du 19/10 : « 1 % restant dans les cellules »
(p. 9) est juste (environ 1 % du calcium est dans les cellules, 0,1 % dans le
liquide extracellulaire : Guyton et Hall) ; « craniopharyngium » (p. 8) est une
coquille sans conséquence, que les cartes signalent sans ATTENTION.

**Les erreurs du ronéo 2025-26 que la ronéo 2026-27 ne répète pas** ne sont plus
en ATTENTION :

- la CRH confondue avec l'ACTH ;
- la « GnRH : growth hormone releasing hormone » ;
- la « PRL (= Prolactine Releasing Hormone) », devenue PRH ;
- l'anticorps « anti RANK » des ostéoblastes, que la ronéo ne commente plus ;
- l'os « à 95 % de collagène et de fibres élastiques », devenu la matrice à 95 % ;
- l'effet « toujours en U inversé » ;
- les dyslipidémies « primaire (I) … secondaire (II) » ;
- les HDL fixés à l'ApoE ;
- le « troisième œil ».

Les cartes qui portaient ces erreurs disent seulement, quand c'est utile, ce
qu'écrivait le ronéo 2025-26.

## Les clés qui ne sont pas reprises telles quelles

Toutes les clés imprimées des 21 QCM sont reprises telles quelles, et le cours
2026-27 n'en contredit aucune ; **aucun conflit** (`CONFLITS = []`). Les deux
rédactionnelles corrigées gardent leur corrigé (`officielle=True`).

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2021/2022 S1 QROC 2 (antidiabétiques oraux) | « pas de correction » | verso déduit des p. 3-4 et du corrigé de 2022/2023 S2, `officielle=False` | la table ne donne rien |
| 2021/2022 S2 QCROC2 (dyslipidémie) | « pas de correction » | verso déduit de la p. 5, `officielle=False` | idem |
| 2019/2020 S1 QCROC2 (dyslipidémie) | « QROC : pas de correction » | verso déduit de la p. 5, `officielle=False` | idem |
| 2017/2018 S1 QROC2 (métabolisme glucidique) | absente de la table | le corrigé de la même question en 2022/2023 S2, `officielle=False` | la table ne donne que le QCM |
| 2015/2016 S1 QROC2 (métabolisme lipidique) | « pas de correction » | verso déduit de la p. 5, `officielle=False` | idem |
| 2024/2025 S1 Q4 (`pmt-an-2425s1-q4`) | aucune (sujet sans corrigé) | **ABCD**, `officielle=False` | voir ci-dessous |
| 2024/2025 S1 Q5 (`pmt-an-2425s1-q5`) | aucune (sujet sans corrigé) | **ACE**, `officielle=False` | voir ci-dessous |

Les raisons des deux clés déduites :

- **Q4** : isotrétinoïne et œstrogènes, causes de dyslipidémie (p. 6) ; statines
  et « récepteurs Apo E », la formule du professeur (p. 5) ; calcitonine qui
  « bloque les ostéoclastes » (p. 10) ; les glucocorticoïdes activent les
  ostéoclastes (p. 10).
- **Q5** : œstrogènes et bisphosphonates freinent les ostéoclastes (p. 10) ;
  somatotropine, analogue de la GH (p. 8) ; l'acide nicotinique stimule les LPL
  (p. 5) ; gliptines, inhibiteurs de la DPP-4 (p. 4).

Discuté dans la carte, sans changer la clé :

| Question | Le point | À l'examen |
|---|---|---|
| 2023/2024 QROC2 (remodelage) | le corrigé met la vitamine D sur les précurseurs des ostéoblastes ; la ronéo 2026-27 (p. 10), comme les cours d'avant, sur les ostéoclastes (ATTENTION (douteux)) ; `CONFLITS` ne vise que les QCM, le cas est dit ici | le corrigé, en attendant Vincent |
| Thiazidiques (2022/2023 S2 Q4 A, 2021/2022 S1 Q.4 A) | la ronéo 2026-27 ne les cite plus ; FC 2025-26, p. 7 | cause de dyslipidémie, pas de diabète |
| « Agoniste D1 / D2 … Prolacting-releasing Hormone » | formulation de l'examen, gardée ; la diapositive pose le (−) sur le PRF | D1 faux, D2 vrai |
| 2022/2023 S1 Q. 4 C, statines et « récepteurs Apo E » | la formule du professeur ; le récepteur des LDL est le récepteur apo B/E | vrai |
| 2017/2018 S2 Q4 E et Q20 A | la ronéo 2026-27 les rendrait fausses (ézétimibe : prise de notes ; metformine : formule ambiguë, douteux) | vraies, comme la clé |

## Les schémas et les figures

**Huit figures en PNG**, au plus 1000 px de large, en 256 couleurs :

- les sept de la FC 2025-26, plus nettes que leurs reprises, dont la légende cite
  les deux pages : les deux diabètes (tableau 2025-26, p. 2), les
  antidiabétiques (p. 3), le syndrome de Cushing (p. 4), la lipoprotéine
  (p. 4/5), les hypolipémiants (p. 5/6), l'axe hypothalamo-hypophysaire (p. 6/7)
  et le remodelage osseux (p. 10) ;
- **la seule nouvelle** : `pmt-regulation-insuline.png`, la régulation de la
  sécrétion d'insuline (ronéo 2026-27, p. 3, cadrée à 400 dpi). Elle est la
  correction de `pmt-qc-regulation`, `pmt-qc-secretion-insuline`,
  `pmt-qc-insuline` et `pmt-fa-insuline`.

**Un schéma cliquable** (`schemas.py`), avec sa version légendée en correction :

| Fichier | Ce qu'on clique | Pourquoi ce dessin |
|---|---|---|
| `antidiabetiques.svg` | la cible des gliflozines (rein, SGLT2), des sulfonylurées et glinides (canal K⁺-ATP), des analogues du GLP-1 (récepteur du GLP-1), des gliptines (DPP-4), des inhibiteurs des α-glucosidases (bordure en brosse), de la metformine et des glitazones (muscle) — 6 zones | la diapositive de la p. 3 et le corrigé du QROC 2022/2023 S2 ; les organes sont nommés (c'est la carte), les cibles non |

**Deux planches à légender** (figures-images, `scripts/planche_depuis_image.py`,
rectangles dans `donnees.py`). Elles citent désormais la ronéo 2026-27 (p. 5 et
p. 10, la même diapositive) ; les images restent celles de 2025-26, plus nettes.

| Planche | Numéros | Intrus |
|---|---|---|
| `pmt-pl-hypolipemiants` (p. 5) | les cinq médicaments (cadres vidés), l'HMG-CoA réductase, le récepteur LDL, VLDL, LDL, HDL, chylomicrons, les deux lipoprotéines lipases — 13 | glitazones, IDL, lipase hormono-sensible |
| `pmt-pl-remodelage` (p. 10) | les huit médicaments (calcitriol, anti-RANKL, bisphosphonates, calcitonine, œstrogènes et raloxifène, tériparatide, strontium, glucocorticoïdes), les précurseurs, les ostéoclastes, les ostéoblastes — 12 | lévothyroxine, glitazones, ostéocalcine |

L'antisclérostine, nouvelle, n'est pas sur la diapositive : elle n'entre pas dans
la planche.

**85 QCM sur 89 illustrés (96 %).** Sans figure : `pmt-qc-metabolisme`,
`pmt-qc-dyslipidemies` et les deux annales de généralités (2017/2018 S2 Q3,
2015/2016 S1 Q5) ; aucune figure du cours ne montre ce qu'elles demandent.

## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026 ; réalignée le 19/10)

L'échelle du pilote de l'immunité innée, étendue à la BMCT pour l'examen du 4/11.
Sous les annales, on trouve deux sortes de marches :

- **36 cartes Simple** (`niveau-simple`) : une idée, trois choix, le schéma troué
  dans la question ;
- **6 cartes Moyen** (`niveau-moyen`) : une paire à ne pas confondre, le schéma à
  lettres en correction.

Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les
QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `metabolisme-bases` | 5 | 1 | 2 |
| `antidiabetiques` | 10 | 1 | 8 |
| `hypolipemiants` | 11 | 2 | 9 |
| `hormonotherapie` | 4 | 1 | 5 |
| `remodelage-osseux` | 6 | 1 | 6 |

**Le schéma** `ech-metabolisme`, « Les médicaments du métabolisme · qui agit sur
quoi », donne 66 fichiers : complet, troués, à lettres. Il est décrit dans
`schemas.py` (`ECH_METABOLISME`, `TROUS_*`, `LETTRES_*`) et dessiné par
`echelle.py`, copie exacte du modèle du skill. Sa légende cite désormais la ronéo
2026-27 (texte p. 2-10, diapositives p. 3, 5, 6, 10), et la FC 2025-26 pour la
définition et les thiazidiques.

**Le réalignement du 19/10** :

- les 42 marches citent leur page de l'année, sauf `pmt-ech-s1` et `pmt-ech-s29`
  (absentes, `fiche=FC2526`) ; leurs justifications citent la ronéo ;
- la case « Le métabolisme » dit « dans tout le corps » (p. 2) au lieu de
  « cellule, tissu, organe… », pour `pmt-ech-s2`, qui est réécrite d'accord ;
- `pmt-ech-s28` suit la ronéo (« très efficace mais dangereux ») ;
- les ATTENTION des marches prennent leur genre : prise de notes (s12, s25),
  cours (s21, s23, m4), douteux (s10, s11, s24).

Les règles de forme sont gardées :

- les clés Simple restent réparties sur A, B et C ;
- les marches Moyen ont de une à trois vraies ;
- chacune finit par « ↗ Prépare … ».

## Le lexique

Douze termes. Aucun n'existait dans un autre paquet (vérifié contre les `lex-*`
de tous les paquets). Les pages sont mesurées dans le texte de la ronéo 2026-27
(`chercher_pages.py`) :

| Terme | Origine | Pages |
|---|---|---|
| Anabolisme | grec anabolḗ | 2, 3 |
| Catabolisme | grec katabolḗ | 2, 3 |
| Glucocorticoïde | grec glukús + latin cortex + grec eîdos | 4, 10 |
| Biguanide | latin bis + guanide (guano, quechua) | 3 |
| Ostéoclaste | grec ostéon + klastós | 9, 10 |
| Ostéoblaste | grec ostéon + blastós | 9, 10 |
| Ostéomalacie | grec ostéon + malakía | 10 |
| Hypophyse | grec hupóphusis | 6, 7, 8 |
| **Glycosurie** (19/10) | grec glukús + oûron | 4 |
| **Hypercholestérolémie** (19/10) | grec hupér + kholḗ + stereós + haîma | 6 |
| **Ostéocyte** (19/10) | grec ostéon + kútos | 9, 10 |
| **Hydroxyapatite** (19/10) | grec húdōr + oxús + apatân | 9 |

Les racines que la FC de sémantique enseigne la citent ; `-claste` et `-urie`
restent hors FC. Les quatre termes nouveaux et une racine nouvelle,
`apatite (grec)` (ἀπατᾶν, « tromper », TLFi), sont proposés à la table commune
dans `scratchpad/etym/bmct_metabolisme.json`. Les textes du lexique sont déjà
écrits dans la forme que `appliquer_etymologies.py` produirait. Les autres
racines (glyc(o)-, -urie, hyper-, chol(é)-, stér(é)-, -émie, ostéo-, cyt(o)- /
-cyte, hydr(o)-, ox-) reprennent les clés existantes.

## Décisions prises en route

- **`EXAMENS` n'est pas déclaré** (décision de FC1) : le partiel du 4/11 se
  règle dans l'application.
- **Les figures restent celles de 2025-26.** Elles sont identiques à celles de la
  ronéo 2026-27, et souvent plus nettes ; leur source reste la FC 2025-26
  (`SRC["medias"]`), et leur légende cite les deux pages. Les planches citent la
  ronéo 2026-27 à sa page.
- **Une carte confirmée garde ses propositions de 2025-26 quand elles restent
  vraies**, en le disant (« FC 2025-26, p. 4 ») ; une carte dont la notion
  centrale n'est plus au cours passe en `ABSENTS_2026`.
- **Les genres des erreurs répétées d'une année à l'autre**, relus le 19/10
  contre les ronéos 2023-24 (Charonéo), 2024-25 et 2025-26 et la diapositive,
  suivent la règle de la liste des erreurs :
  - prise de notes quand l'image, la même page ou un cours d'une autre année dit
    juste : le stress, l'insuline, Cushing, les lipoprotéines, l'ézétimibe, la
    « Growing Hormone » (le ronéo 2025-26 écrit lui-même « growth hormone »
    pour la GHRH), les « Ostéocytes » de la p. 9 ;
  - le cours lui-même quand les années précédentes disent pareil et que rien ne
    dit juste : la somatostatine et l'amyline, le « gastro-intestinal peptide »
    (2024-25, 2025-26, 2026-27 ; la diapositive ne développe pas), les statines
    et l'ApoE, la nicotine ;
  - douteux quand la formule est ambiguë ou imprécise : la metformine « au
    niveau des alpha-glucosidases » se lit aussi comme la baisse de l'absorption
    intestinale que pose la diapositive et que dit le corrigé ; les chylomicrons ;
    les campagnols.

  La concordance entre les ronéos 2025-26 et 2026-27 ne prouve rien à elle
  seule : la ronéo 2026-27 reprend souvent mot pour mot celle de 2025-26, qu'elle
  cite (p. 9). « Craniopharyngium » est une coquille : sans ATTENTION.
- **La diapositive nouvelle tranche le stress** : son (−) du sympathique α2 sur
  la cellule β est l'image du professeur, qui fait foi sur le texte.
- **Une carte par session** pour les questions répétées ; la copie du polycopié
  de variabilité (le QROC 1 de 2022/2023 S1) reste à FC5.
- **Les numéros de questions** sont ceux du polycopié, ponctuation comprise
  (« Q3 », « Q. 3 », « Q.4 », « QCROC2 »).

## Questions pour Vincent

1. **La vitamine D, sur le recrutement de quelles cellules ?** Deux camps
   s'opposent :
   - la ronéo 2026-27 (p. 10 : « Vitamine D et calcium : agissent au niveau du
     recrutement des ostéoclastes »), le ronéo 2025-26, le cours 2023-24 et la
     flèche de la diapositive disent les ostéoclastes ;
   - le corrigé officiel du QROC 2023/2024 dit les précurseurs des ostéoblastes.

   Le verso du QROC garde le corrigé, avec un ATTENTION (douteux). Aucune
   proposition de QCM ne tranche, et la planche dit les deux lectures. La
   référence place l'action sur la lignée des ostéoclastes, dans les deux sens
   selon la dose (Yasuda, PNAS 1998 ; Li, puis Nakamichi, J Bone Miner Res 2017).
2. **Le résumé du traitement des dyslipidémies** (p. 6) : « hypercholestérolémie
   et triglycérides : fibrates ». La carte le pose comme le cours, avec un
   ATTENTION (douteux) qui donne la stratégie de la HAS (statine d'abord). Faut-il
   le tenir pour la parole du professeur, ATTENTION (cours) ?
3. **Les hormones de la ménopause « sans danger »** (p. 8) : douteux, faute de
   savoir si c'est le professeur ou un raccourci des rédacteurs. Même question.
4. **Les notions que seule la FC 2025-26 portait** (l'os cortical à 80 %, le
   syndrome néphrotique, la vitamine D du sujet âgé, les anti-testostérone du
   cancer de la prostate, « la plus petite dose possible ») ne sont plus que dans
   les explications : faut-il une carte entière `ABSENTS_2026` par thème pour les
   réviser encore ? Aucune annale ne les pose.

## À relire

**Aucune carte `a-relire`** : chaque note cite une page de la ronéo 2026-27 ou de
la FC 2025-26, un corrigé d'annale ou une source sûre (RCP, Vidal, HAS, StatPearls,
Duriez 2003, PNAS 1998, J Bone Miner Res 2017). Reste à Vincent :

- trancher les questions ci-dessus ;
- faire entrer les quatre termes et la racine proposés dans `etymologies.json` ;
- ajouter les erreurs ci-dessus à `contenu/ERRATA_RONEOS_2026-27.md` ;
- lancer `copier_les_cours.py` avec le dossier des ronéos 2026-27, hors du bac à
  sable, pour que la fiche s'ouvre dans l'application.

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```
