# Examen neurologique normal — paquet d'exemple

33 notes, 93 cartes. Deux sources : la fiche de cours et les annales de trois
sessions.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| Texte à trous | 10 | 57 |
| QRM | 14 | 14 |
| Repérage sur schéma | 3 | 16 |
| QROC | 4 | 4 |
| Recto-verso | 2 | 2 |

Sur les 14 QRM, **5 sont des annales** de 2017/2018 à 2023/2024, avec la clé de
correction du polycopié. Plus 8 images : 5 tirées du cours, 3 redessinées.

## Ce que les annales ont dicté

Cinq questions seulement, mais **trois portent sur les réflexes ostéotendineux
et leurs racines**. C'est ce qui a décidé la forme du chapitre : la
correspondance réflexe → racine est révisée dans les deux sens, en cliquant sur
le site de percussion et en écrivant la racine, et un test refuse le paquet si
les deux se contredisent.

| Réflexe | Racine | Réponse |
|---|---|---|
| Bicipital | C5 | flexion de l'avant-bras |
| Stylo-radial | C6 | flexion de l'avant-bras |
| Tricipital | C7 | extension de l'avant-bras |
| Cubito-pronateur | C8 | pronation |
| Rotulien | **L4** | extension de la jambe |
| Achilléen | **S1** | flexion plantaire |

Les deux sessions qui se recoupent se confirment l'une l'autre : le rotulien est
donné faux en L3 en 2019/2020 et vrai en L4 en 2017/2018, l'achilléen faux en L5
et vrai en S1.

## Les trois schémas cliquables

1. **Les sites de percussion** — 6 cartes. Une silhouette en pictogramme, six
   sites. Chaque réflexe se cherche des DEUX côtés ; le schéma les répartit sur
   les deux membres pour qu'ils ne se recouvrent pas, et la légende le dit.
2. **La coupe de moelle** — 4 cartes. Une seule coupe porte tout ce que le
   chapitre demande : les cordons postérieurs (voie lemniscale), le faisceau
   spinothalamique, le faisceau pyramidal et la corne antérieure où siège le
   2e motoneurone.
3. **Les directions du regard** — 6 cartes. L'œil gauche vu de face, six
   directions : c'est le test en H fait au lit du malade. Chaque note donne le
   nerf, et rappelle que le IV et le VI ne commandent qu'un muscle chacun.

## Comment la fiche a été lue

Le cours annonce son propre code couleur dès sa deuxième page :

> « certaines notions seront en gris, cela signifie qu'il ne faut pas les
> retenir car elles concernent la partie pathologique de l'examen »

Rien n'est donc tiré des passages gris : les hypertonies et l'hypotonie, les
réflexes vifs ou abolis, les réponses pathologiques du cutané plantaire. Le
cours écarte aussi de lui-même les troubles végétatifs, les fonctions
supérieures et les mouvements involontaires, « pas abordés cette année ».

## Le gris de ce ronéo : à ne pas retenir

Le ronéo 2026-27 (10/09/2026, Pr Defebvre) définit lui-même son gris en
introduction : « certaines notions seront en gris, cela signifie qu'il ne faut
pas les retenir », parce qu'elles relèvent de la partie pathologique, vue plus
tard. C'est l'exception à la règle générale du gris des ronéos (voir
`.claude/rules/cartes.md`). Sont en gris : trois des dix parties de l'examen
(troubles végétatifs, fonctions supérieures, mouvements involontaires), les
hypertonies élastique et plastique, l'hypotonie cérébelleuse et les réflexes
vifs du syndrome pyramidal (p. 2, 3, 5). Vérifié le 25/09/2026 : aucune carte
ne reposait sur ces passages ; le syndrome pyramidal et le cervelet que les cartes
testent sont aussi dans le texte noir (p. 2, 3, 5, 7).

**Décision de Vincent (26/09) : ce gris n'est pas au partiel, mais reste à
savoir pour les EDN.** Il est donc carté, avec le tag `edn` — le thème « Pour
les EDN (hors partiel) » du chapitre, qui se révise à part : les trois
dernières parties de l'examen (`neu-fa-parties-edn`), les hypertonies élastique
et plastique, la roue dentée, l'hypotonie cérébelleuse et le clonus
(`neu-qc-tonus-edn`, `neu-rv-hypertonies`), les réflexes du syndrome pyramidal
(`neu-fa-reflexes-pyramidaux`). Chaque carte le dit dans son explication.

## Aucune incohérence

Contrairement aux chapitres digestif et sémantique, ce polycopié d'annales ne
pose aucun problème : la numérotation de la table suit celle des énoncés, il y a
autant de clés que de questions, et aucune clé ne contredit le cours. La liste
`CONFLITS` d'`annales.py` est vide, et un test vérifie qu'elle a le droit de
l'être.

### Deux clés déduites du cours

Le corrigé officiel du sujet 2025/2026 ne couvre que 20 de ses 25 questions.
Deux des cinq autres sont de ce chapitre ; leur clé est déduite du cours, la
carte le dit dans son explication et n'est pas marquée officielle.

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2025/2026 QCM 5 | aucune | ADE | Mingazzini, Barré et le testing de 0 à 5 cherchent la force ; Romberg et le funambule, l'équilibre (cours, II.A.3) |
| 2025/2026 QCM 6 | aucune | AD | Réflexes monosynaptiques, cherchés allongé et relâché, symétriques chez le sujet sain |

## Erreurs du ronéo 2026-27

Relevées à la relecture du 28/09/2026 ; le tableau d'erreurs de la promo, vide
pour ce cours jusque-là, relève au 11/10/2026 celle du nerf facial (p. 6), et
les ATTENTION de ses deux cartes le disent. C'est une prise de notes : le
Pr Defebvre donnait en 2025-26 le goût des ⅔ antérieurs au VII et celui du ⅓
postérieur aux nerfs mixtes (FC n°2, p. 7). Ces deux cartes, relues sur le
ronéo de l'année, citent sa p. 6 (`page=6`), comme les quatre cartes `edn` citent
leur page ; les autres cartes du chapitre gardent la FC n°2. Les cours ne seront pas modifiés. Elles sont
aussi dans `contenu/ERRATA_RONEOS_2026-27.md`.

| Page | Imprimé | À lire | Carte |
|---|---|---|---|
| p. 5 | « les nerfs prennent naissance dans le tronc cérébral » | du III au XII seulement : le I et le II émergent du cerveau antérieur (StatPearls) | `neu-qc-nerfs` A, reformulé « du III au XII » (ATTENTION) |
| p. 6 | le VII assure la « sensibilité du tiers postérieur de la langue » — **tableau de la promo, 11/10** | le goût des deux tiers antérieurs (corde du tympan) ; le tiers postérieur, goût et sensibilité, revient au IX (FC n°2 2025-26, p. 7 ; StatPearls, NBK526119) | `neu-qc-nerfs` B, `neu-fa-nerfs-1` (ATTENTION) |

Un point douteux, non carté : « une dysmétrie ou une asymétrie » (p. 5) ; les
signes cérébelleux classiques sont la dysmétrie, l'asynergie et
l'adiadococinésie, et « asymétrie » est sans doute une mauvaise écoute
d'« asynergie ».

## Le corrigé officiel 2023-24

Le sujet de sémiologie générale 2023-24 et son corrigé officiel (une clé par question) sont arrivés le 15/10/2026. Les cartes de cette session venaient du polycopié et en gardent la source ; leur clé est vérifiée :

- 2023/2024 QCM 1 (`neu-an-2324-q1`, BC) : clé confirmée par le corrigé officiel 2023-24, dépôt du 15/10/2026.
- 2023/2024 QCM 2 (`neu-an-2324-q2`, AD) : clé confirmée par le corrigé officiel 2023-24, dépôt du 15/10/2026.


## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026)

L'échelle du pilote de l'immunité innée, étendue à la sémiologie pour l'examen du 4/11 (Vincent, 16/10 : « on continue pour les chapitres que je vais avoir à l'examen »). Sous les annales, 18 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 6 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `motricite` | 4 | 1 | 1 |
| `tonus` | 3 | 1 | 1 |
| `sensibilite` | 4 | 1 | 1 |
| `reflexes` | 7 | 3 | 4 |

**Le schéma** `ech-examen-neuro`, « L'examen neurologique · qui examine quoi », donne 32 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_EXAMEN_NEURO`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Tag `edn`** (passage « pas à retenir ») : `neu-ech-s16`.

## Régénérer

```powershell
python generer.py
```

`generer.py` est la copie du modèle du skill `/nouveau-chapitre`. Il réécrit les
trois schémas SVG puis `paquet.json`, **lexique compris** : les termes vivent
dans `LEXIQUE`, en fin de `donnees.py`. Le script refuse d'écrire s'il trouve :
une proposition sans justification, un trou de plus de deux mots, une zone sans
phrase explicative, deux zones qui se recouvrent, une légende hors du schéma,
une image déclarée mais absente, un thème inconnu, ou une annale non officielle
qui ne dit pas pourquoi.
