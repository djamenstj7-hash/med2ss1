# Agents fongiques : généralités et classification des champignons d'intérêt médical — paquet Parasitologie et mycologie

63 notes, 110 cartes. Chapitre `chap-ue-parasito-fc2` de l'UE Parasitologie et
mycologie (`ue-parasito`), ordre 2. Cours du **Pr Sendid, le 21/10/2025**
(11 h-12 h, semaine 6), « Agents fongiques : généralités et classification des
champignons d'intérêt médical » : FC n°2 du Ronéosaure 2025-26, 9 pages.
**Une annale**, le QROC 5 du sujet 2024/2025 de l'UE (les thalles, sans
corrigé) : c'est d'abord un chapitre de cours. Examen du 5 janvier 2027.

**Une fiche provisoire.** Le ronéo 2026-27 de ce cours n'est pas paru : le
chapitre est carté sur le Ronéosaure 2025-26 (décision de Vincent du 02/10), et
le ronéo de l'année corrigera les cartes à sa parution. La source porte son
année dans son auteur (« Ronéosaure 2025-26 ») : chaque carte de cours prend le
tag `cours-2025-26` et le badge « Cours 2025-26 ». Aucune carte ne dit
« Absent du cours 2026-27 », et les erreurs du Ronéosaure sont dites par un
ATTENTION sans genre (précédent d'`immuno_cmh` et d'`immuno_innee`) : la liste
des erreurs de la promo, `contenu/ERRATA_RONEOS_2026-27.md`, ne concerne que
les ronéos 2026-27.

Le dossier contenait un brouillon laissé par un passage interrompu le 03/10 :
`schemas.py` et dix-sept figures dans `media/`. Tout a été relu contre le PDF :
les figures sont les bonnes, à leur page ; le schéma a été gardé, avec une
phrase ajoutée à la zone « tête aspergillaire ». Le reste a été écrit ici.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 23 | 23 |
| QRU | 1 | 1 |
| Texte à trous | 10 | 52 |
| QROC | 9 | 9 |
| Recto-verso | 8 | 8 |
| Schéma cliquable | 1 | 6 |
| Planche à légender | 1 | 1 |
| Lexique | 10 | 10 |

Dont **1 annale** : 2024/2025 S1 QROC 5 (recto-verso, `annales.py`, créé pour
elle). Les 24 QCM du cours ont une justification par proposition. Toutes les
cartes de cours portent leur page dans la fiche 2025-26 ; aucune n'est
`a-relire`.

Dix thèmes : sept propres au chapitre, dans l'ordre du cours, et trois thèmes
partagés de l'UE (plan C16, §0.5 et §3.1), pour les questions que le
professeur pose en fin de cours sur d'autres chapitres.

| Clé | Libellé |
|---|---|
| `regne-fongique` | Le règne des champignons |
| `levures-filamenteux` | Levures et champignons filamenteux |
| `cellule-fongique` | Cellule fongique, paroi et génome |
| `reproduction-fongique` | Reproduction sexuée et asexuée des champignons |
| `classification-champignons` | Classification des champignons d'intérêt médical |
| `conidiogenese` | Conidiogenèse et identification |
| `types-mycoses` | Principaux types de mycoses |
| `agents-infectieux` | Le monde des agents infectieux (thème de la FC n°1, même libellé) |
| `cycle-parasitaire` | Cycle parasitaire et hôtes (partagé : FC n°1, 4, 6) |
| `diagnostic-biologique` | Diagnostic biologique (partagé dans l'UE) |

Les dix libellés sont à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) ; aucune de ces clés n'existe
ailleurs dans l'application.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-parasito-agents-fongiques` — Ronéosaure, « FC n°2 Agents fongiques généralités et classification des champignons d_intérêt médical » (9 p.), `PARASITO-MYCOLOGIE/…` | **2025-26** | **la base** : chaque note porte sa page ; c'est ce que le lecteur ouvre (`chapitre=`) |
| `src-cours-parasito-agents-fongiques-2425` — Ronéosaure, FC n°2 (AC) - Agents fongiques, Pr Sendid (11 p.) | 2024-25 | appoint, cité dans le texte : asexuée « dans 99 % des cas » (p. 7), le mycélium « carrefour » des deux cycles (p. 8), hyalohyphomycose et phaeohyphomycose « à retenir » (p. 9), la paroi épaisse de la chlamydospore (p. 9), Scopulariopsis pour les annellospores (p. 10) |
| erratas du Ronéosaure : cours 2025-26 (`Erratas de Parasitologie mycologie.docx`) | — | aucune entrée sur la FC n°2 |
| errata des cours 2024-25 (`ERRATAS PARASITO.docx`) | — | deux entrées sur la FC n°2 2024-25, aux passages que le chapitre ne cite pas (voir plus bas) |
| `src-sujets-parasito-2425` — sujets de parasitologie-mycologie 2024/2025, session 1 (examen du 10/01/2025, 14 p.), sans chemin | 2024-25 | la source de l'annale (`SRC["annales"]` et `SRC["sessions"]`) ; **aucun corrigé**, réponse déduite du cours ; déclaration commune aux dix chapitres de l'UE, champ pour champ |

Le polycopié d'annales « 2 - Agents fongiques » du Ronéosaure 2024-25 n'est pas
déclaré : sa seule question va à un autre chapitre (ci-dessous).

Vérifications hors du cours, citées dans la carte qui s'en sert :
- le précis Biomnis « Hydatidose » et ANOFEL, « Échinococcoses » (UMVF 2014,
  p. 8), pour la ponction du kyste hydatique et la fréquence de ses
  localisations ;
- le TLFi, s.v. siphomycète, et Mycology Online (université d'Adélaïde,
  « Hyphomycetes »), pour les champignons inférieurs ;
- pour l'étymologie : le TLFi (lu par l'API de cnrtl.fr), le Wiktionnaire,
  le Bailly et le Gaffiot.

## Ce que le cours a dicté

- **« À RETENIR ++ »** (p. 5) : le thalle distingue levuriformes et filamenteux,
  et « on a soit des levures soit des champignons filamenteux +++ chez les
  malades » — `fon-qc-thalle` A et D, `fon-fa-thalles`, la zone.
- **Le gris** est la voix des rédacteurs (titres, « photo diapo à gauche ») et
  se carte. Le thalle plasmodial des myxomycètes, en gris, est dit « on ne s'en
  occupe pas » (p. 5) : aucune carte, une proposition fausse (`fon-qc-thalle` C).
  Pas de rouge.
- **La classification par les cloisons, puis par la reproduction** (p. 5-7) et
  surtout **par les spores** : « l'important est la manière dont les
  champignons fabriquent leurs spores » (p. 5). D'où le poids de la
  conidiogenèse (neuf cartes) et de l'identification des deutéromycètes (p. 8-9).
- **Les questions du professeur en fin de cours** (p. 9) : une carte chacune,
  qui renvoie au chapitre concerné sans en dupliquer les cartes (plan C16, §2) —
  Cryptococcus neurotrope (`fon-qr-cryptococcus`, FC n°8), le paludisme et
  l'anémie (`fon-qr-paludisme`, FC n°4), l'hémoculture de la candidose invasive
  (`fon-qr-hemoculture`, FC n°8), la toxoplasmose de la femme séronégative
  (`fon-qr-toxo`, FC n°6), le téniasis et la viande crue (`fon-rv-tenia`,
  FC n°3), et le **kyste hydatique**, qui n'est que là (`fon-qc-kyste-hydatique`,
  `fon-qr-hydatique`).

## Les erreurs du Ronéosaure 2025-26

Chacune est dite par **ATTENTION**, sans genre, dans la carte qui porte la
notion.

| Page | Ce que dit le Ronéosaure | Ce qui est juste | Carte |
|---|---|---|---|
| 7 | « comme le cleptocoque » | le cryptocoque, Cryptococcus, que la diapositive de la même page range sous Basidiomycotina | `fon-qc-classification` B, `fon-fa-classification` |
| 3 | Aspergillus : « un filament avec un sporange qui donne une vésicule » | pas de sporange : la vésicule porte des phialides qui font des conidiospores (p. 6, 8) ; le sporange est celui des mucorales (p. 7) | `fon-qc-tete-aspergillaire` C (et la zone « tête aspergillaire ») |
| 5 | champignons inférieurs : « Hyphomycètes, siphomycètes » (déjà dans le cours 2024-25, p. 5 ; peut-être la diapositive elle-même) | la diapositive de la classification (p. 7) n'y met que chytridiomycètes (barrés) et zygomycètes ; les siphomycètes sont les inférieurs, au mycélium « non cloisonné » (TLFi) ; les hyphomycètes sont une classe des deutéromycètes, à filament cloisonné (Mycology Online, Adélaïde) — point douteux pour l'examen | `fon-qc-classification-septa` C ; explication de la planche |
| 4 | aneuploïdie : « au lieu d'avoir 2n chromosomes on va en avoir un seul » (2024-25 : « haploïde ou triploïde ») | gain ou perte d'un ou de quelques chromosomes ; passer de 2n à n ou 3n est un changement de ploïdie | `fon-qc-genome` B |
| 9 | « ne jamais proscrire un kyste sans avoir fait la sérologie » | ne jamais **ponctionner** un kyste hydatique avant le diagnostic : choc anaphylactique, dissémination (Biomnis ; ANOFEL, « Échinococcoses », p. 8) | `fon-qc-kyste-hydatique` D |

Sans ATTENTION, parce qu'aucune réponse n'en dépend :
- p. 7, le sporange des zygomycètes « va contenir des conidies » : ce sont des
  sporangiospores, des endospores — dit dans `fon-qc-zygomycetes` C ;
- p. 6, les ascospores « vont éclore et donner naissance à la diploïdie » : nées
  de la méiose, elles sont haploïdes et germent en mycélium ; non carté ;
- p. 3, un cytoplasme « limité par une paroi appelée syncytium ou septum »
  (formule déjà en 2024-25) : confus, non carté ;
- p. 8, « le filament où il n'y a pas de segments [...] c'est un zygomycète
  siphonné », écrit à côté de la photo de Penicillium : la phrase vise sans
  doute les sporanges de la p. 7 ; non carté ;
- p. 2, « les patients les germent » (gardent) ; p. 4, « relèguent »
  (relarguent) ; p. 9, la cinquième espèce de Plasmodium n'est pas nommée
  (P. knowlesi, FC n°4).

**L'errata 2024-25** (cours 2024-25, non cité aux passages concernés) : il
corrige « comme les zygomycètes » en « comme les basidiomycètes » (p. 33 du
papier), et la version numérique lit maintenant « chez les champignons
microscopiques, comme les Basidiomycètes, il y a des sporangiums » (p. 6) — ce
qui est faux, le sporange étant celui des zygomycètes ; il corrige aussi « on
s'intéresse à la reproduction sexuée » en « asexuée » (p. 34 du papier), que la
version numérique n'a pas repris. Aucune carte ne s'appuie sur ces deux
passages.

## Ce que les annales ont dicté

**2024/2025 S1 QROC 5** : « Citez les principaux thalles qui caractérisent les
champignons d'intérêt médical en donnant des exemples d'espèce. » C'est le
« À RETENIR ++ » de la p. 5 : thalle unicellulaire levuriforme (Candida,
Cryptococcus, Malassezia…), thalle pluricellulaire filamenteux, cloisonné
(Aspergillus, dermatophytes…) ou non (mucorales). Aucune annale précédente ne
les demandait.

Le polycopié « 2 - Agents fongiques : généralités et classification des
champignons d'intérêt médical » (Ronéosaure 2024-25) ne porte qu'une question,
**2022/2023 S1 QROC 5** (lésions et localisations du pityriasis versicolor,
sans correction dans ce polycopié). La même question, pour la même session, est
dans le polycopié « 9 & 10 », avec un corrigé non officiel : elle est cartée une
seule fois, dans « Mycoses superficielles » (plan C16, §3.2 et §4.0).

| Question | Polycopié | Chapitre |
|---|---|---|
| 2022/2023 S1 QROC 5 (pityriasis versicolor) | « 2 - Agents fongiques » = « 9 & 10 » | `parasito_mycoses_superficielles` |

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2024/2025 S1 QROC 5 (thalles et espèces) | aucune (sujet sans corrigé) | levuriforme (Candida, Cryptococcus, Malassezia, Trichosporon, Geotrichum) ; filamenteux cloisonné (Aspergillus, Penicillium, Fusarium, Scedosporium, Alternaria, dermatophytes) ou non cloisonné (mucorales) | réponse déduite du cours (FC n°2 2025-26, p. 2-3, 5 ; dermatophytes filamenteux, FC n°7 2025-26, p. 2) ; le thalle plasmodial, « on ne s'en occupe pas » (p. 5), est dit dans l'explication ; non marquée officielle |

Les questions du cours sont cotées sur la fiche, et ses erreurs sont dites plus
haut.

## Le schéma cliquable et la planche

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `thalles-nus.svg` (`fon-zo-thalles`) | parmi six dessins : la levure bourgeonnante, le filament cloisonné, le filament siphonné, le sporange des mucorales, la tête aspergillaire, le pinceau de Penicillium | 6 |

Le plan prévoyait trois thalles ; le brouillon y a ajouté les trois organes de
la reproduction asexuée, qui se reconnaissent aussi d'un coup d'œil (p. 7-9) :
gardé. Les filaments cloisonné et siphonné ont le même tracé et ne diffèrent
que par les septa, exprès. L'hyphe porteuse de la tête aspergillaire et du
pinceau de Penicillium porte ses septa (ce sont des champignons cloisonnés) ;
celle du sporange n'en a pas. Une zone par case ; le dessin et les zones lisent
les mêmes constantes (`CASES`). La version légendée, `thalles.svg`, est en
correction ; rendue avec ses zones superposées et relue.

**La planche** `fon-pl-classification` : la diapositive « Classification
générale » (p. 7), légendes effacées par `scripts/planche_depuis_image.py` —
huit numéros (Deutéromycètes, Candida, Basidiomycètes, Cryptococcus,
Ascomycètes, Aspergillus, Zygomycètes, Mucor), quatre intrus (Chytridiomycètes,
Hyphomycètes, Dermatophytes, Levures, ceux du plan). Les cadres des quatre
groupes restent, vidés ; « Champignons inférieurs / supérieurs »,
Chytridiomycotina (barré) et Oomycotina restent visibles. Image numérotée et
aperçu de contrôle relus.

**Illustrations** : 22 QCM sur 24 (92 %) portent une figure de la fiche en
correction ; 41 notes sur 63 (l'annale prend les six dessins légendés). Les deux QCM sans figure (`fon-qc-genome`,
`fon-qc-kyste-hydatique`) n'en ont pas dans la fiche.

## Le lexique

Dix termes, aux pages mesurées dans le PDF de la fiche 2025-26 (motif de
`chercher_pages.py`, la page 1 étant le plan) : thalle (1, 2, 3, 5), levure (1,
2, 3, 4, 5, 8, 9), mycélium (3, 5, 7), conidie (3, 5, 7), septum (3, 5),
micromycète (1, 2, 3, 5), hétérotrophe (2), deutéromycète (1, 7, 8),
chlamydospore (8), sporange (3, 5, 7). Aucun n'est accueilli par un autre
chapitre. Chacun dit son origine grecque ou latine, relue sur le TLFi : thalle
par le latin thallus, mycélium par le latin scientifique mycelium (Fries,
1832 ; l'anglais n'est attesté qu'en 1836), hétérotrophe du grec ἑτερότροφος,
« nourri d'une autre façon ». Les racines citent la FC de sémantique quand
elle les enseigne (micr(o)-, hétéro-, angi(o)-). La racine `spor(o)- / -spore`
est proposée sous la même clé et le même texte par `parasito_toxoplasmose`.

Sept racines et dix termes sont nouveaux pour
`.claude/skills/nouveau-chapitre/scripts/etymologies.json` ; ils sont proposés
dans `scratchpad/etym/parasito_agents_fongiques.json` (la table n'est pas
modifiée ici), et le texte de `donnees.py` est déjà celui que
`appliquer_etymologies.py` en tirerait. Clés reprises de la table : `myc(o)-`,
`micr(o)-`, `hétéro-`, `troph(o)-`, `angi(o)-`.

## À relire

Aucune carte ne porte `a-relire` : chacune a été relue contre la page de la
fiche 2025-26 qu'elle cite, et les figures contre leur page ; l'annale
2024/2025 a sa réponse déduite à la page.

## Relecture du 05/10

Une relecture contradictoire a repris chaque carte contre sa page, chaque
figure, le schéma rendu avec ses zones, la planche, les sources et le
lexique. Ce qu'elle a corrigé :
- **hyphomycètes** (`fon-qc-classification-septa` C, planche) : la citation
  « TLFi, s.v. siphomycètes » n'avait pas été relue ; elle l'est maintenant
  (s.v. siphomycète), et Mycology Online appuie la place des hyphomycètes. La
  carte dit aussi que la formule du ronéo vient peut-être de la diapositive.
- **kyste hydatique** (`fon-qc-kyste-hydatique` C, D) : la source ANOFEL porte
  son vrai titre et sa page, et la proposition C, qui met os et cerveau au
  rang du foie, donne la fréquence de chaque localisation.
- **chlamydospores** (`fon-qc-identification` B, `fon-qc-chlamydospores`,
  `lex-chlamydospore`) : d'autres champignons en produisent (dermatophytes,
  cours 2024-25 p. 9-10). La définition du lexique est générale (TLFi), et
  Candida en est la signature devant une levure.
- **Aspergillus** (`fon-qc-aspergillus-cycle` C) : « un même filament » qui se
  différencie en deux polarités est une remarque générale du cours, et non une
  propriété d'A. fumigatus.
- **lexique** : étymologies de thalle, mycélium et hétérotrophe alignées sur
  le TLFi ; levure « le plus souvent » bourgeonnante (Geotrichum fait des
  arthroconidies).
- **schéma** : septa sur l'hyphe porteuse d'Aspergillus et de Penicillium, et
  deux légendes raccourcies, qui touchaient le bord de leur case.

## Questions pour Vincent

1. **L'examen du 5 janvier 2027** (plan C16, question 5) : faut-il le déclarer
   (`EXAMENS`) dans les chapitres des quatre UE de janvier, ou le laisser au
   réglage de l'application, comme jusqu'ici ? Proposition appliquée : non
   déclaré.
2. **Les hyphomycètes** : les ronéos 2025-26 et 2024-25 les rangent parmi les
   champignons inférieurs. Celui de 2023-24 aussi (« Non-septés :
   hyphomycètes, siphomycètes »), lu seulement pour cette question. Trois
   années de suite : c'est sans doute la diapositive du professeur. La
   diapositive de la classification ne le dit pas, et c'est faux : ce sont
   des deutéromycètes à filament cloisonné. La carte suit la diapositive de
   la classification et dit le point douteux ; aucune proposition n'est cotée
   sur ce mot, et « Hyphomycètes » reste un intrus de la planche (plan C16).
   Faut-il coter une proposition, et dans quel sens, et le garder comme
   intrus ?
3. **Les questions du professeur en fin de cours** (p. 9) sont rangées dans
   des thèmes partagés de l'UE (`agents-infectieux`, `cycle-parasitaire`,
   `diagnostic-biologique`, `types-mycoses`) plutôt que dans un thème « questions
   du professeur » : d'accord ?


## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier. Sous les annales, 7 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 2 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `levures-filamenteux` | 7 | 2 | 1 |

**Le schéma** `ech-thalles`, « Les thalles des champignons d'intérêt médical · deux formes chez le malade », donne 10 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_THALLES`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Constantes ajoutées** à `annales.py` (`_SCHEMA_LETTRES`, `_SCHEMA_NU`) : sa seule annale est une QROC, rangée dans `ANNALES_QROC`, et l'intégrateur ne les pose que devant une liste `ANNALES` non vide.

**Sans marche** :
- fon-an-2425s1-qroc5 : la réponse type cite d'autres genres (C. glabrata et les autres Candida, Malassezia, Trichosporon, Geotrichum ; Penicillium, Fusarium, Scedosporium, Alternaria) et les dermatophytes filamenteux, qui relèvent de la FC n°7 : le schéma garde deux exemples de levures et Mucor pour le filament sans septa ; Aspergillus fumigatus, l'exemple du filament à septa, est porté par un distracteur et par la Moyen fon-ech-m2. Le cours ne dit pas, genre par genre, si le filament de Penicillium, de Fusarium, de Scedosporium ou d'Alternaria est cloisonné : aucune marche ne l'affirme.

## Régénérer

```powershell
cd contenu\chapitres\parasito_agents_fongiques
..\..\..\app\.venv\Scripts\python.exe generer.py
```

La planche numérotée se refait depuis `app/` (Pillow n'est pas une dépendance
du projet) :
`uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/parasito_agents_fongiques fon-pl-classification --apercus <brouillon>`.
