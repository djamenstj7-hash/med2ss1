# Les cellules matures du sang et leurs fonctions — paquet d'exemple

39 notes, 73 cartes dans le chapitre, plus la planche à légender, qui vit à part
(1 note, 1 carte). Deuxième chapitre de l'UE **Tissu sanguin**. Là où le premier
cours décrivait la fabrique, celui-ci décrit les produits.

**La base est le ronéo 2026-27** : Ronéo & Juliette, « Les cellules matures du
sang », cours du Dr Duployez du **18/09/2026** (semaine n°2, 9 h-10 h), 10 pages.
Le chapitre avait été carté sur le ronéo FC n°2 du Ronéosaure 2024-25 (13
pages) ; il a été relu note par note contre celui de l'année le 25/09/2026
(tâche C3 de la roadmap). Quelques points se vérifient dans les deux autres
cours du même matin, du même enseignant : cellules souches (8 h-9 h) et
hémogramme (10 h-11 h), cités avec les pages de leur propre ronéo. Aucune des
diapositives transmises le 18/09 ne porte sur ce cours : elles concernent
l'hémogramme.

**Ce chapitre n'a pas de polycopié d'annales.** Les huit fascicules de l'UE
couvrent les FC 1, 3, 5, 6, 7-8, 9, 10 et 11 — pas celui-ci. Toutes les cartes
sortent donc du ronéo.

## Sources

| Source | Ce que c'est | Notes qui y renvoient |
|---|---|---|
| `src-fc-sang-matures` | le ronéo 2026-27, 10 pages | 38 notes, chacune à sa page (`page` dans `donnees.py`) |
| `src-cours-sang-matures` | le ronéo 2024-25, 13 pages | `mat-rv-fœtale` seule, dont le contenu n'est plus dans le cours de l'année |

`generer.py` fait d'une note qui porte `page` une note du ronéo 2026-27, à cette
page ; une note sans `page` garde le ronéo 2024-25. Quand une justification
s'appuie encore sur 2024-25, elle le dit : « d'après le ronéo 2024-25 ».

## Ce qui a changé le 25/09/2026

**Rien n'a été retiré, aucun identifiant n'a changé**, aucun trou n'a été
renuméroté : chaque carte garde ses révisions. Une carte fausse contre le cours
de l'année a été réécrite ; une carte dont le contenu a seulement disparu du
cours a été gardée, et elle est listée plus bas.

Le cours 2026-27 est le même cours, plus court : même enseignant, même plan.
Ce qu'il change aux cartes :

- **Drépanocytose.** Les thalassémies, la transmission, le risque d'un sur
  quatre, l'hémoglobine fœtale et les traitements ont disparu. Arrivent la
  mutation ponctuelle de la β-globine, la polymérisation auto-catalytique et
  quatre régions : Méditerranée, Afrique, Moyen-Orient, Inde.
- **EPO.** « Facteur de croissance », produite surtout par le rein, plus
  rarement par le foie (et les « ostéoclastes », voir les ATTENTION). Le ronéo
  **décrit le mécanisme de HIF** (p. 3), et la consigne de 2024-25 « pas
  besoin de connaître son mécanisme » a disparu ; mais HIF est un facteur de
  transcription, et l'exclusion du détail des facteurs de transcription tient
  en attendant Vincent (voir plus bas). La signalisation passe par
  l'activation (dimérisation) du récepteur, puis JAK2, puis STAT : l'ordre
  inverse de 2024-25 (voir les ATTENTION).
- **Vaquez.** Mutation de JAK2 valine → phénylalanine, adulte de 60-70 ans,
  aspirine en première intention, recherche de JAK2 chez le sujet jeune qui
  thrombose sans facteur de risque. Les saignées, le décès et le prurit ont
  quitté ce cours (le prurit reste, « pas important », dans le cours
  hémogramme).
- **Carences.** La vitamine B6 a disparu. Fer : anémie microcytaire hypochrome,
  ferritine diminuée comme dosage diagnostique. B12/B9 : macrocytaire au-delà
  de 100 fL, **« mégaloblastique »** au-delà de 120 fL — les deux ronéos le
  disent ainsi ; c'est la carte qui parlait de « mégalocytes » —, atteinte de
  la lignée rouge puis pancytopénie (anémie + neutropénie + thrombopénie, dans
  la définition du cours hémogramme, p. 14).
- **PNN.** Mêmes chiffres. Chimiotactisme par l'IL-8, le C5a (nouveau) et le
  LPS ; intégrines CD11b/CD18 ; la nétose n'est plus dite « spécifique ». La
  structure (quatre types de granules) est en deux figures, p. 6 et 8.
- **Autres leucocytes.** L'éosinophile et le basophile ne sont plus « moins
  essentiels » ; l'éosinophile gagne un paragraphe (bref séjour sanguin,
  muqueuses, environ 6 jours, granulations délétères). Le monocyte phagocyte et
  épure les globules rouges sénescents ; « sans granules » a disparu.
- **Plaquettes.** Granulations denses, alpha et lysosomes. L'hémostase
  primaire compte **cinq temps**, la lésion vasculaire en premier ; l'hémostase
  secondaire est nommée.

### Items remplacés

| Carte | Avant | Maintenant | Pourquoi |
|---|---|---|---|
| `mat-qc-drepano` C | « Elle se diagnostique dès la naissance », coté faux | « Elle est due à une mutation ponctuelle du gène de la β-globine », vrai | l'appui de 2024-25 a disparu, et l'item était contestable : le dépistage néonatal la diagnostique à la naissance. C n'est plus inacceptable |
| `mat-qc-autres` C | « Le monocyte possède de nombreuses granulations », faux | « Le monocyte n'est pas un phagocyte », faux | « sans granules » a disparu, et le monocyte a de fines granulations (ATTENTION dans la justification, voir plus bas) ; la phagocytose est au cours (p. 9) |
| `mat-qc-proprietes` E | « La netose est un phénomène spécifique du PNN », vrai | « La nétose est le suicide du PNN… », vrai | « spécifique » a disparu, et d'autres cellules forment des pièges extracellulaires |
| `mat-rv-fœtale`, recto | « …ne se diagnostique-t-elle pas à la naissance ? » | « …ne donne-t-elle pas de signes à la naissance ? » | même raison que `mat-qc-drepano` C |
| `mat-rv-hbs`, verso | polymérisation « IRRÉVERSIBLE » | polymérisation « AUTO-CATALYTIQUE » | le mot du cours 2026-27 ; l'irréversibilité n'y est plus |
| `mat-rv-pancytopenie`, verso | « anémie, leucopénie et thrombopénie » | « anémie, NEUTROPÉNIE et thrombopénie » | la définition du cours hémogramme (p. 14 ; p. 3 : la neutropénie « le plus important ») ; l'ancien verso n'était pas faux, un neutropénique est leucopénique |

Textes à trous réécrits autour des mêmes trous : `mat-fa-vgm`
(« mégaloblastique »), `mat-fa-reserves` (compartiment vasculaire), `mat-fa-hemostase`
(cinq temps), `mat-fa-anomalies` (sans les thalassémies). Toutes les
justifications et explications ont été réécrites contre le ronéo 2026-27, avec
leur page.

### Notes ajoutées

| Note | Ce qu'elle teste | Page |
|---|---|---|
| `mat-fa-hif` | normoxie / dégradé / hypoxie / EPO — le rôle de l'oxygène, sans faire réciter HIF, HIF-1β ni le complexe (question à Vincent) | 3 |
| `mat-fa-vaquez` | mutation acquise, phénylalanine, 60-70 ans, aspirine | 4 |
| `mat-rv-jak2-jeune` | rechercher JAK2 chez le jeune qui thrombose sans facteur de risque | 5 |
| `mat-qr-ferritine` | la ferritine, diminuée, fait le diagnostic de la carence en fer | 5 |
| `mat-fa-chimiotactisme` | IL-8, C5a, LPS, sélectines, CD11b/CD18 | 7 |
| `mat-fa-eosinophile` | muqueuses, 6 jours, helminthes | 8 |
| `mat-fa-plaquette` | récepteurs (thrombine, ADP, thromboxane A2) et granulations (denses, alpha) | 10 |

## Les ATTENTION

Règle de Vincent : un contresens ne se tranche jamais en silence. Les ronéos
2026-27 ne seront pas corrigés (« les cours ne seront pas modifiés ») ; le
tableau d'erreurs de l'UE ne relève dans ce cours, au 19/10/2026, que les PRR
(p. 7) : les erreurs sont portées par les cartes.

| Carte | Le point | Les lectures | Retenu |
|---|---|---|---|
| `mat-qc-pnn` A, `mat-fa-normes`, `mat-qc-autres` D | normes des leucocytes | ce ronéo : PNN 2-7,5, éosinophiles < 0,5, monocytes 0,2-1 G/L (p. 6, 8, 9) ; ronéo hémogramme, **même enseignant, même jour** : 1,5-7, 0-0,4, 0,2-0,8 (p. 3), et normes des éosinophiles et basophiles non exigées (p. 2) — mais monocytose au-delà de 1 G/L (p. 6), comme la borne de ce ronéo, seuil dit « à ne pas retenir » avec la basophilie | le chiffre de ce ronéo, sur chaque carte de ce chapitre |
| `mat-fa-normes` (trou c5), `mat-qc-plaquettes` B | norme haute des plaquettes | ce ronéo : 150-400 G/L (p. 10) ; ronéo hémogramme : thrombopénie < 150 (p. 13), thrombocytose > **450** G/L, « à connaître » (p. 14) | 150-400 sur la carte de ce chapitre ; un seuil de thrombocytose se pose à 450 |
| `mat-qc-pnn` (explication) | le PNN « cellule la plus importante en termes de quantité dans le sang adulte » (p. 6) | les hématies sont la majorité des cellules du sang (cours cellules souches, p. 2), et les plaquettes sont bien plus nombreuses | le plus nombreux des **leucocytes** |
| `mat-qc-epo` A | l'EPO « des ostéoclastes » (p. 3) | la production osseuse décrite est celle des ostéoblastes, chez l'animal | rein essentiellement, foie plus rarement ; aucune carte sur les ostéoclastes |
| `mat-qc-mobilisation` A, `mat-fa-chimiotactisme` | l'IL-8 « facteur de croissance » (p. 7) | c'est une chimiokine | l'item « chimiokines » reste vrai |
| `mat-qc-mobilisation` B, `mat-fa-chimiotactisme` | « LPS : protéine bactérienne » (p. 7) | c'est un lipopolysaccharide | molécule bactérienne, lipopolysaccharide |
| `mat-qc-proprietes` A | le PNN va « reconnaître des PRR » (p. 7) — **tableau de la promo, 19/10/2026** | les PRR sont les récepteurs du PNN, qui reconnaissent les motifs des pathogènes (PAMP ; Takeuchi et Akira, *Cell* 2010) | il phagocyte grâce à ses PRR |
| `mat-qc-autres` E | le monocyte présente « des petites bactéries » (p. 9) | il présente des fragments d'antigènes | cellule présentatrice d'antigène |
| `mat-qc-autres` C, planche n° 2 | les granulations du monocyte | ronéo 2024-25 et note n° 2 de la planche : « SANS granulations » ; en réalité de fines granulations, peu visibles ; le ronéo 2026-27 n'en parle plus | aucune carte ne les teste plus ; la planche, non retouchée, est une question à Vincent |
| planche n° 6 | norme des éosinophiles | la note dit « moins de 0,5 G/L », comme ce ronéo ; le ronéo hémogramme dit 0-0,4 et ne l'exige pas | planche non retouchée ; même règle que les cartes |
| `mat-fa-plaquette`, `mat-qc-plaquettes` (explication) | thrombine, ADP et thromboxane A2 « agonistes primaires » (p. 10) | l'ADP et le TXA2, sécrétés par la plaquette activée, sont souvent dits agonistes secondaires, d'amplification (certitude moyenne) | la carte teste les récepteurs, pas le qualificatif, retiré de son texte |
| `mat-qc-drepano` C, `mat-rv-fœtale` | diagnostic de la drépanocytose à la naissance | ronéo 2024-25 : pas avant l'enfance ; le dépistage néonatal, en France étendu à tous les nouveau-nés fin 2024, la diagnostique à la naissance | l'item C est remplacé ; la carte recto-verso demande les signes, pas le diagnostic |
| `mat-qc-hematie` A | l'hématie passe dans les micro-vaisseaux « sans se casser ni se déformer » (p. 2 ; relevé le 28/09/2026) | elle y passe parce qu'elle se déforme (Mohandas et Gallagher, *Blood* 2008) ; le ronéo la dit lui-même « déformable » | la déformabilité ; l'item ne reprend pas « ni se déformer » |
| aucune carte | « Il peut y avoir de l'hyperéosinophilie si les PNE ciblent les cellules épithéliales, trachéales ou encore endothéliales » (p. 8 ; relevé le 28/09/2026) | la phrase précédente dit l'inverse, et juste : c'est l'excès d'éosinophiles qui, par ses granulations, lèse ces tissus | point douteux, sans doute une cause et une conséquence inversées ; non carté |
| `mat-qc-epo` D, `mat-rv-jak2` | ordre de la signalisation | ronéo 2024-25 : JAK2 puis dimérisation ; ronéo 2026-27, texte et figure : récepteur activé (dimérisation) puis JAK2 (p. 4) | l'ordre de 2026-27 |

## Absent du cours 2026-27

Ces cartes ou ces items sont vrais, mais leur contenu ne se lit plus dans le
ronéo de l'année (ni dans les deux autres cours du 18/09). Ils sont **gardés
tels quels**, et leur justification dit « d'après le ronéo 2024-25 ». À Vincent
de décider s'ils restent, sont suspendus ou réécrits.

| Carte | Ce qui n'est plus au cours |
|---|---|
| `mat-rv-fœtale` (toute la note) | l'hémoglobine fœtale qui masque la drépanocytose ; source restée 2024-25 |
| `mat-qc-drepano` A et E | la transmission autosomique récessive, le risque d'un sur quatre |
| `mat-qc-anomalies` C, `mat-rv-g6pd` | les médicaments qui déclenchent l'hémolyse du déficit en G6PD (2026-27 : « dans certaines conditions ») |
| `mat-qc-anomalies` D | les thalassémies et leur géographie |
| `mat-qc-ferritine` B, C et D | la chronologie ferritine → réserves épuisées → anémie, et la surveillance de la ferritine en fin de traitement |
| `mat-qc-proprietes` B | le lieu de l'explosion respiratoire, le phagolysosome |
| `mat-qc-epo` E | l'exemple de l'insuffisance rénale (l'item reste faux par ce que le cours dit du rein) |
| `mat-qc-hematie` B | le centre plus clair du disque au frottis |
| `mat-rv-granulomatose` | le nom de la NADPH oxydase (2026-27 : « le complexe enzymatique qui produit » les ROS) |
| `mat-rv-macrophage` | le mot « macrophage » (la plasticité fonctionnelle, elle, est au cours) |
| `mat-rv-flipflop` | le mot « flip-flop » (les phosphatidylsérines et la bicouche asymétrique sont au cours) |

La planche n'a pas été touchée à cette relecture (consigne), et plusieurs de ses
notes sont dans le même cas : « 55 à 70 % des leucocytes » (numéro 1 — le cours
hémogramme dit qu'on n'interprète pas les pourcentages, p. 3), « il devient
macrophage » (numéro 2), des granulations « très sombres [qui] masquent le
noyau » (numéro 5), un noyau « typiquement bilobé » (numéro 6). Le monocyte
« SANS granulations » (numéro 2) n'est pas seulement absent : il est contredit,
et il figure dans les ATTENTION. L'hématie « 45 % du volume sanguin » (numéro
4), elle, est bien au cours de l'année : la figure de centrifugation du ronéo
cellules souches 2026-27 imprime « globules rouges 45 % » (p. 2).

## Ce que le cours demande, et ce qu'il écarte

| Le ronéo 2024-25 disait | Le ronéo 2026-27 | Ce que fait le paquet |
|---|---|---|
| « pas besoin de connaître son mécanisme [HIF] » | le mécanisme est décrit (p. 3), la consigne a disparu | `mat-fa-hif` teste le rôle de l'oxygène, sans faire réciter HIF, HIF-1β ni le complexe ; l'exclusion des facteurs de transcription tient en attendant Vincent (voir plus bas) |
| structure du PNN : diaporama passé en cours | deux figures (p. 6 et 8) et une phrase | aucune carte : les figures n'ont pas été lues |
| éosinophile et basophile « moins essentiels que le PNN » | la mention a disparu | `mat-fa-eosinophile` ajoutée |
| lymphocytes « peu traités ici » | « vue en cours d'immunologie » (p. 2) | laissés à l'immunologie |

Les deux exclusions posées par Vincent pour l'UE tiennent : aucune carte ne
nomme ni n'ordonne un stade intermédiaire d'une lignée, et le détail des
facteurs de transcription reste hors programme. HIF en est un, et le ronéo
2026-27 décrit son mécanisme sans plus l'écarter : la question est posée à
Vincent, et d'ici là rien n'est tranché. `mat-fa-hif` nomme HIF dans son texte,
hors trou, et ne teste que l'oxygène (normoxie, dégradé, hypoxie, EPO) ; la
dimérisation avec HIF-1β n'est plus que dans son explication. S'il veut
l'interroger, un trou s'ajoute ; s'il écarte HIF entièrement, la carte se
suspend. C'est une note nouvelle : jamais importée, elle ne porte encore aucune
révision.

## Les chiffres que le chapitre carte

| | |
|---|---|
| Hématie | 120 jours |
| PNN | 2 à 7,5 G/L (hémogramme : 1,5-7) · 10-14 µm · 1 à 3 jours dans le sang |
| Éosinophiles | < 0,5 G/L (hémogramme : 0-0,4) · 10-15 µm · environ 6 jours |
| Basophiles | < 0,1 G/L — les plus rares · 11-13 µm |
| Monocytes | 0,2 à 1 G/L (hémogramme : 0,2-0,8, mais monocytose > 1, « à ne pas retenir ») · 20-25 µm, la plus grande cellule du sang |
| Plaquettes | 150 à 400 G/L (hémogramme : thrombopénie < 150, thrombocytose > 450) · 2-4 µm · 7 jours |
| VGM | microcytaire < 80 fL · macrocytaire > 100 · mégaloblastique > 120 |

L'hémoglobine varie avec l'âge **et le sexe** (cours hémogramme, p. 9), les
leucocytes avec l'âge (p. 6), et les **plaquettes ne varient ni avec l'un ni
avec l'autre** (p. 10).

## Illustrations, à faire

Aucun des douze QCM ne porte d'illustration, et le hook le rappelle à chaque
écriture. Les figures du ronéo ne se distribuent pas, et ce générateur n'écrit
aucun média dans le paquet du chapitre : des schémas redessinés (signalisation
EPO → JAK2 → STAT, cinq temps de l'hémostase primaire, mobilisation du PNN,
échelle du VGM) viendront avec le passage au générateur modèle, dernier point de
la tâche C3.

## La planche à légender

**Elle vit à part, dans `contenu/planches/sang_matures/`, et ne part jamais.**
Ses deux images sont tirées d'un ronéo, qui appartient à son cours.
`generer.py` écrit donc deux paquets : ici le chapitre, versionné et livré aux
collègues ; là-bas la planche seule, avec ses images. **Ni les images ni ce
second paquet ne sont versionnés** (`.gitignore` : `contenu/planches/*/media/`
et `contenu/planches/*/paquet.json`) ; ils n'existent que sur la machine où
`contenu/planches/sang_matures/images.py` les a fabriqués. Sans ces images, le
générateur écrit le chapitre et dit que la planche est sautée.

La figure est le frottis schématique de la **p. 2 du ronéo FC n°1 2024-25**
(cellules souches), pas celle de ce ronéo : sept éléments figurés du sang, avec
leurs traits de rappel et **leurs légendes imprimées**. Les lire n'est pas les
savoir, donc `images.py` les efface :

- il détecte les sept blocs de texte — le texte est noir, les cellules et les
  traits sont colorés ;
- il les couvre de blanc avec trois pixels de marge, parce qu'un jambage qui
  dépasse suffit à vendre la réponse ;
- il pose une pastille numérotée **à l'endroit exact où la légende se trouvait**,
  donc au départ de son trait de rappel ;
- il agrandit deux fois, sans quoi les pastilles seraient illisibles dans une
  colonne de six cents pixels.

**Ce n'est pas une automatisation.** Les rectangles ont été relus un par un
contre la planche affichée, et le nom associé à chaque numéro a été lu à l'œil
sur la planche d'origine — jamais déduit d'une position. Si le ronéo change de
version, `images.py` refuse de travailler : la figure n'aurait plus la même
taille (767 × 375 attendu), et les rectangles couvriraient le mauvais endroit.
C'est le cas du ronéo cellules souches 2026-27 : il porte le même frottis en
p. 2, mais à une autre taille. Refaire la planche demande donc le ronéo
2024-25.

Deux fichiers, jamais un seul : `planche-cellules-sang.png` est la question,
`planche-cellules-sang-legendee.png` la correction.

La liste offerte compte **douze entrées pour sept numéros**. Les cinq intrus —
mégacaryocyte, réticulocyte, plasmocyte, macrophage, érythroblaste — sont des
cellules qui ne circulent pas dans un sang normal, et sans eux le dernier numéro
se déduirait par élimination.

## Refabriquer

Depuis ce dossier :

```
..\..\..\app\.venv\Scripts\python.exe generer.py
```

Pour refaire les deux images de la planche, depuis `contenu/planches/sang_matures/`,
avec le ronéo FC n°1 2024-25 :

```
python -m venv venvimg
venvimg/Scripts/pip install pillow
venvimg/Scripts/python images.py <chemin du ronéo FC n°1 2024-25>
```

Pillow n'est pas une dépendance du projet et ne doit pas le devenir.
