# Analyses de survie — paquet Biomédecine quantitative

45 notes, 77 cartes. Chapitre `chap-ue-biomed-quanti-fc14` de l'UE
Biomédecine quantitative, douzième de l'UE. Cours du **Pr G. Ficheur, le
03/12/2025, de 9 h 15 à 9 h 30** — le dernier quart d'heure du cours de
régression logistique —, dans le **Ronéosaure 2025-26** (FC n°12, 3 pages) ;
les annales du polycopié « 14 - Analyses de survie » du Ronéosaure 2024-25
(onze questions, sept sessions). Examen : partiel du mercredi 16 décembre 2026.

**Fiche provisoire** (C15, décision de Vincent du 02/10) : le cours de l'année
2026-27 n'est pas encore paru. Chaque carte de cours cite sa source à sa page,
et l'application montre « Cours 2025-26 » (ou « Cours 2023-24 » pour les sept
cartes bâties sur le cours ancien) ; le ronéo 2026-27 corrigera les cartes
quand il sortira. Aucune carte n'est « Absent du cours 2026-27 ».

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 20 | 20 |
| QRU | 2 | 2 |
| Texte à trous | 7 | 33 |
| QROC | 5 | 5 |
| Recto-verso | 4 | 4 |
| Schéma cliquable | 2 | 8 |
| Lexique | 5 | 5 |

Dont **11 annales** (QRM) sur 7 sessions, de 2019/2020 S1 à 2022/2023 S1, et
11 QCM de cours (9 QRM, 2 QRU), chacun avec une justification par proposition.

Sept thèmes. `hors-fiche` (sémiologie) existe et son libellé dit vrai ici ; les
six autres clés sont nouvelles, et leurs libellés restent à ajouter à
`THEME_LABELS` (`app/src/med_engine/application/scopes.py`). Quatre sont
partagées avec d'autres chapitres de l'UE, sous le même libellé (plan C15, 0.6).

| Clé | Libellé | Notes | Partagée avec |
|---|---|---|---|
| `kaplan-meier` | Kaplan-Meier et censure | 14 | `biostat_analyse_descriptive` |
| `critere-jugement` | Critère de jugement principal | 2 | `biostat_phase_3` |
| `cox` | Modèle de Cox | 10 | — |
| `risque-instantane` | Risque instantané et proportionnalité | 7 | — |
| `multivarie` | Analyses multivariées | 2 | `biostat_scores`, `biostat_regression_logistique` |
| `rr-or` | Risque relatif, odds ratio, hazard ratio | 5 | `biostat_pharmacovigilance`, `biostat_regression_logistique` |
| `hors-fiche` *(existante, tag en plus du thème)* | Tombé en annales, absent de la fiche | 15 | sémiologie, `biostat_regression_lineaire` |

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-biomed-srv-2526` — Ronéosaure, « FC n°12 - Analyses de survie » (3 p.) | **2025-26** | **la base** ; `SRC["fiche"]` (`chapitre=`), c'est ce que le lecteur ouvre ; 5 figures extraites |
| `src-fc-biomed-dsc-2526` — Ronéosaure, « FC n°7 Analyse descriptive » (7 p.) | 2025-26 | la fiche du chapitre `biostat_analyse_descriptive`, déclarée avec son identifiant (`chapitre=chap-ue-biomed-quanti-fc1`) : la censure non informative (p. 4), les pages du lexique (p. 4-5) |
| `src-fc-biomed-ec3b-2526` — Ronéosaure, « FC n°6 partie 2 … phase 3 » (10 p.) | 2025-26 | la fiche de `biostat_phase_3` (`chapitre=chap-ue-biomed-quanti-fc9`) : la notion d'analyse de survie, S(t) et le hazard (p. 3, une diapositive extraite), l'exponentielle du calcul du nombre de sujets (p. 4) ; une carte la cite (`fiche=`) |
| `src-fc-biomed-srv-2425` — Ronéosaure, « FC n°14-analyse de survie » (5 p.) | 2024-25 | le cours de l'an passé du même professeur : la lecture du HR (p. 3-4), la durée de survie qu'il ne mesure pas (p. 4), la censure aléatoire (p. 2), la linéarité (p. 5) ; cité dans le texte |
| `src-fc-biomed-srv-2324` — « 14. Biomédecine quantitative - Analyse de survie », Charonéo (4 p.) | 2023-24 | le cours d'il y a deux ans du même professeur, plus complet : censure à droite (p. 2), HR = exp(β) et ses puissances (p. 4), conditions du modèle (p. 4) ; deux diapositives extraites ; sept cartes le citent (`fiche=`) |
| `src-annales-14-analyses-de-survie` — « 14 - Analyses de survie » (13 p.) | 2024-25 | les onze questions et leur table de corrections (p. 13) ; déclarée selon la règle commune de C15 (id tiré du nom du fichier, cinq champs) |

**Alignées avec les chapitres voisins** : les déclarations de la FC n°7 et de
la FC n°6 partie 2 sont, champ pour champ, celles de `biostat_analyse_descriptive`
et de `biostat_phase_3`, écrits dans la même vague (relues le 02/10) ; celle du
polycopié d'annales est celle de `biostat_scores` et de
`biostat_regression_logistique`. Si l'un de ces chapitres change sa
déclaration, la recopier ici : sinon l'import du dernier paquet l'emporte (rien
ne casse, mais le titre ou la note changent selon l'ordre d'import).

La FC n°11 2025-26 (régression logistique, `src-fc-biomed-rlg-2526`) est citée
dans le texte de plusieurs justifications (âge et sexe parmi les facteurs
d'ajustement et cas-témoins p. 6, k − 1 binaires p. 2, dix événements par
variable p. 11), sans être déclarée : c'est la fiche d'un autre chapitre, que
le plan ne demande pas de déclarer ici.

## Ce que le cours a dicté

La FC n°12 tient en trois pages et deux parties ; tout y a sa carte.

| Partie | Pages | Cartes |
|---|---|---|
| I Estimateur de Kaplan-Meier : probabilités conditionnelles, censure retirée du dénominateur, non paramétrique, cohorte de 20 ans, l'événement précoce « pèse » plus, cancérologie, trois apports, 100 % au départ, marches, HDL élevé contre bas, deux raisons de quitter les à-risque, exclus vivants, ronds ou traits, marche plus grande après une censure | 2-3 | `srv-fa-km-principe`, `srv-fa-a-risque`, `srv-fa-trois-apports`, `srv-qc-km`, `srv-qc-censure`, `srv-qc-pourquoi-survie`, `srv-qc-hdl`, `srv-qr-non-parametrique`, `srv-qr-censure`, `srv-rv-exclu-perdu`, `srv-zo-suivi` |
| II Modèle de Cox : ce qui modélise les données de KM, variables explicatives, risque instantané (rouge), diapositive des modèles multivariés, diapositive de David Cox | 3 | `srv-fa-cox`, `srv-fa-modeles`, `srv-qc-cox`, `srv-qc-choix-modele`, `srv-qr-risque-instantane`, `srv-rv-km-cox` |
| II.A Risque instantané de décès (gris) | 3 | `srv-qc-risque-instantane`, `srv-rv-survie-risque` |
| II.B Proportionnalité des risques (rouge) : avant Cox, le paramétrique ; une seule hypothèse ; comme la régression logistique | 3 | `srv-qc-proportionnalite`, `srv-qr-proportionnalite`, `srv-zo-risques` |

**Le rouge** (titres, « durée », « courbe rouge », « risque instantané de
décès », « proportionnalité des risques ») a chacun sa carte. **Le gris** est
la voix des rédacteurs et se carte (décision du 25/09) : le renvoi au cours du
17/11 (p. 2) dit seulement que la méthode a été vue avec l'analyse
descriptive ; le paragraphe sur le risque instantané (p. 3) finit par « il faut
savoir que c'est ça qui est modélisé, mais pas à quoi cela correspond » — la
définition est cartée quand même, parce que les annales la demandent (h(t),
quatre questions), et la carte cite la phrase.

**Ce que la FC n°12 ne dit pas et que les annales demandent** : le hazard
ratio comme exponentielle du coefficient et sa lecture (« à chaque instant… »,
puissance pour plusieurs unités, IC), la log-linéarité, la censure aléatoire,
la survie exponentielle. Ces cartes s'appuient sur les cours 2023-24 et 2024-25
du même professeur, sur la FC n°7 (censure non informative) et la FC n°11 (dix
événements par variable, en distracteur), ou sur une référence citée, et portent le tag
`hors-fiche` : `srv-fa-hazard-ratio`, `srv-fa-conditions`, `srv-qc-hazard-ratio`,
`srv-qc-hr-ic`, `srv-qc-conditions`, `srv-qr-hazard-ratio`, `srv-rv-hr-or`,
`srv-zo-risques`, et sept annales.

**Les frontières** (plan C15) : la construction et la lecture de la courbe de
Kaplan-Meier, la censure informative et la survie médiane (« QCM +++ ») se
cartent avec la FC n°7 (`biostat_analyse_descriptive`) ; la survie comme
critère de jugement d'un essai de phase III et le nombre de sujets, avec la FC
n°6 (`biostat_phase_3`) ; les modèles multivariés en général et l'odds ratio,
avec la FC n°11 (`biostat_regression_logistique`). Ce chapitre carte ce que la
FC n°12 ajoute : les probabilités conditionnelles, la marche plus grande après
une censure, le modèle de Cox, le risque instantané, la proportionnalité et le
hazard ratio.

## Les erreurs du ronéo 2025-26

Aucune qui change une carte (plan C15). Un mot qui pourrait tromper est dit là
où il se joue, sans ATTENTION : « exclus vivants » (p. 3) désigne les
participants arrivés à la fin de l'étude sans événement, **censurés** à la fin
du suivi, et non retirés de l'analyse (`srv-qc-censure` B, `srv-rv-exclu-perdu`,
zone `exclu` de `srv-zo-suivi`). Le ronéo 2023-24 écrit que la log-linéarité
relie X « au logarithme de Y » : la carte `srv-fa-conditions` dit « au
logarithme du risque instantané », ce que le modèle rend linéaire en X.

L'erreur de la FC n°6 partie 2, p. 4 (« la méthode de Kaplan-Meier est très
astucieuse car ce modèle de Cox ne fait pas d'hypothèse sur l'allure de la
courbe ») se signale dans `biostat_phase_3`, où elle se joue ; ici,
`srv-qc-proportionnalite` dit le fait juste : c'est Kaplan-Meier qui ne suppose
rien, Cox suppose la proportionnalité des risques.

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| La censure n'exclut personne (« censurés exclus de l'analyse », « délais trop faibles ou trop importants ») | 5 |
| Kaplan-Meier estime S(t) sans modèle mathématique ; h(t) est ce que modélise Cox | 5 |
| L'hypothèse des risques proportionnels (fonction de risque proportionnelle, HR constant) | 4 |
| Le modèle de Cox : variables de tous types, ajustement, h(t), coefficients ≠ HR, puissance | 2 |
| Lire un tableau de hazard ratios (HR < 1, IC qui contient 1, puissance de 1,5) | 3 |
| Cohortes et cas-témoins, survie sans censure, censure non aléatoire, log-linéarité, survie exponentielle | 2021/2022 S1 Q29, 2019/2020 S1 Q16 et Q17, et la proposition E de la question posée trois fois (2022/2023 S1 Q20, 2020/2021 S1 Q30, 2019/2020 S2 Q30) |

## Les annales, une par une

| Session | N° | Imprimée | Retenue | Thème | Carte | Remarque |
|---|---|---|---|---|---|---|
| 2022/2023 S1 | Q20 | ABDE | ABDE | `kaplan-meier` | `srv-an-2223s1-q20` | même énoncé en 2020/2021 S1 Q30 et 2019/2020 S2 Q30 |
| 2021/2022 S1 | Q29 | BE | **B** | `kaplan-meier` | `srv-an-2122s1-q29` | CONFLIT sur E (cas-témoins) ; `officielle=False` |
| 2021/2022 S1 | Q30 | BCE | BCE | `cox` | `srv-an-2122s1-q30` | « 1,210 » rétabli en 1,2¹⁰ ; hors fiche |
| 2021/2022 S2 | Q25 | BE | BE | `cox` | `srv-an-2122s2-q25` | tableau des HR en image d'énoncé ; hors fiche |
| 2021/2022 S2 | Q35 | BCE | BCE | `cox` | `srv-an-2122s2-q35` | même énoncé que 2021/2022 S1 Q30 ; reprise dans le polycopié A15 ; hors fiche |
| 2020/2021 S1 | Q30 | ABDE | ABDE | `kaplan-meier` | `srv-an-2021s1-q30` | trois coquilles d'espacement corrigées |
| 2020/2021 S2 | Q30 | BE | BE | `cox` | `srv-an-2021s2-q30` | tableau des HR ; hors fiche |
| 2019/2020 S1 | Q16 | B | B | `kaplan-meier` | `srv-an-1920s1-q16` | survie exponentielle (Gompertz) ; hors fiche |
| 2019/2020 S1 | Q17 | ABDE | ABDE | `cox` | `srv-an-1920s1-q17` | log-linéarité, censure non aléatoire ; deux coquilles corrigées ; hors fiche |
| 2019/2020 S2 | Q30 | ABDE | ABDE | `kaplan-meier` | `srv-an-1920s2-q30` | |
| 2019/2020 S2 | Q31 | BE | BE | `cox` | `srv-an-1920s2-q31` | tableau des HR ; hors fiche |

Non cartées ici : sept entrées des colonnes « 2018/2019 » (clés recopiées de
2020/2021, sans énoncé) ; dix-sept questions de méthodes ou de modèles
multivariés, aux chapitres des scores et de la régression logistique, ou déjà
cartées sous un autre polycopié (plan C15, section 14).

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2021/2022 S1 Q29 (`srv-an-2122s1-q29`) | BE | **B** | E, « le modèle de Cox est fréquemment utilisé car c'est le seul modèle valide dans les études cas-témoin », est fausse : une étude cas-témoins se modélise par la régression logistique et ne rend que des odds ratios (FC n°11 2025-26, p. 6) ; Cox est le modèle des données de survie, typiquement d'une cohorte (FC n°12, p. 2 ; 2022/2023 S1 Q20 E, vraie). ATTENTION dans la justification de E, `CONFLITS`, `officielle=False`. |

Deux rétablissements d'impression, sans changer la clé : « 1,210 » se lit
1,2¹⁰ (2021/2022 S1 Q30 E et S2 Q35 E), dit dans la justification de E ; les
coquilles d'espacement de 2020/2021 S1 Q30 et 2019/2020 S1 Q17, dites dans
l'explication.

## Les schémas et les figures

| Fichier | Ce qu'on clique | Cartes | Pourquoi ce dessin |
|---|---|---|---|
| `suivi-etude.svg` (+ `-legende`) | le décès, le délai jusqu'au décès, la censure de l'exclu vivant, celle du perdu de vue | `srv-zo-suivi` (4) | le schéma « Durée de l'étude » de la p. 2, redessiné nu : rien n'y dit « décès » ni « censure » ; reconnaître les deux censures est la question |
| `risques-instantanes.svg` (+ `-legende`) | risques proportionnels, risques qui se croisent, risque constant (survie exponentielle), risque croissant (mortalité humaine) | `srv-zo-risques` (4) | la diapositive « L'idée de David Cox » (p. 3) montre des h(t) dans un rapport constant ; le croisement vient du cours 2023-24 (p. 4), les deux panneaux du bas de l'annale 2019/2020 S1 Q16 E |

Les figures, en correction sauf deux, qui sont la question elle-même (le
tableau des HR des annales, et les courbes du HDL de `srv-qc-hdl`, dont deux
propositions se jugent en les lisant ; ni l'une ni l'autre ne porte de légende
qui vende la réponse) :

| Fichier | Source | Page |
|---|---|---|
| `srv-duree-etude.png` | FC n°12 2025-26 | 2 |
| `srv-km-exemple.png` | FC n°12 2025-26 | 2 |
| `srv-km-hdl.png` | FC n°12 2025-26 (agrandie ×2), **image d'énoncé** de `srv-qc-hdl` (`illustration_question`) | 2 |
| `srv-modeles-multivaries.png` | FC n°12 2025-26 (agrandie ×2,4) | 3 |
| `srv-idee-cox.png` | FC n°12 2025-26 (agrandie ×2,4 ; porte la photographie de David Cox, statisticien) | 3 |
| `srv-notion-survie.png` | FC n°6 partie 2 2025-26 | 3 |
| `srv-censure-droite.png` | cours 2023-24 | 2 |
| `srv-cox-coefficients.png` | cours 2023-24 | 4 |
| `srv-an-tableau-hr.png` | polycopié d'annales A14 (agrandi), **image d'énoncé** : elle est la question des trois sessions qui la posent (`illustration_question`) | 6 |

Les diapositives de la p. 3 de la FC n°12 sont imprimées petites (310 × 229
px) : elles sont rendues agrandies depuis le PDF, sans rien y ajouter.

**QCM illustrés : 22 sur 22.** Tous les QCM, annales comprises, ont une figure
du côté de la réponse.

## Le lexique

Cinq termes, ceux du plan C15, aucun déjà présent dans un autre paquet :

| Terme | Pages | Racines |
|---|---|---|
| Censure | FC n°12 p. 2, 3 ; FC n°7 p. 4, 5 | censere (latin) |
| Paramétrique | FC n°12 p. 2, 3 ; FC n°7 p. 4, 5 | para- (grec), -métrie |
| Proportionnalité | FC n°12 p. 3 | portio (latin) |
| Instantané | FC n°12 p. 3 | in- (latin, dans), stare (latin) |
| Cancérologie | FC n°12 p. 2 ; FC n°6 partie 2 p. 3 | cancér(o)-, -logie (FC de sémantique 1, p. 5) |

Pages mesurées dans le texte des PDF (la page de plan exclue), selon les règles
de `chercher_pages.py`. Chaque définition finit par son étymologie et chaque
racine dit la sienne ; les racines `para- (grec)`, `-métrie`, `in- (latin,
dans)` et `-logie, de logos (grec)` sont reprises de la table, avec leurs clés ;
`censere (latin)`, `portio (latin)`, `stare (latin)` et `cancér(o)-`, et les
cinq termes, sont proposés dans `scratchpad/etym/biostat_survie.json`
(Wiktionnaire, Gaffiot) pour être versés dans `etymologies.json`. `portio
(latin)` y est identique à la proposition de `biostat_phase_4_eim`
(Disproportionnalité). La racine `pro- (latin)` n'est pas reprise :
`genet_sequencage` et `info_reutilisation` la proposent avec le sens
« devant, en avant » (FC de sémantique 2/2, p. 10), qui ne vaut pas pour
*proportio* ; le terme ne garde que `portio`, et sa définition dit
*pro- + portio*.

## Décisions prises en route

- **Le hazard ratio se carte ici, hors fiche.** La FC 2025-26 ne fait que le
  nommer (« coefficient multiplicateur de h(t) ») ; sept annales sur onze le
  lisent. Les cartes s'appuient sur les cours 2023-24 et 2024-25 du même
  professeur, et portent `hors-fiche`.
- **Le risque instantané se définit, malgré le gris** : la phrase du ronéo (« il
  faut savoir que c'est ça qui est modélisé ») est citée sur la carte.
- **Le calcul de Kaplan-Meier sur cinq patients** (p. 2) n'est pas carté ici :
  c'est la construction de la courbe, que le plan C15 donne à la FC n°7, et
  `biostat_analyse_descriptive` le carte déjà sur le même exemple
  (`dsc-qr-km-calcul`, `dsc-qc-km-lecture`). Ce chapitre garde ce que la
  FC n°12 ajoute : les probabilités conditionnelles (`srv-fa-km-principe`,
  `srv-qc-km`) et la marche plus grande après une censure (`srv-fa-a-risque`,
  `srv-qc-censure` E). Les deux cartes de calcul de la première écriture
  (`srv-fa-km-exemple`, `srv-qc-km-calcul`) ont été retirées à la relecture,
  avant tout import.
- **Le thème `critere-jugement`** porte les deux cartes sur l'intérêt du délai
  (la cancérologie, les trois apports de la p. 2) ; la survie globale comme
  critère d'un essai de phase III reste à `biostat_phase_3`.
- **Les dix événements par variable** sont la règle de la FC n°11 (p. 11),
  cartée par `biostat_regression_logistique` (`rlg-qr-dix-evenements`,
  `rlg-fa-evenements`, qui disent déjà « même logique pour un modèle de
  Cox »). La QROC `srv-qr-dix-evenements` de la première écriture la
  doublait, et citait la FC n°12 sans page pour une phrase qui n'y est pas :
  retirée à la relecture. La règle reste ici en distracteur
  (`srv-qc-conditions` E, 2021/2022 S1 Q29 D).

## Relecture (02/10)

Chaque carte relue contre la page qu'elle cite, chaque clé contre la table
(p. 13), l'errata des annales 2024-25 (rien sur ce polycopié) et l'errata
2025-26 (rien sur la FC n°12). Corrigé à la relecture :

- trois cartes retirées parce qu'un autre chapitre les porte déjà (voir
  « Décisions prises en route ») : `srv-fa-km-exemple`, `srv-qc-km-calcul`,
  `srv-qr-dix-evenements` ;
- `srv-fa-conditions` annonçait « deux conditions » et en listait trois : la
  censure non informative est maintenant dite à part, commune à Kaplan-Meier ;
- « des courbes qui se croisent » (`srv-fa-conditions`, `srv-qc-conditions` A,
  zone `croises`) : le cours 2023-24 parle des **courbes de survie** ; la
  carte le dit, et la zone distingue le croisement des risques dessinés de
  celui des courbes de survie ;
- `srv-fa-hazard-ratio` : le trou « 10 » se lisait dans « 1,03¹⁰ » écrit juste
  après ; le trou porte maintenant le résultat, 1,34 ;
- lexique : la racine `in- (latin, dans)` dit « dans, en », comme dans les
  autres chapitres ; `pro- (latin)` retirée (voir « Le lexique »).

Seconde relecture (02/10, relecteur distinct) — chaque carte contre sa page,
chaque clé contre la table p. 13, les figures contre leurs pages, les zones
rendues sur le schéma. Corrigé :

- **« une seule hypothèse »** : la FC n°12 dit que Cox n'a besoin que de la
  proportionnalité des risques *à la place d'une forme paramétrique* ; or le
  cours 2023-24 et l'annale 2019/2020 S1 Q17 lui donnent aussi la
  log-linéarité et une censure non informative. Les cartes qui disaient « la
  seule hypothèse du modèle de Cox » le disent maintenant « sur l'évolution des
  risques » (`srv-fa-cox`, `srv-qc-cox`, `srv-qc-proportionnalite` D,
  `srv-qr-proportionnalite`, zone `proportionnels`, la justification D de la
  question de 2022/2023 S1 Q20 et de ses deux reprises, `lex-proportionnalite`),
  pour ne plus contredire `srv-qc-conditions` ni la Q17 ;
- `srv-fa-a-risque` : les trous se tapent et se comparent au mot exact ; « la
  marche suivante est plus {{importante}} » et « des ronds ou des lignes »
  reprennent maintenant le texte de la p. 3 (la carte écrivait « grande » et
  « traits ») ;
- zone `croissant` de `srv-zo-risques` : son libellé (« un risque qui augmente
  avec le temps ») désignait aussi la droite bleue montante du panneau des
  risques croisés ; il dit maintenant « un risque instantané unique, qui croît
  de plus en plus vite avec le temps » ;
- `srv-qc-hdl` : ses propositions B (« environ deux fois plus ») et C (« chaque
  petit trait vertical ») ne se jugent qu'en lisant les courbes, que la carte
  ne montrait qu'en correction. Les courbes passent dans l'énoncé
  (`illustration_question`, sans légende qui vende la réponse) ; la
  correction montre l'exemple pas à pas, où les ronds sont des censures.

## Questions pour Vincent

1. **2021/2022 S1 Q29** : la table imprime BE ; la carte retient B (E, « seul
   modèle valide dans les études cas-témoins », est fausse). Proposition du
   plan C15 appliquée et signalée sur la carte ; à confirmer si un corrigé
   officiel dit autre chose.
2. **Le hazard ratio et les conditions du modèle de Cox** ne sont pas dans la
   FC n°12 2025-26 (quinze minutes de cours) : huit cartes de cours et sept
   annales s'appuient sur les cours 2023-24 et 2024-25, avec le tag
   `hors-fiche`. Les garder comme à savoir pour le partiel de décembre ? (Proposé :
   oui, les annales les demandent à chaque session.)

## À relire

Aucune carte `a-relire` : chaque carte cite une page de la FC 2025-26, d'une
autre FC 2025-26 de l'UE ou d'un cours ancien du même professeur, et chaque
annale sa clé imprimée ou la raison de s'en écarter.

## L'échelle : Simple → Moyen → Annale (C20, 18/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 16 décembre. Sous les annales, 18 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 4 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `kaplan-meier` | 7 | 2 | 5 |
| `cox` | 11 | 2 | 6 |

**Le schéma** `ech-survie`, « L'analyse de survie · décrire, expliquer, lire le résultat », donne 34 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_SURVIE`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- srv-an-1920s1-q16 E : « les modèles de survie exponentielle, hypothèse raisonnable pour la mortalité humaine » — la justification de l'annale repose sur des références extérieures (risque constant de la loi exponentielle, loi de Gompertz) ; aucun cours du dossier ne le dit, la FC n°6 partie 2 (p. 4) n'emploie l'exponentielle que pour le nombre de sujets : aucune marche ; sa lettre est posée sur la case du modèle de Cox, où se lit h(t), le risque qu'une survie exponentielle suppose constant.

## Régénérer

```powershell
cd contenu\chapitres\biostat_survie
..\..\..\app\.venv\Scripts\python.exe generer.py
```

`generer.py` est la copie exacte de
`.claude/skills/nouveau-chapitre/scripts/generer_modele.py`. Les figures se
réextraient du PDF par un script de brouillon (images natives, ou rendues
agrandies pour les diapositives de la p. 3 et le tableau d'énoncé) ; elles sont
versionnées dans `media/`.
