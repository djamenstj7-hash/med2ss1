# Analyses médico-économiques — paquet Biomédecine quantitative

95 notes, 172 cartes. Chapitre `chap-ue-biomed-quanti-fc15` de l'UE
Biomédecine quantitative, treizième et dernier de l'UE. Cours du **Dr B.
Dervaux, le 03/12/2025, de 9 h 30 à 11 h**, dans le **Ronéosaure 2025-26**
(FC n°13, 14 pages) ; les annales du polycopié « 15 - Analyse
médico-économique » du Ronéosaure 2024-25 (34 questions, 15 sessions) et la
capture d'une annale 2024/2025 que la FC reproduit p. 14. Examen : partiel du
mercredi 16 décembre 2026.

**Fiche provisoire** (C15, décision de Vincent du 02/10) : le cours de l'année
2026-27 n'est pas encore paru. Chaque carte de cours cite la FC 2025-26 à sa
page et porte le badge « Cours 2025-26 » ; le ronéo 2026-27 corrigera les cartes
quand il sortira. `donnees.py` porte `ANNEE_COURS = "2025-26"`. Aucune carte ne
dit « Absent du cours 2026-27 », et les erreurs du Ronéosaure sont dites par un
ATTENTION sans genre : la liste des erreurs de la promo,
`contenu/ERRATA_RONEOS_2026-27.md`, ne concerne que les ronéos 2026-27.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 51 | 51 |
| Texte à trous | 17 | 90 |
| QROC | 12 | 12 |
| Recto-verso | 6 | 6 |
| Schéma cliquable | 1 | 5 |
| Planche à légender | 1 | 1 |
| Lexique | 7 | 7 |

Dont **35 annales** sur 16 sessions (2015/2016 à 2024/2025) : 34 du polycopié
« 15 - Analyse médico-économique », et la capture « Annales 2024/2025 » de la FC
n°13 p. 14 (`eco-an-2425-fc13`, session 2024/2025, numéro inconnu). Les 16
autres QCM sont des questions de cours.

Huit thèmes dans l'ordre du cours, et `hors-fiche`. `benefice-risque` est celui
de la BMCT, `hors-fiche` celui de la sémiologie ; les sept autres sont nouveaux
et leurs libellés restent à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) :

| Clé | Libellé | Notes |
|---|---|---|
| `vaccins` | Vaccins et types de vaccins | 3 |
| `benefice-risque` *(BMCT)* | Balance bénéfice-risque | 4 |
| `politique-vaccinale` | Acteurs, calendrier et obligations | 14 |
| `efficacite-vaccinale` | Efficacité vaccinale directe, indirecte, totale, globale | 19 |
| `immunite-collective` | Taux de reproduction et seuil d'immunité collective | 16 |
| `varicelle-vaccination` | La varicelle et le boost exogène | 8 |
| `evaluation-economique` | Types d'évaluation économique | 14 |
| `frontiere-efficience` | Dominance, frontière d'efficience et RDCR | 10 |
| `hors-fiche` *(sémiologie, tag ajouté)* | Tombé en annales, absent de la fiche | 5 |

Au regroupement (03/10), la clé `varicelle` du plan est devenue
`varicelle-vaccination` : son libellé ne vaut que pour ce chapitre, et le mot
seul reste libre pour une UE qui parlerait de la maladie elle-même (la
virologie a pris `varicelle-zona`). `vaccins` garde son nom : « Vaccins et
types de vaccins » dit vrai dans toute UE.

Le plan proposait « R0 et seuil d'immunité collective » : un libellé ne porte
aucun chiffre (test `test_le_chapitre_se_decoupe_en_themes_lisibles`), d'où
« Taux de reproduction et seuil d'immunité collective ».

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-biomed-eco-2526` — Ronéosaure, « FC n°13 Analyses médico-économiques » (14 p.) | 2025-26 | le cours ; `SRC["fiche"]`, ses figures ; la capture de l'annale 2024/2025 (p. 14) ; fiche provisoire en attendant le ronéo 2026-27 |
| `src-annales-15-analyse-medico-economique` — « 15 - Analyse médico-économique » (19 p.) | 2024-25 | 15 sessions, table de corrections p. 19 |

Le polycopié d'annales est déclaré exactement comme le déclare déjà
`biostat_tests_diagnostiques` (même id, même titre aux deux espaces finales,
même chemin), qui en carte la 2023/2024 S2 Q.5. Lus en appoint, sans être
déclarés : le cours 2024-25 (FC n°15, Dr Dervaux et Pr Dubos) et le cours
2023-24, pour comprendre une annale — cinq justifications citent le cours
2024-25 (p. 17-18 : l'évaluation est comparative et compte les conséquences ;
p. 20 : « on n'a pas le droit de calculer le RDCR entre le point 1 et le
point 3 » ; p. 21 : le seuil américain en dollars ; p. 23 : le modèle simule, il
n'observe pas) ; l'errata des cours 2025-26 (trois entrées pour cette FC) ;
l'errata des annales 2024-25 (aucune entrée pour ce polycopié).

Les pages citées sont celles du PDF ; la p. 1 est la page de garde et le plan.
Les en-têtes du ronéo, de l'errata et du polycopié portent des noms d'étudiants :
aucun n'est repris. Le polycopié attribue ces annales au « Pr Décaudin » : le
cours est celui du Dr Dervaux, l'attribution n'est pas reprise.

## Ce que le cours a dicté

- **Le rouge** est celui des titres et des notions clés : vaccin inerte ou
  inactivé et vaccin atténué (p. 2 : `eco-fa-types-vaccins`,
  `eco-qc-types-vaccins`) ; BBR individuelle et collective (p. 3 :
  `eco-qc-bbr`, `eco-fa-externalites`) ; efficacité du vaccin, efficacité de la
  vaccination, individuelle, collective (p. 5 : `eco-rv-vaccin-vaccination`,
  `eco-qc-vaccin-vaccination`) ; seuil d'immunité collective, taux de
  reproduction de base, « dans un environnement social donné » (p. 6-7 :
  `eco-fa-seuil`, `eco-qc-r0`, `eco-qr-seuil`).
- **« Bien comprendre la différence »** entre efficacité du vaccin et de la
  vaccination (p. 5-6) : une carte de chaque type la pose.
- **À ne pas apprendre**, dit le ronéo : le calcul du temps de doublement
  (p. 7). Aucune carte ; la phrase qui le suit (« le R0 est un indicateur
  semblable au Td, relation de proportionnalité ») n'est donc pas reprise.
- **L'histoire** (p. 2, « le prof ne s'est pas attardé ») n'a pas de carte
  propre ; Jenner et la vaccine survivent dans le lexique de l'immunologie.
- **Les exercices chiffrés** de la FC (Bangor p. 8, Tecumseh et Adrian p. 9,
  la simulation p. 6) ont chacun leur carte (`eco-qc-bangor`,
  `eco-qr-bangor`, `eco-qc-tecumseh`, `eco-fa-simulation`) : le même calcul
  que les annales des zones A et B, sur d'autres chiffres.
- **Ce qui n'est pas carté ici** (plan C15) : la 2023/2024 S2 Q.5 (une
  spécificité de 87 %, `biostat_tests_diagnostiques`), les 2017/2018 S2 Q.17-18
  (pharmacovigilance, `biostat_pharmacovigilance`), la 2021/2022 S2 Q.35 (modèle
  de Cox, `biostat_survie`) ; le terme « Vaccination » (immunologie).

## Les erreurs du Ronéosaure 2025-26

Le Ronéosaure n'est pas le ronéo de l'année : chaque erreur est portée par un
**ATTENTION nu** dans la carte qui tient la notion, la sorte dite dans le texte,
et rien n'entre dans `contenu/ERRATA_RONEOS_2026-27.md`.

| Page | Le ronéo dit | Retenu | Sorte | Carte |
|---|---|---|---|---|
| 6 | le temps moyen entre un cas et le suivant « (= période d'incubation) » (comme le ronéo 2024-25) | le tableau de la même page dit « temps moyen entre deux cas successifs » : l'intervalle de génération ; l'incubation va de la contamination aux symptômes | point douteux | `eco-fa-simulation` (explication) |
| 8 | « EVdirecte = 1 − RR direct » sous l'effet indirect, « EVindirecte = 1 − RR indirect » sous l'effet total | chaque EV = 1 − le RR de sa propre comparaison (diapositives p. 7-8 ; l'errata ajoute la formule de l'indirect) | prise de notes | `eco-fa-formules` (explication) |
| 12 | « USA = £50000-£100000 » | 50 000 à 100 000 $ par année de vie (cours 2024-25, p. 21) ; la carte ne demande pas le seuil américain | prise de notes | `eco-fa-rdcr` (explication) |
| 13 | « vaccination est un sujet d'enfant » ; « plutôt malin » ; « avec introduction de la varicelle » | « la varicelle est un sujet d'enfant » ; « plutôt grave » ; « introduction de la vaccination contre la varicelle » (errata 2025-26) | prise de notes | `eco-qc-varicelle-choix` (explication) |
| 4 | le BCG parmi les obligations du milieu de travail | obligation suspendue pour les professionnels et étudiants de santé depuis le 1er avril 2019 (décret n° 2019-149) ; la HAS a aussi recommandé en 2023 de lever celle du DTP | daté, point douteux | `eco-fa-travail` (explication) ; `eco-an-1819s1-q37` E le dit |
| 6 | le tableau des EV « calculs incorrects » (errata) | corrigé dans notre PDF (version numérique) : 341 / 31 / 5 cas, 91 % et 99 % | à dire | aucune ; `eco-fa-simulation` suit le PDF |
| 7 | « le R0 est un indicateur semblable au Td (relation de proportionnalité) » | relation inverse : plus le R0 est grand, plus le temps de doublement est court | point douteux | sans carte (temps de doublement « pas à apprendre ») |
| 2 | « les vaccins disponibles en France sont les antiviraux et les antibactériens » | les vaccins antiviraux et antibactériens | prise de notes | sans carte |
| 3 | « plus vulgairement « d'extériorité de troupeau » » | immunité de troupeau | prise de notes | sans carte ; les cartes disent « immunité grégaire » ou « de troupeau » |

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| L'immunité collective et le R0 : définition, seuil = 1 − 1/R0, seuil qui monte avec le R0, protection collective liée à la transmission | 9 : 2020/2021 S1 Q.12, S2 Q.11, 2019/2020 S2 Q.19, 2018/2019 S1 Q.39 (ABD) ; 2018/2019 S2 Q.35 (variante, ACD) ; 2021/2022 S1 Q.16 ; et la « vaccination en général » de 2023/2024 S1 Q.29, 2022/2023 S1 Q.3, S2 Q.29 (ACE) |
| L'évaluation médico-économique et le RDCR | 5 fois la même question, BD (2020/2021 S2 Q.10, 2019/2020 S2 Q.18, 2018/2019 S2 Q.17, 2017/2018 S1 Q.15, S2 Q.13) ; l'évaluation « d'une ou plusieurs interventions » (2016/2017 S1 Q.33, 2015/2016 S1 Q.33) ; ce que permet un modèle (2016/2017 S1 Q.34, 2015/2016 S1 Q.34) |
| Le tableau des taux d'attaque des zones A et B : EV directe, indirecte, totale, globale | 4 : 2023/2024 S1 Q.28, 2022/2023 S1 Q.1, S2 Q.27 et la capture 2024/2025 (AC) ; une variante en sur-incidence, 2021/2022 S2 Q.36 (BDE) ; quel indicateur avec deux populations seulement, 2018/2019 S1 Q.40 (E) |
| Le plan coût-efficacité à cinq stratégies : dominance, frontière, RDCR, bénéfice net | 2 : 2023/2024 S2 Q.4, 2022/2023 S2 Q.30 (BCD) |
| Les recommandations et obligations vaccinales | 7 : 2018/2019 S1 Q.37, S2 Q.16, 2017/2018 S1 Q.14, S2 Q.12, 2022/2023 S1 Q.2, 2016/2017 S1 Q.36, 2015/2016 S1 Q.36 |
| La varicelle : effets indirects, déplacement en âge, recommandations | 2 : 2017/2018 S1 Q.13, 2015/2016 S1 Q.35 |

Chaque session a sa carte, et l'explication renvoie aux autres. Les tableaux et
le plan des énoncés sont des images du polycopié : ils sont en
`illustration_question` (lire l'image est la question), une image par énoncé
commun. La capture de la FC p. 14 porte les cases cochées de la correction : son
tableau seul est en question (`eco-an-2425-tableau.png`), la capture entière en
correction. Des mots collés à l'impression (« méningocoqueB »,
« Efficacitévaccinaleindirecte », « rougeoleoreillons-rubéole »,
« antipoliomyélite », « coûtutilité », « dela ») sont rétablis d'après les autres
sessions, et l'explication le dit ; « médicoéconomique » et « Depuis 2018 ,onze »
sont gardés tels quels.

Cinq annales portent le tag `hors-fiche` : la couverture du ROR (2017/2018 S1
Q.14, S2 Q.12 ; référence Santé publique France), les onze vaccinations de 2018
et la publication annuelle du calendrier (2018/2019 S1 Q.37 et S2 Q.16 ; loi du
30/12/2017), le Comité devenu Commission technique des vaccinations (2018/2019 S1
Q.37 ; HCSP 2016, HAS 2017), les recommandations du HCSP (2015/2016 S1 Q.35).

## Le schéma cliquable et la planche

**Un schéma cliquable** (`schemas.py`), avec sa version légendée en
correction :

| Fichier | Ce qu'on clique | Pourquoi ce dessin |
|---|---|---|
| `plan-cout-efficacite.svg` | la stratégie strictement dominée (c), celle qu'élimine la dominance faible (d), la stratégie retenue pour une disposition à payer de 4 000 € (a), 20 000 € (b) et 40 000 € par QALY (e) — 5 zones | les cinq stratégies des annales (a 1 k€ ; 0,1 QALY · b 2 ; 0,3 · c 3 ; 0,2 · d 6 ; 0,4 · e 8 ; 0,5), sans frontière ni segment : les tracer est la question. RDCR a → b = 5 000 €, b → e = 30 000 € par QALY ; à 6 k€, le mélange de b et e donne 0,43 QALY, plus que d. Disques de 24 px ; b et c, les plus proches, sont à 92 px |

La version légendée (`plan-cout-efficacite-legende.svg`) trace la frontière
a-b-e, le quadrant nord-ouest de c, le point fictif au-dessus de d, les deux
RDCR, la « 2 CV » et la « Rolls-Royce » (p. 11) ; elle illustre aussi les deux
annales du plan.

**Une planche à légender**, `eco-pl-comparaisons` (`planche_depuis_image.py`) :
la figure de la p. 8 — populations A et B, ovales « Vac » et « Non Vac », quatre
traits —, ses six légendes effacées (population A, population B, type I direct,
IIa indirect, IIb total, III global) ; les ovales restent, ils sont la donnée.
Quatre intrus (vaccinés de la population B, effet cocooning, passager
clandestin, taux d'attaque). L'aperçu de contrôle a été regardé : aucun reste
de lettre, les traits intacts. Le n° 6 dit le piège des annales : « direct +
indirect » ne veut pas dire que les EV s'additionnent (RR total = RR direct ×
RR indirect).

**Vingt figures de la FC 2025-26** (captures de diapositives, trois tableaux du
ronéo rendus depuis le PDF, et la formule des quatre RR assemblée depuis les
p. 7-8) et **trois images d'énoncé** du polycopié, réduites à 1000 px de large
au plus et en 256 couleurs. **48 QCM sur 51 illustrés** (les 35 annales, 13 des
16 questions de cours), 74 notes sur 95. Les trois QCM sans figure
(`eco-qc-acteurs`, `eco-qc-economie`, `eco-qc-analyses`) portent sur des
définitions que le ronéo n'illustre pas.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2022/2023 S1 Q.2 | BE | **BCE** (`officielle=False`, CONFLITS C) | clé datée : le méningocoque B est obligatoire chez le nourrisson depuis le 1er janvier 2025 (FC p. 4 ; décret n° 2024-694) — question pour Vincent |
| 2015/2016 S1 Q.34 | ACE | **BCE** (`officielle=False`, CONFLITS A, B) | ACE est la clé de la 2016/2017 S1 Q.34, aux propositions rangées autrement ; ici A est « prédire avec certitude ». La colonne « 2015/2016 Session 2 » de la table, sans énoncés, imprime BCE, qui va avec cet ordre |
| 2015/2016 S1 Q.36 | ACD | **CDE** (`officielle=False`, CONFLITS A, E) | ACD ferait la varicelle obligatoire et omettrait la poliomyélite ; la colonne « 2015/2016 Session 2 » imprime CDE, qui va avec cet ordre |
| 2018/2019 S2 Q.35 | — (la table imprime « 18) ABD », sans énoncé n° 18) | **ACD** (`officielle=False`, CONFLITS B, C ; « clé déduite du cours ») | ABD est la clé de la version « R0 élevé → seuil bas » (2018/2019 S1 Q.39) ; ici C dit « élevé » (vrai) et B « éradication » (faux) |

**Clés gardées, propositions datées ou douteuses** (CONFLITS déclarés, ATTENTION
dans la justification, clé officielle) :

| Question | Proposition | Ce que dit la carte |
|---|---|---|
| 2023/2024 S1 Q.29 C, 2022/2023 S1 Q.3 C, S2 Q.29 C | « le vaccin contre le zona est contre-indiqué chez les personnes immunodéprimées » | vrai pour le cours (la diapositive p. 2 range le zona parmi les vivants atténués) et la clé ; depuis mars 2024, la HAS recommande le vaccin recombinant Shingrix justement chez l'immunodéprimé, et le Zostavax n'est plus commercialisé (juin 2024) |
| 2018/2019 S1 Q.37 C, S2 Q.16 C | « depuis 2018, onze vaccinations sont obligatoires » | vrai alors (LFSS du 30/12/2017) ; douze depuis le 1er janvier 2025 selon le cours |
| 2018/2019 S1 Q.37 B | « le Comité Technique des Vaccinations (CTV) est rattaché à la HAS », compté faux | point douteux : la même phrase avec « Commission » est comptée vraie en 2017/2018 S1 Q.14 E et S2 Q.12 E. Le Comité était celui du HCSP ; la Commission est à la HAS depuis 2017. Clé gardée |

La colonne « 2019/2020 Session 2 » de la table numérote « 19 » les deux
questions : la première est la Q.18 (BD), la seconde la Q.19 (ABD). La clé
« 33) BCD » de 2017/2018 S2 n'a pas d'énoncé : non cartée.

## Le lexique

Sept termes, tous accueillis ici, pages mesurées dans la FC n°13 avec
`chercher_pages.py` (page de plan exclue) :

| Terme | Pages | Origine |
|---|---|---|
| Grégaire | 3, 5, 6, 8 | latin gregarius, de grex, gregis |
| Immunogénicité | 5 | latin immunis + grec -γενής, par immunogène |
| Efficience | 11, 12 | latin efficientia (efficere), par l'anglais efficiency |
| Externalité | 3, 12 | latin externus, par l'anglais externality |
| Éradication | 3, 4 | latin eradicatio (ex + radix) |
| Antigénique | 2 | grec ἀντί + -γενής, par antigène |
| Opportunité | 10 (« coût d'opportunité ») | latin opportunitas (opportunus : ob + portus) |

Les étymologies sont proposées dans le brouillon `etym/biostat_medico_economie.json`
(six racines nouvelles : grex, efficere, externus, ex-/é-, radix, opportunus ;
trois réemployées : immun(o)-, -gène, anti-), vérifiées sur le Wiktionnaire et
le Gaffiot ; les définitions et les racines du chapitre portent déjà le texte que
`appliquer_etymologies.py` écrira. Au regroupement du 03/10, `ex-, é- (latin)`
cite la FC de sémantique 2/2, p. 8 (« ex- / ec- : dehors ; hors de »), qui
l'enseigne. Laissés à d'autres chapitres : « Vaccination »
(immunologie) ; « Varicelle », « Zona », « Atténué », « Épidémie », à vérifier
contre le plan de virologie (plan C15, 19).

## Questions pour Vincent

1. **Le méningocoque B** (2022/2023 S1 Q.2) : la carte retient BCE, la clé de
   2025, contre la clé imprimée BE de 2022/2023 (`officielle=False`). Garder la
   clé à jour, ou la clé imprimée avec un ATTENTION ?
2. **« Onze vaccinations obligatoires depuis 2018 »** (2018/2019 S1 Q.37 C, S2
   Q.16 C) : la clé imprimée (vrai) est gardée ; depuis 2025, le cours en compte
   douze (et d'autres sources treize). Faut-il la compter fausse, comme le
   méningocoque B ?
3. **Le vaccin contre le zona chez l'immunodéprimé** (trois sessions, C) : vrai
   pour le cours et la clé, faux depuis le vaccin recombinant (HAS, mars 2024).
   Clé gardée, comme le plan le proposait ; à revoir si le ronéo 2026-27 change
   la diapositive.
4. **« Comité » ou « Commission » technique des vaccinations** (2018/2019 S1
   Q.37 B) : clé imprimée gardée (faux), point douteux.
5. **La varicelle du nourrisson** : la HAS doit rendre en novembre 2026, avant
   le partiel, son avis sur la vaccination généralisée des nourrissons (note de
   cadrage du 08/12/2025). Si elle la recommande, les D de 2018/2019 S1 Q.37 et
   S2 Q.16, le C de 2015/2016 S1 Q.35 et les cartes de cours qui disent « pas
   recommandée en France » seront à reprendre.

## À relire

Aucune carte `a-relire` : chaque clé et chaque proposition renvoie à une page de
la FC 2025-26, à la table de corrections ou à une source citée.

## L'échelle : Simple → Moyen → Annale (C20, 18/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 16 décembre. Sous les annales, 35 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 6 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `politique-vaccinale` | 6 | 1 | 7 |
| `efficacite-vaccinale` | 6 | 1 | 6 |
| `immunite-collective` | 8 | 1 | 9 |
| `varicelle-vaccination` | 4 | 1 | 2 |
| `evaluation-economique` | 8 | 1 | 9 |
| `frontiere-efficience` | 3 | 1 | 2 |

**Le schéma** `ech-strategie-vaccinale`, « La stratégie vaccinale · protéger, mesurer, évaluer », donne 77 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_STRATEGIE_VACCINALE`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- eco-an-1819s1-q37 A, eco-an-1819s2-q16 A, eco-an-1718s1-q14 A, eco-an-1718s2-q12 A : « le calendrier vaccinal est publié tous les ans », hors fiche (tag hors-fiche) ; la FC ne montre que le calendrier simplifié de 2025 (p. 5), sans dire sa périodicité. Lettre posée sur la case CTV, sans marche.
- eco-an-1718s1-q14 C, eco-an-1718s2-q12 C : la couverture du ROR, hors fiche (Santé publique France) ; la FC ne donne aucune couverture vaccinale réelle. Lettre posée sur la case des obligations, sans marche.
- eco-an-1617s1-q33 B, eco-an-1516s1-q33 C : « la seule méthode qui permette d'établir l'efficience », vraie selon la clé ; la FC ne dit pas « seule » (règle 6), et aucune marche ne peut le simplifier sans le fausser.
- eco-an-1819s1-q40 C : l'efficacité « partielle », un nom qui n'existe pas ; le schéma nomme les quatre RR, et une marche bâtie sur un mot absent du cours n'apprendrait rien.
- eco-an-2223s1-q2 E : le ROR, obligatoire, se lit en clair sur la case des obligations (ligne non effacée) ; aucune marche propre.
- eco-an-1516s1-q35 D : la recommandation du vaccin contre le zona chez les personnes âgées (HCSP), hors fiche ; la FC ne fait que poser la question d'associer les deux vaccinations (p. 12).

## Régénérer

```powershell
cd contenu\chapitres\biostat_medico_economie
..\..\..\app\.venv\Scripts\python.exe generer.py
```

La planche numérotée se refait, depuis `app/`, avec
`uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/biostat_medico_economie eco-pl-comparaisons --apercus <brouillon>`.
