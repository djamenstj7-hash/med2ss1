# Abord et examen clinique du malade — paquet d'exemple

60 notes, 88 cartes. Deux sources : la fiche de cours et les annales de onze
sessions.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 30 | 30 |
| Recto-verso | 14 | 14 |
| Texte à trous | 7 | 26 |
| QROC | 6 | 6 |
| Repérage sur schéma | 3 | 12 |

Sur les 30 QRM, **20 sont des annales** de 2015/2016 à 2023/2024, avec la clé de
correction du polycopié. Quatre images : trois schémas redessinés, une figure du
cours.

## Un cours qui n'a qu'une couleur

La fiche est en gras de bout en bout — le gras n'y distingue donc rien et n'a pas
été lu comme un signal. **Un seul passage est en rouge**, celui qui range les
signes cliniques en trois types. Deux passages sont en gris, écartés : la
remarque du ronéiste sur l'étape « périlleuse » de l'anamnèse, et l'exemple de la
biopsie hépatique. Aucun commentaire en marge.

Cette pauvreté du code couleur est en réalité un cadeau : elle désigne le centre
du chapitre sans ambiguïté, et les annales le confirment.

## Ce que les annales ont dicté

**Vingt questions, onze sessions, et pas une qui sorte du passage rouge.** Toutes
demandent de ranger un signe, ou de savoir quel geste le produit. La hiérarchie
du chapitre en découle : ranger un signe est révisé de cinq façons — en texte à
trous, en QCM, en QROC, en cliquant sur le découpage de la consultation, et sur
les vingt questions déjà tombées.

Trois pièges reviennent sans se lasser :

| Le piège | Sessions | Verdict |
|---|---|---|
| Le stéthoscope et le marteau à réflexes donneraient des signes **paracliniques** | 3 | toujours faux : ce sont des outils cliniques |
| L'anamnèse serait **la conclusion** formulée à la fin de l'examen | 5 | toujours faux : c'est l'histoire de la maladie |
| Il serait **inutile de faire déshabiller** le patient | 3 | toujours faux |

Et deux mots décident à eux seuls de la plupart des items : **« toujours »** et
**« uniquement »**. Dans ce chapitre, ils annoncent presque toujours un faux.

### Ce que le cours ne dit pas, et que les annales apprennent

**Un bon interrogatoire peut à lui seul suffire à poser un diagnostic.** C'est
contre-intuitif, le cours ne l'écrit nulle part aussi nettement, et deux sessions
le tranchent dans les deux sens : en 2017/2018 « ne peut à lui seul suffire » est
donné **faux**, en 2022/2023 « peut suffire à établir le diagnostic » est donné
**vrai**.

## Les trois schémas cliquables

| Fichier | Ce qu'on y clique | Cartes |
|---|---|---|
| `entretien-examen.svg` | les quatre accolades : anamnèse, examen clinique, entretien, examen physique | 4 |
| `consultation-phases.svg` | les quatre phases, dans l'ordre | 4 |
| `ippa.svg` | les quatre temps de l'examen physique | 4 |

Le premier est la figure du professeur, redessinée **avec sa seule colonne
centrale écrite**. Les six composants — parcours, antécédents, histoire, signes
fonctionnels, signes physiques, examens complémentaires — sont la donnée ; ce
sont les regroupements qu'on demande. C'est là que se cache la difficulté des
annales : les signes fonctionnels appartiennent à l'entretien **et** à l'examen
clinique, mais pas à l'examen physique. La figure du cours revient à la
correction, avec ses accolades nommées.

Le troisième garde le seul piège vraiment tombé : **matité et tympanisme viennent
de la percussion**, jamais de l'auscultation.

## Les vignettes cliniques, à part

Le professeur consacre un tiers du cours à dix cas où l'inspection a tranché
seule : mastocytose, sarcoïdose, livedo racemosa, sclérodermie, fasciite,
dermatomyosite, maladie de Fabry, Ehlers-Danlos, Melkersson-Rosenthal,
pseudoxanthome élastique. **Aucune n'a jamais été interrogée.**

Elles sont gardées dans leur propre thème, « Vignettes cliniques du cours », pour
qu'on puisse les réviser ou les laisser de côté en connaissance de cause. Elles
ne sont pas du bavardage : elles montrent à quoi sert le déshabillage, qui est
lui bel et bien au programme.

## La seule anomalie du polycopié

C'est le polycopié le plus régulier des chapitres traités jusqu'ici. La table de
corrections suit la numérotation des énoncés, il y a autant de clés que de
questions, et **aucune clé ne contredit le cours ni une autre session**.

Une seule coquille, de mise en page : en 2019/2020 nov S1, la proposition D de la
question 18 tient sur deux lignes et la seconde a reçu la lettre « A ». Il y a
donc six lettres imprimées pour cinq propositions. Les deux morceaux ont été
recollés, et la carte le signale à l'endroit exact.

**Clés non reprises telles quelles : aucune.** Relue le 26/09/2026 (règle de
Vincent : la clé retenue est la bonne, pas la clé imprimée), la clé ABCD de
cette question est juste : un bon interrogatoire peut suffire au diagnostic
(« parfois l'interrogatoire lui-même suffit à faire un diagnostic », ronéo
2026-27, p. 4), les signes généraux ne désignent aucun organe (p. 2), la matité
vient de la percussion (Collège des enseignants de pneumologie, référentiel de
sémiologie respiratoire, 2009, p. 74), et la phase III est celle des hypothèses
diagnostiques (p. 9).

## Le corrigé officiel 2023-24

Le sujet de sémiologie générale 2023-24 et son corrigé officiel (une clé par question) sont arrivés le 15/10/2026. Les cartes de cette session venaient du polycopié et en gardent la source ; leur clé est vérifiée :

- 2023/2024 QCM 7 (`abo-an-2324-q7`, AC) : clé confirmée par le corrigé officiel 2023-24, dépôt du 15/10/2026.


## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026)

L'échelle du pilote de l'immunité innée, étendue à la sémiologie pour l'examen du 4/11 (Vincent, 16/10 : « on continue pour les chapitres que je vais avoir à l'examen »). Sous les annales, 30 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 7 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `definitions` | 18 | 4 | 17 |
| `interrogatoire` | 6 | 2 | 3 |
| `physique` | 6 | 1 | 3 |

**Le schéma** `ech-abord`, « Abord du malade · recueillir, ranger, décider », donne 61 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_ABORD`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sources.** `SRC` n'a pas de clé `fiche` : chaque marche nomme la sienne (`fiche="src-fc-semio-abord"`, la ronéo 2026-27), et les images de l'échelle sont déclarées sous `SRC["cours"]`. La marche `abo-ech-s26` cite la ronéo 2026-27 de sémiologie digestive (matité et tympanisme, p. 10) : `src-fc-semio-dig` est déclarée dans `SOURCES`, copiée de `semio_digestive`.

**La fièvre**, que la ronéo digestive range à l'anamnèse parmi des « signes fonctionnels extra-digestifs associés » (p. 3) avant de la rechercher avec l'AEG (p. 5), est signalée par un `ATTENTION` dans `abo-ech-s7` (C) et `abo-ech-m2` (B), et inscrite aux points douteux de `contenu/ERRATA_RONEOS_2026-27.md`.

**Sans marche** :
- abo-an-2324-q7 E, abo-an-2223-q17 E, abo-an-1819-q6 E, abo-an-2526-q9 E : la spécificité des signes fonctionnels envers une pathologie. Le ronéo 2026-27 ne la dit pas des signes ; il ne dit la non-spécificité que des syndromes (p. 3), et la marche du syndrome (s14) n'est pas ce fait-là. Les clés, constantes sur quatre sessions, suivent 2018/2019 Q6 E (« le plus souvent peu spécifiques »). Lettre posée sur la case des signes fonctionnels.
- abo-an-1617-q15 E : la dysurie n'est pas dans le ronéo 2026-27 d'abord ; la ronéo 2026-27 de sémiologie urologique la définit parmi les troubles mictionnels sans la ranger dans un type de signes. Lettre posée sur la case des signes fonctionnels.

## Régénérer

```powershell
python generer.py
```

Le script valide avant d'écrire et refuse d'écrire s'il trouve une erreur :
propositions comptées, justifications présentes, zones qui ne se recouvrent pas,
trous courts, sessions déclarées, conflits signalés là où ils se jouent.
