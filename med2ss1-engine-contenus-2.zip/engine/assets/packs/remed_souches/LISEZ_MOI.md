# Cellules souches et renouvellement tissulaire — paquet ECL Remédiation

104 notes, 183 cartes. Chapitre `chap-remed-souches` de l'UE ECL Remédiation
(`ue-remediation`), séance 4 du 15/10/2026, évalué au **test intermédiaire 2
du 29/10/2026** (QCM avec degré de certitude ; `exam-remed-ti2`, déclaré par le
squelette). Sources : les diapositives de la séance 3 de 2024-25 (66 pages), le
sujet du test intermédiaire 3 de 2024-25 (questions 15 à 21) et celui du test
intermédiaire 2 de 2025-26 (questions 19 à 27), tous deux sans corrigé.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 48 | 48 |
| QRU | 7 | 7 |
| Texte à trous | 14 | 82 |
| QROC | 11 | 11 |
| Recto-verso | 7 | 7 |
| Schéma cliquable | 3 | 14 |
| Lexique | 14 | 14 |

Dont **16 annales** (QRM), deux sessions : `2024/2025 TI3` (7 questions) et
`2025/2026 TI2` (9 questions, ajoutées le 26/10/2026). Les 39 QCM du cours
(32 QRM, 7 QRU) ont une justification par proposition, qui commence par « Vrai » ou « Faux »
(sauf deux ATTENTION) ; leurs clés se répartissent sur les cinq lettres (A 19,
B 20, C 18, D 19, E 20 fois vraie) et comptent de une à quatre vraies (1 : 8,
2 : 9, 3 : 18, 4 : 4, QRU comprises).

Huit thèmes, dans l'ordre du cours :

| Clé | Libellé | |
|---|---|---|
| `tissu-epithelial` | Le tissu épithélial et la peau | **nouveau** |
| `culture-cellulaire` | La culture cellulaire | **nouveau** |
| `expression-differentielle` | Cellules différenciées et expression des gènes | **nouveau** |
| `proprietes-cs` | Propriétés et potentialités des cellules souches | celui de `bmcp_cellules_souches` |
| `ips` | Cellules souches pluripotentes induites (iPS) | celui de `bmcp_cellules_souches` |
| `bioethique-embryons` | Bioéthique : embryons, lignées, clonage | celui de `bmcp_cellules_souches` |
| `pigmentation-uv` | UV, ADN et pigmentation de la peau | **nouveau** |
| `communication-cellulaire` | Modes de communication et messagers | celui de BMCP |

Les quatre libellés nouveaux sont dans `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`), ajoutés avec ce chapitre (C30).

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-remed-souches` — « Le tissu — cellules différenciées, cellules souches, renouvellement et communication intercellulaire », `Remediation/Cellules souches_tissus_161025.pdf` (66 p.) | diapositives du **31/10/2024** (séance 3), distribuées le 16/10/2025 ; l'auteur porte « 2025-26 » | **la base** : chaque note du cours porte sa page (`page=`) ; c'est ce que le lecteur ouvre (`chapitre=`) ; le badge « Cours 2025-26 » est juste, ce sont les diapositives d'une année passée |
| `src-remed-ti3-2425` — test intermédiaire 3 de 2024-25 (25/11/2024), sujet photographié, déclaré mot pour mot comme dans `remed_gene_proteine` | 2024-25 | les questions 15 à 21 ; sans corrigé |
| `src-remed-ti2-2526` — test intermédiaire 2 de 2025-26 (30/10/2025, 10 h-11 h 15, 36 QCM, 7 pages), sujet imprimé, déclaré à l'identique dans `remed_immuno` (questions 1 à 18) et `remed_pharmaco` (28 à 36) | 2025-26 | les questions 19 à 27, section « Histologie » ; sans corrigé ni annotation |

Les diapositives sont celles de l'année du sujet : en 2024-25, ce cours (séance
3, 31/10/2024) venait après le test 2 et a été évalué au test 3 du 25/11/2024.
Aucune ronéo de l'année n'existe pour ce cours : rien n'entre dans
`contenu/ERRATA_RONEOS_2026-27.md`, et aucune carte ne dit « Absent du cours
2026-27 ».

Vérifications hors du cours, citées dans la carte qui s'en sert : Stevens et
Lowe, *Histologie humaine*, et Junqueira, *Basic Histology* (innervation des
épithéliums, derme conjonctif et sa matrice extracellulaire, villosités et
cryptes intestinales, siège basal des cellules souches de l'épiderme,
microvillosités et cils, cellules de Langerhans et de Merkel) ; le cours des
cellules dendritiques de l'UE Immunologie (ronéo 2026-27, p. 7 : « Peau, Cell.
Langerhans ») et le cours d'immunologie de la remédiation (immuno1 p. 26, la
cellule dendritique de la peau) ; Morrison et Kimble, *Nature* 2006 (divisions
symétriques et asymétriques) ; Alberts,
*Molecular Biology of the Cell* (masses de la myosine et de l'albumine) ;
Freshney, *Culture of Animal Cells* (rôle du CO2 et de l'humidité, O2 de
l'étuve) ; Parrinello et al., *Nat Cell Biol* 2003, et Ezashi et al., *PNAS*
2005 (la culture en O2 bas) ; le Code de la santé publique, art. L. 2151-2 (pas d'embryon conçu
pour la recherche), L. 2151-5, L. 2151-6 et L. 2151-7 (loi du 2 août 2021) ;
Takahashi et Yamanaka, *Cell* 2006 ; Cui et al., *Cell* 2007 (α-MSH, MC1R, AMPc,
MITF) ; le comité Nobel (2012, 2024) ; l'étymologie (TLFi, relu à la source ;
Wiktionnaire ; Bailly ; Gaffiot).

## Ce que le cours a dicté

Des diapositives, sans code couleur ni prise de notes : le gras et les encadrés
rouges disent ce que le professeur met en avant, et ont tous leur carte —
la définition du tissu (p. 5), « jointives », « membrane basale », « non
vascularisé » (p. 10), les trois critères de classement (p. 12), les sept
fonctions (p. 13), l'équivalence génomique (p. 27), « même génome » et
« phénotypes différents » (p. 36), la régulation par les micro-ARN et le Nobel
2024 (p. 39), le rappel « un mélanocyte pour 10 kératinocytes basaux » (p. 60),
la communication paracrine (p. 64), le NB « les cellules souches embryonnaires
sont multipotentes, pluripotentes, mais pas totipotentes » (p. 51).

- **Les diapositives-questions** (« Quels sont les différents niveaux
  d'organisation ? », p. 4 ; « Quelles sont les 4 grandes variétés ? », p. 7 ;
  « Quel autre système de régulation ? », p. 38 ; « Quels sont les impacts des
  UV ? », p. 56 ; « Schématiser le processus… », p. 59) ont leur réponse à la
  page suivante, qui porte la carte.
- **L'étude de document** (p. 30-35) a quatre cartes qui font lire le
  résultat : un QCM (`rsou-qc-western-blot`), un QRU d'interprétation
  (`rsou-qc-western-interpretation`), une QROC sur l'expérience réciproque
  (`rsou-qr-western-reciproque`) et un schéma cliquable où l'on pose chaque
  bande (`rsou-zo-western`). La règle : la protéine produite est celle du
  cytoplasme receveur — noyau H dans une cellule M, myosine ; noyau M dans une
  cellule H, albumine (p. 35).
- **Les diapositives sans texte de la communication** (p. 62-66) ne nomment
  aucun facteur : « Facteur soluble », « Facteur », « Récepteur », « Second
  messager », « Facteur de transcription », « Facteur protéique » ; seul **p53**
  est nommé (p. 64), et il a sa QROC (`rsou-qr-p53`). Le facteur de la
  référence (l'α-MSH, issue de la POMC, le récepteur MC1R, l'AMPc, MITF ; Cui et
  al., *Cell* 2007) n'est cité que dans deux explications
  (`rsou-qc-cascade-paracrine`, `rsou-fa-cascade-uv`), jamais en proposition.
  Les schémas génériques des p. 62-63 (signal, récepteur, transduction par des
  molécules relais, réponse : la transcription d'un gène) ont leur texte à
  trous (`rsou-fa-signalisation`, ajouté à la relecture). La p. 66 (types de
  communication) a son QCM.
- **L'infographie de la p. 52** (des outils pour mieux comprendre, pour mieux
  soigner, une utilisation encadrée par la loi) a son QCM
  (`rsou-qc-cse-usages`, ajouté à la relecture).
- Les pièges des chapitres voisins, relus dans `bmcp_cellules_souches` et
  `sang_souches`, et que ce cours pose autrement : la totipotence des premiers
  jours (ici de 12 heures au 4e jour sur la figure p. 45, où BMCP dit « jusqu'à
  8 cellules » — aucune carte ne demande la date), la division asymétrique (ici
  une seule fille identique à la mère, sans parler de progéniteur), la loi de
  2021 (déclaration à l'Agence de la biomédecine).

## Les erreurs des diapositives

Dites par **ATTENTION** sans genre, dans la carte qui porte la notion (« À
l'examen : », puis « La référence : ») :

| Page | La diapositive | La référence | Carte |
|---|---|---|---|
| 31-35 | « Myosine (18 kDa) », la bande sous le repère de 20 kDa | la chaîne lourde de la myosine pèse environ 220 kDa (la molécule, environ 500 kDa) ; 18-20 kDa est la masse des chaînes légères (Alberts). L'albumine (68 kDa) est juste, à 66,5 kDa près | `rsou-qc-western-blot` E (depuis la relecture, une proposition FAUSSE qui inverse les deux masses : la carte ne fait plus cocher vraie une masse fausse), `rsou-zo-western` (explication) |
| 52 | « En France, le comité consultatif national d'éthique est sollicité pour leur utilisation » | le CCNE rend des avis ; les protocoles de recherche sur les CSE humaines sont déclarés à l'Agence de la biomédecine, qui peut s'y opposer, et la recherche sur l'embryon est autorisée par elle (CSP, art. L. 2151-5 et L. 2151-6, loi du 2 août 2021) | `rsou-qc-ethique-cadre` D |

Sans ATTENTION, parce qu'aucune réponse n'en dépend : « différences apicales »
pour différenciations apicales (p. 12, dit dans `rsou-fa-classification`) ;
« Athmosphère » (p. 23) ; « Follicule pilleux » (p. 15, 16, 26) ;
« énucléees » (p. 30) ; « ayant a pour objet » (p. 53) ; « blastula » pour
blastocyste (p. 51, dit dans `rsou-qc-ethique-cse` B) ; « différentiation » pour
différenciation (p. 43-48, dit dans `rsou-fa-cellule-souche`) ; les CSE
« multipotentes, pluripotentes » (p. 51) ; les micro-ARN rangés en
« régulation épigénétique » (p. 39) — l'expression change, pas la séquence, ce
qui est juste ; le comité Nobel dit « post-transcriptionnelle »
(`rsou-qc-micro-arn` A).

## Ce que les annales ont dicté

### Le test 3 de 2024-25 (25/11/2024), questions 15 à 21

| Question | Clé déduite | Savoir | Page du cours |
|---|---|---|---|
| Q15 | ACDE | les quatre grandes variétés de tissu (B, « ovothélium », est un distracteur forgé) | 8 |
| Q16 | ABC | caractéristiques des épithéliums ; B, l'innervation, hors des diapositives | 10-13 |
| Q17 | BE | épiderme et endothélium ; mélanocytes et kératinocytes ; A et C hors des diapositives | 14, 17, 61-64 |
| Q18 | BC | équivalence génomique, expression différentielle, facteurs de transcription et micro-ARN | 27-39 |
| Q19 | BD | classement et fonctions des épithéliums, épiderme et derme, cellules de la peau | 12-27 |
| Q20 | BC | **la même question que Q18**, au mot près | 27-39 |
| Q21 | BE | iPS : autorenouvellement, pluripotence, facteurs de Yamanaka, cellules de malades | 43-51 |

Toutes portent `officielle=False`, et leur `explain` commence par « Clé déduite
du cours, absente de la table de corrections », dit où le cours tranche et ce
que montre la copie annotée. Elles citent la page du cours en source
secondaire (`page=`). Chaque savoir a aussi ses cartes de cours, sous un autre
angle, pour que l'annale ne se réussisse pas par cœur.

**Les anomalies du sujet** :
- **Q18 et Q20 sont la même question** : même énoncé, mêmes cinq propositions.
  Les deux sont transcrites, avec la même clé ; l'`explain` de chacune le dit
  (ATTENTION), et la docstring d'`annales.py`.
- **Q19 D**, vraie pour le cours, est surlignée en vert sur la copie, la couleur
  des désaccords avec la correction de 2024 : voir plus bas, cas ouvert.
- La page des questions 11 à 13 du sujet manque ; elle n'appartient pas à ce
  chapitre (du gène à la protéine).

### Le test 2 de 2025-26 (30/10/2025), questions 19 à 27

La section « Histologie » d'un sujet imprimé de 36 QCM (immunologie 1 à 18
dans `remed_immuno`, pharmacologie 28 à 36 dans `remed_pharmaco`), recopiée
mot pour mot du texte du PDF. **Sans corrigé ni annotation** : toutes les clés
sont déduites du cours, `officielle=False`, et l'`explain` commence par « Clé
déduite du cours, absente de la table de corrections ». C'est le test qui
évaluait ce cours en 2025-26, comme celui du 29/10/2026.

| Question | Clé déduite | Savoir | Page du cours | Reprise de 2024-25 |
|---|---|---|---|---|
| Q19 | ACDE | les quatre grandes variétés de tissu ; « le tissu digestif » est un appareil | 5, 8 | **Q15**, même énoncé, même clé ; les lettres ont bougé, « digestif » remplace « ovothélium » |
| Q20 | ABD | épithéliums : jointifs, échanges gazeux, non vascularisés, membrane basale, pas de soutien | 8, 10, 13 | **Q16**, même énoncé : A, D, E sont ses A, C, D ; B et C nouvelles |
| Q21 | A | division symétrique (autorenouvellement) et asymétrique (une seule fille identique à la mère) | 44, 46 | nouvelle |
| Q22 | CE | épiderme : épithélium pluristratifié, renouvelé par ses cellules souches, cornée au sommet, mélanine reçue des mélanocytes | 14, 17, 41, 61-65 | nouvelle ; E met à l'endroit Q17 D |
| Q23 | B | cellules de l'épiderme, fibroblastes du derme, mélanocytes, paracrine et endocrine, matrice extracellulaire | 6, 10, 15-20, 66 | C est **Q17 C** mot pour mot |
| Q24 | CE | CSE pluripotentes, cellules souches adultes, iPS pluripotentes et leurs usages | 41-51 | nouvelle ; D reprend le piège de Q21 C |
| Q25 | BC | équivalence génomique, expression différentielle, micro-ARN | 27-39 | **Q18** (et Q20) : D, E mot pour mot ; « spécialisée » devient « différenciée » en A, B, C ; même clé |
| Q26 | D | épithéliums : où, jointifs, polarité, différences apicales, renouvellement | 10-12, 41, 57 | nouvelle |
| Q27 | C | Langerhans et Merkel, étuve, équivalence génomique, embryon et loi, iPS | 17, 23, 27, 49-52 | nouvelle ; C rejoint Q18 B |

Quatre questions n'ont qu'une vraie (Q21, Q23, Q26, Q27) : le cours le veut, et
aucun verdict n'a été plié pour étaler les lettres. Neuf clés, 17 vraies sur
45 propositions (A 3, B 3, C 5, D 3, E 3 fois vraie).

Q27, qui passe sur tout le cours, est rangée sous `expression-differentielle`,
le thème de sa seule vraie (l'équivalence génomique) ; Q22 et Q23, sous
`tissu-epithelial` ; Q21 et Q24, sous `proprietes-cs`.

**Deux propositions à deux lectures**, déclarées dans `CONFLITS` et signalées
par un ATTENTION en tête de leur justification (relecture du sceptique,
26/10/2026). Aucune ne contredit une clé de 2024-25 ; le cours tranche chacune,
la référence la rend défendable. Les clés ne changent pas :

| Question | Proposition | Retenu | Les deux lectures |
|---|---|---|---|
| Q21 | B, « La division symétrique permet aux cellules souches de se différencier en divers types cellulaires… » | faux | la diapositive fait de la symétrique l'autorenouvellement, de l'asymétrique la différentiation (p. 46) ; la référence connaît des divisions symétriques où les deux filles se différencient (Morrison et Kimble, *Nature* 2006). À l'examen : faux |
| Q27 | B, « Une température de 37°C et un taux d’O2 à 5% favorise la culture in vitro des cellules » | faux | l'étuve du cours tient 5 % de CO2 (p. 23), le piège échange les gaz ; mais la culture en O2 bas (3-5 %) favorise vraiment fibroblastes et cellules souches (Parrinello et al., *Nat Cell Biol* 2003 ; Ezashi et al., *PNAS* 2005). À l'examen : faux |

Ce que les diapositives ne disent pas, la référence citée dans la
justification le tranche, sans ATTENTION :
- **Q22 C** : la couche basale, siège des cellules souches de l'épiderme (la
  figure de la p. 41 ne les place dans aucune couche) ;
- **Q23 E** : la matrice extracellulaire du derme, tissu conjonctif ;
- **Q26 D** : les microvillosités et les cils, que la figure de la p. 12
  dessine sans les nommer ;
- **Q27 A** : la cellule du toucher est celle de Merkel ; celle de Langerhans
  est une cellule dendritique (le cours d'immunologie du même test montre la
  cellule dendritique de la peau, immuno1 p. 26) ;
- **Q27 D** : la loi interdit de concevoir un embryon pour la recherche (Code
  de la santé publique, art. L. 2151-2, vérifié) ; l'Agence de la biomédecine
  autorise des recherches sur des embryons surnuméraires (art. L. 2151-5).

**Les coquilles du sujet**, gardées telles quelles et listées dans la
docstring d'`annales.py` : « favorise » pour « favorisent » (Q27 B), « l’agence
de Biomédecine » pour l'Agence de la biomédecine (Q27 D) ; « 37°C », « 5% » et
« O2 » sont écrits comme dans le sujet.

## Les clés déduites qui s'écartent des annotations de la copie

La copie est annotée par un étudiant : lettres entourées ou barrées,
surlignages verts. Ce n'est pas un corrigé ; la clé vient du cours.

**Ce que veut dire le vert** (relu à la relecture sur la page 9 de la même
copie, IMG_8047, questions de mort cellulaire) : il y couvre des propositions
entourées et fausses (Q22 A, Q23 E, Q24 C), mais aussi des propositions vraies
que l'étudiant a barrées (Q23 D, le clivage des lamines et du cytosquelette ;
Q24 E, les lamines cibles des caspases). Le vert marque donc les **désaccords
de l'étudiant avec la correction de 2024**, pas le faux. Lu ainsi, la
correction donnait BE à Q17, BE à Q21 (comme le cours) et B seule à Q19 (contre
le cours, voir le cas ouvert) ; les questions sans vert (Q15, Q16, Q18, Q20)
avaient sans doute la clé que l'étudiant a cochée, qui est aussi celle du cours.
Ce n'est qu'un indice : la page 10 n'a aucun vert malgré des erreurs, l'étudiant
n'a pas surligné partout.

| Question | La copie entoure | Clé retenue | Ce qui s'écarte, et pourquoi |
|---|---|---|---|
| Q15 | A C D E | ACDE | rien |
| Q16 | A B C | ABC | rien |
| Q17 | B **D** E (D surlignée en vert) | BE | **D** est démentie par le cours : le mélanocyte produit la mélanine, le kératinocyte la reçoit (p. 61, 64). ATTENTION dans l'`explain` |
| Q18 | B C | BC | rien |
| Q19 | B **C** D (C et D surlignées en vert) | BD | **C** est démentie par le cours : c'est l'épiderme qui est un épithélium pavimenteux stratifié (p. 14) ; **D**, que la copie entoure aussi, est retenue vraie — voir le cas ouvert |
| Q20 | B C | BC | rien |
| Q21 | B **D** E (D surlignée en vert) | BE | **D** est démentie par le cours : la reprogrammation apporte les facteurs de pluripotence, éteints dans la cellule adulte (p. 49). ATTENTION dans l'`explain` |

**Le cas ouvert : Q19 D**, « La peau renferme des cellules épithéliales et des
fibroblastes ». Le vert, couleur des désaccords avec la correction, la couvre
alors que l'étudiant l'a entourée : la correction de 2024 l'a
vraisemblablement cotée **fausse**. Le cours la donne vraie (fibroblastes,
kératinocytes et mélanocytes du revêtement cutané, p. 27 ; culture de
fibroblastes à partir d'une biopsie de peau, p. 20 ; épiderme épithélial et
derme, p. 14-15), l'histologie aussi (Stevens et Lowe). Retenue **vraie** ;
`CONFLITS` déclaré, ATTENTION en tête de sa justification, tag `a-relire`
jusqu'à un corrigé ou une décision de Vincent.

**Un indice venu du sujet de 2025-26** : sa question 23 A, « Les fibroblastes
de la peau sont situés dans l’épiderme » (fausse : ils sont dans le derme),
parle des « fibroblastes de la peau ». Le sujet suivant tient donc pour acquis
que la peau en contient, ce qui appuie la lecture du cours. Dit dans l'`explain`
de `remed-ti2-2526-q23` ; la carte de 2024-25 n'a pas été retouchée, et le cas
reste ouvert.

| Question | Clé vraisemblable de la correction de 2024 (d'après le vert) | Clé retenue | Pourquoi |
|---|---|---|---|
| Q19 | B | BD | D est vraie pour le cours (p. 14, 15, 20, 27) et pour l'histologie ; aucune page ne la rend fausse |

## Les schémas cliquables

| Fichier nu / légendé | Ce qu'on clique | Cartes |
|---|---|---|
| `rsou-peau-nue.svg` / `rsou-peau.svg` (`rsou-zo-peau`) | l'épiderme, la jonction dermo-épidermique, le derme, l'hypoderme | 4 |
| `rsou-epiderme-nu.svg` / `rsou-epiderme.svg` (`rsou-zo-epiderme`) | les couches cornée, granuleuse, épineuse, basale, la lame basale, le derme | 6 |
| `rsou-western-nu.svg` / `rsou-western.svg` (`rsou-zo-western`) | la bande produite par chacune des quatre cellules : témoin M, témoin H, noyau H dans une cellule M, noyau M dans une cellule H | 4 |

- **La peau** est redessinée d'après les p. 15-16, sans une légende : ce qui la
  rend lisible, c'est que l'épiderme n'a aucun vaisseau (p. 10), que la
  jonction ondule et se dessine en bande épaisse (pour qu'on puisse la cliquer),
  que le derme porte fibres, vaisseaux et une glande sudoripare, l'hypoderme ses
  lobules adipeux. Les quatre zones pavent le bloc : les polygones partagent
  exactement les points de l'onde (`HAUT_JONCTION`, `BAS_JONCTION`).
- **L'épiderme** est redessiné d'après les p. 17 et 41 en couches horizontales :
  chaque couche se reconnaît à ses cellules (une rangée cubique, des polygones à
  épines, des cellules aplaties à grains, des écailles sans noyau, dont une se
  détache). Les cellules isolées (mélanocyte, Langerhans, Merkel) ne sont pas
  dessinées : elles feraient des zones dans des zones.
- **Le western blot** reprend la mise en page de la diapositive p. 35 : deux
  membranes, les mêmes quatre pistes et leurs lettres (noyau, cytoplasme), les
  repères de 70 et 20 kDa. La version nue n'a pas de bande ; la question nomme
  la cellule, pas la protéine : il faut savoir quelle membrane et quelle piste.
  La correction montre les quatre bandes (toutes les zones), et la diapositive
  p. 35 en illustration.

## Les illustrations

**55 QCM sur 55** portent une figure en correction : 37 diapositives extraites
en PNG (1100 px de large, réduites à 256 couleurs le 19/10 ; la p. 63, `rsou-transduction.png`,
ajoutée à la relecture), toutes déclarées dans `IMAGES` avec leur page ; 90
notes sur 104 en tout. Les neuf annales de 2025-26 reprennent des figures déjà
déclarées, chacune choisie pour montrer la réponse : les p. 8, 10, 12, 17, 27,
28, 41, 45 et 46. Chaque PNG a été recontrôlé contre sa page. Les trois schémas légendés
illustrent aussi le texte à trous de l'épiderme, la QROC du western blot et le
recto-verso épiderme-derme. Aucune image n'est dans une question, sauf les
trois schémas nus des cartes à zones.

## Le lexique

Quatorze termes, chacun avec son origine grecque ou latine : Épithélium (p. 8,
10, 12, 13, 14), Endothélium (14), Épiderme (14-17, 26, 60), Derme (15-17, 26,
60), Pavimenteux (14), Kératinocyte (17, 27-29, 40, 60-63, 65), Mélanocyte (15,
16, 17, 26, 27-29, 40, 60-63, 65), Mélanine (58, 61, 65), Mélanosome (65),
Fibroblaste (19-23, 27, 40), Totipotent (45, 51), Pluripotent (45, 49, 51),
Multipotent (45, 51), Trophectoderme (51). Les pages réunissent deux mesures :
le texte du PDF, avec `chercher_pages.py` (remesuré à la relecture : identique),
et les figures, dont les légendes sont des images sans texte PDF, lues sur les
pages rendues — Épiderme, Derme et Pavimenteux n'existent que là, et la relecture
a ajouté les figures oubliées : « Épithélium pavimenteux » (p. 14), le schéma de
la peau répété p. 26 (Épiderme, Derme, Mélanocytes), « Mélanocytes » des p. 15
et 16, « Kératinocytes » et « Mélanocyte » de la p. 17.

Identifiants `lex-<terme>-remed` (les `lex-melanocyte`, `lex-totipotent`…
nus existent dans BMCP). Les étymologies — deux racines nouvelles (`-thélium`,
grec θηλή ; `pavimentum (latin)`) et les quatorze termes, dont quatre recopiés
de la table (`lex-melanocyte`, `lex-totipotent`, `lex-pluripotent`,
`lex-multipotent`) — sont versées dans
`.claude/skills/nouveau-chapitre/scripts/etymologies.json`. Les définitions et les
racines disent mot pour mot ce qu'`appliquer_etymologies.py` en écrit (recontrôlé à la relecture, terme par
terme et racine par racine). La relecture a vérifié chaque étymologie dans le
TLFi (« Étymologie et histoire », par l'API du portail cnrtl) et en a corrigé
deux : **pavimenteux**, « dér. sav. du lat. pavimentum », qui veut dire « aire
en terre battue » puis « plancher, carreau », de pavire, « battre (la terre) »
(et non le seul « pavé, pavement » du Wiktionnaire) ; **mélanine**, composé
de mélan(o)- et du suffixe -ine, l'anglais melanin n'étant qu'un « cf. » pour
le TLFi (et non « par l'anglais »). Les entrées du JSON citent désormais le
TLFi. Les racines réemployées gardent la
clé et la page de la FC de sémantique quand elles en ont une (`épi-`, `endo-`,
`ecto-`, `mélan(o)-`, `cyt(o)- / -cyte`, `-blaste`).

Écartés : « autorenouvellement » (formation française), « niche », « micro-ARN »
(le chapitre `remed_gene_proteine` le prendra s'il le veut).

## Les pages sans carte

| Pages | Pourquoi |
|---|---|
| 1 | la page de titre (équipe pédagogique, date) |
| 2, 3, 9, 18, 25, 42, 54 | le sommaire, répété à chaque partie |
| 4, 7, 38, 56, 59 | des questions sans contenu, dont la réponse est la page suivante (cartée) |
| 26 | la question « Quel(s) type(s) cellulaire(s) ? » sur le schéma de la p. 15, répondue p. 27 |
| 55 | le titre de la dernière partie et la photographie « avant / après » d'un bronzage |

Les p. 30 à 34 (l'énoncé et la construction pas à pas du western blot) sont
citées par les cartes de la p. 35 ; la p. 40 répète la p. 27. Les p. 16, 19,
20, 22, 29, 41, 60 et 62 n'ont pas de carte à elles, mais sont citées dans le
texte des cartes voisines ; la p. 60 illustre aussi `rsou-rv-keratinocyte-melanocyte`.

## La relecture du sceptique (18/10/2026)

Toutes les cartes relues, une à une, contre les 66 pages rendues et les photos
IMG_8045-8046 du sujet (et IMG_8047-8048 pour le code des couleurs). Les sept
annales sont conformes mot pour mot (énoncés, propositions, ordre, numéros,
session) et leurs clés sont justes ; les schémas cliquables et les 37 PNG du
rédacteur sont justes. Les corrections :

| Carte | Correction |
|---|---|
| `remed-ti3-2425-q19` et ses voisines | le vert de la copie relu comme la couleur des désaccords avec la correction (preuve : page 9) ; le cas ouvert de D en sort renforcé (correction de 2024 vraisemblablement B), dit dans la justification, l'`explain`, `CONFLITS` et la docstring ; les `explain` de Q15-18, Q20, Q21 disent la présence ou l'absence de vert |
| `rsou-qc-polarite` D | recopiait l'annale Q16 E (« ne présentent pas de polarité ») : remplacée par une lecture du schéma (le noyau près du pôle apical, faux) |
| `rsou-qc-caracteristiques-epitheliums` B | recopiait Q16 C mot pour mot : reformulée |
| `rsou-qc-classification` A | trop proche de Q19 A : reformulée (« les cellules posées sur la membrane basale ») |
| `rsou-qc-exemples-epitheliums` A, B | recopiaient Q17 B et Q17 E : reformulées par les mots du nom (couches, forme, surface) et par la description de l'endothélium |
| `rsou-qc-melanocytes-keratinocytes` D, E | D recopiait Q17 D : reformulée (le pigment fabriqué par le kératinocyte puis cédé au mélanocyte) ; E devient fausse (la mélanine par le sang) : clé BCE → BC |
| `rsou-qc-ips` D | recopiait Q21 C (« totipotentes ») : reformulée (refaire le trophectoderme) |
| `rsou-qc-western-blot` E | faisait cocher vraie « la myosine vers 18 kDa », masse fausse : la proposition inverse les deux masses et devient fausse, l'ATTENTION reste ; clé BCE → BC |
| `rsou-qc-ethique-cse` D | doublon des cartes de la p. 52 : remplacée par un distracteur du même champ (concevoir des embryons pour la recherche) ; clé BCD → BC |
| `rsou-qc-potentialites` C, `rsou-fa-potentialites` | la figure de la p. 45 range « pluripotentes + multipotentes » sous l'embryon implanté et le fœtus, pas les seules multipotentes |
| `rsou-qc-spectre-melanine` A, B | lectures des courbes refaites (l'absorbance de la mélanine vaut environ 0,8 à 400 nm, pas « près de 1 ») |
| `rsou-qc-cs-embryonnaires-adultes` D | la figure de la p. 41 ne place pas les cellules souches dans une couche : la note dit ce que montre la figure, et la couche basale par la référence d'histologie |
| `rsou-qc-csm` B | « deux noms du même facteur » donné comme référence, pas comme diapositive |
| `rsou-rv-keratinocyte-melanocyte` | p53 n'est pas le message soluble : il fait transcrire le gène du facteur sécrété |
| `lex-pavimenteux-remed`, `lex-melanine-remed` | étymologies corrigées sur le TLFi (voir le lexique) |
| `lex-epithelium-remed`, `lex-epiderme-remed`, `lex-derme-remed`, `lex-keratinocyte-remed`, `lex-melanocyte-remed` | pages des figures ajoutées |
| docstring de `donnees.py` | la nuance « post-transcriptionnelle » est dans `rsou-qc-micro-arn` A, pas D |

Deux cartes ajoutées, pour deux pages qui enseignaient sans carte :
`rsou-fa-signalisation` (p. 62-63 : signal, récepteur, molécules relais,
effecteur actif, réponse ; figure `rsou-transduction.png`) et
`rsou-qc-cse-usages` (p. 52 : l'infographie des usages des CSE, clé AC).
Le déplacement de trois clés ramène les QCM à trois vraies de 21 à 18 sur 39.

## La critique d'ensemble (19/10)

Un critique a relu les quatre chapitres de l'ECL ensemble. Ici :
- **Deux figures déclarées, aucune carte** : la p. 60 (un mélanocyte pour dix
  kératinocytes basaux) illustre maintenant le recto-verso kératinocyte et
  mélanocyte ; la p. 29, une question sans contenu, est retirée d'`IMAGES` et
  de `media/`.
- **La fin de la totipotence** : la figure p. 45 la place au 4e jour, la BMCP
  au stade de 8 cellules (`bmcp_cellules_souches`). `rsou-fa-potentialites` et
  `rsou-rv-toti-pluri` le disent : à chaque examen, la borne de son UE.
- **Le poids des figures** : les PNG passent à 256 couleurs, de 7,8 à 2,8 Mo,
  relus après réduction.
- **Le nombre de pages du sujet** : `src-remed-ti3-2425` dit 15 pages (IMG_8053
  est la page 15, la page 6 manque), à l'identique dans `remed_gene_proteine`.

## La relecture du sceptique du test de 2025-26 (26/10/2026)

Les neuf questions relues contre le texte du sujet (énoncés, cinq propositions,
ordre : conformes mot pour mot) et contre les pages rendues du cours (p. 5, 12,
15, 17, 20, 23, 27, 41, 45, 46, 50, 61, 64-66, et immuno1 p. 26). Les neuf
clés sont confirmées ; les reprises de 2024-25 gardent leur verdict ; les
figures montrent bien la réponse. Les corrections :

| Carte | Correction |
|---|---|
| `remed-ti2-2526-q21` B | la justification écartait la référence (« un même destin ») : ATTENTION, les deux lectures, `CONFLITS` ; reste fausse |
| `remed-ti2-2526-q27` B | la culture en O2 bas existe et favorise fibroblastes et cellules souches : ATTENTION, les deux lectures, `CONFLITS` ; reste fausse. L'O2 d'une étuve ordinaire : un peu moins de 20 %, pas « autour de 20 % » |
| `remed-ti2-2526-q24` D | la citation « ne peuvent pas refaire le trophectoderme » (p. 51) était prêtée aux iPS : elle dit les cellules souches embryonnaires, auxquelles la p. 49 compare les iPS |
| `remed-ti2-2526-q27` A | ajout du cours d'immunologie du même test (immuno1 p. 26 : la cellule dendritique de la peau) |
| `remed-ti2-2526-q27` D | l'article L. 2151-2 du Code de la santé publique vérifié (interdiction de concevoir un embryon pour la recherche, rédactions de 2011 et de 2021) |

## À relire

**1 carte** porte le tag `a-relire` : `remed-ti3-2425-q19` (le cas ouvert de
la proposition D, voir plus haut). Le tag se retire quand un corrigé du test
de 2024 tranche, ou quand Vincent garde la lecture du cours.

Dix cartes tirées au hasard ont été relues contre les pages : `rsou-fa-milieu`,
`lex-derme-remed`, `lex-pluripotent-remed`, `rsou-qc-etuve`,
`lex-melanine-remed`, `rsou-qc-ips-usages`, `rsou-rv-regulations`,
`remed-ti3-2425-q17` (transcription comprise), `rsou-qc-cse-pluripotentes`,
`rsou-qr-abm` : toutes retrouvées à leur page.

## Régénérer

```powershell
cd contenu\chapitres\remed_souches
..\..\..\app\.venv\Scripts\python.exe generer.py
```

`generer.py` est la copie exacte de
`.claude/skills/nouveau-chapitre/scripts/generer_modele.py`. Les figures sont
versionnées dans `media/` ; chacune dit sa page dans `IMAGES`. Pour en refaire
une, rendre la page du PDF à 1100 px de large et la recadrer sur la figure.
