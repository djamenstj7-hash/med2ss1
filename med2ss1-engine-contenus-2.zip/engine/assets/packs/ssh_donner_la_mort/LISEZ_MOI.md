# Éthique : donner la mort — paquet SSH

90 notes, 180 cartes. Chapitre `chap-ue-ssh-fc6` de l'UE SSH (examen écrit
du 6 janvier 2027, « 10 QROC + 1 QR »). **La base est le ronéo Ronéo &
Juliette 2026-27 « Éthique - Donner la mort »**, cours du **Pr Devinant** du
29/09/2026, 9 h-11 h, 6 pages. Réaligné sur lui le 11/10/2026 ; le chapitre
était carté depuis le 05/10 sur le Ronéosaure 2025-26 (FC n°5 du 30/09/2025 et
FC n°7 du 17/10/2025), qui reste la source de tout ce que le ronéo 2026-27 n'a
pas encore traité. Annales : le polycopié SSH 6 du Ronéosaure 2024-25 (deux
Q.R), une QROC que la FC n°7 2025-26 imprime elle-même (p. 10), et la même QROC
posée mot pour mot au sujet de 2024/2025, déposé le 15/10/2026.

**18/10/2026** : 1 recto-verso du sujet de SSH 2025/2026 (examen du
09/01/2026, sans corrigé) — QROC 4 ; voir « Le sujet 2025/2026 ».

**Le cours continue.** Le ronéo 2026-27 s'arrête sur « À quoi tient encore le
débat autour de l'euthanasie ? » (p. 6) : la suite — les arguments des
soignants, l'éthique minimaliste, la sédation, l'éthique de la mise à mort,
puis toute la partie 2 (tuer et laisser mourir, l'utilitarisme, le double
effet) — n'est pas encore parue. Ses cartes restent sur la FC 2025-26, avec le
badge « Cours 2025-26 », et sont listées plus bas (« En attente des ronéos
suivantes »).

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 18 | 18 |
| QRU | 1 | 1 |
| Texte à trous | 15 | 98 |
| QROC | 25 | 25 |
| Recto-verso | 17 | 17 |
| Schéma cliquable | 2 | 9 |
| Lexique | 12 | 12 |

Dont **5 annales**, toutes rédactionnelles, donc en recto-verso
(`ANNALES_QROC`, `type="basic"`), sur 5 sessions (2022/2023, S1 et S2 ; 2024/2025 S1 ; 2025/2026 S1). Les 19
QCM sont des questions de cours, une justification par proposition ; ils
portent les pièges, puisque l'examen n'a pas de QCM. **17 QCM sur 19 (89 %)**
montrent une figure en correction ; 57 notes sur 90 en ont une. **5 cartes
absentes du cours 2026-27** (tag `absent-2026`), **9 cartes portent un piège
du ronéo** (thème « Pièges des ronéos »), 1 carte `a-relire`.

Huit thèmes, dans l'ordre du cours, déjà dans `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) ; le réalignement n'en ajoute
aucun : `dilemme-tramway`, `debat-euthanasie`, `definition-euthanasie`,
`legislation-euthanasie`, `personne-tuer`, `tuer-laisser-mourir`,
`utilitarisme`, `double-effet`.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-ssh-mort-2627` — « ÉTHIQUE_ DONNER LA MORT » (6 p.), `SSH/…` | **2026-27** | **la fiche** (`SRC["fiche"]`, `chapitre=`) : 41 notes la citent à leur page |
| `src-fc-ssh-mort-1` — « FC n°5 Euthanasie, donner la mort » (9 p.) | 2025-26 | appoint, sans `chapitre=` : la source des cartes en attente de la partie 1 (p. 7-9) et des 5 cartes absentes (`fiche=F1`) |
| `src-fc-ssh-mort-2` — « FC n°7 éthique donner la mort » (10 p.) | 2025-26 | appoint, sans `chapitre=` : la partie 2, que le ronéo 2026-27 n'a pas encore atteinte (`fiche=F2`) ; la QROC 7 de 2022/2023 (p. 10) |
| `src-fc-ssh-causalite-2526-pt2` — « FC n°4 La causalité en médecine pt2 » | 2025-26 | appoint : ses deux diapositives du tramway (p. 6) ; plus aucune carte ne la cite à une page |
| `src-annales-ssh-6-ethique-donner-la-mort` — « SSH 6 - Ethique _ donner la mort » | 2024-25 | les deux Q.R de 2022/2023 |
| `src-sujets-ssh-2425` — « Sujets de SSH 2024/2025, session 1 » (examen du 10/01/2025, 1 QR et 10 QROC, sans corrigé), déposés le 15/10/2026 | 2024-25 | la source de la session 2024/2025 S1 (`SRC["sessions"]`), la QROC 7 ; déclarée à l'identique dans tous les chapitres de SSH qui en cartent une question |
| Ronéosaure 2024-25, FC n°6 ; Charonéo 2023-24, n°10 | 2024-25, 2023-24 | lus pour départager les années du professeur (le « palier » néerlandais, « arrêter » le tramway), cités dans le texte, non déclarés |

Le tableau des erreurs SSH 2026-27 de la promo n'a aucune entrée sur ce cours
au 11/10. Vérifications hors du cours, citées dans la carte qui s'en sert :
Légifrance (loi n° 2026-794 du 18 août 2026 ; code de la santé publique,
L. 1111-12-1 à L. 1111-12-5, R. 4127-38 ; code de la sécurité sociale,
L. 160-14 et L. 160-15 ; code pénal, 122-4, 221-1, 221-6, 223-6 ; la note de
la loi : lecture définitive du 15 juillet 2026, décision n° 2026-910 DC),
Actu-Juridique (291 voix contre 241), APHP (la décision et ses trois
réserves), commissions régionales de
contrôle néerlandaises (RTE, rapport 2025 : kamerstuk 32647 n° 112),
Commission fédérale belge de contrôle et d'évaluation de l'euthanasie
(chiffres 2024 et 2025), United States Holocaust Memorial Museum (le programme
nazi dit « euthanasie »), CCNE (avis 63, 121, 139), CESE (rapport de la
Convention citoyenne, avril 2023 : 76 % pour une aide active à mourir), Thomson
(1976, 1985) ; l'étymologie (TLFi, Gaffiot, Wiktionnaire).

## La loi, au 11/10/2026

La **loi n° 2026-794 du 18 août 2026 relative au droit à l'aide à mourir**
est adoptée définitivement le 15 juillet 2026 (vote de l'Assemblée nationale,
291 voix contre 241), validée par le Conseil constitutionnel le 14 août
(décision n° 2026-910 DC, trois réserves d'interprétation), promulguée le
18 août, publiée au JO du 19 août 2026. Elle crée dans le code de la santé
publique le droit, pour une personne qui l'a demandé, d'être autorisée à
recourir à une substance létale, qu'elle s'administre ou, si elle n'en est pas
physiquement capable, qu'un médecin ou un infirmier lui administre
(L. 1111-12-1) ; cinq critères cumulatifs (L. 1111-12-2) ; une demande à un
médecin hors de la famille, jamais en téléconsultation (L. 1111-12-3) ; une
procédure collégiale, une décision du médecin notifiée en quinze jours, un
délai de réflexion d'au moins deux jours, une réévaluation au-delà de trois
mois (L. 1111-12-4) ; une prise en charge intégrale par l'Assurance maladie ;
l'irresponsabilité pénale des soignants (code pénal, 122-4) et une clause de
conscience. Elle est en vigueur, mais ses textes d'application manquaient
encore fin août ; au 29/09, dit le cours, aucune aide à mourir n'avait eu lieu
dans les hôpitaux. Le ronéo 2026-27 la présente (p. 5-6) : elle se carte ici
(`mort-qc-loi-france`, `mort-qc-loi-2026`, `mort-qc-procedure-2026`,
`mort-fa-loi-2026`, `mort-fa-procedure-2026`, `mort-qr-auto-administration`,
`mort-rv-article-38-loi`, et le schéma `aide-a-mourir-2026.svg`). Les cartes
qui disent encore le droit d'avant la loi (`mort-qr-peine`, absente ;
`mort-qc-tuer-laisser` B, en attente) le signalent.

## Le réalignement du 11/10/2026

- **41 notes citent le ronéo 2026-27** à leur page : 26 notes anciennes
  relues, 9 notes nouvelles, 6 termes de lexique.
- **Réécrites** sur le ronéo (18) : les textes à trous `mort-fa-tramway`,
  `-distanciation`, `-pourquoi-debat`, `-definition`, `-abstention`,
  `-autres-pays` ; les QCM `mort-qc-tramway` (D, E : l'utilitarisme compare
  5 vies contre 1, l'éthique déontologique suit une règle morale),
  `-distanciation` (C), `-pourquoi-debat` (B : le caractère sacré de la vie),
  `-criteres` (B : l'animal de compagnie), `-ne-pas-confondre` (C, E),
  `-loi-france` (entier : la loi de 2026, l'Assurance maladie, l'article 38,
  le CCNE, la Convention citoyenne), `-pays` (C et la clé, ABD → ABCD : le
  cours dit une stabilisation, à l'examen « vrai ») ; les recto-verso
  `mort-rv-euthanasie-aide`, `-active-passive`, `-consequences-intentions` ;
  les QROC `mort-qr-aide-suicide`, `-passive`.
- **Confirmées** (8 : page et explication) : `mort-qr-foot`, `-thomson`,
  `-cadre-utilitariste`, `-medicalisation`, `-convention`, `-etymologie`,
  `-article-38`, la grille `mort-zo-actes`.
- **Nouvelles** (9) : `mort-qc-loi-2026` (les cinq critères),
  `mort-qc-procedure-2026`, `mort-qc-mesusages` (QRU : l'animal de compagnie,
  le programme nazi, l'accident, l'aide au suicide), `mort-fa-loi-2026`,
  `mort-fa-procedure-2026`, `mort-qr-trolleologie`,
  `mort-qr-auto-administration`, `mort-rv-dignite` (les deux conceptions de la
  dignité), `mort-rv-article-38-loi` ; et trois termes de lexique.
- **Ce que le cours 2026-27 change** : la loi d'août 2026 remplace l'état du
  droit de 2025-26 (l'homicide volontaire, le CCNE « défavorable ») ;
  l'abstention thérapeutique était la solution principale « jusqu'en août » ;
  le tramway se lit avec deux éthiques, utilitariste et déontologique, sans
  Kant ; l'exemple du mésusage est l'animal de compagnie (2025-26 : de
  laboratoire) et le programme nazi ; deux conceptions de la dignité entrent
  dans le débat ; les Pays-Bas connaissent un « afflux » stabilisé (2025-26 :
  pas d'explosion) et la Belgique « le même phénomène » ; l'Oregon et
  l'acharnement thérapeutique ne sont plus nommés.
- Les détails propres à 2025-26 que garde une carte relue sont dits dans son
  texte, avec leur source (« FC n°5 2025-26, p. 5 »).
- **Relecture critique (11/10)** : chaque carte nouvelle ou réécrite relue sur
  sa page du ronéo ; la loi vérifiée article par article sur Légifrance
  (L. 1111-12-1 à L. 1111-12-5 et L. 1111-12-12, R. 4127-38 inchangé depuis
  2004), le vote du 15 juillet et la décision n° 2026-910 DC ; les chiffres
  néerlandais et belges sur les rapports 2025. Trois corrections : le programme
  nazi « d'avant guerre » n'est plus un point douteux (`mort-qc-mesusages` A,
  précisé sans ATTENTION) ; le « palier » néerlandais de `mort-an-2223-qroc7`
  porte son genre, (cours) ; les 76 % de la Convention citoyenne ne sont plus
  attribués à la FC n°5, qui ne donne aucun chiffre (`mort-qr-convention`).

## En attente des ronéos suivantes

Le ronéo 2026-27 n'a pas encore traité ces notions : leurs cartes restent sur
la FC 2025-26, inchangées, avec le badge « Cours 2025-26 ». Elles se relisent
à la parution de la suite.

| Notion (cours 2025-26) | Cartes |
|---|---|
| Les trois arguments des soignants, l'opinion (FC n°5, p. 7) | `mort-fa-opinion`, `mort-qc-resistances` |
| L'éthique minimaliste, les plus vulnérables, le Canada (FC n°5, p. 7-8) | `mort-qc-minimaliste`, `mort-qr-ogien`, `mort-rv-minimaliste` |
| La sédation, « demi-euthanasie » (FC n°5, p. 8) | `mort-rv-sedation` |
| L'éthique de la mise à mort : la personne et l'organisme (FC n°5, p. 8-9) | `mort-fa-personne`, `mort-qc-personne`, `mort-qr-higher-brain`, `mort-rv-vie-personne`, `lex-sentience` |
| Tuer et laisser mourir, Rachels (FC n°7, p. 2-3) | `mort-fa-rachels`, `mort-qc-tuer-laisser` |
| L'utilitarisme : culpabilité, calcul des chances, pente glissante, Beauchamp (FC n°7, p. 3-6) | `mort-qc-arguments`, `mort-qr-petition`, `mort-qr-immobilisme`, `mort-qr-incommensurabilite`, `mort-rv-calcul-chances`, `mort-fa-pente-glissante`, `mort-qc-pente`, `mort-qr-regle`, `lex-consequentialisme`, `lex-petition-de-principe`, `lex-pente-glissante` |
| La déontologie : Claeys-Leonetti, le double effet, Foot, le principisme (FC n°7, p. 6-9) | `mort-qr-principe-loi`, `mort-fa-double-effet`, `mort-qc-double-effet`, `mort-qr-aquin`, `mort-rv-voulu-prevu`, `mort-zo-double-effet`, `mort-qc-foot`, `mort-qr-obligations`, `mort-rv-obligations`, `mort-rv-critique-foot`, `mort-fa-principisme`, `mort-qc-principisme`, `mort-qr-primum`, `lex-double-effet`, `lex-principisme` |

33 notes de cours et 6 termes de lexique. Les annales de 2022/2023 S2 (le
chirurgien, Foot) et les deux QROC 7 (la pente glissante) s'appuient aussi sur cette
suite. La case « soulager au risque d'abréger » de la grille `mort-zo-actes`
vient de la FC n°7 2025-26, p. 6.

## Absent du cours 2026-27

Cinq cartes entières, dans des sections que le ronéo 2026-27 couvre en
entier, `ABSENTS_2026` (origine : `ORIGINE_ABSENTS`, la FC n°5 2025-26) :

| Carte | Ce que le cours 2025-26 disait | Ce que dit le ronéo 2026-27 |
|---|---|---|
| `mort-qr-kant` | Kant : traiter autrui comme une fin, non comme un moyen (p. 3) | l'éthique déontologique, sans Kant (p. 3) |
| `mort-fa-aide-suicide` | l'Oregon, Death with Dignity Act, 1997, six mois (p. 5) | « certains états et pays de manière très encadrée » (p. 4) |
| `mort-qr-oregon` | l'Oregon (p. 5) | idem |
| `mort-qr-acharnement` | l'abstention s'oppose à l'acharnement (escalade) thérapeutique (p. 5) | l'abstention thérapeutique sans l'acharnement (p. 4) ; la notion reste au chapitre des droits des malades (obstination déraisonnable) |
| `mort-qr-peine` | l'euthanasie, un homicide volontaire, trente ans (p. 6) | la loi d'août 2026 (p. 5-6) |

Les propositions d'une autre année que gardent des QCM relus (la
non-assistance à personne en danger, la Belgique en 2002, le Canada, l'Oregon)
le disent dans leur propre justification.

## Ce que le cours a dicté

- **Ni rouge, ni gris** dans le ronéo 2026-27. Ce que le professeur appuie a
  sa carte : la distanciation, « un concept essentiel en médecine », et l'effet
  désimpliquant de la robotisation (`mort-fa-distanciation`,
  `mort-qc-distanciation`) ; « il est important en éthique d'avoir des bases
  stables » ; « il faut des caractéristiques minimales pour pouvoir parler
  d'euthanasie » (`mort-qc-mesusages`, `mort-qc-criteres`).
- **Les frontières** : la sédation profonde et continue, l'obstination
  déraisonnable et les soins palliatifs sont du chapitre « Droits des
  personnes malades » (FC n°14) ; la loi d'août 2026, que le ronéo présente,
  se carte ici. La mort cérébrale est au chapitre de littérature.

## Ce que les annales ont dicté

| Poly | Session | N° | Corrigé imprimé | Sujet | Carte |
|---|---|---|---|---|---|
| SSH 6 | 2022/2023 S1 | Q.R | « Pas de corrections officielles » | *Une mort très douce* (S. de Beauvoir) : le titre, les justifications du mensonge, le type de raisonnement, le problème | `mort-an-2223s1-qr` |
| SSH 6 | 2022/2023 S2 | Q.R | grille de correction, sans accolades : **officielle** | le chirurgien David (J. J. Thomson) : levier ou pont, et les intuitions selon Foot | `mort-an-2223s2-qr` |
| FC n°7 2025-26, p. 10 | 2022/2023 | QROC 7 | corrigé des rédacteurs | la pente glissante et son rôle dans le débat | `mort-an-2223-qroc7` |
| sujet 2024/2025 | 2024/2025 S1 | QROC 7 | aucun (sujet sans corrigé) | la même, mot pour mot, au même rang | `mort-an-2425s1-qroc7` |

Relues sur le ronéo 2026-27 : aucune clé ne change. La correction de 2022/2023
S2 montre désormais la figure du ronéo 2026-27 (la passerelle, p. 2) ; sa
partie Foot et double effet, comme la pente glissante, attend la suite du
cours.

## Le sujet 2025/2026 (18/10/2026)

Les sujets de SSH de l'examen du 09/01/2026 (1 QR, 10 QROC,
`src-sujets-ssh-2526`, sans corrigé), déposés le 18/10/2026, apportent 1
recto-verso à ce chapitre (QROC 4). Aucun n'était déjà en cartes. Au verso, la
bonne réponse, tirée du ronéo 2026-27 quand il couvre la notion, sinon du
cours 2025-26, celui de l'année de l'examen ; ce qui dépasse le cours est dit
« hors cours », avec sa source (`officielle=False`). Rédigés et
contre-vérifiés le 18/10/2026 : un rédacteur, un sceptique, un critique de
complétude.

| Question | Ce que le verso répond | Voisine de |
|---|---|---|
| 2025/2026 S1 QROC 4 (`mort-an-2526s1-qroc4`) | le double effet (déontologique) dans la première réplique, la pente glissante (conséquentialiste) dans la seconde | `mort-an-2425s1-qroc7` |

Ce qui est signalé :

- La QROC 4 fait reconnaître, dans un échange, la doctrine du double effet et la
  pente glissante ; voisine de 2024/2025 S1 QROC 7 (la pente glissante seule).
  Le verso cite la loi d'août 2026 sur l'aide à mourir (ronéo 2026-27, p. 5-6)
  comme limite fixée collectivement.
- ATTENTION nu dans l'explication : « Tom Beauchamps » (FC n°7, p. 6) pour Tom
  L. Beauchamp ; carte ajoutée à la liste des ATTENTION du Ronéosaure.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2022/2023 S1 Q.R (Beauvoir) | aucune (« Pas de corrections officielles ») | clé déduite, `officielle=False`, `a-relire` | le livre de 2022-23 n'est dans aucun cours lu ; la partie éthique vient du cours (l'éthique utilitariste et l'éthique déontologique, ronéo 2026-27 p. 3 ; le calcul des chances ; le paternalisme et l'autonomie ; le droit à l'information, FC n°14) ; la partie sur le livre n'a été vérifiée que sur des sources secondaires |
| 2022/2023 QROC 7 (pente glissante) | corrigé des rédacteurs (FC n°7, p. 10) | le corrigé, complété du cours (p. 4-6), `officielle=False` | non officiel ; absente du polycopié, session non précisée ; le « palier » néerlandais est signalé (ATTENTION (cours) : le ronéo 2026-27 le redit) |
| 2022/2023 S2 Q.R (chirurgien) | grille officielle | la grille, `officielle=True` | conforme au cours |
| 2024/2025 S1 QROC 7 (pente glissante) | aucune (sujet sans corrigé) | clé déduite, le verso de 2022/2023 QROC 7 repris tel quel, revérifié sur la FC n°7 (p. 4-6), `officielle=False` | reprise mot pour mot de 2022/2023 QROC 7 ; même ATTENTION (cours) sur le « palier » néerlandais |

Aucune question à choix : `CONFLITS = []`.

## Les erreurs du ronéo 2026-27

Chacune est dite dans la carte qui porte la notion, avec son genre ; elles
vont dans `contenu/ERRATA_RONEOS_2026-27.md`.

| Page | La ronéo dit | Ce qui est juste | Source | Genre | Carte |
|---|---|---|---|---|---|
| 2 | on pousse la personne sur les voies « pour faire dérailler le train » | le corps de l'homme corpulent **arrête** le tramway | Ronéosaure 2024-25, FC n°6, p. 3 ; FC n°4 2025-26, p. 6 ; Thomson (1976, 1985) | prise de notes | `mort-fa-tramway` |
| 5 | la loi « votée en août de cette année » | adoptée définitivement le **15 juillet** 2026 ; validée le 14 août (n° 2026-910 DC) ; promulguée le 18 août (JO du 19) | Légifrance ; Actu-Juridique | prise de notes | `mort-qc-loi-france` A, `mort-fa-loi-2026` |
| 6 | « être français ou résident en France depuis longtemps » | résider « de façon stable et régulière » en France, sans durée | CSP, L. 1111-12-2, 2° | prise de notes | `mort-qc-loi-2026` B |
| 6 | une souffrance « absolument réfractaire, c'est-à-dire qui ne répond pas aux traitements » | réfractaire aux traitements, **ou** insupportable quand la personne a refusé ou arrêté un traitement ; jamais une souffrance psychologique seule | CSP, L. 1111-12-2, 4° | prise de notes | `mort-qc-loi-2026` D |
| 6 | « La décision est prise de manière collégiale. Le médecin ne prend donc pas la décision tout seul » | la **procédure** est collégiale ; la décision est prise par le médecin, à son issue | CSP, L. 1111-12-4, II et IV | prise de notes | `mort-qc-procedure-2026` C |
| 6 | au-delà de trois mois « depuis la demande », « revérifier la demande » | trois mois après la **notification de la décision** ; le médecin réévalue la volonté libre et éclairée | CSP, L. 1111-12-4, V | prise de notes | `mort-qc-procedure-2026` E |
| 5 | **le cours lui-même** : aux Pays-Bas, un afflux « qui a mis une quinzaine d'années à se stabiliser », « environ 6000 demandes par an » | à l'examen : stabilisé autour de 6 000 par an. La référence : 6 126 (2018), 6 361 (2019), 9 068 (2023), 9 958 (2024), 10 341 (2025, 5,97 % des décès) signalements : une hausse continue, pas un palier | RTE, rapport 2025 (kamerstuk 32647 n° 112) ; le professeur le dit en 2024-25 et 2025-26 | cours | `mort-qc-pays` C, `mort-fa-autres-pays`, `mort-an-2223-qroc7`, `mort-an-2425s1-qroc7` |
| 5 | « En Belgique on a pu observer le même phénomène » | point douteux : un afflux, oui ; une stabilisation, non — 2 966 (2022), 3 423 (2023), 3 991 (2024), 4 486 (2025) | Commission fédérale belge (CFCEE) | douteux | `mort-qc-pays` B, `mort-fa-autres-pays` |

Sans ATTENTION, parce qu'aucune réponse n'en dépend : « l'utilitarisme
conséquent » (p. 2, pour conséquentialiste) ; « the doctrine of the double
effet » (p. 2) ; l'évaluation qui « prend 15 jours » (p. 6 : un délai de
quinze jours au plus, dit `mort-fa-procedure-2026`) ; « 6000 demandes » pour
des euthanasies signalées (dit dans l'ATTENTION des Pays-Bas). **Le programme
nazi « d'avant guerre » (p. 3) n'est pas une erreur** : il se prépare au
printemps et à l'été 1939, avant la guerre, et tue surtout pendant, à partir de
l'automne 1939 (USHMM) ; « les handicapés mentaux » laisse de côté les
handicaps physiques. `mort-qc-mesusages` A le précise, sans ATTENTION. La
première version du réalignement en faisait un point douteux ; la relecture
l'a retiré.

## Les erreurs du Ronéosaure 2025-26

Dites par un **ATTENTION** nu, sans genre, dans les cartes qui citent encore
la FC 2025-26 : « homicide involontaire » (FC n°5, p. 6 ; errata de la promo :
volontaire → `mort-qr-peine`, absente) ; « Johns » (FC n°7, p. 3 →
`mort-fa-rachels`) ; « Tom Beauchamps » (FC n°7, p. 6 → `mort-qc-pente` E,
`mort-qr-regle`, `mort-an-2526s1-qroc4`) ; « Primum non nocer », « non-malfaissance » (FC n°7, p. 9 →
`mort-fa-principisme`, `mort-qr-primum`) ; Thomas d'Aquin « théologien de la
monastique » (FC n°7, p. 7 → `mort-qr-aquin`) ; les soins palliatifs « vers la
fin des années 90 » (FC n°5, p. 7 → `mort-qc-resistances`). « Phillipe Foot »
(FC n°4, p. 6) n'est plus qu'une remarque de `mort-qr-foot`, qui cite le ronéo
2026-27, juste. Le CCNE « défavorable » (FC n°5, p. 6) est corrigé par le cours
lui-même : en 2026-27, son dernier avis a mené au questionnement sur la
légalisation (`mort-qc-loi-france` D). Le « palier » néerlandais est devenu
l'ATTENTION (cours) du ronéo 2026-27, y compris dans `mort-an-2223-qroc7` et sa
reprise de 2024/2025, `mort-an-2425s1-qroc7`, puisque le ronéo 2026-27 le redit.

**Point douteux, non tranché** (inchangé) : le « À retenir » de la FC n°7, p. 3
(« ni moralement bon ni mauvais »), cité par `mort-qc-tuer-laisser` E sans
qu'aucune clé ne le prenne à rebours.

## Les schémas et les figures

| Fichier | Rôle | Cartes |
|---|---|---|
| `tramway-levier-2627.png`, `tramway-pont-2627.png` | **les deux figures du ronéo 2026-27** (p. 2), extraites telles que le PDF les embarque | les cartes du tramway relues sur 2026-27, `mort-qc-foot`, l'annale 2022/2023 S2 |
| `actes-fin-de-vie-nu.svg` (à cliquer) et `actes-fin-de-vie.svg` | la grille : qui accomplit le geste × ce qui cause la mort ; quatre cases (euthanasie, aide au suicide, soulagement à double effet, abstention thérapeutique) | `mort-zo-actes` et les cartes de définition ; la légende de l'aide au suicide dit désormais « principe de la loi 2026 », les notes de zone citent le ronéo 2026-27 |
| `aide-a-mourir-2026.svg` (nouveau) | la loi du 18 août 2026 : les cinq critères à gauche, la procédure en cinq étapes à droite, la prise en charge, la clause de conscience, l'article 38 | les cartes de la loi |
| `double-effet-nu.svg` (à cliquer), `double-effet.svg`, `personne-organisme.svg`, `arguments-debat.svg`, `smith-jones.svg`, `pente-glissante.svg`, `principisme.svg` | inchangés : ils illustrent les cartes en attente | — |
| `tramway-levier.png`, `tramway-pont.png` | les diapositives 2025-26 (FC n°4, p. 6), avec leurs références (Foot, 1967 ; Thomson, 1985) | `mort-qr-kant` (absente) ; la première reste déclarée pour sa référence |

## Le lexique

Douze termes, pages mesurées dans le texte des PDF (`chercher_pages.py`) ; les
pages du ronéo 2026-27 viennent en tête et font la provenance :

| Terme | Pages | Racines |
|---|---|---|
| Euthanasie | ronéo 2026-27 p. 2-6 ; FC n°5 p. 4-8 ; FC n°7 p. 2, 4-6, 9-10 | eu- ; thanatos (grec) |
| Abstention thérapeutique | ronéo 2026-27 p. 4 ; FC n°5 p. 5-6 ; FC n°7 p. 2, 6 | ab- (latin) ; tenere (latin) ; -thérapie |
| Utilitarisme | ronéo 2026-27 p. 2 ; FC n°5 p. 2 ; FC n°7 p. 3, 6, 9 | utilitas (latin) |
| **Aide au suicide** (nouveau) | ronéo 2026-27 p. 4 ; FC n°5 p. 5-6 | adjutare (latin) ; sui (latin) ; -cide (latin) |
| **Aide à mourir** (nouveau) | ronéo 2026-27 p. 5 ; FC n°5 p. 7-8 | adjutare (latin) ; mori (latin) |
| **Létal** (nouveau) | ronéo 2026-27 p. 5 (« létale ») ; FC n°5 p. 5 | letum (latin) |
| Conséquentialisme, Sentience, Pétition de principe, Pente glissante, Double effet, Principisme | FC 2025-26 seulement (en attente) | inchangées |

**L'étymologie est proposée, pas encore dans la table** : `etymologies.json`
n'a pas été touché. Les quatre racines nouvelles (`adjutare (latin)`, `sui
(latin)`, `mori (latin)`, `letum (latin)`) et les trois termes nouveaux, avec
leurs sources (TLFi, Gaffiot), rejoignent les six racines et neuf termes déjà
proposés dans `etym/ssh_donner_la_mort.json` ; les textes du `LEXIQUE` sont
écrits comme `appliquer_etymologies.py` les écrirait. `-cide (latin)` est
reprise de la table à sa clé exacte.

## À relire

**Une carte** porte `a-relire` : `mort-an-2223s1-qr` (*Une mort très douce*).
Sa partie éthique est tirée du cours ; sa partie sur le livre n'a été vérifiée
que sur des sources secondaires, pas sur le texte de Beauvoir (Gallimard,
1964). Le tag se retire après lecture du récit.

## Questions pour Vincent

- (11/10) Cinq cartes sont marquées « Absent du cours 2026-27 » : mort-qr-kant, mort-fa-aide-suicide, mort-qr-oregon, mort-qr-acharnement et mort-qr-peine. La ronéo remplace Kant par l'éthique déontologique (Kant n'est pas non plus dans la partie 2 de 2025-26) et l'Oregon par « certains états et pays ». Elle ne nomme plus l'acharnement, et la loi de 2026 remplace l'homicide volontaire. Si le diaporama du Pr Devinant les montre encore, faut-il les retirer d'ABSENTS_2026 ?
- (11/10) La ronéo du 29/09 s'arrête sur « À quoi tient encore le débat » et 39 notes attendent la suite : les arguments des soignants, l'éthique minimaliste, la sédation, la personne, puis toute la partie 2. La suite de « Donner la mort » est-elle déjà prévue dans une prochaine ronéo ?
- (11/10) Les erreurs de la ronéo sur la loi (votée en août, « depuis longtemps », « absolument réfractaire », décision collégiale, « depuis la demande ») sont classées « prise de notes », comme le veut la convention de la liste : une erreur prouvée par une source sûre, sans preuve que le professeur l'enseigne. Si le diaporama les reprend, elles passent en « cours ». L'as-tu sous la main ?
- (11/10) As-tu « Une mort très douce » sous la main ? Il permettrait de retirer le tag a-relire de mort-an-2223s1-qr.
- (11/10) Faut-il un EXAMENS `exam-ssh-jan-2027` (6 janvier 2027) pour toute l'UE SSH ?

1. **Les cinq cartes absentes** (Kant, l'Oregon ×2, l'acharnement, la peine) :
   le ronéo 2026-27 les remplace dans des sections qu'il couvre en entier. Si
   le diaporama du Pr Devinant les montre encore, elles repassent en cartes
   ordinaires en les retirant d'`ABSENTS_2026`.
2. **`ordre` en double** : ce chapitre et `ssh_epistemologie` ont `ordre=5` ;
   en 2026-27, l'épistémologie (23-25/09) précède ce cours (29/09). Rien n'est
   changé ici.
3. **Le PDF de l'année** : `uv run python ../outils/copier_les_cours.py
   "<dossier des ronéos 2026-27>"`, hors du bac à sable, pour que
   `SSH/ÉTHIQUE_ DONNER LA MORT.pdf` s'ouvre dans l'application.
4. **Le sujet 2022/2023 S1** porte sur le livre de 2022-23. As-tu *Une mort très
   douce* sous la main, pour retirer le `a-relire` ?
5. **`EXAMENS`** : aucun chapitre SSH n'en déclare ; un seul
   `exam-ssh-jan-2027` (6 janvier 2027) pour toute l'UE, si tu le veux.

## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier (BMCP) ou du 6 janvier (SSH, papier). Sous les annales, 15 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 3 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `utilitarisme` | 7 | 2 | 3 |
| `double-effet` | 8 | 1 | 2 |

**Le schéma** `ech-donner-la-mort`, « Le tramway, le double effet, la pente glissante », donne 19 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_DONNER_LA_MORT`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Constantes ajoutées** à `annales.py` (`_SCHEMA_LETTRES`, `_SCHEMA_NU`) : les annales de SSH sont toutes des QROC, rangées dans `ANNALES_QROC` ; chacune reçoit le schéma nu, et les marches la préparent sans lettre.

**Sans marche** :
- mort-an-2223s1-qr : tout ce qui tient au livre de 2022-23, « Une mort très douce » de Simone de Beauvoir (le titre, le mensonge de la « péritonite ») — absent de tous les cours lus ; seule la partie éthique a ses marches (s4, s5, m3)
- mort-an-2223s1-qr : le paternalisme et Kant — Kant est « Absent du cours 2026-27 » (mort-qr-kant), sans marche
- mort-an-2223-qroc7 et mort-an-2425s1-qroc7 : le « palier » néerlandais, que porte l'ATTENTION (cours) des deux annales — volontairement sans marche
- mort-an-2526s1-qroc4 : la loi d'août 2026 comme limite fixée collectivement — le ronéo 2026-27 la porte (p. 5-6), mais ses erreurs de prise de notes rendraient la marche tributaire de quatre ATTENTION ; laissée aux cartes de cours

## Régénérer

```powershell
cd contenu\chapitres\ssh_donner_la_mort
..\..\..\app\.venv\Scripts\python.exe generer.py
```
