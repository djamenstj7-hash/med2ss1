# Ectoparasitoses — paquet Parasitologie et mycologie

66 notes, 124 cartes. Chapitre `chap-ue-parasito-fc8` de l'UE Parasitologie et
mycologie (`ordre` 10). Cours du **Dr Cornu, le 02/12/2025**, « Ectoparasitoses »
(FC n°10 du Ronéosaure 2025-26, 6 pages) ; annales du polycopié
« 8. Ectoparasitoses » du Ronéosaure 2024-25 (9 questions, 8 sessions) et du
sujet 2024/2025 de l'UE (1 question, sans corrigé). Examen du 5 janvier 2027.

**Une fiche provisoire.** Aucun ronéo 2026-27 de parasitologie n'est paru : le
chapitre est carté sur le Ronéosaure 2025-26 (décision de Vincent du 02/10,
plan C16), et le ronéo de l'année corrigera les cartes à sa parution. La
source porte son année dans son auteur (« Ronéosaure 2025-26 ») : chaque carte
de cours prend le tag `cours-2025-26` et le badge « Cours 2025-26 ». Aucune
carte ne dit « Absent du cours 2026-27 », et les erreurs du Ronéosaure sont
dites par un ATTENTION sans genre : la liste des erreurs de la promo,
`contenu/ERRATA_RONEOS_2026-27.md`, ne concerne que les ronéos 2026-27.

L'identifiant `fc8` vient du squelette, qui suit la numérotation 2024-25 (les
ectoparasitoses y étaient la FC n°8) ; l'ordre, 10, est celui de 2025-26.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 26 | 26 |
| QRU | 1 | 1 |
| Texte à trous | 11 | 58 |
| QROC | 8 | 8 |
| Recto-verso | 8 | 8 |
| Schéma cliquable | 1 | 12 |
| Planche à légender | 1 | 1 |
| Lexique | 10 | 10 |

Dont **10 annales** : 7 QCM (QRM) et 3 QROC (recto-verso), sur 9 sessions, de
2015/2016 S1 à 2024/2025 S1 (la Q7 du sujet 2024/2025, clé déduite). Les 20 QCM du cours ont une justification par
proposition, comme les annales.

Six thèmes, dans l'ordre du cours :

| Clé | Libellé |
|---|---|
| `ectoparasites` | Ectoparasites : définition et classification |
| `sarcopte` | Sarcoptes scabiei et transmission de la gale |
| `gale-clinique` | Les formes cliniques de la gale |
| `gale-diagnostic` | Diagnostic de la gale |
| `traitement-prevention` | Traitement et prévention (partagé par l'UE, plan C16) |
| `pediculoses` | Pédiculoses : poux et morpions |

Les six libellés sont à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) ; aucune clé n'existait ailleurs.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-parasito-ectoparasitoses` — Ronéosaure, « FC n°10 Ectoparasitoses » (6 p.), `PARASITO-MYCOLOGIE/FC n°10 Ectoparasitoses .pdf` | **2025-26** | **la base** : chaque note du cours porte sa page ; c'est ce que le lecteur ouvre (`chapitre=`) |
| `src-annales-8-ectoparasitoses` — Ronéosaure, « 8. Ectoparasitoses » (4 p.) | 2024-25 | les 9 questions et leur table de corrections (p. 4) ; déclaration aux seuls champs communs, que tout chapitre qui prendrait ce polycopié copie à l'identique |
| `src-cours-parasito-ectoparasitoses-2425` — FC n°8, Dr Cornu (9 p.) | 2024-25 | appoint, cité dans le texte : poux visibles à l'œil nu et diméticone (p. 8), nodules scabieux (p. 5), bilan d'IST (p. 9) |
| `src-cours-parasito-ectoparasitoses-2324` — Charonéo, Dr Cornu (8 p.) | 2023-24 | appoint, cité pour trancher deux annales : « cette femelle n'est pas visible à l'œil nu » (p. 3), les nodules (p. 4), les pattes du morpion (p. 7) |
| erratas de la promo : cours 2025-26 (`Erratas de Parasitologie mycologie.docx`), cours 2024-25, annales 2024-25 | — | aucune entrée sur ce cours ni sur ce polycopié |
| `src-sujets-parasito-2425` — sujets de parasitologie-mycologie 2024/2025, session 1 (examen du 10/01/2025, 14 p.), sans chemin | 2024-25 | 2024/2025 S1 Q7, par `SRC["sessions"]` ; **aucun corrigé**, clé déduite du cours ; déclaration commune aux dix chapitres de l'UE, champ pour champ |

Vérifications hors du cours, citées dans la carte qui s'en sert : le VIDAL
(sarcopte « invisible à l'œil nu » ; Ascabiol en deux applications à 8 jours,
laissées 24 heures ; incubation de deux à trois semaines, trois ou quatre jours
à une recontamination), le CDC (« About Scabies » : la gale se transmet avant
les symptômes), la Revue du Praticien (Bernigaud et Chosidow, 2018 : femelle
« très difficilement visible à l'œil nu », nodules scabieux) ; l'étymologie
(Wiktionnaire, FC de sémantique 2026-27).

## Ce que le cours a dicté

- **La seule ligne rouge**, la définition d'un ectoparasite (p. 2) :
  `ect-qc-definition` A, en `indispensables` ; la proposition « Sarcoptes
  scabiei est un insecte » y est `inacceptables`, parce que c'est l'erreur que
  trois annales tendent.
- **La pédiculose « ne sera pas interrogée »** (p. 6) : ses cinq cartes de cours
  (`ect-qc-pediculoses`, `ect-qc-morpions`, `ect-fa-pediculoses`,
  `ect-qr-dimeticone`, `ect-rv-pou-morpion`) portent le tag `edn` ; les
  annales de poux restent des cartes ordinaires (question 2 ci-dessous).
- Ni gris ni ✪ dans le texte ; les étoiles des diapositives (cycle de la gale,
  gale du nourrisson, gale profuse, tableau des pédiculoses) sont sur les
  figures, qui illustrent toutes une correction.
- **Ce qui n'est pas développé** (moustiques, moucherons, mouches, taons,
  punaises, tiques, p. 2) n'a qu'une carte, `ect-qc-vecteurs`, et sa place
  dans la planche.

## Les erreurs et imprécisions du Ronéosaure 2025-26

| Page | Ce que dit le Ronéosaure | Ce qui est juste | Carte |
|---|---|---|---|
| 3 | « On devient contagieux de la gale au bout de 3 semaines » | c'est le cours lui-même (même formule en 2024-25, p. 3) : à l'examen, vrai ; mais un sujet infesté transmet la gale pendant l'incubation, avant tout symptôme (CDC) | `ect-qc-contagiosite` A (ATTENTION) |

Sans ATTENTION, parce qu'aucune réponse n'en dépend : « une acquisition
sexuelle chez le sarcopte » (p. 3, pour une maturité sexuelle) ; « squames
blanc-jaune souffre » (p. 4, soufre) ; « Ascabiol […] 2 applications en 2
couches chacune, de 24 à 8j d'intervalle » (p. 5), que les cartes lisent
« deux couches laissées 24 heures, seconde application à J8 » (VIDAL) —
`ect-fa-traitement`, `ect-rv-local-oral`, `ect-qr-benzoate`.

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| La gale : prurit nocturne, sièges, lésions pathognomoniques, diagnostic clinique, contagiosité | 2023/2024 S2 Q. 6, 2019/2020 S1 Q. 4, 2018/2019 S1 Q. 15, 2022/2023 S2 QROC 1, 2017/2018 S1 QROC 3, 2024/2025 S1 7) (les sièges, en QCM) |
| Acarien ou insecte ; hématophage ou non ; visible ou non | 2023/2024 S2 Q. 7, 2021/2022 S2 Q. 4, 2018/2019 S1 Q. 15 A, 2015/2016 S1 Q. 14 |
| Les poux | 2015/2016 S1 Q. 14, 2021/2022 S2 Q. 4, 2020/2021 S1 QROC 3 |

**Une question du polycopié n'est pas ici** : 2021/2022 S1 Q. 6 (parasitoses
cosmopolites), imprimée aussi dans « 5 - Parasitoses digestives exotiques »
pour la même session, est cartée une fois, dans
`parasito_digestives_exotiques` (avec le désaccord des deux tables sur la
gale : « BC (D) » là-bas, « BCD » ici).

## Le schéma cliquable et la planche

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `sieges-gale.svg` (`ect-zo-sieges`) | tête, sillon sous-mammaire, ombilic, pli inguinal, verge, poignet (de face) ; dos, fesses, coude (de dos) ; espaces interdigitaux, paume (gros plan de la main) ; plante (gros plan du pied) | 12 |

Ce qui se clique n'est pas l'anatomie, c'est le tri : chaque question nomme le
lieu par ce que la gale en fait (« le grand siège du tronc que la gale commune
épargne », « le siège de la gale du nourrisson, à la main », « le pli où le
grattage est le plus marqué (++) ») et l'oppose à son voisin (dos épargné et
fesses atteintes ; paume du nourrisson et espaces interdigitaux de l'adulte ;
pli inguinal et ombilic). Un lieu pair n'a sa zone que d'un côté, à gauche de
l'image ; la légende de l'image le dit. La version légendée,
`sieges-gale-legende.svg` (rouge : gale commune ; bleu : épargné ; orangé :
nourrisson), tirée des mêmes constantes, est en correction et illustre aussi
quatre autres cartes. Les sièges viennent de la FC (p. 3-4) et du corrigé de
2022/2023 S2 QROC 1 (coudes, aréoles, ombilic).

**La planche** `ect-pl-classification` : la diapositive « Classification des
ectoparasites » (p. 2), neuf cases vidées par
`scripts/planche_depuis_image.py` — arthropodes, insectes, arachnides, puces,
poux et morpions, acariens, tiques, Sarcoptes scabiei, Demodex ; quatre intrus
(crustacés, myriapodes, araignées, scorpions). Les feuilles de la branche des
insectes (moustiques, moucherons, mouches, taons, punaises) restent visibles.
L'aperçu de contrôle et l'image numérotée ont été relus : aucun reste de
lettre.

**Illustrations** : 24 QCM sur 27 (89 %) portent une figure de la fiche ou les
sièges légendés en correction ; 46 notes sur 66 (l'annale 2024/2025 prend les
sièges légendés). Les trois QCM sans figure
(`ect-qc-traitement`, `ect-qc-environnement`, `ect-qc-epidemie`) portent sur la
p. 5, qui n'en a pas. Les neuf figures sont extraites telles quelles du PDF
(p. 2, 3, 4, 6) ; ne sont pas repris le logo de la p. 1 et une photographie
d'illustration du rasage (p. 6).

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2021/2022 S2 Q. 4 (épidémiologie des ectoparasites) | BCE | **BCDE** | D, « le sarcopte de la gale est invisible à l'œil nu », est vraie en toutes lettres pour le cours de la même enseignante (FC 2025-26 p. 3 : « pas à l'œil nu » ; cours 2023-24 p. 3) et pour le VIDAL ; le cours 2024-25 le dit « de taille microscopique, mais quand même assez gros » (p. 3), ce qui appuie la seule lecture qui sauve la clé : la femelle, 0,30 à 0,45 mm, reste « très difficilement visible » (Revue du Praticien, 2018). Conflit déclaré sur D, `officielle=False` |
| 2022/2023 S2 QROC 1 (localisations de la gale) | corrigé imprimé sous « 2021/2022, Session 1 » | ce corrigé, rattaché au QROC | la session 2021/2022 S1 du polycopié n'a que la Q. 6 ; le corrigé répond mot pour mot à ce QROC. Repris tel quel, non marqué officiel |
| 2017/2018 S1 QROC 3 (signes cutanés) | {sillons scabieux, vésicules perlées, signe de l'aile du deltaplane} | idem, plus les lésions de grattage, non spécifiques | correction non officielle du secrétaire, que le cours confirme (p. 4) : « clé déduite du cours », non marqué officiel |
| 2024/2025 S1 7) (sites corporels de la gale) | aucune (sujet sans corrigé) | **ACE** | clé déduite de la FC 2025-26 : espaces interdigitaux, poignets, plis inguinaux ++ ; la gale commune épargne la tête, le dos et la plante des pieds (p. 3-4) ; `officielle=False`. Le même savoir que 2022/2023 S2 QROC 1, posé en QCM |

Une nuance sans conflit : 2021/2022 S2 Q. 4 A, « le sarcopte est hématophage »,
cotée fausse par la table comme par le cours (salive qui lyse la couche cornée,
p. 3) ; la page grand public du VIDAL, citée en D, écrit pourtant qu'il « se
nourrit de sang ». La justification le dit et garde la clé imprimée.

Reprises, avec une remarque dans la carte : **2019/2020 S1 Q. 4** (imprimée
« desmacules », « desvésicules », gardé tel quel ; A, les nodules, vient des
cours 2024-25 et 2023-24, pas de la FC 2025-26).

Cas ouvert : aucun.

## Le lexique

Dix termes, aux pages mesurées dans la FC n°10 2025-26
(`chercher_pages.py`) : ectoparasite (p. 2), acarien (2, 3, 5, 6), scabiose (2),
sillon scabieux (4), vésicule perlée (4, 6), hématophage (6), pédiculose (1, 2,
6), lente (6), érythrodermie (4), scabicide (5, 6). Le plan comptait
« ectoparasite » p. 1-6 : l'en-tête de chaque page dit « Ectoparasitoses »,
qui n'est pas le terme ; seule la p. 2 l'emploie. « Prurit », « cosmopolite »
et « hyperéosinophilie » sont accueillis par `parasito_digestives_autochtones`
(plan C16), et ne sont pas repris.

Chaque terme dit son origine grecque ou latine. Les étymologies nouvelles —
six racines propres à ce chapitre (`ecto-`, `acar(i)-`, `scabies (latin)`,
`perna (latin)`, `pédicul- (latin)`, `lens, lendis (latin)`) et les dix
termes — sont **proposées** dans `scratchpad/etym/parasito_ectoparasitoses.json`,
avec leurs sources ; la table `scripts/etymologies.json` n'est pas modifiée par
ce chapitre. Deux racines nouvelles sont partagées avec des chapitres écrits en
même temps, et leur entrée est identique dans les deux propositions :
`-site (grec)` (σῖτος, « blé, nourriture », avec `parasito_parasitisme`, pour
« parasite ») et `vesicula (latin)` (« petite vessie, gousse », reprise de
`viro_pathogenes_2`). Les définitions et les
racines disent déjà, mot pour mot, ce qu'`appliquer_etymologies.py` en écrira
(vérifié). Les racines réemployées gardent la clé de la table : `para- (grec)`,
`-ose`, `hém(at)-`, `phag(o)-`, `éryth(r)-`, `derm(o)-`, `-cide (latin)`.
Celles que les FC de sémantique
2026-27 enseignent citent leur page : `ecto-` (2/2 p. 9), `para- (grec)`
(2/2 p. 8), `-ose` (2/2 p. 9), `éryth(r)-` (2/2 p. 7), `-cide (latin)` (1/2 p. 9).

## Questions pour Vincent

1. **2021/2022 S2 Q. 4 D, le sarcopte « invisible à l'œil nu »** (question 2
   du plan C16) : la table la cote fausse ; le cours de la même enseignante la
   dit vraie en 2025-26 et en 2023-24 (« pas à l'œil nu »), et en 2024-25
   « de taille microscopique, mais quand même assez gros ». La carte retient
   BCDE et donne les deux lectures. La valides-tu, ou préfères-tu la clé
   imprimée BCE ?
2. **La pédiculose « non interrogée »** (question 4 du plan) : les cinq cartes
   de cours portent le tag `edn` ; les trois annales de poux (2015/2016 Q. 14,
   2020/2021 QROC 3, et 2021/2022 S2 Q. 4, qui mêle poux et sarcopte) restent
   des cartes ordinaires. Est-ce bien ce que tu veux ?
3. **La contagiosité « au bout de 3 semaines »** (p. 3) : la carte répond
   comme le cours (vrai) et dit, par un ATTENTION, que la gale se transmet en
   réalité dès l'incubation (CDC). D'accord pour la garder ainsi ?
4. **L'examen du 5 janvier 2027** (question 5 du plan) : il n'est pas déclaré
   dans `EXAMENS`, comme dans les autres chapitres ; à décider pour les quatre
   UE de janvier ensemble.

## À relire

Aucune carte `a-relire` : chaque carte de cours porte sa page dans la fiche
2025-26, chaque annale sa clé vérifiée sur la table (relue en image), ou
déduite à la page pour celle de 2024/2025. À la
parution du ronéo 2026-27 de ce cours, relire toutes les cartes contre lui :
pages, chiffres (328 cas pour 100 000, moins de 10 sarcoptes, 100 par cm²,
délais du traitement et de la décontamination), sièges de la gale, et
l'imprécision de la p. 3.


## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier. Sous les annales, 25 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 5 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `ectoparasites` | 9 | 1 | 2 |
| `sarcopte` | 3 | 1 | 1 |
| `gale-clinique` | 10 | 2 | 5 |
| `pediculoses` | 3 | 1 | 2 |

**Le schéma** `ech-ectoparasitoses`, « Les ectoparasitoses · l'agent, les signes, la preuve », donne 38 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_ECTOPARASITOSES`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Tag `edn`** (passage « pas à retenir ») : `ect-ech-s20`, `ect-ech-s21`, `ect-ech-s22`, `ect-ech-s23`, `ect-ech-s24`, `ect-ech-s25`, `ect-ech-m5`.

**Sans marche** :
- ect-an-1819s1-q15 B : la larva migrans viscérale (Toxocara, impasse parasitaire) relève de la FC n°1 2025-26 (p. 10), la fiche d'un autre chapitre ; lettre posée sur la case du sarcopte (qui reste sous la couche cornée), sans marche.

## Régénérer

```powershell
cd contenu\chapitres\parasito_ectoparasitoses
..\..\..\app\.venv\Scripts\python.exe generer.py
```

La planche se refait depuis `app/`, si ses rectangles changent :
`uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/parasito_ectoparasitoses ect-pl-classification --apercus <brouillon>`.
