# Sémiologie ostéo-articulaire — paquet d'exemple

88 notes, 115 cartes une fois importées (un texte à trous donne une carte par
trou), dont 12 termes de lexique. 30 notes de cours sur le ronéo 2026-27,
21 gardées sur le cours 2023-24, 25 questions d'annales sur 14 sessions.

**La base est le ronéo 2026-27** : Ronéo & Juliette, « Sémiologie
ostéo-articulaire normale » (Sémiologie - Rhumatologie), cours du **Pr R.M.
Flipo** du **15/09/2026** (semaine 2, 10 h-11 h), 14 pages. Le chapitre avait été
carté sur le **Charonéo 2023-24** du Pr Paccou (cours du 18/09/2023, 7 pages) ;
ce LISEZ_MOI le présentait à tort comme « le ronéo du Pr Paccou, arrivé le
17/09/2026 ». Il a été relu note par note contre le cours de l'année le
25/09/2026 (tâche C4 de la roadmap).

Le ronéo 2026-27 n'a ni texte gris ni définition de son gris : rien n'y est
écarté à ce titre.

## Sources

| Source | Ce que c'est | Notes qui y renvoient |
|---|---|---|
| `src-fc-semio-osteo` | le ronéo 2026-27, 14 pages (`SRC["fiche"]`) | 30 notes de cours, chacune à sa page (`page` dans `donnees.py`) |
| `src-cours-osteo` | le Charonéo 2023-24 du Pr Paccou, 7 pages | les 21 notes absentes du cours 2026-27, listées plus bas |
| `src-annales-osteo` | le polycopié d'annales du Ronéosaure 2024-25 : 12 sessions, 30 questions | 21 questions |
| `src-sujet-2526` | le sujet 2025/2026 et son corrigé officiel | 2 questions |
| `src-sujet-semio-2324` | le sujet de sémiologie générale 2023/2024, session 1, et son corrigé officiel (une clé par question), déposés le 15/10/2026 ; `SRC["sessions"]["2023/2024"]` | 2 questions : `ost-an-2324-q8`, `ost-an-2324-q9` |

`generer.py` fait d'une note qui porte `page` une note du ronéo 2026-27, à cette
page ; une note sans `page` garde le Charonéo 2023-24. Une justification qui
s'appuie encore sur l'ancien cours le dit : « cours 2023-24 ».

## Ce que le cours 2026-27 enseigne

C'est un autre cours, et non le même cours mis à jour. Le Pr Flipo consacre la
moitié de son heure à la spécialité elle-même : l'étymologie (« rheuma »,
couler), l'histoire (Hippocrate, la Ligue de 1928, la reconnaissance de 1960,
le thermalisme), le champ (quatre grands groupes, le muscle « cas à part »),
les outils, l'épidémiologie, et les grandes affections — polyarthrite
rhumatoïde, spondyloarthrite, goutte et chondrocalcinose, arthrose, ostéoporose,
lombalgies, pathologies abarticulaires. Suivent des rappels sur l'os (compact
et spongieux, collagène I, remodelage) et sur l'articulation (cartilage,
synoviale), puis la classification des maladies articulaires.

La sémiologie tient en trois gestes : un **interrogatoire** dichotomique,
mécanique ou inflammatoire ; les **quatre signes cardinaux** à l'examen, avec le
compte des articulations (mono-, bi-, oligo-, polyarthrite) ; et la
**radiographie** de l'arthrose et de l'arthrite. Sa conclusion : ces trois-là
suffisent le plus souvent à trancher.

## Le tableau qui vaut tout le reste

Le couple mécanique / inflammatoire reste le cœur du chapitre, et le polycopié
le pose **neuf fois sur trente questions** (l'ancien compte de huit était faux) :
les trois questions sur l'horaire d'une douleur rachidienne comprises. Le
tableau du cours 2026-27 (p. 12-13) :

| | Mécanique (l'arthrose) | Inflammatoire |
|---|---|---|
| Installation | petit à petit | par crises, par poussées |
| Mouvement, activité | la déclenche, l'aggrave | la soulage |
| Repos, nuit | l'atténuent | ne la calment pas |
| Dérouillage matinal | **aucun** | prolongé, « jusqu'à 30-45 min » — pas un plafond : les annales comptent une heure |
| Réveils nocturnes | non | oui, seconde partie de nuit, vers 3-4 h (cortisol) |
| Dans la journée | s'accentue | à son pire au réveil |

## Ce qui a changé le 25/09/2026

**Rien n'a été retiré, aucun identifiant n'a changé**, aucun trou n'a été
renuméroté : chaque carte garde ses révisions. Une carte fausse contre le cours
de l'année a été réécrite ; une carte dont le contenu est seulement absent du
cours a été gardée, et elle est listée plus bas.

### Cartes réécrites

| Carte | Avant | Maintenant | Pourquoi |
|---|---|---|---|
| `ost-fa-tableau` | début {progressif}, {influencée} par l'effort, dérouillage {bref} de 5 à 10 min | installation {progressive}, déclenchée par les {mouvements}, dérouillage {absent} | « il n'y a pas de dérouillage matinal » (p. 12) ; mêmes six trous, dans le même ordre |
| `ost-qr-derouillage` | durée du dérouillage d'une douleur mécanique : 5 à 10 min | la durée que le ronéo donne à celui d'une douleur inflammatoire : 30 à 45 min, dérouillage « prolongé » et non plafond | la douleur mécanique n'en a plus (p. 12) |
| `ost-qr-fonctionnels` | les « deux seuls signes fonctionnels » : douleur et gêne | le symptôme d'appel (douleur, plus de 9 fois sur 10) et l'autre motif (déformation, 1 sur 10) | p. 12 ; le cours 2026-27 ne parle pas de gêne |
| `ost-qr-hanche` | repère d'une douleur de hanche : pli inguinal, pas le haut de la fesse | son principal piège : ne faire mal qu'au genou | p. 12 |
| `ost-qc-mecanique`, `ost-qc-inflammatoire`, `ost-qc-appareil` | justifications sur le cours 2023-24 | justifications sur le ronéo 2026-27, avec leur page | l'inflammatoire est « soulagée par l'activité », non plus « non influencée par l'effort » ; le muscle est « un cas à part » |

`ost-fa-cardinaux` et `ost-rv-arthrose` n'ont changé que d'explication : ils
sont vrais contre les deux cours. Les énoncés de `ost-qc-traitements`,
`ost-rv-flessum` et `ost-rv-echelles` disent désormais « le cours 2023-24 ». Les
21 notes gardées disent toutes, dans leur explication, qu'elles viennent du
cours 2023-24, et ce que le ronéo 2026-27 en dit — le plus souvent rien.

### Notes ajoutées

| Note | Ce qu'elle teste | Page |
|---|---|---|
| `ost-qc-histoire` | rheuma, Hippocrate, 1928 et 1960, thermalisme, discipline médicale | 2 |
| `ost-qc-muscles` | qui soigne le muscle : douleur, faiblesse, inflammation, enfant | 4 |
| `ost-fa-groupes` | les quatre grands groupes de la rhumatologie | 4 |
| `ost-qc-outils` | outils diagnostiques, infiltrations, biomédicaments | 5 |
| `ost-qc-epidemio` | mal de dos, rhumatismes inflammatoires, arthrose digitale, col du fémur | 5 |
| `ost-rv-oms` | les cinq rhumatismes, priorité de l'OMS | 6 |
| `ost-qc-pr-spa` | polyarthrite rhumatoïde et spondyloarthrite | 7 |
| `ost-qc-microcristaux` | goutte (urate) et chondrocalcinose (pyrophosphate) | 7 |
| `ost-qc-arthrose` | genou et hanche au programme, obésité, Occident, mains | 8 |
| `ost-qc-osteoporose` | capital osseux, ménopause, facteurs modifiables, densitométrie | 8 |
| `ost-qc-lombalgie` | lumbago, chronicité, discordance radio-clinique | 9 |
| `ost-rv-abarticulaires` | gestes répétitifs, médecine du travail | 9 |
| `ost-qc-os` | os cortical et spongieux, collagène I, réserve calcique | 9 |
| `ost-qc-remodelage` | ostéoclaste, ostéoblaste, ménopause, traitements | 10 |
| `ost-qc-cartilage` | collagène II, avascularité, imbibition, synoviale | 11 |
| `ost-qc-familles` | la classification des maladies articulaires | 11 |
| `ost-qc-interrogatoire` | raisonnement dichotomique, mode de début | 12 |
| `ost-fa-inflammatoire` | le tableau de la douleur inflammatoire, en miroir de `ost-fa-tableau` | 12 |
| `ost-qc-signes` | rubéfaction, chaleur, tuméfaction, médecine globale | 13 |
| `ost-fa-comptage` | mono-, bi-, oligo-, polyarthrite | 13 |
| `ost-qc-imagerie` | radiographie de l'arthrite contre celle de l'arthrose | 14 |

### Annales

Énoncés, propositions et clés sont restés tels qu'imprimés. Les justifications
citent désormais le ronéo 2026-27 là où il tranche, et disent « cours 2023-24 »
ailleurs. Quatre questions ont quitté le thème `hors-fiche`, parce que le cours
de l'année les couvre : les trois sur la classification des rhumatismes (QCM 9
de 2018/2019, QCM 19 de 2017/2018, QCM 15 de 2015/2016 S2) passent en
`rhumatismes`, la radiographie de l'arthrose (QCM 20 de 2017/2018) en
`paracliniques`. Le champ de la rhumatologie (QCM 14 de 2015/2016) passe, lui,
d'`interrogatoire` à `rhumatologie`, comme `ost-qc-appareil`.

### Thèmes

Trois thèmes sont nés de ce cours : `rhumatologie`, `rhumatismes`,
`os-articulation`. Un tag n'a qu'un libellé pour toute la bibliothèque : ils ont
été ajoutés à `THEME_LABELS` (`app/src/med_engine/application/scopes.py`), faute
de quoi `test_tout_theme_du_paquet_a_son_libelle` refuse le paquet. L'examen
clinique et l'imagerie reprennent les tags existants `examen` (« L'examen
clinique ») et `paracliniques` (« Examens complémentaires »).

## Les ATTENTION

Règle de Vincent : un contresens ne se tranche jamais en silence, et la clé
retenue est la bonne, vérifiée sur des sources sûres (26/09/2026). Les ronéos
2026-27 ne seront pas corrigés (« les cours ne seront pas modifiés ») : ses
erreurs sont portées par les cartes. Le tableau d'erreurs de la promo (version
du 28/09/2026) en relève une dans ce cours : « PMS » pour **TMS**, troubles
musculo-squelettiques (p. 9). `ost-rv-abarticulaires` disait déjà troubles
musculo-squelettiques ; son explication le signale par ATTENTION. Toutes ces
erreurs sont aussi dans `contenu/ERRATA_RONEOS_2026-27.md`.

| Carte | Le point | Les lectures | Retenu |
|---|---|---|---|
| `ost-fa-tableau`, `ost-qr-derouillage` | dérouillage de la douleur mécanique | 2023-24 : « bref (5-10 min) » ; 2026-27 : « il n'y a pas de dérouillage matinal » (p. 12) | 2026-27 ; les annales tiennent dans les deux lectures |
| `ost-qc-inflammatoire` C, `ost-qr-derouillage`, `ost-fa-inflammatoire` | une heure de dérouillage | 2026-27 : « jusqu'à 30-45 minutes » (p. 12), qui se lirait comme un maximum ; 2023-24 et clé officielle du QCM 7 de 2025/2026 : une heure est inflammatoire ; QCM 17 de 2021/2022 : plus de 30 minutes | la durée du ronéo, donnée pour un dérouillage « prolongé » et non pour un plafond ; une heure est a fortiori inflammatoire |
| `ost-qc-mecanique` B | l'inflammatoire et l'effort | 2023-24 : « non influencée par l'effort » ; 2026-27 : « soulagée par l'activité » (p. 12) | 2026-27 ; l'item, sur la mécanique, reste faux |
| `ost-qr-fonctionnels` | les motifs de consultation | 2023-24 : douleur et gêne ; 2026-27 : douleur et déformation (p. 12) | 2026-27 |
| `ost-qr-hanche` | le piège d'une douleur de hanche | 2023-24 : le pli inguinal, « et non pas du haut de la fesse ! » ; 2026-27 : le genou, « le principal piège » (p. 12) | 2026-27 ; les deux restent vrais |
| `ost-qc-histoire` C | date de la spécialité | le ronéo la dit « apparue au XIXe siècle » (p. 3), mais née « officiellement » en 1960, avant quoi il n'existait pas de spécialités « à proprement parler » (p. 2-3) : contradiction du ronéo, ou des origines thermales au XIXe et une reconnaissance en 1960 | ouvert ; l'item ne porte que sur la reconnaissance, et la carte retient 1960 |
| `ost-qc-remodelage` B | l'ostéocyte | le ronéo : « l'ostéoclaste assure la résorption osseuse (mature : ostéocyte) » (p. 10) ; l'histologie, et le ronéo lui-même quelques lignes plus haut (« le fibroblaste évolue vers l'ostéocyte mature », raccourci de la lignée ostéoblastique) : l'ostéocyte est l'ostéoblaste mature | **erreur du ronéo 2026-27** ; la carte retient l'histologie |
| `ost-qc-cartilage` B | les tissus non vascularisés | le ronéo : le cartilage et la cornée, « les 2 seuls tissus humains non vascularisés » (p. 11) ; l'histologie : les épithéliums et le cristallin ne le sont pas non plus | **point douteux** (tri du 28/09/2026) : ni diapositive, ni cours antérieur, ni annale pour dire si « seuls » est du Pr Flipo ou des preneurs de notes, mais la phrase forme un raisonnement d'enseignant (non vascularisés, donc greffés sans rejet) ; « seuls » est de trop, et l'item, sans « seuls », est vrai dans les deux lectures |
| `ost-an-1516-q14` E, `ost-qc-appareil` E | les maladies musculaires | clé imprimée : vrai ; 2026-27 : quatre grands groupes, le muscle « cas à part », soigné par le rhumatologue quand il fait mal (p. 4) | la clé, juste : la rhumatologie soigne les « maladies de l'appareil locomoteur », muscles compris (Société française de rhumatologie) ; un énoncé sur les « quatre grands groupes » exclurait l'item |
| `ost-an-1516s2-q15` C | la goutte, « pathologie dite inflammatoire » | clé imprimée : vrai ; 2026-27 : la goutte est rangée parmi les maladies MICROCRISTALLINES, pas parmi les inflammatoires (p. 11), mais sa crise est une inflammation, rouge « pivoine » (p. 13) | la clé, juste : « le rhumatisme inflammatoire le plus fréquent dans les pays industrialisés » (Collège de rhumatologie, abrégé 2016, item 194) ; une question sur la classification du cours l'exclurait (`ost-qc-familles`). Déclaré dans `CONFLITS` |
| `ost-an-1718-q20` D | la « macrogéode » d'hyperpression | clé imprimée : vrai ; 2026-27 : « micro géodes d'hyperpression » (p. 14) | **ouvert**, la clé gardée : la géode d'hyperpression, « lacune cerclée en regard du pincement maximal », est un signe cardinal radiographique de l'arthrose (Collège de rhumatologie, abrégé 2016, item 125), qui ne lui donne pas de taille ; la macrogéode d'hyperpression est décrite dans l'arthrose, surtout à la hanche, mais rare (Bouabdellah et coll., coxarthrose dysplasique). Micro ou macro, les deux se voient sur le cliché : le signe est le même, et le cours ne le donne jamais à l'arthrite. Une question de cette année qui opposerait les deux préfixes suivrait le ronéo. Déclaré dans `CONFLITS` |
| `ost-rv-genu` | genu valgum et varum | le Charonéo 2023-24 les décrit **inversés** — ce n'était pas une ambiguïté : son tableau d'erreurs relève « Inversion Genu Varum et Genu Valgum », corrigée sur papier seulement, le PDF reste inversé | la correction : valgum en X, varum en O |
| `ost-rv-rachis` | scoliose, cyphose | le Charonéo 2023-24 : « scoliose, cyphose (déviation dans le plan frontal) » | la parenthèse ne vaut que pour la scoliose ; la cyphose est sagittale |

## Une clé imprimée qui n'est pas suivie

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| `ost-an-2526-q8` (goutte, QCM 9 du polycopié) | D, nodules de Bouchard | ACE : rougeur, tuméfaction, chaleur | Bouchard, c'est l'arthrose digitale ; l'accès goutteux est une arthrite aiguë inflammatoire (Collège de rhumatologie, abrégé 2016, items 125 et 194) ; corrigé officiel de 2025/2026 ; ronéo 2026-27 (goutte rouge « pivoine », monoarthrite, p. 13) ; le polycopié se contredit (tophus, chaleur et rougeur ailleurs) ; l'errata du Ronéosaure 2024-25 la dit « mal corrigée » |
| `ost-an-2324-q9` (la même question, sous sa session vraie) | D (polycopié) ; **ACE** (corrigé officiel 2023-24, reçu le 15/10/2026) | ACE, le corrigé officiel — carte officielle | les mêmes raisons ; c'est désormais le corrigé officiel de la session elle-même qui dément la table du polycopié |

Elles sont déclarées dans `CONFLITS`, en fin de bloc d'annales de `donnees.py`, et
signalées par ATTENTION sur l'item D, qui dit que la correction imprimée n'est
pas bonne. La carte est rangée sous la session 2025/2026, dont le corrigé
officiel donne ACE : elle reste **officielle** (revu le 26/09/2026, tâche C7 :
la clé retenue est la bonne, pas la clé imprimée). Le hook `verifier_paquet.py` contrôle
désormais `CONFLITS` quand il vit dans `donnees.py`, et le trouve signalé.

Le cours 2026-27 confirme en revanche la clé la plus contre-intuitive du
chapitre : une douleur mécanique s'installe « petit à petit » (p. 12), comme le
disait déjà le cours 2023-24. L'item E du QCM 7 est bien vrai.

### Les sessions « 2022/2023 » : réglé par le corrigé officiel 2023-24

La même ligne d'errata du Ronéosaure 2024-25 (« Questions 2022-2023 en réalité
2023-2024 + Q9 mal corrigée ») disait que les deux questions imprimées sous
« 2022/2023 » (p. 1-2 du polycopié : Q8 rythmicité, Q9 goutte) sont de
2023/2024. Elle n'avait pas d'avis du bureau, et la question restait ouverte.
**Le sujet 2023/2024 et son corrigé officiel, déposés le 15/10/2026, la
tranchent** : ses QCM 8 et 9 (Pr Paccou, cours du 18/09/2023) sont ces deux
questions, au même numéro, et le corrigé donne BDE et **ACE** — la Q9 était bien
mal corrigée. Elles ont désormais leur carte sous leur vraie session,
`ost-an-2324-q8` et `ost-an-2324-q9`, à côté des cartes 2025/2026 qui les
reprennent (une carte par session). Les cartes 2025/2026, qui disent « imprimée
2022/2023, 2023/2024 selon une proposition d'errata », n'ont pas été retouchées.
L'entrée « 2022/2023 » de `SESSIONS` n'est toujours portée par aucune carte.

Deux coquilles du sujet 2023/2024, gardées telles qu'imprimées : l'énoncé de la
QCM 8, « lesquels en faveur d'une douleur » (il manque « sont »), et
« nodules de bouchard » sans majuscule en D de la QCM 9.

## Absent du cours 2026-27

Ces notes ne sont pas contredites par le ronéo de l'année : il n'en parle pas.
Elles sont **gardées**, sans page, sur le Charonéo 2023-24. Vincent décide.

| Note | Ce qu'elle teste | Pourquoi elle est absente |
|---|---|---|
| `ost-qc-atcd` | les antécédents à rechercher | le cours 2026-27 n'interroge que la douleur (mode de début, horaire) |
| `ost-qc-traitements` | statines, fluoroquinolones, anticoagulants | idem |
| `ost-qc-neuropathique` | douleur neuropathique contre nociceptive | le couple a disparu |
| `ost-qc-inspection` | ce que cherche l'inspection | l'examen en quatre temps a disparu ; seuls les signes cardinaux restent (p. 13) |
| `ost-qc-epanchement` | choc rotulien, ponction, dos de la main | pas de palpation ni de ponction ; l'épanchement n'est cité que comme cause de tuméfaction (p. 13) |
| `ost-qc-reflexes` | rotulien L4, achilléen S1, Tinel, goniomètre | pas de percussion |
| `ost-qc-physique` | les conditions de l'examen physique | pas d'examen physique décrit ; la comparaison bilatérale et la médecine globale restent (p. 13) |
| `ost-fa-etapes` | inspection, palpation, percussion, amplitudes | idem |
| `ost-fa-schober` | l'indice de Schöber | pas d'amplitudes |
| `ost-fa-liquide` | l'aspect du liquide de ponction | pas de ponction |
| `ost-qr-rotulien`, `ost-qr-achilleen` | les racines des réflexes | pas de réflexes |
| `ost-qr-tinel` | le signe de Tinel | idem |
| `ost-rv-tophus` | le tophus et ses sites | décrit sans être nommé : « dépôts d'urates sous la peau » (p. 7) |
| `ost-rv-dupuytren` | la maladie de Dupuytren | absente |
| `ost-rv-genu` | genu valgum et varum | pas de troubles statiques |
| `ost-rv-rachis` | scoliose et cyphose | idem ; seule la courbure du dos de la spondyloarthrite (p. 7) |
| `ost-rv-flessum` | le flessum irréductible du genou | pas d'attitudes vicieuses |
| `ost-rv-echelles` | EVA et EN | l'intensité est seulement dite subjective (p. 12) |
| `ost-rv-gene` | la gêne fonctionnelle | le deuxième motif de consultation est la déformation (p. 12) |
| `ost-rv-testing` | goniomètre et testing moteur | pas d'amplitudes |

Côté annales, restent **hors fiche** — et désormais hors des deux cours — la
coxarthrose (QCM 2 de 2020/2021), la rupture du ligament croisé antérieur
(QCM 9 de 2020/2021), l'examen du rachis (QCM 19 de 2022/2023 S2, QCM 17 de
2019/2020 juin S1), les degrés de liberté de la hanche (QCM 13 de 2019/2020 juin
S1) et la polyarthrite rhumatoïde dans son détail clinique et biologique (QCM 18
et 19 de 2017/2018 S2). La douleur nociceptive du genou (QCM 3 de 2020/2021)
s'appuie sur le cours 2023-24. Ces cartes restent valables : les annales sont
celles de l'examen.

## Non carté dans le ronéo 2026-27

Quelques passages n'ont pas été cartés, faute d'être sûrs ou lisibles :
l'incidence des fractures vertébrales, illisible (« 10,7/1000 de l'ESCF (chez
la femme) : 16,8/10 000 », p. 6) ; la prévalence de la goutte, « 1,4/1000 »
(p. 6), fausse : 0,9 % de la population adulte française (Bardin et al.,
*Arthritis Care Res* 2016) ; « une femme sur trois possèdera une prothèse de
genou » (p. 8), douteuse ; l'os à « 2 % d'eau » (p. 10), faux : l'eau fait
environ 20 % du volume de l'os cortical (Granke et al., *Calcif Tissue Int*
2015) ; ces trois-là sont dans `contenu/ERRATA_RONEOS_2026-27.md` ; la phrase
sur « le fibroblaste [qui] évolue vers l'ostéocyte mature » (p. 10), douteuse
(l'ostéocyte vient de l'ostéoblaste, lui-même issu d'une cellule
mésenchymateuse) ; la phrase sur la parathormone et la
calcitonine (p. 10) ; l'ancien nom « polyarthroïdie ankylosante » de la
spondyloarthrite (p. 7) ; les macrophages qui « mangent le cartilage » (p. 11).
Le cartilage et la cornée « seuls tissus non vascularisés » (p. 11) est carté
sans le « seuls », et l'ATTENTION de `ost-qc-cartilage` B dit pourquoi, et
que c'est un point douteux. La définition de l'oligoarthrite (trois articulations,
p. 13) est celle du cours ; la carte note que d'autres sources vont de deux à
quatre.

## Sans illustration

Avant l'échelle, aucun des 49 QCM n'était illustré ; depuis le 16/10, ses 39 marches
portent le schéma `ech-osteo` (39 QCM illustrés sur 90, 43 %), et les annales le
schéma à lettres en correction, que le hook ne compte pas. Le chapitre n'atteint
pas la moitié. Les figures du ronéo 2026-27 (les images de l'imagerie, p. 14, et
celles des pages 1 et 6) et celles du Charonéo 2023-24 appartiennent à leurs
auteurs : elles ne s'ajoutent pas aux cartes. La
matière de l'année est surtout verbale — histoire, champ, épidémiologie,
interrogatoire, classification — et ne se dessine pas. Trois schémas
redessinés seraient utiles et restent à faire, dans `schemas.py` : les deux
radiographies en miroir (pincement localisé et ostéophytes contre pincement
global et érosions), le genu valgum et le genu varum, le choc rotulien.

## À relire

Aucune carte ne porte le tag `a-relire` : chaque carte de cours cite sa page,
du ronéo 2026-27 ou du Charonéo 2023-24, et chaque carte d'annales sa clé.

## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026)

L'échelle du pilote de l'immunité innée, étendue au tissu sanguin et aux trois derniers chapitres de sémiologie pour l'examen du 4/11 (Vincent, 16/10 : « on continue pour les chapitres que je vais avoir à l'examen »). Sous les annales, 31 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 8 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `douleur` | 1 | 1 | 1 |
| `rythmicite` | 7 | 2 | 6 |
| `inspection` | 7 | 1 | 6 |
| `rhumatologie` | 2 | 0 | 1 |
| `rhumatismes` | 5 | 1 | 3 |
| `paracliniques` | 3 | 1 | 1 |
| `hors-fiche` | 6 | 2 | 7 |

**Le schéma** `ech-osteo`, « Sémiologie ostéo-articulaire · mécanique ou inflammatoire », donne 65 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_OSTEO`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Questions négatives.** 2020/2021 QCM 6 et 2021/2022 QCM 14 demandent ce qui n'est pas évocateur : leurs lettres disent la vérité de chaque proposition, et la réponse attendue est la lettre rouge (`"negatives"` du mécanisme, `echelle.py`).

**ATTENTION posés** : le dérouillage, 30-45 minutes en 2026-27 contre une heure dans le cours 2023-24 et la clé de 2025/2026 QCM 7 (s3, s4, m2) ; la douleur mécanique « soulagée par l'activité » (s7, m1) ; les nodules de Bouchard de la table du polycopié (s13, m3) ; la goutte « dite inflammatoire » (s16, m4) ; les maladies musculaires (s24) ; macrogéode ou micro géodes, question ouverte (m5). La Moyen m4 sert aussi le thème de la rhumatologie.

**Sans marche** :
- ost-an-2021-q6 B, D : les amplitudes et la mobilisation douloureuse d'une arthrite septique ; ni le ronéo 2026-27 ni l'appoint ne les décrivent, la justification raisonne sans source de cours
- ost-an-2021-q19 B, D : l'anesthésie et la nécrose, intrus qu'aucun cours ne nomme
- ost-an-2122-q13 E : la bursite, absente des deux cours et de l'appoint
- ost-an-2223s2-q19 A, C, E : dorsalgie, attitude antalgique, position d'examen ; l'examen du rachis manque aux deux cours et à l'appoint, la clé seule les tient
- ost-an-1920s1-q17 A, C, D : la sciatique, ses racines, la manœuvre de Lasègue ; absentes des deux cours et de l'appoint
- ost-an-2021-q2 A, B, C : la douleur, le surpoids et l'âge de la coxarthrose ; le surpoids dans l'arthrose (p. 8) est déjà carté par ost-qc-arthrose, et le schéma n'a pas de case de terrain
- ost-an-2021-q9 E : le ressaut rotatoire, que seule la justification décrit
- ost-an-2021-q3 C, E : le coup de poignard et le mal de dent lancinant ; ni l'appoint ni le cours 2023-24 ne les nomment
- ost-an-1718s2-q19 C, D : thrombocytose et anémie inflammatoires ; aucun cours ne les donne
- ost-an-1718-q19 E : l'ostéoporose, qui ne fait mal que par ses fractures ; le ronéo dit ses complications (p. 8), le schéma n'a pas de case osseuse

## Régénérer

```
python generer.py
```

Le script valide avant d'écrire : une justification manquante, un trou de plus
de deux mots, une page hors de la fiche, un conflit déclaré et non signalé — et
il refuse d'écrire.
