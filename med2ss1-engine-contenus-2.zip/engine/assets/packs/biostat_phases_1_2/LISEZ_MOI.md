# Développement d'un médicament et études cliniques de phase I et II — paquet Biomédecine quantitative

138 notes, 212 cartes. Chapitre `chap-ue-biomed-quanti-fc8` de l'UE Biomédecine
quantitative, ordre 5. Cours du **Pr N. Penel et du Pr G. Ficheur, le
12/11/2025** (8 h-10 h), « Développement d'un médicament et études cliniques de
phase I et II — exemple des anticancéreux » (FC n°5 du Ronéosaure 2025-26,
16 pages) ; annales des polycopiés « 8.Essais de phases 1 et 2 » (80 questions)
et « 9. Essais thérapeutiques de phase III » (3 questions) du Ronéosaure
2024-25, 83 questions sur 18 sessions. Examen du 16 décembre 2026.

**Une fiche provisoire.** Le ronéo 2026-27 de ce cours n'est pas paru au
02/10/2026 : le chapitre est carté sur le Ronéosaure 2025-26 (tâche C15,
décision de Vincent du 02/10), et le ronéo de l'année corrigera les cartes à sa
parution. La source porte son année dans son auteur (« Ronéosaure 2025-26 ») :
chaque carte de cours prend le tag `cours-2025-26` et montre « Cours 2025-26 ».
Aucune carte ne dit « Absent du cours 2026-27 », et les erreurs du Ronéosaure
sont dites par un ATTENTION sans genre : la liste des erreurs de la promo,
`contenu/ERRATA_RONEOS_2026-27.md`, ne concerne que les ronéos 2026-27.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 97 | 97 |
| QRU | 2 | 2 |
| Texte à trous | 14 | 86 |
| QROC | 8 | 8 |
| Recto-verso | 7 | 7 |
| Schéma cliquable | 1 | 3 |
| Planche à légender | 1 | 1 |
| Lexique | 8 | 8 |

Dont **83 annales** (82 QRM, 1 QRU), sur 18 sessions, de 2015/2016 S1 à
2023/2024 S2. Les 16 QCM du cours ont, comme les annales, une justification
par proposition.

Huit thèmes, dans l'ordre du cours :

| Clé | Libellé |
|---|---|
| `developpement-medicament` | Développement d'un médicament (partagé avec `biostat_phase_3`) |
| `preclinique` | Phase préclinique et première dose |
| `escalade-dose` | Phase I : escalade de dose |
| `protocole` | Protocole et analyses pré-spécifiées (partagé avec `biostat_phase_3`) |
| `tests` | Tests statistiques (celui de `remed_biostats`, même libellé) |
| `risques-alpha-beta` | Risques α et β, puissance |
| `nombre-sujets` | Nombre de sujets nécessaires (partagé avec `biostat_phase_3`) |
| `phase-ii-recist` | Phase II : critère RECIST et proportions |

Sept libellés nouveaux, à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`). **Deux clés diffèrent du plan
C15** : `phase-1` et `phase-2` portaient un chiffre, et une clé qui porte un
chiffre est une provenance, pas un thème (`scopes.is_theme`) ; elles deviennent
`escalade-dose` et `phase-ii-recist`, aux libellés du plan.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-biomed-ec1-2526` — Ronéosaure, « FC n°5 Développement d’un médicament et études cliniques de phase I et II » (16 p.), `BIOMEDECINE QUANTI/…` | **2025-26** | **la base** : chaque note du cours porte sa page ; c'est ce que le lecteur ouvre (`chapitre=`) |
| `src-annales-8-essais-de-phases-1-et-2` — « 8.Essais de phases 1 et 2 » (32 p., table p. 31-32) | 2024-25 | 80 des 81 questions ; la 2019/2020 S1 Q6 est au chapitre de la phase III |
| `src-annales-9-essais-therapeutiques-de-phase-iii` — « 9. Essais thérapeutiques de phase III » | 2024-25 | 2023/2024 S2 Q15 et Q17, 2021/2022 S1 Q14 |
| errata des cours 2025-26 (`Erratas Biomédecine Quanti.docx`) et errata des annales 2024-25 | — | une entrée sur la FC n°5 (p. 15), une sur le polycopié 8 (2023/2024 Q14) : reprises |
| cours 2024-25 (FC Phase I-II, Ronéosaure 2024-25) | 2024-25 | cité une fois dans le texte d'une justification (le test « sert à répondre à une question : notre objectif principal », p. 18), sans être déclaré |

**Les deux polycopiés d'annales sont déclarés avec exactement les champs
prescrits pour les chapitres écrits en parallèle** (identifiant tiré du nom du
fichier, `kind`, `titre`, `chemin_relatif`, `auteur`, rien d'autre) : le
chapitre de la phase III, qui prend la plupart des questions du polycopié 9 et
une du polycopié 8, doit les déclarer à l'identique.

**Une session, un polycopié.** Le générateur ne cite qu'une source par session
(`SRC["sessions"]`). La 2023/2024 S2 cite le polycopié de phase III ; la
2021/2022 S1 Q14, seule question du polycopié 9 dans une session que le
polycopié 8 couvre aussi, cite le polycopié 8, et son explication dit où elle
est vraiment imprimée.

Vérifications hors du cours, citées dans la carte qui s'en sert : la loi
binomiale (règle de décision de 2019/2020 S1 Q5 E, puissance de l'éribuline),
Colquhoun (R Soc Open Sci 2014) pour ce que α ne dit pas ; l'étymologie (TLFi,
Bailly, Gaffiot, Wiktionnaire).

## Ce que le cours a dicté

- **Le rouge** — le processus « long, coûteux », la première dose (1/10 de la
  DL10), l'objectif principal de la phase I, la DMT (2/3 ou 2/6) — a chacun sa
  carte : `ec1-fa-entonnoir`, `ec1-qc-premiere-dose`, `ec1-fa-toxicologie`,
  `ec1-qr-dl10`, `ec1-fa-objectifs-phase1`, `ec1-qc-dmt`, `ec1-qr-dmt`,
  `ec1-fa-tdl`.
- **Le gris** : l'éribuline en phase I (« pas à retenir », p. 7) et la
  structure de l'article au-delà de « Matériel et méthodes » (« à titre de
  curiosité », p. 7). Aucune carte ne les interroge ; la diapositive de
  l'éribuline en phase I n'est pas reprise. L'éribuline de la phase II (p. 16)
  n'est pas grise : elle a sa carte, son texte à trous et illustre cinq
  corrections.
- **Ce qui appartient à un autre chapitre n'est pas carté** (plan C15) : les
  phases en général et la phase III, les risques et le nombre de sujets en
  phase III, le SAP, CONSORT, l'intention de traiter (`biostat_phase_3`).
  Le texte à trous du tableau des phases (`ec1-fa-quatre-phases`, p. 2) ne
  troue que les phases 1 et 2 ; les phases 3 et 4 y restent en clair.
- **La numérotation du ronéo** : le plan (p. 1) numérote la méthodologie « V »,
  le corps l'intitule « VII » (p. 7), comme la phase II (p. 14). Les cartes
  suivent le plan : « V.B Rédaction d'un protocole ».

## Les erreurs du Ronéosaure 2025-26

| Page | Ce que dit le Ronéosaure | Ce qui est juste | Sorte | Carte |
|---|---|---|---|---|
| 13 | α étant fixé à 5 %, « lorsqu'on conclut qu'un médicament marche, on se trompe 1 fois sur 20 » | α = probabilité de décider H1 quand H0 est vraie (diapositive de la même page) ; la part de conclusions fausses dépend aussi de la puissance et de la proportion de traitements efficaces (Colquhoun 2014) | le cours lui-même, à l'oral — à l'examen : α = 5 %, risque de première espèce | `ec1-qc-risque-alpha` (explication) |
| 16 | « on est certain d'exclure H0 » | on rejette H0 au risque α = 5 % ; un test ne conclut jamais à coup sûr (p. 13) | prise de notes | `ec1-qc-eribuline` E |
| 15 | les deux calculs de nombre de sujets (47, 164) sans la règle | l'errata 2025-26 ajoute : « plus la différence entre p0 et p1 est petite, plus il faut de patients » | ajout de l'errata | `ec1-qc-nombre-sujets` C, `ec1-fa-nombre-sujets` |
| 16 | diapositive de l'éribuline : « Observé (21.5%) » pour 17 réponses sur 80 | 17/80 = 21,25 % ; la décision (17 ≥ 13) n'en dépend pas | point douteux (arrondi fautif, ou 79 patientes évaluables ?), relevé en relisant | `ec1-fa-eribuline`, `ec1-qc-eribuline` (explications) |

Sans ATTENTION, parce qu'aucune réponse n'en dépend : la zone compatible avec
H0 sur 50 lancers, [18 ; 32], « 95 % » sur la diapositive, en contient
exactement 96,7 % (dit dans `ec1-qc-raisonnement` et `ec1-fa-piece`) ; la
numérotation « VII » répétée (ci-dessus).

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| La puissance : 1 − β, le nombre de sujets, la phase 2 | 2023/2024 S1 Q13, 2022/2023 S1 Q22, 2022/2023 S2 Q8, 2021/2022 S1 Q11, 2021/2022 S2 Q10, 2020/2021 S1 et S2 Q36, 2019/2020 S1 Q2, 2019/2020 S2 Q13, 2018/2019 S1 Q2, 2018/2019 S2 Q13, 2017/2018 S1 QCM 6, 2017/2018 S2 Q9, 2023/2024 S2 Q15 (quatorze) |
| La population éligible en phase I | 2022/2023 S1 Q21, 2021/2022 S2 Q9, 2020/2021 S1 et S2 Q35, 2019/2020 S2 Q12, 2018/2019 S2 Q11, 2017/2018 S2 Q5, 2016/2017 S1 et S2 Q30, 2015/2016 S1 et S2 Q26 (onze) |
| « Exposer des cohortes successives… » : la phase 1 | 2023/2024 S1 Q15, 2022/2023 S1 Q24, 2022/2023 S2 Q10, 2021/2022 S1 Q12, 2021/2022 S2 Q13, 2020/2021 S1 et S2 Q39, 2019/2020 S2 Q16, 2018/2019 S2 Q14, 2017/2018 S1 QCM 7, 2023/2024 S2 Q17 (onze) |
| Le risque α (ou β) en phase II | 2023/2024 S1 Q14, 2022/2023 S1 Q23, 2022/2023 S2 Q9, 2021/2022 S1 Q10, 2021/2022 S2 Q12, 2020/2021 S1 et S2 Q38, 2019/2020 S2 Q15, 2018/2019 S1 Q4, 2017/2018 S1 QCM 5 (dix) |
| L'escalade 3 + 3 sur un tableau | 2021/2022 S1 Q13, 2021/2022 S2 Q8, 2020/2021 S1 et S2 Q34, 2019/2020 S1 Q3, 2019/2020 S2 Q11, 2018/2019 S1 Q1 (sept) |
| Le principe du test de phase II | 2021/2022 S1 Q9, 2021/2022 S2 Q11, 2020/2021 S1 et S2 Q37, 2019/2020 S2 Q14, 2017/2018 S1 QCM 4, 2017/2018 S2 Q8 (sept) |
| d1, d2 : un événement toxique sur trois | 2020/2021 S2 Q40, 2018/2019 S2 Q12, 2016/2017 S1 et S2 Q32, 2015/2016 S1 et S2 Q28 (six) |
| Les objectifs de la phase I | 2019/2020 S1 Q4, 2017/2018 S2 Q4, 2016/2017 S1 et S2 Q29, 2015/2016 S1 et S2 Q25 (six) |
| L'objectif principal de la phase II | 2017/2018 S2 Q7 (QRU), 2016/2017 S1 et S2 Q31, 2015/2016 S1 et S2 Q27 (cinq) |
| Le développement d'un anticancéreux | 2021/2022 S1 Q8, 2017/2018 S1 QCM 3 |
| La conception d'une phase II (p0, p1, N, règle) | 2019/2020 S1 Q5, 2021/2022 S1 Q14 |
| La méthodologie de la phase I ; les prérequis | 2018/2019 S1 Q6 ; 2017/2018 S2 Q6 |

Une carte par question et par session (convention BMCT), même quand l'énoncé
revient mot pour mot : l'explication dit la récurrence. Les huit questions de
phases I-II que le polycopié de phase III recopie (2023/2024 S1 Q13 et Q15,
2022/2023 S1 Q22, 2021/2022 S1 Q11, 2020/2021 S2 Q36, 2019/2020 S2 Q13,
2017/2018 S1 Q6 et sa « Q9 ») ne sont cartées qu'une fois, sous leur référence
du polycopié 8. La session « 2023-2024 » du polycopié 8, sans numéro, est la
S1 d'après le polycopié de phase III.

## Le schéma cliquable et la planche

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `paliers-escalade.svg` (`ec1-zo-paliers`) | le palier de la première dose, celui de la dose recommandée, celui de la DMT | 3 |

Redessiné d'après l'exemple 2 du cours (diapositive p. 6) : cinq paliers (dose
1 ; 1,5 ; 2 ; 2,3 ; 2,6), trois patients, RAS ou TDL. Les flèches « dose
recommandée » et « dose maximale tolérée » de la diapositive sont retirées de
la version nue ; les paliers 2 et 3, qui ne se distinguent pas, n'ont pas de
zone. La version légendée, `paliers-escalade-legende.svg`, tirée des mêmes
constantes, illustre la correction de la zone, de `ec1-qc-dmt` et des sept
annales à tableau d'escalade.

**La planche** `ec1-pl-risques` : la diapositive « Les 2 risques » (p. 13),
légendes effacées par `scripts/planche_depuis_image.py` — huit numéros : les
trois cases α, β, 1 − β du tableau vérité × décision, les deux lettres et les
deux noms d'espèce des définitions du bas, la puissance (1 − β) ; quatre
intrus : 1 − α (la case vide), p-valeur, niveau de confiance, prévalence. Les
lettres et les noms sont effacés ensemble : laissés, les « α = Proba(décider
H1 / H0 vraie) » situaient les cases. L'aperçu de contrôle a été relu ; le
rectangle du n°5 a été raccourci pour garder le signe « = ».

**Illustrations** : 85 QCM sur 99 (86 %) portent une diapositive de la fiche
ou l'escalade légendée en correction ; 108 notes sur 138. Les quatorze QCM sans
figure : les onze annales de la population éligible en phase I et trois cartes
du cours (`ec1-qc-population-phase1`, `ec1-qc-protocole`,
`ec1-qc-objectifs-criteres`) — la fiche n'a pas de figure sur la population ni
sur le protocole. Les deux coupes de scanner RECIST (p. 16) n'illustrent que des
cartes qui les commentent (`ec1-qc-phase2`, `ec1-qr-recist`).

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2016/2017 S2 Q29 (objectifs de la phase I) | AD | **ABCE** | la table de cette session recopie les clés des Q29-32 du polycopié de phase III, même session (AD, BE, ABE, AC) ; ABCE est la clé de 2017/2018 S2 Q4, même question au mot près. Conflits sur B, C, D, E |
| 2016/2017 S2 Q30 (population éligible) | BE | **A** | même recopie ; l'impasse thérapeutique, seule vraie dans les huit sessions où la table est fiable. Conflits sur A, B, E |
| 2016/2017 S2 Q31 (objectif de la phase II) | ABE | **B** | même recopie ; B dans les trois sessions fiables. Conflits sur A, E |
| 2016/2017 S2 Q32 (d1, d2) | AC | **E** | même recopie ; « inclure 3 patients supplémentaires à d2 », seule vraie dans les quatre sessions fiables. Conflits sur A, C, E |
| 2015/2016 S2 Q25 (objectifs de la phase I) | DE | **ABCE** | les quatre clés de la session (DE, DE, BDE, ABC) ne vont avec aucun des énoncés, d'origine inconnue. Conflits sur A, B, C, D |
| 2015/2016 S2 Q26 (population éligible) | DE | **A** | idem. Conflits sur A, D, E |
| 2015/2016 S2 Q27 (objectif de la phase II) | BDE | **B** | idem. Conflits sur D, E |
| 2015/2016 S2 Q28 (d1, d2) | ABC | **D** | idem ; A, B et C se contredisent entre elles. Conflits sur A, B, C, D |

Ces huit questions portent `officielle=False` ; leur explication commence par
« Clé déduite du cours, absente de la table de corrections » (convention du
plan C15 pour les tables recopiées), et chaque item dont le verdict change
porte son ATTENTION et son entrée dans `CONFLITS` (25 en tout).

Reprises telles quelles, avec une remarque dans la carte :

- **2023/2024 S1 Q14** : l'énoncé dit « le risque Bêta (risque de première
  espèce) » ; β est de deuxième espèce. L'errata des annales le relève, sans
  avis. Énoncé gardé, clé ABCD reprise ; ATTENTION sur E (la définition de α,
  que l'erreur ferait cocher), conflit déclaré.
- **2019/2020 S1 Q5 A** : imprimée « H0 pp0 », le signe ≤ a sauté ; rétabli
  (« H0 : p ≤ p0 ») et dit dans la justification. Clé AB reprise.
- **2016/2017 S1 Q32 B** : « cet essai ne permet pas de déterminer la dose
  recommandée » donnée fausse : l'essai continue au palier d2 et donnera la
  dose ; la justification le dit.
- **2017/2018 S2 Q6 E** : le CPP « a donné son autorisation » donné vrai ; le
  ronéo le dit ainsi (p. 4), la justification précise que le CPP rend un avis
  et que l'ANSM autorise (p. 7).

Cas ouvert : aucun.

## Le lexique

Huit termes, aux pages mesurées dans la fiche 2025-26 (`chercher_pages.py`,
page du plan exclue) : préclinique (p. 2, 3, 8, 11, 16 ; écrit aussi
« pré-clinique »), toxicologie (4), mitotique (3), immortalisé (3,
« immortalisées »), hypothético-déductif (8), binomial (12), protocole (5, 7,
8, 10, 11, 13, 14), neutropénie (5). Chacun dit son origine grecque ou latine.
« Hypothético-déductif » est aussi à la p. 3 de la FC n°11 (régression
logistique) : le terme cite cette page sous l'identifiant que le plan C15
donne à la fiche dans son chapitre, `src-fc-biomed-rlg-2526` (plan, 19.4 :
« déclarer les deux sources »), sans la déclarer ici, comme on cite les FC de
sémantique ; la page s'ouvrira quand le chapitre de la régression logistique
sera importé.

Les étymologies nouvelles — neuf racines (`clin-`, `mit(o)-`, `mors (latin)`,
`thesis (grec)`, `deducere (latin)`, `bi- (latin)`, `nomen (latin)`, `proto-`,
`colla- (grec)` ; `bi- (latin)` reprend à l'identique la clé et l'étymon que
propose `bmct_metabolisme`) et les huit termes — sont **proposées** pour
`scripts/etymologies.json` (fichier `etym/biostat_phases_1_2.json` du
brouillon de la tâche C15), avec leurs sources ; la table n'est pas modifiée
par ce chapitre. Les définitions et les racines disent déjà, mot pour mot, ce
qu'`appliquer_etymologies.py` en écrira. Les racines réemployées gardent la
clé de la table : `pré- (latin)`, `tox(i)-`, `-logie, de logos (grec)`,
`hypo-`, `in- (latin)`, `neutr(o)-`, `-pénie`. Celles que les FC de sémantique
2026-27 enseignent citent leur page : pré-, proto-, hypo- (2/2, p. 10), clin-
(2/2, p. 11), -pénie (2/2, p. 3), -logie (1/2, p. 5), colla- (1/2, p. 6).

## Questions pour Vincent

Les propositions du plan sont appliquées et signalées sur les cartes ; restent
à trancher :

1. **La phrase de α (p. 13)** : le plan la range dans « le cours lui-même »
   (la carte répond comme le professeur : α = 5 %, risque de première
   espèce) ; mais la diapositive de la même page définit α juste, ce qui en
   ferait plutôt une prise de notes. La carte le dit ; à confirmer quand le
   ronéo 2026-27 paraîtra.
2. **Une source par session** : faut-il que le modèle de générateur accepte une
   source par note (`source=`), pour que la 2021/2022 S1 Q14 cite le polycopié
   de phase III ? Le chapitre des dispositifs médicaux a le même cas.
3. **Les clés de thème** `phase-1` et `phase-2` du plan, renommées
   `escalade-dose` et `phase-ii-recist` (un chiffre fait d'une clé une
   provenance) : à reprendre dans le plan et dans `THEME_LABELS`.

## À relire

Aucune carte `a-relire` : chaque carte de cours porte sa page dans la fiche
2025-26, chaque annale sa clé vérifiée proposition par proposition (tableaux
d'escalade relus dans le PDF). À la parution du ronéo 2026-27 de ce cours,
relire toutes les cartes contre lui : pages, chiffres (10 000 molécules, 25-30
ans, 800 millions, 0,5 %, 1 sur 6, 47 et 164 patients, 13/80 et 17/80), et les
erreurs ci-dessus.

## L'échelle : Simple → Moyen → Annale (C20, 18/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 16 décembre. Sous les annales, 46 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 11 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `developpement-medicament` | 2 | 1 | 2 |
| `preclinique` | 2 | 1 | 1 |
| `escalade-dose` | 23 | 4 | 42 |
| `tests` | 4 | 1 | 7 |
| `risques-alpha-beta` | 11 | 2 | 24 |
| `phase-ii-recist` | 4 | 2 | 7 |

**Les schémas** sont au nombre de 2 : `ech-phase-1`, « La phase I d'un anticancéreux · laboratoire, patients, paliers » (27 Simple, 6 Moyen, 45 annales ; 79 fichiers), et `ech2-test-phase-2`, « Deux risques, une puissance, une décision » (19 Simple, 5 Moyen, 38 annales ; 63 fichiers). Une carte ou une annale va au schéma de son mécanisme. Ils sont décrits dans `schemas.py` (`ECH_PHASE_1`, `ECH2_TEST_PHASE_2`, avec leurs `TROUS_*` et `LETTRES_*`, un `FICHIERS.update` chacun) et dessinés par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- E des onze annales « cohortes successives » (2023/2024 S1 Q15, 2022/2023 S1 Q24, 2022/2023 S2 Q10, 2021/2022 S1 Q12, 2021/2022 S2 Q13, 2020/2021 S1 Q39, 2020/2021 S2 Q39, 2019/2020 S2 Q16, 2018/2019 S2 Q14, 2017/2018 S1 QCM 7, 2023/2024 S2 Q17), « étude de phase 4 » : la phase IV, post-marketing (p. 2), se carte au chapitre biostat_phase_3 (plan C15). Elle est écrite en clair dans la case « Les phases suivantes », où sa lettre est posée ; la Moyen m1 couvre déjà A à D et n'a que quatre propositions.
- ec1-an-1718s2-q7 E, ec1-an-1617s1-q31 C, ec1-an-1617s2-q31 E, ec1-an-1516s1-q27 E, ec1-an-1516s2-q27 E — « identifier des facteurs prédictifs de décès » : la FC n°5 2025-26 ne parle ni de pronostic ni de facteurs prédictifs ; la justification de l'annale le tranche sans page. Aucune marche ne peut le citer (règle 1). Deux de ces lettres portent un conflit (CONFLITS 2016/2017 S2 Q31 E, 2015/2016 S2 Q27 E), dit par la carte de l'annale.

## Régénérer

```powershell
cd contenu\chapitres\biostat_phases_1_2
..\..\..\app\.venv\Scripts\python.exe generer.py
```

La planche se refait depuis `app/`, si ses rectangles changent (Pillow n'est
pas une dépendance du projet) :
`uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/biostat_phases_1_2 ec1-pl-risques --apercus <brouillon>`.
