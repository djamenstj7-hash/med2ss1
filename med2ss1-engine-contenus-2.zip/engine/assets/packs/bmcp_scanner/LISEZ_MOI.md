# Scanner : contraste, lecture des images — paquet BMCP

80 notes, 139 cartes. Chapitre `chap-ue-bmcp-fc19` de l'UE BMCP, vingt et
unième de l'UE (`ordre=21`). Cours du **Pr Olivier Ernst, le 10/12/2025, de 9 h
à 10 h**, dans le **Ronéosaure 2025-26** (FC n°21, 10 pages) ; les annales du
polycopié BMCP 19 du Ronéosaure 2024-25 (10 sessions) et la Q. 28 du **sujet
de 2024/2025 S1** (examen du 09/01/2025, sans corrigé, déposé le 15/10/2026).
Examen : partiel du mardi 5 janvier 2027.

**Fiche provisoire** (C16, décision de Vincent du 02/10) : le ronéo 2026-27 de
ce cours n'est pas encore paru. Chaque carte de cours cite la FC 2025-26 à sa
page et porte le badge « Cours 2025-26 » (tag `cours-2025-26`, lu dans
l'auteur de la source) ; le ronéo 2026-27 la corrigera à sa parution.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 37 | 37 |
| QRU | 2 | 2 |
| Texte à trous | 12 | 62 |
| QROC | 12 | 12 |
| Recto-verso | 8 | 8 |
| Schéma cliquable | 2 | 11 |
| Planche à légender | 1 | 1 |
| Lexique | 6 | 6 |

Dont **17 annales** sur 11 sessions : 15 QCM et 2 QROC (un QROC qui se tape,
un recto-verso), toutes du polycopié BMCP 19 sauf la Q. 28 de 2024/2025, du
sujet de l'examen.

Six thèmes, tous nouveaux ; leurs libellés (ceux du plan C16) sont dans `THEME_LABELS` (`app/src/med_engine/application/scopes.py`) depuis l'intégration du 05/10 :

| Clé | Libellé | Notes |
|---|---|---|
| `unites-hounsfield` | Unités Hounsfield et échelle de gris | 17 |
| `fenetrage` | Régler l'échelle de gris : centre et largeur | 15 |
| `injection-iodee` | Injection de produit de contraste iodé | 17 |
| `dangers-scanner` | Dangers du scanner | 3 |
| `lecture-scanner` | Lecture d'un scanner | 13 |
| `foie-phases` | Tumeurs du foie et phases d'injection | 9 |

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-bmcp-sct-2526` — Ronéosaure, « FC n°21 - Scanner, contraste, lecture des images » (10 p.) | 2025-26 | le cours ; `SRC["fiche"]`, ses figures |
| `src-annales-bmcp-19-scanner-et-contraste` — « BMCP 19 - Scanner et Contraste » | 2024-25 | 10 sessions, 15 QCM et 2 QROC, table p. 6 |
| `src-sujets-bmcp-2425` — « Sujets de BMCP 2024/2025, session 1 » (examen du 09/01/2025, 30 p.) | 2024-25 | la session 2024/2025 S1 (Q. 28) ; sujet sans corrigé ; déclarée à l'identique dans tous les chapitres de BMCP qui en tirent une question |

La source d'annales est déclarée avec les seuls champs convenus (id, kind,
titre, chemin, auteur) : un autre chapitre qui cite ce polycopié doit la
déclarer à l'identique. Le polycopié BMCP 15, qui recopie les deux questions de
2023/2024 S2, n'est pas déclaré : il n'est cité que dans leurs justifications.
Lus en appoint, sans être déclarés : l'errata des cours 2025-26 et celui des
annales (rien sur ce cours ni sur BMCP 19), la FC n°15 2025-26 (dose d'un
scanner abdomino-pelvien, partie 1 p. 6). Les pages citées sont celles du PDF,
identiques à celles imprimées.

Les en-têtes du ronéo, du polycopié et des erratas portent des noms
d'étudiants : aucun n'est repris.

## Ce que le cours a dicté

- **Le plan du cours fait les thèmes** : I-II (plages, UH, échelle de gris),
  III (sans et avec injection), IV (dangers), V (lecture), VI (foie), VII
  (messages).
- **Le rouge** du ronéo (l'air, « Eau : 0 UH », « Air : −1000 UH », « tous les
  scanners ») a ses cartes : `sct-fa-valeurs-uh`, `sct-zo-hounsfield`,
  `sct-qc-uh-definition`. **Le gris** (le calcium p. 2 ; la spécialité du
  professeur, la question d'un étudiant et la réponse du professeur sur les
  tumeurs hypovasculaires p. 9) est la voix des rédacteurs, cartée comme le
  reste : la réponse du professeur fait `sct-qc-hypovasculaire` C.
- **Le calcul centre / largeur** (noir au-dessous de C − L/2, blanc au-dessus
  de C + L/2) a son texte à trous de principe et deux textes à trous chiffrés
  sur les exemples du cours (0/400, 110/350, 120/600), un QCM, et deux QROC sur
  les réglages des annales (60/120, 90/200). La correction ignore les signes :
  dans les trous chiffrés, le signe reste hors du trou, et il se travaille dans
  les QCM et sur la réglette cliquable.
- **Ce qui n'est pas carté ici** (plan C16, § 0.7) : la physique du scanner
  (`bmcp_bases_physiques`), les produits de contraste en général et le détail de
  leurs effets indésirables (FC 16), la radioprotection (FC 15). Les cartes les
  citent.

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| Les repères de l'échelle : vide, eau, os, graisse ; même échelle pour tous les scanners ; « la graisse noire comme l'air car même densité » (faux) | 2024/2025 S1 Q.28, 2023/2024 S2 Q.18, 2022/2023 S1 Q.28, 2021/2022 S2 Q.28, 2018/2019 S1 Q.26, 2015/2016 S2 Q.28, 2017/2018 S1 (deux QROC) |
| La densité scanographique et l'échelle de gris : définition, qui la règle, le centre | 2021/2022 S1 Q.24, 2019/2020 S2 Q.27 |
| Le calcul centre / largeur | 2020/2021 S2 (90/200), 2019/2020 S2 Q.27 B (60/120) |
| L'injection : délai d'acquisition, tumeur sans injection, réglage fracture / hématome, études tumorales, plans de l'espace, vaisseaux du scanner injecté | 2023/2024 S2 Q.19, 2022/2023 S2 Q.27, 2019/2020 S2 Q.28, 2018/2019 S1 Q.27, 2017/2018 S1 Q.28 |
| Le principe : irradiation, coupes, durée, une ou deux acquisitions | 2021/2022 S1 Q.20 |

Chaque question a sa carte, même quand elle revient presque mot pour mot ;
l'explication renvoie aux autres sessions. Les deux questions de 2023/2024 S2
sont aussi imprimées dans le polycopié BMCP 15 (même numéro, même clé) : une
carte chacune, ici, qui le dit. La Q.28 de 2016/2017 S1 de ce polycopié
(physique du scanner) est au chapitre des bases physiques (plan C16, § 10).

**2024/2025 S1 Q.28 reprend 2022/2023 S1 Q.28**, les propositions dans un
autre ordre (A = l'ancienne E, C = C, D = D, E = l'ancienne A), deux d'entre
elles changées : le vide « égal à 500 UH » (300 en 2022/2023), le scanner
« basé sur l'absorption des rayons gamma » (« la réflexion des ultrasons » en
2022/2023) ; l'énoncé perd « (ou tomodensitométrique) ». Clé AD, les deux mêmes
vraies que la clé DE de 2022/2023.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2019/2020 S2 Q.27 | « Pas de correction » | AB, `officielle=False` | clé déduite du cours : eau 0 UH (p. 3) ; centre 60, largeur 120 → noir au-dessous de 0 UH, l'air et la graisse noirs (p. 4) |
| 2019/2020 S2 Q.28 | « Pas de correction » | BCDE, `officielle=False` | clé déduite du cours ; les propositions de 2018/2019 S1 Q.27, corrigées BCDE |
| 2017/2018 S1, 1er QROC | absente de la table | eau 0 UH, air −1000 UH (recto-verso) | clé déduite du cours, p. 3 |
| 2017/2018 S1, 2e QROC | absente de la table | 2 < 4 < 1 < 3 (poumon, graisse, foie, corticale) | clé déduite du cours (p. 3) ; le parenchyme pulmonaire, que le cours ne chiffre pas, est cité sur Radiopaedia (−950 à −650 UH) |
| 2024/2025 S1 Q.28 | aucune (sujet sans corrigé) | AD, `officielle=False` | clé déduite du cours : l'air vers −1000 UH, la même échelle pour tous (p. 3) ; le scanner mesure des rayons X, pas des rayons gamma (p. 2) ; la graisse vaut −80 UH, le vide −1000 (p. 3) |

Toutes les autres clés sont reprises telles qu'imprimées : aucune ne contredit
le cours 2025-26 ; `CONFLITS` est vide. Ce qui, sans changer de clé, est dit
dans la carte :

| Question | Le point |
|---|---|
| 2020/2021 S2 | énoncé numéroté « Q. 27 », table « Q.28 » ; seule question de la session dans ce polycopié : la clé BCE est la sienne (`num` = « Q. 27 (table : Q.28) ») |
| 2021/2022 S1 Q.24 | la tige parle d'« un examen scanographique », les propositions d'« elle » (la densité scanographique) : énoncé gardé tel quel, l'explication le dit |
| 2023/2024 S2 Q.19 E | « E. E. » imprimé : un « E. » doublé par la mise en page, absent de la copie de BMCP 15, non repris |
| 2022/2023 S1 Q.28 D | « en UHE. » : le « E. » de la proposition suivante collé par la mise en page, non repris |
| 2015/2016 S2 Q.28 E | l'os spongieux, que le cours ne chiffre pas : +300 à +800 UH (Radiopaedia), faux comme la clé |

## Les erreurs du Ronéosaure 2025-26

Le Ronéosaure n'est pas le ronéo de l'année : chaque erreur est portée par un
**ATTENTION nu** dans la carte qui tient la notion, la sorte dite dans le texte,
et rien n'entre dans `contenu/ERRATA_RONEOS_2026-27.md`.

| Page | Le ronéo dit | Retenu | Sorte | Carte |
|---|---|---|---|---|
| 6 | embolie pulmonaire, « caillot dans les veines pulmonaires » (remarque) | dans les **artères** pulmonaires : la même page plus bas et la diapositive | prise de notes | `sct-qc-indications-injection` B, `sct-qr-embolie` |
| 6 | phase tardive à 5 min : « les reins ont éliminé le produit de contraste : plus rien n'est opacifié » | phase d'équilibre de 2 à 20 min, élimination quasi complète à 30 min (même page, diapositive p. 5) | point douteux | `sct-qc-phases-foie` D |
| 7 | « un scanner abdominal équivaut à 5 ans d'irradiation naturelle » | un scanner abdomino-pelvien ≈ 9 mSv (FC 15 partie 1, p. 6) ; irradiation naturelle ≈ 3 mSv/an en France (IRSN, bilan 2014-2019), 2,4 mSv/an en moyenne mondiale (UNSCEAR) : 3 à 4 ans ; 5 ans suppose un examen plus irradiant, à plusieurs phases. À l'examen, comme le cours | point douteux | `sct-qc-dangers` B |
| 8 | la fracture vue en réglant « avec une largeur très faible » | fenêtre **large** (diapositive : « fracture os pariétal fenêtre large ») ; l'étroite est celle de l'hématome | prise de notes | `sct-qc-hematome-fracture` C, `sct-rv-fracture-hematome` |
| 8 | le pneumopéritoine vu « en bougeant la souris pour réduire la largeur » | en l'**élargissant** (diapositive : « fenêtre large : bien pour rechercher de l'air dans le péritoine » ; p. 3-4 du même ronéo) | prise de notes | `sct-qc-pneumoperitoine` B |

Les deux erreurs de la p. 8 n'étaient pas au plan, qui relevait les trois des
p. 6 et 7 : elles ont été trouvées en relisant les diapositives de la p. 8 contre
le texte du ronéo. Sans carte, parce qu'aucune n'en dépend : « une échelle de grille »
(p. 3), « des métastases d'un mélanome semi-osseux du patient et du foie »
(p. 8 ; la diapositive dit « Métastase mélanome »), « la droite à est toujours à
gauche de l'écran » (p. 7).

## Les schémas, la planche et les figures

**Deux schémas cliquables** (`schemas.py`), chacun avec sa version légendée en
correction :

| Fichier | Ce qu'on clique | Pourquoi ce dessin |
|---|---|---|
| `echelle-hounsfield.svg` | l'air, la graisse, l'eau, le foie, l'os cortical (5 zones) | la réglette de la p. 3 redessinée de −1000 à +1000 UH, avec une loupe de −200 à +200 UH où graisse, eau et foie, à 50 ou 80 UH l'un de l'autre, se séparent ; seules les valeurs que le cours chiffre sont des zones (le poumon n'en est pas une) |
| `coupe-abdomen.svg` | le foie, la rate, l'aorte, le corps vertébral, la graisse sous-cutanée (anneau), l'air d'un pneumopéritoine (6 zones) | une coupe axiale d'abdomen haut, sans injection, en fenêtre tissus mous, présentée selon la convention (droite du patient à gauche de l'écran, p. 7) ; l'aorte a la densité des muscles (non injecté, p. 6) ; le pneumopéritoine là où la diapositive de la p. 8 dit de le chercher. Les lettres D et G ne sont que sur la version légendée : trouver le foie, c'est savoir la convention |

**Une planche à légender** (`sct-pl-phases`) : la diapositive des quatre phases
d'un scanner hépatique (p. 6), ses quatre légendes blanchies par
`scripts/planche_depuis_image.py` (rectangles dans `donnees.py`, aperçu de
contrôle relu). Les numéros ne suivent pas l'ordre de lecture (1 = tardif,
2 = sans injection, 3 = portal, 4 = artériel), sinon la séquence se
devinerait ; deux intrus : « Temps pulmonaire (20 s) », « Élimination complète
(30 min) ». Le plan proposait des zones posées sur cette figure : ses légendes
sont imprimées dans l'image, c'est donc une planche, qui les efface.

**Vingt figures de la FC 2025-26**, extraites en PNG (1000 px de large au plus,
256 couleurs) : les quatre plages (p. 2), trois échelles de gris (p. 3), les UH
(p. 3), hyper- et hypodense (p. 3-4), centre et largeur (p. 4), les fenêtres de
la graisse et de l'air (p. 4-5), le scanner sans injection (p. 5), la
distribution du produit iodé (p. 5), les quatre phases (p. 6), injecté ou non
(p. 6), l'embolie pulmonaire (p. 6), l'hématome et la fracture, le
pneumopéritoine, les deux cerveaux, la métastase cérébrale, les adénopathies
(p. 8), les tumeurs hypo- et hypervasculaires (p. 9-10), les reconstructions
coronales (p. 10). Ce sont des coupes de scanner, la matière du cours, pas des
photographies de patient. **Trois captures portaient des données de patient**
incrustées par la console du scanner, masquées à la relecture du 05/10 :
un nom (en haut de la coupe « sans injection » de `sct-foie-hypovasculaire.png`),
une date de naissance et un identifiant (coins de `sct-fenetres-graisse.png`),
et les mêmes cartouches, illisibles, sur `sct-fenetres-air.png`. Les autres
figures n'en portent pas (vérifié coin par coin) ; les cartouches techniques
(kV, filtre, « IV CONTRAST ») restent. Deux des figures sont la question
(`illustration_question`) : les deux cerveaux (« lequel est injecté ? », p. 8)
et l'aorte comparée aux muscles (p. 6) — la diapositive pose elle-même la
question et n'imprime pas la réponse.

**37 QCM sur 39 illustrés (95 %)**, 69 notes sur 80. Sans figure :
`sct-qc-dangers` et `sct-qc-messages`, qu'aucune figure du ronéo ne montre.

## Le lexique

Le plan C16 donnait neuf termes. **Trois existent déjà** dans la bibliothèque,
au même identifiant, dans la sémiologie : Hématome (`semio_blessures`),
Pneumopéritoine (`semio_digestive`), Adénopathie (`semio_gyneco`). Un
identifiant, un terme : ils y restent (précédent d'`immuno_organes` pour
l'adénopathie). Les six autres sont accueillis ici ; pages mesurées dans la FC
2025-26 (`chercher_pages.py`) :

| Terme | Origine | Pages |
|---|---|---|
| Hyperdense | grec ὑπέρ + latin densus | 3, 5, 7, 8, 9 |
| Hypodense | grec ὑπό + latin densus | 4, 9 |
| Hépatocarcinome | grec ἧπαρ + καρκίνωμα | 3, 7, 10 |
| Embolie | grec ἐμβολή | 6 |
| Hypervasculaire | grec ὑπέρ + latin vasculum | 9, 10 |
| Hypovasculaire | grec ὑπό + latin vasculum | 9 |

`hyper-` (2/2, p. 9) et `hypo-` (2/2, p. 10) sont enseignées par la FC de
sémantique et la citent. Trois racines nouvelles — `densus (latin)`,
`carcin(o)-`, `embol- (grec)` — et les six termes sont proposés à la table
commune (`etymologies.json`), vérifiés sur le TLFi, le Wiktionnaire et le
Bailly ; les textes du lexique sont déjà écrits dans la forme que
`appliquer_etymologies.py` produirait. `hyper-`, `hypo-`, `hépat(o)-`, `-ome`
et `vasculum (latin)` reprennent les clés existantes.

## Décisions prises en route

- **Le brouillon du 03/10** (une course interrompue) ne contenait que
  `schemas.py` et dix-neuf figures : tout a été relu. Les figures sont justes et
  à leur page ; les deux schémas ont été rendus et vérifiés (zones sans
  recouvrement, valeurs du cours, convention droite-gauche). Le reste du
  chapitre est écrit dans cette tâche ; une vingtième figure (les
  reconstructions coronales, p. 10) et la planche s'y sont ajoutées.
- **`semaine`** est « Ronéosaure 2025-26 », comme les autres chapitres faits sur
  le Ronéosaure ; `EXAMENS` n'est pas déclaré (aucun chapitre BMCP n'en a).

## Questions pour Vincent

1. **Le lexique** : Hématome, Pneumopéritoine et Adénopathie, que le plan
   donnait à ce chapitre, existent déjà dans la sémiologie (même identifiant) ;
   ils y sont restés. Faut-il les accueillir aussi dans le lexique de la BMCP,
   ce qui demanderait une autre façon de partager un terme entre deux UE ?
2. **Les « 5 ans d'irradiation naturelle »** du scanner abdominal (p. 7) : la
   carte répond comme le cours et dit que le chiffre est douteux (un passage
   ≈ 9 mSv, soit 3 à 4 ans). À vérifier sur le ronéo 2026-27, ou auprès du
   professeur.

## À relire

**Aucune carte `a-relire`** : toutes citent une page de la FC 2025-26 ou une
source nommée ; les cinq clés absentes de la table (dont celle de 2024/2025,
sujet sans corrigé) se déduisent du cours.
Reste à Vincent :

- quand le ronéo 2026-27 de ce cours paraîtra, relire chaque carte sur lui et
  retirer le badge « Cours 2025-26 » ;
- `copier_les_cours.py` avec le dossier `…/examen janvier` du Ronéosaure
  2025-26, hors du bac à sable, pour que la fiche s'ouvre dans l'application.

## Intégration (05/10)

- Les libellés de thèmes sont dans `THEME_LABELS`
  (`app/src/med_engine/application/scopes.py`), bloc « BMCP FC n°6 à 22 ».
- Les étymologies proposées (racines et termes) sont versées dans
  `.claude/skills/nouveau-chapitre/scripts/etymologies.json` ;
  `appliquer_etymologies.py` n'a rien réécrit, les textes du lexique étant
  déjà à sa forme.
- `densus (latin)` n'a qu'une entrée, commune avec `bmcp_bases_physiques` ;
  son sens d'étymon est celui de ce chapitre (« épais, serré, compact »).

## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier (BMCP) ou du 6 janvier (SSH, papier). Sous les annales, 29 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 6 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `unites-hounsfield` | 13 | 2 | 9 |
| `fenetrage` | 4 | 1 | 2 |
| `injection-iodee` | 8 | 2 | 5 |
| `lecture-scanner` | 4 | 1 | 1 |

**Le schéma** `ech-scanner`, « Le scanner · l'échelle, la fenêtre, l'injection », donne 51 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_SCANNER`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- sct-an-2122s1-q24 B (« elle se mesure en Unité Hounsfield ») : l'unité est écrite sur presque toutes les cases du schéma (« eau : 0 UH »…) ; aucune case vide ne pourrait la cacher. La lettre est posée sur la case de l'échelle.
- sct-an-1516s2-q28 E (l'os spongieux au-delà de +1000 UH) : le cours 2025-26 ne chiffre que l'os compact, cortical (p. 3) ; la justification de l'annale s'appuie sur Radiopaedia, hors du cours. La lettre est posée sur la case des tissus, où se joue l'os compact (sct-ech-s7).

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```

La planche numérotée se refait depuis `app/` :
`uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/bmcp_scanner sct-pl-phases --apercus <brouillon>`.
