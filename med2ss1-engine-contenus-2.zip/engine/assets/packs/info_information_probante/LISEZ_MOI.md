# Chercher de l'information probante en santé — paquet Informatique médicale

62 notes, 122 cartes. Chapitre `chap-ue-info-medicale-information-probante` de
l'UE Informatique médicale, cinquième de l'UE. Cours du **Dr Erwin Gérard, le
19/11/2025, de 10 h à 11 h**, dans le **Ronéosaure 2025-26** (FC n°5, 7 pages).
**Aucune annale** : le ronéo l'écrit lui-même (« Absence d'annale car nouveau
cours », p. 1). Examen : partiel du mercredi 16 décembre 2026.

**Fiche provisoire** (C15, décision de Vincent du 02/10) : le cours de l'année
2026-27 n'est pas encore paru. Chaque carte de cours cite la FC 2025-26 à sa
page ; le ronéo 2026-27 la corrigera quand il sortira. `donnees.py` porte
`ANNEE_COURS = "2025-26"`, et l'auteur de la fiche, « Ronéosaure 2025-26 »,
donne aux cartes le badge « Cours 2025-26 ».

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 21 | 21 |
| QRU | 3 | 3 |
| Texte à trous | 12 | 67 |
| QROC | 11 | 11 |
| Recto-verso | 7 | 7 |
| Schéma cliquable | 1 | 6 |
| Planche à légender | 1 | 1 |
| Lexique | 6 | 6 |

Aucune annale, donc aucun `annales.py`, aucune session, aucun conflit.

Six thèmes, dans l'ordre du cours ; les six clés sont nouvelles (plan C15) et
leurs libellés restent à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) :

| Clé | Libellé | Notes |
|---|---|---|
| `source-fiable` | Source fiable et donnée probante | 17 |
| `ebm` | Médecine fondée sur les preuves | 14 |
| `pico` | Formuler une question clinique : PICO | 4 |
| `sources-information` | Sources d'information en santé | 8 |
| `evaluer-source` | Repérer une bonne source ; biais | 7 |
| `ia-generative` | IA générative et recherche d'information | 6 |

Les sept cartes du tableau de la HAS (p. 5) portent en plus le tag existant
`niveaux-preuve` (« Niveaux de preuve », biomédecine quantitative), dont le
libellé dit vrai ici : on les révise avec les niveaux de preuve de l'autre UE.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-info-probante-2526` — Ronéosaure, « FC n°5 Chercher de l'information probante en santé » (7 p.) | 2025-26 | le cours ; `SRC["fiche"]`, `SRC["cours"]`, `SRC["medias"]` ; ses deux figures |

Le nom du fichier finit par une espace avant `.pdf` et porte une apostrophe
typographique (U+2019) : `chemin_relatif` le recopie tel quel, en NFC. Lus en
appoint, sans être déclarés : l'errata des cours 2025-26 (vide : le tableau
n'a que ses deux exemples), l'errata des annales 2024-25 (vide). Aucun cours
2023-24 ni 2024-25 ne tenait ce cours, aucun polycopié d'annales n'en parle.

L'en-tête du ronéo porte des noms d'étudiants : aucun n'est repris.

## Ce que le cours a dicté

- **Ni rouge ni gris** dans ce ronéo : tout se carte. Le plan en douze parties
  fait les six thèmes.
- **Ce que le professeur n'a pas détaillé** : la pyramide des preuves (« pas
  détaillé par le prof car pas l'objectif du cours », p. 5) et les biais
  (« pas de détail car pas l'objet du cours », p. 7). Le tableau de la HAS,
  projeté, se carte tel qu'il est imprimé (planche, texte à trous, deux QCM,
  un recto-verso) ; les biais, par leur seule liste et la seule définition
  donnée, celle du biais de sélection.
- **Ce qui n'est pas carté ici**, parce qu'un autre chapitre le tient (plan C15) :
  les types d'études et l'échelle phase III > cohorte > cas-témoins > cas
  (`info_reutilisation`, FC3) ; les méthodes du machine learning et l'évaluation
  des modèles (`info_machine_learning`, FC8). Les cartes les citent.
- **Deux listes de cinq à ne pas mélanger** (p. 2-3) : la source fiable
  (transparence, rigueur, évaluation, objectivité, actualisation) et la donnée
  probante (origine scientifique, validités interne et externe, niveau de
  preuve, pertinence clinique). Un texte à trous chacune, et un QCM qui les
  oppose (`ebm-qc-caracteristiques`).
- **Les couples à ne pas inverser** ont leur recto-verso : mésinformation et
  désinformation, validité interne et externe, source fiable et donnée
  probante, grade et niveau, biais cognitif et biais d'étude, Embase et
  CINAHL, Anses et ANSM.

## Ce que les annales ont dicté

Rien : il n'y en a pas. Le chapitre se carte en questions du cours (24 QCM,
dont 3 QRU), textes à trous, QROC et recto-verso, comme le plan C15 le prévoit.

## Les erreurs du ronéo 2025-26

Le Ronéosaure n'est pas la ronéo de l'année (convention C13) : ses erreurs se
signalent par un **ATTENTION nu**, sans genre, et n'entrent pas dans
`contenu/ERRATA_RONEOS_2026-27.md`.

| Page | Le ronéo dit | Retenu | Sorte | Carte |
|---|---|---|---|---|
| 6 | « aux USA, 40 % de la population est obèse alors que 10 % en France » | France 17,2 % d'adultes obèses (étude Esteban 2015, Santé publique France, BEH 2017 n° 13) ; États-Unis 42,4 % (CDC, NHANES 2017-2018, NCHS Data Brief n° 360). L'idée du cours, USA ≠ France, reste juste | point douteux | `ebm-qc-reperer` E |
| 5 | « en cas d'allergie à l'acide ascorbique, on fait quoi ? » | exemple obscur (l'allergie vraie à la vitamine C est exceptionnelle) ; seule l'idée se carte : l'essai comparatif l'emporte sur l'étude cas-témoins | point douteux, sans carte | `ebm-qc-hierarchie` C (l'idée seule) |
| 5 | « L'Institut national du cancer (InCA) » | INCa | coquille, sans ATTENTION | `sources-sante.svg`, `ebm-qc-organismes` (explication) |
| 5 | « The Journal of the American Medical (JAMA) » | Journal of the American Medical Association | coquille, dite dans la justification | `ebm-qc-bases` E |
| 5 | « Cochrane CENTRAL : essais randomisés et systématique » | CENTRAL est le registre central des essais contrôlés de la Cochrane ; ses revues systématiques sont dans une autre base de la même bibliothèque | imprécision, dite dans la justification | `ebm-qc-qru-cochrane` C |

## Les clés qui ne sont pas reprises telles quelles

Sans objet : aucune annale. Aucune carte n'est `a-relire`.

## Les schémas et les figures

Deux figures du ronéo, extraites du PDF en PNG (xref 22 et 25), illustrent les
corrections ; six schémas redessinés (`schemas.py`) couvrent les pages qui n'en
ont pas. **23 QCM sur 24 sont illustrés** (96 %) : seul celui de
l'introduction (`ebm-qc-introduction`) n'a pas de figure à montrer.

| Fichier | Ce que c'est | Cartes |
|---|---|---|
| `ebm-trois-piliers.png` | la diapositive des trois piliers de l'EBM, p. 4 | 3 |
| `ebm-grades-has.png` | le tableau de la HAS, grades et niveaux de preuve, p. 5 | 6, et la correction de la planche |
| `ebm-grades-has-numerote.png` | le même tableau, grades et niveaux effacés et numérotés : la question de la planche | 1 |
| `pico-question.svg` | **schéma cliquable** : une question clinique en six segments, sans aucune lettre | `ebm-zo-pico` (6 zones) |
| `pico-question-legende.svg` | le même, légendé P, I, C, O, T, S | 3, et la correction de la zone |
| `source-fiable-probante.svg` | source fiable, donnée probante, points de vigilance (p. 2-3) | 11 |
| `ebm-usages.svg` | les trois piliers et les six usages de l'EBM (p. 3-4) | 3 |
| `sources-sante.svg` | production scientifique, organismes publics, international, sociétés, associations (p. 5-6) | 8 |
| `reperer-source.svg` | les cinq questions pour juger une source et les biais (p. 6-7) | 7 |
| `ia-generative.svg` | modèle de langage, bons et mauvais usages, hallucinations, biais (p. 7) | 6 |

**La planche `ebm-pl-grades`**, comme le plan C15 la demande : sur le
tableau de la p. 5, les trois lettres de grade, les trois noms de grade et les
quatre niveaux sont effacés et numérotés (10 numéros) ; les études restent
visibles, et c'est d'elles qu'on déduit le grade et le niveau. Intrus : « Grade
D », « Avis d'experts », « Niveau 5 ». Les rectangles sont mesurés sur un
agrandissement quadrillé et gardés dans `donnees.py` ; l'image se refait avec
`scripts/planche_depuis_image.py`. L'aperçu de contrôle a été regardé : aucun
reste de lettre, aucun trait entamé. Le tableau est celui de l'ANAES (2000),
que la HAS reprend dans son état des lieux d'avril 2013 ; elle y ajoute, hors
du tableau, l'« accord d'experts » des recommandations sans grade.

**Le schéma cliquable PICO** n'est pas au plan, qui ne prévoyait que la
planche : la méthode PICO se prête au clic (où est le comparateur dans cette
question ?), et c'est la confusion O = outcome / objectif qu'il attrape.
L'exemple (l'adulte hypertendu de plus de 65 ans, un diurétique thiazidique
plutôt qu'un inhibiteur calcique, la mortalité cardiovasculaire, à cinq ans, en
médecine de ville) est construit pour l'exercice : le ronéo n'en donne pas, et
la carte le dit. La formulation évite « comparé à », qui vendrait le C. Une
zone par segment, rectangles disjoints, lus des mêmes constantes que le dessin.

## Le lexique

Six termes, ceux du plan C15, aucun déjà pris dans un autre paquet ni réservé
par le plan de biomédecine quantitative (vérifié dans tous les `paquet.json` et
`donnees.py` le 02/10, et dans `plan_biostat.md`). Pages mesurées dans le PDF,
en-tête courant exclu (`pages_termes.py` du plan) ; aucune annale ne les
emploie.

| Terme | Origine | Pages |
|---|---|---|
| Probant | latin probans, -antis (probare) | 1, 3, 7 |
| Infobésité | mot-valise, latin informatio + obesitas | 2 |
| Mésinformation | français més- (francique *missi, TLFi) + information | 3, 4, 6 |
| Désinformation | français, de désinformer (XXe siècle) | 3 |
| Méta-analyse | grec metá + análusis (Glass, 1976) | 5 |
| Hallucination | latin hallucinatio | 7 |

Les étymologies sont proposées dans
`scratchpad/etym/info_information_probante.json` (forme de `etymologies.json`,
que ce chapitre ne touche pas). Racines déjà dans la table, réemployées sous
leur clé exacte : `méta-`, `ana- (grec)`, `-lyse`, `dé- (latin)`.
`informare (latin)` est écrite comme dans la proposition de `genet_sequencage`.
Nouvelles : `probare (latin)`, `obesus (latin)`, `més- (francique)` (origine
« origine francique », pour que `appliquer_etymologies.py` ne la réécrive pas),
`hallucinari (latin)`.

Laissés à d'autres chapitres : *biais*, *sensibilité*, *prévalence* et les
termes d'épidémiologie (biomédecine quantitative) ; *observance* (déjà
`lex-observance`, BMCT) ; *cohorte* (`lex-cohorte`, biostatistiques).

## Décisions prises en route

- **La planche suit le plan**, et non un premier essai qui effaçait les types
  d'études : lettres, noms de grade et niveaux effacés, études visibles.
- **`EXAMENS` n'est pas déclaré** (convention de BMCT et du plan C15).
- **Le PICO a un exemple construit** dans un QCM (`ebm-qc-pico` : l'enfant
  asthmatique, la corticothérapie inhalée, le placebo, les hospitalisations,
  un an) et dans le schéma cliquable ; les deux le disent dans leur
  explication.
- **Une seule figure par carte**, côté réponse ; le schéma nu PICO et la
  planche numérotée sont les seules images montrées avant la réponse.

## Questions pour Vincent

Aucune des trois questions du plan C15 ne touche ce chapitre. Une seule, née
en route :

1. Le schéma cliquable PICO (`ebm-zo-pico`, six cartes de zone) n'était pas au
   plan, qui ne prévoyait que la planche de la HAS. Je l'ai gardé, signalé ici
   et dans son explication (exemple construit) : tu le gardes ?

## À relire

Aucune carte `a-relire` : chaque carte cite sa page de la FC 2025-26, et le
seul point douteux qui touche une carte (l'obésité, p. 6) a ses sources dans
la carte. Reste à Vincent :

- quand le ronéo 2026-27 paraîtra, relire chaque carte sur lui et retirer le
  badge « Cours 2025-26 » ;
- `copier_les_cours.py` avec le dossier `…/examen décembre` du Ronéosaure
  2025-26, hors du bac à sable, pour que la fiche s'ouvre dans l'application ;
- ajouter les six libellés de thèmes à `THEME_LABELS`.

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```
