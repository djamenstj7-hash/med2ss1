# Le CMH et la présentation des antigènes aux LT — paquet Immunologie

83 notes, 151 cartes. Chapitre `chap-ue-immunologie-fc3` de l'UE Immunologie
(identifiant du squelette), construit en même temps que `immuno_temporelle` et
`immuno_organes` ; examen de novembre (aucune date encore, donc pas d'`EXAMENS`). Cours du **Pr Dubucquoi,
le 25/09/2026**, en deux ronéos : la **partie 1** (16 pages, le début du cours,
arrivée le 03/10/2026) et la **partie 2** (10 pages, la fin). Le Ronéosaure 2024-25 (Pr Labalette)
n'est plus qu'un appoint. Annales : 19 questions sur 12 sessions.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 39 | 39 |
| QRU | 1 | 1 |
| Texte à trous | 12 | 68 |
| QROC | 10 | 10 |
| Recto-verso | 10 | 10 |
| Lexique | 9 | 9 |
| Schéma cliquable | 2 | 14 |

Dont **19 annales** sur 12 sessions (2017/2018 S1 à 2024/2025 S1) : 15 QCM et
4 QROC rédactionnels, en recto-verso. **38 QCM sur 40 illustrés** (95 %) : des
figures des deux ronéos 2026-27, une diapositive de la FC n°3 2024-25 (la
codominance), deux schémas redessinés pour le clic. **7 cartes absentes du cours
2026-27** (tag `absent-2026`), **10 cartes portent un piège du ronéo** (thème
« Pièges des ronéos »).

Sept thèmes, dans l'ordre du cours : six nouveaux, et `cellules-dendritiques`,
partagé avec `immuno_temporelle` sous le même libellé. Leurs libellés sont dans
`THEME_LABELS` (`app/src/med_engine/application/scopes.py`), que
`test_tout_theme_du_paquet_a_son_libelle` vérifie sur ce chapitre.

| Clé | Libellé |
|---|---|
| `genes-hla` | Les gènes du système HLA |
| `molecules-hla` | Structure et expression des molécules HLA |
| `chargement-peptides` | Le chargement des peptides |
| `cmh-peptide-tcr` | Le complexe CMH-peptide et le TCR |
| `role-hla` | Rôles des molécules HLA |
| `presentation-croisee` | La présentation croisée |
| `cellules-dendritiques` | Les cellules dendritiques |

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-immuno-cmh-1` — Ronéo & Juliette, « Cellules dendritiques 1 » (16 p.) | **2026-27** | **la base du début du cours** : BCR et TCR (p. 2-5), gènes, polymorphisme, haplotypes (p. 6-10), structure et expression des molécules (p. 11-13), chargement des peptides (p. 14-16) ; ses 26 notes de cours portent leur page et `fiche=FC1` ; c'est ce que le lecteur ouvre |
| `src-fc-immuno-cmh` — Ronéo & Juliette, « Les cellules dendritiques 2 » (10 p.) | **2026-27** | **la base de la fin du cours** : la niche, les poches d'ancrage, le TCR (p. 2-5) et les cellules dendritiques (p. 5-10) ; ses 22 notes de cours portent leur page ; c'est le fichier `LES CELLULES DENDRITIQUES.pdf` déjà déclaré (livré le 03/10 sous le nom `LES CELLULES DENDRITIQUES 2.pdf`) |
| `src-cours-immuno-cmh` — Ronéosaure, FC n°3 (27 p.) | 2024-25 | **appoint** : précisions que les ronéos 2026-27 ne donnent pas (covalence, interférons, chiffres de la classe I), et source des **7 cartes absentes** |
| `src-roneo-immuno-cmh-2324` — Charonéo 2023-24 (22 p.) | 2023-24 | appoint : β2-microglobuline sur le chromosome 15, TAP en classe II, CD8 sur α3, CD4 sur β2, les deux voies de la présentation croisée |
| `src-annales-immuno-cmh` — Ronéosaure, « IMMUNO n°3 - Le CMH » (7 p.) | 2024-25 | 14 QCM, 3 QROC, table de corrections p. 6 ; source de la session 2023/2024 S1, dont le QROC 1 (corrigé officiel, absent du polycopié) |
| `src-sujets-immuno-2425` — sujet de système immunitaire 2024/2025, session 1 (3 p.) | 2024-25 | dépôt du 15/10/2026 : la Q1 (`SRC["sessions"]["2024/2025 S1"]`) ; sujet sans corrigé, clé déduite du cours ; déclaré à l'identique dans chaque chapitre d'immunologie qui en a une question |
| sujet et corrigés officiels 2023/2024 (02/11/2023 : grille des QCM, corrigé des QROC) | 2023-24 | dépôt du 15/10/2026 : confirment les clés du polycopié, donnent le corrigé du QROC 1 et les énoncés exacts des Q1 et Q3 ; cités dans les cartes, pas déclarés (la session garde son polycopié) |
| erratas d'immunologie 2024-25 (cours et annales) | 2024-25 | une seule entrée sur ce cours, « HLA-DO » pour HLA-DQ (p. 10), déjà corrigée dans la version numérique ; aucune sur ces annales |
| tableau d'erreurs d'immunologie 2026-27 | 2026-27 | vide au 03/10/2026 ; au **11/10/2026**, deux entrées sur ce cours, les deux comptes de gènes de la partie 1, p. 8 (« 3 », puis « 6 gènes de classe II » : des paires) ; au **19/10/2026**, une troisième, l'« équilibre de liaison » de la partie 2, p. 5 (déséquilibre), déjà portée en prise de notes |

Les citations de texte disent « ronéo 2026-27 (partie 1) » ou « (partie 2) » :
c'est ce qui distingue deux ronéos du même cours et de la même année. Les
vérifications faites hors du cours sont citées dans la carte qui s'en sert :
Djilali-Saiah et al., Tissue Antigens 1996 (TAP dans la région de classe II),
base IPD-IMGT/HLA 2025 (plus de 10 000 allèles HLA-B ; gènes DRA, DRB1, DQA1, DQB1,
DPA1, DPB1), Wieczorek et al., Front Immunol 2017 (le plus souvent 8 à 10 et 13 à 25 acides
aminés), Randolph et al., Nat Rev Immunol 2005 (migration des CD par la lymphe),
Sallusto et al., J Exp Med 1995, et Liu et Roche, Front Physiol 2015
(macropinocytose), Limmer et al., Nat Med 2000 (présentation croisée par les cellules
endothéliales du foie), Triebel et al., J Exp Med 1990, et Huard et al., Eur J
Immunol 1996 (LAG-3), Valleix et al., N Engl J Med 2012 (mutation de la
β2-microglobuline), Neefjes et al., Nat Rev Immunol 2011, et Roche et Furuta, Nat
Rev Immunol 2015 (les origines des peptides de la classe II), Rossjohn et al., Annu
Rev Immunol 2015 (CD1 et MR1), Price et al., Immunol Rev 1999 (l'haplotype A1-B8-DR3),
Alberts et al., Molecular Biology of the Cell (l'ARNm mature est seul traduit).

## Le début du cours a son ronéo 2026-27 (03/10/2026)

Jusqu'au 02/10, le début du cours — gènes HLA, structure, expression, chargement
des peptides — n'avait pas de ronéo 2026-27 et était carté sur la FC n°3 du
Ronéosaure 2024-25, sans `page`, avec le badge « Cours 2024-25 ». La partie 1 est
arrivée ; le chapitre a été relu contre elle, carte par carte.

**Les 18 notes qui attendaient ce ronéo** :

| Devenir | Notes |
|---|---|
| Relues sur la partie 1 (`page` et `fiche=FC1`, plus de badge 2024-25) : 15 | `cmh-qc-genes` (p. 6), `cmh-fa-regions` (p. 6), `cmh-qr-hla` (p. 6), `cmh-qr-b2m` (p. 7), `cmh-qr-dausset` (p. 2), `cmh-qc-fratrie` (p. 10), `cmh-fa-transmission` (p. 10), `cmh-qc-expression` (p. 13), `cmh-qc-chargement1` (p. 14), `cmh-fa-chargement1` (p. 14), `cmh-zo-chargement` (p. 14), `cmh-qc-chargement2` (p. 15), `cmh-fa-chargement2` (p. 15), `cmh-qr-clip` (p. 15), `cmh-qc-origine-peptides` (p. 16) |
| Devenues **absentes du cours 2026-27** : 3 | `cmh-qr-tap`, `cmh-qc-roles`, `cmh-rv-restriction` |

Six notes qui citaient la partie 2 passent aussi sur la partie 1, parce que la
notion y est enseignée : `cmh-fa-classe1` (p. 11), `cmh-qc-classe1` (p. 11),
`cmh-fa-classe2` (p. 12), `cmh-qc-classe2` (p. 12) — le CD8 sur α3 et le CD4 sur
β2, que ces quatre-là empruntaient au Ronéosaure, sont sur les diapositives p. 12 — et
`cmh-fa-caracteristiques`, `cmh-qc-caracteristiques` (p. 10, la synthèse du système HLA).

**Ce que le ronéo 2026-27 dit autrement, et ce qui a été corrigé** :

- **Le bras court du chromosome 6** est marqué « ne pas retenir » (p. 6) : il n'est plus
  un énoncé de carte (`cmh-fa-regions`, `cmh-qc-genes` A), il reste dans l'explication.
  La région compte « 250 gènes codant 150 protéines » (p. 6), que `cmh-qc-genes` cite.
- **Le chargement de la classe I** n'a plus de TAP, d'ubiquitine à part, ni de
  glycosylation seule : la diapositive p. 14 montre le protéasome, des peptides « injectés
  dans le RE », les chaperonnes (leur rôle, pas leurs noms), le tri du peptide le plus stable,
  le Golgi. Le texte à trous `cmh-fa-chargement1` garde l'ubiquitine, le protéasome, le RE, les
  chaperonnes à la place de TAP, le Golgi, la glycosylation ; `cmh-qc-chargement1` remplace
  « TAP fait entrer les peptides » par « les peptides sont injectés dans le RE ».
- **L'expression** : la proposition sur les interférons (FC 2024-25 p. 12) n'est pas dans le
  ronéo 2026-27 ; `cmh-qc-expression` la remplace par la faible expression de la classe I au
  cerveau, aux testicules et à la barrière foeto-maternelle (p. 13), et la garde dans
  l'explication.
- **La structure** : le ronéo ne dit rien de la liaison covalente (FC 2024-25) et écrit que le
  domaine qui s'associe à la β2-microglobuline « n'est pas à retenir » (p. 11) :
  `cmh-qc-classe1` D devient « la β2-microglobuline est polymorphe », fausse (p. 11).
- **Les chiffres du polymorphisme** : 5 091 allèles pour HLA-B sur la diapositive p. 8
  (près de 6 000 en 2024-25, plus de 10 000 en 2025) ; les cartes et les annales qui
  citaient « près de 6 000 » donnent les trois.
- **Les peptides de la classe I** : « 8 à 10 » dans la partie 2 (p. 3) mais « 8 à 9 AA » sur la
  diapositive du chargement de la partie 1 (p. 14) ; `cmh-fa-niches` le signale par un
  `ATTENTION` et garde 8 à 10 (la littérature le confirme).
- **Dausset** : la question ne parle plus des sérums de femmes multipares ni du prix Nobel
  (FC 2024-25) ; le ronéo dit seulement « découvert par Dausset dans les années 60 » (p. 2).
  La réponse et l'explication gardent le détail, dit de 2024-25.
- **La région intermédiaire** est citée sans plus (complément, TNF), comme en 2024-25.

**Cartes nouvelles** (5) : `cmh-qc-bcr-tcr` (BCR et TCR, p. 3-4, avec la figure p. 4) ;
`cmh-fa-presentation` (le CMH présentoir, CD8-classe I, CD4-classe II, activation ou
tolérance, p. 5) ; `cmh-qc-polymorphisme` (le nombre d'allèles par gène, p. 8) ;
`cmh-qc-haplotype` (haplotype, déséquilibre de liaison, A1-B8-DR3, p. 9) ;
`cmh-qc-synthese-classe1` (production de la classe I, tri du peptide, six molécules,
p. 14-15). La probabilité d'être HLA-identique avec au moins un frère ou une sœur,
1 − 0,75^n (p. 10), entre dans `cmh-fa-transmission` et `cmh-qc-fratrie`, et
l'autophagie, troisième origine des peptides de la classe II (p. 15-16), dans
`cmh-qc-origine-peptides`.

**Les annales** restent cotées sur leur source ; leurs justifications citent désormais la partie
1 là où le ronéo dit la même chose, et la FC 2024-25 en appoint. Aucune clé n'a changé.

## Ce que le cours a dicté

- **Les consignes du professeur**, cartées là où elles se jouent : « la notion
  de poche d'ancrage est très importante !! » (partie 2 p. 3 : `cmh-qc-niche1`,
  `cmh-fa-niches`, `cmh-qr-ancrage`) ; « À RETENIR +++ » (partie 1 p. 7, le système
  polygénique, et p. 9, la transmission en bloc : `cmh-fa-caracteristiques`,
  `cmh-fa-transmission`) ; « il y a un vocabulaire à maîtriser !! », immature et mature
  (partie 2 p. 7) ; la diapositive de la maturation marquée « Retenir » (partie 2 p. 9 :
  `cmh-fa-maturation`, `cmh-qc-cd-maturation`) ; les deux listes de questions pour orienter
  les révisions (partie 2 p. 5 et p. 10 : `cmh-fa-caracteristiques`, `cmh-rv-classe1-classe2`,
  `cmh-rv-interlocuteurs`) ; la synthèse du système HLA en cinq points (partie 1 p. 10).
- **Ce qu'il ne faut pas retenir** : le bras court du chromosome 6 (partie 1 p. 6) ; le domaine de
  la chaîne α qui s'associe à la β2-microglobuline (partie 1 p. 11) ; les récepteurs des
  signaux de danger, « pour le fun », à « ne pas retenir » (partie 2 diapositive p. 8 — aucune
  carte ne les demande, `cmh-qc-cd-danger` ne demande que l'enchaînement) ; les noms des
  protéines chaperonnes du RE (FC n°3 2024-25, p. 13) ; les noms des chimiokines, « juste
  CCR6 et CCR7 » (FC n°3 2024-25, p. 26).
- **Le cours 2024-25** conseille d'apprendre en dessinant les molécules (p. 8) :
  d'où le schéma cliquable des deux molécules.
- **Le gris** : la partie 1 n'a qu'un passage gris (p. 6), les molécules HLA non
  classiques « qui ne seront pas abordées dans ce cours » ; la partie 2 n'en a qu'un
  (p. 5), la voix des rédacteurs, repris dans l'explication de `cmh-fa-cd-missions`. Aucun
  gris hors programme défini. Les récepteurs KIR des NK sont en gris sur la diapositive
  p. 12 de la partie 1 : repris dans l'explication de `cmh-rv-classe1-classe2`.

## Ce que les annales ont dicté

Le chargement des peptides et la niche reviennent le plus (sept sessions sur
douze : les chargements de 2020/2021 S1 et S2, la classe II de 2021/2022 S2,
2018/2019 Q2, et une proposition en 2023/2024, 2022/2023 et 2017/2018) ; puis la
classe II (six questions, dont les cellules qui l'expriment constitutivement en
2024/2025 Q1), les cellules dendritiques
matures (2021/2022 S2 Q3, 2017/2018 Q2, QROC 2023/2024), les caractéristiques génétiques du
système HLA (QROC de 2021/2022 et de 2019/2020, 2018/2019 Q1, 2022/2023 Q1), la
présentation croisée (2021/2022 Q2, QROC 1 de 2018/2019). Les cartes du cours les
préparent une à une (`cmh-zo-chargement`, `cmh-qc-niche1`, `cmh-qc-niche2`,
`cmh-qc-cd-maturation`, `cmh-fa-caracteristiques`, `cmh-qc-croisee`).

Anomalies du polycopié, dites dans la carte : l'énoncé de 2023/2024 Question 1
commençait par une autre question, rédactionnelle, collée au QCM sur la classe
II, et écrivait « chaîne b » pour β ; la proposition E du Q.3 finissait par une
parenthèse orpheline. **Le sujet officiel (dépôt du 15/10/2026) les corrige** :
les deux énoncés y sont alignés, et la question rédactionnelle est devenue sa
propre carte (voir plus bas). Le polycopié saute de la Question 1 au Q.3 : la
Q.2 est dans `immuno_reponse_t` ; 2023/2024 Q.3 est une question de lymphopoïèse
T (le TCR).

## Les annales du dépôt du 15/10/2026

Vincent a déposé les sujets 2023-24 (avec grilles et corrigés officiels) et
2024-25 (sans corrigé).

- **2023/2024, clés confirmées par la grille officielle (dépôt du 15/10/2026)** :
  `cmh-an-2324-q1` (ABC) et `cmh-an-2324-q3` (ABCD). Leurs énoncés suivent
  désormais le sujet : la question rédactionnelle retirée de la Q1, « chaîne β »,
  la parenthèse orpheline de la Q.3 E retirée. Aucune clé ne change.
- **2023/2024, Question 1 du cahier de QROC** — les fonctions des cellules
  dendritiques immatures et matures : `cmh-an-2324-qroc1`, recto-verso, corrigé
  officiel, `officielle=True`. La session garde sa source (le polycopié), et
  l'explication dit que la question et son corrigé viennent du sujet. La bascule
  CCR6 → CCR7, que le corrigé demande, n'est plus dans le ronéo 2026-27 :
  l'explication cite la FC n°3 2024-25 (p. 26-27).
- **2024/2025 S1, Q1** — les cellules qui expriment constitutivement la classe
  II : `cmh-an-2425s1-q1`, clé déduite du cours (**ABCD**), illustrée par le
  tableau d'expression (partie 1, p. 13). Le sujet imprime « consitutivement »,
  gardé. Sa Q3 (le TCR), voisine de 2023/2024 Q.3, est rangée dans
  `immuno_thymus` (`thy-an-2425s1-q3`), le chapitre du TCR.

## Les schémas cliquables

| Fichier | Ce qu'on clique | Carte |
|---|---|---|
| `hla-molecules.svg` | une molécule de classe I et une de classe II, nues : les deux niches, le plateau α1-α2 de la classe I, α3, la β2-microglobuline, α1, β1, α2, β2 de la classe II (9 zones) | `cmh-zo-molecules` |
| `chargement-cellule.svg` | une cellule présentatrice, organites sans nom : le protéasome, TAP, le RE, le Golgi, le compartiment endolysosomal (5 zones), chacun désigné par ce qu'il fait | `cmh-zo-chargement` |

Aucun nom n'est écrit, pas même « classe I » ou « classe II » : reconnaître la
molécule à sa forme fait partie de la question. Les domaines α1 et α2 de la
classe I forment une seule zone, parce que leur ordre gauche-droite n'est
qu'une convention de dessin. Pour la classe II, la chaîne α est à gauche, comme
sur toutes les figures du cours, et la légende de l'image le dit. La figure p. 2
de la partie 2 est en correction de la première carte ; la figure p. 15 de la partie 1
(classe II) en correction de la seconde. **La zone « TAP »** désigne le canal qui
injecte les peptides dans le RE : le ronéo 2026-27 le montre sans le nommer
(partie 1, p. 14), le nom vient du cours 2024-25 ; la note de la zone le dit.

## Les erreurs des ronéos 2026-27

Le tableau de la promo, vide au 03/10, relève au 11/10 les deux comptes de gènes de la
partie 1 (p. 8), et au 19/10 l'« équilibre de liaison » de la partie 2 (p. 5) ; les autres erreurs viennent de la liste vérifiée
(trouvées en relisant) et sont aussi dans `contenu/ERRATA_RONEOS_2026-27.md`. Aucun
des deux ronéos n'est corrigé ; chaque erreur est portée par une carte, avec son genre,
et la carte retient la bonne lecture. À l'examen, on répond d'abord comme le
professeur : toutes les prises de notes ci-dessous sont démenties par la diapositive de la
même page, par le même ronéo ailleurs ou par le cours 2024-25.

**Prises de notes fausses** (`ATTENTION (prise de notes)`) :

| Partie, page | Le ronéo dit | Ce qui est juste | Carte |
|---|---|---|---|
| 2, p. 5 | « équilibre de liaison » parmi les caractéristiques des gènes HLA — **tableau de la promo, 19/10** | déséquilibre de liaison (la partie 1 l'écrit p. 9-10 ; FC n°3 2024-25, p. 7 ; Charonéo 2023-24, p. 6) | `cmh-fa-caracteristiques`, `cmh-qc-caracteristiques` (E), `cmh-an-1920-qroc1` |
| 2, p. 7 | les CD « circulent par le sang entre les tissus et les organes lymphoïdes secondaires » | le sang n'apporte que les précurseurs et les monocytes vers les tissus (diapositive p. 7) ; les CD matures gagnent le ganglion par la lymphe afférente (FC n°3 2024-25, p. 25-26 ; Randolph et al. 2005) | `cmh-qc-cd-localisation` (C) |
| 2, p. 8 | les CD des tissus « n'expriment pas l'antigène, pas d'élément de communication, pas de production de cytokine » | présentation, co-stimulation et cytokines ± sur la diapositive p. 9 ; HLA I et II exprimées en base (FC n°3 2024-25, p. 27) | `cmh-qc-cd-maturation` (B), `cmh-fa-maturation` |
| 1, p. 8 | le système est polygénique « car il y a un mode de transmission équitable du patrimoine héréditaire » | polygénique = codé par plusieurs gènes (p. 7, diapositive p. 7) ; la transmission équitable est la transmission en bloc | `cmh-fa-caracteristiques`, `cmh-qc-caracteristiques` (A) |
| 1, p. 8 | « Il y a 3 gènes de classe I et 3 gènes de classes II par chromosome 6 », « donc 6 gènes de classes I et 6 gènes de classes II » — **tableau de la promo, 11/10** | trois PAIRES de gènes de classe II par chromosome (DPA/B, DQA/B, DRA/B), comme le même ronéo l'écrit p. 7 et plus haut p. 8, et la diapositive p. 7 (le « 3 classe II » de la synthèse p. 10 compte les loci DR, DQ, DP) ; six gènes de classe I et six paires de classe II avec les deux chromosomes 6 (IPD-IMGT/HLA) | `cmh-qc-caracteristiques` (A) |
| 1, p. 8 | « pour DPA2 on a que 2 allèles » | 5 sur la diapositive de la même page (7 pour DRA, 6 pour DPB2) | `cmh-qc-polymorphisme` (E) |
| 1, p. 14 | les « pré-ARN » des gènes A, B, C et de la β2m « sont traduits » | seul l'ARN messager mature est traduit ; la diapositive dit « production et assemblage » dans le RE | `cmh-qc-synthese-classe1` (C) |
| 1, p. 16 | la classe II présente, « en conditions pathologiques », des peptides du catabolisme du protéasome | trois origines pour la classe II (extracellulaire, membranaire, autophagie) selon le résumé de la même page et la diapositive p. 15 ; le protéasome sert la classe I (Neefjes 2011 ; Roche et Furuta 2015) | `cmh-qc-origine-peptides` (B) |

**C'est le cours lui-même** (`ATTENTION (cours)`) : aucune.

**Points douteux** (`ATTENTION (douteux)`), dits dans la carte sans changer sa
clé :

| Partie, page | Le point | Carte |
|---|---|---|
| 2, p. 7 | des CD « gloutonnes », « 6 fois leur volume cellulaire par jour » ; in vitro, 1 000 à 1 500 µm³ par heure, à peu près leur volume (Sallusto et al. 1995) — peut-être le chiffre du professeur, rien ne tranche | `cmh-qc-cd-maturation` (A) |
| 2, p. 8 | les CD des organes lymphoïdes secondaires « phagocytent plus » : sans doute « ne phagocytent plus » ; la diapositive p. 9 dit ± | `cmh-qc-cd-maturation` (D), `cmh-an-1718-q2` (C) |

**Une coquille de diapositive, non reprise dans la liste** : la diapositive p. 7 de la partie 1
écrit « 3 types de molécules HLA de classe II » sous les gènes de classe I, alors que la
légende qui suit dit « classe I » ; la légende de l'image le dit.

## L'erreur du Ronéosaure 2024-25

Signalée par un `ATTENTION` sans genre : le texte de la FC n°3 2024-25 place les
gènes du transporteur TAP « dans la région intermédiaire » (p. 14) ; sa propre
diapositive (p. 4), le Charonéo 2023-24 (p. 3) et la diapositive p. 6 de la partie 1 les
mettent dans la région de classe II, où ils sont (Djilali-Saiah et al. 1996) —
`cmh-qc-genes` (E), `cmh-fa-regions`. De même `cmh-fa-niches` signale par un `ATTENTION`
sans genre que les deux parties du ronéo 2026-27 donnent 8 à 10 et 8 à 9 acides aminés.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2019/2020 S1, QROC 1 | aucune (colonne absente de la table) | réponse déduite du cours, pages citées (ronéo 2026-27 partie 1 p. 10 et partie 2 p. 5 ; FC n°3 2024-25 p. 5-7) | la carte le dit en tête de son explication |
| 2024/2025 S1, Q1 (`cmh-an-2425s1-q1`) | aucune (sujet sans corrigé) ; le PDF déposé surligne A, B, C | **ABCD**, déduite du cours, non officielle | DC, cTEC, mTEC et LB expriment la classe II en conditions basales (tableau du ronéo 2026-27 partie 1, p. 13 ; « TCR et lymphopoïèse T », p. 11-12) ; le LT seulement activé. **D (les LB) est un conflit déclaré** : le surlignage du PDF l'omet, mais le cours 2024-25 range les LB parmi les « cellules exprimant constitutivement les molécules HLA de classe I et II » (FC n°3 2024-25, p. 23). Ce surlignage, d'auteur inconnu, ne couvre que les Q1 et Q3 du sujet ; sur le sujet 2023-24, le même surlignage reproduit la grille officielle |

Toutes les autres clés sont reprises. Trois restent justes pour le cours mais
sont nuancées par la référence ; elles sont déclarées dans `CONFLITS`, gardent
la clé imprimée et `cle_officielle`, et la justification commence par
`ATTENTION` (le quatrième conflit déclaré est celui de 2024/2025 Q1 D, ci-dessus) :

| Question | Clé | La nuance |
|---|---|---|
| 2017/2018 S1 Q1 B, vraie | AB | « issues de différents gènes localisés sur le chromosome 6 » : vrai des chaînes α (HLA-A, -B, -C) ; la β2-microglobuline de chaque molécule est codée sur le chromosome 15 |
| 2021/2022 S1 Q2 B, vraie | BCD | présentation croisée « exclusivement » dans les CPAg : c'est le cours (Charonéo p. 12) ; hors des CPAg professionnelles du cours, les cellules endothéliales sinusoïdales du foie en font aussi (Limmer et al. 2000), que leurs auteurs appellent présentatrices non myéloïdes |
| 2019/2020 S2 Q8 B, fausse | CE | la classe II « interagit avec des récepteurs de cellules NK » : faux pour le cours (les KIR lisent la classe I) ; LAG-3, sur les NK activés, lie pourtant la classe II (Triebel et al. 1990 ; Huard et al. 1996) |

Aucune session ne contredit une autre : la classe II « en moyenne 20 acides
aminés » est vraie en 2021/2022 S2 comme en 2020/2021 S2, et les deux clés des
CD matures (2021/2022 S2, 2017/2018) s'accordent.

## Absent du cours 2026-27

Sept cartes entières ne sont dans aucune des deux parties du cours 2026-27 du Pr
Dubucquoi. Elles le disent en tête de leur explication, portent le tag `absent-2026`
et citent la FC n°3 2024-25 ou le Charonéo à la page, jamais le ronéo de l'année.

| Carte | Source |
|---|---|
| `cmh-rv-ccr7` — la bascule CCR6 → CCR7 | FC n°3 2024-25, p. 26-27 ; Charonéo 2023-24, p. 20 |
| `cmh-rv-pont-temporel` — le « pont temporel » | FC n°3 2024-25, p. 26-27 ; Charonéo 2023-24, p. 20 |
| `cmh-rv-plasmacytoides` — les CD plasmacytoïdes (seulement nommées « pDC » sur la figure p. 6 de la partie 2) | FC n°3 2024-25, p. 24-25 ; Charonéo 2023-24, p. 18-19 |
| `cmh-qr-il12` — l'IL-12 de la CD mature (la partie 2 dit « cytokines +++ » sans les nommer) | FC n°3 2024-25, p. 27 |
| `cmh-qr-tap` — le transporteur TAP (la partie 1 ne donne que ses gènes, diapositive p. 6, et dit « injectés dans le RE », diapositive p. 14) | FC n°3 2024-25, p. 14 et figure p. 13 |
| `cmh-qc-roles` — les rôles du HLA, surtout l'éducation thymique (la partie 1 garde la réponse T, la greffe, la tolérance du soi ; « Organes et circulation des cellules » écarte les mécanismes du thymus, en gris) | FC n°3 2024-25, p. 21-23 ; Charonéo 2023-24, p. 16-17 |
| `cmh-rv-restriction` — restriction au soi et tolérance centrale | FC n°3 2024-25, p. 21-22 ; Charonéo 2023-24, p. 16-17 |

Les quatre premières cartes viennent de la partie « cellules dendritiques » du cours du
Pr Labalette ; les trois dernières, de son début, que le ronéo 2026-27 ne reprend pas.

## Les figures

Vingt-cinq fichiers (PNG de 900 px de large au plus, 256 couleurs, et deux SVG), côté
réponse seulement. **De la partie 2** : les molécules de classe I et II (p. 2), la niche de
classe I et ses poches d'ancrage, le « puzzle », le TCR sur les berges (p. 3), la niche de
classe II (p. 4), l'origine des CD (p. 6), leur localisation (p. 7), les signaux de danger
(p. 8), la maturation et la présentation croisée (p. 9). **De la partie 1** (onze, extraites
le 03/10, sans nom d'étudiant) :

| Figure | Page | Cartes |
|---|---|---|
| `modes-reconnaissance-lt-lb.png` | 4 | `cmh-qc-bcr-tcr`, `cmh-fa-presentation` |
| `region-hla-trois-zones.png` | 6 | `cmh-fa-regions` |
| `organisation-genes-hla.png` | 7 | `cmh-qc-genes`, `cmh-qr-b2m`, `cmh-an-2223-q1`, `cmh-an-1819-q1`, `cmh-an-1718-q1` |
| `polymorphisme-alleles-hla.png` | 8 | `cmh-qc-polymorphisme` |
| `haplotypes-fratrie.png` | 10 | `cmh-qc-haplotype`, `cmh-qc-fratrie`, `cmh-fa-transmission` |
| `genes-aux-molecules-hla.png` | 11 | `cmh-an-1718s2-q2` |
| `tcr-cd8-classe1.png` | 12 | `cmh-qc-classe1`, `cmh-fa-classe1` |
| `tcr-cd4-classe2.png` | 12 | `cmh-qc-classe2`, `cmh-fa-classe2` |
| `expression-hla-cellules.png` | 13 | `cmh-qc-expression`, `cmh-qc-cpa`, `cmh-an-1920s2-q8`, `cmh-an-2425s1-q1` |
| `chargement-classe1-roneo.png` | 14 | `cmh-qc-chargement1`, `cmh-qc-synthese-classe1`, `cmh-fa-chargement1` |
| `chargement-classe2.png` | 15 | `cmh-qc-chargement2`, `cmh-qc-origine-peptides`, `cmh-fa-chargement2`, `cmh-qr-clip`, `cmh-zo-chargement`, `cmh-an-2021s2-q2` |

**Quatre des six diapositives du Ronéosaure 2024-25 que Vincent avait autorisées le
29/09 « en attendant le ronéo » sont remplacées par celles de la partie 1** (les trois
zones, l'organisation des gènes, l'expression, le chargement de la classe II : la même
figure du professeur, en meilleure résolution, côté ronéo de l'année). Il en reste
**deux**, sans équivalent dans la partie 1 : `codominance-hla.png` (FC n°3 2024-25, p. 7 :
`cmh-fa-caracteristiques`, `cmh-qc-caracteristiques`, `cmh-an-2122-qroc3`,
`cmh-an-1920-qroc1`) et `chargement-classe1.png` (p. 13, avec TAP, que le ronéo 2026-27 ne
nomme pas : `cmh-qr-tap`, la carte absente). Les deux QCM sans illustration sont
`cmh-qc-cd-role` et `cmh-qc-roles` (absente).

## Le lexique

Neuf termes, qu'aucun autre chapitre d'immunologie n'accueille : histocompatibilité, haplotype, allèle,
polymorphisme, β2-microglobuline, protéasome, cellule dendritique, endocytose,
macropinocytose. Pages mesurées dans le texte des ronéos 2026-27 et de la FC n°3
2024-25 (la logique de `chercher_pages.py`, avec pymupdf, `uv` n'étant pas sur
le PATH ; l'en-tête de la partie 2 répète « cellules dendritiques » à chaque page,
seules les pages 5 à 10 sont retenues ; le plan de la partie 1, p. 1, n'est pas compté).
Le 03/10, les pages de la partie 1 ont été ajoutées en tête pour sept termes
(histocompatibilité p. 4, haplotype p. 9-10, allèle p. 8-10, polymorphisme p. 7-9 et 11,
β2-microglobuline p. 7-8, 11-12 et 14, protéasome p. 14 et 16, cellule dendritique p. 13) ;
« endocytose » et « macropinocytose » n'y sont pas dans le texte. Les racines
qu'enseignent les FC de sémantique citent leur page (hist(o)- et cyt(o)- 1/2 p. 8, endo- 1/2 p. 2,
morph(o)-, micr(o)- et macro- 2/2 p. 6, -ose 2/2 p. 9) ; les autres sont hors
FC. La racine de la cellule s'écrit `cyt(o)- / -cyte`, comme dans
`immuno_temporelle`, pour qu'elle ne fasse qu'une entrée dans la table. L'origine grecque ou latine de chaque terme et de chaque racine nouvelle est
proposée pour la table `etymologies.json` du skill (vérifiée sur le
Wiktionnaire, le TLFi, le Bailly et le Gaffiot), à fusionner puis à écrire par
`appliquer_etymologies.py`.

## À relire

Aucune carte ne porte le tag `a-relire` : chaque carte cite sa page, dans l'un
des deux ronéos 2026-27 ou, pour les sept cartes absentes, dans la FC n°3 2024-25 ou le
Charonéo 2023-24, et les deux clés déduites, celles du QROC 1 de 2019/2020 et de la Q1 de
2024/2025, le sont du cours, pages citées. Reste ouvert, et dit sur la carte : l'origine
du surlignage A, B, C du sujet 2024/2025 (Q1 D). Reste à décider (Vincent) : le fichier de la partie 2 est livré le 03/10 sous
le nom `LES CELLULES DENDRITIQUES 2.pdf`, alors que la source garde l'ancien nom
`LES CELLULES DENDRITIQUES.pdf` ; `outils/copier_les_cours.py` cherche les fiches par leur nom.

## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026)

Le pilote de l'immunité innée, étendu au reste de l'immunologie pour l'examen du 4/11 (choix de Vincent, 15/10). Sous les annales, 30 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 9 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `genes-hla` | 6 | 2 | 4 |
| `molecules-hla` | 6 | 2 | 5 |
| `chargement-peptides` | 8 | 1 | 3 |
| `cmh-peptide-tcr` | 3 | 2 | 2 |
| `presentation-croisee` | 3 | 1 | 2 |
| `cellules-dendritiques` | 4 | 1 | 3 |

**Le schéma** `ech-cmh`, « Le CMH · des gènes à la présentation aux LT », donne 55 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_CMH`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu les dix chapitres ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- cmh-an-2324-q3 A : le TCR des thymocytes doubles positifs relève de la lymphopoïèse T ; aucun des deux ronéos 2026-27 du CMH n'en parle (ronéo 2026-27 « TCR et lymphopoïèse T », p. 11, chapitre du thymus). La lettre est posée sur la case du TCR.
- cmh-an-2122s2-q3 D : CD28, le récepteur du LT qui lit les molécules de co-stimulation, n'est nommé dans aucun des deux ronéos du CMH ; la marche m8 ne prépare que la co-stimulation +++ de la CD mature, pas le piège CD28.

## Régénérer

```powershell
cd contenu\chapitres\immuno_cmh
..\..\..\app\.venv\Scripts\python.exe generer.py
```
