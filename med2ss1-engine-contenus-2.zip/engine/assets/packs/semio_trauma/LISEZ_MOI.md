# Examen d'un traumatisé de la route — paquet de sémiologie

93 notes, 157 cartes. **La base est la ronéo 2026-27** (Ronéo & Juliette, cours du
Pr Wiel du 28/09/2026, 10 pages) ; le Ronéosaure (fiche FC9 sur le ronéo 2025-26,
FC n°6 2024-25, Charonéo 2023-24) n'est plus qu'un appoint. S'y ajoutent les annales
de dix-huit sessions, le polycopié le plus fourni du corpus.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 51 | 51 |
| Texte à trous | 17 | 70 |
| Repérage sur schéma | 3 | 14 |
| QROC | 9 | 9 |
| Recto-verso | 5 | 5 |
| Lexique | 8 | 8 |

Sur les 51 QRM, **32 sont des annales** de 2015/2016 à 2025/2026. **27 QRM sur 51
sont illustrés** (53 %) : 19 par un des trois schémas redessinés, 7 par une figure de
la ronéo 2026-27, 1 par une figure du Ronéosaure 2024-25.

## La base : la ronéo 2026-27

Le chapitre avait été carté sur la fiche FC9 de Vincent, c'est-à-dire le ronéo de
l'année précédente (Swan & Ronéo 2025-26, cours du 17/09/2025), puis complété par
le Charonéo 2023-24. Il a été **relu note par note sur la ronéo 2026-27 le
11/10/2026**, comme `immuno_cmh` le 03/10 :

- la ronéo est déclarée dans `SOURCES` (`src-fc-semio-trauma`, seule source qui
  porte `chapitre=`) et c'est `SRC["fiche"]` ; l'en-tête imprime « 28/09/25 »,
  coquille de l'année (la ronéo se dit « Ronéo Et Juliette 2026-2027 ») ;
- **50 notes de cours sur 53 citent la ronéo 2026-27 à leur page** (`page=`) et
  perdent le badge « Cours 2025-26 » ; les 3 autres sont « Absent du cours 2026-27 »
  (plus bas) ;
- le lexique cite la ronéo 2026-27 pour cinq de ses huit termes.

Le gris de cette ronéo (« Attention QCM possible à l'examen », sur la détresse
hémodynamique p. 5 et le Glasgow p. 9) est la voix des rédacteurs : il se carte
comme le reste.

## Ce qui a changé par rapport au Ronéosaure

La ronéo 2026-27 reprend presque mot pour mot celle de 2025-26. Ce qui a fait
bouger des cartes :

| Changement | Page | Cartes |
|---|---|---|
| L'**hypothermie** est rangée parmi les **causes** d'insuffisance circulatoire aiguë (avec un schéma). Ce n'est pas un changement de 2026-27 : le ronéo 2025-26 la rangeait déjà ainsi, et seuls le Charonéo 2023-24 et le cours 2024-25 n'en faisaient qu'un facteur aggravant. C'est la carte qui était fausse | p. 6 | `tra-qc-causes-circulatoire` : la proposition C passe de **faux à vrai** (clé ABD → **ABCD**), avec un ATTENTION qui dit les années |
| Le **Shock Index** entre dans le cours (SI = Fc / PAS, ≥ 0,9 = choc sévère) | p. 10 | `tra-qc-shockindex` et l'annale 2022/2023 QCM 15 quittent le thème « Tombé en annales, absent de la fiche » pour la détresse hémodynamique |
| L'**exsufflation** du pneumothorax suffocant (2e espace intercostal) disparaît ; la ronéo ne garde que le risque d'arrêt cardiaque par compression | p. 8 | `tra-fa-pneumothorax` absent ; la proposition D de `tra-qc-respiratoire` le dit |
| La **capnographie** comme indicateur circulatoire disparaît ; restent l'ETCO2 et « ce n'est pas un critère de Vittel » | p. 5, 7 | `tra-fa-capno` absent ; `tra-fa-etco2` nouveau |
| Le **pilote** qui décide de se poser, le **casque** du commandant, la **presse** disparaissent ; le **régulateur** décide du transport héliporté, les **pompiers** définissent la DZ, la **gendarmerie** fait le constat | p. 4 | `tra-rv-dropzone` réécrit ; `tra-qc-chantier` dit, proposition par proposition, ce qui vient des années précédentes ; `tra-qc-regulateur` nouveau |
| Le terme « polytraumatisé » n'est plus nommé ; le traumatisé grave n'est plus réservé au pronostic vital engagé ; « possible QCM sur la notion de cinétique » | p. 2 | `tra-qc-traumagrave`, `tra-qr-cinetique` |
| Quatre formules « jusqu'à preuve du contraire » (dont « une personne âgée qui chute est un traumatisé grave ») | p. 2, 4, 6, 8, 10 | `tra-qr-rachis` réécrit |
| Ajouts de 2026-27 : « on ne donne pas à boire à un traumatisé de la route » ; l'épistaxis, tête **en avant**, et sa raison ; l'anisocorie du côté de l'extra-dural (que le Charonéo 2023-24 donnait, et pas les deux cours suivants). Notions déjà là en 2025-26 mais jusqu'ici sans carte : les signes de souffrance cérébrale, le tableau du Glasgow | p. 6, 7, 9, 10 | `tra-qc-soif`, `tra-qc-epistaxis`, `tra-qc-tc-evaluation`, `tra-fa-glasgow-moteur` nouveaux ; `tra-rv-anisocorie` réécrit |
| 69 sites SEVESO dans les Hauts-de-France (63 les années précédentes) | p. 2 | justification des annales sur les causes |
| Le Charonéo donnait « 50 % meurent sur les lieux » et « 50 % des décès sont liés à une hémorragie » ; la ronéo n'en garde qu'un | p. 2 | `tra-qc-golden` corrigé, `tra-fa-mortalite` le dit |

**Nouvelles notes** (8, plus 6 termes de lexique) : `tra-qc-regulateur`,
`tra-qc-soif`, `tra-qc-epistaxis`, `tra-qc-tc-evaluation`, `tra-fa-glasgow-moteur`,
`tra-fa-pneumo-echo`, `tra-fa-etco2`, et `tra-rv-rupture`, un recto-verso dont la
radiographie de la rupture diaphragmatique est la question (la lire *est* la
question ; elle ne porte aucune légende).

## Les erreurs de la ronéo 2026-27

Aucune entrée sur ce cours dans le tableau d'erreurs de la promo au 11/10/2026 :
toutes ont été trouvées en relisant. Elles sont portées dans la carte avec leur
genre, et à reporter dans `contenu/ERRATA_RONEOS_2026-27.md`.

| Page | Ce que dit la ronéo | Ce qui est juste | Genre | Carte |
|---|---|---|---|---|
| 5 | « => Pad = PAS-PAD » | pression **différentielle** = PAS − PAD (la ronéo l'écrit juste deux lignes plus haut) | prise de notes | `tra-qr-differentielle` |
| 10 (et 7) | Vittel : « PAS ≤ 90 mmHg », « SpO2 ≤ 90 % » ; p. 7 « PAS < 90 » | les critères de Vittel sont stricts : PAS < 90, SpO2 < 90 %, GCS < 13 (La Revue du Praticien ; CESU 21 CHU Dijon). À l'examen : le récapitulatif du cours | cours | `tra-fa-vittel` |
| 6 | « Hypothermie, appelée “diamant létal” » | le diamant létal = hypothermie + acidose + coagulopathie + hypocalcémie (Dupuy et al., WJES 2025). À l'examen : diamant létal | cours | `tra-qr-hypothermie` |
| 9 | Glasgow « défini uniquement pour les traumatisés crâniens » | il décrit toute altération de la conscience (StatPearls), et Vittel le cote chez tout traumatisé grave. À l'examen : comme le professeur | cours | `tra-qc-glasgow` |
| 7 | « plus de 25 c/m chez la victime de plus de 75 ans non diabétique » | « non diabétique » s'explique (acidose compensée) ; « plus de 75 ans » n'a pas d'explication, la détresse se reconnaît à ses signes quel que soit l'âge | douteux | `tra-qr-fr` |
| 7 | le sang avalé « transformé en ammoniac (toxique et pouvant causer une perte de connaissance) » | l'ammoniac ne trouble la conscience que chez le cirrhotique ; le sang avalé fait surtout vomir (StatPearls ; NHS Scotland) | douteux | `tra-qc-epistaxis` |
| 9 | la manœuvre de Pierre Marie et Foix est interdite car le nerf facial, dans la parotide, « peut entraîner une paresthésie » | dans la parotide, le nerf facial ne donne que des branches motrices (Kenhub) ; sa compression fait grimacer et sert à révéler une paralysie faciale (OQLF) : une lésion donnerait une parésie, pas une paresthésie. À l'examen : manœuvre interdite | douteux | `tra-qc-neuro` |

Deux coquilles sans portée ne sont pas portées en erreur : « ETCO » pour ETCO2
(p. 7), et un texte qui ne nomme que les réponses motrice et verbale du Glasgow
(p. 9) — le tableau de la même page donne les trois.

## Deux questions annoncées par le professeur

En 2025-26, le ronéo rapportait **deux questions d'examen données en cours** :

> « Quelle est la première cause de mortalité du traumatisé de la route ? »
> → le **choc hémorragique**
>
> « Le score de Glasgow va de 0 à 15 ? »
> → **faux**, de **3 à 15**

La ronéo 2026-27 les redit : « Attention QCM possible à l'examen » en gris sur la
détresse hémodynamique et sur le Glasgow, « de 3 à 15 (et pas de 0 à 15) », et le
récapitulatif (« 1ère cause de mortalité → détresse hémodynamique »). Les deux
propositions restent **indispensables**.

## Réviser six listes et trois nombres

**Quatorze des trente-deux clés sont « ABCDE »** : des listes intégralement vraies,
reposées à l'identique d'une session à l'autre.

| La liste | Occurrences |
|---|---|
| Les facteurs de gravité | 5 |
| Le score de Glasgow et ses corollaires | 6 |
| Les paramètres monitorés et leurs unités | 5 |
| Les causes de traumatisme grave | 3 |

Et trois nombres, qui sont les **critères de Vittel** :

| Critère | Seuil du cours (récapitulatif, p. 10) |
|---|---|
| Pression artérielle systolique | ≤ **90 mmHg** |
| Saturation en oxygène | ≤ **90 %** |
| Score de Glasgow | **< 13** |

Six questions ne demandent que ce tri, et la fausse réponse est **toujours** la
fréquence cardiaque ou la fréquence respiratoire. Attention à un seuil qui
ressemble aux autres sans l'être : le Glasgow se cote **après correction** de la
PAS (≥ 90 mmHg) et de la **SpO2 ≥ 94 %** — et non 90 %.

## Deux anomalies du polycopié

- **2022/2023 S2 QCM 11** — la clé imprimée « BCDE » donnerait **fausse** la
  proposition « la PA est exprimée en mmHg ou cmHg » et **vraie** « la fréquence
  cardiaque est exprimée en battements par **heure** ». Les deux sont intenables :
  la ronéo 2026-27 écrit « FC : b/min » (p. 5), et la session 2021/2022 S2 pose
  les mêmes items avec « b/min » et une clé intégrale. La carte retient **ACDE**
  et n'est **pas** marquée comme clé officielle.
- **2021/2022 QCM 16** — la proposition C imprime « un patient **hyper**tendu et
  marbré doit faire évoquer un choc hémorragique », et la clé la donne vraie. La
  session 2020/2021 S2 pose la même question avec « **hypo**tendu ». Coquille de
  mot ; le texte est rétabli et la carte le signale.

### Clés non reprises telles quelles

Relues le 26/09/2026, puis le 11/10/2026 sur la ronéo 2026-27 : **aucune clé
d'annale n'est contredite par le cours de l'année**.

| Question | Clé imprimée | Retenu | Pourquoi | Source |
|---|---|---|---|---|
| 2022/2023 S2 QCM 11 (`tra-an-2223s2-q11`) | BCDE | **ACDE** — carte non officielle | A : la PA s'exprime en mmHg, et se dit en cmHg en France (120/90 = « 12/9 ») ; B : la FC s'exprime en battements par **minute** | ronéo 2026-27, p. 5 ; 2021/2022 S2 et quatre autres sessions ; Wikipédia, « Pression artérielle » ; Université Lyon 1, « Paramètres vitaux » (IFSI 2025) |
| 2021/2022 QCM 16 (`tra-an-2122-q16`) | C | C, gardée | coquille « hypertendu » dans l'énoncé de l'item ; la clé est juste, un choc hémorragique est hypotendu | ronéo 2026-27, p. 6 ; FC n°6 2024-25, p. 8 ; Collège des enseignants de médecine intensive-réanimation, « Choc hémorragique » |

Une clé de **carte de cours** a changé : `tra-qc-causes-circulatoire`, ABD →
ABCD, parce que la ronéo 2026-27, comme le ronéo 2025-26, range l'hypothermie
parmi les causes d'insuffisance circulatoire aiguë (ATTENTION dans la
proposition C).

## Hors du cours : la syncope

Le vocabulaire **syncope / lipothymie** appartient au chapitre « Abord de
l'examen » ; aucune année de ce cours ne le porte, mais trois sessions le posent
ici, mot pour mot. Il reste dans le thème **« Tombé en annales, absent de la
fiche »**, et la carte de cours `tra-qc-syncope` est « Absent du cours 2026-27 ».
La lipothymie est un malaise **sans** perte de connaissance. Le Shock Index, lui,
a quitté ce thème : la ronéo 2026-27 le porte (p. 10).

La syncope n'est pas au cours de traumatologie, mais elle est à la **ronéo
cardiovasculaire de l'année** (`src-fc-semio-cv`, p. 8, déclarée dans `SOURCES`
le 16/10/2026) : les marches `tra-ech-s32` et `tra-ech-m6` la citent, sur leur
propre schéma (`ech-malaise`), et `tra-qc-syncope` pourrait citer cette page.

## Les trois schémas cliquables

| Fichier | Ce qu'on y clique | Cartes |
|---|---|---|
| `vittel-criteres.svg` | trois paramètres retenus, un qui ne l'est pas | 4 |
| `glasgow-echelle.svg` | la plage impossible, sévère, modéré, mineur | 4 |
| `fractures-volumes.svg` | six os, du plus petit au plus grand saignement | 6 |

Le deuxième gradue l'échelle **de 0 à 16** et laisse trouver où le score commence
vraiment : la plage 0-2 y est une zone cliquable, parce que c'est elle que le
professeur annonce comme piège. Les trois citent la ronéo 2026-27 (p. 10, 9, 7).

## Les figures

Cinq figures de la ronéo 2026-27, extraites en PNG et déclarées dans `IMAGES`
avec leur page, illustrent les corrections : les causes de l'insuffisance
circulatoire aiguë (p. 6), les causes de la détresse respiratoire (p. 8), le
pneumothorax en radiographie et en scanner (p. 8), la rupture diaphragmatique
(p. 8, image de la question de `tra-rv-rupture`), le tableau du score de Glasgow
(p. 9). Une figure vient du Ronéosaure 2024-25 (FC n°6, p. 12), faute
d'équivalent dans la ronéo de l'année : les hématomes extra-dural et sous-dural en
tomodensitométrie.

## Le lexique

Huit termes. `lex-hemorragie` cite désormais la ronéo 2026-27 (p. 2, 6, 7) ;
`lex-hypotension` n'y a pas de page (la ronéo écrit « Hypo PA »). Six termes
nouveaux, dont l'origine est proposée pour `etymologies.json` (brouillon
`etym/semio_trauma.json`, vérifié sur le Wiktionnaire, le Bailly et le Gaffiot) :
**anisocorie** (que la FC de sémantique 2 définit aussi, p. 5), **médiastinite**,
**cinétique**, **désincarcération**, **défenestration**, **polytraumatisé** (sans
page : la ronéo 2026-27 ne l'emploie plus ; deux annales, si). Laissés à d'autres
chapitres : pneumothorax et hémostase (pneumologie, qui les emploie dans ses
annales), paresthésie (sémantique), trépanation (médico-légale).

## Absent du cours 2026-27

Trois cartes entières, que la ronéo du 28/09/2026 ne porte plus (`ABSENTS_2026`) ;
elles citent la fiche FC9 (2025-26), jamais la ronéo de l'année :

| Carte | La notion | D'où elle vient |
|---|---|---|
| `tra-fa-pneumothorax` | l'exsufflation au 2e espace intercostal, bord supérieur de la côte inférieure | cours 2023-24 à 2025-26 |
| `tra-fa-capno` | la capnographie, indicateur respiratoire **et circulatoire** ; VM = VT × FR | Charonéo 2023-24 |
| `tra-qc-syncope` | syncope / lipothymie | les annales (chapitre « Abord de l'examen ») |

Des propositions isolées d'une autre année le disent dans leur justification :
le casque du commandant, le pilote d'hélicoptère et la presse (`tra-qc-chantier`),
l'exsufflation (`tra-qc-respiratoire` D), l'ARM qui demande si l'on sait masser
(`tra-qr-arm`), l'anisocorie sans scanner (`tra-rv-anisocorie`).

## À relire

Aucune carte `a-relire` : chaque carte cite sa page dans la ronéo 2026-27, ou dit
d'où elle vient quand elle n'y est plus.

## Le corrigé officiel 2023-24

Le sujet de sémiologie générale 2023-24 et son corrigé officiel (une clé par question) sont arrivés le 15/10/2026. Les cartes de cette session venaient du polycopié et en gardent la source ; leur clé est vérifiée :

- 2023/2024 QCM 12 (`tra-an-2324-q12`, ADE) : clé confirmée par le corrigé officiel 2023-24, dépôt du 15/10/2026.
- 2023/2024 QCM 13 (`tra-an-2324-q13`, ABCDE) : clé confirmée par le corrigé officiel 2023-24, dépôt du 15/10/2026.


## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026)

L'échelle du pilote de l'immunité innée, étendue à la sémiologie pour l'examen du 4/11 (Vincent, 16/10 : « on continue pour les chapitres que je vais avoir à l'examen »). Sous les annales, 32 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 6 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `accident` | 7 | 1 | 7 |
| `hemodynamique` | 13 | 2 | 9 |
| `neurologique` | 5 | 1 | 7 |
| `vittel` | 6 | 1 | 6 |
| `hors-fiche` | 1 | 1 | 3 |

**Les schémas** sont au nombre de 2 : `ech-traumatise`, « Le traumatisé grave · de l'accident au pronostic » (31 Simple, 5 Moyen, 29 annales ; 66 fichiers), et `ech-malaise`, « Le malaise · nommer ce qui s'est passé » (1 Simple, 1 Moyen, 3 annales ; 6 fichiers). Une carte ou une annale va au schéma de son mécanisme. Ils sont décrits dans `schemas.py` (`ECH_TRAUMATISE`, `ECH_MALAISE`, avec leurs `TROUS_*` et `LETTRES_*`, un `FICHIERS.update` chacun) et dessinés par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Le second mécanisme**, `ech-malaise`, porte le thème `hors-fiche` (malaise, syncope, lipothymie) : il redessine la ronéo cardiovasculaire 2026-27 (p. 8), déclarée dans `SOURCES` (`src-fc-semio-cv`), que citent `tra-ech-s32` et `tra-ech-m6` (voir « Hors du cours : la syncope »).

**Sans marche** :
- Facteurs de gravité D (2023/2024 QCM 13, 2022/2023 S2 QCM 12, 2021/2022 S2 QCM 10, 2019/2020 nov S2 QCM 22) : « victime renversée ne se relevant pas » ; une victime renversée qui se relève n'est pas sans ambiguïté hors de cause, puisque la cinétique suffit (p. 2) : pas de distracteur sûr. Lettre posée sur la case des facteurs.
- Glasgow A (sept annales : « l'évaluation du traumatisé crânien se fait par le score de Glasgow ») : le mot crânien se lit déjà dans trois cases ; la case vide serait trahie. Lettre posée sur la case du Glasgow.
- 2022/2023 S2 QCM 11 D-E et D des listes de paramètres (2021/2022 S2 QCM 9, 2019/2020 nov S1 QCM 11, 2018/2019 QCM 2, 2016/2017 S2 QCM 20) : la SpO2 en % se lit déjà dans le critère de Vittel, et la température en °C n'a pas de distracteur qui apprenne ; lettres posées sur la case des constantes.
- A des listes de paramètres en mmHg (2021/2022 S2 QCM 9, 2018/2019 QCM 2, 2016/2017 S2 QCM 20) : prise par la Moyen tra-ech-m1 (A) ; pas de Simple, l'unité mmHg se lisant dans les critères de Vittel.
- 2021/2022 QCM 16 et 2020/2021 S2 QCM 16, A et D (« toujours une fracture du bassin », « une fracture ouverte ne peut pas s'infecter ») : la ronéo 2026-27 n'en dit rien (seul le fémur « fermé ou ouvert », p. 7) ; lettres posées sur la case des fractures.
- 2019/2020 juin S1 QCM 7 E (turgescence jugulaire, mécanisme distributif ou obstructif) : absent de la ronéo 2026-27 ; lettre posée sur la case des signes du choc, contre lesquels la turgescence se juge.
- 2019/2020 nov S2 QCM 21 et 2016/2017 S2 QCM 21 D : la seconde idée de la justification (60 b/min est une fréquence normale) n'est pas dans le cours ; la première (la FC n'est pas un critère de Vittel) a sa marche, tra-ech-s29.

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```

## Questions pour Vincent

- (11/10) Le professeur dit que le Glasgow est « défini uniquement pour les traumatisés crâniens » (même phrase depuis 2023-24). C'est classé comme erreur du cours : la carte répond « faux » à « il s'applique à tous les traumatisés », comme lui, et l'ATTENTION donne la référence (StatPearls). Tu es d'accord ?
- (11/10) Nouveau point douteux : le cours dit que la manœuvre de Pierre Marie et Foix peut donner une « paresthésie » par le nerf facial, alors que ce nerf est moteur dans la parotide (ATTENTION (douteux) sur tra-qc-neuro). Si tu as la diapositive, dis-moi ce qu'elle porte.
- (11/10) La carte tra-qc-causes-circulatoire a changé de clé (ABD → ABCD) : l'hypothermie est une cause d'insuffisance circulatoire aiguë dans les ronéos 2025-26 et 2026-27. La carte la donnait fausse depuis le début, en suivant la lecture du cours 2024-25. Ta révision de cette carte repart donc sur une clé différente.
