# Pathogènes viraux II : éruptions cutanées et fièvres hémorragiques — paquet Virologie

122 notes, 185 cartes. Chapitre `chap-ue-virologie-fc6` de l'UE Virologie
(ordre 7). Cours du **Pr Hober, le 18/11/2025** (11 h-13 h), « Pathogènes
viraux II : les éruptions cutanées et les fièvres hémorragiques » (FC n°7 du
Ronéosaure 2025-26, 19 pages) ; annales du polycopié VIRO n°6 du Ronéosaure
2024-25 (48 questions, 18 sessions), dont la session 2023/2024 S1 prise dans
VIRO n°2_3, et deux questions du sujet de l'examen du 09/01/2025 (2024/2025 Q9
et Q10, sans corrigé). Examen de virologie le **5 janvier 2027**.

**18/10/2026** : 2 questions du sujet de virologie 2025/2026 (examen du
08/01/2026, sans corrigé) — Q.11, Q.12 ; voir « Le sujet 2025/2026 ».

**Une fiche provisoire.** Vincent a demandé le 02/10/2026 de carter tout le
Ronéosaure 2025-26 ; le ronéo 2026-27 de ce cours n'est pas paru (la
virologie 2026-27 commence le 06/10) et corrigera les cartes à sa parution.
La source porte son année dans son auteur (« Ronéosaure 2025-26 ») : chaque
carte de cours prend le badge « Cours 2025-26 ». Aucune carte ne dit « Absent
du cours 2026-27 », et les erreurs du Ronéosaure sont dites par un ATTENTION
sans genre (précédent d'`immuno_innee`) : la liste des erreurs de la promo,
`contenu/ERRATA_RONEOS_2026-27.md`, ne concerne que les ronéos 2026-27.

**Repris d'un brouillon.** Un premier passage, interrompu le 03/10, avait
laissé `schemas.py` et 32 figures dans `media/`. Tout a été relu : les figures
sont celles des pages annoncées (une recadrée, `pv2-lesions-elementaires.png`,
qui débordait sur une photo voisine ; une ajoutée, `pv2-herpes-structure.png`) ;
dans `schemas.py`, la zone de l'épithélium englobe désormais la vésicule
dessinée au-dessus de lui (un clic sur la vésicule tombait hors zone), et la
phrase du ganglion lymphatique cite l'annale exacte (« HSV2 établit une
infection latente dans les ganglions lymphatiques », 2022/2023 S1 Q.11 D).

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 78 | 78 |
| Texte à trous | 14 | 68 |
| QROC | 10 | 10 |
| Recto-verso | 7 | 7 |
| Schéma cliquable | 2 | 11 |
| Planche à légender | 1 | 1 |
| Lexique | 10 | 10 |

Dont **52 annales**, toutes des QRM (la virologie n'a pas de QROC), sur 20
sessions, de 2015/2016 S1 à 2025/2026. Les 26 QCM du cours ont, comme les
annales, une justification par proposition.

Sept thèmes, dans l'ordre du cours — sept clés nouvelles, sans chiffre, à
ajouter à `THEME_LABELS` (`app/src/med_engine/application/scopes.py`) ; aucune
n'y est encore, et les trois partagées portent le même libellé dans les autres
chapitres de l'UE :

| Clé | Libellé |
|---|---|
| `eruptions-maculopapuleuses` | Éruptions maculo-papuleuses |
| `eruptions-vesiculeuses` | Éruptions vésiculeuses |
| `herpesviridae` | Les Herpesviridae (partagé avec `viro_antiviraux`) |
| `poxvirus` | Les poxvirus |
| `hpv` | Les papillomavirus humains (partagé avec `viro_vaccins`) |
| `arbovirus` | Les arbovirus (partagé avec `viro_vaccins`) |
| `fievres-hemorragiques` | Fièvres virales et fièvres hémorragiques |

Le plan proposait « Fièvres hémorragiques virales » pour la dernière : le
thème porte aussi les fièvres prolongées (CMV, VIH, EBV, p. 12), d'où le
libellé élargi.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-viro-fc7` — Ronéosaure, « FC n°7 Pathogènes viraux 2 - Eruptions cutanées et fièvres » (19 p.), `VIROLOGIE/…` | **2025-26** | **la base** : chaque note du cours porte sa page (index du PDF, couverture = p. 1) ; c'est ce que le lecteur ouvre (`chapitre=`) |
| `src-annales-virologie-6-pathogenes-viraux-ii` — « VIROLOGIE 6 - Pathogènes viraux II » (24 p.) | 2024-25 | 46 questions et la table de corrections (p. 23-24) |
| `src-annales-virologie-2-3-multiplication-des-virus` — « VIROLOGIE 2_3 - Multiplication des virus » | 2024-25 | la session 2023/2024 S1 (questions 9 et 10, table p. 8) |
| `src-sujet-viro-2425` — « Sujet de virologie 2024/2025, session 1 » (examen du 09/01/2025, 16 p., 30 QCM) | 2024-25 | la session 2024/2025 (Q9, Q10) ; sujet sans corrigé ; déclaration identique dans tous les chapitres de virologie qui en prennent une question |
| FC n°1 partie 1 et 2, FC n°10 partie 1 2025-26 | 2025-26 | citées dans le texte, à la page, sans être déclarées : les fiches d'autres chapitres de l'UE |
| Cours 2024-25, FC n°5 « Les pathogènes viraux » | 2024-25 | cité dans le texte, pour trois erreurs du Ronéosaure 2025-26 et une annale (« les arbovirus, première cause d'encéphalite », p. 37) |
| Erratas du Ronéosaure : cours 2025-26 (`Erratas Virologie.docx`) et annales 2024-25 | — | une entrée sur la FC n°7 (« V. de la fièvre », p. 13) ; une entrée sur VIRO n°6 (la table p. 24), reprises |

**Les deux déclarations d'annales sont partagées** avec les autres chapitres
de l'UE : elles portent exactement les champs convenus (identifiant tiré du
nom du fichier, `kind`, `titre`, `chemin_relatif`, `auteur`), rien d'autre.
VIRO n°5, qui imprime aussi trois de ces questions, n'est pas déclaré ici :
chaque carte de ces questions le nomme dans son explication.

Vérifications hors du cours, citées dans la carte qui s'en sert : CIRC,
monographie 100B (HPV et oropharynx, EBV et nasopharynx) ; Zerr et al., N
Engl J Med 2005 (transmission salivaire de HHV-6) ; Vasilakis et al., Nat Rev
Microbiol 2011 (cycle selvatique simien de la dengue) ; ICTV (papillomavirus :
ADN double brin circulaire, capside nue) ; l'étymologie (TLFi, Bailly,
Gaffiot, Wiktionnaire).

## Ce que le cours a dicté

- **Le classement par lésion**, qui est le plan du cours (maculo-papule,
  vésicule, pustule, papule, nodule) : un schéma cliquable, un recto-verso
  (`pv2-rv-maculo-vesicule`), deux textes à trous et cinq termes du lexique.
- **Pas de rouge ni de gris** dans cette FC : le gras seul. Aucune consigne du
  professeur (« à ne pas connaître ») ne retire de passage.
- **Ce qui n'est pas carté** : les chiffres d'épidémies (1 000 cas par an de
  monkeypox en RDC est dit dans une justification, pas demandé ; 20 000 cas
  d'Ebola en 2013-2016, 2 000 cas de Rift, cécité dans 10 % des cas) ; la
  « quarantaine de gènes de la latence » (p. 6), douteuse ; le syndrome
  urémique des hantavirus (p. 16), dont la phrase est confuse ; la symétrie de
  la capside des poxvirus — le ronéo dit « hélicoïdale » (p. 9), le cours de
  structure range les poxvirus parmi les virus « complexes » (FC n°1 partie 2,
  p. 2) : la carte `pv2-qc-poxvirus-structure` ne la demande pas et le dit.

## Les erreurs du Ronéosaure 2025-26

Dites par **ATTENTION**, sans genre, dans la carte qui porte la notion ; celles
dont aucune réponse ne dépend sont dites dans l'explication, sans ATTENTION.

| Page | Ce que dit le Ronéosaure | Ce qui est juste | Carte |
|---|---|---|---|
| 12 | « Les virus ne sont pas impliqués dans les fièvres prolongées », suivi de la liste CMV, VIH, EBV | ils y sont **rarement** impliqués : « les étiologies virales de fièvres prolongées sont peu fréquentes » (cours 2024-25, FC n°5, p. 35) ; annales 2017/2018 S1 et S2 Q21 A, cotées vraies | `pv2-qc-fievres-prolongees` E, `pv2-an-1718s1-q21` A, `pv2-an-1718s2-q21` A |
| 15 | la dengue, « au départ animal (réservoir : oiseaux) » | réservoir **humain** (même page ; FC n°10 partie 1 2025-26, p. 11 : « il n'a pas de réservoir animal ») ; cycle selvatique d'origine simien | `pv2-qc-dengue` D, `pv2-an-1617s2-q23` B, `pv2-an-1516s1-q23` B, `pv2-an-2526-q12` C |
| 11 | les HPV-16 et 18 « provoquent des cancers du nasopharynx et de la cavité buccale » — **le cours lui-même** (même phrase en 2024-25 et dans la FC n°10 partie 1) | l'**oro**pharynx (amygdales, base de langue) ; le cancer du nasopharynx est celui de l'EBV (CIRC, monographie 100B) | `pv2-qc-hpv` E |
| 13 | « V. de la fièvre » dans le tableau des arbovirus (errata du cours) | le virus de la fièvre **jaune** | dit dans `pv2-fa-arbovirus-familles` |
| 17 | la forêt de Kyasanur « (Togaviridae, genre Flavivirus) » | un Flavivirus est un **Flaviviridae**, transmis par les tiques (tableau p. 17) | dit dans `pv2-qc-rift-arenavirus` |
| 12 | « le v. du Rosa River (Océanie), de Sindbis Mayaro (pays scandinaves) » | **Ross River** (Australie, Océanie) ; Sindbis (Scandinavie) et Mayaro (Amérique du Sud) sont deux virus (cours 2024-25, FC n°5, p. 35, 37) | dit dans `pv2-qc-arbovirus` |

Sans conséquence : « signe de Koplick » pour Koplik (p. 2 ; dit dans
`pv2-qc-rougeole` A et `pv2-qr-koplik`).

## Ce que les annales ont dicté

| Savoir | Combien |
|---|---|
| Maculo-papule (complexes immuns, pas de virus, non contagieuse) contre vésicule (multiplication virale, contagieuse) | presque chaque session ; 48 propositions jouent sur « contagieuses » |
| HSV : vésicules, latence dans le ganglion sensitif (ADN), réactivation, ni sang ni lymphe | 27 propositions, dans 14 questions |
| VZV : voie sanguine, éruption généralisée, latence, zona | 18 propositions |
| HPV : 6 et 11 contre 16 et 18, cavité buccale, lésions localisées | 24 propositions |
| Parvovirus B19 : mégalérythème, joues, non contagieux, IgM | 22 propositions |
| Molluscum contagiosum : réservoir humain, infection locale | 11 propositions |
| Arbovirus (ARN, vecteurs), dengue, fièvre jaune, Lassa, Ebola, Filoviridae | 12 questions |

Les mêmes questions reviennent « en miroir » d'une session à l'autre (S1 et
S2 d'une même année, polarités inversées) : chaque carte nomme sa jumelle.

**Les étiquettes en cycle de VIRO n°6.** Les énoncés imprimés sous
« 2019/2020 S1 » ont leurs clés dans la colonne « 2020-2021 Session 1 » de
la table ; ceux de « 2020/2021 S1 », dans « 2020-2021 Session 2 » ; ceux de
« 2020/2021 S2 », dans « 2019-2020 Session 1 ». Vérifié question par
question : chaque clé ainsi appariée est juste au regard du cours, et VIRO
n°4 et n°5 impriment des questions de ces sessions sous les étiquettes de la
table. L'errata des annales signale l'inversion ; les réponses, une fois
appariées, sont bonnes. **Retenu : les étiquettes de la table** ; les neuf
cartes concernées le disent dans leur explication.

| Session (table) | Questions | Clés |
|---|---|---|
| 2024/2025 (sujet du 09/01/2025, sans corrigé) | 9), 10) | **CDE**, **E** (déduites du cours) |
| 2023/2024 S1 (VIRO n°2_3) | 9., 10. | ABC, ABC |
| 2023/2024 S2 | Q9, Q10 | ABDE, BDE |
| 2022/2023 S1 | Q9, Q17 | BCDE, BDE |
| 2022/2023 S2 | Q9, Q17 | AC, ABCD |
| 2021/2022 S1 | Q9, Q17 | ABD, AC |
| 2021/2022 S2 | Q9, Q17 | ABCE, BDE |
| 2020/2021 S1 (imprimées « 2019/2020 S1 ») | Q22, Q25, Q26 | BD, ABE, ABC |
| 2020/2021 S2 (imprimées « 2020/2021 S1 ») | Q7, Q10, Q11 | ABD, ABCD, CDE |
| 2019/2020 S1 (imprimées « 2020/2021 S2 ») | Q7, 10., Q11 | ABCE, ABDE, ABCE |
| 2019/2020 S2 | Q6, Q10, Q11 | ABCD, ABCD, ACD |
| 2018/2019 S1 | Q22, Q25, Q26 | ABC, ABD, ABC |
| 2018/2019 S2 | Q22, Q25, Q26 | ABDE, ABC, ABCD |
| 2017/2018 S1 | Q21, Q22, Q25 | ABCD, AB, ACD |
| 2017/2018 S2 | Q21, Q22, Q25 | ABDE, **ACD** (imprimé ACDE), BDE |
| 2016/2017 S1 | Q23, Q24, Q27 | ACD, ABC, ABC |
| 2016/2017 S2 | Q23, Q24, Q27 | ABE, ABCE, CDE |
| 2015/2016 S1 | Q23, Q24, Q27 | ABDE, B, AB |
| 2015/2016 S2 | Q23, Q24, Q27 | DE, ACDE, BCDE |

Imprimées deux fois, cartées une fois ici : 2023/2024 S1 Q9 et Q10, 2022/2023
S1 Q9, 2021/2022 S1 Q9 (VIRO n°2_3 et n°6) ; 2021/2022 S1 et S2 Q17,
2020/2021 S1 Q25 (VIRO n°5 et n°6). Les gastro-entérites de VIRO n°6 sont
dans `viro_pathogenes_1` ; sa question sur la résistance de l'hôte (2016/2017
S1 Q21), dans « Virus et hôte ». Énoncés gardés tels qu'imprimés, coquilles
comprises, chacune dite dans sa justification : « parvorivus »,
« maculo-apules », « gengivo-stomatite », « contagiosium », « de de lésions »,
« survient surviennent » (2024/2025 Q10 D).

## Les schémas cliquables et la planche

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `lesions-elementaires-nue.svg` (`pv2-zo-lesions`) | macule, papule, vésicule, pustule, nodule, sur une coupe de peau | 5 |
| `latence-herpes-nue.svg` (`pv2-zo-latence-herpes`) | épithélium buccal, filet nerveux sensitif, ganglion sensitif, moelle, ganglion lymphatique, vaisseau sanguin | 6 |

Les lésions se reconnaissent à leur forme, sans une légende : plane, relief
plein, bulle claire pleine de virus, bulle trouble, masse profonde ; chaque
colonne est une zone (un pavage). Le trajet du HSV-1 porte deux leurres que
les annales emploient sans cesse — le ganglion lymphatique (« HSV2 établit une
infection latente dans les ganglions lymphatiques », 2022/2023 S1 Q.11 D,
« Multiplication des virus ») et le sang (« HSV1 se dissémine par voie
sanguine », 2016/2017 S1 Q24 D ; « par voie sanguine », 2015/2016 S1 Q24
C). Les versions légendées, tirées des mêmes constantes, sont en correction.
Rendus avec leurs zones superposées et relus. À la relecture, la zone du filet
nerveux était écrite en dur et laissait deux bouts de nerf hors zone (sous
l'épithélium, devant le ganglion) : elle est désormais tirée des constantes du
dessin (`X_FILET`, `Y_FILET`, `EPITHELIUM`, `GANGLION`) et va de l'épithélium au
bord du ganglion, qu'elle touche sans le recouvrir.

**La planche** `pv2-pl-b19-cinetique` : la figure « Marqueurs biologiques de
l'infection par parvovirus B19 chez l'adulte immunocompétent » (p. 3),
légendes effacées par `scripts/planche_depuis_image.py` — neuf numéros
(réticulocytes, hémoglobine, dot blot, PCR, virémie, fièvre-céphalée-myalgies,
IgM, éruption-arthralgies, IgG), quatre intrus (IgA, plaquettes, éruption
vésiculeuse, antigène viral). Les rectangles ont été mesurés sur un
agrandissement quadrillé ; l'aperçu de contrôle et l'image numérotée ont été
relus (aucun reste de lettre ; le rectangle des réticulocytes mord à peine le
creux de leur courbe).

**Illustrations** : 77 QCM sur 78 (99 %) portent une figure de la fiche ou un
schéma légendé en correction ; 110 notes sur 122. Le seul QCM sans figure,
`pv2-qc-fievres-prolongees`, n'en a pas dans la fiche. Pas de section « Sans
illustration ».

## Le sujet 2025/2026 (18/10/2026)

Le sujet de virologie de l'examen du 08/01/2026 (cahier de 30 QCM,
`src-sujet-viro-2526`, sans corrigé), déposé le 18/10/2026, apporte 2
questions à ce chapitre (Q.11, Q.12) ; les autres questions vont aux chapitres
de leur cours. Aucune n'était déjà en cartes. Chaque clé est déduite du cours
2025-26, l'année de l'examen, proposition par proposition et page à l'appui
(`officielle=False`) ; les propositions déjà posées d'autres années ont servi
de contre-épreuve, et l'explication dit chaque reprise. Rédigées et
contre-vérifiées le 18/10/2026 : un rédacteur, un sceptique qui a refait
chaque clé sur le cours, un critique de complétude. Le profil des clés — A
souvent vraie, trois ou quatre vraies par question — est celui des sessions 1
officielles du Pr Hober (2021/2022 S1, 2023/2024 S1).

| Question | Clé imprimée | Retenue | Lecture |
|---|---|---|---|
| 2025/2026 Q.11 (`pv2-an-2526-q11`) | aucune (sujet sans corrigé) | **ABE** | Vésicules : le virus est dans la lésion ; maculo-papules : des complexes immuns ; HSV reste local ; molluscum, réservoir humain ; HHV-8, des vaisseaux qui prolifèrent. |
| 2025/2026 Q.12 (`pv2-an-2526-q12`) | aucune (sujet sans corrigé) | **ABE** | Arbovirus : quatre familles à ARN, Togaviridae compris, et une fièvre au début ; la dengue à réservoir humain, le moustique tigre jusqu'en Normandie ; Lassa, un arénavirus des rongeurs. |

Ce qui est signalé :

- Coquilles gardées telles qu'imprimées : « provoque » au singulier (Q.11 A), «
  singes vivants », « Polynésie Française », « Aedes Albopictus » (Q.12 C et
  D).
- Q.12 C : ATTENTION sur le « réservoir : oiseaux » de la dengue (FC n°7, p.
  15), carte ajoutée à sa ligne du tableau des erreurs.
- Q.12 D : l'implantation du moustique tigre depuis 2004 est hors cours (Santé
  publique France) ; la clé se lit sur la p. 15.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2017/2018 S2 Q22 (zona, HSV, entérovirus) | ACDE | **ACD** | E attribue le zona à un Betaherpesvirinae : le VZV est un Alphaherpesvirinae, genre Varicellovirus (FC n°7 2025-26, p. 6 ; FC n°10 partie 1, p. 9) ; la même formule est cotée fausse en 2017/2018 S1 Q22 E. `officielle=False`, conflit sur E |
| 2024/2025 Q9 (`pv2-an-2425-q9`) | aucune (sujet sans corrigé) | **CDE** | clé déduite du cours : mécanisme immunopathologique connu (p. 2) ; le Koplik, des points blancs, pas des vésicules (p. 2) ; IgM de la rougeole et du B19 (p. 2-3) ; lésions du B19 non contagieuses. `officielle=False` |
| 2024/2025 Q10 (`pv2-an-2425-q10`) | aucune (sujet sans corrigé) | **E** | clé déduite du cours : molluscum Poxviridae (p. 9-10), condylomes à HPV (p. 11), HHV-8 et Kaposi (p. 12), exanthème subit non vésiculeux (p. 4), entérovirus vésiculeux (p. 4-5). `officielle=False` |

Reprises, avec une remarque dans la carte : **2022/2023 S1 Q9 C** (HHV-6 « se
transmet par voie respiratoire », cotée vraie : point douteux, voir
ci-dessous) ; **2017/2018 S1 et S2 Q21 A** (le CMV et la fièvre prolongée :
clé juste, contre une phrase fausse du Ronéosaure) ; **2018/2019 S1 et S2 Q26
C** (« les arbovirus, principaux agents d'encéphalite aiguë » : vraie, dite en
ces termes par le cours 2024-25, p. 37) ; **2019/2020 S2 Q6 E** (le pityriasis
versicolor, une mycose à Malassezia, intrus pris en mycologie).

## Questions pour Vincent

1. **HHV-6 « par voie respiratoire »** (2022/2023 S1 Q9 C, cotée vraie). Le
   cours ne dit pas comment se transmet HHV-6 ; la littérature dit la salive
   (Zerr et al., N Engl J Med 2005). Proposition appliquée (plan C16, §14) :
   garder la clé imprimée, et le dire dans la carte par un « ATTENTION —
   point douteux ». À confirmer, ou à coter autrement.
2. **HPV-16/18 et « cancers du nasopharynx »** (p. 11). C'est la phrase du
   professeur, trois années de suite. Proposition appliquée : aucune carte ne
   demande le nasopharynx ; `pv2-qc-hpv` E dit l'erreur (« ATTENTION — […]
   c'est le cours lui-même ») et la référence (oropharynx ; nasopharynx =
   EBV). À l'examen, une proposition « HPV et cancers du nasopharynx » serait
   probablement cotée vraie par le professeur.

## Le lexique

Dix termes, aux pages mesurées dans la fiche 2025-26 (`chercher_pages`, sur le
texte du PDF ; la p. 1, le plan, est retirée) : exanthème (2-4), énanthème (2),
macule (2, 4, 10), papule (2, 9-12), vésicule (4-10), pustule (9, 10),
mégalérythème épidémique (2), herpangine (4), condylome (11), arbovirus (12,
13, 16, 17). Chacun dit son origine grecque ou latine. L'herpangine est aussi
dans la FC n°5 2025-26 (p. 11), une fiche d'un autre chapitre : la page n'est
pas citée ici.

**« Papule »** existe déjà dans l'UE BMCP (`lex-papule`, `bmcp_cycle_cellulaire`) :
le terme est repris ici sous un identifiant propre, `lex-papule-viro`, comme
`lex-phagocytose-bmcp` l'a fait, pour que l'import d'un paquet ne déplace pas
la note de l'autre.

Les étymologies nouvelles sont **proposées** dans
`scratchpad/etym/viro_pathogenes_2.json` (onze racines, dix termes, avec leurs
sources) ; `scripts/etymologies.json` n'est pas modifié par ce chapitre. Les
définitions et les racines disent déjà, mot pour mot, ce
qu'`appliquer_etymologies.py` en écrira (vérifié). Racines nouvelles :
`-anthème`, `en- (grec)`, `macula (latin)`, `vesicula (latin)`,
`pustula (latin)`, `mégal(o)-`, `herpès (grec)`, `angina (latin)`,
`condyl(o)-`, `-pode`, `virus (latin)`. Racines réemployées, clé exacte de la
table : `ec- (grec)` (FC de sémantique 2/2, p. 8), `papula (latin)`,
`éryth(r)-` (FC de sémantique 2/2, p. 7), `-ome`, `arthr(o)-`.

Quatre racines nouvelles sont aussi proposées par des chapitres écrits en
parallèle, sous la même clé : `-pode`, `en- (grec)` et `virus (latin)`
(`viro_multiplication`), `vesicula (latin)` (`parasito_ectoparasitoses`).
`-pode` et `vesicula (latin)` disent la même chose partout ; `en- (grec)` et
`virus (latin)` ont été alignés à la relecture sur `viro_multiplication`
(« dans, en » ; « suc, jus ; venin, poison »). `viro_vaccins` écrit encore
« suc, humeur ; venin, poison » pour `virus (latin)` : à unifier à la fusion.

## À relire

Aucune carte `a-relire` : chaque carte de cours porte sa page dans la fiche
2025-26 ; chaque annale est recopiée mot pour mot (comparée par programme au
texte de VIRO n°6 et n°2_3) et sa clé vérifiée contre la table et le cours. À
la parution du ronéo 2026-27 de ce cours : relire toutes les cartes contre
lui — pages, délais (rubéole J16, HHV-6, varicelle), les six erreurs
ci-dessus, et la phrase sur les fièvres prolongées.


## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier. Sous les annales, 66 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 13 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `eruptions-maculopapuleuses` | 14 | 2 | 14 |
| `eruptions-vesiculeuses` | 6 | 1 | 10 |
| `herpesviridae` | 15 | 3 | 10 |
| `poxvirus` | 3 | 1 | 2 |
| `hpv` | 6 | 2 | 4 |
| `arbovirus` | 14 | 3 | 10 |
| `fievres-hemorragiques` | 8 | 1 | 2 |

**Les schémas** sont au nombre de 2 : `ech-eruptions`, « Les éruptions virales · lésion, virus, latence » (35 Simple, 6 Moyen, 34 annales ; 76 fichiers), et `ech2-lesions-vecteurs`, « Pathogènes viraux II · poxvirus, HPV, arbovirus et fièvres virales » (31 Simple, 7 Moyen, 18 annales ; 57 fichiers). Une carte ou une annale va au schéma de son mécanisme. Ils sont décrits dans `schemas.py` (`ECH_ERUPTIONS`, `ECH2_LESIONS_VECTEURS`, avec leurs `TROUS_*` et `LETTRES_*`, un `FICHIERS.update` chacun) et dessinés par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- pv2-an-2526-q11 D : le molluscum et son réservoir humain, thème poxvirus — préparé par les marches de l'autre rédacteur du chapitre ; lettre posée sur la case Poxvirus.
- pv2-an-2425-q10 A, B : le molluscum, un Poxviridae, et les condylomes des HPV 6 et 11, thèmes poxvirus et hpv — autre rédacteur ; lettres posées sur Poxvirus et HPV.
- pv2-an-2324s1-q10 A, B et pv2-an-2324s2-q10 A, B : molluscum (réservoir humain) et HPV 6 et 11 (verrues génitales), thèmes poxvirus et hpv — autre rédacteur ; « virus à ADN non enveloppés » (B) n'est d'ailleurs pas dans la FC n°7 2025-26.
- pv2-an-2122s1-q9 B et pv2-an-2122s2-q9 B : l'infection locale du molluscum et des Poxviridae, thème poxvirus — autre rédacteur ; lettres posées sur Poxvirus.
- pv2-an-2021s2-q10 D, E ; pv2-an-1920s1-q10 D, E ; pv2-an-1819s1-q25 D, E ; pv2-an-1819s2-q25 D, E : HPV 6, 11, 16, 18 et réservoir du molluscum, thèmes hpv et poxvirus — autre rédacteur ; lettres posées sur HPV et Poxvirus.
- pv2-an-1718s1-q25 E, pv2-an-1718s2-q25 E, pv2-an-1617s1-q27 B, C, pv2-an-2223s1-q17 E, pv2-an-2223s2-q17 E, pv2-an-2122s1-q17 E, pv2-an-2122s2-q17 E : les HPV de la cavité buccale et des verrues génitales, thème hpv — autre rédacteur ; lettres posées sur HPV.
- pv2-an-2223s1-q9 C, sa première moitié (HHV-6 « se transmet par voie respiratoire ») : le cours ne dit pas la voie de transmission de HHV-6, point douteux de l'annale ; la seconde moitié (l'exanthème subit) est préparée par pv2-ech-s13, qui porte l'ATTENTION.
- pv2-an-2324s1-q10 B et pv2-an-2324s2-q10 B, moitié « virus à ADN non enveloppés » : absente de la FC n°7 2025-26 (l'autre moitié le dit) ; la moitié « verrues génitales » est préparée par pv2-ech2-s9.

## Régénérer

```powershell
cd contenu\chapitres\viro_pathogenes_2
..\..\..\app\.venv\Scripts\python.exe generer.py
```

La planche se refait depuis `app/`, si ses rectangles changent :
`uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/viro_pathogenes_2 pv2-pl-b19-cinetique --apercus <brouillon>`.
